#pragma once

#include <cstdint>

// Object: Class SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate
// Size: 0x130 (Inherited: 0x130)
struct UAbilityTask_Tick_WaitAbilityActivate : UAbilityTask_WaitAbilityActivate
{

	// Object: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirementsInTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10215c420
	// Params: [ Num(5) Size(0x58) ]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirementsInTick(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C8D44
	// [Call #10] RVA: 0x10215B000
	// [Call #11] RVA: 0x1020C64D4
	// [Call #12] RVA: 0x1020C64D4
	// [Call #13] RVA: 0x1020C64D4
	// [Call #14] RVA: 0x1020C64D4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateInTick_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10215c288
	// Params: [ Num(5) Size(0x60) ]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateInTick_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E41A18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E43F54
	// [Call #11] RVA: 0x10215B050
	// [Call #12] RVA: 0x1020C4EB4
	// [Call #13] RVA: 0x1020C4EB4
	// [Call #14] RVA: 0x1020C4EB4
	// [Call #15] RVA: 0x1020C4EB4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateInTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10215c108
	// Params: [ Num(6) Size(0x28) ]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateInTick(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10215AF60
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105E41A18
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class SGameplayAbilities.SAbilitySystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct USAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function SGameplayAbilities.SAbilitySystemBlueprintLibrary.RequestGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10215c908
	// Params: [ Num(3) Size(0x20) ]
	struct FGameplayTag RequestGameplayTag(struct FString InTagName, bool ErrorIfNotFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10215B0A0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10508F76C

	// Object: Function SGameplayAbilities.SAbilitySystemBlueprintLibrary.CreateGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10215c838
	// Params: [ Num(2) Size(0x30) ]
	struct FGameplayTagContainer CreateGameplayTagContainer(struct TArray<struct FGameplayTag>& SourceTags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10215B0F4
	// [Call #4] RVA: 0x105E421EC
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E3C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E3C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10215B0A0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
};

// Object: Class SGameplayAbilities.SAbilitySystemComponent
// Size: 0x1218 (Inherited: 0x1140)
struct USAbilitySystemComponent : UAbilitySystemComponent
{
	uint8_t Pad_0x1140[0x58]; // 0x1140(0x58)
	struct FString LuaFilePath; // 0x1198(0x10)
	struct TArray<struct UGameplayAbility*> PreloadedAbilities; // 0x11A8(0x10)
	struct TArray<struct FGameplayAbilitySpecHandle> PreloadedAbilityHandles; // 0x11B8(0x10)
	struct FLuaNetSerialization LuaNetSerialization; // 0x11C8(0x50)


	// Object: Function SGameplayAbilities.SAbilitySystemComponent.TryActivateAbilitiesByTagString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10215cd20
	// Params: [ Num(3) Size(0x12) ]
	bool TryActivateAbilitiesByTagString(struct FString AbilityTag, bool bAllowRemoteActivation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x10215B47C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function SGameplayAbilities.SAbilitySystemComponent.ReloadAbilities
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10215cd0c
	// Params: [ Num(0) Size(0x0) ]
	void ReloadAbilities();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x10215B47C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function SGameplayAbilities.SAbilitySystemComponent.GiveAbilityByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10215cc80
	// Params: [ Num(2) Size(0xC) ]
	struct FGameplayAbilitySpecHandle GiveAbilityByClass(struct UGameplayAbility* AbilityClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10215B404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10215B47C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function SGameplayAbilities.SAbilitySystemComponent.CancelAbilitiesByTagString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10215cb9c
	// Params: [ Num(1) Size(0x10) ]
	void CancelAbilitiesByTagString(struct FString AbilityTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215B504
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10215B404
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x10215B47C
};

// Object: Class SGameplayAbilities.SGameplayAbility
// Size: 0x4A8 (Inherited: 0x440)
struct USGameplayAbility : UGameplayAbility
{
	uint8_t Pad_0x440[0x58]; // 0x440(0x58)
	struct FString LuaFilePath; // 0x498(0x10)


	// Object: Function SGameplayAbilities.SGameplayAbility.K2_OnGiveAbility
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xB8) ]
	void K2_OnGiveAbility(struct FGameplayAbilityActorInfo& ActorInfo, struct FGameplayAbilitySpec& Spec);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function SGameplayAbilities.SGameplayAbility.AddTargetRequiredTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d940
	// Params: [ Num(1) Size(0x10) ]
	void AddTargetRequiredTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AE90
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddTargetBlockedTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d85c
	// Params: [ Num(1) Size(0x10) ]
	void AddTargetBlockedTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AEDC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AE90
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
	// [Call #24] RVA: 0x105190870

	// Object: Function SGameplayAbilities.SGameplayAbility.AddSourceRequiredTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d778
	// Params: [ Num(1) Size(0x10) ]
	void AddSourceRequiredTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215ADF8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AEDC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AE90
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddSourceBlockedTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d694
	// Params: [ Num(1) Size(0x10) ]
	void AddSourceBlockedTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AE44
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215ADF8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AEDC
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddCancelAbilityTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d5b0
	// Params: [ Num(1) Size(0x10) ]
	void AddCancelAbilityTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AC7C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AE44
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215ADF8
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddBlockAbilityTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d4cc
	// Params: [ Num(1) Size(0x10) ]
	void AddBlockAbilityTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215ACC8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AC7C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AE44
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddActivationRequiredTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d3e8
	// Params: [ Num(1) Size(0x10) ]
	void AddActivationRequiredTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AD60
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215ACC8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AC7C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddActivationOwnedTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d304
	// Params: [ Num(1) Size(0x10) ]
	void AddActivationOwnedTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AD14
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AD60
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215ACC8
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddActivationBlockedTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d220
	// Params: [ Num(1) Size(0x10) ]
	void AddActivationBlockedTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215ADAC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215AD14
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AD60
	// [Call #27] RVA: 0x101F8130C

	// Object: Function SGameplayAbilities.SGameplayAbility.AddAbilityTag
	// Flags: [Final|Native|Public]
	// Offset: 0x10215d13c
	// Params: [ Num(1) Size(0x10) ]
	void AddAbilityTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10215AC30
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10215ADAC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x10215AD14
	// [Call #27] RVA: 0x101F8130C
};

