#pragma once

#include <cstdint>

// Object: Enum NiagaraShader.FNiagaraCompileEventSeverity
enum class EFNiagaraCompileEventSeverity : uint8_t
{
	Log = 0,
	Warning = 1,
	Error = 2,
	FNiagaraCompileEventSeverity_MAX = 3
};

// Object: ScriptStruct NiagaraShader.NiagaraDataInterfaceGPUParamInfo
// Size: 0x20 (Inherited: 0x0)
struct FNiagaraDataInterfaceGPUParamInfo
{
	struct FString DataInterfaceHLSLSymbol; // 0x0(0x10)
	struct FString DIClassName; // 0x10(0x10)
};

// Object: ScriptStruct NiagaraShader.NiagaraCompileEvent
// Size: 0x48 (Inherited: 0x0)
struct FNiagaraCompileEvent
{
	uint8_t Severity; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString Message; // 0x8(0x10)
	struct FGuid NodeGuid; // 0x18(0x10)
	struct FGuid PinGuid; // 0x28(0x10)
	struct TArray<struct FGuid> StackGuids; // 0x38(0x10)
};

