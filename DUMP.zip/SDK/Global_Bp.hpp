#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Global_Bp.Global_Bp_C
// Size: 0x448 (Inherited: 0x418)
struct UGlobal_Bp_C : UUAEUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x418(0x8)
	struct USettingConfig_C* SettingConfigObject; // 0x420(0x8)
	struct Abp_global_C* bp_global; // 0x428(0x8)
	bool isPostProcessVolumeInit; // 0x430(0x1)
	uint8_t Pad_0x431[0x7]; // 0x431(0x7)
	struct APostProcessVolume* postProcessClassic; // 0x438(0x8)
	struct ACameraPostProcessActor_C* cameraPostProcessActor; // 0x440(0x8)


	// Object: Function Global_Bp.Global_Bp_C.InitOBSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitOBSettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitCustomizeSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitCustomizeSettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitFireGyroSensibilitySettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitFireGyroSensibilitySettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.MapFromCBToESBH
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void MapFromCBToESBH(struct USettingConfig_C* SettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitMirrorObjMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitMirrorObjMapPickupSetting(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitThrowObjMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitThrowObjMapPickupSetting(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitDrugMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitDrugMapPickupSetting(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitBasicSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitBasicSettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitPickupSettingData_XT
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitPickupSettingData_XT(struct USettingConfig_C* SettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitPickupSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitPickupSettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitSensibilitySettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitSensibilitySettingData(struct USettingConfig_C* ServerSettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.SetGrenadeDefaultPickValue
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void SetGrenadeDefaultPickValue();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.InitMapFromCBToES
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitMapFromCBToES();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.MapFromCBToESGlobal
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void MapFromCBToESGlobal(struct USettingConfig_C* SettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.MapFromCBToESJK
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void MapFromCBToESJK(struct USettingConfig_C* SettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.MapFromCBToESVN
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void MapFromCBToESVN(struct USettingConfig_C* SettingConfig);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.LoadSettingConfigFromSlot
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void LoadSettingConfigFromSlot();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.SetPostProcessSettings
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0xA) ]
	void SetPostProcessSettings(int ID, float Time, bool isReverse, bool isClosing);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.EventAndroidQuitGame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventAndroidQuitGame();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Global_Bp.Global_Bp_C.ExecuteUbergraph_Global_Bp
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Global_Bp(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

