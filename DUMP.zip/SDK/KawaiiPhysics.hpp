#pragma once

#include <cstdint>

// Object: Enum KawaiiPhysics.EPlanarConstraint
enum class EPlanarConstraint : uint8_t
{
	None = 0,
	X = 1,
	Y = 2,
	Z = 3,
	EPlanarConstraint_MAX = 4
};

// Object: Enum KawaiiPhysics.EComplianceType
enum class EComplianceType : uint8_t
{
	Leather = 0,
	Rubber = 1,
	Silk = 2,
	Custom = 3,
	EComplianceType_MAX = 4
};

// Object: Enum KawaiiPhysics.ELateralConstraintMode
enum class ELateralConstraintMode : uint8_t
{
	PBD = 0,
	XPBD = 1,
	ELateralConstraintMode_MAX = 2
};

// Object: Enum KawaiiPhysics.EKawaiiPhysicsSimulationSpace
enum class EKawaiiPhysicsSimulationSpace : uint8_t
{
	ComponentSpace = 0,
	WorldSpace = 1,
	EKawaiiPhysicsSimulationSpace_MAX = 2
};

// Object: ScriptStruct KawaiiPhysics.AnimNode_KawaiiPhysics
// Size: 0x1E0 (Inherited: 0x78)
struct FAnimNode_KawaiiPhysics : FAnimNode_SkeletalControlBase
{
	struct FBoneReference RootBone; // 0x78(0x18)
	struct TArray<struct FBoneReference> ExcludeBones; // 0x90(0x10)
	int TargetFramerate; // 0xA0(0x4)
	bool OverrideTargetFramerate; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	struct FKawaiiPhysicsSettings PhysicsSettings; // 0xA8(0x18)
	struct UCurveFloat* DampingCurve; // 0xC0(0x8)
	struct UCurveFloat* WorldDampingLocationCurve; // 0xC8(0x8)
	struct UCurveFloat* WorldDampingRotationCurve; // 0xD0(0x8)
	struct UCurveFloat* StiffnessCurve; // 0xD8(0x8)
	struct UCurveFloat* RadiusCurve; // 0xE0(0x8)
	struct UCurveFloat* LimitAngleCurve; // 0xE8(0x8)
	bool bUpdatePhysicsSettingsInGame; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float DummyBoneLength; // 0xF4(0x4)
	uint8_t PlanarConstraint; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x7]; // 0xF9(0x7)
	struct TArray<struct FSphericalLimit> SphericalLimits; // 0x100(0x10)
	struct TArray<struct FCapsuleLimit> CapsuleLimits; // 0x110(0x10)
	struct TArray<struct FPlanarLimit> PlanarLimits; // 0x120(0x10)
	float TeleportDistanceThreshold; // 0x130(0x4)
	float TeleportRotationThreshold; // 0x134(0x4)
	struct FVector Gravity; // 0x138(0xC)
	bool bEnableWind; // 0x144(0x1)
	uint8_t Pad_0x145[0x3]; // 0x145(0x3)
	float WindScale; // 0x148(0x4)
	uint8_t Pad_0x14C[0x4]; // 0x14C(0x4)
	struct TArray<struct FKawaiiPhysicsModifyBone> ModifyBones; // 0x150(0x10)
	float TotalBoneLength; // 0x160(0x4)
	uint8_t Pad_0x164[0xC]; // 0x164(0xC)
	struct FTransform PreSkelCompTransform; // 0x170(0x30)
	bool bInitPhysicsSettings; // 0x1A0(0x1)
	uint8_t Pad_0x1A1[0x3F]; // 0x1A1(0x3F)
};

// Object: ScriptStruct KawaiiPhysics.KawaiiPhysicsModifyBone
// Size: 0xB0 (Inherited: 0x0)
struct FKawaiiPhysicsModifyBone
{
	struct FBoneReference BoneRef; // 0x0(0x18)
	int ParentIndex; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<int> ChildIndexs; // 0x20(0x10)
	struct FKawaiiPhysicsSettings PhysicsSettings; // 0x30(0x18)
	struct FVector Location; // 0x48(0xC)
	struct FVector PrevLocation; // 0x54(0xC)
	struct FQuat PrevRotation; // 0x60(0x10)
	struct FVector PoseLocation; // 0x70(0xC)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	struct FQuat PoseRotation; // 0x80(0x10)
	struct FVector PoseScale; // 0x90(0xC)
	float LengthFromRoot; // 0x9C(0x4)
	bool bDummy; // 0xA0(0x1)
	bool bExcluded; // 0xA1(0x1)
	uint8_t Pad_0xA2[0xE]; // 0xA2(0xE)
};

// Object: ScriptStruct KawaiiPhysics.KawaiiPhysicsSettings
// Size: 0x18 (Inherited: 0x0)
struct FKawaiiPhysicsSettings
{
	float Damping; // 0x0(0x4)
	float WorldDampingLocation; // 0x4(0x4)
	float WorldDampingRotation; // 0x8(0x4)
	float Stiffness; // 0xC(0x4)
	float Radius; // 0x10(0x4)
	float LimitAngle; // 0x14(0x4)
};

// Object: ScriptStruct KawaiiPhysics.CollisionLimitBase
// Size: 0x50 (Inherited: 0x0)
struct FCollisionLimitBase
{
	struct FBoneReference DrivingBone; // 0x0(0x18)
	struct FVector OffsetLocation; // 0x18(0xC)
	struct FRotator OffsetRotation; // 0x24(0xC)
	struct FVector Location; // 0x30(0xC)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FQuat Rotation; // 0x40(0x10)
};

// Object: ScriptStruct KawaiiPhysics.PlanarLimit
// Size: 0x60 (Inherited: 0x50)
struct FPlanarLimit : FCollisionLimitBase
{
	struct FPlane Plane; // 0x50(0x10)
};

// Object: ScriptStruct KawaiiPhysics.CapsuleLimit
// Size: 0x60 (Inherited: 0x50)
struct FCapsuleLimit : FCollisionLimitBase
{
	float Radius; // 0x50(0x4)
	float Length; // 0x54(0x4)
	uint8_t Pad_0x58[0x8]; // 0x58(0x8)
};

// Object: ScriptStruct KawaiiPhysics.SphericalLimit
// Size: 0x60 (Inherited: 0x50)
struct FSphericalLimit : FCollisionLimitBase
{
	float Radius; // 0x50(0x4)
	uint8_t LimitType; // 0x54(0x1)
	uint8_t Pad_0x55[0xB]; // 0x55(0xB)
};

// Object: ScriptStruct KawaiiPhysics.KawaiiPhysicsEdgeCollisionSettings
// Size: 0x2C (Inherited: 0x0)
struct FKawaiiPhysicsEdgeCollisionSettings
{
	bool bEnableEdgeCollision; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int StripIndex; // 0x4(0x4)
	int StripGroup; // 0x8(0x4)
	bool bLoopStripGroup; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	int TotalStripCount; // 0x10(0x4)
	float CollisionTolerance; // 0x14(0x4)
	bool bDebugDrawInGame; // 0x18(0x1)
	bool bActiveLateralConstraint; // 0x19(0x1)
	uint8_t Pad_0x1A[0x2]; // 0x1A(0x2)
	int LateralConstraintIterationCount; // 0x1C(0x4)
	float LateralConstraintWeight; // 0x20(0x4)
	bool bUseDiagonalEdgesForLateralConstraint; // 0x24(0x1)
	uint8_t LateralConstraintMode; // 0x25(0x1)
	uint8_t ComplianceType; // 0x26(0x1)
	uint8_t Pad_0x27[0x1]; // 0x27(0x1)
	float ComplianceValueOverride; // 0x28(0x4)
};

// Object: ScriptStruct KawaiiPhysics.NewAnimNode_KawaiiPhysics
// Size: 0x350 (Inherited: 0x78)
struct FNewAnimNode_KawaiiPhysics : FAnimNode_SkeletalControlBase
{
	struct FBoneReference RootBone; // 0x78(0x18)
	struct TArray<struct FBoneReference> ExcludeBones; // 0x90(0x10)
	struct TArray<struct FBoneReference> FixedBones; // 0xA0(0x10)
	uint8_t SimulationSpace; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x3]; // 0xB1(0x3)
	int TargetFramerate; // 0xB4(0x4)
	bool OverrideTargetFramerate; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	struct FKawaiiPhysicsSettings PhysicsSettings; // 0xBC(0x18)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct UCurveFloat* DampingCurve; // 0xD8(0x8)
	struct UCurveFloat* WorldDampingLocationCurve; // 0xE0(0x8)
	struct UCurveFloat* WorldDampingRotationCurve; // 0xE8(0x8)
	struct UCurveFloat* StiffnessCurve; // 0xF0(0x8)
	struct UCurveFloat* RadiusCurve; // 0xF8(0x8)
	struct UCurveFloat* LimitAngleCurve; // 0x100(0x8)
	bool bUpdatePhysicsSettingsInGame; // 0x108(0x1)
	uint8_t Pad_0x109[0x3]; // 0x109(0x3)
	float DummyBoneLength; // 0x10C(0x4)
	uint8_t PlanarConstraint; // 0x110(0x1)
	uint8_t Pad_0x111[0x7]; // 0x111(0x7)
	struct TArray<struct FSphericalLimit> SphericalLimits; // 0x118(0x10)
	struct TArray<struct FCapsuleLimit> CapsuleLimits; // 0x128(0x10)
	struct TArray<struct FPlanarLimit> PlanarLimits; // 0x138(0x10)
	float TeleportDistanceThreshold; // 0x148(0x4)
	float TeleportRotationThreshold; // 0x14C(0x4)
	struct FVector Gravity; // 0x150(0xC)
	struct FVector MaxDistance; // 0x15C(0xC)
	struct FVector MinDistance; // 0x168(0xC)
	bool bEnableWind; // 0x174(0x1)
	uint8_t Pad_0x175[0x3]; // 0x175(0x3)
	float WindScale; // 0x178(0x4)
	struct FKawaiiPhysicsEdgeCollisionSettings EdgeCollisionSettings; // 0x17C(0x2C)
	bool bEnableEndBoneControl; // 0x1A8(0x1)
	uint8_t Pad_0x1A9[0x3]; // 0x1A9(0x3)
	struct FVector EndBoneControlOffset; // 0x1AC(0xC)
	struct FRotator EndBoneControlRotation; // 0x1B8(0xC)
	struct FVector RootBoneControlOffset; // 0x1C4(0xC)
	struct TArray<struct FNewKawaiiPhysicsModifyBone> ModifyBones; // 0x1D0(0x10)
	float TotalBoneLength; // 0x1E0(0x4)
	uint8_t Pad_0x1E4[0xC]; // 0x1E4(0xC)
	struct FTransform PreSkelCompTransform; // 0x1F0(0x30)
	bool bInitPhysicsSettings; // 0x220(0x1)
	uint8_t Pad_0x221[0x12F]; // 0x221(0x12F)
};

// Object: ScriptStruct KawaiiPhysics.NewKawaiiPhysicsModifyBone
// Size: 0x170 (Inherited: 0x0)
struct FNewKawaiiPhysicsModifyBone
{
	struct FBoneReference BoneRef; // 0x0(0x18)
	int ParentIndex; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<int> ChildIndexs; // 0x20(0x10)
	struct FKawaiiPhysicsSettings PhysicsSettings; // 0x30(0x18)
	struct FVector Location; // 0x48(0xC)
	struct FVector PrevLocation; // 0x54(0xC)
	struct FQuat PrevRotation; // 0x60(0x10)
	struct FVector PoseLocation; // 0x70(0xC)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	struct FQuat PoseRotation; // 0x80(0x10)
	struct FVector PoseScale; // 0x90(0xC)
	float LengthFromRoot; // 0x9C(0x4)
	bool bDummy; // 0xA0(0x1)
	bool bExcluded; // 0xA1(0x1)
	uint8_t Pad_0xA2[0x2]; // 0xA2(0x2)
	struct FVector ForwardPos; // 0xA4(0xC)
	struct FVector BackwardPos; // 0xB0(0xC)
	bool bIsEndBone; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
	struct FVector WorldPoseLocation; // 0xC0(0xC)
	uint8_t Pad_0xCC[0xA4]; // 0xCC(0xA4)
};

// Object: ScriptStruct KawaiiPhysics.SimulationSpaceCache
// Size: 0x60 (Inherited: 0x0)
struct FSimulationSpaceCache
{
	struct FTransform ComponentToTargetSpace; // 0x0(0x30)
	struct FTransform TargetSpaceToComponent; // 0x30(0x30)
};

