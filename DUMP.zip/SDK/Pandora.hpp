#pragma once

#include <cstdint>

// Object: Enum Pandora.EPandoraPanelType
enum class EPandoraPanelType : uint8_t
{
	PDRPT_Pandora = 0,
	PDRPT_Gamelet = 1,
	PDRPT_MAX = 2
};

// Object: Enum Pandora.EPandoraCMDType
enum class EPandoraCMDType : uint8_t
{
	PDRCT_Pandora = 0,
	PDRCT_Gamelet = 1,
	PDRCT_Undefined = 2,
	PDRCT_MAX = 3
};

// Object: Enum Pandora.EPandoraEnv
enum class EPandoraEnv : uint8_t
{
	PDR_Test = 0,
	PDR_Prod = 1,
	PDR_SingaporeTest = 2,
	PDR_SingaporeProd = 3,
	PDR_NorthAmericaTest = 4,
	PDR_NorthAmericaProd = 5,
	PDR_EnvMax = 6,
	PDR_MAX = 7
};

// Object: ScriptStruct Pandora.PLuaBPVar
// Size: 0x20 (Inherited: 0x0)
struct FPLuaBPVar
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: Class Pandora.BulletScreen
// Size: 0x220 (Inherited: 0x130)
struct UBulletScreen : UCanvasPanel
{
	struct UBulletScreenItem* TemplateWidget; // 0x130(0x8)
	int MaxBulletLines; // 0x138(0x4)
	float BulletSpeed; // 0x13C(0x4)
	float LineHeight; // 0x140(0x4)
	float HorizontalInterval; // 0x144(0x4)
	int MaxCachedBulletCount; // 0x148(0x4)
	uint8_t Pad_0x14C[0xD4]; // 0x14C(0xD4)


	// Object: Function Pandora.BulletScreen.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0a1c8
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519077C

	// Object: Function Pandora.BulletScreen.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0a1b4
	// Params: [ Num(0) Size(0x0) ]
	void Start();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519077C

	// Object: Function Pandora.BulletScreen.Resume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0a1a0
	// Params: [ Num(0) Size(0x0) ]
	void Resume();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519077C

	// Object: Function Pandora.BulletScreen.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0a18c
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Pandora.BulletScreen.AddBullets
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0a0e4
	// Params: [ Num(1) Size(0x10) ]
	void AddBullets(struct TArray<struct FString>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A7105C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Pandora.BulletScreen.AddBullet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0a04c
	// Params: [ Num(1) Size(0x10) ]
	void AddBullet(struct FString Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A70E78
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A7105C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
};

// Object: Class Pandora.BulletScreenItem
// Size: 0x268 (Inherited: 0x260)
struct UBulletScreenItem : UUserWidget
{
	uint8_t Pad_0x260[0x8]; // 0x260(0x8)
};

// Object: Class Pandora.GameletSDKDelegateHandler
// Size: 0x48 (Inherited: 0x28)
struct UGameletSDKDelegateHandler : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)


	// Object: Function Pandora.GameletSDKDelegateHandler.ExecOnViewCreated
	// Flags: [Final|Native|Public]
	// Offset: 0x102b0a788
	// Params: [ Num(2) Size(0x18) ]
	void ExecOnViewCreated(struct UUserWidget* Widget, struct FString WinInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102AF4A10
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Pandora.GameletSDKDelegateHandler.ExecOnViewAboutToDestroy
	// Flags: [Final|Native|Public]
	// Offset: 0x102b0a6b4
	// Params: [ Num(2) Size(0x18) ]
	void ExecOnViewAboutToDestroy(struct UUserWidget* Widget, struct FString WinInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102AF4A28
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102AF4A10
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function Pandora.GameletSDKDelegateHandler.ExecOnSDKMessage
	// Flags: [Final|Native|Public]
	// Offset: 0x102b0a60c
	// Params: [ Num(2) Size(0x14) ]
	int ExecOnSDKMessage(struct FString Msg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102AF49E4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102AF4A28
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102AF4A10
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Pandora.GameletSDKDelegateHandler.ExecOnRefreshUserdata
	// Flags: [Final|Native|Public]
	// Offset: 0x102b0a5d8
	// Params: [ Num(1) Size(0x4) ]
	int ExecOnRefreshUserdata();
	// [Call #1] RVA: 0x102AF49FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102AF49E4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102AF4A28
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102AF4A10
};

// Object: Class Pandora.PLatentDelegate
// Size: 0x30 (Inherited: 0x28)
struct UPLatentDelegate : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function Pandora.PLatentDelegate.OnLatentCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0aac4
	// Params: [ Num(1) Size(0x4) ]
	void OnLatentCallback(int threadRef);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A9DFC0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B0AEE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
};

// Object: Class Pandora.PLuaActor
// Size: 0x560 (Inherited: 0x4B0)
struct APLuaActor : AActor
{
	uint8_t Pad_0x4B0[0x90]; // 0x4B0(0x90)
	struct FString LuaFilePath; // 0x540(0x10)
	struct FString LuaStateName; // 0x550(0x10)


	// Object: Function Pandora.PLuaActor.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0ac98
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F26C
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190648
	// [Call #21] RVA: 0x105190870
};

// Object: Class Pandora.PLuaPawn
// Size: 0x5C0 (Inherited: 0x510)
struct APLuaPawn : APawn
{
	uint8_t Pad_0x510[0x90]; // 0x510(0x90)
	struct FString LuaFilePath; // 0x5A0(0x10)
	struct FString LuaStateName; // 0x5B0(0x10)


	// Object: Function Pandora.PLuaPawn.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0b044
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F378
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaCharacter
// Size: 0x9A0 (Inherited: 0x8F0)
struct APLuaCharacter : ACharacter
{
	uint8_t Pad_0x8F0[0x88]; // 0x8F0(0x88)
	struct FString LuaFilePath; // 0x978(0x10)
	struct FString LuaStateName; // 0x988(0x10)
	uint8_t Pad_0x998[0x8]; // 0x998(0x8)


	// Object: Function Pandora.PLuaCharacter.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0b320
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F438
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaController
// Size: 0x5C8 (Inherited: 0x518)
struct APLuaController : AController
{
	uint8_t Pad_0x518[0x90]; // 0x518(0x90)
	struct FString LuaFilePath; // 0x5A8(0x10)
	struct FString LuaStateName; // 0x5B8(0x10)


	// Object: Function Pandora.PLuaController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0b5fc
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F4F8
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaPlayerController
// Size: 0x8D8 (Inherited: 0x828)
struct APLuaPlayerController : APlayerController
{
	uint8_t Pad_0x828[0x90]; // 0x828(0x90)
	struct FString LuaFilePath; // 0x8B8(0x10)
	struct FString LuaStateName; // 0x8C8(0x10)


	// Object: Function Pandora.PLuaPlayerController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0b8dc
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F5B8
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaActorComponent
// Size: 0x238 (Inherited: 0x178)
struct UPLuaActorComponent : UActorComponent
{
	uint8_t Pad_0x178[0xA0]; // 0x178(0xA0)
	struct FString LuaFilePath; // 0x218(0x10)
	struct FString LuaStateName; // 0x228(0x10)


	// Object: Function Pandora.PLuaActorComponent.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0bbbc
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F678
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaGameModeBase
// Size: 0x5F0 (Inherited: 0x540)
struct APLuaGameModeBase : AGameModeBase
{
	uint8_t Pad_0x540[0x90]; // 0x540(0x90)
	struct FString LuaFilePath; // 0x5D0(0x10)
	struct FString LuaStateName; // 0x5E0(0x10)


	// Object: Function Pandora.PLuaGameModeBase.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0be98
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F738
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaHUD
// Size: 0x648 (Inherited: 0x598)
struct APLuaHUD : AHUD
{
	uint8_t Pad_0x598[0x90]; // 0x598(0x90)
	struct FString LuaFilePath; // 0x628(0x10)
	struct FString LuaStateName; // 0x638(0x10)


	// Object: Function Pandora.PLuaHUD.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0c17c
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0F7F8
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PLuaTableObjectInterface
// Size: 0x28 (Inherited: 0x28)
struct IPLuaTableObjectInterface : IInterface
{
};

// Object: Class Pandora.PLuaBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPLuaBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Pandora.PLuaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0d1ec
	// Params: [ Num(3) Size(0x38) ]
	struct FString GetStringFromVar(struct FPLuaBPVar Value, int Index);
	// [Call #1] RVA: 0x102AA1F28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102AAE32C
	// [Call #7] RVA: 0x102AA3208
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102AA00CC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102AA00CC
	// [Call #14] RVA: 0x102AA00CC
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x10519022C

	// Object: Function Pandora.PLuaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0d0ec
	// Params: [ Num(3) Size(0x30) ]
	struct UObject* GetObjectFromVar(struct FPLuaBPVar Value, int Index);
	// [Call #1] RVA: 0x102AA1F28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102AAE32C
	// [Call #7] RVA: 0x102AA3330
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x102AA00CC
	// [Call #10] RVA: 0x102AA00CC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102AA1F28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102AAE32C
	// [Call #19] RVA: 0x102AA3208
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x102AA00CC
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x102AA00CC
	// [Call #26] RVA: 0x102AA00CC
	// [Call #27] RVA: 0x106C8459C

	// Object: Function Pandora.PLuaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cfec
	// Params: [ Num(3) Size(0x28) ]
	float GetNumberFromVar(struct FPLuaBPVar Value, int Index);
	// [Call #1] RVA: 0x102AA1F28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102AAE32C
	// [Call #7] RVA: 0x102AA3014
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x102AA00CC
	// [Call #10] RVA: 0x102AA00CC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102AA1F28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102AAE32C
	// [Call #19] RVA: 0x102AA3330
	// [Call #20] RVA: 0x102AA00CC
	// [Call #21] RVA: 0x102AA00CC
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x102AA00CC
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x102AA1F28
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function Pandora.PLuaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0ceec
	// Params: [ Num(3) Size(0x28) ]
	int GetIntFromVar(struct FPLuaBPVar Value, int Index);
	// [Call #1] RVA: 0x102AA1F28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102AAE32C
	// [Call #7] RVA: 0x102AA2F1C
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x102AA00CC
	// [Call #10] RVA: 0x102AA00CC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102AA1F28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102AAE32C
	// [Call #19] RVA: 0x102AA3014
	// [Call #20] RVA: 0x102AA00CC
	// [Call #21] RVA: 0x102AA00CC
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x102AA00CC
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x102AA1F28
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function Pandora.PLuaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cdec
	// Params: [ Num(3) Size(0x25) ]
	bool GetBoolFromVar(struct FPLuaBPVar Value, int Index);
	// [Call #1] RVA: 0x102AA1F28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102AAE32C
	// [Call #7] RVA: 0x102AA310C
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x102AA00CC
	// [Call #10] RVA: 0x102AA00CC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102AA1F28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102AAE32C
	// [Call #19] RVA: 0x102AA2F1C
	// [Call #20] RVA: 0x102AA00CC
	// [Call #21] RVA: 0x102AA00CC
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x102AA00CC
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x102AA1F28
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function Pandora.PLuaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cce4
	// Params: [ Num(2) Size(0x30) ]
	struct FPLuaBPVar CreateVarFromString(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102AA21A8
	// [Call #5] RVA: 0x102AA15AC
	// [Call #6] RVA: 0x102AA00CC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102AA00CC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x102AA1F28
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102AAE32C
	// [Call #21] RVA: 0x102AA310C
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x102AA00CC
	// [Call #24] RVA: 0x102AA00CC
	// [Call #25] RVA: 0x102AA00CC
	// [Call #26] RVA: 0x106C8459C
	// [Call #27] RVA: 0x102AA1F28
	// [Call #28] RVA: 0x10516D168

	// Object: Function Pandora.PLuaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cc04
	// Params: [ Num(3) Size(0x30) ]
	struct FPLuaBPVar CreateVarFromObject(struct UObject* WorldContextObject, struct UObject* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102AA23FC
	// [Call #6] RVA: 0x102AA15AC
	// [Call #7] RVA: 0x102AA00CC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x102AA21A8
	// [Call #14] RVA: 0x102AA15AC
	// [Call #15] RVA: 0x102AA00CC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x102AA00CC
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x102AA1F28
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4
	// [Call #27] RVA: 0x10516D168

	// Object: Function Pandora.PLuaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cb60
	// Params: [ Num(2) Size(0x28) ]
	struct FPLuaBPVar CreateVarFromNumber(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102AA22C4
	// [Call #4] RVA: 0x102AA15AC
	// [Call #5] RVA: 0x102AA00CC
	// [Call #6] RVA: 0x102AA00CC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102AA23FC
	// [Call #13] RVA: 0x102AA15AC
	// [Call #14] RVA: 0x102AA00CC
	// [Call #15] RVA: 0x102AA00CC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x102AA21A8
	// [Call #21] RVA: 0x102AA15AC
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x102AA00CC

	// Object: Function Pandora.PLuaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0cabc
	// Params: [ Num(2) Size(0x28) ]
	struct FPLuaBPVar CreateVarFromInt(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102AA2104
	// [Call #4] RVA: 0x102AA15AC
	// [Call #5] RVA: 0x102AA00CC
	// [Call #6] RVA: 0x102AA00CC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102AA22C4
	// [Call #11] RVA: 0x102AA15AC
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x102AA00CC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102AA23FC
	// [Call #20] RVA: 0x102AA15AC
	// [Call #21] RVA: 0x102AA00CC
	// [Call #22] RVA: 0x102AA00CC
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Pandora.PLuaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0ca10
	// Params: [ Num(2) Size(0x28) ]
	struct FPLuaBPVar CreateVarFromBool(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102AA2364
	// [Call #4] RVA: 0x102AA15AC
	// [Call #5] RVA: 0x102AA00CC
	// [Call #6] RVA: 0x102AA00CC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102AA2104
	// [Call #11] RVA: 0x102AA15AC
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x102AA00CC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102AA22C4
	// [Call #18] RVA: 0x102AA15AC
	// [Call #19] RVA: 0x102AA00CC
	// [Call #20] RVA: 0x102AA00CC
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Pandora.PLuaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0c7c0
	// Params: [ Num(5) Size(0x58) ]
	struct FPLuaBPVar CallToLuaWithArgs(struct UObject* WorldContextObject, struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args, struct FString StateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x102AA18E8
	// [Call #12] RVA: 0x102AA15AC
	// [Call #13] RVA: 0x102AA00CC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x102B0F32C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x102AA00CC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x102B0F32C
	// [Call #28] RVA: 0x101F8130C
	// [Call #29] RVA: 0x106C8459C

	// Object: Function Pandora.PLuaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b0c5e0
	// Params: [ Num(4) Size(0x48) ]
	struct FPLuaBPVar CallToLua(struct UObject* WorldContextObject, struct FString FunctionName, struct FString StateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102AA1F44
	// [Call #10] RVA: 0x102AA15AC
	// [Call #11] RVA: 0x102AA00CC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x102AA00CC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4
	// [Call #28] RVA: 0x10516D168
};

// Object: Class Pandora.PLuaDelegate
// Size: 0x38 (Inherited: 0x28)
struct UPLuaDelegate : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)


	// Object: Function Pandora.PLuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0d778
	// Params: [ Num(0) Size(0x0) ]
	void EventTrigger();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102B0DAE8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102B0FA90
	// [Call #11] RVA: 0x102AA15AC
};

// Object: Class Pandora.PLuaUserWidget
// Size: 0x348 (Inherited: 0x260)
struct UPLuaUserWidget : UUserWidget
{
	uint8_t Pad_0x260[0x90]; // 0x260(0x90)
	struct FString LuaFilePath; // 0x2F0(0x10)
	struct FString LuaStateName; // 0x300(0x10)
	uint8_t Pad_0x310[0x38]; // 0x310(0x38)


	// Object: Function Pandora.PLuaUserWidget.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b0d8e4
	// Params: [ Num(3) Size(0x40) ]
	struct FPLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPLuaBPVar>& Args);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B0FA90
	// [Call #7] RVA: 0x102AA15AC
	// [Call #8] RVA: 0x102AA00CC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102B0F32C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102AA00CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x102B0F32C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870
};

// Object: Class Pandora.PPixUILogAdapter
// Size: 0x38 (Inherited: 0x28)
struct UPPixUILogAdapter : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)


	// Object: Function Pandora.PPixUILogAdapter.OnPixUILog
	// Flags: [Final|Native|Private]
	// Offset: 0x102b0dd58
	// Params: [ Num(3) Size(0x18) ]
	void OnPixUILog(int InLogType, int InLogLevel, struct FString InLogContent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x102AF4A40
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
};

// Object: Class Pandora.PRichText
// Size: 0x420 (Inherited: 0x100)
struct UPRichText : UWidget
{
	struct FText Text; // 0x100(0x18)
	DelegateProperty TextDelegate; // 0x118(0x10)
	struct FSlateFontInfo Font; // 0x128(0x58)
	struct FLinearColor Color; // 0x180(0x10)
	enum class ETextJustify Justification; // 0x190(0x1)
	bool AutoWrapText; // 0x191(0x1)
	uint8_t Pad_0x192[0x2]; // 0x192(0x2)
	float WrapTextAt; // 0x194(0x4)
	struct FMargin Margin; // 0x198(0x10)
	float LineHeightPercentage; // 0x1A8(0x4)
	uint8_t Pad_0x1AC[0x4]; // 0x1AC(0x4)
	struct TArray<struct URichTextBlockDecorator*> Decorators; // 0x1B0(0x10)
	uint8_t Pad_0x1C0[0x260]; // 0x1C0(0x260)


	// Object: Function Pandora.PRichText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0e080
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x102AF6738
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10508F76C

	// Object: Function Pandora.PRichText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b0e01c
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x102AF67A0
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104F0F380
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104F0F458
	// [Call #10] RVA: 0x102AF6738
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
};

// Object: Class Pandora.Scale9Grid
// Size: 0x308 (Inherited: 0x288)
struct UScale9Grid : UImage
{
	uint8_t Pad_0x288[0x80]; // 0x288(0x80)
};

// Object: Class Pandora.WaterfallScrollView
// Size: 0x580 (Inherited: 0x118)
struct UWaterfallScrollView : UPanelWidget
{
	struct FScrollBoxStyle WidgetStyle; // 0x118(0x2E8)
	struct USlateWidgetStyleAsset* Style; // 0x400(0x8)
	struct UUserWidget* TemplateWidget; // 0x408(0x8)
	int ItemCount; // 0x410(0x4)
	int ColumnCount; // 0x414(0x4)
	struct FScriptMulticastDelegate onReachTop; // 0x418(0x10)
	struct FScriptMulticastDelegate onReachBottom; // 0x428(0x10)
	uint8_t ConsumeMouseWheel; // 0x438(0x1)
	bool AllowOverscroll; // 0x439(0x1)
	uint8_t Pad_0x43A[0x146]; // 0x43A(0x146)


	// Object: Function Pandora.WaterfallScrollView.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0e494
	// Params: [ Num(0) Size(0x0) ]
	void ScrollToStart();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B106CC

	// Object: Function Pandora.WaterfallScrollView.RefreshLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0e418
	// Params: [ Num(1) Size(0x4) ]
	void RefreshLayout(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A73D98
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Pandora.WaterfallScrollView.Fill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0e404
	// Params: [ Num(0) Size(0x0) ]
	void Fill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A73D98
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Pandora.WaterfallScrollView.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b0e3f0
	// Params: [ Num(0) Size(0x0) ]
	void Clear();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A73D98
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

