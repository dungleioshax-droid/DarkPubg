#pragma once

#include <cstdint>

// Object: Enum SlateCore.ECheckBoxState
enum class ECheckBoxState : uint8_t
{
	Unchecked = 0,
	Checked = 1,
	Undetermined = 2,
	ECheckBoxState_MAX = 3
};

// Object: Enum SlateCore.EWidgetClipping
enum class EWidgetClipping : uint8_t
{
	Inherit = 0,
	ClipToBounds = 1,
	ClipToBoundsWithoutIntersecting = 2,
	ClipToBoundsAlways = 3,
	OnDemand = 4,
	EWidgetClipping_MAX = 5
};

// Object: Enum SlateCore.ESlateBrushImageType
enum class ESlateBrushImageType : uint8_t
{
	NoImage = 0,
	FullColor = 1,
	Linear = 2,
	ESlateBrushImageType_MAX = 3
};

// Object: Enum SlateCore.ESlateBrushMirrorType
enum class ESlateBrushMirrorType : uint8_t
{
	NoMirror = 0,
	Horizontal = 1,
	Vertical = 2,
	Both = 3,
	ESlateBrushMirrorType_MAX = 4
};

// Object: Enum SlateCore.ESlateBrushTileType
enum class ESlateBrushTileType : uint8_t
{
	NoTile = 0,
	Horizontal = 1,
	Vertical = 2,
	Both = 3,
	ESlateBrushTileType_MAX = 4
};

// Object: Enum SlateCore.ESlateBrushDrawType
enum class ESlateBrushDrawType : uint8_t
{
	NoDrawType = 0,
	Box = 1,
	Border = 2,
	Image = 3,
	HollowBox = 4,
	ESlateBrushDrawType_MAX = 5
};

// Object: Enum SlateCore.ESlateColorStylingMode
enum class ESlateColorStylingMode : uint8_t
{
	UseColor_Specified = 0,
	UseColor_Specified_Link = 1,
	UseColor_Foreground = 2,
	UseColor_Foreground_Subdued = 3,
	UseColor_MAX = 4
};

// Object: Enum SlateCore.EWidgetVisible
enum class EWidgetVisible : uint8_t
{
	Default = 0,
	ForceNotVisible = 1,
	ForceVisible = 2,
	MaxVisible = 3,
	EWidgetVisible_MAX = 4
};

// Object: Enum SlateCore.EUINavigationRule
enum class EUINavigationRule : uint8_t
{
	Escape = 0,
	Explicit = 1,
	Wrap = 2,
	Stop = 3,
	Custom = 4,
	Invalid = 5,
	EUINavigationRule_MAX = 6
};

// Object: Enum SlateCore.EUINavigation
enum class EUINavigation : uint8_t
{
	Left = 0,
	Right = 1,
	Up = 2,
	Down = 3,
	Next = 4,
	Previous = 5,
	Num = 6,
	Invalid = 7,
	EUINavigation_MAX = 8
};

// Object: Enum SlateCore.EButtonClickMethod
enum class EButtonClickMethod : uint8_t
{
	DownAndUp = 0,
	MouseDown = 1,
	MouseUp = 2,
	PreciseClick = 3,
	EButtonClickMethod_MAX = 4
};

// Object: Enum SlateCore.EButtonTouchMethod
enum class EButtonTouchMethod : uint8_t
{
	DownAndUp = 0,
	PreciseTap = 1,
	EButtonTouchMethod_MAX = 2
};

// Object: Enum SlateCore.ESelectInfo
enum class ESelectInfo : uint8_t
{
	OnKeyPress = 0,
	OnNavigation = 1,
	OnMouseClick = 2,
	Direct = 3,
	ESelectInfo_MAX = 4
};

// Object: Enum SlateCore.ETextCommit
enum class ETextCommit : uint8_t
{
	Default = 0,
	OnEnter = 1,
	OnUserMovedFocus = 2,
	OnCleared = 3,
	ETextCommit_MAX = 4
};

// Object: Enum SlateCore.ETextShapingMethod
enum class ETextShapingMethod : uint8_t
{
	Auto = 0,
	KerningOnly = 1,
	FullShaping = 2,
	ETextShapingMethod_MAX = 3
};

// Object: Enum SlateCore.EOrientation
enum class EOrientation : uint8_t
{
	Orient_Horizontal = 0,
	Orient_Vertical = 1,
	Orient_MAX = 2
};

// Object: Enum SlateCore.EConsumeMouseWheel
enum class EConsumeMouseWheel : uint8_t
{
	WhenScrollingPossible = 0,
	Always = 1,
	Never = 2,
	EConsumeMouseWheel_MAX = 3
};

// Object: Enum SlateCore.EFontLayoutMethod
enum class EFontLayoutMethod : uint8_t
{
	Metrics = 0,
	BoundingBox = 1,
	EFontLayoutMethod_MAX = 2
};

// Object: Enum SlateCore.EFontLoadingPolicy
enum class EFontLoadingPolicy : uint8_t
{
	LazyLoad = 0,
	Stream = 1,
	Inline = 2,
	EFontLoadingPolicy_MAX = 3
};

// Object: Enum SlateCore.EFontHinting
enum class EFontHinting : uint8_t
{
	Default = 0,
	Auto = 1,
	AutoLight = 2,
	Monochrome = 3,
	None = 4,
	EFontHinting_MAX = 5
};

// Object: Enum SlateCore.EFocusCause
enum class EFocusCause : uint8_t
{
	Mouse = 0,
	Navigation = 1,
	SetDirectly = 2,
	Cleared = 3,
	OtherWidgetLostFocus = 4,
	WindowActivate = 5,
	EFocusCause_MAX = 6
};

// Object: Enum SlateCore.EFlowDirectionPreference
enum class EFlowDirectionPreference : uint8_t
{
	Inherit = 0,
	Culture = 1,
	LeftToRight = 2,
	RightToLeft = 3,
	EFlowDirectionPreference_MAX = 4
};

// Object: Enum SlateCore.EHitTestAreaPolicyType
enum class EHitTestAreaPolicyType : uint8_t
{
	UnknowType = 0,
	CircularHitTestArea = 1,
	EHitTestAreaPolicyType_MAX = 2
};

// Object: Enum SlateCore.ESlateDebuggingFocusEvent
enum class ESlateDebuggingFocusEvent : uint8_t
{
	FocusChanging = 0,
	FocusLost = 1,
	FocusReceived = 2,
	MAX = 3
};

// Object: Enum SlateCore.ESlateDebuggingNavigationMethod
enum class ESlateDebuggingNavigationMethod : uint8_t
{
	Unknown = 0,
	Explicit = 1,
	CustomDelegateBound = 2,
	CustomDelegateUnbound = 3,
	NextOrPrevious = 4,
	HitTestGrid = 5,
	ESlateDebuggingNavigationMethod_MAX = 6
};

// Object: Enum SlateCore.ESlateDebuggingStateChangeEvent
enum class ESlateDebuggingStateChangeEvent : uint8_t
{
	MouseCaptureGained = 0,
	MouseCaptureLost = 1,
	ESlateDebuggingStateChangeEvent_MAX = 2
};

// Object: Enum SlateCore.ESlateDebuggingInputEvent
enum class ESlateDebuggingInputEvent : uint8_t
{
	MouseMove = 0,
	MouseEnter = 1,
	MouseLeave = 2,
	PreviewMouseButtonDown = 3,
	MouseButtonDown = 4,
	MouseButtonUp = 5,
	MouseButtonDoubleClick = 6,
	MouseWheel = 7,
	TouchStart = 8,
	TouchEnd = 9,
	TouchForceChanged = 10,
	TouchFirstMove = 11,
	TouchMoved = 12,
	DragDetected = 13,
	DragEnter = 14,
	DragLeave = 15,
	DragOver = 16,
	DragDrop = 17,
	DropMessage = 18,
	PreviewKeyDown = 19,
	KeyDown = 20,
	KeyUp = 21,
	KeyChar = 22,
	AnalogInput = 23,
	TouchGesture = 24,
	MotionDetected = 25,
	MAX = 26
};

// Object: Enum SlateCore.EBlurType
enum class EBlurType : uint8_t
{
	BlurType_None = 0,
	BlurType_Default = 1,
	BlurType_Directional = 2,
	BlurType_Radial = 3,
	BlurType_Rotate = 4,
	BlurType_AlphaOnly = 5,
	BlurType_MAX = 6
};

// Object: Enum SlateCore.EScrollDirection
enum class EScrollDirection : uint8_t
{
	Scroll_Down = 0,
	Scroll_Up = 1,
	Scroll_MAX = 2
};

// Object: Enum SlateCore.EMenuPlacement
enum class EMenuPlacement : uint8_t
{
	MenuPlacement_BelowAnchor = 0,
	MenuPlacement_CenteredBelowAnchor = 1,
	MenuPlacement_BelowRightAnchor = 2,
	MenuPlacement_ComboBox = 3,
	MenuPlacement_ComboBoxRight = 4,
	MenuPlacement_MenuRight = 5,
	MenuPlacement_AboveAnchor = 6,
	MenuPlacement_CenteredAboveAnchor = 7,
	MenuPlacement_AboveRightAnchor = 8,
	MenuPlacement_MenuLeft = 9,
	MenuPlacement_Center = 10,
	MenuPlacement_RightLeftCenter = 11,
	MenuPlacement_MatchBottomLeft = 12,
	MenuPlacement_ComboBoxAbove = 13,
	MenuPlacement_MAX = 14
};

// Object: Enum SlateCore.EVerticalAlignment
enum class EVerticalAlignment : uint8_t
{
	VAlign_Fill = 0,
	VAlign_Top = 1,
	VAlign_Center = 2,
	VAlign_Bottom = 3,
	VAlign_MAX = 4
};

// Object: Enum SlateCore.EHorizontalAlignment
enum class EHorizontalAlignment : uint8_t
{
	HAlign_Fill = 0,
	HAlign_Left = 1,
	HAlign_Center = 2,
	HAlign_Right = 3,
	HAlign_MAX = 4
};

// Object: Enum SlateCore.ENavigationGenesis
enum class ENavigationGenesis : uint8_t
{
	Keyboard = 0,
	Controller = 1,
	User = 2,
	ENavigationGenesis_MAX = 3
};

// Object: Enum SlateCore.ENavigationSource
enum class ENavigationSource : uint8_t
{
	FocusedWidget = 0,
	WidgetUnderCursor = 1,
	ENavigationSource_MAX = 2
};

// Object: Enum SlateCore.EButtonPressMethod
enum class EButtonPressMethod : uint8_t
{
	DownAndUp = 0,
	ButtonPress = 1,
	ButtonRelease = 2,
	EButtonPressMethod_MAX = 3
};

// Object: Enum SlateCore.EFontFallback
enum class EFontFallback : uint8_t
{
	FF_NoFallback = 0,
	FF_LocalizedFallback = 1,
	FF_LastResortFallback = 2,
	FF_Max = 3
};

// Object: Enum SlateCore.ESlateCheckBoxType
enum class ESlateCheckBoxType : uint8_t
{
	CheckBox = 0,
	ToggleButton = 1,
	ESlateCheckBoxType_MAX = 2
};

// Object: Enum SlateCore.EWidgetPixelSnapping
enum class EWidgetPixelSnapping : uint8_t
{
	Inherit = 0,
	Disabled = 1,
	SnapToPixel = 2,
	EWidgetPixelSnapping_MAX = 3
};

// Object: ScriptStruct SlateCore.InputEvent
// Size: 0x20 (Inherited: 0x0)
struct FInputEvent
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct SlateCore.KeyEvent
// Size: 0x40 (Inherited: 0x20)
struct FKeyEvent : FInputEvent
{
	uint8_t Pad_0x20[0x20]; // 0x20(0x20)
};

// Object: ScriptStruct SlateCore.AnalogInputEvent
// Size: 0x48 (Inherited: 0x40)
struct FAnalogInputEvent : FKeyEvent
{
	uint8_t Pad_0x40[0x8]; // 0x40(0x8)
};

// Object: ScriptStruct SlateCore.Geometry
// Size: 0x38 (Inherited: 0x0)
struct FGeometry
{
	uint8_t Pad_0x0[0x38]; // 0x0(0x38)
};

// Object: ScriptStruct SlateCore.Margin
// Size: 0x10 (Inherited: 0x0)
struct FMargin
{
	float Left; // 0x0(0x4)
	float Top; // 0x4(0x4)
	float Right; // 0x8(0x4)
	float Bottom; // 0xC(0x4)
};

// Object: ScriptStruct SlateCore.SlateBrush
// Size: 0xB8 (Inherited: 0x0)
struct FSlateBrush
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct FVector2D ImageSize; // 0x8(0x8)
	struct FMargin Margin; // 0x10(0x10)
	struct FSlateColor TintColor; // 0x20(0x28)
	bool bAsyncEnabled; // 0x48(0x1)
	bool bOnlySoftInEditor; // 0x49(0x1)
	uint8_t Pad_0x4A[0x6]; // 0x4A(0x6)
	struct UObject* ResourceObject; // 0x50(0x8)
	struct UObject* SoftResourceObject; // 0x58(0x28)
	struct FName ResourceName; // 0x80(0x8)
	struct FBox2D UVRegion; // 0x88(0x14)
	enum class ESlateBrushDrawType DrawAs; // 0x9C(0x1)
	enum class ESlateBrushTileType Tiling; // 0x9D(0x1)
	enum class ESlateBrushMirrorType Mirroring; // 0x9E(0x1)
	enum class ESlateBrushImageType ImageType; // 0x9F(0x1)
	uint8_t Pad_0xA0[0x10]; // 0xA0(0x10)
	uint8_t bIsDynamicallyLoaded : 1; // 0xB0(0x1), Mask(0x1)
	uint8_t bHasUObject : 1; // 0xB0(0x1), Mask(0x2)
	uint8_t bUseImageSizeAsTextureSize : 1; // 0xB0(0x1), Mask(0x4)
	uint8_t BitPad_0xB0_3 : 5; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
};

// Object: ScriptStruct SlateCore.SlateColor
// Size: 0x28 (Inherited: 0x0)
struct FSlateColor
{
	struct FLinearColor SpecifiedColor; // 0x0(0x10)
	enum class ESlateColorStylingMode ColorUseRule; // 0x10(0x1)
	uint8_t Pad_0x11[0x17]; // 0x11(0x17)
};

// Object: ScriptStruct SlateCore.PointerEvent
// Size: 0x78 (Inherited: 0x20)
struct FPointerEvent : FInputEvent
{
	uint8_t Pad_0x20[0x58]; // 0x20(0x58)
};

// Object: ScriptStruct SlateCore.SlateWidgetStyle
// Size: 0x8 (Inherited: 0x0)
struct FSlateWidgetStyle
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct SlateCore.ButtonStyle
// Size: 0x338 (Inherited: 0x8)
struct FButtonStyle : FSlateWidgetStyle
{
	struct FSlateBrush Normal; // 0x8(0xB8)
	struct FSlateBrush Hovered; // 0xC0(0xB8)
	struct FSlateBrush Pressed; // 0x178(0xB8)
	struct FSlateBrush Disabled; // 0x230(0xB8)
	struct FMargin NormalPadding; // 0x2E8(0x10)
	struct FMargin PressedPadding; // 0x2F8(0x10)
	struct FSlateSound PressedSlateSound; // 0x308(0x18)
	struct FSlateSound HoveredSlateSound; // 0x320(0x18)
};

// Object: ScriptStruct SlateCore.SlateSound
// Size: 0x18 (Inherited: 0x0)
struct FSlateSound
{
	struct UObject* ResourceObject; // 0x0(0x8)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: ScriptStruct SlateCore.SlateFontInfo
// Size: 0x58 (Inherited: 0x0)
struct FSlateFontInfo
{
	struct UObject* FontObject; // 0x0(0x8)
	struct UObject* FontMaterial; // 0x8(0x8)
	struct FFontOutlineSettings OutlineSettings; // 0x10(0x28)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
	struct FName TypefaceFontName; // 0x48(0x8)
	int Size; // 0x50(0x4)
	bool IsBold; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
};

// Object: ScriptStruct SlateCore.FontOutlineSettings
// Size: 0x28 (Inherited: 0x0)
struct FFontOutlineSettings
{
	int OutlineSize; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UObject* OutlineMaterial; // 0x8(0x8)
	struct FLinearColor OutlineColor; // 0x10(0x10)
	bool bSeparateFillAlpha; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: ScriptStruct SlateCore.TableRowStyle
// Size: 0x8F8 (Inherited: 0x8)
struct FTableRowStyle : FSlateWidgetStyle
{
	struct FSlateBrush SelectorFocusedBrush; // 0x8(0xB8)
	struct FSlateBrush ActiveHoveredBrush; // 0xC0(0xB8)
	struct FSlateBrush ActiveBrush; // 0x178(0xB8)
	struct FSlateBrush InactiveHoveredBrush; // 0x230(0xB8)
	struct FSlateBrush InactiveBrush; // 0x2E8(0xB8)
	struct FSlateBrush EvenRowBackgroundHoveredBrush; // 0x3A0(0xB8)
	struct FSlateBrush EvenRowBackgroundBrush; // 0x458(0xB8)
	struct FSlateBrush OddRowBackgroundHoveredBrush; // 0x510(0xB8)
	struct FSlateBrush OddRowBackgroundBrush; // 0x5C8(0xB8)
	struct FSlateColor TextColor; // 0x680(0x28)
	struct FSlateColor SelectedTextColor; // 0x6A8(0x28)
	struct FSlateBrush DropIndicator_Above; // 0x6D0(0xB8)
	struct FSlateBrush DropIndicator_Onto; // 0x788(0xB8)
	struct FSlateBrush DropIndicator_Below; // 0x840(0xB8)
};

// Object: ScriptStruct SlateCore.ComboBoxStyle
// Size: 0x508 (Inherited: 0x8)
struct FComboBoxStyle : FSlateWidgetStyle
{
	struct FComboButtonStyle ComboButtonStyle; // 0x8(0x4D0)
	struct FSlateSound PressedSlateSound; // 0x4D8(0x18)
	struct FSlateSound SelectionChangeSlateSound; // 0x4F0(0x18)
};

// Object: ScriptStruct SlateCore.ComboButtonStyle
// Size: 0x4D0 (Inherited: 0x8)
struct FComboButtonStyle : FSlateWidgetStyle
{
	struct FButtonStyle ButtonStyle; // 0x8(0x338)
	struct FSlateBrush DownArrowImage; // 0x340(0xB8)
	float ArrowPaddingLeft; // 0x3F8(0x4)
	float ArrowPaddingRight; // 0x3FC(0x4)
	float ArrowPaddingTop; // 0x400(0x4)
	float ArrowPaddingBottom; // 0x404(0x4)
	struct FSlateBrush MenuBorderBrush; // 0x408(0xB8)
	struct FMargin MenuBorderPadding; // 0x4C0(0x10)
};

// Object: ScriptStruct SlateCore.EditableTextStyle
// Size: 0x2B0 (Inherited: 0x8)
struct FEditableTextStyle : FSlateWidgetStyle
{
	struct FSlateFontInfo Font; // 0x8(0x58)
	struct FSlateColor ColorAndOpacity; // 0x60(0x28)
	struct FSlateBrush BackgroundImageSelected; // 0x88(0xB8)
	struct FSlateBrush BackgroundImageComposing; // 0x140(0xB8)
	struct FSlateBrush CaretImage; // 0x1F8(0xB8)
};

// Object: ScriptStruct SlateCore.EditableTextBoxStyle
// Size: 0xA68 (Inherited: 0x8)
struct FEditableTextBoxStyle : FSlateWidgetStyle
{
	struct FSlateBrush BackgroundImageNormal; // 0x8(0xB8)
	struct FSlateBrush BackgroundImageHovered; // 0xC0(0xB8)
	struct FSlateBrush BackgroundImageFocused; // 0x178(0xB8)
	struct FSlateBrush BackgroundImageReadOnly; // 0x230(0xB8)
	struct FMargin Padding; // 0x2E8(0x10)
	struct FSlateFontInfo Font; // 0x2F8(0x58)
	struct FSlateColor ForegroundColor; // 0x350(0x28)
	struct FSlateColor BackgroundColor; // 0x378(0x28)
	struct FSlateColor ReadOnlyForegroundColor; // 0x3A0(0x28)
	struct FMargin HScrollBarPadding; // 0x3C8(0x10)
	struct FMargin VScrollBarPadding; // 0x3D8(0x10)
	struct FScrollBarStyle ScrollBarStyle; // 0x3E8(0x680)
};

// Object: ScriptStruct SlateCore.ScrollBarStyle
// Size: 0x680 (Inherited: 0x8)
struct FScrollBarStyle : FSlateWidgetStyle
{
	struct FSlateBrush HorizontalBackgroundImage; // 0x8(0xB8)
	struct FSlateBrush VerticalBackgroundImage; // 0xC0(0xB8)
	struct FSlateBrush VerticalTopSlotImage; // 0x178(0xB8)
	struct FSlateBrush HorizontalTopSlotImage; // 0x230(0xB8)
	struct FSlateBrush VerticalBottomSlotImage; // 0x2E8(0xB8)
	struct FSlateBrush HorizontalBottomSlotImage; // 0x3A0(0xB8)
	struct FSlateBrush NormalThumbImage; // 0x458(0xB8)
	struct FSlateBrush HoveredThumbImage; // 0x510(0xB8)
	struct FSlateBrush DraggedThumbImage; // 0x5C8(0xB8)
};

// Object: ScriptStruct SlateCore.TextBlockStyle
// Size: 0x250 (Inherited: 0x8)
struct FTextBlockStyle : FSlateWidgetStyle
{
	struct FSlateFontInfo Font; // 0x8(0x58)
	uint8_t Pad_0x60[0x8]; // 0x60(0x8)
	struct FSlateColor ColorAndOpacity; // 0x68(0x28)
	struct FVector2D ShadowOffset; // 0x90(0x8)
	struct FLinearColor ShadowColorAndOpacity; // 0x98(0x10)
	struct FSlateColor SelectedBackgroundColor; // 0xA8(0x28)
	struct FLinearColor HighlightColor; // 0xD0(0x10)
	struct FSlateBrush HighlightShape; // 0xE0(0xB8)
	struct FSlateBrush UnderlineBrush; // 0x198(0xB8)
};

// Object: ScriptStruct SlateCore.SpinBoxStyle
// Size: 0x3D8 (Inherited: 0x8)
struct FSpinBoxStyle : FSlateWidgetStyle
{
	struct FSlateBrush BackgroundBrush; // 0x8(0xB8)
	struct FSlateBrush HoveredBackgroundBrush; // 0xC0(0xB8)
	struct FSlateBrush ActiveFillBrush; // 0x178(0xB8)
	struct FSlateBrush InactiveFillBrush; // 0x230(0xB8)
	struct FSlateBrush ArrowsImage; // 0x2E8(0xB8)
	struct FSlateColor ForegroundColor; // 0x3A0(0x28)
	struct FMargin TextPadding; // 0x3C8(0x10)
};

// Object: ScriptStruct SlateCore.ScrollBoxStyle
// Size: 0x2E8 (Inherited: 0x8)
struct FScrollBoxStyle : FSlateWidgetStyle
{
	struct FSlateBrush TopShadowBrush; // 0x8(0xB8)
	struct FSlateBrush BottomShadowBrush; // 0xC0(0xB8)
	struct FSlateBrush LeftShadowBrush; // 0x178(0xB8)
	struct FSlateBrush RightShadowBrush; // 0x230(0xB8)
};

// Object: ScriptStruct SlateCore.FocusEvent
// Size: 0x8 (Inherited: 0x0)
struct FFocusEvent
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct SlateCore.CharacterEvent
// Size: 0x28 (Inherited: 0x20)
struct FCharacterEvent : FInputEvent
{
	uint8_t Pad_0x20[0x8]; // 0x20(0x8)
};

// Object: ScriptStruct SlateCore.MotionEvent
// Size: 0x50 (Inherited: 0x20)
struct FMotionEvent : FInputEvent
{
	uint8_t Pad_0x20[0x30]; // 0x20(0x30)
};

// Object: ScriptStruct SlateCore.WAnimTime
// Size: 0x10 (Inherited: 0x0)
struct FWAnimTime
{
	float PlayTime_1; // 0x0(0x4)
	float PlayTime_2; // 0x4(0x4)
	float PlayTime_3; // 0x8(0x4)
	float PlayTime_4; // 0xC(0x4)
};

// Object: ScriptStruct SlateCore.CompositeFont
// Size: 0x20 (Inherited: 0x0)
struct FCompositeFont
{
	struct FTypeface DefaultTypeface; // 0x0(0x10)
	struct TArray<struct FCompositeSubFont> SubTypefaces; // 0x10(0x10)
};

// Object: ScriptStruct SlateCore.CompositeSubFont
// Size: 0x28 (Inherited: 0x0)
struct FCompositeSubFont
{
	struct FTypeface Typeface; // 0x0(0x10)
	struct TArray<struct FInt32Range> CharacterRanges; // 0x10(0x10)
	float ScalingFactor; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct SlateCore.Typeface
// Size: 0x10 (Inherited: 0x0)
struct FTypeface
{
	struct TArray<struct FTypefaceEntry> Fonts; // 0x0(0x10)
};

// Object: ScriptStruct SlateCore.TypefaceEntry
// Size: 0x28 (Inherited: 0x0)
struct FTypefaceEntry
{
	struct FName Name; // 0x0(0x8)
	struct FFontData Font; // 0x8(0x20)
};

// Object: ScriptStruct SlateCore.FontData
// Size: 0x20 (Inherited: 0x0)
struct FFontData
{
	struct FString FontFilename; // 0x0(0x10)
	uint8_t Hinting; // 0x10(0x1)
	uint8_t LoadingPolicy; // 0x11(0x1)
	uint8_t Pad_0x12[0x6]; // 0x12(0x6)
	struct UObject* FontFaceAsset; // 0x18(0x8)
};

// Object: ScriptStruct SlateCore.NavigationEvent
// Size: 0x28 (Inherited: 0x20)
struct FNavigationEvent : FInputEvent
{
	uint8_t Pad_0x20[0x8]; // 0x20(0x8)
};

// Object: ScriptStruct SlateCore.WindowStyle
// Size: 0x1490 (Inherited: 0x8)
struct FWindowStyle : FSlateWidgetStyle
{
	struct FButtonStyle MinimizeButtonStyle; // 0x8(0x338)
	struct FButtonStyle MaximizeButtonStyle; // 0x340(0x338)
	struct FButtonStyle RestoreButtonStyle; // 0x678(0x338)
	struct FButtonStyle CloseButtonStyle; // 0x9B0(0x338)
	struct FTextBlockStyle TitleTextStyle; // 0xCE8(0x250)
	struct FSlateBrush ActiveTitleBrush; // 0xF38(0xB8)
	struct FSlateBrush InactiveTitleBrush; // 0xFF0(0xB8)
	struct FSlateBrush FlashTitleBrush; // 0x10A8(0xB8)
	struct FSlateColor BackgroundColor; // 0x1160(0x28)
	struct FSlateBrush OutlineBrush; // 0x1188(0xB8)
	struct FSlateColor OutlineColor; // 0x1240(0x28)
	struct FSlateBrush BorderBrush; // 0x1268(0xB8)
	struct FSlateBrush BackgroundBrush; // 0x1320(0xB8)
	struct FSlateBrush ChildBackgroundBrush; // 0x13D8(0xB8)
};

// Object: ScriptStruct SlateCore.ScrollBorderStyle
// Size: 0x178 (Inherited: 0x8)
struct FScrollBorderStyle : FSlateWidgetStyle
{
	struct FSlateBrush TopShadowBrush; // 0x8(0xB8)
	struct FSlateBrush BottomShadowBrush; // 0xC0(0xB8)
};

// Object: ScriptStruct SlateCore.DockTabStyle
// Size: 0x940 (Inherited: 0x8)
struct FDockTabStyle : FSlateWidgetStyle
{
	struct FButtonStyle CloseButtonStyle; // 0x8(0x338)
	struct FSlateBrush NormalBrush; // 0x340(0xB8)
	struct FSlateBrush ActiveBrush; // 0x3F8(0xB8)
	struct FSlateBrush ColorOverlayTabBrush; // 0x4B0(0xB8)
	struct FSlateBrush ColorOverlayIconBrush; // 0x568(0xB8)
	struct FSlateBrush ForegroundBrush; // 0x620(0xB8)
	struct FSlateBrush HoveredBrush; // 0x6D8(0xB8)
	struct FSlateBrush ContentAreaBrush; // 0x790(0xB8)
	struct FSlateBrush TabWellBrush; // 0x848(0xB8)
	struct FMargin TabPadding; // 0x900(0x10)
	float OverlapWidth; // 0x910(0x4)
	uint8_t Pad_0x914[0x4]; // 0x914(0x4)
	struct FSlateColor FlashColor; // 0x918(0x28)
};

// Object: ScriptStruct SlateCore.HeaderRowStyle
// Size: 0xF60 (Inherited: 0x8)
struct FHeaderRowStyle : FSlateWidgetStyle
{
	struct FTableColumnHeaderStyle ColumnStyle; // 0x8(0x680)
	struct FTableColumnHeaderStyle LastColumnStyle; // 0x688(0x680)
	struct FSplitterStyle ColumnSplitterStyle; // 0xD08(0x178)
	struct FSlateBrush BackgroundBrush; // 0xE80(0xB8)
	struct FSlateColor ForegroundColor; // 0xF38(0x28)
};

// Object: ScriptStruct SlateCore.SplitterStyle
// Size: 0x178 (Inherited: 0x8)
struct FSplitterStyle : FSlateWidgetStyle
{
	struct FSlateBrush HandleNormalBrush; // 0x8(0xB8)
	struct FSlateBrush HandleHighlightBrush; // 0xC0(0xB8)
};

// Object: ScriptStruct SlateCore.TableColumnHeaderStyle
// Size: 0x680 (Inherited: 0x8)
struct FTableColumnHeaderStyle : FSlateWidgetStyle
{
	struct FSlateBrush SortPrimaryAscendingImage; // 0x8(0xB8)
	struct FSlateBrush SortPrimaryDescendingImage; // 0xC0(0xB8)
	struct FSlateBrush SortSecondaryAscendingImage; // 0x178(0xB8)
	struct FSlateBrush SortSecondaryDescendingImage; // 0x230(0xB8)
	struct FSlateBrush NormalBrush; // 0x2E8(0xB8)
	struct FSlateBrush HoveredBrush; // 0x3A0(0xB8)
	struct FSlateBrush MenuDropdownImage; // 0x458(0xB8)
	struct FSlateBrush MenuDropdownNormalBorderBrush; // 0x510(0xB8)
	struct FSlateBrush MenuDropdownHoveredBorderBrush; // 0x5C8(0xB8)
};

// Object: ScriptStruct SlateCore.InlineTextImageStyle
// Size: 0xC8 (Inherited: 0x8)
struct FInlineTextImageStyle : FSlateWidgetStyle
{
	struct FSlateBrush Image; // 0x8(0xB8)
	int16_t Baseline; // 0xC0(0x2)
	uint8_t Pad_0xC2[0x6]; // 0xC2(0x6)
};

// Object: ScriptStruct SlateCore.VolumeControlStyle
// Size: 0x690 (Inherited: 0x8)
struct FVolumeControlStyle : FSlateWidgetStyle
{
	struct FSliderStyle SliderStyle; // 0x8(0x2F0)
	struct FSlateBrush HighVolumeImage; // 0x2F8(0xB8)
	struct FSlateBrush MidVolumeImage; // 0x3B0(0xB8)
	struct FSlateBrush LowVolumeImage; // 0x468(0xB8)
	struct FSlateBrush NoVolumeImage; // 0x520(0xB8)
	struct FSlateBrush MutedImage; // 0x5D8(0xB8)
};

// Object: ScriptStruct SlateCore.SliderStyle
// Size: 0x2F0 (Inherited: 0x8)
struct FSliderStyle : FSlateWidgetStyle
{
	struct FSlateBrush NormalBarImage; // 0x8(0xB8)
	struct FSlateBrush DisabledBarImage; // 0xC0(0xB8)
	struct FSlateBrush NormalThumbImage; // 0x178(0xB8)
	struct FSlateBrush DisabledThumbImage; // 0x230(0xB8)
	float BarThickness; // 0x2E8(0x4)
	uint8_t Pad_0x2EC[0x4]; // 0x2EC(0x4)
};

// Object: ScriptStruct SlateCore.SearchBoxStyle
// Size: 0xDC0 (Inherited: 0x8)
struct FSearchBoxStyle : FSlateWidgetStyle
{
	struct FEditableTextBoxStyle TextBoxStyle; // 0x8(0xA68)
	struct FSlateFontInfo ActiveFontInfo; // 0xA70(0x58)
	struct FSlateBrush UpArrowImage; // 0xAC8(0xB8)
	struct FSlateBrush DownArrowImage; // 0xB80(0xB8)
	struct FSlateBrush GlassImage; // 0xC38(0xB8)
	struct FSlateBrush ClearImage; // 0xCF0(0xB8)
	struct FMargin ImagePadding; // 0xDA8(0x10)
	bool bLeftAlignButtons; // 0xDB8(0x1)
	uint8_t Pad_0xDB9[0x7]; // 0xDB9(0x7)
};

// Object: ScriptStruct SlateCore.ExpandableAreaStyle
// Size: 0x180 (Inherited: 0x8)
struct FExpandableAreaStyle : FSlateWidgetStyle
{
	struct FSlateBrush CollapsedImage; // 0x8(0xB8)
	struct FSlateBrush ExpandedImage; // 0xC0(0xB8)
	float RolloutAnimationSeconds; // 0x178(0x4)
	uint8_t Pad_0x17C[0x4]; // 0x17C(0x4)
};

// Object: ScriptStruct SlateCore.ProgressBarStyle
// Size: 0x230 (Inherited: 0x8)
struct FProgressBarStyle : FSlateWidgetStyle
{
	struct FSlateBrush BackgroundImage; // 0x8(0xB8)
	struct FSlateBrush FillImage; // 0xC0(0xB8)
	struct FSlateBrush MarqueeImage; // 0x178(0xB8)
};

// Object: ScriptStruct SlateCore.InlineEditableTextBlockStyle
// Size: 0xCC0 (Inherited: 0x8)
struct FInlineEditableTextBlockStyle : FSlateWidgetStyle
{
	struct FEditableTextBoxStyle EditableTextBoxStyle; // 0x8(0xA68)
	struct FTextBlockStyle TextStyle; // 0xA70(0x250)
};

// Object: ScriptStruct SlateCore.HyperlinkStyle
// Size: 0x5A0 (Inherited: 0x8)
struct FHyperlinkStyle : FSlateWidgetStyle
{
	struct FButtonStyle UnderlineStyle; // 0x8(0x338)
	struct FTextBlockStyle TextStyle; // 0x340(0x250)
	struct FMargin Padding; // 0x590(0x10)
};

// Object: ScriptStruct SlateCore.CheckBoxStyle
// Size: 0x730 (Inherited: 0x8)
struct FCheckBoxStyle : FSlateWidgetStyle
{
	enum class ESlateCheckBoxType CheckBoxType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FSlateBrush UncheckedImage; // 0x10(0xB8)
	struct FSlateBrush UncheckedHoveredImage; // 0xC8(0xB8)
	struct FSlateBrush UncheckedPressedImage; // 0x180(0xB8)
	struct FSlateBrush CheckedImage; // 0x238(0xB8)
	struct FSlateBrush CheckedHoveredImage; // 0x2F0(0xB8)
	struct FSlateBrush CheckedPressedImage; // 0x3A8(0xB8)
	struct FSlateBrush UndeterminedImage; // 0x460(0xB8)
	struct FSlateBrush UndeterminedHoveredImage; // 0x518(0xB8)
	struct FSlateBrush UndeterminedPressedImage; // 0x5D0(0xB8)
	struct FMargin Padding; // 0x688(0x10)
	struct FSlateColor ForegroundColor; // 0x698(0x28)
	struct FSlateColor BorderBackgroundColor; // 0x6C0(0x28)
	struct FSlateSound CheckedSlateSound; // 0x6E8(0x18)
	struct FSlateSound UncheckedSlateSound; // 0x700(0x18)
	struct FSlateSound HoveredSlateSound; // 0x718(0x18)
};

// Object: Class SlateCore.SlateWidgetStyleContainerBase
// Size: 0x30 (Inherited: 0x28)
struct USlateWidgetStyleContainerBase : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: Class SlateCore.FontBulkData
// Size: 0xD8 (Inherited: 0x28)
struct UFontBulkData : UObject
{
	uint8_t Pad_0x28[0xB0]; // 0x28(0xB0)
};

// Object: Class SlateCore.FontFaceInterface
// Size: 0x28 (Inherited: 0x28)
struct IFontFaceInterface : IInterface
{
};

// Object: Class SlateCore.FontProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct IFontProviderInterface : IInterface
{
};

// Object: Class SlateCore.SlateTypes
// Size: 0x28 (Inherited: 0x28)
struct USlateTypes : UObject
{
};

// Object: Class SlateCore.SlateWidgetStyleAsset
// Size: 0x30 (Inherited: 0x28)
struct USlateWidgetStyleAsset : UObject
{
	struct USlateWidgetStyleContainerBase* CustomStyle; // 0x28(0x8)
};

// Object: Class SlateCore.SlateWidgetStyleContainerInterface
// Size: 0x28 (Inherited: 0x28)
struct ISlateWidgetStyleContainerInterface : IInterface
{
};

