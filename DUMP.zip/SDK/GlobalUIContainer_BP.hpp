#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass GlobalUIContainer_BP.GlobalUIContainer_BP_C
// Size: 0x438 (Inherited: 0x430)
struct UGlobalUIContainer_BP_C : UUAEWidgetContainer
{
	struct UCanvasPanel* CanvasContainer; // 0x430(0x8)
};

