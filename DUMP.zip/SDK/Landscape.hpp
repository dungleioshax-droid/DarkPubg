#pragma once

#include <cstdint>

// Object: Enum Landscape.ELandscapeSetupErrors
enum class ELandscapeSetupErrors : uint8_t
{
	LSE_None = 0,
	LSE_NoLandscapeInfo = 1,
	LSE_CollsionXY = 2,
	LSE_NoLayerInfo = 3,
	LSE_MAX = 4
};

// Object: Enum Landscape.ELandscapeGizmoType
enum class ELandscapeGizmoType : uint8_t
{
	LGT_None = 0,
	LGT_Height = 1,
	LGT_Weight = 2,
	LGT_MAX = 3
};

// Object: Enum Landscape.EGrassScaling
enum class EGrassScaling : uint8_t
{
	Uniform = 0,
	Free = 1,
	LockXY = 2,
	EGrassScaling_MAX = 3
};

// Object: Enum Landscape.ELandscapeLODFalloff
enum class ELandscapeLODFalloff : uint8_t
{
	Linear = 0,
	SquareRoot = 1,
	ELandscapeLODFalloff_MAX = 2
};

// Object: Enum Landscape.ELandscapeLayerDisplayMode
enum class ELandscapeLayerDisplayMode : uint8_t
{
	Default = 0,
	Alphabetical = 1,
	UserSpecific = 2,
	ELandscapeLayerDisplayMode_MAX = 3
};

// Object: Enum Landscape.ELandscapeLayerPaintingRestriction
enum class ELandscapeLayerPaintingRestriction : uint8_t
{
	None = 0,
	UseMaxLayers = 1,
	ExistingOnly = 2,
	UseComponentWhitelist = 3,
	ELandscapeLayerPaintingRestriction_MAX = 4
};

// Object: Enum Landscape.ELandscapeImportAlphamapType
enum class ELandscapeImportAlphamapType : uint8_t
{
	Additive = 0,
	Layered = 1,
	ELandscapeImportAlphamapType_MAX = 2
};

// Object: Enum Landscape.LandscapeSplineMeshOrientation
enum class ELandscapeSplineMeshOrientation : uint8_t
{
	LSMO_XUp = 0,
	LSMO_YUp = 1,
	LSMO_MAX = 2
};

// Object: Enum Landscape.ELandscapeLayerBlendType
enum class ELandscapeLayerBlendType : uint8_t
{
	LB_WeightBlend = 0,
	LB_AlphaBlend = 1,
	LB_HeightBlend = 2,
	LB_MAX = 3
};

// Object: Enum Landscape.ELandscapeCustomizedCoordType
enum class ELandscapeCustomizedCoordType : uint8_t
{
	LCCT_None = 0,
	LCCT_CustomUV0 = 1,
	LCCT_CustomUV1 = 2,
	LCCT_CustomUV2 = 3,
	LCCT_WeightMapUV = 4,
	LCCT_MAX = 5
};

// Object: Enum Landscape.ETerrainCoordMappingType
enum class ETerrainCoordMappingType : uint8_t
{
	TCMT_Auto = 0,
	TCMT_XY = 1,
	TCMT_XZ = 2,
	TCMT_YZ = 3,
	TCMT_MAX = 4
};

// Object: ScriptStruct Landscape.LandscapeColorMask
// Size: 0x1 (Inherited: 0x0)
struct FLandscapeColorMask
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.LandscapeColorMaskLayer
// Size: 0x1 (Inherited: 0x0)
struct FLandscapeColorMaskLayer
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.OverridePhyxMaterial
// Size: 0x20 (Inherited: 0x0)
struct FOverridePhyxMaterial
{
	struct TArray<struct UPhysicalMaterial*> OriginalPhysxMaterial; // 0x0(0x10)
	struct TArray<struct UPhysicalMaterial*> OverridePhysxMaterial; // 0x10(0x10)
};

// Object: ScriptStruct Landscape.WeightmapLayerAllocationInfo
// Size: 0x10 (Inherited: 0x0)
struct FWeightmapLayerAllocationInfo
{
	struct ULandscapeLayerInfoObject* LayerInfo; // 0x0(0x8)
	uint8_t WeightmapTextureIndex; // 0x8(0x1)
	uint8_t WeightmapTextureChannel; // 0x9(0x1)
	uint8_t Pad_0xA[0x6]; // 0xA(0x6)
};

// Object: ScriptStruct Landscape.VisibilityData
// Size: 0x10 (Inherited: 0x0)
struct FVisibilityData
{
	struct TArray<uint8_t> VisibilityData; // 0x0(0x10)
};

// Object: ScriptStruct Landscape.LandscapeEditToolRenderData
// Size: 0x30 (Inherited: 0x0)
struct FLandscapeEditToolRenderData
{
	struct UMaterialInterface* ToolMaterial; // 0x0(0x8)
	struct UMaterialInterface* GizmoMaterial; // 0x8(0x8)
	int SelectedType; // 0x10(0x4)
	int DebugChannelR; // 0x14(0x4)
	int DebugChannelG; // 0x18(0x4)
	int DebugChannelB; // 0x1C(0x4)
	int DebugChannelA; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct UTexture2D* DataTexture; // 0x28(0x8)
};

// Object: ScriptStruct Landscape.SimpleMeshSection
// Size: 0x40 (Inherited: 0x0)
struct FSimpleMeshSection
{
	struct TArray<struct FSimpleMeshVertex> VertexBuffer; // 0x0(0x10)
	struct TArray<int> IndexBuffer; // 0x10(0x10)
	struct FBox BoundingBox; // 0x20(0x1C)
	bool Visible; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
};

// Object: ScriptStruct Landscape.SimpleMeshVertex
// Size: 0x34 (Inherited: 0x0)
struct FSimpleMeshVertex
{
	struct FVector Position; // 0x0(0xC)
	struct FVector Normal; // 0xC(0xC)
	struct FSimpleMeshTangent Tangent; // 0x18(0x10)
	struct FColor Color; // 0x28(0x4)
	struct FVector2D UV0; // 0x2C(0x8)
};

// Object: ScriptStruct Landscape.SimpleMeshTangent
// Size: 0x10 (Inherited: 0x0)
struct FSimpleMeshTangent
{
	struct FVector TangentX; // 0x0(0xC)
	bool bFlipTangentY; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct Landscape.LevelComponentMapValue
// Size: 0x150 (Inherited: 0x0)
struct FLevelComponentMapValue
{
	struct FString Name; // 0x0(0x10)
	struct TArray<int> IndexOffsetArray; // 0x10(0x10)
	struct TArray<int> IndexCountArray; // 0x20(0x10)
	struct TArray<int> VertexOffsetIndex; // 0x30(0x10)
	struct TArray<int> BorderIndex1; // 0x40(0x10)
	struct TArray<int> BorderIndex2; // 0x50(0x10)
	struct TArray<int> BorderIndex3; // 0x60(0x10)
	struct TArray<int> BorderIndex4; // 0x70(0x10)
	struct TArray<int> UnderBorderIndex1; // 0x80(0x10)
	struct TArray<int> UnderBorderIndex2; // 0x90(0x10)
	struct TArray<int> UnderBorderIndex3; // 0xA0(0x10)
	struct TArray<int> UnderBorderIndex4; // 0xB0(0x10)
	struct TArray<int> BorderIndicesBuffer1; // 0xC0(0x10)
	struct TArray<int> BorderIndicesBuffer2; // 0xD0(0x10)
	struct TArray<int> BorderIndicesBuffer3; // 0xE0(0x10)
	struct TArray<int> BorderIndicesBuffer4; // 0xF0(0x10)
	struct FString Sibling1Name; // 0x100(0x10)
	struct FString Sibling2Name; // 0x110(0x10)
	struct FString Sibling3Name; // 0x120(0x10)
	struct FString Sibling4Name; // 0x130(0x10)
	int Sibling1Idx; // 0x140(0x4)
	int Sibling2Idx; // 0x144(0x4)
	int Sibling3Idx; // 0x148(0x4)
	int Sibling4Idx; // 0x14C(0x4)
};

// Object: ScriptStruct Landscape.GizmoSelectData
// Size: 0x50 (Inherited: 0x0)
struct FGizmoSelectData
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct Landscape.GrassVariety
// Size: 0x48 (Inherited: 0x0)
struct FGrassVariety
{
	struct UStaticMesh* GrassMesh; // 0x0(0x8)
	float GrassDensity; // 0x8(0x4)
	bool bUseGrid; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	float PlacementJitter; // 0x10(0x4)
	int StartCullDistance; // 0x14(0x4)
	int EndCullDistance; // 0x18(0x4)
	int MinLOD; // 0x1C(0x4)
	uint8_t Scaling; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	struct FFloatInterval ScaleX; // 0x24(0x8)
	struct FFloatInterval ScaleY; // 0x2C(0x8)
	struct FFloatInterval ScaleZ; // 0x34(0x8)
	bool RandomRotation; // 0x3C(0x1)
	bool AlignToSurface; // 0x3D(0x1)
	bool bUseLandscapeLightmap; // 0x3E(0x1)
	struct FLightingChannels LightingChannels; // 0x3F(0x1)
	bool bReceivesDecals; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
};

// Object: ScriptStruct Landscape.IdeaGrassFieldData
// Size: 0x90 (Inherited: 0x0)
struct FIdeaGrassFieldData
{
	struct UTextureRenderTarget2D* ForceTextureRT; // 0x0(0x8)
	struct TArray<struct FVector> TramplerPositionList; // 0x8(0x10)
	struct TArray<struct FRotator> TramplerDirectionList; // 0x18(0x10)
	struct TArray<float> TramplerCutoff; // 0x28(0x10)
	struct UTexture* TrampleTexture; // 0x38(0x8)
	float TrampleScale; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct UTexture* SkillTexture; // 0x48(0x8)
	struct TArray<float> CleanTextureScale; // 0x50(0x10)
	float GrassSpringness; // 0x60(0x4)
	uint8_t Pad_0x64[0xC]; // 0x64(0xC)
	struct FVector4 GrassFieldRect; // 0x70(0x10)
	uint8_t FeatureLevel; // 0x80(0x1)
	uint8_t Pad_0x81[0xF]; // 0x81(0xF)
};

// Object: ScriptStruct Landscape.LandscapeInfoLayerSettings
// Size: 0x10 (Inherited: 0x0)
struct FLandscapeInfoLayerSettings
{
	struct ULandscapeLayerInfoObject* LayerInfoObj; // 0x0(0x8)
	struct FName LayerName; // 0x8(0x8)
};

// Object: ScriptStruct Landscape.LandscapeImportLayerInfo
// Size: 0x1 (Inherited: 0x0)
struct FLandscapeImportLayerInfo
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.LandscapeLayerStruct
// Size: 0x8 (Inherited: 0x0)
struct FLandscapeLayerStruct
{
	struct ULandscapeLayerInfoObject* LayerInfoObj; // 0x0(0x8)
};

// Object: ScriptStruct Landscape.LandscapeEditorLayerSettings
// Size: 0x1 (Inherited: 0x0)
struct FLandscapeEditorLayerSettings
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.LandscapeWeightmapUsage
// Size: 0x20 (Inherited: 0x0)
struct FLandscapeWeightmapUsage
{
	struct ULandscapeComponent* ChannelUsage[0x4]; // 0x0(0x20)
};

// Object: ScriptStruct Landscape.LandscapeSplineConnection
// Size: 0x10 (Inherited: 0x0)
struct FLandscapeSplineConnection
{
	struct ULandscapeSplineSegment* Segment; // 0x0(0x8)
	uint8_t End : 1; // 0x8(0x1), Mask(0x1)
	uint8_t BitPad_0x8_1 : 7; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Landscape.ForeignWorldSplineData
// Size: 0x1 (Inherited: 0x0)
struct FForeignWorldSplineData
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.ForeignSplineSegmentData
// Size: 0x1 (Inherited: 0x0)
struct FForeignSplineSegmentData
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.ForeignControlPointData
// Size: 0x1 (Inherited: 0x0)
struct FForeignControlPointData
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Landscape.LandscapeSplineMeshEntry
// Size: 0x38 (Inherited: 0x0)
struct FLandscapeSplineMeshEntry
{
	struct UStaticMesh* Mesh; // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> MaterialOverrides; // 0x8(0x10)
	uint8_t bCenterH : 1; // 0x18(0x1), Mask(0x1)
	uint8_t BitPad_0x18_1 : 7; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	struct FVector2D CenterAdjust; // 0x1C(0x8)
	uint8_t bScaleToWidth : 1; // 0x24(0x1), Mask(0x1)
	uint8_t BitPad_0x24_1 : 7; // 0x24(0x1)
	uint8_t Pad_0x25[0x3]; // 0x25(0x3)
	struct FVector Scale; // 0x28(0xC)
	enum class ELandscapeSplineMeshOrientation Orientation; // 0x34(0x1)
	enum class ESplineMeshAxis ForwardAxis; // 0x35(0x1)
	enum class ESplineMeshAxis UpAxis; // 0x36(0x1)
	uint8_t Pad_0x37[0x1]; // 0x37(0x1)
};

// Object: ScriptStruct Landscape.LandscapeSplineSegmentConnection
// Size: 0x18 (Inherited: 0x0)
struct FLandscapeSplineSegmentConnection
{
	struct ULandscapeSplineControlPoint* ControlPoint; // 0x0(0x8)
	float TangentLen; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FName SocketName; // 0x10(0x8)
};

// Object: ScriptStruct Landscape.LandscapeSplineInterpPoint
// Size: 0x40 (Inherited: 0x0)
struct FLandscapeSplineInterpPoint
{
	struct FVector Center; // 0x0(0xC)
	struct FVector Left; // 0xC(0xC)
	struct FVector Right; // 0x18(0xC)
	struct FVector FalloffLeft; // 0x24(0xC)
	struct FVector FalloffRight; // 0x30(0xC)
	float StartEndFalloff; // 0x3C(0x4)
};

// Object: ScriptStruct Landscape.GrassInput
// Size: 0x48 (Inherited: 0x0)
struct FGrassInput
{
	struct FName Name; // 0x0(0x8)
	struct ULandscapeGrassType* GrassType; // 0x8(0x8)
	struct FExpressionInput Input; // 0x10(0x38)
};

// Object: ScriptStruct Landscape.LayerBlendInput
// Size: 0x98 (Inherited: 0x0)
struct FLayerBlendInput
{
	struct FName LayerName; // 0x0(0x8)
	enum class ELandscapeLayerBlendType BlendType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FExpressionInput LayerInput; // 0x10(0x38)
	struct FExpressionInput HeightInput; // 0x48(0x38)
	float PreviewWeight; // 0x80(0x4)
	struct FVector ConstLayerInput; // 0x84(0xC)
	float ConstHeightInput; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
};

// Object: Class Landscape.ControlPointMeshComponent
// Size: 0xBD0 (Inherited: 0xBD0)
struct UControlPointMeshComponent : UStaticMeshComponent
{
};

// Object: Class Landscape.LandscapeProxy
// Size: 0xAD0 (Inherited: 0x4B0)
struct ALandscapeProxy : AActor
{
	uint8_t Pad_0x4B0[0x20]; // 0x4B0(0x20)
	struct ULandscapeSplinesComponent* SplineComponent; // 0x4D0(0x8)
	struct FGuid LandscapeGuid; // 0x4D8(0x10)
	struct FGuid BoundingGuid; // 0x4E8(0x10)
	struct FIntPoint LandscapeSectionOffset; // 0x4F8(0x8)
	int MaxLODLevel; // 0x500(0x4)
	float LODDistanceFactor; // 0x504(0x4)
	enum class ELandscapeLODFalloff LODFalloff; // 0x508(0x1)
	bool bUseScreenSizeLOD; // 0x509(0x1)
	uint8_t Pad_0x50A[0x2]; // 0x50A(0x2)
	float LOD0DistributionSetting; // 0x50C(0x4)
	float LODDistributionSetting; // 0x510(0x4)
	uint8_t NearMaxLOD_Baked; // 0x514(0x1)
	uint8_t Pad_0x515[0x3]; // 0x515(0x3)
	float NearFactor_Baked; // 0x518(0x4)
	float NearExtent_Baked; // 0x51C(0x4)
	float FarFactor_Baked; // 0x520(0x4)
	float LandscapeRoughness; // 0x524(0x4)
	bool EnableImproveLOD; // 0x528(0x1)
	uint8_t Pad_0x529[0x7]; // 0x529(0x7)
	struct TArray<float> ImproveLODValues; // 0x530(0x10)
	uint8_t NearMaxLOD; // 0x540(0x1)
	uint8_t Pad_0x541[0x3]; // 0x541(0x3)
	float NearFactor; // 0x544(0x4)
	float NearExtent; // 0x548(0x4)
	float FarFactor; // 0x54C(0x4)
	int StaticLightingLOD; // 0x550(0x4)
	uint8_t Pad_0x554[0x4]; // 0x554(0x4)
	struct UPhysicalMaterial* DefaultPhysMaterial; // 0x558(0x8)
	float StreamingDistanceMultiplier; // 0x560(0x4)
	uint8_t bCacheHeightData : 1; // 0x564(0x1), Mask(0x1)
	uint8_t BitPad_0x564_1 : 7; // 0x564(0x1)
	uint8_t Pad_0x565[0x3]; // 0x565(0x3)
	struct UMaterialInterface* LandscapeMaterial; // 0x568(0x8)
	struct UMaterialInterface* LandscapeHoleMaterial; // 0x570(0x8)
	struct TMap<struct FName, struct UMaterialInterface*> OtherMaterials; // 0x578(0x50)
	uint8_t bOverrideGrassTypes : 1; // 0x5C8(0x1), Mask(0x1)
	uint8_t BitPad_0x5C8_1 : 7; // 0x5C8(0x1)
	uint8_t Pad_0x5C9[0x7]; // 0x5C9(0x7)
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // 0x5D0(0x10)
	float MinGrassWeightThreshold; // 0x5E0(0x4)
	float NegativeZBoundsExtension; // 0x5E4(0x4)
	float PositiveZBoundsExtension; // 0x5E8(0x4)
	uint8_t Pad_0x5EC[0x4]; // 0x5EC(0x4)
	struct UTexture2D* GrassColor_WorldMaskNoiseTexture; // 0x5F0(0x8)
	struct FVector2D GrassColor_UVScale_WorldMaskNoise; // 0x5F8(0x8)
	struct FVector2D GrassColor_Center_WorldMaskNoise; // 0x600(0x8)
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // 0x608(0x10)
	struct ULandscapeAOTextureDataAsset* LandscapeAOTextureDataAsset; // 0x618(0x8)
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // 0x620(0x10)
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // 0x630(0x10)
	uint8_t Pad_0x640[0xB0]; // 0x640(0xB0)
	bool bHasLandscapeGrass; // 0x6F0(0x1)
	uint8_t Pad_0x6F1[0x3]; // 0x6F1(0x3)
	float StaticLightingResolution; // 0x6F4(0x4)
	uint8_t bCastStaticShadow : 1; // 0x6F8(0x1), Mask(0x1)
	uint8_t bCastShadowAsTwoSided : 1; // 0x6F8(0x1), Mask(0x2)
	uint8_t bCastFarShadow : 1; // 0x6F8(0x1), Mask(0x4)
	uint8_t BitPad_0x6F8_3 : 5; // 0x6F8(0x1)
	struct FLightingChannels LightingChannels; // 0x6F9(0x1)
	uint8_t bUseMaterialPositionOffsetInStaticLighting : 1; // 0x6FA(0x1), Mask(0x1)
	uint8_t bRenderCustomDepth : 1; // 0x6FA(0x1), Mask(0x2)
	uint8_t BitPad_0x6FA_2 : 6; // 0x6FA(0x1)
	uint8_t Pad_0x6FB[0x1]; // 0x6FB(0x1)
	int CustomDepthStencilValue; // 0x6FC(0x4)
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x700(0x18)
	int CollisionMipLevel; // 0x718(0x4)
	int SimpleCollisionMipLevel; // 0x71C(0x4)
	float CollisionThickness; // 0x720(0x4)
	uint8_t Pad_0x724[0xC]; // 0x724(0xC)
	struct FBodyInstance BodyInstance; // 0x730(0x210)
	uint8_t bGenerateOverlapEvents : 1; // 0x940(0x1), Mask(0x1)
	uint8_t bBakeMaterialPositionOffsetIntoCollision : 1; // 0x940(0x1), Mask(0x2)
	uint8_t bUseHoleConsistent : 1; // 0x940(0x1), Mask(0x4)
	uint8_t BitPad_0x940_3 : 5; // 0x940(0x1)
	uint8_t Pad_0x941[0x3]; // 0x941(0x3)
	int ComponentSizeQuads; // 0x944(0x4)
	int SubsectionSizeQuads; // 0x948(0x4)
	int NumSubsections; // 0x94C(0x4)
	uint8_t bUsedForNavigation : 1; // 0x950(0x1), Mask(0x1)
	uint8_t bMobileMultiLayers : 1; // 0x950(0x1), Mask(0x2)
	uint8_t BitPad_0x950_2 : 6; // 0x950(0x1)
	uint8_t NavigationGeometryGatheringMode; // 0x951(0x1)
	bool bUseLandscapeForCullingInvisibleHLODVertices; // 0x952(0x1)
	bool bUseLandscapeVT; // 0x953(0x1)
	uint8_t Pad_0x954[0x4]; // 0x954(0x4)
	struct UTexture2D* MaskTextureUsedByGrassClear; // 0x958(0x8)
	uint8_t Pad_0x960[0x170]; // 0x960(0x170)


	// Object: Function Landscape.LandscapeProxy.SetLandScapeRenderMask
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x105c0f0dc
	// Params: [ Num(3) Size(0x6) ]
	void SetLandScapeRenderMask(int Index, bool bUseRenderMask, uint8_t RenderMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105BECA84
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Landscape.LandscapeProxy.EditorApplySpline
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c0edf8
	// Params: [ Num(11) Size(0x30) ]
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Landscape.LandscapeProxy.ChangeLODDistributionSettingConsoleVariable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105c0eddc
	// Params: [ Num(0) Size(0x0) ]
	void ChangeLODDistributionSettingConsoleVariable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105c0ed58
	// Params: [ Num(1) Size(0x4) ]
	void ChangeLODDistanceFactor(float InLODDistanceFactor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Landscape.LandscapeProxy.ChangeLOD0DistributionSettingConsoleVariable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105c0ed3c
	// Params: [ Num(0) Size(0x0) ]
	void ChangeLOD0DistributionSettingConsoleVariable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Landscape.LandscapeProxy.ChangebUseScreenSizeLOD
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105c0ecb0
	// Params: [ Num(1) Size(0x1) ]
	void ChangebUseScreenSizeLOD(bool InbUseScreenSizeLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class Landscape.Landscape
// Size: 0xB70 (Inherited: 0xAD0)
struct ALandscape : ALandscapeProxy
{
	uint8_t Pad_0xAD0[0xA0]; // 0xAD0(0xA0)
};

// Object: Class Landscape.SimpleMeshComponent
// Size: 0xA50 (Inherited: 0xA20)
struct USimpleMeshComponent : UMeshComponent
{
	struct TArray<struct FSimpleMeshSection> MeshSections; // 0xA20(0x10)
	struct FBoxSphereBounds LocalBounds; // 0xA30(0x1C)
	uint8_t Pad_0xA4C[0x4]; // 0xA4C(0x4)
};

// Object: Class Landscape.LandscapeComponent
// Size: 0xDE0 (Inherited: 0x9D0)
struct ULandscapeComponent : UPrimitiveComponent
{
	int SectionBaseX; // 0x9C8(0x4)
	int SectionBaseY; // 0x9CC(0x4)
	int ComponentSizeQuads; // 0x9D0(0x4)
	int SubsectionSizeQuads; // 0x9D4(0x4)
	int NumSubsections; // 0x9D8(0x4)
	uint8_t bSubSectionRenderMaskComp : 1; // 0x9DC(0x1), Mask(0x1)
	uint8_t SubSectionRenderMaskComp; // 0x9DD(0x1)
	struct UMaterialInterface* OverrideMaterial; // 0x9E0(0x8)
	struct UMaterialInterface* OverrideHoleMaterial; // 0x9E8(0x8)
	struct TMap<struct FName, struct UMaterialInterface*> OverrideOtherMaterials; // 0x9F0(0x50)
	struct FOverridePhyxMaterial OverridePhyxMaterial; // 0xA40(0x20)
	uint8_t bOverrideGrassTypes : 1; // 0xA60(0x1), Mask(0x1)
	uint8_t BitPad_0xA65_2 : 6; // 0xA65(0x1)
	uint8_t Pad_0xA66[0x2]; // 0xA66(0x2)
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // 0xA68(0x10)
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // 0xA78(0x10)
	struct TMap<struct FName, struct UMaterialInstanceConstant*> OtherMaterialInstances; // 0xA88(0x50)
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // 0xAD8(0x10)
	struct TArray<struct UTexture2D*> WeightmapTextures; // 0xAE8(0x10)
	int VisibilityLayerChannel; // 0xAF8(0x4)
	uint8_t Pad_0xAFC[0x4]; // 0xAFC(0x4)
	struct UTexture2D* XYOffsetmapTexture; // 0xB00(0x8)
	uint8_t Pad_0xB08[0x8]; // 0xB08(0x8)
	struct FVector4 WeightmapScaleBias; // 0xB10(0x10)
	float WeightmapSubsectionOffset; // 0xB20(0x4)
	uint8_t Pad_0xB24[0xC]; // 0xB24(0xC)
	struct FVector4 HeightmapScaleBias; // 0xB30(0x10)
	struct UTexture2D* HeightmapTexture; // 0xB40(0x8)
	struct TMap<struct FString, struct FVisibilityData> MultiVisibilityTextureData; // 0xB48(0x50)
	struct FString VisibleVisibilityLayer; // 0xB98(0x10)
	struct FBox CachedLocalBox; // 0xBA8(0x1C)
	uint8_t bUseCachedSectionLocalBoxs : 1; // 0xBC4(0x1), Mask(0x1)
	uint8_t BitPad_0xBC4_1 : 7; // 0xBC4(0x1)
	uint8_t Pad_0xBC5[0x3]; // 0xBC5(0x3)
	struct TArray<float> CachedSectionLocalBoxsHeight; // 0xBC8(0x10)
	struct TLazyObjectPtr<struct ULandscapeHeightfieldCollisionComponent> CollisionComponent; // 0xBD8(0x1C)
	struct FGuid MapBuildDataId; // 0xBF4(0x10)
	uint8_t Pad_0xC04[0x4]; // 0xC04(0x4)
	struct TArray<struct FGuid> IrrelevantLights; // 0xC08(0x10)
	int CollisionMipLevel; // 0xC18(0x4)
	int SimpleCollisionMipLevel; // 0xC1C(0x4)
	float NegativeZBoundsExtension; // 0xC20(0x4)
	float PositiveZBoundsExtension; // 0xC24(0x4)
	float StaticLightingResolution; // 0xC28(0x4)
	int ForcedLOD; // 0xC2C(0x4)
	int LODBias; // 0xC30(0x4)
	int MobileVertexHoleMaxLOD; // 0xC34(0x4)
	uint8_t Pad_0xC38[0x10]; // 0xC38(0x10)
	struct TArray<float> LODDeltaVertex; // 0xC48(0x10)
	float MaxDeltaVertex; // 0xC58(0x4)
	struct FGuid stateID; // 0xC5C(0x10)
	struct FGuid BakedTextureMaterialGuid; // 0xC6C(0x10)
	uint8_t Pad_0xC7C[0x4]; // 0xC7C(0x4)
	struct UTexture2D* GIBakedBaseColorTexture; // 0xC80(0x8)
	struct FString OccluderMeshDataPath; // 0xC88(0x10)
	uint8_t MobileBlendableLayerMask; // 0xC98(0x1)
	uint8_t Pad_0xC99[0x7]; // 0xC99(0x7)
	struct UMaterialInterface* MobileMaterialInterface; // 0xCA0(0x8)
	struct TMap<struct FName, struct UMaterialInterface*> OtherMobileMaterialInterfaces; // 0xCA8(0x50)
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // 0xCF8(0x10)
	struct UTexture2D* MobileWeightNormalmapTexture; // 0xD08(0x8)
	uint8_t bMobileMultiLayers : 1; // 0xD10(0x1), Mask(0x1)
	uint8_t BitPad_0xD10_1 : 7; // 0xD10(0x1)
	uint8_t Pad_0xD11[0x7]; // 0xD11(0x7)
	struct TArray<uint16_t> CachedHeightData; // 0xD18(0x10)
	bool bUseLandscapeVT; // 0xD28(0x1)
	bool bLandscapeVTNeedHeightmap; // 0xD29(0x1)
	uint8_t Pad_0xD2A[0x76]; // 0xD2A(0x76)
	bool bHasROCData; // 0xDA0(0x1)
	uint8_t Pad_0xDA1[0x1F]; // 0xDA1(0x1F)
	struct FName UsedOtherMaterialName; // 0xDC0(0x8)
	uint8_t Pad_0xDC8[0x18]; // 0xDC8(0x18)
};

// Object: Class Landscape.LandscapeGeometryAsset
// Size: 0x198 (Inherited: 0x30)
struct ULandscapeGeometryAsset : UDataAsset
{
	struct TArray<struct FVector> Vertex; // 0x30(0x10)
	struct TArray<struct FVector> Normals; // 0x40(0x10)
	struct TArray<struct FVector2D> UV; // 0x50(0x10)
	struct TArray<int> Indices; // 0x60(0x10)
	struct TMap<struct FIntPoint, int> ComponentIndexOffset; // 0x70(0x50)
	int ComponentIndexCount; // 0xC0(0x4)
	int ComponentVertexCount; // 0xC4(0x4)
	struct TMap<struct FString, struct FLevelComponentMapValue> SubLevelComponentMap; // 0xC8(0x50)
	struct UStaticMesh* HighQualityMesh; // 0x118(0x28)
	float HighQualityMeshDestroyHight; // 0x140(0x4)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
	struct TMap<struct FIntPoint, int> ComponentVertexIndexOffset; // 0x148(0x50)
};

// Object: Class Landscape.LandscapeGizmoActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct ALandscapeGizmoActor : AActor
{
};

// Object: Class Landscape.LandscapeGizmoActiveActor
// Size: 0x500 (Inherited: 0x4B0)
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor
{
	uint8_t Pad_0x4B0[0x50]; // 0x4B0(0x50)
};

// Object: Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x9D0 (Inherited: 0x9D0)
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent
{
};

// Object: Class Landscape.LandscapeGrassType
// Size: 0x58 (Inherited: 0x28)
struct ULandscapeGrassType : UObject
{
	struct TArray<struct FGrassVariety> GrassVarieties; // 0x28(0x10)
	struct UStaticMesh* GrassMesh; // 0x38(0x8)
	float GrassDensity; // 0x40(0x4)
	float PlacementJitter; // 0x44(0x4)
	int StartCullDistance; // 0x48(0x4)
	int EndCullDistance; // 0x4C(0x4)
	bool RandomRotation; // 0x50(0x1)
	bool AlignToSurface; // 0x51(0x1)
	uint8_t Pad_0x52[0x6]; // 0x52(0x6)
};

// Object: Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0xAB0 (Inherited: 0x9D0)
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent
{
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // 0x9C8(0x10)
	int SectionBaseX; // 0x9D8(0x4)
	int SectionBaseY; // 0x9DC(0x4)
	int CollisionSizeQuads; // 0x9E0(0x4)
	float CollisionScale; // 0x9E4(0x4)
	int SimpleCollisionSizeQuads; // 0x9E8(0x4)
	struct TArray<uint8_t> CollisionQuadFlags; // 0x9F0(0x10)
	struct FGuid HeightfieldGuid; // 0xA00(0x10)
	struct FBox CachedLocalBox; // 0xA10(0x1C)
	struct TLazyObjectPtr<struct ULandscapeComponent> RenderComponent; // 0xA2C(0x1C)
	uint8_t Pad_0xA4C[0xC]; // 0xA4C(0xC)
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // 0xA58(0x10)
	uint8_t Pad_0xA68[0x48]; // 0xA68(0x48)
};

// Object: Class Landscape.IdeaGrassFieldFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UIdeaGrassFieldFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureTrample
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105c0dc8c
	// Params: [ Num(1) Size(0x90) ]
	void IdeaGrassRenderForceTextureTrample(struct FIdeaGrassFieldData GrassFieldData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C11B04
	// [Call #4] RVA: 0x105BE2B4C
	// [Call #5] RVA: 0x105C11A4C
	// [Call #6] RVA: 0x105C11A4C
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x105C11A4C
	// [Call #9] RVA: 0x105C11A4C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureSkill
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105c0db8c
	// Params: [ Num(1) Size(0x90) ]
	void IdeaGrassRenderForceTextureSkill(struct FIdeaGrassFieldData GrassFieldData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C11B04
	// [Call #4] RVA: 0x105BE2B50
	// [Call #5] RVA: 0x105C11A4C
	// [Call #6] RVA: 0x105C11A4C
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x105C11A4C
	// [Call #9] RVA: 0x105C11A4C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105C11B04
	// [Call #14] RVA: 0x105BE2B4C
	// [Call #15] RVA: 0x105C11A4C
	// [Call #16] RVA: 0x105C11A4C
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x105C11A4C
	// [Call #19] RVA: 0x105C11A4C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureFade
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105c0da8c
	// Params: [ Num(1) Size(0x90) ]
	void IdeaGrassRenderForceTextureFade(struct FIdeaGrassFieldData GrassFieldData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C11B04
	// [Call #4] RVA: 0x105BE2B48
	// [Call #5] RVA: 0x105C11A4C
	// [Call #6] RVA: 0x105C11A4C
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x105C11A4C
	// [Call #9] RVA: 0x105C11A4C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105C11B04
	// [Call #14] RVA: 0x105BE2B50
	// [Call #15] RVA: 0x105C11A4C
	// [Call #16] RVA: 0x105C11A4C
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x105C11A4C
	// [Call #19] RVA: 0x105C11A4C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105c0d98c
	// Params: [ Num(1) Size(0x90) ]
	void IdeaGrassRenderForceTexture(struct FIdeaGrassFieldData GrassFieldData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C11B04
	// [Call #4] RVA: 0x105BE2B44
	// [Call #5] RVA: 0x105C11A4C
	// [Call #6] RVA: 0x105C11A4C
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x105C11A4C
	// [Call #9] RVA: 0x105C11A4C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105C11B04
	// [Call #14] RVA: 0x105BE2B48
	// [Call #15] RVA: 0x105C11A4C
	// [Call #16] RVA: 0x105C11A4C
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x105C11A4C
	// [Call #19] RVA: 0x105C11A4C
	// [Call #20] RVA: 0x106C8459C
};

// Object: Class Landscape.LandscapeInfo
// Size: 0x3F0 (Inherited: 0x28)
struct ULandscapeInfo : UObject
{
	struct TLazyObjectPtr<struct ALandscape> LandscapeActor; // 0x28(0x1C)
	struct FGuid LandscapeGuid; // 0x44(0x10)
	int ComponentSizeQuads; // 0x54(0x4)
	int SubsectionSizeQuads; // 0x58(0x4)
	int ComponentNumSubsections; // 0x5C(0x4)
	struct FVector DrawScale; // 0x60(0xC)
	uint8_t Pad_0x6C[0x244]; // 0x6C(0x244)
	struct TSet<struct ALandscapeStreamingProxy*> Proxies; // 0x2B0(0x50)
	uint8_t Pad_0x300[0xF0]; // 0x300(0xF0)
};

// Object: Class Landscape.LandscapeInfoMap
// Size: 0x80 (Inherited: 0x28)
struct ULandscapeInfoMap : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
};

// Object: Class Landscape.LandscapeLayerInfoObject
// Size: 0x50 (Inherited: 0x28)
struct ULandscapeLayerInfoObject : UObject
{
	struct FName LayerName; // 0x28(0x8)
	struct UPhysicalMaterial* PhysMaterial; // 0x30(0x8)
	float Hardness; // 0x38(0x4)
	struct FLinearColor LayerUsageDebugColor; // 0x3C(0x10)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x280 (Inherited: 0x280)
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant
{
	uint8_t bIsLayerThumbnail : 1; // 0x279(0x1), Mask(0x1)
	uint8_t bDisableTessellation : 1; // 0x279(0x1), Mask(0x2)
};

// Object: Class Landscape.LandscapeMeshCollisionComponent
// Size: 0xAC0 (Inherited: 0xAB0)
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent
{
	struct FGuid MeshGuid; // 0xAA8(0x10)
};

// Object: Class Landscape.LandscapeMeshProxyActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct ALandscapeMeshProxyActor : AActor
{
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // 0x4B0(0x8)
};

// Object: Class Landscape.LandscapeMeshProxyComponent
// Size: 0xBF0 (Inherited: 0xBD0)
struct ULandscapeMeshProxyComponent : UStaticMeshComponent
{
	struct FGuid LandscapeGuid; // 0xBC8(0x10)
	struct TArray<struct FIntPoint> ProxyComponentBases; // 0xBD8(0x10)
	uint8_t ProxyLOD; // 0xBE8(0x1)
};

// Object: Class Landscape.LandscapeSplinesComponent
// Size: 0xA00 (Inherited: 0x9D0)
struct ULandscapeSplinesComponent : UPrimitiveComponent
{
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // 0x9C8(0x10)
	struct TArray<struct ULandscapeSplineSegment*> Segments; // 0x9D8(0x10)
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // 0x9E8(0x10)
};

// Object: Class Landscape.LandscapeSplineControlPoint
// Size: 0x98 (Inherited: 0x28)
struct ULandscapeSplineControlPoint : UObject
{
	struct FVector Location; // 0x28(0xC)
	struct FRotator Rotation; // 0x34(0xC)
	float Width; // 0x40(0x4)
	float SideFalloff; // 0x44(0x4)
	float EndFalloff; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // 0x50(0x10)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0x60(0x10)
	struct FBox Bounds; // 0x70(0x1C)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
	struct UControlPointMeshComponent* LocalMeshComponent; // 0x90(0x8)
};

// Object: Class Landscape.LandscapeSplineSegment
// Size: 0xB0 (Inherited: 0x28)
struct ULandscapeSplineSegment : UObject
{
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // 0x28(0x30)
	struct FInterpCurveVector SplineInfo; // 0x58(0x18)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0x70(0x10)
	struct FBox Bounds; // 0x80(0x1C)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // 0xA0(0x10)
};

// Object: Class Landscape.LandscapeStreamingProxy
// Size: 0xAF0 (Inherited: 0xAD0)
struct ALandscapeStreamingProxy : ALandscapeProxy
{
	struct TLazyObjectPtr<struct ALandscape> LandscapeActor; // 0xAC8(0x1C)
	bool bLandscapeProxyUseSceenSizeLOD; // 0xAE4(0x1)
	uint8_t Pad_0xAED[0x3]; // 0xAED(0x3)
};

// Object: Class Landscape.MaterialExpressionLandscapeFlattenCoords
// Size: 0x98 (Inherited: 0x60)
struct UMaterialExpressionLandscapeFlattenCoords : UMaterialExpression
{
	struct FExpressionInput UVScaleBias; // 0x60(0x38)
};

// Object: Class Landscape.MaterialExpressionLandscapeFlattenTexture
// Size: 0x98 (Inherited: 0x60)
struct UMaterialExpressionLandscapeFlattenTexture : UMaterialExpression
{
	struct FExpressionInput Coordinates; // 0x60(0x38)
};

// Object: Class Landscape.MaterialExpressionLandscapeFlattenBaseColor
// Size: 0x98 (Inherited: 0x98)
struct UMaterialExpressionLandscapeFlattenBaseColor : UMaterialExpressionLandscapeFlattenTexture
{
};

// Object: Class Landscape.MaterialExpressionLandscapeFlattenNormal
// Size: 0x98 (Inherited: 0x98)
struct UMaterialExpressionLandscapeFlattenNormal : UMaterialExpressionLandscapeFlattenTexture
{
};

// Object: Class Landscape.MaterialExpressionLandscapeFlattenRSM
// Size: 0x98 (Inherited: 0x98)
struct UMaterialExpressionLandscapeFlattenRSM : UMaterialExpressionLandscapeFlattenTexture
{
};

// Object: Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x70 (Inherited: 0x60)
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput
{
	struct TArray<struct FGrassInput> GrassTypes; // 0x60(0x10)
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x80 (Inherited: 0x60)
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression
{
	struct TArray<struct FLayerBlendInput> Layers; // 0x60(0x10)
	struct FGuid ExpressionGUID; // 0x70(0x10)
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0xB0 (Inherited: 0x60)
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression
{
	enum class ETerrainCoordMappingType MappingType; // 0x60(0x1)
	enum class ELandscapeCustomizedCoordType CustomUVType; // 0x61(0x1)
	uint8_t Pad_0x62[0x6]; // 0x62(0x6)
	struct FExpressionInput MappingScaleOverride; // 0x68(0x38)
	float MappingScale; // 0xA0(0x4)
	float MappingRotation; // 0xA4(0x4)
	float MappingPanU; // 0xA8(0x4)
	float MappingPanV; // 0xAC(0x4)
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x80 (Inherited: 0x60)
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression
{
	struct FName ParameterName; // 0x60(0x8)
	float PreviewWeight; // 0x68(0x4)
	struct FGuid ExpressionGUID; // 0x6C(0x10)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0xF0 (Inherited: 0x60)
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression
{
	struct FExpressionInput LayerUsed; // 0x60(0x38)
	struct FExpressionInput LayerNotUsed; // 0x98(0x38)
	struct FName ParameterName; // 0xD0(0x8)
	uint8_t PreviewUsed : 1; // 0xD8(0x1), Mask(0x1)
	uint8_t BitPad_0xD8_1 : 7; // 0xD8(0x1)
	uint8_t Pad_0xD9[0x3]; // 0xD9(0x3)
	struct FGuid ExpressionGUID; // 0xDC(0x10)
	uint8_t Pad_0xEC[0x4]; // 0xEC(0x4)
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0xF8 (Inherited: 0x60)
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression
{
	struct FExpressionInput Base; // 0x60(0x38)
	struct FExpressionInput Layer; // 0x98(0x38)
	struct FName ParameterName; // 0xD0(0x8)
	float PreviewWeight; // 0xD8(0x4)
	struct FVector ConstBase; // 0xDC(0xC)
	struct FGuid ExpressionGUID; // 0xE8(0x10)
};

// Object: Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x70 (Inherited: 0x60)
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression
{
	struct FGuid ExpressionGUID; // 0x60(0x10)
};

