#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_ResourcePatchCfg_type.BP_STRUCT_ResourcePatchCfg_type
// Size: 0x20 (Inherited: 0x0)
struct FBP_STRUCT_ResourcePatchCfg_type
{
	struct FString Res_0_5336A20017C3AD3C6DD6CA9604AB86B3; // 0x0(0x10)
	struct FString Version_1_77115100133C471835D454DB02BD35DE; // 0x10(0x10)
};

