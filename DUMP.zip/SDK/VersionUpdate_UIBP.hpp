#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass VersionUpdate_UIBP.VersionUpdate_UIBP_C
// Size: 0x4C4 (Inherited: 0x260)
struct UVersionUpdate_UIBP_C : UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x8)
	struct UWidgetAnimation* Animation_loading; // 0x268(0x8)
	struct UButton* Button_Bulletin; // 0x270(0x8)
	struct UButton* Button_Cancel; // 0x278(0x8)
	struct UButton* Button_L; // 0x280(0x8)
	struct UButton* Button_R; // 0x288(0x8)
	struct UButton* Button_SystemNotify; // 0x290(0x8)
	struct UButton* Button_Updated; // 0x298(0x8)
	struct UCanvasPanel* CanvasPanel_Car; // 0x2A0(0x8)
	struct UCanvasPanel* CanvasPanel_CarRoot; // 0x2A8(0x8)
	struct UCanvasPanel* CanvasPanel_Details; // 0x2B0(0x8)
	struct UCanvasPanel* CanvasPanel_Item1; // 0x2B8(0x8)
	struct UCanvasPanel* CanvasPanel_Item2; // 0x2C0(0x8)
	struct UCanvasPanel* CanvasPanel_ItemGroup; // 0x2C8(0x8)
	struct UCanvasPanel* CanvasPanel_SDDL; // 0x2D0(0x8)
	struct UCanvasPanel* CanvasPanel_SSRewardItem1; // 0x2D8(0x8)
	struct UCanvasPanel* CanvasPanel_SSRewardItem2; // 0x2E0(0x8)
	struct UCanvasPanel* CanvasPanel_Video; // 0x2E8(0x8)
	struct UGridPanel* GridPanel_IPX; // 0x2F0(0x8)
	struct UGridPanel* GridPanel_NoWifiUpdated; // 0x2F8(0x8)
	struct UGridPanel* GridPanel_UpdateUI; // 0x300(0x8)
	struct UGridPanel* GridPanel_WifiUpdated; // 0x308(0x8)
	struct UHorizontalBox* HorizontalBox_VersionSizeInfo; // 0x310(0x8)
	struct UImage* Image_0; // 0x318(0x8)
	struct UImage* Image_bg; // 0x320(0x8)
	struct UImage* Image_Car; // 0x328(0x8)
	struct UImage* image_L; // 0x330(0x8)
	struct UImage* Image_LoginBG; // 0x338(0x8)
	struct UImage* Image_SSRewardItem1; // 0x340(0x8)
	struct UImage* Image_SSRewardItem2; // 0x348(0x8)
	struct UImage* Image_SSRewardQuality1; // 0x350(0x8)
	struct UImage* Image_SSRewardQuality2; // 0x358(0x8)
	struct UImage* Image_Yan01; // 0x360(0x8)
	struct UImage* Image_Yan02; // 0x368(0x8)
	struct UImage* MediaContainer; // 0x370(0x8)
	struct UProgressBar* ProgressBar_Update; // 0x378(0x8)
	struct UTextBlock* RewardItemCount1; // 0x380(0x8)
	struct UTextBlock* RewardItemCount2; // 0x388(0x8)
	struct UTextBlock* RichText_LoadingTip; // 0x390(0x8)
	struct USizeBox* SizeBox_Bulletin; // 0x398(0x8)
	struct UTextBlock* TextBlock_0; // 0x3A0(0x8)
	struct UTextBlock* TextBlock_1; // 0x3A8(0x8)
	struct UTextBlock* TextBlock_5; // 0x3B0(0x8)
	struct UTextBlock* TextBlock_7; // 0x3B8(0x8)
	struct UTextBlock* TextBlock_10; // 0x3C0(0x8)
	struct UTextBlock* TextBlock_Bulletin; // 0x3C8(0x8)
	struct UTextBlock* TextBlock_Current; // 0x3D0(0x8)
	struct UTextBlock* TextBlock_SDDLSpeed; // 0x3D8(0x8)
	struct UTextBlock* TextBlock_SDDLTips; // 0x3E0(0x8)
	struct UTextBlock* TextBlock_SDLoading; // 0x3E8(0x8)
	struct UTextBlock* TextBlock_SDProportion; // 0x3F0(0x8)
	struct UTextBlock* TextBlock_SysNotify; // 0x3F8(0x8)
	struct UUTRichTextBlock* UpdateTips; // 0x400(0x8)
	struct UUTRichTextBlock* UpdateTips2; // 0x408(0x8)
	struct UUTRichTextBlock* UpdateTips3; // 0x410(0x8)
	struct UVerticalBox* VerticalBox_autoHide_3; // 0x418(0x8)
	struct UVerticalBox* VerticalBox_UpdateInfo; // 0x420(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Down; // 0x428(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Up; // 0x430(0x8)
	int CurBgIndex; // 0x438(0x4)
	uint8_t Pad_0x43C[0x4]; // 0x43C(0x4)
	struct TArray<struct FString> BgPaths; // 0x440(0x10)
	struct TArray<struct FString> MiddlePicPaths; // 0x450(0x10)
	struct TArray<int> LocalizeStrIndex; // 0x460(0x10)
	int AverageDownloadedSize; // 0x470(0x4)
	uint8_t Pad_0x474[0x4]; // 0x474(0x4)
	struct TArray<struct FString> CDNPicPaths; // 0x478(0x10)
	int CDNDownloadIndex; // 0x488(0x4)
	uint8_t Pad_0x48C[0x4]; // 0x48C(0x4)
	struct FString TempDownloadUrl; // 0x490(0x10)
	struct FString TempShowUrl; // 0x4A0(0x10)
	struct TArray<struct FString> CDNTitleArray; // 0x4B0(0x10)
	int AlreadyDownloadCount; // 0x4C0(0x4)


	// Object: Function VersionUpdate_UIBP.VersionUpdate_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function VersionUpdate_UIBP.VersionUpdate_UIBP_C.ExecuteUbergraph_VersionUpdate_UIBP
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_VersionUpdate_UIBP(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

