#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehiclePropsBPTable_type.BP_STRUCT_VehiclePropsBPTable_type
// Size: 0x28 (Inherited: 0x0)
struct FBP_STRUCT_VehiclePropsBPTable_type
{
	struct FString Path_0_4EDAFC402F5F7A8148151E1F0E26A1A8; // 0x0(0x10)
	int ID_1_788B5C402A5D724740AE2C51090E2714; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString CName_2_3B11AA00669A1BB25698D87D027CD8D5; // 0x18(0x10)
};

