#pragma once

#include <cstdint>

// Object: Enum GeneralNode.EGNActionState
enum class EGNActionState : uint8_t
{
	Uninitialized = 0,
	DelayRun = 1,
	Running = 2,
	Finished = 3,
	EGNActionState_MAX = 4
};

// Object: Enum GeneralNode.EGNRunRole
enum class EGNRunRole : uint8_t
{
	All = 0,
	Authority = 1,
	Autonomous = 2,
	Simulated = 3,
	AutonomousSimulated = 4,
	AutonomousAuthority = 5,
	AuthoritySimulated = 6,
	EGNRunRole_MAX = 7
};

// Object: ScriptStruct GeneralNode.GNMultiSharedDelegateWrap
// Size: 0x18 (Inherited: 0x0)
struct FGNMultiSharedDelegateWrap
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UObject* Outer; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
};

// Object: ScriptStruct GeneralNode.GNSharedDelegateWrap
// Size: 0x18 (Inherited: 0x0)
struct FGNSharedDelegateWrap
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UObject* Outer; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
};

// Object: ScriptStruct GeneralNode.GNUniqueInstancedNodeKey
// Size: 0x10 (Inherited: 0x0)
struct FGNUniqueInstancedNodeKey
{
	struct UObject* Object; // 0x0(0x8)
	struct FName Key; // 0x8(0x8)
};

// Object: ScriptStruct GeneralNode.GNComponentPicker
// Size: 0x10 (Inherited: 0x0)
struct FGNComponentPicker
{
	struct UActorComponent* ComponentClass; // 0x0(0x8)
	struct FName ComponentTag; // 0x8(0x8)
};

// Object: ScriptStruct GeneralNode.GNActionRunData
// Size: 0x48 (Inherited: 0x0)
struct FGNActionRunData
{
	struct UGNAction* Action; // 0x0(0x8)
	struct TArray<struct UGNCondition*> Conditions; // 0x8(0x10)
	struct TArray<struct UGNTargetPicker*> TargetPickers; // 0x18(0x10)
	struct TArray<struct UGNTargetFilter*> TargetFilters; // 0x28(0x10)
	struct FGNContext Context; // 0x38(0x10)
};

// Object: ScriptStruct GeneralNode.GNContext
// Size: 0x10 (Inherited: 0x0)
struct FGNContext
{
	struct AActor* Owner; // 0x0(0x8)
	struct UObject* SourceObject; // 0x8(0x8)
};

// Object: ScriptStruct GeneralNode.GNActionInstance
// Size: 0x68 (Inherited: 0x0)
struct FGNActionInstance
{
	struct UGNAction* Action; // 0x0(0x8)
	struct FGNContext Context; // 0x8(0x10)
	struct FGNTargetContext TargetContext; // 0x18(0x20)
	uint8_t Pad_0x38[0x30]; // 0x38(0x30)
};

// Object: ScriptStruct GeneralNode.GNTargetContext
// Size: 0x20 (Inherited: 0x0)
struct FGNTargetContext
{
	struct TArray<struct UObject*> Targets; // 0x0(0x10)
	struct TArray<struct FVector> TargetLocations; // 0x10(0x10)
};

// Object: Class GeneralNode.GNNode
// Size: 0x28 (Inherited: 0x28)
struct UGNNode : UObject
{
};

// Object: Class GeneralNode.GNAction
// Size: 0x48 (Inherited: 0x28)
struct UGNAction : UGNNode
{
	uint8_t RunRole; // 0x28(0x1)
	bool bActionCanUndo; // 0x29(0x1)
	bool bNeedTick; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x1]; // 0x2B(0x1)
	float TickInterval; // 0x2C(0x4)
	bool bTargetOwnerIfNoTarget; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	float RunDelay; // 0x34(0x4)
	bool bNeedUndoOnEnd; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	float ActionDuration; // 0x3C(0x4)
	uint8_t Pad_0x40[0x8]; // 0x40(0x8)
};

// Object: Class GeneralNode.GNCondition
// Size: 0x28 (Inherited: 0x28)
struct UGNCondition : UGNNode
{
};

// Object: Class GeneralNode.GNSharedDelegate
// Size: 0x40 (Inherited: 0x28)
struct UGNSharedDelegate : UObject
{
	struct UObject* FunctionOuter; // 0x28(0x8)
	struct FName FunctionName; // 0x30(0x8)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)


	// Object: Function GeneralNode.GNSharedDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a3c924
	// Params: [ Num(0) Size(0x0) ]
	void EventTrigger();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102A3C3B8
	// [Call #5] RVA: 0x105184F34
	// [Call #6] RVA: 0x105190648
	// [Call #7] RVA: 0x1036A6C08
	// [Call #8] RVA: 0x105190870
};

// Object: Class GeneralNode.GNSubsystem
// Size: 0x210 (Inherited: 0x30)
struct UGNSubsystem : UBattleSubsystem
{
	struct TMap<struct UGNNode*, struct UGNNode*> InstancedNodes; // 0x30(0x50)
	struct TMap<struct FGNUniqueInstancedNodeKey, struct UGNNode*> UniqueInstancedNodes; // 0x80(0x50)
	struct TMap<int, struct FGNActionInstance> ActionInstances; // 0xD0(0x50)
	struct TMap<struct FGNSharedDelegateWrap, struct UGNSharedDelegate*> DelegateMap; // 0x120(0x50)
	struct TMap<struct FGNMultiSharedDelegateWrap, struct UGNSharedDelegate*> MultiDelegateMap; // 0x170(0x50)
	uint8_t Pad_0x1C0[0x50]; // 0x1C0(0x50)
};

// Object: Class GeneralNode.GNTargetFilter
// Size: 0x28 (Inherited: 0x28)
struct UGNTargetFilter : UGNNode
{
};

// Object: Class GeneralNode.GNTargetPicker
// Size: 0x28 (Inherited: 0x28)
struct UGNTargetPicker : UGNNode
{
};

