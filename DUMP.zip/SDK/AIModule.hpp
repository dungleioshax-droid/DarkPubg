#pragma once

#include <cstdint>

// Object: Enum AIModule.EPathFollowingResult
enum class EPathFollowingResult : uint8_t
{
	Success = 0,
	Blocked = 1,
	OffPath = 2,
	Aborted = 3,
	Skipped_DEPRECATED = 4,
	Invalid = 5,
	EPathFollowingResult_MAX = 6
};

// Object: Enum AIModule.EEnvQueryStatus
enum class EEnvQueryStatus : uint8_t
{
	Processing = 0,
	Success = 1,
	Failed = 2,
	Aborted = 3,
	OwnerLost = 4,
	MissingParam = 5,
	EEnvQueryStatus_MAX = 6
};

// Object: Enum AIModule.EPathFollowingStatus
enum class EPathFollowingStatus : uint8_t
{
	Idle = 0,
	Waiting = 1,
	Paused = 2,
	Moving = 3,
	EPathFollowingStatus_MAX = 4
};

// Object: Enum AIModule.EPathFollowingRequestResult
enum class EPathFollowingRequestResult : uint8_t
{
	Failed = 0,
	AlreadyAtGoal = 1,
	RequestSuccessful = 2,
	EPathFollowingRequestResult_MAX = 3
};

// Object: Enum AIModule.EAISenseNotifyType
enum class EAISenseNotifyType : uint8_t
{
	OnEveryPerception = 0,
	OnPerceptionChange = 1,
	EAISenseNotifyType_MAX = 2
};

// Object: Enum AIModule.EAITaskPriority
enum class EAITaskPriority : uint8_t
{
	Lowest = 0,
	Low = 64,
	AutonomousAI = 127,
	High = 192,
	Ultimate = 254,
	EAITaskPriority_MAX = 255
};

// Object: Enum AIModule.EGenericAICheck
enum class EGenericAICheck : uint8_t
{
	Less = 0,
	LessOrEqual = 1,
	Equal = 2,
	NotEqual = 3,
	GreaterOrEqual = 4,
	Greater = 5,
	IsTrue = 6,
	MAX = 7
};

// Object: Enum AIModule.EAILockSource
enum class EAILockSource : uint8_t
{
	Animation = 0,
	Logic = 1,
	Script = 2,
	Gameplay = 3,
	MAX = 4
};

// Object: Enum AIModule.EAIRequestPriority
enum class EAIRequestPriority : uint8_t
{
	SoftScript = 0,
	Logic = 1,
	HardScript = 2,
	Reaction = 3,
	Ultimate = 4,
	MAX = 5
};

// Object: Enum AIModule.EPawnActionEventType
enum class EPawnActionEventType : uint8_t
{
	Invalid = 0,
	FailedToStart = 1,
	InstantAbort = 2,
	FinishedAborting = 3,
	FinishedExecution = 4,
	Push = 5,
	EPawnActionEventType_MAX = 6
};

// Object: Enum AIModule.EPawnActionResult
enum class EPawnActionResult : uint8_t
{
	NotStarted = 0,
	InProgress = 1,
	Success = 2,
	Failed = 3,
	Aborted = 4,
	EPawnActionResult_MAX = 5
};

// Object: Enum AIModule.EPawnActionAbortState
enum class EPawnActionAbortState : uint8_t
{
	NeverStarted = 0,
	NotBeingAborted = 1,
	MarkPendingAbort = 2,
	LatentAbortInProgress = 3,
	AbortDone = 4,
	MAX = 5
};

// Object: Enum AIModule.FAIDistanceType
enum class EFAIDistanceType : uint8_t
{
	Distance3D = 0,
	Distance2D = 1,
	DistanceZ = 2,
	MAX = 3
};

// Object: Enum AIModule.EAIOptionFlag
enum class EAIOptionFlag : uint8_t
{
	Default = 0,
	Enable = 1,
	Disable = 2,
	MAX = 3
};

// Object: Enum AIModule.EBTFlowAbortMode
enum class EBTFlowAbortMode : uint8_t
{
	None = 0,
	LowerPriority = 1,
	Self = 2,
	Both = 3,
	EBTFlowAbortMode_MAX = 4
};

// Object: Enum AIModule.EBTNodeResult
enum class EBTNodeResult : uint8_t
{
	Succeeded = 0,
	Failed = 1,
	Aborted = 2,
	InProgress = 3,
	EBTNodeResult_MAX = 4
};

// Object: Enum AIModule.ETextKeyOperation
enum class ETextKeyOperation : uint8_t
{
	Equal = 0,
	NotEqual = 1,
	Contain = 2,
	NotContain = 3,
	ETextKeyOperation_MAX = 4
};

// Object: Enum AIModule.EArithmeticKeyOperation
enum class EArithmeticKeyOperation : uint8_t
{
	Equal = 0,
	NotEqual = 1,
	Less = 2,
	LessOrEqual = 3,
	Greater = 4,
	GreaterOrEqual = 5,
	EArithmeticKeyOperation_MAX = 6
};

// Object: Enum AIModule.EBasicKeyOperation
enum class EBasicKeyOperation : uint8_t
{
	Set = 0,
	NotSet = 1,
	EBasicKeyOperation_MAX = 2
};

// Object: Enum AIModule.EBTParallelMode
enum class EBTParallelMode : uint8_t
{
	AbortBackground = 0,
	WaitForBackground = 1,
	EBTParallelMode_MAX = 2
};

// Object: Enum AIModule.EBTDecoratorLogic
enum class EBTDecoratorLogic : uint8_t
{
	Invalid = 0,
	Test = 1,
	And = 2,
	Or = 3,
	Not = 4,
	EBTDecoratorLogic_MAX = 5
};

// Object: Enum AIModule.EBTChildIndex
enum class EBTChildIndex : uint8_t
{
	FirstNode = 0,
	TaskNode = 1,
	EBTChildIndex_MAX = 2
};

// Object: Enum AIModule.EBTBlackboardRestart
enum class EBTBlackboardRestart : uint8_t
{
	ValueChange = 0,
	ResultChange = 1,
	EBTBlackboardRestart_MAX = 2
};

// Object: Enum AIModule.EBlackBoardEntryComparison
enum class EBlackBoardEntryComparison : uint8_t
{
	Equal = 0,
	NotEqual = 1,
	EBlackBoardEntryComparison_MAX = 2
};

// Object: Enum AIModule.EPathExistanceQueryType
enum class EPathExistanceQueryType : uint8_t
{
	NavmeshRaycast2D = 0,
	HierarchicalQuery = 1,
	RegularPathFinding = 2,
	EPathExistanceQueryType_MAX = 3
};

// Object: Enum AIModule.EPointOnCircleSpacingMethod
enum class EPointOnCircleSpacingMethod : uint8_t
{
	BySpaceBetween = 0,
	ByNumberOfPoints = 1,
	EPointOnCircleSpacingMethod_MAX = 2
};

// Object: Enum AIModule.EEQSNormalizationType
enum class EEQSNormalizationType : uint8_t
{
	Absolute = 0,
	RelativeToScores = 1,
	EEQSNormalizationType_MAX = 2
};

// Object: Enum AIModule.EEnvTestDistance
enum class EEnvTestDistance : uint8_t
{
	Distance3D = 0,
	Distance2D = 1,
	DistanceZ = 2,
	DistanceAbsoluteZ = 3,
	EEnvTestDistance_MAX = 4
};

// Object: Enum AIModule.EEnvTestDot
enum class EEnvTestDot : uint8_t
{
	Dot3D = 0,
	Dot2D = 1,
	EEnvTestDot_MAX = 2
};

// Object: Enum AIModule.EEnvTestPathfinding
enum class EEnvTestPathfinding : uint8_t
{
	PathExist = 0,
	PathCost = 1,
	PathLength = 2,
	EEnvTestPathfinding_MAX = 3
};

// Object: Enum AIModule.EEnvQueryTestClamping
enum class EEnvQueryTestClamping : uint8_t
{
	None = 0,
	SpecifiedValue = 1,
	FilterThreshold = 2,
	EEnvQueryTestClamping_MAX = 3
};

// Object: Enum AIModule.EEnvDirection
enum class EEnvDirection : uint8_t
{
	TwoPoints = 0,
	Rotation = 1,
	EEnvDirection_MAX = 2
};

// Object: Enum AIModule.EEnvOverlapShape
enum class EEnvOverlapShape : uint8_t
{
	Box = 0,
	Sphere = 1,
	Capsule = 2,
	EEnvOverlapShape_MAX = 3
};

// Object: Enum AIModule.EEnvTraceShape
enum class EEnvTraceShape : uint8_t
{
	Line = 0,
	Box = 1,
	Sphere = 2,
	Capsule = 3,
	EEnvTraceShape_MAX = 4
};

// Object: Enum AIModule.EEnvQueryTrace
enum class EEnvQueryTrace : uint8_t
{
	None = 0,
	Navigation = 1,
	Geometry = 2,
	NavigationOverLedges = 3,
	EEnvQueryTrace_MAX = 4
};

// Object: Enum AIModule.EAIParamType
enum class EAIParamType : uint8_t
{
	Float = 0,
	Int = 1,
	Bool = 2,
	MAX = 3
};

// Object: Enum AIModule.EEnvQueryParam
enum class EEnvQueryParam : uint8_t
{
	Float = 0,
	Int = 1,
	Bool = 2,
	EEnvQueryParam_MAX = 3
};

// Object: Enum AIModule.EEnvQueryRunMode
enum class EEnvQueryRunMode : uint8_t
{
	SingleResult = 0,
	RandomBest5Pct = 1,
	RandomBest25Pct = 2,
	AllMatching = 3,
	EEnvQueryRunMode_MAX = 4
};

// Object: Enum AIModule.EEnvTestScoreOperator
enum class EEnvTestScoreOperator : uint8_t
{
	AverageScore = 0,
	MinScore = 1,
	MaxScore = 2,
	EEnvTestScoreOperator_MAX = 3
};

// Object: Enum AIModule.EEnvTestFilterOperator
enum class EEnvTestFilterOperator : uint8_t
{
	AllPass = 0,
	AnyPass = 1,
	EEnvTestFilterOperator_MAX = 2
};

// Object: Enum AIModule.EEnvTestCost
enum class EEnvTestCost : uint8_t
{
	Low = 0,
	Medium = 1,
	High = 2,
	EEnvTestCost_MAX = 3
};

// Object: Enum AIModule.EEnvTestWeight
enum class EEnvTestWeight : uint8_t
{
	None = 0,
	Square = 1,
	Inverse = 2,
	Unused = 3,
	Constant = 4,
	Skip = 5,
	EEnvTestWeight_MAX = 6
};

// Object: Enum AIModule.EEnvTestScoreEquation
enum class EEnvTestScoreEquation : uint8_t
{
	Linear = 0,
	Square = 1,
	InverseLinear = 2,
	SquareRoot = 3,
	Constant = 4,
	EEnvTestScoreEquation_MAX = 5
};

// Object: Enum AIModule.EEnvTestFilterType
enum class EEnvTestFilterType : uint8_t
{
	Minimum = 0,
	Maximum = 1,
	Range = 2,
	Match = 3,
	EEnvTestFilterType_MAX = 4
};

// Object: Enum AIModule.EEnvTestPurpose
enum class EEnvTestPurpose : uint8_t
{
	Filter = 0,
	Score = 1,
	FilterAndScore = 2,
	EEnvTestPurpose_MAX = 3
};

// Object: Enum AIModule.EEnvQueryHightlightMode
enum class EEnvQueryHightlightMode : uint8_t
{
	All = 0,
	Best5Pct = 1,
	Best25Pct = 2,
	EEnvQueryHightlightMode_MAX = 3
};

// Object: Enum AIModule.ETeamAttitude
enum class ETeamAttitude : uint8_t
{
	Friendly = 0,
	Neutral = 1,
	Hostile = 2,
	ETeamAttitude_MAX = 3
};

// Object: Enum AIModule.EPathFollowingAction
enum class EPathFollowingAction : uint8_t
{
	Error = 0,
	NoMove = 1,
	DirectMove = 2,
	PartialPath = 3,
	PathToGoal = 4,
	EPathFollowingAction_MAX = 5
};

// Object: Enum AIModule.EPawnActionFailHandling
enum class EPawnActionFailHandling : uint8_t
{
	RequireSuccess = 0,
	IgnoreFailure = 1,
	EPawnActionFailHandling_MAX = 2
};

// Object: Enum AIModule.EPawnSubActionTriggeringPolicy
enum class EPawnSubActionTriggeringPolicy : uint8_t
{
	CopyBeforeTriggering = 0,
	ReuseInstances = 1,
	EPawnSubActionTriggeringPolicy_MAX = 2
};

// Object: Enum AIModule.EPawnActionMoveMode
enum class EPawnActionMoveMode : uint8_t
{
	UsePathfinding = 0,
	StraightLine = 1,
	EPawnActionMoveMode_MAX = 2
};

// Object: ScriptStruct AIModule.AIRequestID
// Size: 0x4 (Inherited: 0x0)
struct FAIRequestID
{
	uint32_t RequestID; // 0x0(0x4)
};

// Object: ScriptStruct AIModule.AIStimulus
// Size: 0x60 (Inherited: 0x0)
struct FAIStimulus
{
	float Age; // 0x0(0x4)
	float ExpirationAge; // 0x4(0x4)
	float Strength; // 0x8(0x4)
	struct FVector StimulusLocation; // 0xC(0xC)
	struct FVector ReceiverLocation; // 0x18(0xC)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FName Tag; // 0x28(0x8)
	uint8_t Pad_0x30[0x10]; // 0x30(0x10)
	int iExtraData_0; // 0x40(0x4)
	int iExtraData_1; // 0x44(0x4)
	int iExtraData_2; // 0x48(0x4)
	float fExtraData_0; // 0x4C(0x4)
	float fExtraData_1; // 0x50(0x4)
	float fExtraData_2; // 0x54(0x4)
	uint8_t BitPad_0x58_0 : 1; // 0x58(0x1)
	uint8_t bSuccessfullySensed : 1; // 0x58(0x1), Mask(0x2)
	uint8_t BitPad_0x58_2 : 6; // 0x58(0x1)
	uint8_t Pad_0x59[0x7]; // 0x59(0x7)
};

// Object: ScriptStruct AIModule.BlackboardKeySelector
// Size: 0x28 (Inherited: 0x0)
struct FBlackboardKeySelector
{
	struct TArray<struct UBlackboardKeyType*> AllowedTypes; // 0x0(0x10)
	struct FName SelectedKeyName; // 0x10(0x8)
	struct UBlackboardKeyType* SelectedKeyType; // 0x18(0x8)
	uint8_t SelectedKeyID; // 0x20(0x1)
	uint8_t bNoneIsAllowedValue : 1; // 0x21(0x1), Mask(0x1)
	uint8_t BitPad_0x21_1 : 7; // 0x21(0x1)
	uint8_t Pad_0x22[0x6]; // 0x22(0x6)
};

// Object: ScriptStruct AIModule.AIDataProviderValue
// Size: 0x20 (Inherited: 0x0)
struct FAIDataProviderValue
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UProperty* CachedProperty; // 0x8(0x8)
	struct UAIDataProvider* DataBinding; // 0x10(0x8)
	struct FName DataField; // 0x18(0x8)
};

// Object: ScriptStruct AIModule.AIDataProviderTypedValue
// Size: 0x28 (Inherited: 0x20)
struct FAIDataProviderTypedValue : FAIDataProviderValue
{
	struct UProperty* PropertyType; // 0x20(0x8)
};

// Object: ScriptStruct AIModule.AIDataProviderBoolValue
// Size: 0x30 (Inherited: 0x28)
struct FAIDataProviderBoolValue : FAIDataProviderTypedValue
{
	bool DefaultValue; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: ScriptStruct AIModule.AIDataProviderFloatValue
// Size: 0x30 (Inherited: 0x28)
struct FAIDataProviderFloatValue : FAIDataProviderTypedValue
{
	float DefaultValue; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AIModule.AIDataProviderIntValue
// Size: 0x30 (Inherited: 0x28)
struct FAIDataProviderIntValue : FAIDataProviderTypedValue
{
	int DefaultValue; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AIModule.AIDataProviderStructValue
// Size: 0x30 (Inherited: 0x20)
struct FAIDataProviderStructValue : FAIDataProviderValue
{
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
};

// Object: ScriptStruct AIModule.ActorPerceptionBlueprintInfo
// Size: 0x20 (Inherited: 0x0)
struct FActorPerceptionBlueprintInfo
{
	struct AActor* Target; // 0x0(0x8)
	struct TArray<struct FAIStimulus> LastSensedStimuli; // 0x8(0x10)
	uint8_t bIsHostile : 1; // 0x18(0x1), Mask(0x1)
	uint8_t BitPad_0x18_1 : 7; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct AIModule.AISenseAffiliationFilter
// Size: 0x4 (Inherited: 0x0)
struct FAISenseAffiliationFilter
{
	uint8_t bDetectEnemies : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bDetectNeutrals : 1; // 0x0(0x1), Mask(0x2)
	uint8_t bDetectFriendlies : 1; // 0x0(0x1), Mask(0x4)
	uint8_t BitPad_0x0_3 : 5; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
};

// Object: ScriptStruct AIModule.AIDamageEvent
// Size: 0x30 (Inherited: 0x0)
struct FAIDamageEvent
{
	float Amount; // 0x0(0x4)
	struct FVector Location; // 0x4(0xC)
	struct FVector HitLocation; // 0x10(0xC)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct AActor* DamagedActor; // 0x20(0x8)
	struct AActor* Instigator; // 0x28(0x8)
};

// Object: ScriptStruct AIModule.AINoiseEvent
// Size: 0x30 (Inherited: 0x0)
struct FAINoiseEvent
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	struct FVector NoiseLocation; // 0x4(0xC)
	float Loudness; // 0x10(0x4)
	float MaxRange; // 0x14(0x4)
	struct AActor* Instigator; // 0x18(0x8)
	struct FName Tag; // 0x20(0x8)
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: ScriptStruct AIModule.AIPredictionEvent
// Size: 0x18 (Inherited: 0x0)
struct FAIPredictionEvent
{
	struct AActor* Requestor; // 0x0(0x8)
	struct AActor* PredictedActor; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
};

// Object: ScriptStruct AIModule.AISightEvent
// Size: 0x18 (Inherited: 0x0)
struct FAISightEvent
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct AActor* SeenActor; // 0x8(0x8)
	struct AActor* Observer; // 0x10(0x8)
};

// Object: ScriptStruct AIModule.AITeamStimulusEvent
// Size: 0x38 (Inherited: 0x0)
struct FAITeamStimulusEvent
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
	struct AActor* Broadcaster; // 0x28(0x8)
	struct AActor* Enemy; // 0x30(0x8)
};

// Object: ScriptStruct AIModule.AITouchEvent
// Size: 0x20 (Inherited: 0x0)
struct FAITouchEvent
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
	struct AActor* TouchReceiver; // 0x10(0x8)
	struct AActor* OtherActor; // 0x18(0x8)
};

// Object: ScriptStruct AIModule.AIMoveRequest
// Size: 0x40 (Inherited: 0x0)
struct FAIMoveRequest
{
	struct AActor* GoalActor; // 0x0(0x8)
	uint8_t Pad_0x8[0x38]; // 0x8(0x38)
};

// Object: ScriptStruct AIModule.BehaviorTreeTemplateInfo
// Size: 0x18 (Inherited: 0x0)
struct FBehaviorTreeTemplateInfo
{
	struct UBehaviorTree* Asset; // 0x0(0x8)
	struct UBTCompositeNode* Template; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
};

// Object: ScriptStruct AIModule.BlackboardEntry
// Size: 0x18 (Inherited: 0x0)
struct FBlackboardEntry
{
	struct FName EntryName; // 0x0(0x8)
	struct UBlackboardKeyType* KeyType; // 0x8(0x8)
	uint8_t bInstanceSynced : 1; // 0x10(0x1), Mask(0x1)
	uint8_t BitPad_0x10_1 : 7; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct AIModule.BTCompositeChild
// Size: 0x30 (Inherited: 0x0)
struct FBTCompositeChild
{
	struct UBTCompositeNode* ChildComposite; // 0x0(0x8)
	struct UBTTaskNode* ChildTask; // 0x8(0x8)
	struct TArray<struct UBTDecorator*> Decorators; // 0x10(0x10)
	struct TArray<struct FBTDecoratorLogic> DecoratorOps; // 0x20(0x10)
};

// Object: ScriptStruct AIModule.BTDecoratorLogic
// Size: 0x4 (Inherited: 0x0)
struct FBTDecoratorLogic
{
	enum class EBTDecoratorLogic Operation; // 0x0(0x1)
	uint8_t Pad_0x1[0x1]; // 0x1(0x1)
	uint16_t Number; // 0x2(0x2)
};

// Object: ScriptStruct AIModule.CrowdAvoidanceSamplingPattern
// Size: 0x20 (Inherited: 0x0)
struct FCrowdAvoidanceSamplingPattern
{
	struct TArray<float> Angles; // 0x0(0x10)
	struct TArray<float> Radii; // 0x10(0x10)
};

// Object: ScriptStruct AIModule.CrowdAvoidanceConfig
// Size: 0x1C (Inherited: 0x0)
struct FCrowdAvoidanceConfig
{
	float VelocityBias; // 0x0(0x4)
	float DesiredVelocityWeight; // 0x4(0x4)
	float CurrentVelocityWeight; // 0x8(0x4)
	float SideBiasWeight; // 0xC(0x4)
	float ImpactTimeWeight; // 0x10(0x4)
	float ImpactTimeRange; // 0x14(0x4)
	uint8_t CustomPatternIdx; // 0x18(0x1)
	uint8_t AdaptiveDivisions; // 0x19(0x1)
	uint8_t AdaptiveRings; // 0x1A(0x1)
	uint8_t AdaptiveDepth; // 0x1B(0x1)
};

// Object: ScriptStruct AIModule.EnvQueryInstanceCache
// Size: 0x178 (Inherited: 0x0)
struct FEnvQueryInstanceCache
{
	struct UEnvQuery* Template; // 0x0(0x8)
	uint8_t Pad_0x8[0x170]; // 0x8(0x170)
};

// Object: ScriptStruct AIModule.EnvQueryRequest
// Size: 0x68 (Inherited: 0x0)
struct FEnvQueryRequest
{
	struct UEnvQuery* QueryTemplate; // 0x0(0x8)
	struct UObject* Owner; // 0x8(0x8)
	struct UWorld* World; // 0x10(0x8)
	uint8_t Pad_0x18[0x50]; // 0x18(0x50)
};

// Object: ScriptStruct AIModule.EQSParametrizedQueryExecutionRequest
// Size: 0x48 (Inherited: 0x0)
struct FEQSParametrizedQueryExecutionRequest
{
	struct UEnvQuery* QueryTemplate; // 0x0(0x8)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x8(0x10)
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0x18(0x28)
	enum class EEnvQueryRunMode RunMode; // 0x40(0x1)
	uint8_t bUseBBKeyForQueryTemplate : 1; // 0x41(0x1), Mask(0x1)
	uint8_t BitPad_0x41_1 : 7; // 0x41(0x1)
	uint8_t Pad_0x42[0x6]; // 0x42(0x6)
};

// Object: ScriptStruct AIModule.AIDynamicParam
// Size: 0x38 (Inherited: 0x0)
struct FAIDynamicParam
{
	struct FName ParamName; // 0x0(0x8)
	uint8_t ParamType; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float Value; // 0xC(0x4)
	struct FBlackboardKeySelector BBKey; // 0x10(0x28)
};

// Object: ScriptStruct AIModule.EnvQueryResult
// Size: 0x40 (Inherited: 0x0)
struct FEnvQueryResult
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
	struct UEnvQueryItemType* itemType; // 0x10(0x8)
	uint8_t Pad_0x18[0x14]; // 0x18(0x14)
	int OptionIndex; // 0x2C(0x4)
	int QueryID; // 0x30(0x4)
	uint8_t Pad_0x34[0xC]; // 0x34(0xC)
};

// Object: ScriptStruct AIModule.EnvOverlapData
// Size: 0x1C (Inherited: 0x0)
struct FEnvOverlapData
{
	float ExtentX; // 0x0(0x4)
	float ExtentY; // 0x4(0x4)
	float ExtentZ; // 0x8(0x4)
	struct FVector ShapeOffset; // 0xC(0xC)
	enum class ECollisionChannel OverlapChannel; // 0x18(0x1)
	enum class EEnvOverlapShape OverlapShape; // 0x19(0x1)
	uint8_t bOnlyBlockingHits : 1; // 0x1A(0x1), Mask(0x1)
	uint8_t bOverlapComplex : 1; // 0x1A(0x1), Mask(0x2)
	uint8_t BitPad_0x1A_2 : 6; // 0x1A(0x1)
	uint8_t Pad_0x1B[0x1]; // 0x1B(0x1)
};

// Object: ScriptStruct AIModule.EnvTraceData
// Size: 0x30 (Inherited: 0x0)
struct FEnvTraceData
{
	int VersionNum; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UNavigationQueryFilter* NavigationFilter; // 0x8(0x8)
	float ProjectDown; // 0x10(0x4)
	float ProjectUp; // 0x14(0x4)
	float ExtentX; // 0x18(0x4)
	float ExtentY; // 0x1C(0x4)
	float ExtentZ; // 0x20(0x4)
	float PostProjectionVerticalOffset; // 0x24(0x4)
	enum class ETraceTypeQuery TraceChannel; // 0x28(0x1)
	enum class ECollisionChannel SerializedChannel; // 0x29(0x1)
	enum class EEnvTraceShape TraceShape; // 0x2A(0x1)
	enum class EEnvQueryTrace TraceMode; // 0x2B(0x1)
	uint8_t bTraceComplex : 1; // 0x2C(0x1), Mask(0x1)
	uint8_t bOnlyBlockingHits : 1; // 0x2C(0x1), Mask(0x2)
	uint8_t bCanTraceOnNavMesh : 1; // 0x2C(0x1), Mask(0x4)
	uint8_t bCanTraceOnGeometry : 1; // 0x2C(0x1), Mask(0x8)
	uint8_t bCanDisableTrace : 1; // 0x2C(0x1), Mask(0x10)
	uint8_t bCanProjectDown : 1; // 0x2C(0x1), Mask(0x20)
	uint8_t BitPad_0x2C_6 : 2; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
};

// Object: ScriptStruct AIModule.EnvDirection
// Size: 0x20 (Inherited: 0x0)
struct FEnvDirection
{
	struct UEnvQueryContext* LineFrom; // 0x0(0x8)
	struct UEnvQueryContext* LineTo; // 0x8(0x8)
	struct UEnvQueryContext* Rotation; // 0x10(0x8)
	enum class EEnvDirection DirMode; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct AIModule.EnvNamedValue
// Size: 0x10 (Inherited: 0x0)
struct FEnvNamedValue
{
	struct FName ParamName; // 0x0(0x8)
	uint8_t ParamType; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float Value; // 0xC(0x4)
};

// Object: ScriptStruct AIModule.GenericTeamId
// Size: 0x1 (Inherited: 0x0)
struct FGenericTeamId
{
	uint8_t TeamID; // 0x0(0x1)
};

// Object: ScriptStruct AIModule.PawnActionStack
// Size: 0x8 (Inherited: 0x0)
struct FPawnActionStack
{
	struct UPawnAction* TopAction; // 0x0(0x8)
};

// Object: ScriptStruct AIModule.PawnActionEvent
// Size: 0x18 (Inherited: 0x0)
struct FPawnActionEvent
{
	struct UPawnAction* Action; // 0x0(0x8)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: AISenseBlueprintListener AIModule.Default__AISenseBlueprintListener
// Size: 0x0 (Inherited: 0x0)
struct FDefault__AISenseBlueprintListener
{
};

// Object: Class AIModule.BTNode
// Size: 0x58 (Inherited: 0x28)
struct UBTNode : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FString NodeName; // 0x30(0x10)
	struct UBehaviorTree* TreeAsset; // 0x40(0x8)
	struct UBTCompositeNode* ParentNode; // 0x48(0x8)
	uint8_t Pad_0x50[0x8]; // 0x50(0x8)
};

// Object: Class AIModule.BTAuxiliaryNode
// Size: 0x58 (Inherited: 0x58)
struct UBTAuxiliaryNode : UBTNode
{
};

// Object: Class AIModule.BTDecorator
// Size: 0x60 (Inherited: 0x58)
struct UBTDecorator : UBTAuxiliaryNode
{
	uint8_t BitPad_0x58_0 : 7; // 0x58(0x1)
	uint8_t bInverseCondition : 1; // 0x58(0x1), Mask(0x80)
	enum class EBTFlowAbortMode FlowAbortMode; // 0x59(0x1)
	uint8_t Pad_0x5A[0x6]; // 0x5A(0x6)
};

// Object: Class AIModule.BTService
// Size: 0x68 (Inherited: 0x58)
struct UBTService : UBTAuxiliaryNode
{
	float Interval; // 0x58(0x4)
	float RandomDeviation; // 0x5C(0x4)
	uint8_t bCallTickOnSearchStart : 1; // 0x60(0x1), Mask(0x1)
	uint8_t bRestartTimerOnEachActivation : 1; // 0x60(0x1), Mask(0x2)
	uint8_t BitPad_0x60_2 : 6; // 0x60(0x1)
	uint8_t Pad_0x61[0x7]; // 0x61(0x7)
};

// Object: Class AIModule.BTTaskNode
// Size: 0x70 (Inherited: 0x58)
struct UBTTaskNode : UBTNode
{
	struct TArray<struct UBTService*> Services; // 0x58(0x10)
	uint8_t bIgnoreRestartSelf : 1; // 0x68(0x1), Mask(0x1)
	uint8_t BitPad_0x68_1 : 7; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
};

// Object: Class AIModule.AIController
// Size: 0x5B8 (Inherited: 0x518)
struct AAIController : AController
{
	uint8_t Pad_0x518[0x38]; // 0x518(0x38)
	uint8_t bStopAILogicOnUnposses : 1; // 0x550(0x1), Mask(0x1)
	uint8_t bLOSflag : 1; // 0x550(0x1), Mask(0x2)
	uint8_t bSkipExtraLOSChecks : 1; // 0x550(0x1), Mask(0x4)
	uint8_t bAllowStrafe : 1; // 0x550(0x1), Mask(0x8)
	uint8_t bWantsPlayerState : 1; // 0x550(0x1), Mask(0x10)
	uint8_t bSetControlRotationFromPawnOrientation : 1; // 0x550(0x1), Mask(0x20)
	uint8_t BitPad_0x550_6 : 2; // 0x550(0x1)
	uint8_t Pad_0x551[0x7]; // 0x551(0x7)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x558(0x8)
	struct UBrainComponent* BrainComponent; // 0x560(0x8)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x568(0x8)
	struct UPawnActionsComponent* ActionsComp; // 0x570(0x8)
	struct UBlackboardComponent* Blackboard; // 0x578(0x8)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x580(0x8)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x588(0x8)
	struct FScriptMulticastDelegate ReceiveMoveCompleted; // 0x590(0x10)
	uint8_t Pad_0x5A0[0x1]; // 0x5A0(0x1)
	bool UseGameplayTasksComponent; // 0x5A1(0x1)
	bool bShareNavigationSystem; // 0x5A2(0x1)
	uint8_t Pad_0x5A3[0x1]; // 0x5A3(0x1)
	struct FVector ShareNavSysOffset; // 0x5A4(0xC)
	bool bEnableActiveRegion; // 0x5B0(0x1)
	uint8_t Pad_0x5B1[0x7]; // 0x5B1(0x7)


	// Object: Function AIModule.AIController.UseBlackboard
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ece5dc
	// Params: [ Num(3) Size(0x11) ]
	bool UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E5CCD0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AIModule.AIController.UnclaimTaskResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ece560
	// Params: [ Num(1) Size(0x8) ]
	void UnclaimTaskResource(struct UGameplayTaskResource* ResourceClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5CF60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E5CCD0
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.AIController.SetMoveBlockDetection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ece4dc
	// Params: [ Num(1) Size(0x1) ]
	void SetMoveBlockDetection(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5CB20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E5CF60
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E5CCD0
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function AIModule.AIController.RunBehaviorTree
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ece448
	// Params: [ Num(2) Size(0x9) ]
	bool RunBehaviorTree(struct UBehaviorTree* BTAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E5CB20
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E5CF60
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E5CCD0

	// Object: Function AIModule.AIController.OnUsingBlackBoard
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void OnUsingBlackBoard(struct UBlackboardComponent* BlackboardComp, struct UBlackboardData* BlackboardAsset);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AIController.OnUnpossess
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnUnpossess(struct APawn* UnpossessedPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AIController.OnPossess
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnPossess(struct APawn* PossessedPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AIController.OnGameplayTaskResourcesClaimed
	// Flags: [Native|Public]
	// Offset: 0x105ece388
	// Params: [ Num(2) Size(0x4) ]
	void OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E5CB20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E5CF60

	// Object: Function AIModule.AIController.MoveToLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ece114
	// Params: [ Num(9) Size(0x22) ]
	enum class EPathFollowingRequestResult MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E5BDE8

	// Object: Function AIModule.AIController.MoveToActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecdef8
	// Params: [ Num(8) Size(0x1A) ]
	enum class EPathFollowingRequestResult MoveToActor(struct AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E5BC20

	// Object: Function AIModule.AIController.K2_SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecde7c
	// Params: [ Num(1) Size(0x8) ]
	void K2_SetFocus(struct AActor* NewFocus);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5ACB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.K2_SetFocalPoint
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ecde00
	// Params: [ Num(1) Size(0xC) ]
	void K2_SetFocalPoint(struct FVector FP);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5ACC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E5ACB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.K2_ClearFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecddec
	// Params: [ Num(0) Size(0x0) ]
	void K2_ClearFocus();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5ACC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E5ACB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.HasPartialPath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecddb8
	// Params: [ Num(1) Size(0x1) ]
	bool HasPartialPath();
	// [Call #1] RVA: 0x105E5CA88
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E5ACC4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5ACB4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.GetPathFollowingComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdd9c
	// Params: [ Num(1) Size(0x8) ]
	struct UPathFollowingComponent* GetPathFollowingComponent();
	// [Call #1] RVA: 0x105E5CA88
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E5ACC4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5ACB4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AIModule.AIController.GetMoveStatus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdd68
	// Params: [ Num(1) Size(0x1) ]
	enum class EPathFollowingStatus GetMoveStatus();
	// [Call #1] RVA: 0x105E5CA70
	// [Call #2] RVA: 0x105E5CA88
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E5ACC4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E5ACB4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function AIModule.AIController.GetImmediateMoveDestination
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdd30
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetImmediateMoveDestination();
	// [Call #1] RVA: 0x105E5CAEC
	// [Call #2] RVA: 0x105E5CA70
	// [Call #3] RVA: 0x105E5CA88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E5ACC4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E5ACB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function AIModule.AIController.GetFocusActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdcfc
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetFocusActor();
	// [Call #1] RVA: 0x105E5A8CC
	// [Call #2] RVA: 0x105E5CAEC
	// [Call #3] RVA: 0x105E5CA70
	// [Call #4] RVA: 0x105E5CA88
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5ACC4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E5ACB4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.GetFocalPointOnActor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdc64
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetFocalPointOnActor(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5A8CC
	// [Call #4] RVA: 0x105E5CAEC
	// [Call #5] RVA: 0x105E5CA70
	// [Call #6] RVA: 0x105E5CA88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E5ACC4
	// [Call #10] RVA: 0x10516D168

	// Object: Function AIModule.AIController.GetFocalPoint
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecdc2c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetFocalPoint();
	// [Call #1] RVA: 0x105E5AB24
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E5A8CC
	// [Call #5] RVA: 0x105E5CAEC
	// [Call #6] RVA: 0x105E5CA70
	// [Call #7] RVA: 0x105E5CA88
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E5ACC4

	// Object: Function AIModule.AIController.GetAIPerceptionComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ecdc10
	// Params: [ Num(1) Size(0x8) ]
	struct UAIPerceptionComponent* GetAIPerceptionComponent();
	// [Call #1] RVA: 0x105E5AB24
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E5A8CC
	// [Call #5] RVA: 0x105E5CAEC
	// [Call #6] RVA: 0x105E5CA70
	// [Call #7] RVA: 0x105E5CA88
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function AIModule.AIController.ClaimTaskResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecdb94
	// Params: [ Num(1) Size(0x8) ]
	void ClaimTaskResource(struct UGameplayTaskResource* ResourceClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5CED0
	// [Call #4] RVA: 0x105E5AB24
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5A8CC
	// [Call #8] RVA: 0x105E5CAEC
	// [Call #9] RVA: 0x105E5CA70
	// [Call #10] RVA: 0x105E5CA88
};

// Object: Class AIModule.BTService_BlackboardBase
// Size: 0x90 (Inherited: 0x68)
struct UBTService_BlackboardBase : UBTService
{
	struct FBlackboardKeySelector BlackboardKey; // 0x68(0x28)
};

// Object: Class AIModule.BTTask_BlackboardBase
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_BlackboardBase : UBTTaskNode
{
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
};

// Object: Class AIModule.BTTask_MoveTo
// Size: 0xB0 (Inherited: 0x98)
struct UBTTask_MoveTo : UBTTask_BlackboardBase
{
	float AcceptableRadius; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct UNavigationQueryFilter* FilterClass; // 0xA0(0x8)
	float ObservedBlackboardValueTolerance; // 0xA8(0x4)
	uint8_t bObserveBlackboardValue : 1; // 0xAC(0x1), Mask(0x1)
	uint8_t bAllowStrafe : 1; // 0xAC(0x1), Mask(0x2)
	uint8_t bAllowPartialPath : 1; // 0xAC(0x1), Mask(0x4)
	uint8_t bTrackMovingGoal : 1; // 0xAC(0x1), Mask(0x8)
	uint8_t bProjectGoalLocation : 1; // 0xAC(0x1), Mask(0x10)
	uint8_t bReachTestIncludesAgentRadius : 1; // 0xAC(0x1), Mask(0x20)
	uint8_t bReachTestIncludesGoalRadius : 1; // 0xAC(0x1), Mask(0x40)
	uint8_t bStopOnOverlap : 1; // 0xAC(0x1), Mask(0x80)
	uint8_t bStopOnOverlapNeedsUpdate : 1; // 0xAD(0x1), Mask(0x1)
	uint8_t BitPad_0xAD_1 : 7; // 0xAD(0x1)
	uint8_t Pad_0xAE[0x2]; // 0xAE(0x2)
};

// Object: Class AIModule.BTTask_MoveDirectlyToward
// Size: 0xB0 (Inherited: 0xB0)
struct UBTTask_MoveDirectlyToward : UBTTask_MoveTo
{
	uint8_t bDisablePathUpdateOnGoalLocationChange : 1; // 0xAE(0x1), Mask(0x1)
	uint8_t bProjectVectorGoalToNavigation : 1; // 0xAE(0x1), Mask(0x2)
	uint8_t bUpdatedDeprecatedProperties : 1; // 0xAE(0x1), Mask(0x4)
};

// Object: Class AIModule.BlackboardComponent
// Size: 0x270 (Inherited: 0x178)
struct UBlackboardComponent : UActorComponent
{
	struct UBrainComponent* BrainComp; // 0x178(0x8)
	struct UBlackboardData* BlackboardAsset; // 0x180(0x8)
	uint8_t Pad_0x188[0x20]; // 0x188(0x20)
	struct TArray<struct UBlackboardKeyType*> KeyInstances; // 0x1A8(0x10)
	uint8_t Pad_0x1B8[0xB8]; // 0x1B8(0xB8)


	// Object: Function AIModule.BlackboardComponent.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ed96cc
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.BlackboardComponent.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed9588
	// Params: [ Num(2) Size(0x18) ]
	void SetValueAsString(struct FName& KeyName, struct FString StringValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10519022C

	// Object: Function AIModule.BlackboardComponent.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ed94b0
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsRotator(struct FName& KeyName, struct FRotator RotatorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function AIModule.BlackboardComponent.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed93d8
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed9300
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsName(struct FName& KeyName, struct FName NameValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed9228
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsInt(struct FName& KeyName, int IntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed9150
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsFloat(struct FName& KeyName, float FloatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed9078
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsEnum(struct FName& KeyName, uint8_t EnumValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed8fa0
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed8ec0
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsBool(struct FName& KeyName, bool BoolValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.IsVectorValueSet
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8e24
	// Params: [ Num(2) Size(0x9) ]
	bool IsVectorValueSet(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B8EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8d84
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetValueAsVector(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B62C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B8EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function AIModule.BlackboardComponent.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8cc0
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetValueAsString(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B5CC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E6B62C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6B8EC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8c20
	// Params: [ Num(2) Size(0x14) ]
	struct FRotator GetValueAsRotator(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B630
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B5CC
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6B62C
	// [Call #14] RVA: 0x10516D168

	// Object: Function AIModule.BlackboardComponent.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8b84
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B4C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B630
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B5CC
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function AIModule.BlackboardComponent.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8ae8
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetValueAsName(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B600
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B4C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B630
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function AIModule.BlackboardComponent.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8a4c
	// Params: [ Num(2) Size(0xC) ]
	int GetValueAsInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B548
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B600
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B4C4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E6B630

	// Object: Function AIModule.BlackboardComponent.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed89b0
	// Params: [ Num(2) Size(0xC) ]
	float GetValueAsFloat(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B574
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B548
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B600
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E6B4C4

	// Object: Function AIModule.BlackboardComponent.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8914
	// Params: [ Num(2) Size(0x9) ]
	uint8_t GetValueAsEnum(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B51C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B574
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B548
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E6B600

	// Object: Function AIModule.BlackboardComponent.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8878
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsClass(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B4F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B51C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B574
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E6B548

	// Object: Function AIModule.BlackboardComponent.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed87dc
	// Params: [ Num(2) Size(0x9) ]
	bool GetValueAsBool(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B5A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6B4F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E6B51C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E6B574

	// Object: Function AIModule.BlackboardComponent.GetRotationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed86f8
	// Params: [ Num(3) Size(0x15) ]
	bool GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6BCC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E6B5A0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E6B4F0

	// Object: Function AIModule.BlackboardComponent.GetLocationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed8614
	// Params: [ Num(3) Size(0x15) ]
	bool GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6BC18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E6BCC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6B5A0

	// Object: Function AIModule.BlackboardComponent.ClearValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed8588
	// Params: [ Num(1) Size(0x8) ]
	void ClearValue(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6B958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E6BC18
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6BCC8
};

// Object: Class AIModule.PathFollowingComponent
// Size: 0x348 (Inherited: 0x178)
struct UPathFollowingComponent : UActorComponent
{
	uint8_t Pad_0x178[0x48]; // 0x178(0x48)
	struct UNavMovementComponent* MovementComp; // 0x1C0(0x8)
	uint8_t Pad_0x1C8[0x8]; // 0x1C8(0x8)
	struct ANavigationData* MyNavData; // 0x1D0(0x8)
	uint8_t Pad_0x1D8[0x170]; // 0x1D8(0x170)


	// Object: Function AIModule.PathFollowingComponent.OnNavDataRegistered
	// Flags: [Final|Native|Protected]
	// Offset: 0x105ef1340
	// Params: [ Num(1) Size(0x8) ]
	void OnNavDataRegistered(struct ANavigationData* NavData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB5008
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function AIModule.PathFollowingComponent.OnActorBump
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x105ef11ec
	// Params: [ Num(4) Size(0xA8) ]
	void OnActorBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105EB5008
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AIModule.PathFollowingComponent.GetPathDestination
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ef11b4
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetPathDestination();
	// [Call #1] RVA: 0x105EB65DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C8CD38
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EB5008
	// [Call #14] RVA: 0x10519022C

	// Object: Function AIModule.PathFollowingComponent.GetPathActionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ef1180
	// Params: [ Num(1) Size(0x1) ]
	enum class EPathFollowingAction GetPathActionType();
	// [Call #1] RVA: 0x105EB6560
	// [Call #2] RVA: 0x105EB65DC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105EB5008
};

// Object: Class AIModule.AISense
// Size: 0x80 (Inherited: 0x28)
struct UAISense : UObject
{
	float DefaultExpirationAge; // 0x28(0x4)
	uint8_t NotifyType; // 0x2C(0x1)
	uint8_t bWantsNewPawnNotification : 1; // 0x2D(0x1), Mask(0x1)
	uint8_t bAutoRegisterAllPawnsAsSources : 1; // 0x2D(0x1), Mask(0x2)
	uint8_t BitPad_0x2D_2 : 6; // 0x2D(0x1)
	uint8_t Pad_0x2E[0x2]; // 0x2E(0x2)
	struct UAIPerceptionSystem* PerceptionSystemInstance; // 0x30(0x8)
	uint8_t Pad_0x38[0x48]; // 0x38(0x48)
};

// Object: Class AIModule.AISenseConfig
// Size: 0x48 (Inherited: 0x28)
struct UAISenseConfig : UObject
{
	struct FColor DebugColor; // 0x28(0x4)
	float MaxAge; // 0x2C(0x4)
	uint8_t bStartsEnabled : 1; // 0x30(0x1), Mask(0x1)
	uint8_t BitPad_0x30_1 : 7; // 0x30(0x1)
	uint8_t Pad_0x31[0x17]; // 0x31(0x17)
};

// Object: Class AIModule.AISenseEvent
// Size: 0x28 (Inherited: 0x28)
struct UAISenseEvent : UObject
{
};

// Object: Class AIModule.CrowdFollowingComponent
// Size: 0x398 (Inherited: 0x348)
struct UCrowdFollowingComponent : UPathFollowingComponent
{
	uint8_t Pad_0x348[0x8]; // 0x348(0x8)
	struct FVector CrowdAgentMoveDirection; // 0x350(0xC)
	uint8_t Pad_0x35C[0x4]; // 0x35C(0x4)
	struct UCharacterMovementComponent* CharacterMovement; // 0x360(0x8)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x368(0x4)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x36C(0x4)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x370(0x4)
	uint8_t Pad_0x374[0x24]; // 0x374(0x24)


	// Object: Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ee5270
	// Params: [ Num(1) Size(0x1) ]
	void SuspendCrowdSteering(bool bSuspend);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105ECCA04
	// [Call #7] RVA: 0x105184F34
};

// Object: Class AIModule.CrowdManager
// Size: 0xF8 (Inherited: 0x28)
struct UCrowdManager : UCrowdManagerBase
{
	uint8_t EnabledCrowd : 1; // 0x28(0x1), Mask(0x1)
	uint8_t BitPad_0x28_1 : 7; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct ANavigationData* MyNavData; // 0x30(0x8)
	struct TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // 0x38(0x10)
	struct TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0x48(0x10)
	int MaxAgents; // 0x58(0x4)
	float MaxAgentRadius; // 0x5C(0x4)
	int MaxAvoidedAgents; // 0x60(0x4)
	int MaxAvoidedWalls; // 0x64(0x4)
	float NavmeshCheckInterval; // 0x68(0x4)
	float PathOptimizationInterval; // 0x6C(0x4)
	float SeparationDirClamp; // 0x70(0x4)
	float PathOffsetRadiusMultiplier; // 0x74(0x4)
	uint8_t BitPad_0x78_0 : 4; // 0x78(0x1)
	uint8_t bResolveCollisions : 1; // 0x78(0x1), Mask(0x10)
	uint8_t BitPad_0x78_5 : 3; // 0x78(0x1)
	uint8_t Pad_0x79[0x7F]; // 0x79(0x7F)
};

// Object: Class AIModule.BrainComponent
// Size: 0x1D8 (Inherited: 0x178)
struct UBrainComponent : UActorComponent
{
	uint8_t Pad_0x178[0x8]; // 0x178(0x8)
	struct UBlackboardComponent* BlackboardComp; // 0x180(0x8)
	struct AAIController* AIOwner; // 0x188(0x8)
	uint8_t Pad_0x190[0x48]; // 0x190(0x48)


	// Object: Function AIModule.BrainComponent.StopLogic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105edaf7c
	// Params: [ Num(1) Size(0x10) ]
	void StopLogic(struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.BrainComponent.RestartLogic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105edaf60
	// Params: [ Num(0) Size(0x0) ]
	void RestartLogic();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.BrainComponent.IsRunning
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105edaf24
	// Params: [ Num(1) Size(0x1) ]
	bool IsRunning();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.BrainComponent.IsPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105edaee8
	// Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class AIModule.BehaviorTreeComponent
// Size: 0x310 (Inherited: 0x1D8)
struct UBehaviorTreeComponent : UBrainComponent
{
	uint8_t Pad_0x1D8[0x20]; // 0x1D8(0x20)
	struct TArray<struct UBTNode*> NodeInstances; // 0x1F8(0x10)
	uint8_t Pad_0x208[0x108]; // 0x208(0x108)


	// Object: Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ed7dec
	// Params: [ Num(2) Size(0x10) ]
	void SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870

	// Object: Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed7d60
	// Params: [ Num(2) Size(0xC) ]
	float GetTagCooldownEndTime(struct FGameplayTag CooldownTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E645C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed7c64
	// Params: [ Num(3) Size(0xD) ]
	void AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E64614
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E645C0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class AIModule.BTDecorator_BlackboardBase
// Size: 0x88 (Inherited: 0x60)
struct UBTDecorator_BlackboardBase : UBTDecorator
{
	struct FBlackboardKeySelector BlackboardKey; // 0x60(0x28)
};

// Object: Class AIModule.BTDecorator_Cooldown
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_Cooldown : UBTDecorator
{
	float CoolDownTime; // 0x5C(0x4)
};

// Object: Class AIModule.BTService_DefaultFocus
// Size: 0x98 (Inherited: 0x90)
struct UBTService_DefaultFocus : UBTService_BlackboardBase
{
	uint8_t FocusPriority; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
};

// Object: Class AIModule.BTTask_Wait
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_Wait : UBTTaskNode
{
	float WaitTime; // 0x6C(0x4)
	float RandomDeviation; // 0x70(0x4)
};

// Object: Class AIModule.AIAsyncTaskBlueprintProxy
// Size: 0x68 (Inherited: 0x28)
struct UAIAsyncTaskBlueprintProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFail; // 0x38(0x10)
	uint8_t Pad_0x48[0x20]; // 0x48(0x20)


	// Object: Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x105ecca6c
	// Params: [ Num(2) Size(0x5) ]
	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E85E4C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105ECD998
	// [Call #10] RVA: 0x10516D168
};

// Object: Class AIModule.AIBlueprintHelperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAIBlueprintHelperLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ecd4f0
	// Params: [ Num(3) Size(0xA) ]
	void UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E867C0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ecd344
	// Params: [ Num(7) Size(0x40) ]
	struct APawn* SpawnAIFromClass(struct UObject* WorldContextObject, struct APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E86578
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ecd218
	// Params: [ Num(4) Size(0x19) ]
	void SendAIMessage(struct APawn* Target, struct FName Message, struct UObject* MessageSource, bool bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E86504
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ecd11c
	// Params: [ Num(3) Size(0xA) ]
	void LockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E8672C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E86504

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ecd0a0
	// Params: [ Num(2) Size(0xD) ]
	bool IsValidAIRotation(struct FRotator Rotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E86918
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E8672C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ecd024
	// Params: [ Num(2) Size(0xD) ]
	bool IsValidAILocation(struct FVector Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E86854
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E86918
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E8672C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105eccfa8
	// Params: [ Num(2) Size(0xD) ]
	bool IsValidAIDirection(struct FVector DirectionVector);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E868AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E86854
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E86918
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105eccf2c
	// Params: [ Num(2) Size(0x10) ]
	struct UNavigationPath* GetCurrentPath(struct AController* Controller);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E8694C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E868AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E86854
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E86918
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ecceb0
	// Params: [ Num(2) Size(0x10) ]
	struct UBlackboardComponent* GetBlackboard(struct AActor* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E866E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E8694C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E868AC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E86854
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E86918

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetAIController
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ecce34
	// Params: [ Num(2) Size(0x10) ]
	struct AAIController* GetAIController(struct AActor* ControlledActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E8669C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E866E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E8694C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E868AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E86854

	// Object: Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105eccc84
	// Params: [ Num(7) Size(0x38) ]
	struct UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(struct UObject* WorldContextObject, struct APawn* Pawn, struct FVector Destination, struct AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E860F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E8669C
};

// Object: Class AIModule.AIDataProvider
// Size: 0x28 (Inherited: 0x28)
struct UAIDataProvider : UObject
{
};

// Object: Class AIModule.AIDataProvider_QueryParams
// Size: 0x40 (Inherited: 0x28)
struct UAIDataProvider_QueryParams : UAIDataProvider
{
	struct FName ParamName; // 0x28(0x8)
	float FloatValue; // 0x30(0x4)
	int IntValue; // 0x34(0x4)
	bool BoolValue; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
};

// Object: Class AIModule.AIDataProvider_Random
// Size: 0x48 (Inherited: 0x40)
struct UAIDataProvider_Random : UAIDataProvider_QueryParams
{
	float Min; // 0x3C(0x4)
	float Max; // 0x40(0x4)
	uint8_t bInteger : 1; // 0x44(0x1), Mask(0x1)
};

// Object: Class AIModule.AIHotSpotManager
// Size: 0x28 (Inherited: 0x28)
struct UAIHotSpotManager : UObject
{
};

// Object: Class AIModule.AIPerceptionComponent
// Size: 0x250 (Inherited: 0x178)
struct UAIPerceptionComponent : UActorComponent
{
	struct TArray<struct UAISenseConfig*> SensesConfig; // 0x178(0x10)
	struct UAISense* DominantSense; // 0x188(0x8)
	uint8_t Pad_0x190[0x10]; // 0x190(0x10)
	struct AAIController* AIOwner; // 0x1A0(0x8)
	uint8_t Pad_0x1A8[0x80]; // 0x1A8(0x80)
	struct FScriptMulticastDelegate OnPerceptionUpdated; // 0x228(0x10)
	struct FScriptMulticastDelegate OnTargetPerceptionUpdated; // 0x238(0x10)
	uint8_t Pad_0x248[0x8]; // 0x248(0x8)


	// Object: Function AIModule.AIPerceptionComponent.SetSenseEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecfe4c
	// Params: [ Num(2) Size(0x9) ]
	void SetSenseEnabled(struct UAISense* SenseClass, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB8510
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ecfe38
	// Params: [ Num(0) Size(0x0) ]
	void RequestStimuliListenerUpdate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB8510
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
	// Flags: [Final|Native|Public]
	// Offset: 0x105ecfd80
	// Params: [ Num(2) Size(0x9) ]
	void OnOwnerEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB6E70
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105EB8510
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecfcd8
	// Params: [ Num(1) Size(0x10) ]
	void GetPerceivedHostileActors(struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB80C0
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105EB6E70
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105EB8510

	// Object: Function AIModule.AIPerceptionComponent.GetPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecfbf4
	// Params: [ Num(2) Size(0x18) ]
	void GetPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB85A8
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105EB80C0
	// [Call #12] RVA: 0x101F811FC
	// [Call #13] RVA: 0x101F811FC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105EB6E70

	// Object: Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecfb10
	// Params: [ Num(2) Size(0x18) ]
	void GetKnownPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB827C
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EB85A8
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105EB80C0
	// [Call #20] RVA: 0x101F811FC

	// Object: Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ecfa2c
	// Params: [ Num(2) Size(0x18) ]
	void GetCurrentlyPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB80CC
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EB827C
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AIModule.AIPerceptionComponent.GetActorsPerception
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ecf92c
	// Params: [ Num(3) Size(0x29) ]
	bool GetActorsPerception(struct AActor* Actor, struct FActorPerceptionBlueprintInfo& Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB8424
	// [Call #6] RVA: 0x1035FF9F8
	// [Call #7] RVA: 0x1035FF9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EB80CC
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class AIModule.AIPerceptionListenerInterface
// Size: 0x28 (Inherited: 0x28)
struct IAIPerceptionListenerInterface : IInterface
{
};

// Object: Class AIModule.AIPerceptionStimuliSourceComponent
// Size: 0x190 (Inherited: 0x178)
struct UAIPerceptionStimuliSourceComponent : UActorComponent
{
	uint8_t bAutoRegisterAsSource : 1; // 0x178(0x1), Mask(0x1)
	uint8_t BitPad_0x178_1 : 7; // 0x178(0x1)
	uint8_t Pad_0x179[0x7]; // 0x179(0x7)
	struct TArray<struct UAISense*> RegisterAsSourceForSenses; // 0x180(0x10)


	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed0410
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterFromSense(struct UAISense* SenseClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB8920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed03fc
	// Params: [ Num(0) Size(0x0) ]
	void UnregisterFromPerceptionSystem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB8920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed03e8
	// Params: [ Num(0) Size(0x0) ]
	void RegisterWithPerceptionSystem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB8920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed036c
	// Params: [ Num(1) Size(0x8) ]
	void RegisterForSense(struct UAISense* SenseClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EB8814
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105EB8920
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

// Object: Class AIModule.AIPerceptionSystem
// Size: 0x130 (Inherited: 0x28)
struct UAIPerceptionSystem : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct TArray<struct UAISense*> Senses; // 0x80(0x10)
	float PerceptionAgingRate; // 0x90(0x4)
	uint8_t Pad_0x94[0x9C]; // 0x94(0x9C)


	// Object: Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ed09bc
	// Params: [ Num(2) Size(0x10) ]
	void ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EBA3B8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionSystem.ReportEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ed0940
	// Params: [ Num(1) Size(0x8) ]
	void ReportEvent(struct UAISenseEvent* PerceptionEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EBA340
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105EBA3B8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ed0850
	// Params: [ Num(4) Size(0x19) ]
	bool RegisterPerceptionStimuliSource(struct UObject* WorldContextObject, struct UAISense* Sense, struct AActor* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105EBA24C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105EBA340
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105EBA3B8
	// [Call #16] RVA: 0x10519022C

	// Object: Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
	// Flags: [Final|Native|Protected]
	// Offset: 0x105ed0798
	// Params: [ Num(2) Size(0x9) ]
	void OnPerceptionStimuliSourceEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB8B88
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105EBA24C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105EBA340
	// [Call #16] RVA: 0x10516D168

	// Object: Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ed06cc
	// Params: [ Num(3) Size(0x70) ]
	struct UAISense* GetSenseClassForStimulus(struct UObject* WorldContextObject, struct FAIStimulus& Stimulus);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1035FF8C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105EBA2F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105EB8B88
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class AIModule.AIResourceInterface
// Size: 0x28 (Inherited: 0x28)
struct IAIResourceInterface : IInterface
{
};

// Object: Class AIModule.AIResource_Movement
// Size: 0x30 (Inherited: 0x30)
struct UAIResource_Movement : UGameplayTaskResource
{
};

// Object: Class AIModule.AIResource_Logic
// Size: 0x30 (Inherited: 0x30)
struct UAIResource_Logic : UGameplayTaskResource
{
};

// Object: Class AIModule.AISense_Blueprint
// Size: 0xA8 (Inherited: 0x80)
struct UAISense_Blueprint : UAISense
{
	struct UUserDefinedStruct* ListenerDataType; // 0x80(0x8)
	struct TArray<struct UAIPerceptionComponent*> ListenerContainer; // 0x88(0x10)
	struct TArray<struct UAISenseEvent*> UnprocessedEvents; // 0x98(0x10)


	// Object: Function AIModule.AISense_Blueprint.OnUpdate
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x14) ]
	float OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AISense_Blueprint.OnListenerUpdated
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void OnListenerUpdated(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AISense_Blueprint.OnListenerUnregistered
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void OnListenerUnregistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AISense_Blueprint.OnListenerRegistered
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void OnListenerRegistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AISense_Blueprint.K2_OnNewPawn
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void K2_OnNewPawn(struct APawn* NewPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.AISense_Blueprint.GetAllListenerComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed15b8
	// Params: [ Num(1) Size(0x10) ]
	void GetAllListenerComponents(struct TArray<struct UAIPerceptionComponent*>& ListenerComponents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EBAF7C
	// [Call #4] RVA: 0x105EC7388
	// [Call #5] RVA: 0x105EC7388
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.AISense_Blueprint.GetAllListenerActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ed1510
	// Params: [ Num(1) Size(0x10) ]
	void GetAllListenerActors(struct TArray<struct AActor*>& ListenerActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105EBAEE0
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105EBAF7C
	// [Call #10] RVA: 0x105EC7388
	// [Call #11] RVA: 0x105EC7388
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
};

// Object: Class AIModule.AISense_Damage
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Damage : UAISense
{
	struct TArray<struct FAIDamageEvent> RegisteredEvents; // 0x80(0x10)


	// Object: Function AIModule.AISense_Damage.ReportDamageEvent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ed1a24
	// Params: [ Num(6) Size(0x34) ]
	void ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EBB450
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
};

// Object: Class AIModule.AISense_Hearing
// Size: 0xE8 (Inherited: 0x80)
struct UAISense_Hearing : UAISense
{
	struct TArray<struct FAINoiseEvent> NoiseEvents; // 0x80(0x10)
	float SpeedOfSoundSq; // 0x90(0x4)
	uint8_t Pad_0x94[0x54]; // 0x94(0x54)


	// Object: Function AIModule.AISense_Hearing.ReportNoiseEvent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ed1de8
	// Params: [ Num(6) Size(0x30) ]
	void ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105EBBA08
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
};

// Object: Class AIModule.AISense_Prediction
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Prediction : UAISense
{
	struct TArray<struct FAIPredictionEvent> RegisteredEvents; // 0x80(0x10)


	// Object: Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ed229c
	// Params: [ Num(3) Size(0x14) ]
	void RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105EBC1B0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C

	// Object: Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ed21b4
	// Params: [ Num(3) Size(0x14) ]
	void RequestControllerPredictionEvent(struct AAIController* Requestor, struct AActor* PredictedActor, float PredictionTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105EBC110
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105EBC1B0
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
};

// Object: Class AIModule.AISense_Sight
// Size: 0x158 (Inherited: 0x80)
struct UAISense_Sight : UAISense
{
	uint8_t Pad_0x80[0xB0]; // 0x80(0xB0)
	int MaxTracesPerTick; // 0x130(0x4)
	int MinQueriesPerTimeSliceCheck; // 0x134(0x4)
	double MaxTimeSlicePerTick; // 0x138(0x8)
	float HighImportanceQueryDistanceThreshold; // 0x140(0x4)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
	float MaxQueryImportance; // 0x148(0x4)
	float SightLimitQueryImportance; // 0x14C(0x4)
	uint8_t Pad_0x150[0x8]; // 0x150(0x8)
};

// Object: Class AIModule.AISense_Team
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Team : UAISense
{
	struct TArray<struct FAITeamStimulusEvent> RegisteredEvents; // 0x80(0x10)
};

// Object: Class AIModule.AISense_Touch
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Touch : UAISense
{
	struct TArray<struct FAITouchEvent> RegisteredEvents; // 0x80(0x10)
};

// Object: Class AIModule.AISenseBlueprintListener
// Size: 0xA8 (Inherited: 0xA8)
struct UAISenseBlueprintListener : UUserDefinedStruct
{
};

// Object: Class AIModule.AISenseConfig_Blueprint
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Blueprint : UAISenseConfig
{
	struct UAISense_Blueprint* Implementation; // 0x48(0x8)
};

// Object: Class AIModule.AISenseConfig_Damage
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Damage : UAISenseConfig
{
	struct UAISense_Damage* Implementation; // 0x48(0x8)
};

// Object: Class AIModule.AISenseConfig_Hearing
// Size: 0x60 (Inherited: 0x48)
struct UAISenseConfig_Hearing : UAISenseConfig
{
	struct UAISense_Hearing* Implementation; // 0x48(0x8)
	float HearingRange; // 0x50(0x4)
	float LoSHearingRange; // 0x54(0x4)
	uint8_t bUseLoSHearing : 1; // 0x58(0x1), Mask(0x1)
	uint8_t BitPad_0x58_1 : 7; // 0x58(0x1)
	uint8_t Pad_0x59[0x3]; // 0x59(0x3)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5C(0x4)
};

// Object: Class AIModule.AISenseConfig_Prediction
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Prediction : UAISenseConfig
{
};

// Object: Class AIModule.AISenseConfig_Sight
// Size: 0x68 (Inherited: 0x48)
struct UAISenseConfig_Sight : UAISenseConfig
{
	struct UAISense_Sight* Implementation; // 0x48(0x8)
	float SightRadius; // 0x50(0x4)
	float LoseSightRadius; // 0x54(0x4)
	float PeripheralVisionAngleDegrees; // 0x58(0x4)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5C(0x4)
	float AutoSuccessRangeFromLastSeenLocation; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
};

// Object: Class AIModule.AISenseConfig_Team
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Team : UAISenseConfig
{
};

// Object: Class AIModule.AISenseConfig_Touch
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Touch : UAISenseConfig
{
};

// Object: Class AIModule.AISenseEvent_Damage
// Size: 0x58 (Inherited: 0x28)
struct UAISenseEvent_Damage : UAISenseEvent
{
	struct FAIDamageEvent Event; // 0x28(0x30)
};

// Object: Class AIModule.AISenseEvent_Hearing
// Size: 0x58 (Inherited: 0x28)
struct UAISenseEvent_Hearing : UAISenseEvent
{
	struct FAINoiseEvent Event; // 0x28(0x30)
};

// Object: Class AIModule.AISightTargetInterface
// Size: 0x28 (Inherited: 0x28)
struct IAISightTargetInterface : IInterface
{
};

// Object: Class AIModule.AISystem
// Size: 0x128 (Inherited: 0x50)
struct UAISystem : UAISystemBase
{
	struct FSoftClassPath PerceptionSystemClassName; // 0x50(0x18)
	struct FSoftClassPath HotSpotManagerClassName; // 0x68(0x18)
	float AcceptanceRadius; // 0x80(0x4)
	float PathfollowingRegularPathPointAcceptanceRadius; // 0x84(0x4)
	float PathfollowingNavLinkAcceptanceRadius; // 0x88(0x4)
	bool bFinishMoveOnGoalOverlap; // 0x8C(0x1)
	bool bAcceptPartialPaths; // 0x8D(0x1)
	bool bAllowStrafing; // 0x8E(0x1)
	bool bEnableBTAITasks; // 0x8F(0x1)
	bool bAllowControllersAsEQSQuerier; // 0x90(0x1)
	bool bEnableDebuggerPlugin; // 0x91(0x1)
	enum class ECollisionChannel DefaultSightCollisionChannel; // 0x92(0x1)
	uint8_t Pad_0x93[0x5]; // 0x93(0x5)
	struct UBehaviorTreeManager* BehaviorTreeManager; // 0x98(0x8)
	struct UEnvQueryManager* EnvironmentQueryManager; // 0xA0(0x8)
	struct UAIPerceptionSystem* PerceptionSystem; // 0xA8(0x8)
	struct TArray<struct UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0xB0(0x10)
	struct UAIHotSpotManager* HotSpotManager; // 0xC0(0x8)
	struct UNavLocalGridManager* NavLocalGrids; // 0xC8(0x8)
	uint8_t Pad_0xD0[0x58]; // 0xD0(0x58)


	// Object: Function AIModule.AISystem.AILoggingVerbose
	// Flags: [Exec|Native|Public]
	// Offset: 0x105ed6a4c
	// Params: [ Num(0) Size(0x0) ]
	void AILoggingVerbose();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105ECCA04
	// [Call #6] RVA: 0x105185230

	// Object: Function AIModule.AISystem.AIIgnorePlayers
	// Flags: [Exec|Native|Public]
	// Offset: 0x105ed6a30
	// Params: [ Num(0) Size(0x0) ]
	void AIIgnorePlayers();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105ECCA04
	// [Call #6] RVA: 0x105185230
};

// Object: Class AIModule.AITask
// Size: 0x68 (Inherited: 0x60)
struct UAITask : UGameplayTask
{
	struct AAIController* OwnerController; // 0x60(0x8)
};

// Object: Class AIModule.AITask_LockLogic
// Size: 0x68 (Inherited: 0x68)
struct UAITask_LockLogic : UAITask
{
};

// Object: Class AIModule.AITask_MoveTo
// Size: 0x108 (Inherited: 0x68)
struct UAITask_MoveTo : UAITask
{
	struct FScriptMulticastDelegate OnRequestFailed; // 0x68(0x10)
	struct FScriptMulticastDelegate OnMoveFinished; // 0x78(0x10)
	struct FAIMoveRequest MoveRequest; // 0x88(0x40)
	uint8_t Pad_0xC8[0x40]; // 0xC8(0x40)


	// Object: Function AIModule.AITask_MoveTo.AIMoveTo
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ed6f34
	// Params: [ Num(10) Size(0x38) ]
	struct UAITask_MoveTo* AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuosGoalTracking);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class AIModule.AITask_RunEQS
// Size: 0xE0 (Inherited: 0x68)
struct UAITask_RunEQS : UAITask
{
	uint8_t Pad_0x68[0x78]; // 0x68(0x78)


	// Object: Function AIModule.AITask_RunEQS.RunEQS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ed73c4
	// Params: [ Num(3) Size(0x18) ]
	struct UAITask_RunEQS* RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105ECC0C8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105ECCA04
	// [Call #10] RVA: 0x105185230
};

// Object: Class AIModule.BehaviorTree
// Size: 0x60 (Inherited: 0x28)
struct UBehaviorTree : UObject
{
	struct UBTCompositeNode* RootNode; // 0x28(0x8)
	struct UBlackboardData* BlackboardAsset; // 0x30(0x8)
	struct TArray<struct UBTDecorator*> RootDecorators; // 0x38(0x10)
	struct TArray<struct FBTDecoratorLogic> RootDecoratorOps; // 0x48(0x10)
	uint8_t Pad_0x58[0x8]; // 0x58(0x8)
};

// Object: Class AIModule.BehaviorTreeManager
// Size: 0x50 (Inherited: 0x28)
struct UBehaviorTreeManager : UObject
{
	int MaxDebuggerSteps; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // 0x30(0x10)
	struct TArray<struct UBehaviorTreeComponent*> ActiveComponents; // 0x40(0x10)
};

// Object: Class AIModule.BehaviorTreeTypes
// Size: 0x28 (Inherited: 0x28)
struct UBehaviorTreeTypes : UObject
{
};

// Object: Class AIModule.BlackboardData
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardData : UDataAsset
{
	struct UBlackboardData* Parent; // 0x30(0x8)
	struct TArray<struct FBlackboardEntry> Keys; // 0x38(0x10)
	uint8_t bHasSynchronizedKeys : 1; // 0x48(0x1), Mask(0x1)
	uint8_t BitPad_0x48_1 : 7; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: Class AIModule.BlackboardKeyType
// Size: 0x30 (Inherited: 0x28)
struct UBlackboardKeyType : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: Class AIModule.BlackboardKeyType_Bool
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Bool : UBlackboardKeyType
{
};

// Object: Class AIModule.BlackboardKeyType_Class
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Class : UBlackboardKeyType
{
	struct UObject* BaseClass; // 0x30(0x8)
};

// Object: Class AIModule.BlackboardKeyType_Enum
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardKeyType_Enum : UBlackboardKeyType
{
	struct UEnum* EnumType; // 0x30(0x8)
	struct FString EnumName; // 0x38(0x10)
	uint8_t bIsEnumNameValid : 1; // 0x48(0x1), Mask(0x1)
	uint8_t BitPad_0x48_1 : 7; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: Class AIModule.BlackboardKeyType_Float
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Float : UBlackboardKeyType
{
};

// Object: Class AIModule.BlackboardKeyType_Int
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Int : UBlackboardKeyType
{
};

// Object: Class AIModule.BlackboardKeyType_Name
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Name : UBlackboardKeyType
{
};

// Object: Class AIModule.BlackboardKeyType_NativeEnum
// Size: 0x48 (Inherited: 0x30)
struct UBlackboardKeyType_NativeEnum : UBlackboardKeyType
{
	struct FString EnumName; // 0x30(0x10)
	struct UEnum* EnumType; // 0x40(0x8)
};

// Object: Class AIModule.BlackboardKeyType_Object
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Object : UBlackboardKeyType
{
	struct UObject* BaseClass; // 0x30(0x8)
};

// Object: Class AIModule.BlackboardKeyType_Rotator
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Rotator : UBlackboardKeyType
{
};

// Object: Class AIModule.BlackboardKeyType_String
// Size: 0x40 (Inherited: 0x30)
struct UBlackboardKeyType_String : UBlackboardKeyType
{
	struct FString StringValue; // 0x30(0x10)
};

// Object: Class AIModule.BlackboardKeyType_Vector
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Vector : UBlackboardKeyType
{
};

// Object: Class AIModule.BTCompositeNode
// Size: 0x90 (Inherited: 0x58)
struct UBTCompositeNode : UBTNode
{
	struct TArray<struct FBTCompositeChild> Children; // 0x58(0x10)
	struct TArray<struct UBTService*> Services; // 0x68(0x10)
	uint8_t Pad_0x78[0x18]; // 0x78(0x18)
};

// Object: Class AIModule.BTComposite_Selector
// Size: 0x90 (Inherited: 0x90)
struct UBTComposite_Selector : UBTCompositeNode
{
};

// Object: Class AIModule.BTComposite_Sequence
// Size: 0x90 (Inherited: 0x90)
struct UBTComposite_Sequence : UBTCompositeNode
{
};

// Object: Class AIModule.BTComposite_SimpleParallel
// Size: 0x90 (Inherited: 0x90)
struct UBTComposite_SimpleParallel : UBTCompositeNode
{
	enum class EBTParallelMode FinishMode; // 0x8B(0x1)
};

// Object: Class AIModule.BTDecorator_Blackboard
// Size: 0xB8 (Inherited: 0x88)
struct UBTDecorator_Blackboard : UBTDecorator_BlackboardBase
{
	int IntValue; // 0x88(0x4)
	float FloatValue; // 0x8C(0x4)
	struct FString StringValue; // 0x90(0x10)
	struct FString CachedDescription; // 0xA0(0x10)
	uint8_t OperationType; // 0xB0(0x1)
	enum class EBTBlackboardRestart NotifyObserver; // 0xB1(0x1)
	uint8_t Pad_0xB2[0x6]; // 0xB2(0x6)
};

// Object: Class AIModule.BTDecorator_BlueprintBase
// Size: 0x98 (Inherited: 0x60)
struct UBTDecorator_BlueprintBase : UBTDecorator
{
	struct AAIController* AIOwner; // 0x60(0x8)
	struct AActor* ActorOwner; // 0x68(0x8)
	struct TArray<struct FName> ObservedKeyNames; // 0x70(0x10)
	uint8_t Pad_0x80[0x10]; // 0x80(0x10)
	uint8_t bShowPropertyDetails : 1; // 0x90(0x1), Mask(0x1)
	uint8_t bCheckConditionOnlyBlackBoardChanges : 1; // 0x90(0x1), Mask(0x2)
	uint8_t bIsObservingBB : 1; // 0x90(0x1), Mask(0x4)
	uint8_t BitPad_0x90_3 : 5; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)


	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverDeactivated(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverActivated(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveExecutionStart(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	void ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult NodeResult);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	bool PerformConditionCheck(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105edc180
	// Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorObserverActive();
	// [Call #1] RVA: 0x105E71228
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105edc14c
	// Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorExecutionActive();
	// [Call #1] RVA: 0x105E711D4
	// [Call #2] RVA: 0x105E71228
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// Size: 0xC0 (Inherited: 0x60)
struct UBTDecorator_CheckGameplayTagsOnActor : UBTDecorator
{
	struct FBlackboardKeySelector ActorToCheck; // 0x60(0x28)
	uint8_t TagsToMatch; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
	struct FGameplayTagContainer GameplayTags; // 0x90(0x20)
	struct FString CachedDescription; // 0xB0(0x10)
};

// Object: Class AIModule.BTDecorator_CompareBBEntries
// Size: 0xB0 (Inherited: 0x60)
struct UBTDecorator_CompareBBEntries : UBTDecorator
{
	enum class EBlackBoardEntryComparison Operator; // 0x5A(0x1)
	struct FBlackboardKeySelector BlackboardKeyA; // 0x60(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x88(0x28)
};

// Object: Class AIModule.BTDecorator_ConditionalLoop
// Size: 0xB8 (Inherited: 0xB8)
struct UBTDecorator_ConditionalLoop : UBTDecorator_Blackboard
{
};

// Object: Class AIModule.BTDecorator_ConeCheck
// Size: 0xE0 (Inherited: 0x60)
struct UBTDecorator_ConeCheck : UBTDecorator
{
	float ConeHalfAngle; // 0x5C(0x4)
	struct FBlackboardKeySelector ConeOrigin; // 0x60(0x28)
	struct FBlackboardKeySelector ConeDirection; // 0x88(0x28)
	struct FBlackboardKeySelector Observed; // 0xB0(0x28)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
};

// Object: Class AIModule.BTDecorator_DoesPathExist
// Size: 0xC0 (Inherited: 0x60)
struct UBTDecorator_DoesPathExist : UBTDecorator
{
	struct FBlackboardKeySelector BlackboardKeyA; // 0x60(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x88(0x28)
	uint8_t bUseSelf : 1; // 0xB0(0x1), Mask(0x1)
	uint8_t BitPad_0xB0_1 : 7; // 0xB0(0x1)
	enum class EPathExistanceQueryType PathQueryType; // 0xB1(0x1)
	uint8_t Pad_0xB2[0x6]; // 0xB2(0x6)
	struct UNavigationQueryFilter* FilterClass; // 0xB8(0x8)
};

// Object: Class AIModule.BTDecorator_ForceSuccess
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_ForceSuccess : UBTDecorator
{
};

// Object: Class AIModule.BTDecorator_IsAtLocation
// Size: 0xC8 (Inherited: 0x88)
struct UBTDecorator_IsAtLocation : UBTDecorator_BlackboardBase
{
	float AcceptableRadius; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
	struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x90(0x30)
	uint8_t GeometricDistanceType; // 0xC0(0x1)
	uint8_t bUseParametrizedRadius : 1; // 0xC1(0x1), Mask(0x1)
	uint8_t bUseNavAgentGoalLocation : 1; // 0xC1(0x1), Mask(0x2)
	uint8_t bPathFindingBasedTest : 1; // 0xC1(0x1), Mask(0x4)
	uint8_t BitPad_0xC1_3 : 5; // 0xC1(0x1)
	uint8_t Pad_0xC2[0x6]; // 0xC2(0x6)
};

// Object: Class AIModule.BTDecorator_IsBBEntryOfClass
// Size: 0x90 (Inherited: 0x88)
struct UBTDecorator_IsBBEntryOfClass : UBTDecorator_BlackboardBase
{
	struct UObject* TestClass; // 0x88(0x8)
};

// Object: Class AIModule.BTDecorator_KeepInCone
// Size: 0xB8 (Inherited: 0x60)
struct UBTDecorator_KeepInCone : UBTDecorator
{
	float ConeHalfAngle; // 0x5C(0x4)
	struct FBlackboardKeySelector ConeOrigin; // 0x60(0x28)
	struct FBlackboardKeySelector Observed; // 0x88(0x28)
	uint8_t bUseSelfAsOrigin : 1; // 0xB0(0x1), Mask(0x1)
	uint8_t bUseSelfAsObserved : 1; // 0xB0(0x1), Mask(0x2)
	uint8_t BitPad_0xB4_2 : 6; // 0xB4(0x1)
	uint8_t Pad_0xB5[0x3]; // 0xB5(0x3)
};

// Object: Class AIModule.BTDecorator_Loop
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator_Loop : UBTDecorator
{
	int NumLoops; // 0x5C(0x4)
	bool bInfiniteLoop; // 0x60(0x1)
	float InfiniteLoopTimeoutTime; // 0x64(0x4)
};

// Object: Class AIModule.BTDecorator_ReachedMoveGoal
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_ReachedMoveGoal : UBTDecorator
{
};

// Object: Class AIModule.BTDecorator_SetTagCooldown
// Size: 0x70 (Inherited: 0x60)
struct UBTDecorator_SetTagCooldown : UBTDecorator
{
	struct FGameplayTag CooldownTag; // 0x60(0x8)
	float CooldownDuration; // 0x68(0x4)
	bool bAddToExistingDuration; // 0x6C(0x1)
	uint8_t Pad_0x6D[0x3]; // 0x6D(0x3)
};

// Object: Class AIModule.BTDecorator_TagCooldown
// Size: 0x70 (Inherited: 0x60)
struct UBTDecorator_TagCooldown : UBTDecorator
{
	struct FGameplayTag CooldownTag; // 0x60(0x8)
	float CooldownDuration; // 0x68(0x4)
	bool bAddToExistingDuration; // 0x6C(0x1)
	bool bActivatesCooldown; // 0x6D(0x1)
	uint8_t Pad_0x6E[0x2]; // 0x6E(0x2)
};

// Object: Class AIModule.BTDecorator_TimeLimit
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_TimeLimit : UBTDecorator
{
	float TimeLimit; // 0x5C(0x4)
};

// Object: Class AIModule.BTFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBTFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ee2284
	// Params: [ Num(1) Size(0x8) ]
	void StopUsingExternalEvent(struct UBTNode* NodeOwner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6EB08
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ee21d8
	// Params: [ Num(2) Size(0x10) ]
	void StartUsingExternalEvent(struct UBTNode* NodeOwner, struct AActor* OwningActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6EB04
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E6EB08
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ee20ac
	// Params: [ Num(3) Size(0x3C) ]
	void SetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FVector Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E934
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E6EB04
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E6EB08

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1f1c
	// Params: [ Num(3) Size(0x40) ]
	void SetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x105E6E78C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102248B48
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x102248B48
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ee1df0
	// Params: [ Num(3) Size(0x3C) ]
	void SetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FRotator Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6EA1C
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x105E6E78C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1cc4
	// Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E4F0
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6EA1C
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1b98
	// Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FName Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E8C8
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E4F0
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1a6c
	// Params: [ Num(3) Size(0x34) ]
	void SetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E634
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E8C8
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1940
	// Params: [ Num(3) Size(0x34) ]
	void SetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E6A0
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E634
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee1814
	// Params: [ Num(3) Size(0x31) ]
	void SetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, uint8_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E5C8
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E6A0
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee16e8
	// Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E55C
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E5C8
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee15b4
	// Params: [ Num(3) Size(0x31) ]
	void SetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E6E720
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x102248B48
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E6E55C
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x102248B48

	// Object: Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee1538
	// Params: [ Num(2) Size(0x10) ]
	struct UBlackboardComponent* GetOwnersBlackboard(struct UBTNode* NodeOwner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6E274
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E6E720
	// [Call #11] RVA: 0x102248B48
	// [Call #12] RVA: 0x102248B48
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetOwnerComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee14bc
	// Params: [ Num(2) Size(0x10) ]
	struct UBehaviorTreeComponent* GetOwnerComponent(struct UBTNode* NodeOwner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E6E224
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E6E274
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E720
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee13c4
	// Params: [ Num(3) Size(0x3C) ]
	struct FVector GetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E470
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E6E224
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105E6E274
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee12ac
	// Params: [ Num(3) Size(0x40) ]
	struct FString GetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E3FC
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x102248B48
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x102248B48
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E6E470
	// [Call #17] RVA: 0x102248B48
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee11b4
	// Params: [ Num(3) Size(0x3C) ]
	struct FRotator GetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E4B0
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E3FC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x102248B48
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x102248B48
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee10c4
	// Params: [ Num(3) Size(0x38) ]
	struct UObject* GetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E290
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E4B0
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0fd0
	// Params: [ Num(3) Size(0x38) ]
	struct FName GetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E43C
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E290
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0ee0
	// Params: [ Num(3) Size(0x34) ]
	int GetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E35C
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E43C
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0df0
	// Params: [ Num(3) Size(0x34) ]
	float GetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E390
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E35C
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0d00
	// Params: [ Num(3) Size(0x31) ]
	uint8_t GetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E328
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E390
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0c10
	// Params: [ Num(3) Size(0x38) ]
	struct UObject* GetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E2F4
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E328
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0b20
	// Params: [ Num(3) Size(0x31) ]
	bool GetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E3C8
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E2F4
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee0a30
	// Params: [ Num(3) Size(0x38) ]
	struct AActor* GetBlackboardValueAsActor(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E2C4
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E3C8
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee0948
	// Params: [ Num(2) Size(0x30) ]
	void ClearBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6E9E8
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E2C4
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AIModule.BTFunctionLibrary.ClearBlackboardValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ee0860
	// Params: [ Num(2) Size(0x30) ]
	void ClearBlackboardValue(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E6EAD0
	// [Call #6] RVA: 0x102248B48
	// [Call #7] RVA: 0x102248B48
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E6E9E8
	// [Call #14] RVA: 0x102248B48
	// [Call #15] RVA: 0x102248B48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class AIModule.BTService_BlueprintBase
// Size: 0x90 (Inherited: 0x68)
struct UBTService_BlueprintBase : UBTService
{
	struct AAIController* AIOwner; // 0x68(0x8)
	struct AActor* ActorOwner; // 0x70(0x8)
	uint8_t Pad_0x78[0x10]; // 0x78(0x10)
	uint8_t bShowPropertyDetails : 1; // 0x88(0x1), Mask(0x1)
	uint8_t bShowEventDetails : 1; // 0x88(0x1), Mask(0x2)
	uint8_t BitPad_0x88_2 : 6; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)


	// Object: Function AIModule.BTService_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveSearchStart(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveDeactivation(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveActivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveActivation(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTService_BlueprintBase.IsServiceActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ee30e0
	// Params: [ Num(1) Size(0x1) ]
	bool IsServiceActive();
	// [Call #1] RVA: 0x105E7F0FC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class AIModule.BTService_RunEQS
// Size: 0xE8 (Inherited: 0x90)
struct UBTService_RunEQS : UBTService_BlackboardBase
{
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x90(0x48)
	uint8_t Pad_0xD8[0x10]; // 0xD8(0x10)
};

// Object: Class AIModule.BTTask_BlueprintBase
// Size: 0xA0 (Inherited: 0x70)
struct UBTTask_BlueprintBase : UBTTaskNode
{
	struct AAIController* AIOwner; // 0x70(0x8)
	struct AActor* ActorOwner; // 0x78(0x8)
	uint8_t Pad_0x80[0x18]; // 0x80(0x18)
	uint8_t bShowPropertyDetails : 1; // 0x98(0x1), Mask(0x1)
	uint8_t BitPad_0x98_1 : 7; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)


	// Object: Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105ee3b50
	// Params: [ Num(2) Size(0xC) ]
	void SetFinishOnMessageWithId(struct FName MessageName, int RequestID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E80FAC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105ee3ad4
	// Params: [ Num(1) Size(0x8) ]
	void SetFinishOnMessage(struct FName MessageName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E80F54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E80FAC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveExecute(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveAbort(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ee3aa0
	// Params: [ Num(1) Size(0x1) ]
	bool IsTaskExecuting();
	// [Call #1] RVA: 0x105E80EFC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E80F54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E80FAC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.BTTask_BlueprintBase.IsTaskAborting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ee3a6c
	// Params: [ Num(1) Size(0x1) ]
	bool IsTaskAborting();
	// [Call #1] RVA: 0x105E80F48
	// [Call #2] RVA: 0x105E80EFC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E80F54
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E80FAC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AIModule.BTTask_BlueprintBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105ee39e8
	// Params: [ Num(1) Size(0x1) ]
	void FinishExecute(bool bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E80E24
	// [Call #4] RVA: 0x105E80F48
	// [Call #5] RVA: 0x105E80EFC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E80F54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E80FAC
	// [Call #14] RVA: 0x10519022C

	// Object: Function AIModule.BTTask_BlueprintBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105ee39d4
	// Params: [ Num(0) Size(0x0) ]
	void FinishAbort();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E80E24
	// [Call #4] RVA: 0x105E80F48
	// [Call #5] RVA: 0x105E80EFC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E80F54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E80FAC
};

// Object: Class AIModule.BTTask_GameplayTaskBase
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_GameplayTaskBase : UBTTaskNode
{
	uint8_t bWaitForGameplayTask : 1; // 0x69(0x1), Mask(0x1)
};

// Object: Class AIModule.BTTask_MakeNoise
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_MakeNoise : UBTTaskNode
{
	float Loudnes; // 0x6C(0x4)
};

// Object: Class AIModule.BTTask_PawnActionBase
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_PawnActionBase : UBTTaskNode
{
};

// Object: Class AIModule.BTTask_PlayAnimation
// Size: 0xB0 (Inherited: 0x70)
struct UBTTask_PlayAnimation : UBTTaskNode
{
	struct UAnimationAsset* AnimationToPlay; // 0x70(0x8)
	uint8_t bLooping : 1; // 0x78(0x1), Mask(0x1)
	uint8_t bNonBlocking : 1; // 0x78(0x1), Mask(0x2)
	uint8_t BitPad_0x78_2 : 6; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
	struct UBehaviorTreeComponent* MyOwnerComp; // 0x80(0x8)
	struct USkeletalMeshComponent* CachedSkelMesh; // 0x88(0x8)
	uint8_t Pad_0x90[0x20]; // 0x90(0x20)
};

// Object: Class AIModule.BTTask_PlaySound
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PlaySound : UBTTaskNode
{
	struct USoundCue* SoundToPlay; // 0x70(0x8)
};

// Object: Class AIModule.BTTask_PushPawnAction
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PushPawnAction : UBTTask_PawnActionBase
{
	struct UPawnAction* Action; // 0x70(0x8)
};

// Object: Class AIModule.BTTask_RotateToFaceBBEntry
// Size: 0xA0 (Inherited: 0x98)
struct UBTTask_RotateToFaceBBEntry : UBTTask_BlackboardBase
{
	float Precision; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
};

// Object: Class AIModule.BTTask_RunBehavior
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_RunBehavior : UBTTaskNode
{
	struct UBehaviorTree* BehaviorAsset; // 0x70(0x8)
};

// Object: Class AIModule.BTTask_RunBehaviorDynamic
// Size: 0x88 (Inherited: 0x70)
struct UBTTask_RunBehaviorDynamic : UBTTaskNode
{
	struct FGameplayTag InjectionTag; // 0x70(0x8)
	struct UBehaviorTree* DefaultBehaviorAsset; // 0x78(0x8)
	struct UBehaviorTree* BehaviorAsset; // 0x80(0x8)
};

// Object: Class AIModule.BTTask_RunEQSQuery
// Size: 0x150 (Inherited: 0x98)
struct UBTTask_RunEQSQuery : UBTTask_BlackboardBase
{
	struct UEnvQuery* QueryTemplate; // 0x98(0x8)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0xA0(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0xB0(0x10)
	enum class EEnvQueryRunMode RunMode; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x7]; // 0xC1(0x7)
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0xC8(0x28)
	bool bUseBBKey; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x7]; // 0xF1(0x7)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xF8(0x48)
	uint8_t Pad_0x140[0x10]; // 0x140(0x10)
};

// Object: Class AIModule.BTTask_SetTagCooldown
// Size: 0x80 (Inherited: 0x70)
struct UBTTask_SetTagCooldown : UBTTaskNode
{
	struct FGameplayTag CooldownTag; // 0x70(0x8)
	bool bAddToExistingDuration; // 0x78(0x1)
	uint8_t Pad_0x79[0x3]; // 0x79(0x3)
	float CooldownDuration; // 0x7C(0x4)
};

// Object: Class AIModule.BTTask_WaitBlackboardTime
// Size: 0xA0 (Inherited: 0x78)
struct UBTTask_WaitBlackboardTime : UBTTask_Wait
{
	struct FBlackboardKeySelector BlackboardKey; // 0x78(0x28)
};

// Object: Class AIModule.CrowdAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct ICrowdAgentInterface : IInterface
{
};

// Object: Class AIModule.DetourCrowdAIController
// Size: 0x5B8 (Inherited: 0x5B8)
struct ADetourCrowdAIController : AAIController
{
};

// Object: Class AIModule.EnvQuery
// Size: 0x48 (Inherited: 0x30)
struct UEnvQuery : UDataAsset
{
	struct FName QueryName; // 0x30(0x8)
	struct TArray<struct UEnvQueryOption*> Options; // 0x38(0x10)
};

// Object: Class AIModule.EnvQueryContext
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext : UObject
{
};

// Object: Class AIModule.EnvQueryContext_BlueprintBase
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryContext_BlueprintBase : UEnvQueryContext
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x1C) ]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x18) ]
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class AIModule.EnvQueryContext_Item
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Item : UEnvQueryContext
{
};

// Object: Class AIModule.EnvQueryContext_Querier
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Querier : UEnvQueryContext
{
};

// Object: Class AIModule.EnvQueryDebugHelpers
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryDebugHelpers : UObject
{
};

// Object: Class AIModule.EnvQueryNode
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryNode : UObject
{
	int VerNum; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class AIModule.EnvQueryGenerator
// Size: 0x50 (Inherited: 0x30)
struct UEnvQueryGenerator : UEnvQueryNode
{
	struct FString OptionName; // 0x30(0x10)
	struct UEnvQueryItemType* itemType; // 0x40(0x8)
	uint8_t bAutoSortTests : 1; // 0x48(0x1), Mask(0x1)
	uint8_t BitPad_0x48_1 : 7; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: Class AIModule.EnvQueryGenerator_ActorsOfClass
// Size: 0xC0 (Inherited: 0x50)
struct UEnvQueryGenerator_ActorsOfClass : UEnvQueryGenerator
{
	struct AActor* SearchedActorClass; // 0x50(0x8)
	struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0x58(0x30)
	struct FAIDataProviderFloatValue SearchRadius; // 0x88(0x30)
	struct UEnvQueryContext* SearchCenter; // 0xB8(0x8)
};

// Object: Class AIModule.EnvQueryGenerator_BlueprintBase
// Size: 0x80 (Inherited: 0x50)
struct UEnvQueryGenerator_BlueprintBase : UEnvQueryGenerator
{
	struct FText GeneratorsActionDescription; // 0x50(0x18)
	struct UEnvQueryContext* Context; // 0x68(0x8)
	struct UEnvQueryItemType* GeneratedItemType; // 0x70(0x8)
	uint8_t Pad_0x78[0x8]; // 0x78(0x8)


	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ee892c
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetQuerier();
	// [Call #1] RVA: 0x105E94480
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void DoItemGeneration(struct TArray<struct FVector>& ContextLocations);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|Const]
	// Offset: 0x105ee88b0
	// Params: [ Num(1) Size(0xC) ]
	void AddGeneratedVector(struct FVector GeneratedVector);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E9416C
	// [Call #4] RVA: 0x105E94480
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x105ee8834
	// Params: [ Num(1) Size(0x8) ]
	void AddGeneratedActor(struct AActor* GeneratedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E942DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E9416C
	// [Call #7] RVA: 0x105E94480
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class AIModule.EnvQueryGenerator_Composite
// Size: 0x70 (Inherited: 0x50)
struct UEnvQueryGenerator_Composite : UEnvQueryGenerator
{
	struct TArray<struct UEnvQueryGenerator*> Generators; // 0x50(0x10)
	uint8_t bAllowDifferentItemTypes : 1; // 0x60(0x1), Mask(0x1)
	uint8_t bHasMatchingItemType : 1; // 0x60(0x1), Mask(0x2)
	uint8_t BitPad_0x60_2 : 6; // 0x60(0x1)
	uint8_t Pad_0x61[0x7]; // 0x61(0x7)
	struct UEnvQueryItemType* ForcedItemType; // 0x68(0x8)
};

// Object: Class AIModule.EnvQueryGenerator_ProjectedPoints
// Size: 0x80 (Inherited: 0x50)
struct UEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator
{
	struct FEnvTraceData ProjectionData; // 0x50(0x30)
};

// Object: Class AIModule.EnvQueryGenerator_Cone
// Size: 0x150 (Inherited: 0x80)
struct UEnvQueryGenerator_Cone : UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue AlignedPointsDistance; // 0x80(0x30)
	struct FAIDataProviderFloatValue ConeDegrees; // 0xB0(0x30)
	struct FAIDataProviderFloatValue AngleStep; // 0xE0(0x30)
	struct FAIDataProviderFloatValue Range; // 0x110(0x30)
	struct UEnvQueryContext* CenterActor; // 0x140(0x8)
	uint8_t bIncludeContextLocation : 1; // 0x148(0x1), Mask(0x1)
	uint8_t BitPad_0x148_1 : 7; // 0x148(0x1)
	uint8_t Pad_0x149[0x7]; // 0x149(0x7)
};

// Object: Class AIModule.EnvQueryGenerator_CurrentLocation
// Size: 0x58 (Inherited: 0x50)
struct UEnvQueryGenerator_CurrentLocation : UEnvQueryGenerator
{
	struct UEnvQueryContext* QueryContext; // 0x50(0x8)
};

// Object: Class AIModule.EnvQueryGenerator_Donut
// Size: 0x1A8 (Inherited: 0x80)
struct UEnvQueryGenerator_Donut : UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue InnerRadius; // 0x80(0x30)
	struct FAIDataProviderFloatValue OuterRadius; // 0xB0(0x30)
	struct FAIDataProviderIntValue NumberOfRings; // 0xE0(0x30)
	struct FAIDataProviderIntValue PointsPerRing; // 0x110(0x30)
	struct FEnvDirection ArcDirection; // 0x140(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x160(0x30)
	bool bUseSpiralPattern; // 0x190(0x1)
	uint8_t Pad_0x191[0x7]; // 0x191(0x7)
	struct UEnvQueryContext* Center; // 0x198(0x8)
	uint8_t bDefineArc : 1; // 0x1A0(0x1), Mask(0x1)
	uint8_t BitPad_0x1A0_1 : 7; // 0x1A0(0x1)
	uint8_t Pad_0x1A1[0x7]; // 0x1A1(0x7)
};

// Object: Class AIModule.EnvQueryGenerator_OnCircle
// Size: 0x1E8 (Inherited: 0x80)
struct UEnvQueryGenerator_OnCircle : UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue CircleRadius; // 0x80(0x30)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xB0(0x30)
	struct FAIDataProviderIntValue NumberOfPoints; // 0xE0(0x30)
	uint8_t PointOnCircleSpacingMethod; // 0x110(0x1)
	uint8_t Pad_0x111[0x7]; // 0x111(0x7)
	struct FEnvDirection ArcDirection; // 0x118(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x138(0x30)
	float AngleRadians; // 0x168(0x4)
	uint8_t Pad_0x16C[0x4]; // 0x16C(0x4)
	struct UEnvQueryContext* CircleCenter; // 0x170(0x8)
	bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x178(0x1)
	uint8_t Pad_0x179[0x7]; // 0x179(0x7)
	struct FAIDataProviderFloatValue CircleCenterZOffset; // 0x180(0x30)
	struct FEnvTraceData TraceData; // 0x1B0(0x30)
	uint8_t bDefineArc : 1; // 0x1E0(0x1), Mask(0x1)
	uint8_t BitPad_0x1E0_1 : 7; // 0x1E0(0x1)
	uint8_t Pad_0x1E1[0x7]; // 0x1E1(0x7)
};

// Object: Class AIModule.EnvQueryGenerator_SimpleGrid
// Size: 0xE8 (Inherited: 0x80)
struct UEnvQueryGenerator_SimpleGrid : UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue GridSize; // 0x80(0x30)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xB0(0x30)
	struct UEnvQueryContext* GenerateAround; // 0xE0(0x8)
};

// Object: Class AIModule.EnvQueryGenerator_PathingGrid
// Size: 0x150 (Inherited: 0xE8)
struct UEnvQueryGenerator_PathingGrid : UEnvQueryGenerator_SimpleGrid
{
	struct FAIDataProviderBoolValue PathToItem; // 0xE8(0x30)
	struct UNavigationQueryFilter* NavigationFilter; // 0x118(0x8)
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x120(0x30)
};

// Object: Class AIModule.EnvQueryInstanceBlueprintWrapper
// Size: 0x78 (Inherited: 0x28)
struct UEnvQueryInstanceBlueprintWrapper : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	int QueryID; // 0x30(0x4)
	uint8_t Pad_0x34[0x24]; // 0x34(0x24)
	struct UEnvQueryItemType* itemType; // 0x58(0x8)
	int OptionIndex; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct FScriptMulticastDelegate OnQueryFinishedEvent; // 0x68(0x10)


	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ee9730
	// Params: [ Num(2) Size(0xC) ]
	void SetNamedParam(struct FName ParamName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E8AD34
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee96cc
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetResultsAsLocations();
	// [Call #1] RVA: 0x105E8A8B8
	// [Call #2] RVA: 0x10246DCBC
	// [Call #3] RVA: 0x101F8C3A4
	// [Call #4] RVA: 0x101F8C3A4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E8AD34
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee9668
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetResultsAsActors();
	// [Call #1] RVA: 0x105E8A5D0
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105E8A8B8
	// [Call #7] RVA: 0x10246DCBC
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E8AD34
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x10519022C

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ee95dc
	// Params: [ Num(2) Size(0x8) ]
	float GetItemScore(int ItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E8A59C
	// [Call #4] RVA: 0x105E8A5D0
	// [Call #5] RVA: 0x10212ECFC
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x105E8A8B8
	// [Call #10] RVA: 0x10246DCBC
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E8AD34
	// [Call #19] RVA: 0x10519022C

	// Object: DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	void EQSQueryDoneSignature__DelegateSignature(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class AIModule.EnvQueryItemType
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryItemType : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: Class AIModule.EnvQueryItemType_VectorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_VectorBase : UEnvQueryItemType
{
};

// Object: Class AIModule.EnvQueryItemType_ActorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_ActorBase : UEnvQueryItemType_VectorBase
{
};

// Object: Class AIModule.EnvQueryItemType_Actor
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Actor : UEnvQueryItemType_ActorBase
{
};

// Object: Class AIModule.EnvQueryItemType_Direction
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Direction : UEnvQueryItemType_VectorBase
{
};

// Object: Class AIModule.EnvQueryItemType_Point
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Point : UEnvQueryItemType_VectorBase
{
};

// Object: Class AIModule.EnvQueryManager
// Size: 0x138 (Inherited: 0x28)
struct UEnvQueryManager : UObject
{
	uint8_t Pad_0x28[0x78]; // 0x28(0x78)
	struct TArray<struct FEnvQueryInstanceCache> InstanceCache; // 0xA0(0x10)
	struct TArray<struct UEnvQueryContext*> LocalContexts; // 0xB0(0x10)
	struct TArray<struct UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0xC0(0x10)
	uint8_t Pad_0xD0[0x54]; // 0xD0(0x54)
	float MaxAllowedTestingTime; // 0x124(0x4)
	bool bTestQueriesUsingBreadth; // 0x128(0x1)
	uint8_t Pad_0x129[0x3]; // 0x129(0x3)
	int QueryCountWarningThreshold; // 0x12C(0x4)
	double QueryCountWarningInterval; // 0x130(0x8)


	// Object: Function AIModule.EnvQueryManager.RunEQSQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105eea158
	// Params: [ Num(6) Size(0x30) ]
	struct UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, enum class EEnvQueryRunMode RunMode, struct UEnvQueryInstanceBlueprintWrapper* WrapperClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E8CA1C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x1051903D0
	// [Call #14] RVA: 0x105190870
};

// Object: Class AIModule.EnvQueryOption
// Size: 0x40 (Inherited: 0x28)
struct UEnvQueryOption : UObject
{
	struct UEnvQueryGenerator* Generator; // 0x28(0x8)
	struct TArray<struct UEnvQueryTest*> Tests; // 0x30(0x10)
};

// Object: Class AIModule.EnvQueryTest
// Size: 0x1C0 (Inherited: 0x30)
struct UEnvQueryTest : UEnvQueryNode
{
	int TestOrder; // 0x2C(0x4)
	enum class EEnvTestPurpose TestPurpose; // 0x30(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	struct FString TestComment; // 0x38(0x10)
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // 0x48(0x1)
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // 0x49(0x1)
	enum class EEnvTestFilterType FilterType; // 0x4A(0x1)
	uint8_t Pad_0x4B[0x5]; // 0x4B(0x5)
	struct FAIDataProviderBoolValue BoolValue; // 0x50(0x30)
	struct FAIDataProviderFloatValue FloatValueMin; // 0x80(0x30)
	struct FAIDataProviderFloatValue FloatValueMax; // 0xB0(0x30)
	uint8_t Pad_0xE0[0x1]; // 0xE0(0x1)
	enum class EEnvTestScoreEquation ScoringEquation; // 0xE1(0x1)
	enum class EEnvQueryTestClamping ClampMinType; // 0xE2(0x1)
	enum class EEnvQueryTestClamping ClampMaxType; // 0xE3(0x1)
	uint8_t NormalizationType; // 0xE4(0x1)
	uint8_t Pad_0xE5[0x3]; // 0xE5(0x3)
	struct FAIDataProviderFloatValue ScoreClampMin; // 0xE8(0x30)
	struct FAIDataProviderFloatValue ScoreClampMax; // 0x118(0x30)
	struct FAIDataProviderFloatValue ScoringFactor; // 0x148(0x30)
	struct FAIDataProviderFloatValue ReferenceValue; // 0x178(0x30)
	bool bDefineReferenceValue; // 0x1A8(0x1)
	uint8_t Pad_0x1A9[0xF]; // 0x1A9(0xF)
	uint8_t bWorkOnFloatValues : 1; // 0x1B8(0x1), Mask(0x1)
	uint8_t BitPad_0x1B8_1 : 7; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x7]; // 0x1B9(0x7)
};

// Object: Class AIModule.EnvQueryTest_Distance
// Size: 0x1C8 (Inherited: 0x1C0)
struct UEnvQueryTest_Distance : UEnvQueryTest
{
	enum class EEnvTestDistance TestMode; // 0x1B9(0x1)
	struct UEnvQueryContext* DistanceTo; // 0x1C0(0x8)
};

// Object: Class AIModule.EnvQueryTest_Dot
// Size: 0x208 (Inherited: 0x1C0)
struct UEnvQueryTest_Dot : UEnvQueryTest
{
	struct FEnvDirection LineA; // 0x1C0(0x20)
	struct FEnvDirection LineB; // 0x1E0(0x20)
	uint8_t TestMode; // 0x200(0x1)
	bool bAbsoluteValue; // 0x201(0x1)
	uint8_t Pad_0x202[0x6]; // 0x202(0x6)
};

// Object: Class AIModule.EnvQueryTest_GameplayTags
// Size: 0x230 (Inherited: 0x1C0)
struct UEnvQueryTest_GameplayTags : UEnvQueryTest
{
	struct FGameplayTagQuery TagQueryToMatch; // 0x1C0(0x48)
	bool bUpdatedToUseQuery; // 0x208(0x1)
	uint8_t TagsToMatch; // 0x209(0x1)
	uint8_t Pad_0x20A[0x6]; // 0x20A(0x6)
	struct FGameplayTagContainer GameplayTags; // 0x210(0x20)
};

// Object: Class AIModule.EnvQueryTest_Overlap
// Size: 0x1D8 (Inherited: 0x1C0)
struct UEnvQueryTest_Overlap : UEnvQueryTest
{
	struct FEnvOverlapData OverlapData; // 0x1BC(0x1C)
};

// Object: Class AIModule.EnvQueryTest_Pathfinding
// Size: 0x230 (Inherited: 0x1C0)
struct UEnvQueryTest_Pathfinding : UEnvQueryTest
{
	enum class EEnvTestPathfinding TestMode; // 0x1B9(0x1)
	struct UEnvQueryContext* Context; // 0x1C0(0x8)
	struct FAIDataProviderBoolValue PathFromContext; // 0x1C8(0x30)
	struct FAIDataProviderBoolValue SkipUnreachable; // 0x1F8(0x30)
	struct UNavigationQueryFilter* FilterClass; // 0x228(0x8)
};

// Object: Class AIModule.EnvQueryTest_PathfindingBatch
// Size: 0x260 (Inherited: 0x230)
struct UEnvQueryTest_PathfindingBatch : UEnvQueryTest_Pathfinding
{
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x230(0x30)
};

// Object: Class AIModule.EnvQueryTest_Project
// Size: 0x1F0 (Inherited: 0x1C0)
struct UEnvQueryTest_Project : UEnvQueryTest
{
	struct FEnvTraceData ProjectionData; // 0x1C0(0x30)
};

// Object: Class AIModule.EnvQueryTest_Random
// Size: 0x1C0 (Inherited: 0x1C0)
struct UEnvQueryTest_Random : UEnvQueryTest
{
};

// Object: Class AIModule.EnvQueryTest_Trace
// Size: 0x288 (Inherited: 0x1C0)
struct UEnvQueryTest_Trace : UEnvQueryTest
{
	struct FEnvTraceData TraceData; // 0x1C0(0x30)
	struct FAIDataProviderBoolValue TraceFromContext; // 0x1F0(0x30)
	struct FAIDataProviderFloatValue ItemHeightOffset; // 0x220(0x30)
	struct FAIDataProviderFloatValue ContextHeightOffset; // 0x250(0x30)
	struct UEnvQueryContext* Context; // 0x280(0x8)
};

// Object: Class AIModule.EnvQueryTypes
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryTypes : UObject
{
};

// Object: Class AIModule.EQSQueryResultSourceInterface
// Size: 0x28 (Inherited: 0x28)
struct IEQSQueryResultSourceInterface : IInterface
{
};

// Object: Class AIModule.EQSRenderingComponent
// Size: 0xA00 (Inherited: 0x9D0)
struct UEQSRenderingComponent : UPrimitiveComponent
{
	uint8_t Pad_0x9D0[0x30]; // 0x9D0(0x30)
};

// Object: Class AIModule.EQSTestingPawn
// Size: 0x950 (Inherited: 0x8F0)
struct AEQSTestingPawn : ACharacter
{
	struct UEnvQuery* QueryTemplate; // 0x8F0(0x8)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0x8F8(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x908(0x10)
	float TimeLimitPerStep; // 0x918(0x4)
	int StepToDebugDraw; // 0x91C(0x4)
	uint8_t HighlightMode; // 0x920(0x1)
	uint8_t bDrawLabels : 1; // 0x921(0x1), Mask(0x1)
	uint8_t bDrawFailedItems : 1; // 0x921(0x1), Mask(0x2)
	uint8_t bReRunQueryOnlyOnFinishedMove : 1; // 0x921(0x1), Mask(0x4)
	uint8_t bShouldBeVisibleInGame : 1; // 0x921(0x1), Mask(0x8)
	uint8_t bTickDuringGame : 1; // 0x921(0x1), Mask(0x10)
	uint8_t BitPad_0x921_5 : 3; // 0x921(0x1)
	enum class EEnvQueryRunMode QueryingMode; // 0x922(0x1)
	uint8_t Pad_0x923[0x2D]; // 0x923(0x2D)
};

// Object: Class AIModule.GenericTeamAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct IGenericTeamAgentInterface : IInterface
{
};

// Object: Class AIModule.GridPathAIController
// Size: 0x5B8 (Inherited: 0x5B8)
struct AGridPathAIController : AAIController
{
};

// Object: Class AIModule.GridPathFollowingComponent
// Size: 0x378 (Inherited: 0x348)
struct UGridPathFollowingComponent : UPathFollowingComponent
{
	struct UNavLocalGridManager* GridManager; // 0x348(0x8)
	uint8_t Pad_0x350[0x28]; // 0x350(0x28)
};

// Object: Class AIModule.NavFilter_AIControllerDefault
// Size: 0x48 (Inherited: 0x48)
struct UNavFilter_AIControllerDefault : UNavigationQueryFilter
{
};

// Object: Class AIModule.NavLocalGridManager
// Size: 0x58 (Inherited: 0x28)
struct UNavLocalGridManager : UObject
{
	uint8_t Pad_0x28[0x30]; // 0x28(0x30)


	// Object: Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ef0b68
	// Params: [ Num(3) Size(0xD) ]
	bool SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105EB3DFC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ef0a78
	// Params: [ Num(3) Size(0xD) ]
	void RemoveLocalNavigationGrid(struct UObject* WorldContextObject, int GridId, bool bRebuildGrids);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105EB3D70
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105EB3DFC
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ef08f4
	// Params: [ Num(5) Size(0x31) ]
	bool FindLocalNavigationGridPath(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct TArray<struct FVector>& PathPoints);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105EB3DAC
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ef073c
	// Params: [ Num(6) Size(0x28) ]
	int AddLocalNavigationGridForPoints(struct UObject* WorldContextObject, struct TArray<struct FVector>& Locations, int Radius2D, float Height, bool bRebuildGrids);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105EB39F8
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ef05b4
	// Params: [ Num(6) Size(0x24) ]
	int AddLocalNavigationGridForPoint(struct UObject* WorldContextObject, struct FVector& Location, int Radius2D, float Height, bool bRebuildGrids);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105EB3924
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ef03b8
	// Params: [ Num(8) Size(0x2C) ]
	int AddLocalNavigationGridForCapsule(struct UObject* WorldContextObject, struct FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int Radius2D, float Height, bool bRebuildGrids);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105EB3C74
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ef01b8
	// Params: [ Num(8) Size(0x3C) ]
	int AddLocalNavigationGridForBox(struct UObject* WorldContextObject, struct FVector& Location, struct FVector Extent, struct FRotator Rotation, int Radius2D, float Height, bool bRebuildGrids);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105EB3B48
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class AIModule.PawnAction
// Size: 0x98 (Inherited: 0x28)
struct UPawnAction : UObject
{
	struct UPawnAction* ChildAction; // 0x28(0x8)
	struct UPawnAction* ParentAction; // 0x30(0x8)
	struct UPawnActionsComponent* OwnerComponent; // 0x38(0x8)
	struct UObject* Instigator; // 0x40(0x8)
	struct UBrainComponent* BrainComp; // 0x48(0x8)
	uint8_t Pad_0x50[0x30]; // 0x50(0x30)
	uint8_t bAllowNewSameClassInstance : 1; // 0x80(0x1), Mask(0x1)
	uint8_t bReplaceActiveSameClassInstance : 1; // 0x80(0x1), Mask(0x2)
	uint8_t bShouldPauseMovement : 1; // 0x80(0x1), Mask(0x4)
	uint8_t bAlwaysNotifyOnFinished : 1; // 0x80(0x1), Mask(0x8)
	uint8_t BitPad_0x80_4 : 4; // 0x80(0x1)
	uint8_t Pad_0x81[0x17]; // 0x81(0x17)


	// Object: Function AIModule.PawnAction.GetActionPriority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ef17f8
	// Params: [ Num(1) Size(0x1) ]
	enum class EAIRequestPriority GetActionPriority();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10516EACC

	// Object: Function AIModule.PawnAction.Finish
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x105ef176c
	// Params: [ Num(1) Size(0x1) ]
	void Finish(enum class EPawnActionResult WithResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function AIModule.PawnAction.CreateActionInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ef16b8
	// Params: [ Num(3) Size(0x18) ]
	struct UPawnAction* CreateActionInstance(struct UObject* WorldContextObject, struct UPawnAction* ActionClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E57E1C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class AIModule.PawnAction_BlueprintBase
// Size: 0x98 (Inherited: 0x98)
struct UPawnAction_BlueprintBase : UPawnAction
{

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ActionTick(struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionStart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ActionStart(struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionResume
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ActionResume(struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionPause
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ActionPause(struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionFinished
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	void ActionFinished(struct APawn* ControlledPawn, enum class EPawnActionResult WithResult);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class AIModule.PawnAction_Move
// Size: 0xE8 (Inherited: 0x98)
struct UPawnAction_Move : UPawnAction
{
	struct AActor* GoalActor; // 0x98(0x8)
	struct FVector GoalLocation; // 0xA0(0xC)
	float AcceptableRadius; // 0xAC(0x4)
	struct UNavigationQueryFilter* FilterClass; // 0xB0(0x8)
	uint8_t bAllowStrafe : 1; // 0xB8(0x1), Mask(0x1)
	uint8_t bFinishOnOverlap : 1; // 0xB8(0x1), Mask(0x2)
	uint8_t bUsePathfinding : 1; // 0xB8(0x1), Mask(0x4)
	uint8_t bAllowPartialPath : 1; // 0xB8(0x1), Mask(0x8)
	uint8_t bProjectGoalToNavigation : 1; // 0xB8(0x1), Mask(0x10)
	uint8_t bUpdatePathToGoal : 1; // 0xB8(0x1), Mask(0x20)
	uint8_t bAbortChildActionOnPathChange : 1; // 0xB8(0x1), Mask(0x40)
	uint8_t BitPad_0xB8_7 : 1; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x2F]; // 0xB9(0x2F)
};

// Object: Class AIModule.PawnAction_Repeat
// Size: 0xB8 (Inherited: 0x98)
struct UPawnAction_Repeat : UPawnAction
{
	struct UPawnAction* ActionToRepeat; // 0x98(0x8)
	struct UPawnAction* RecentActionCopy; // 0xA0(0x8)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xA8(0x1)
	uint8_t Pad_0xA9[0xF]; // 0xA9(0xF)
};

// Object: Class AIModule.PawnAction_Sequence
// Size: 0xC0 (Inherited: 0x98)
struct UPawnAction_Sequence : UPawnAction
{
	struct TArray<struct UPawnAction*> ActionSequence; // 0x98(0x10)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x7]; // 0xA9(0x7)
	struct UPawnAction* RecentActionCopy; // 0xB0(0x8)
	uint8_t Pad_0xB8[0x8]; // 0xB8(0x8)
};

// Object: Class AIModule.PawnAction_Wait
// Size: 0xA8 (Inherited: 0x98)
struct UPawnAction_Wait : UPawnAction
{
	float TimeToWait; // 0x94(0x4)
	uint8_t Pad_0x9C[0xC]; // 0x9C(0xC)
};

// Object: Class AIModule.PawnActionsComponent
// Size: 0x1B0 (Inherited: 0x178)
struct UPawnActionsComponent : UActorComponent
{
	struct APawn* ControlledPawn; // 0x178(0x8)
	struct TArray<struct FPawnActionStack> ActionStacks; // 0x180(0x10)
	struct TArray<struct FPawnActionEvent> ActionEvents; // 0x190(0x10)
	struct UPawnAction* CurrentAction; // 0x1A0(0x8)
	uint8_t Pad_0x1A8[0x8]; // 0x1A8(0x8)


	// Object: Function AIModule.PawnActionsComponent.K2_PushAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ef26a8
	// Params: [ Num(4) Size(0x19) ]
	bool K2_PushAction(struct UPawnAction* NewAction, enum class EAIRequestPriority Priority, struct UObject* Instigator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5A264
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AIModule.PawnActionsComponent.K2_PerformAction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ef25b0
	// Params: [ Num(4) Size(0x12) ]
	bool K2_PerformAction(struct APawn* Pawn, struct UPawnAction* Action, enum class EAIRequestPriority Priority);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E5A2E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105E5A264
	// [Call #15] RVA: 0x10519022C

	// Object: Function AIModule.PawnActionsComponent.K2_ForceAbortAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ef2524
	// Params: [ Num(2) Size(0x9) ]
	enum class EPawnActionAbortState K2_ForceAbortAction(struct UPawnAction* ActionToAbort);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5A144
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E5A2E4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AIModule.PawnActionsComponent.K2_AbortAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ef2498
	// Params: [ Num(2) Size(0x9) ]
	enum class EPawnActionAbortState K2_AbortAction(struct UPawnAction* ActionToAbort);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E5A0B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E5A144
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E5A2E4
	// [Call #14] RVA: 0x10516D168
};

// Object: Class AIModule.PawnSensingComponent
// Size: 0x1C0 (Inherited: 0x178)
struct UPawnSensingComponent : UActorComponent
{
	float HearingThreshold; // 0x178(0x4)
	float LOSHearingThreshold; // 0x17C(0x4)
	float SightRadius; // 0x180(0x4)
	float SensingInterval; // 0x184(0x4)
	float HearingMaxSoundAge; // 0x188(0x4)
	uint8_t bEnableSensingUpdates : 1; // 0x18C(0x1), Mask(0x1)
	uint8_t bOnlySensePlayers : 1; // 0x18C(0x1), Mask(0x2)
	uint8_t bSeePawns : 1; // 0x18C(0x1), Mask(0x4)
	uint8_t bHearNoises : 1; // 0x18C(0x1), Mask(0x8)
	uint8_t BitPad_0x18C_4 : 4; // 0x18C(0x1)
	uint8_t Pad_0x18D[0xB]; // 0x18D(0xB)
	struct FScriptMulticastDelegate OnSeePawn; // 0x198(0x10)
	struct FScriptMulticastDelegate OnHearNoise; // 0x1A8(0x10)
	float PeripheralVisionAngle; // 0x1B8(0x4)
	float PeripheralVisionCosine; // 0x1BC(0x4)


	// Object: Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105ef2bfc
	// Params: [ Num(1) Size(0x1) ]
	void SetSensingUpdatesEnabled(bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function AIModule.PawnSensingComponent.SetSensingInterval
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105ef2b78
	// Params: [ Num(1) Size(0x4) ]
	void SetSensingInterval(float NewSensingInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105ef2af4
	// Params: [ Num(1) Size(0x4) ]
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SeePawnDelegate__DelegateSignature(struct APawn* Pawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x18) ]
	void HearNoiseDelegate__DelegateSignature(struct APawn* Instigator, struct FVector& Location, float Volume);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ef2ad8
	// Params: [ Num(1) Size(0x4) ]
	float GetPeripheralVisionCosine();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ef2abc
	// Params: [ Num(1) Size(0x4) ]
	float GetPeripheralVisionAngle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class AIModule.VisualLoggerExtension
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerExtension : UObject
{
};

