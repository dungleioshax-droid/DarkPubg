#pragma once

#include <cstdint>

// Object: Enum ZLevel.EMonsterSpawnSourceType
enum class EMonsterSpawnSourceType : uint8_t
{
	Default = 0,
	LevelData = 1,
	EventTrigger = 2,
	BossCall = 3,
	GMTest = 4,
	AirDrop = 5,
	MonsterSpawnAction = 6,
	ItemCall = 7,
	UserTrigger = 8,
	EMonsterSpawnSourceType_MAX = 9
};

// Object: Enum ZLevel.ELevelEndCondType
enum class ELevelEndCondType : uint8_t
{
	MonsterWaveEnd = 0,
	ELevelEndCondType_MAX = 1
};

// Object: Enum ZLevel.EGenerateType
enum class EGenerateType : uint8_t
{
	Random = 0,
	Nearest = 1,
	EGenerateType_MAX = 2
};

// Object: Enum ZLevel.EMonsterWaveEndCondType
enum class EMonsterWaveEndCondType : uint8_t
{
	AllMonsterDead = 0,
	SpecialMonsterDead = 1,
	MonsterNumLimit = 2,
	DurTimeLimit = 3,
	EMonsterWaveEndCondType_MAX = 4
};

// Object: ScriptStruct ZLevel.RoadPointInfo
// Size: 0x14 (Inherited: 0x0)
struct FRoadPointInfo
{
	int ID; // 0x0(0x4)
	int Radius; // 0x4(0x4)
	struct FVector pos; // 0x8(0xC)
};

// Object: ScriptStruct ZLevel.GameLevelDesc
// Size: 0x18 (Inherited: 0x0)
struct FGameLevelDesc
{
	int ChapterID; // 0x0(0x4)
	int LevelID; // 0x4(0x4)
	struct FString Desc; // 0x8(0x10)
};

// Object: ScriptStruct ZLevel.LevelData
// Size: 0xB8 (Inherited: 0x0)
struct FLevelData
{
	struct FGameLevelDesc LevelDesc; // 0x0(0x18)
	struct TArray<struct FString> TargetClassPaths; // 0x18(0x10)
	struct FString LeveDirectorFilePath; // 0x28(0x10)
	enum class ELevelEndCondType EndCondType; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FString EndCondPar; // 0x40(0x10)
	bool IsLastLevel; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	int DiffcultPerc; // 0x54(0x4)
	struct TArray<struct FVector> TaskPointLocations; // 0x58(0x10)
	struct TArray<struct FRelifePoint> PVERelifePointsInfo; // 0x68(0x10)
	struct TArray<struct FPVECircle> PVECircleInfo; // 0x78(0x10)
	struct TArray<struct FMonsterWave> MonsterWaveCfg; // 0x88(0x10)
	struct FVector pos; // 0x98(0xC)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct TArray<struct FLevelObjets> LevelAddObjs; // 0xA8(0x10)
};

// Object: ScriptStruct ZLevel.LevelObjets
// Size: 0x40 (Inherited: 0x0)
struct FLevelObjets
{
	struct UObject* Objects; // 0x0(0x8)
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FTransform Trans; // 0x10(0x30)
};

// Object: ScriptStruct ZLevel.MonsterWave
// Size: 0x38 (Inherited: 0x0)
struct FMonsterWave
{
	float WaveDelayTime; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FMonsterGroup> MonsterGroupList; // 0x8(0x10)
	struct FString Desc; // 0x18(0x10)
	enum class EMonsterWaveEndCondType EndCondType; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	int EndCondPar; // 0x2C(0x4)
	int ID; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct ZLevel.MonsterGroup
// Size: 0x50 (Inherited: 0x0)
struct FMonsterGroup
{
	struct FString Desc; // 0x0(0x10)
	enum class EGenerateType ChooseGroupSpotType; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	int NearPlayTeamIdx; // 0x14(0x4)
	struct TArray<struct UZMonsterSpotGroup*> SpotGroupChooseList; // 0x18(0x10)
	struct TArray<struct FMonsterSpotGroup> MonsterSpotGroupChooseList; // 0x28(0x10)
	struct TArray<struct FMonsterGeneratePlan> PlanList; // 0x38(0x10)
	int ID; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct ZLevel.MonsterGeneratePlan
// Size: 0x30 (Inherited: 0x0)
struct FMonsterGeneratePlan
{
	struct FString Desc; // 0x0(0x10)
	int PlanWeight; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FMonsterGenerateCfg> PlanDetail; // 0x18(0x10)
	int ID; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct ZLevel.MonsterGenerateCfg
// Size: 0x38 (Inherited: 0x0)
struct FMonsterGenerateCfg
{
	int MonsterID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Desc; // 0x8(0x10)
	uint8_t SpotType; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int MonsterNum; // 0x1C(0x4)
	float RandomGenerateDelayTime; // 0x20(0x4)
	int ReBornTimes; // 0x24(0x4)
	int RebornDelay; // 0x28(0x4)
	float GenerateDelayTime; // 0x2C(0x4)
	int ID; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct ZLevel.MonsterSpotGroup
// Size: 0x30 (Inherited: 0x0)
struct FMonsterSpotGroup
{
	struct FString Desc; // 0x0(0x10)
	struct FVector pos; // 0x10(0xC)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<struct FMonsterSpot> SpotList; // 0x20(0x10)
};

// Object: ScriptStruct ZLevel.MonsterSpot
// Size: 0x38 (Inherited: 0x0)
struct FMonsterSpot
{
	struct FString Desc; // 0x0(0x10)
	uint8_t MonsterSpotType; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	struct FVector pos; // 0x14(0xC)
	struct TArray<struct FRoadPointInfo> RoadPointList; // 0x20(0x10)
	uint8_t SpotRadius; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: ScriptStruct ZLevel.PVECircle
// Size: 0x18 (Inherited: 0x0)
struct FPVECircle
{
	int CircleID; // 0x0(0x4)
	struct FVector2D targetPos; // 0x4(0x8)
	float Radius; // 0xC(0x4)
	float MoveTime; // 0x10(0x4)
	float Pain; // 0x14(0x4)
};

// Object: ScriptStruct ZLevel.RelifePoint
// Size: 0x40 (Inherited: 0x0)
struct FRelifePoint
{
	int ID; // 0x0(0x4)
	bool IsActivePoint; // 0x4(0x1)
	uint8_t Pad_0x5[0xB]; // 0x5(0xB)
	struct FTransform Trans; // 0x10(0x30)
};

// Object: ScriptStruct ZLevel.MonsterGenerateInfo
// Size: 0x38 (Inherited: 0x0)
struct FMonsterGenerateInfo
{
	int MonsterID; // 0x0(0x4)
	int MonsterNum; // 0x4(0x4)
	int MonsterWaveID; // 0x8(0x4)
	struct FVector pos; // 0xC(0xC)
	int PosRadius; // 0x18(0x4)
	int ReBornTimes; // 0x1C(0x4)
	int RebornDelay; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<struct FRoadPointInfo> RoadPointList; // 0x28(0x10)
};

// Object: Class ZLevel.ZLevelData
// Size: 0x5A0 (Inherited: 0x4B0)
struct AZLevelData : AActor
{
	struct FGameLevelDesc LevelDesc; // 0x4B0(0x18)
	struct TArray<struct FString> TargetClassPaths; // 0x4C8(0x10)
	struct FString LeveDirectorFilePath; // 0x4D8(0x10)
	enum class ELevelEndCondType EndCondType; // 0x4E8(0x1)
	uint8_t Pad_0x4E9[0x7]; // 0x4E9(0x7)
	struct FString EndCondPar; // 0x4F0(0x10)
	bool IsLastLevel; // 0x500(0x1)
	uint8_t Pad_0x501[0x3]; // 0x501(0x3)
	int DiffcultPerc; // 0x504(0x4)
	struct TArray<struct UZPVECircle*> PVECircleConfigs; // 0x508(0x10)
	struct TArray<struct UZPVERelifePoint*> PVERelifePoints; // 0x518(0x10)
	struct TArray<struct UZMonsterSpotGroup*> MonsterSpotGroups; // 0x528(0x10)
	struct TArray<struct FVector> TaskPointLocations; // 0x538(0x10)
	struct TArray<struct FRelifePoint> PVERelifePointsInfo; // 0x548(0x10)
	struct TArray<struct FPVECircle> PVECircleInfo; // 0x558(0x10)
	struct TArray<struct FMonsterWave> MonsterWaveCfg; // 0x568(0x10)
	struct TArray<struct FLevelData> CfgList; // 0x578(0x10)
	struct TArray<struct FLevelObjets> LevelAddObjs; // 0x588(0x10)
	int CurComponentNameIndex; // 0x598(0x4)
	uint8_t Pad_0x59C[0x4]; // 0x59C(0x4)


	// Object: Function ZLevel.ZLevelData.ReBindLevelDataComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1069f361c
	// Params: [ Num(0) Size(0x0) ]
	void ReBindLevelDataComponent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x105190870

	// Object: Function ZLevel.ZLevelData.CheckMonsterSpotIsOnLand
	// Flags: [Final|Native|Public]
	// Offset: 0x1069f3568
	// Params: [ Num(2) Size(0x10) ]
	void CheckMonsterSpotIsOnLand(struct UZMonsterSpot* MonsterSpot, struct UZMonsterSpotGroup* SpotGroup);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069F1B6C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class ZLevel.ZSpotSceneComponent
// Size: 0x3A0 (Inherited: 0x3A0)
struct UZSpotSceneComponent : USceneComponent
{
};

// Object: Class ZLevel.ZMonsterRoadPoint
// Size: 0x3B0 (Inherited: 0x3A0)
struct UZMonsterRoadPoint : UZSpotSceneComponent
{
	int ID; // 0x39C(0x4)
	int Radius; // 0x3A0(0x4)
	uint8_t Pad_0x3A8[0x8]; // 0x3A8(0x8)
};

// Object: Class ZLevel.ZMonsterSpot
// Size: 0x3D0 (Inherited: 0x3A0)
struct UZMonsterSpot : UZSpotSceneComponent
{
	struct FString Desc; // 0x3A0(0x10)
	uint8_t MonsterSpotType; // 0x3B0(0x1)
	uint8_t Pad_0x3B1[0x7]; // 0x3B1(0x7)
	struct TArray<struct UZMonsterRoadPoint*> RoadPointList; // 0x3B8(0x10)
	uint8_t SpotRadius; // 0x3C8(0x1)
	uint8_t Pad_0x3C9[0x7]; // 0x3C9(0x7)
};

// Object: Class ZLevel.ZMonsterSpotGroup
// Size: 0x3C0 (Inherited: 0x3A0)
struct UZMonsterSpotGroup : USceneComponent
{
	struct FString Desc; // 0x3A0(0x10)
	struct TArray<struct UZMonsterSpot*> SpotList; // 0x3B0(0x10)
};

// Object: Class ZLevel.ZPVECircle
// Size: 0x3C0 (Inherited: 0x3A0)
struct UZPVECircle : UZSpotSceneComponent
{
	int CircleID; // 0x39C(0x4)
	struct FVector2D targetPos; // 0x3A0(0x8)
	float Radius; // 0x3A8(0x4)
	float MoveTime; // 0x3AC(0x4)
	float Pain; // 0x3B0(0x4)
	uint8_t Pad_0x3B8[0x8]; // 0x3B8(0x8)
};

// Object: Class ZLevel.ZPVERelifePoint
// Size: 0x3B0 (Inherited: 0x3A0)
struct UZPVERelifePoint : UZSpotSceneComponent
{
	int ID; // 0x39C(0x4)
	bool IsActivePoint; // 0x3A0(0x1)
	uint8_t Pad_0x3A5[0xB]; // 0x3A5(0xB)
};

