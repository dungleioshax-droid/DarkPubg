#pragma once

#include <cstdint>

// Object: ScriptStruct iTOP.iTOPResult
// Size: 0x40 (Inherited: 0x0)
struct FiTOPResult
{
	int imsdkRetCode; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString imsdkRetMsg; // 0x8(0x10)
	int thirdRetCode; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString thirdRetMsg; // 0x20(0x10)
	struct FString retExtraJson; // 0x30(0x10)
};

// Object: ScriptStruct iTOP.IMSDKQRCodeStatusResult
// Size: 0x58 (Inherited: 0x40)
struct FIMSDKQRCodeStatusResult : FiTOPResult
{
	int status; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString Channel; // 0x48(0x10)
};

// Object: ScriptStruct iTOP.IMSDKQRCodeResult
// Size: 0x80 (Inherited: 0x40)
struct FIMSDKQRCodeResult : FiTOPResult
{
	struct FString codeId; // 0x40(0x10)
	struct FString randStr; // 0x50(0x10)
	int nextAt; // 0x60(0x4)
	int expireAt; // 0x64(0x4)
	int createAt; // 0x68(0x4)
	int queryInterval; // 0x6C(0x4)
	struct FString codeData; // 0x70(0x10)
};

// Object: ScriptStruct iTOP.IMSDKWebVerifyResult
// Size: 0x50 (Inherited: 0x40)
struct FIMSDKWebVerifyResult : FiTOPResult
{
	struct FString captcha; // 0x40(0x10)
};

// Object: ScriptStruct iTOP.IMSDKUnifiedAccountResult
// Size: 0xE8 (Inherited: 0x40)
struct FIMSDKUnifiedAccountResult : FiTOPResult
{
	int Ret; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString retMsg; // 0x48(0x10)
	struct FString accountToken; // 0x58(0x10)
	struct FString UID; // 0x68(0x10)
	struct FString expireTime; // 0x78(0x10)
	int verifyCodeExpire; // 0x88(0x4)
	int isRegister; // 0x8C(0x4)
	int isSetPwd; // 0x90(0x4)
	int isReceiveEmail; // 0x94(0x4)
	struct FString emailAccount; // 0x98(0x10)
	struct FString phoneAccount; // 0xA8(0x10)
	struct FString phoneExtra; // 0xB8(0x10)
	int accountType; // 0xC8(0x4)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct FString phoneArea; // 0xD0(0x10)
	int sendType; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
};

// Object: ScriptStruct iTOP.IMSDKShortUrlResult
// Size: 0x50 (Inherited: 0x40)
struct FIMSDKShortUrlResult : FiTOPResult
{
	struct FString shortUrl; // 0x40(0x10)
};

// Object: ScriptStruct iTOP.iTOPFriendResult
// Size: 0x50 (Inherited: 0x40)
struct FiTOPFriendResult : FiTOPResult
{
	struct TArray<struct FiTOPFriendInfo> sameGameFriendList; // 0x40(0x10)
};

// Object: ScriptStruct iTOP.iTOPFriendInfo
// Size: 0x78 (Inherited: 0x0)
struct FiTOPFriendInfo
{
	struct FString OpenID; // 0x0(0x10)
	struct FString channelUserId; // 0x10(0x10)
	struct FString channelId; // 0x20(0x10)
	struct FString UserName; // 0x30(0x10)
	int Gender; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString pictureUrl; // 0x48(0x10)
	struct FString email; // 0x58(0x10)
	struct FString phone; // 0x68(0x10)
};

// Object: ScriptStruct iTOP.iTOPLoginResult
// Size: 0xF8 (Inherited: 0x40)
struct FiTOPLoginResult : FiTOPResult
{
	struct FString Channel; // 0x40(0x10)
	int channelId; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString channelToken; // 0x58(0x10)
	int channelTokenExpire; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct FString channelUserId; // 0x70(0x10)
	int GameID; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct FString Guid; // 0x88(0x10)
	struct FString guidUserBirthday; // 0x98(0x10)
	struct FString guidUserNick; // 0xA8(0x10)
	struct FString guidUserPortrait; // 0xB8(0x10)
	int guidUserSex; // 0xC8(0x4)
	int innerTokenExpire; // 0xCC(0x4)
	int isFirstLogin; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct FString innerToken; // 0xD8(0x10)
	struct FString OpenID; // 0xE8(0x10)
};

// Object: ScriptStruct iTOP.iTOPBindResult
// Size: 0x108 (Inherited: 0xF8)
struct FiTOPBindResult : FiTOPLoginResult
{
	struct TArray<struct FiTOPChannelInfo> bindInfoList; // 0xF8(0x10)
};

// Object: ScriptStruct iTOP.iTOPChannelInfo
// Size: 0x68 (Inherited: 0x40)
struct FiTOPChannelInfo : FiTOPResult
{
	int channelId; // 0x40(0x4)
	int Gender; // 0x44(0x4)
	struct FString pictureUrl; // 0x48(0x10)
	struct FString UserName; // 0x58(0x10)
};

// Object: ScriptStruct iTOP.iTOPNoticeResult
// Size: 0x58 (Inherited: 0x40)
struct FiTOPNoticeResult : FiTOPResult
{
	struct TArray<struct FiTOPNoticeInfo> noticesList; // 0x40(0x10)
	int noticesNum; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: ScriptStruct iTOP.iTOPNoticeInfo
// Size: 0xD0 (Inherited: 0x0)
struct FiTOPNoticeInfo
{
	struct FString stateCode; // 0x0(0x10)
	int noticeId; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString AppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	struct FString noticeUrl; // 0x38(0x10)
	int noticeScene; // 0x48(0x4)
	int noticeUpdateTime; // 0x4C(0x4)
	int noticeEndTime; // 0x50(0x4)
	int noticeStartTime; // 0x54(0x4)
	struct FString screenName; // 0x58(0x10)
	struct FString noticeLanguage; // 0x68(0x10)
	int noticeContentType; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	struct FString noticeTitle; // 0x80(0x10)
	struct FString noticeContent; // 0x90(0x10)
	struct TArray<struct FiTOPNoticePicInfo> noticePics; // 0xA0(0x10)
	struct FString noticeContentWebUrl; // 0xB0(0x10)
	struct FString ExtraJson; // 0xC0(0x10)
};

// Object: ScriptStruct iTOP.iTOPNoticePicInfo
// Size: 0x58 (Inherited: 0x0)
struct FiTOPNoticePicInfo
{
	int noticeId; // 0x0(0x4)
	int screenDir; // 0x4(0x4)
	struct FString PicUrl; // 0x8(0x10)
	struct FString picHash; // 0x18(0x10)
	struct FString picTitle; // 0x28(0x10)
	struct FString picSize; // 0x38(0x10)
	struct FString ExtraJson; // 0x48(0x10)
};

// Object: ScriptStruct iTOP.iTOPAuthMigrateResult
// Size: 0x68 (Inherited: 0x40)
struct FiTOPAuthMigrateResult : FiTOPResult
{
	struct FString migrateCode; // 0x40(0x10)
	int validTime; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<struct FiTOPAuthSNSInfo> snsInfoList; // 0x58(0x10)
};

// Object: ScriptStruct iTOP.iTOPAuthSNSInfo
// Size: 0x40 (Inherited: 0x0)
struct FiTOPAuthSNSInfo
{
	struct FString OpenID; // 0x0(0x10)
	int channelId; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString UserName; // 0x18(0x10)
	int Gender; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString pictureUrl; // 0x30(0x10)
};

// Object: ScriptStruct iTOP.iTOPGPSInfoResult
// Size: 0x70 (Inherited: 0x40)
struct FiTOPGPSInfoResult : FiTOPResult
{
	double longitude; // 0x40(0x8)
	double latitude; // 0x48(0x8)
	double horizontalAccuracyMeters; // 0x50(0x8)
	double verticalAccuracyMeters; // 0x58(0x8)
	struct FString locationProvider; // 0x60(0x10)
};

// Object: ScriptStruct iTOP.iTOPLbsResult
// Size: 0x100 (Inherited: 0x40)
struct FiTOPLbsResult : FiTOPResult
{
	int channelId; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString cityName; // 0x48(0x10)
	int cityNumber; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct FString countryName; // 0x60(0x10)
	int countryNumber; // 0x70(0x4)
	int GameID; // 0x74(0x4)
	struct FString Guid; // 0x78(0x10)
	struct FString guidToken; // 0x88(0x10)
	int guidTokenExpire; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct FString guidUserBirthday; // 0xA0(0x10)
	struct FString guidUserNick; // 0xB0(0x10)
	struct FString guidUserPortrait; // 0xC0(0x10)
	int guidUserSex; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct FString provinceName; // 0xD8(0x10)
	struct FString OpenID; // 0xE8(0x10)
	int provinceNumber; // 0xF8(0x4)
	uint8_t Pad_0xFC[0x4]; // 0xFC(0x4)
};

// Object: ScriptStruct iTOP.iTOPAuthResult
// Size: 0xB0 (Inherited: 0x40)
struct FiTOPAuthResult : FiTOPResult
{
	struct FString Channel; // 0x40(0x10)
	int channelId; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString DeviceID; // 0x58(0x10)
	int GameID; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct FString innerToken; // 0x70(0x10)
	int isFirstLogin; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct FString OpenID; // 0x88(0x10)
	int tokenExpireTime; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct TArray<struct FiTOPAuthSNSInfo> snsInfoList; // 0xA0(0x10)
};

// Object: ScriptStruct iTOP.iTOPAuthConnectResult
// Size: 0x90 (Inherited: 0x40)
struct FiTOPAuthConnectResult : FiTOPResult
{
	struct FString confirmCode; // 0x40(0x10)
	int channelId; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString OpenID; // 0x58(0x10)
	int Gender; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct FString UserName; // 0x70(0x10)
	struct FString pictureUrl; // 0x80(0x10)
};

// Object: ScriptStruct iTOP.iTOPWebViewStatusResult
// Size: 0x48 (Inherited: 0x40)
struct FiTOPWebViewStatusResult : FiTOPResult
{
	int stateCode; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct iTOP.iTOPWebViewTicketResult
// Size: 0x60 (Inherited: 0x40)
struct FiTOPWebViewTicketResult : FiTOPResult
{
	struct FString Ticket; // 0x40(0x10)
	struct FString Domain; // 0x50(0x10)
};

// Object: Class iTOP.FBHelper
// Size: 0x28 (Inherited: 0x28)
struct UFBHelper : UObject
{

	// Object: Function iTOP.FBHelper.DelayToSetAutoInitFacebookLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b220f0
	// Params: [ Num(1) Size(0x1) ]
	void DelayToSetAutoInitFacebookLog(bool IsAutoInit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B2876C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519077C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function iTOP.FBHelper.DelayToInitFacebookSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b22030
	// Params: [ Num(2) Size(0x2) ]
	void DelayToInitFacebookSDK(bool IsAutoInit, bool WithLaunchOption);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B28684
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B2876C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

