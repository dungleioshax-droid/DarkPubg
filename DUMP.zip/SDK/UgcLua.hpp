#pragma once

#include <cstdint>

// Object: Enum UgcLua.EEntityType
enum class EEntityType : uint8_t
{
	Invalid = 0,
	Timer = 1,
	Trigger = 2,
	TriggerGroup = 3,
	Component = 4,
	ComponentPreset = 5,
	LightComponent = 6,
	LightComponentPreset = 7,
	Region = 8,
	GameplayDevice = 9,
	GameplayDevicePreset = 10,
	PlayerState = 11,
	ArmedAICharacter = 12,
	MonsterCharacter = 13,
	PlayerPreset = 14,
	PlayerCharacterPreset = 15,
	ArmedAI = 16,
	ArmedAIPreset = 17,
	Monster = 18,
	MonsterPreset = 19,
	SkillPreset = 20,
	BuffPreset = 21,
	WeaponPreset = 22,
	WeatherPreset = 23,
	Item = 24,
	ItemPreset = 25,
	Vehicle = 26,
	VehiclePreset = 27,
	Effect = 28,
	EffectPreset = 29,
	Sound = 30,
	SoundPreset = 31,
	LogicObject = 32,
	LogicObjectPreset = 33,
	TriggerArea = 34,
	TriggerAreaPreset = 35,
	Marker = 36,
	Pickup = 37,
	PickupPreset = 38,
	ContestedItem = 39,
	ContestedItemPreset = 40,
	BankProduct = 41,
	BuildingInstance = 42,
	Skill = 43,
	Projectile = 44,
	ActorSkill = 45,
	Empower = 46,
	DropGroupPreset = 47,
	TreasurePreset = 48,
	NPC = 49,
	UObject = 50,
	__MAX = 51,
	EEntityType_MAX = 52
};

// Object: Enum UgcLua.EUGCLuaType
enum class EUGCLuaType : uint8_t
{
	LuaNiil = 0,
	Boolean = 1,
	Number = 2,
	String = 3,
	EUGCLuaType_MAX = 4
};

// Object: Class UgcLua.CreativeLuaVM
// Size: 0x440 (Inherited: 0x28)
struct UCreativeLuaVM : UObject
{
	uint64_t SuspendFrameCounter; // 0x28(0x8)
	uint64_t RunFrameCounter; // 0x30(0x8)
	int CostCheckInterval; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	double FrameExecuteTime; // 0x40(0x8)
	float FrameSuspendMaxDelay; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	double SuspendFrameExecuteTime; // 0x50(0x8)
	int CrossVMAPICost; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct UWorld* World; // 0x60(0x8)
	struct AWorldSettings* WorldSettings; // 0x68(0x8)
	uint8_t Pad_0x70[0x8]; // 0x70(0x8)
	bool bExitWhenFatalOccurs; // 0x78(0x1)
	bool bExecuting; // 0x79(0x1)
	bool bAbort; // 0x7A(0x1)
	uint8_t Pad_0x7B[0x1]; // 0x7B(0x1)
	int MaxLoopRunCount; // 0x7C(0x4)
	int MaxExecuteAPICount; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct FString LuaReturnFunctionName; // 0x88(0x10)
	struct FString RedirectorName; // 0x98(0x10)
	struct TMap<struct FString, double> ElapsedTimeMap; // 0xA8(0x50)
	struct TMap<struct FString, double> MaxElapsedTimeMap; // 0xF8(0x50)
	struct TMap<struct FString, int> CountBlockMap; // 0x148(0x50)
	uint8_t Pad_0x198[0xD0]; // 0x198(0xD0)
	bool bCanFreeze; // 0x268(0x1)
	uint8_t Pad_0x269[0x7]; // 0x269(0x7)
	DelegateProperty AtPanicDelegate; // 0x270(0x10)
	struct FScriptMulticastDelegate OnLineCommentDelegate; // 0x280(0x10)
	uint8_t Pad_0x290[0x10]; // 0x290(0x10)
	DelegateProperty CodeFinishDelegate; // 0x2A0(0x10)
	DelegateProperty CodeOutputDelegate; // 0x2B0(0x10)
	DelegateProperty HasEventToRunDelegate; // 0x2C0(0x10)
	DelegateProperty PrepareEventDelegate; // 0x2D0(0x10)
	DelegateProperty ExecuteDelayedDelegate; // 0x2E0(0x10)
	DelegateProperty CodePreExecuteDelegate; // 0x2F0(0x10)
	uint8_t Pad_0x300[0x20]; // 0x300(0x20)
	struct FString MainModule; // 0x320(0x10)
	struct FString EventHandlerName; // 0x330(0x10)
	struct TScriptInterface<Class> EntityInterface; // 0x340(0x10)
	uint8_t Pad_0x350[0xF0]; // 0x350(0xF0)


	// Object: Function UgcLua.CreativeLuaVM.Step
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537c10
	// Params: [ Num(0) Size(0x0) ]
	void Step();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeLuaVM.SetUGCLuaMemoryProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537b8c
	// Params: [ Num(1) Size(0x1) ]
	void SetUGCLuaMemoryProfile(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252C8C4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeLuaVM.SetUGCLuaMemoryAllocDebugPrint
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537b08
	// Params: [ Num(1) Size(0x1) ]
	void SetUGCLuaMemoryAllocDebugPrint(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252C8CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10252C8C4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeLuaVM.SetPerformanceLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537a84
	// Params: [ Num(1) Size(0x1) ]
	void SetPerformanceLog(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252B680
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10252C8CC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10252C8C4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function UgcLua.CreativeLuaVM.SetNowRC
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537a08
	// Params: [ Num(1) Size(0x4) ]
	void SetNowRC(int idx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252D8E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10252B680
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10252C8CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10252C8C4
	// [Call #13] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeLuaVM.SetCodeOutputDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x102537978
	// Params: [ Num(1) Size(0x10) ]
	void SetCodeOutputDelegate(DelegateProperty InDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252E1E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10252D8E8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10252B680
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10252C8CC
	// [Call #14] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.SetCodeFinishDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1025378e8
	// Params: [ Num(1) Size(0x10) ]
	void SetCodeFinishDelegate(DelegateProperty InDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252E1CC
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252E1E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252D8E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252B680
	// [Call #15] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.ResetUGCLuaMemoryProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025378d4
	// Params: [ Num(0) Size(0x0) ]
	void ResetUGCLuaMemoryProfile();
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252E1CC
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252E1E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252D8E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252B680

	// Object: Function UgcLua.CreativeLuaVM.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025378c0
	// Params: [ Num(0) Size(0x0) ]
	void Reset();
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252E1CC
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252E1E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252D8E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252B680

	// Object: Function UgcLua.CreativeLuaVM.RequireMain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025378ac
	// Params: [ Num(0) Size(0x0) ]
	void RequireMain();
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252E1CC
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252E1E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252D8E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252B680

	// Object: Function UgcLua.CreativeLuaVM.RegisterLuaFunctions
	// Flags: [Final|Native|Public]
	// Offset: 0x102537730
	// Params: [ Num(2) Size(0x20) ]
	void RegisterLuaFunctions(struct FString ModuleName, struct TArray<struct FString> OpenFunctions);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F86A94
	// [Call #7] RVA: 0x10252E1F4
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x101FD9E48
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10252E1CC

	// Object: Function UgcLua.CreativeLuaVM.RegisterLuaAPIStringValue
	// Flags: [Final|Native|Public]
	// Offset: 0x10253751c
	// Params: [ Num(3) Size(0x30) ]
	void RegisterLuaAPIStringValue(struct FString ModuleName, struct FString Name, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x10252E8A8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x101F8130C
	// [Call #29] RVA: 0x106C8459C
	// [Call #30] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.RegisterLuaAPINumberValue
	// Flags: [Final|Native|Public]
	// Offset: 0x102537360
	// Params: [ Num(3) Size(0x24) ]
	void RegisterLuaAPINumberValue(struct FString ModuleName, struct FString Name, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10252EA48
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.RegisterLuaAPIBoolValue
	// Flags: [Final|Native|Public]
	// Offset: 0x102537194
	// Params: [ Num(3) Size(0x21) ]
	void RegisterLuaAPIBoolValue(struct FString ModuleName, struct FString Name, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10252E744
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.RefreshLastCommentInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537180
	// Params: [ Num(0) Size(0x0) ]
	void RefreshLastCommentInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10252E744
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.PostInit
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102537164
	// Params: [ Num(0) Size(0x0) ]
	void PostInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10252E744
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.LogBlockExecuteTime
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1025370c4
	// Params: [ Num(1) Size(0x10) ]
	void LogBlockExecuteTime(struct FString blockId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x10252E744
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x101F8130C

	// Object: Function UgcLua.CreativeLuaVM.KillJob
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102537008
	// Params: [ Num(2) Size(0x5) ]
	void KillJob(int JobId, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252EF20
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.InitEditMods
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102536f60
	// Params: [ Num(1) Size(0x10) ]
	void InitEditMods(struct TArray<struct FString>& mods);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252F55C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252EF20
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function UgcLua.CreativeLuaVM.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536ee4
	// Params: [ Num(1) Size(0x4) ]
	void Init(int MemLimit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252B9B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10252F55C
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252EF20
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.GetUGCLuaBlockMemoryLiveBytes
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102536e3c
	// Params: [ Num(2) Size(0x14) ]
	int GetUGCLuaBlockMemoryLiveBytes(struct FString blockId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252C8D8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10252B9B8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10252F55C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.GetNowRC
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536e08
	// Params: [ Num(1) Size(0x4) ]
	int GetNowRC();
	// [Call #1] RVA: 0x10252A598
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10252C8D8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10252B9B8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10252F55C
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.GetMemoryUsed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536dd4
	// Params: [ Num(1) Size(0x4) ]
	int GetMemoryUsed();
	// [Call #1] RVA: 0x10252C8A8
	// [Call #2] RVA: 0x10252A598
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252C8D8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252B9B8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10252F55C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C

	// Object: Function UgcLua.CreativeLuaVM.GetLastCommentInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536d70
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLastCommentInfo();
	// [Call #1] RVA: 0x10252A878
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10252C8A8
	// [Call #7] RVA: 0x10252A598
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10252C8D8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10252B9B8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.FreezeGameTime
	// Flags: [Final|Native|Public]
	// Offset: 0x102536cec
	// Params: [ Num(1) Size(0x1) ]
	void FreezeGameTime(bool bCond);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252B484
	// [Call #4] RVA: 0x10252A878
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10252C8A8
	// [Call #10] RVA: 0x10252A598
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10252C8D8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeLuaVM.ExtractCurrentCode
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102536bec
	// Params: [ Num(2) Size(0x18) ]
	void ExtractCurrentCode(int& CodeIdx, struct FString& code);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252D8D4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252B484
	// [Call #12] RVA: 0x10252A878
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10252C8A8
	// [Call #18] RVA: 0x10252A598

	// Object: Function UgcLua.CreativeLuaVM.ExportUGCLuaMemoryProfileAsSluaStat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102536ae0
	// Params: [ Num(3) Size(0x21) ]
	bool ExportUGCLuaMemoryProfileAsSluaStat(struct FString FilePath, struct FString& outFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252C8E8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10252D8D4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.ExeCodeUntilSuspended
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536acc
	// Params: [ Num(0) Size(0x0) ]
	void ExeCodeUntilSuspended();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252C8E8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10252D8D4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.EnqueueCode
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025369c0
	// Params: [ Num(3) Size(0x18) ]
	int EnqueueCode(struct FString& RuntimeCode, int& CodeUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10252C3B0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10252C8E8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function UgcLua.CreativeLuaVM.DumpUGCLuaBlockMemoryProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253690c
	// Params: [ Num(2) Size(0x18) ]
	struct FString DumpUGCLuaBlockMemoryProfile(int TopN);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252C8E0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10252C3B0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function UgcLua.CreativeLuaVM.DescribeLuaThread
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025368a8
	// Params: [ Num(1) Size(0x10) ]
	struct FString DescribeLuaThread();
	// [Call #1] RVA: 0x10252BC04
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252C8E0
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10252C3B0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function UgcLua.CreativeLuaVM.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536894
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x10252BC04
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10252C8E0
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10252C3B0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function UgcLua.CreativeLuaVM.AllowRequire
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102536810
	// Params: [ Num(1) Size(0x1) ]
	void AllowRequire(bool bAllow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10252EBB4
	// [Call #4] RVA: 0x10252BC04
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10252C8E0
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class UgcLua.CreativeEntityInterface
// Size: 0x28 (Inherited: 0x28)
struct ICreativeEntityInterface : IInterface
{

	// Object: Function UgcLua.CreativeEntityInterface.UUID2UObject
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x1025360a4
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* UUID2UObject(int64_t& UUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeEntityInterface.UUID2Type
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535f60
	// Params: [ Num(4) Size(0xB) ]
	bool UUID2Type(int64_t& UUID, uint8_t& Type, uint8_t& SubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C

	// Object: Function UgcLua.CreativeEntityInterface.UUID2Key
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535ebc
	// Params: [ Num(2) Size(0xC) ]
	uint32_t UUID2Key(int64_t& UUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeEntityInterface.RemoveUUID
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535e28
	// Params: [ Num(1) Size(0x8) ]
	void RemoveUUID(int64_t& UUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeEntityInterface.GetInstanceObjectUUID
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535d84
	// Params: [ Num(2) Size(0x10) ]
	int64_t GetInstanceObjectUUID(int64_t& UUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeEntityInterface.CreateEntityIfNotExistsFromUObject
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535c58
	// Params: [ Num(4) Size(0x18) ]
	int64_t CreateEntityIfNotExistsFromUObject(struct UObject* Object, uint8_t& Type, uint8_t& SubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function UgcLua.CreativeEntityInterface.CreateEntityIfNotExistsFromKey
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102535b14
	// Params: [ Num(4) Size(0x10) ]
	int64_t CreateEntityIfNotExistsFromKey(uint32_t& Key, uint8_t& Type, uint8_t& SubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

