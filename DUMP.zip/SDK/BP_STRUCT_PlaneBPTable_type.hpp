#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_PlaneBPTable_type.BP_STRUCT_PlaneBPTable_type
// Size: 0x38 (Inherited: 0x0)
struct FBP_STRUCT_PlaneBPTable_type
{
	int ID_0_59EBC34020F2CB575FD7DA4501D5C5E4; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Path_1_6A746340179EA83F75000E8B05C45978; // 0x8(0x10)
	struct FString CName_2_5267910037561B4A1C0638D70C555B65; // 0x18(0x10)
	struct FString LobbyPath_3_11D881407290252D3B3DCF9705C20AE8; // 0x28(0x10)
};

