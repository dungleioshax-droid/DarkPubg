#pragma once

#include <cstdint>

// Object: Enum UAESharedModule.EUAEBlackboardType
enum class EUAEBlackboardType : uint8_t
{
	EBT_Object = 0,
	EBT_WeakObjectPtr = 1,
	EBT_Class = 2,
	EBT_Enum = 3,
	EBT_Int = 4,
	EBT_UInt = 5,
	EBT_Float = 6,
	EBT_Bool = 7,
	EBT_String = 8,
	EBT_Name = 9,
	EBT_Vector = 10,
	EBT_Rotator = 11,
	EBT_MAX = 12
};

// Object: ScriptStruct UAESharedModule.UAEBlackboardParameter
// Size: 0x98 (Inherited: 0x0)
struct FUAEBlackboardParameter
{
	struct FName Name; // 0x0(0x8)
	enum class EUAEBlackboardType Type; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FUAEBlackboardParameterDefaultValue DefaultValue; // 0x10(0x88)
};

// Object: ScriptStruct UAESharedModule.UAEBlackboardParameterDefaultValue
// Size: 0x88 (Inherited: 0x0)
struct FUAEBlackboardParameterDefaultValue
{
	struct UObject* DefaultObject; // 0x0(0x28)
	struct UClass* DefaultClass; // 0x28(0x28)
	uint8_t DefaultEnum; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	int DefaultInt; // 0x54(0x4)
	float DefaultFloat; // 0x58(0x4)
	bool DefaultBool; // 0x5C(0x1)
	uint8_t Pad_0x5D[0x3]; // 0x5D(0x3)
	struct FString DefaultString; // 0x60(0x10)
	struct FName DefaultName; // 0x70(0x8)
	struct FVector DefaultVector; // 0x78(0xC)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
};

// Object: ScriptStruct UAESharedModule.UAEBlackboardKeySelector
// Size: 0x8 (Inherited: 0x0)
struct FUAEBlackboardKeySelector
{
	struct FName SelectedKeyName; // 0x0(0x8)
};

// Object: ScriptStruct UAESharedModule.UAEBlackboardKeySelectorIndex
// Size: 0x10 (Inherited: 0x8)
struct FUAEBlackboardKeySelectorIndex : FUAEBlackboardKeySelector
{
	int Index; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct UAESharedModule.UAEBlackboardContainer
// Size: 0x3C0 (Inherited: 0x0)
struct FUAEBlackboardContainer
{
	struct TMap<struct FName, struct UObject*> ObjectParamMap; // 0x0(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> WeakObjectParamMap; // 0x50(0x50)
	struct TMap<struct FName, struct UObject*> ClassParamMap; // 0xA0(0x50)
	struct TMap<struct FName, uint8_t> EnumParamMap; // 0xF0(0x50)
	struct TMap<struct FName, int> IntParamMap; // 0x140(0x50)
	struct TMap<struct FName, uint32_t> UIntParamMap; // 0x190(0x50)
	struct TMap<struct FName, float> FloatParamMap; // 0x1E0(0x50)
	struct TMap<struct FName, bool> BoolParamMap; // 0x230(0x50)
	struct TMap<struct FName, struct FString> StringParamMap; // 0x280(0x50)
	struct TMap<struct FName, struct FName> NameParamMap; // 0x2D0(0x50)
	struct TMap<struct FName, struct FVector> VectorParamMap; // 0x320(0x50)
	struct TMap<struct FName, struct FRotator> RotatorParamMap; // 0x370(0x50)
};

// Object: Class UAESharedModule.OwnBlackboardInterface
// Size: 0x28 (Inherited: 0x28)
struct IOwnBlackboardInterface : IInterface
{

	// Object: Function UAESharedModule.OwnBlackboardInterface.GetOwnBlackboardParameter
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1022c03e4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FUAEBlackboardParameter> GetOwnBlackboardParameter();
	// [Call #1] RVA: 0x1022C0660
	// [Call #2] RVA: 0x1022C879C
	// [Call #3] RVA: 0x1022C879C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648
	// [Call #9] RVA: 0x10519077C

	// Object: Function UAESharedModule.OwnBlackboardInterface.GetOwnBlackboard
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1022c03a8
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEBlackboard* GetOwnBlackboard();
	// [Call #1] RVA: 0x1022C0660
	// [Call #2] RVA: 0x1022C879C
	// [Call #3] RVA: 0x1022C879C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648
	// [Call #9] RVA: 0x10519077C
};

// Object: Class UAESharedModule.UAEBlackboardBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UUAEBlackboardBlueprintFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsWeakObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c3174
	// Params: [ Num(3) Size(0x3D0) ]
	void SetValueAsWeakObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA0E8
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022c3024
	// Params: [ Num(3) Size(0x3D4) ]
	void SetValueAsVector(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct FVector& VectorValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA43C
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2e80
	// Params: [ Num(3) Size(0x3D8) ]
	void SetValueAsString(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct FString StringValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x1022BA310
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x1022BC35C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022c2d30
	// Params: [ Num(3) Size(0x3D4) ]
	void SetValueAsRotator(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct FRotator& RotatorValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA494
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2bec
	// Params: [ Num(3) Size(0x3D0) ]
	void SetValueAsObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA0A0
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2aa8
	// Params: [ Num(3) Size(0x3D0) ]
	void SetValueAsName(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct FName NameValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA3F0
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA0A0
	// [Call #20] RVA: 0x1022BC35C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2964
	// Params: [ Num(3) Size(0x3CC) ]
	void SetValueAsInt(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, int IntValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA1DC
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA3F0
	// [Call #20] RVA: 0x1022BC35C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2820
	// Params: [ Num(3) Size(0x3CC) ]
	void SetValueAsFloat(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, float FloatValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA270
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA1DC
	// [Call #20] RVA: 0x1022BC35C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c26dc
	// Params: [ Num(3) Size(0x3C9) ]
	void SetValueAsEnum(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, uint8_t EnumValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA190
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA270
	// [Call #20] RVA: 0x1022BC35C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c2598
	// Params: [ Num(3) Size(0x3D0) ]
	void SetValueAsClass(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA144
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA190
	// [Call #20] RVA: 0x1022BC35C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.SetValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c244c
	// Params: [ Num(3) Size(0x3C9) ]
	void SetValueAsBool(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key, bool BoolValue);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA2C4
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1022BA144

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistWeakObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c2344
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistWeakObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA510
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1022BA2C4
	// [Call #18] RVA: 0x1022BC35C
	// [Call #19] RVA: 0x1022BC35C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistVector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c223c
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistVector(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA674
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA510
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c2134
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistString(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA624
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA674
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c202c
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistRotator(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA69C
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA624
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1f24
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA4EC
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA69C
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1e1c
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistName(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA64C
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA4EC
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1d14
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistInt(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA588
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA64C
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1c0c
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistFloat(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA5D4
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA588
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1b04
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistEnum(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA560
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA5D4
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c19fc
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistClass(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA538
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA560
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.IsExistBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c18f4
	// Params: [ Num(3) Size(0x3C9) ]
	bool IsExistBool(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA5FC
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA538
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsWeakObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c17ec
	// Params: [ Num(3) Size(0x3D0) ]
	struct UObject* GetValueAsWeakObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9C7C
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA5FC
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsWeakActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c16c4
	// Params: [ Num(3) Size(0x3D0) ]
	struct AActor* GetValueAsWeakActor(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9C7C
	// [Call #7] RVA: 0x101F8A5D4
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1022BB1A0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022B9C7C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x1022BC35C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x1022BB1A0

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c15b4
	// Params: [ Num(3) Size(0x3D4) ]
	struct FVector GetValueAsVector(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9FC0
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9C7C
	// [Call #16] RVA: 0x101F8A5D4
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x1022BC35C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1484
	// Params: [ Num(3) Size(0x3D8) ]
	struct FString GetValueAsString(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9EE8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x1022BC35C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1022BB1A0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1022B9FC0
	// [Call #19] RVA: 0x1022BC35C
	// [Call #20] RVA: 0x1022BC35C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1374
	// Params: [ Num(3) Size(0x3D4) ]
	struct FRotator GetValueAsRotator(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA030
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9EE8
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x1022BC35C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x1022BC35C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c126c
	// Params: [ Num(3) Size(0x3D0) ]
	struct UObject* GetValueAsObject(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9BF4
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BA030
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1160
	// Params: [ Num(3) Size(0x3D0) ]
	struct FName GetValueAsName(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9F70
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9BF4
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c1058
	// Params: [ Num(3) Size(0x3CC) ]
	int GetValueAsInt(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9DAC
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9F70
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c0f50
	// Params: [ Num(3) Size(0x3CC) ]
	float GetValueAsFloat(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9E48
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9DAC
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c0e48
	// Params: [ Num(3) Size(0x3C9) ]
	uint8_t GetValueAsEnum(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9D5C
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9E48
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c0d40
	// Params: [ Num(3) Size(0x3D0) ]
	struct UObject* GetValueAsClass(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9D0C
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9D5C
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c0c38
	// Params: [ Num(3) Size(0x3C9) ]
	bool GetValueAsBool(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9E94
	// [Call #7] RVA: 0x1022BC35C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1022BB1A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022B9D0C
	// [Call #16] RVA: 0x1022BC35C
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1022BB1A0
	// [Call #20] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.GetValueAsActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022c0b10
	// Params: [ Num(3) Size(0x3D0) ]
	struct AActor* GetValueAsActor(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9BF4
	// [Call #7] RVA: 0x101F8A5D4
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1022BB1A0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022B9E94
	// [Call #17] RVA: 0x1022BC35C
	// [Call #18] RVA: 0x1022BC35C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x1022BB1A0

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.FillBlackboardByBlackboard
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c09f4
	// Params: [ Num(2) Size(0x780) ]
	void FillBlackboardByBlackboard(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardContainer& OtherUAEBlackboardContainer);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1022BB1A0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022B9010
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x1022BC35C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1022BB1A0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1022B9BF4
	// [Call #19] RVA: 0x101F8A5D4
	// [Call #20] RVA: 0x1022BC35C
	// [Call #21] RVA: 0x1022BC35C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.FillBlackboard
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c08e0
	// Params: [ Num(2) Size(0x3D0) ]
	void FillBlackboard(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct TArray<struct FUAEBlackboardParameter>& ParamList);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B992C
	// [Call #7] RVA: 0x1022C879C
	// [Call #8] RVA: 0x1022BC35C
	// [Call #9] RVA: 0x1022C879C
	// [Call #10] RVA: 0x1022BC35C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1022BB1A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022BB1A0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1022B9010
	// [Call #19] RVA: 0x1022BC35C
	// [Call #20] RVA: 0x1022BC35C
	// [Call #21] RVA: 0x1022BC35C
	// [Call #22] RVA: 0x1022BC35C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x1022BB1A0

	// Object: Function UAESharedModule.UAEBlackboardBlueprintFunctionLibrary.AddValueByParam
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c07c0
	// Params: [ Num(2) Size(0x458) ]
	void AddValueByParam(struct FUAEBlackboardContainer& UAEBlackboardContainer, struct FUAEBlackboardParameter& NewParam);
	// [Call #1] RVA: 0x1022BB1A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10229BB10
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022B99C4
	// [Call #8] RVA: 0x10227D0F8
	// [Call #9] RVA: 0x1022BC35C
	// [Call #10] RVA: 0x10227D0F8
	// [Call #11] RVA: 0x1022BC35C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1022BB1A0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1022B992C
	// [Call #19] RVA: 0x1022C879C
	// [Call #20] RVA: 0x1022BC35C
	// [Call #21] RVA: 0x1022C879C
	// [Call #22] RVA: 0x1022BC35C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x1022BB1A0
};

// Object: Class UAESharedModule.UAEBlackboard
// Size: 0x3E8 (Inherited: 0x28)
struct UUAEBlackboard : UObject
{
	struct FUAEBlackboardContainer UAEBlackboardContainer; // 0x28(0x3C0)


	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c5720
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA76C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022c5650
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsVector(struct FUAEBlackboardKeySelector& Key, struct FVector VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA800
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA76C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c5514
	// Params: [ Num(2) Size(0x18) ]
	void SetValueAsString(struct FUAEBlackboardKeySelector& Key, struct FString StringValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1022BA79C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1022BA800
	// [Call #19] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022c5444
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsRotator(struct FUAEBlackboardKeySelector& Key, struct FRotator VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA82C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x1022BA79C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c5374
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA764
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA82C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c52a4
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsName(struct FUAEBlackboardKeySelector& Key, struct FName NameValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA7F8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA764
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c51d4
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsInt(struct FUAEBlackboardKeySelector& Key, int IntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA784
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA7F8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c5104
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsFloat(struct FUAEBlackboardKeySelector& Key, float FloatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA78C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA784
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c5034
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsEnum(struct FUAEBlackboardKeySelector& Key, uint8_t EnumValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA77C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA78C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c4f64
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsClass(struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA774
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA77C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.SetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c4e8c
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsBool(struct FUAEBlackboardKeySelector& Key, bool BoolValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022BA794
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA774
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.IsExistWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4df0
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistWeakObject(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA860
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022BA794
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022BA774

	// Object: Function UAESharedModule.UAEBlackboard.IsExistVector
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4d54
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistVector(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA8A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA860
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1022BA794
	// [Call #12] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.IsExistString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4cb8
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistString(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA898
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA8A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA860
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.IsExistRotator
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4c1c
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistRotator(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA8B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA898
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA8A8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA860

	// Object: Function UAESharedModule.UAEBlackboard.IsExistObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4b80
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistObject(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA858
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA8B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA898
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA8A8

	// Object: Function UAESharedModule.UAEBlackboard.IsExistName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4ae4
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistName(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA8A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA858
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA8B0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA898

	// Object: Function UAESharedModule.UAEBlackboard.IsExistInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4a48
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistInt(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA878
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA8A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA858
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA8B0

	// Object: Function UAESharedModule.UAEBlackboard.IsExistFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c49ac
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistFloat(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA888
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA878
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA8A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA858

	// Object: Function UAESharedModule.UAEBlackboard.IsExistEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4910
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistEnum(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA870
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA888
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA878
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA8A0

	// Object: Function UAESharedModule.UAEBlackboard.IsExistClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4874
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistClass(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA868
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA870
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA888
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA878

	// Object: Function UAESharedModule.UAEBlackboard.IsExistBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c47d8
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistBool(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA890
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA868
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA870
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA888

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c473c
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA70C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA890
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA868
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA870

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsWeakActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4684
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* GetValueAsWeakActor(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022B9C7C
	// [Call #4] RVA: 0x101F8A5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022BA70C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA890
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c45e4
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetValueAsVector(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA754
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022B9C7C
	// [Call #7] RVA: 0x101F8A5D4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA70C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4520
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetValueAsString(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA744
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA754
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022B9C7C
	// [Call #14] RVA: 0x101F8A5D4

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4480
	// Params: [ Num(2) Size(0x14) ]
	struct FRotator GetValueAsRotator(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA75C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA744
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022BA754
	// [Call #14] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c43e4
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsObject(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA704
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA75C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA744
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4348
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetValueAsName(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA74C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA704
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA75C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c42ac
	// Params: [ Num(2) Size(0xC) ]
	int GetValueAsInt(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA724
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA74C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA704
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA75C

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4210
	// Params: [ Num(2) Size(0xC) ]
	float GetValueAsFloat(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA734
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA724
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA74C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA704

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c4174
	// Params: [ Num(2) Size(0x9) ]
	uint8_t GetValueAsEnum(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA71C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA734
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA724
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA74C

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c40d8
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsClass(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA714
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA71C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA734
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA724

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c403c
	// Params: [ Num(2) Size(0x9) ]
	bool GetValueAsBool(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022BA73C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022BA714
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022BA71C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022BA734

	// Object: Function UAESharedModule.UAEBlackboard.GetValueAsActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c3f84
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* GetValueAsActor(struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022B9BF4
	// [Call #4] RVA: 0x101F8A5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022BA73C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022BA714
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UAESharedModule.UAEBlackboard.AddValueByParam
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022c3ecc
	// Params: [ Num(1) Size(0x98) ]
	void AddValueByParam(struct FUAEBlackboardParameter& NewParam);
	// [Call #1] RVA: 0x10229BB10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1022BA6FC
	// [Call #5] RVA: 0x10227D0F8
	// [Call #6] RVA: 0x10227D0F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022B9BF4
	// [Call #11] RVA: 0x101F8A5D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1022BA73C
	// [Call #15] RVA: 0x10516D168
};

// Object: Class UAESharedModule.UAESharedModuleInterface
// Size: 0x28 (Inherited: 0x28)
struct IUAESharedModuleInterface : IInterface
{
};

