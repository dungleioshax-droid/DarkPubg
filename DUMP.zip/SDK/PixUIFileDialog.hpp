#pragma once

#include <cstdint>

// Object: Class PixUIFileDialog.PxFileDialogMgr
// Size: 0x28 (Inherited: 0x28)
struct UPxFileDialogMgr : UObject
{
};

