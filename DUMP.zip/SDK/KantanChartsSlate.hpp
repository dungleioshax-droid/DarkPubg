#pragma once

#include <cstdint>

// Object: Enum KantanChartsSlate.EChartAxisPosition
enum class EChartAxisPosition : uint8_t
{
	LeftBottom = 0,
	RightTop = 1,
	Floating = 2,
	EChartAxisPosition_MAX = 3
};

// Object: Enum KantanChartsSlate.EKantanDataPointSize
enum class EKantanDataPointSize : uint8_t
{
	Small = 0,
	Medium = 1,
	Large = 2,
	EKantanDataPointSize_MAX = 3
};

// Object: Enum KantanChartsSlate.ECartesianRangeBoundType
enum class ECartesianRangeBoundType : uint8_t
{
	FixedValue = 0,
	FitToData = 1,
	FitToDataRounded = 2,
	ECartesianRangeBoundType_MAX = 3
};

// Object: Enum KantanChartsSlate.ECartesianScalingType
enum class ECartesianScalingType : uint8_t
{
	FixedScale = 0,
	FixedRange = 1,
	ECartesianScalingType_MAX = 2
};

// Object: Enum KantanChartsSlate.EKantanBarValueExtents
enum class EKantanBarValueExtents : uint8_t
{
	NoValueLines = 0,
	ZeroLineOnly = 1,
	ZeroAndMaxLines = 2,
	EKantanBarValueExtents_MAX = 3
};

// Object: Enum KantanChartsSlate.EKantanBarLabelPosition
enum class EKantanBarLabelPosition : uint8_t
{
	NoLabels = 0,
	Standard = 1,
	Overlaid = 2,
	EKantanBarLabelPosition_MAX = 3
};

// Object: Enum KantanChartsSlate.EKantanBarChartOrientation
enum class EKantanBarChartOrientation : uint8_t
{
	Vertical = 0,
	Horizontal = 1,
	EKantanBarChartOrientation_MAX = 2
};

// Object: ScriptStruct KantanChartsSlate.CartesianAxisConfig
// Size: 0x48 (Inherited: 0x0)
struct FCartesianAxisConfig
{
	struct FText Title; // 0x0(0x18)
	struct FText Unit; // 0x18(0x18)
	float MarkerSpacing; // 0x30(0x4)
	int MaxValueDigits; // 0x34(0x4)
	struct FCartesianAxisInstanceConfig LeftBottomAxis; // 0x38(0x4)
	struct FCartesianAxisInstanceConfig RightTopAxis; // 0x3C(0x4)
	struct FCartesianAxisInstanceConfig FloatingAxis; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct KantanChartsSlate.CartesianAxisInstanceConfig
// Size: 0x4 (Inherited: 0x0)
struct FCartesianAxisInstanceConfig
{
	bool bEnabled; // 0x0(0x1)
	bool bShowTitle; // 0x1(0x1)
	bool bShowMarkers; // 0x2(0x1)
	bool bShowLabels; // 0x3(0x1)
};

// Object: ScriptStruct KantanChartsSlate.KantanChartStyle
// Size: 0x150 (Inherited: 0x8)
struct FKantanChartStyle : FSlateWidgetStyle
{
	struct FSlateBrush Background; // 0x8(0xB8)
	struct FLinearColor ChartLineColor; // 0xC0(0x10)
	float ChartLineThickness; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct FSlateFontInfo BaseFont; // 0xD8(0x58)
	int TitleFontSize; // 0x130(0x4)
	int AxisDescriptionFontSize; // 0x134(0x4)
	int AxisValueFontSize; // 0x138(0x4)
	struct FLinearColor FontColor; // 0x13C(0x10)
	uint8_t Pad_0x14C[0x4]; // 0x14C(0x4)
};

// Object: ScriptStruct KantanChartsSlate.KantanBarChartStyle
// Size: 0x158 (Inherited: 0x150)
struct FKantanBarChartStyle : FKantanChartStyle
{
	float BarOpacity; // 0x14C(0x4)
	float BarOutlineOpacity; // 0x150(0x4)
	float BarOutlineThickness; // 0x154(0x4)
};

// Object: ScriptStruct KantanChartsSlate.KantanCartesianChartStyle
// Size: 0x158 (Inherited: 0x150)
struct FKantanCartesianChartStyle : FKantanChartStyle
{
	float DataOpacity; // 0x14C(0x4)
	float DataLineThickness; // 0x150(0x4)
};

// Object: ScriptStruct KantanChartsSlate.CartesianRangeBound
// Size: 0x8 (Inherited: 0x0)
struct FCartesianRangeBound
{
	uint8_t Type; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float FixedBoundValue; // 0x4(0x4)
};

// Object: ScriptStruct KantanChartsSlate.KantanCartesianPlotScale
// Size: 0x24 (Inherited: 0x0)
struct FKantanCartesianPlotScale
{
	uint8_t Type; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	struct FVector2D Scale; // 0x4(0x8)
	struct FVector2D FocalCoordinates; // 0xC(0x8)
	struct FCartesianAxisRange RangeX; // 0x14(0x8)
	struct FCartesianAxisRange RangeY; // 0x1C(0x8)
};

// Object: ScriptStruct KantanChartsSlate.CartesianAxisRange
// Size: 0x8 (Inherited: 0x0)
struct FCartesianAxisRange
{
	float Min; // 0x0(0x4)
	float Max; // 0x4(0x4)
};

// Object: ScriptStruct KantanChartsSlate.KantanCategoryStyle
// Size: 0x18 (Inherited: 0x0)
struct FKantanCategoryStyle
{
	struct FName CategoryStyleId; // 0x0(0x8)
	struct FLinearColor Color; // 0x8(0x10)
};

// Object: ScriptStruct KantanChartsSlate.KantanSeriesStyle
// Size: 0x20 (Inherited: 0x0)
struct FKantanSeriesStyle
{
	struct FName StyleID; // 0x0(0x8)
	struct UKantanPointStyle* PointStyle; // 0x8(0x8)
	struct FLinearColor Color; // 0x10(0x10)
};

// Object: Class KantanChartsSlate.KantanBarChartWidgetStyle
// Size: 0x188 (Inherited: 0x30)
struct UKantanBarChartWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FKantanBarChartStyle ChartStyle; // 0x30(0x158)
};

// Object: Class KantanChartsSlate.KantanCartesianChartWidgetStyle
// Size: 0x188 (Inherited: 0x30)
struct UKantanCartesianChartWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FKantanCartesianChartStyle ChartStyle; // 0x30(0x158)
};

// Object: Class KantanChartsSlate.KantanCategoryStyleSet
// Size: 0x40 (Inherited: 0x30)
struct UKantanCategoryStyleSet : UDataAsset
{
	struct TArray<struct FKantanCategoryStyle> Styles; // 0x30(0x10)
};

// Object: Class KantanChartsSlate.KantanPointStyle
// Size: 0x50 (Inherited: 0x30)
struct UKantanPointStyle : UDataAsset
{
	struct UTexture2D* DataPointTexture; // 0x30(0x8)
	struct FIntPoint PointSizeTextureOffsets[0x3]; // 0x38(0x18)
};

// Object: Class KantanChartsSlate.KantanSeriesStyleSet
// Size: 0x40 (Inherited: 0x30)
struct UKantanSeriesStyleSet : UDataAsset
{
	struct TArray<struct FKantanSeriesStyle> Styles; // 0x30(0x10)
};

