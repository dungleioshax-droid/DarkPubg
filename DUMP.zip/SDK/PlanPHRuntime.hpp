#pragma once

#include <cstdint>

// Object: Enum PlanPHRuntime.EDirectionType
enum class EDirectionType : uint8_t
{
	Up = 0,
	Down = 1,
	Left = 2,
	Right = 3,
	EDirectionType_MAX = 4
};

// Object: Enum PlanPHRuntime.EHomeAssetType
enum class EHomeAssetType : uint8_t
{
	CompleteEdgeStyle = 0,
	HalfEdgeStyle = 1,
	ArcStyle = 2,
	DoorStyle = 3,
	FilletWall = 4,
	TwoEdgeWall = 5,
	ThreeEdgeWall = 6,
	BigArcStyle = 7,
	BigArcDoorStyle = 8,
	TwoEdgeDoorStyle = 9,
	PlaneWallStyle = 10,
	PlaneDoorStyle = 11,
	TwoArcWindowStyle = 12,
	EHomeAssetType_MAX = 13
};

// Object: ScriptStruct PlanPHRuntime.StructureData
// Size: 0x14 (Inherited: 0x0)
struct FStructureData
{
	struct FVector2D Position; // 0x0(0x8)
	float Thickness; // 0x8(0x4)
	uint8_t AssetType; // 0xC(0x1)
	uint8_t Direction; // 0xD(0x1)
	uint8_t OccupiedX; // 0xE(0x1)
	uint8_t OccupiedY; // 0xF(0x1)
	uint8_t PaintNum; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
};

// Object: ScriptStruct PlanPHRuntime.PlanPH_CommonOccupy
// Size: 0x28 (Inherited: 0x0)
struct FPlanPH_CommonOccupy
{
	int LandId; // 0x0(0x4)
	bool bOccupied; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	int BeginTime; // 0x8(0x4)
	int EndTime; // 0xC(0x4)
	struct FString PlayerUID; // 0x10(0x10)
	bool bIsWedding; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: Class PlanPHRuntime.BinFileHelper
// Size: 0x28 (Inherited: 0x28)
struct UBinFileHelper : UObject
{

	// Object: Function PlanPHRuntime.BinFileHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10281f5bc
	// Params: [ Num(3) Size(0xC) ]
	int Init(int z4BufferSize, int zeroListSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10281BF2C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519077C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10281F708
};

// Object: Class PlanPHRuntime.MapBarrierWidget
// Size: 0x130 (Inherited: 0x100)
struct UMapBarrierWidget : UWidget
{
	uint8_t Pad_0x100[0x30]; // 0x100(0x30)


	// Object: Function PlanPHRuntime.MapBarrierWidget.SetMapStructureData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10281fb70
	// Params: [ Num(1) Size(0x10) ]
	void SetMapStructureData(struct TArray<struct FStructureData> InMapStructureData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10281DAA4
	// [Call #4] RVA: 0x10280E250
	// [Call #5] RVA: 0x10281D66C
	// [Call #6] RVA: 0x10281D66C
	// [Call #7] RVA: 0x10281D66C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x10281D66C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.MapBarrierWidget.SetMapMidPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10281fae8
	// Params: [ Num(1) Size(0x8) ]
	void SetMapMidPoint(struct FVector2D& InMapMidPoint);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280E1E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10281DAA4
	// [Call #7] RVA: 0x10280E250
	// [Call #8] RVA: 0x10281D66C
	// [Call #9] RVA: 0x10281D66C
	// [Call #10] RVA: 0x10281D66C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x10281D66C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.MapBarrierWidget.SetLevelBoundExtent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10281fa6c
	// Params: [ Num(1) Size(0x4) ]
	void SetLevelBoundExtent(int InLevelBoundExtent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280E208
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10280E1E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10281DAA4
	// [Call #10] RVA: 0x10280E250
	// [Call #11] RVA: 0x10281D66C
	// [Call #12] RVA: 0x10281D66C
	// [Call #13] RVA: 0x10281D66C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x10281D66C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.MapBarrierWidget.SetGridSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10281f9f0
	// Params: [ Num(1) Size(0x4) ]
	void SetGridSize(float InGridSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280E23C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10280E208
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10280E1E8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10281DAA4
	// [Call #13] RVA: 0x10280E250
	// [Call #14] RVA: 0x10281D66C
	// [Call #15] RVA: 0x10281D66C
	// [Call #16] RVA: 0x10281D66C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
};

// Object: Class PlanPHRuntime.PlanPH_GameMode
// Size: 0x22B8 (Inherited: 0x22B0)
struct APlanPH_GameMode : ABattleRoyaleGameMode
{
	uint8_t Pad_0x22B0[0x8]; // 0x22B0(0x8)


	// Object: Function PlanPHRuntime.PlanPH_GameMode.HandleNavigationInfo
	// Flags: [Final|Native|Private]
	// Offset: 0x10282003c
	// Params: [ Num(1) Size(0x8) ]
	void HandleNavigationInfo(struct AController* Controller);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280BD28
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function PlanPHRuntime.PlanPH_GameMode.GetPlayerStart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	struct ASTExtraPlayerStart* GetPlayerStart(int LandId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanPHRuntime.PlanPH_GameMode.DSPlayerKickOut
	// Flags: [Final|Native|Public]
	// Offset: 0x10281fed4
	// Params: [ Num(3) Size(0x20) ]
	void DSPlayerKickOut(uint64_t UID, struct FName PlayerType, struct FString ExitReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x10280C204
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10280BD28
	// [Call #19] RVA: 0x10519022C
};

// Object: Class PlanPHRuntime.PlanPH_GameModeState_Active
// Size: 0xC8 (Inherited: 0xC8)
struct UPlanPH_GameModeState_Active : UGameModeStateActive
{
};

// Object: Class PlanPHRuntime.PlanPH_GameModeState_Fighting
// Size: 0xD8 (Inherited: 0xD8)
struct UPlanPH_GameModeState_Fighting : UGameModeStateFightingTeam
{
};

// Object: Class PlanPHRuntime.PlanPH_GameState
// Size: 0x16D0 (Inherited: 0x1620)
struct APlanPH_GameState : ASTExtraGameStateBase
{
	struct FScriptMulticastDelegate OnIslandPlayerChangeDelegate; // 0x1620(0x10)
	struct FPlanPH_CommonOccupy PartyDanceLeadInfo_1; // 0x1630(0x28)
	struct FPlanPH_CommonOccupy PartyDanceLeadInfo_2; // 0x1658(0x28)
	struct FPlanPH_CommonOccupy PartyDanceLeadInfo_3; // 0x1680(0x28)
	struct FPlanPH_CommonOccupy PartyDanceLeadInfo_4; // 0x16A8(0x28)


	// Object: Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_4
	// Flags: [Final|Native|Public]
	// Offset: 0x102820844
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_4();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_3
	// Flags: [Final|Native|Public]
	// Offset: 0x102820830
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_3();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_2
	// Flags: [Final|Native|Public]
	// Offset: 0x10282081c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_2();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_1
	// Flags: [Final|Native|Public]
	// Offset: 0x102820808
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_1();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_GameState.LuaOnRep_PartyDanceLeadInfo
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void LuaOnRep_PartyDanceLeadInfo(int LandId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanPHRuntime.PlanPH_GameState.ChangePartyLeadInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1028205cc
	// Params: [ Num(6) Size(0x21) ]
	void ChangePartyLeadInfo(int LandId, bool bOccupied, int BeginTime, int EndTime, struct FString PlayerUID, bool bIsWedding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x10280C624
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
};

// Object: Class PlanPHRuntime.PlanPH_PlayerState
// Size: 0x1CE0 (Inherited: 0x1CD8)
struct APlanPH_PlayerState : ASTExtraPlayerState
{
	int LandId; // 0x1CD8(0x4)
	uint8_t Pad_0x1CDC[0x4]; // 0x1CDC(0x4)


	// Object: Function PlanPHRuntime.PlanPH_PlayerState.RequestPaintDecal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102820c60
	// Params: [ Num(2) Size(0x40) ]
	void RequestPaintDecal(int DecalId, struct FTransform& TargetTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280C9F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_PlayerState.OnRep_LandId
	// Flags: [Final|Native|Public]
	// Offset: 0x102820c4c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LandId();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280C9F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPH_PlayerState.InitLandId
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitLandId();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanPHRuntime.PlanPH_PlayerState.CanPaintDecal
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102820bb8
	// Params: [ Num(2) Size(0x5) ]
	bool CanPaintDecal(int DecalId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10280C9F4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class PlanPHRuntime.PlanPHCustomStaticMeshComponent
// Size: 0xC30 (Inherited: 0xBD0)
struct UPlanPHCustomStaticMeshComponent : UStaticMeshComponent
{
	uint8_t Pad_0xBD0[0x50]; // 0xBD0(0x50)
	struct FString LuaFilePath; // 0xC20(0x10)


	// Object: Function PlanPHRuntime.PlanPHCustomStaticMeshComponent.BPPreSetStaticMesh
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void BPPreSetStaticMesh(struct UStaticMesh* NewMesh);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanPHRuntime.PlanPHCustomStaticMeshComponent.BPPostSetStaticMesh
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void BPPostSetStaticMesh(struct UStaticMesh* NewMesh);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class PlanPHRuntime.PlanPHDoor
// Size: 0x588 (Inherited: 0x570)
struct APlanPHDoor : ALuaActor
{
	bool bUseDoorWaitPush; // 0x569(0x1)
	struct FVector WrapExtentsOffset; // 0x56C(0xC)
	struct FVector TransformDirVector; // 0x578(0xC)


	// Object: Function PlanPHRuntime.PlanPHDoor.Refresh_DoorCollisionChanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102821258
	// Params: [ Num(2) Size(0x9) ]
	void Refresh_DoorCollisionChanel(struct UStaticMeshComponent* StaticMeshComponent, bool bEnableCollision);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280A994
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function PlanPHRuntime.PlanPHDoor.DoorAniFinish
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102821198
	// Params: [ Num(2) Size(0x9) ]
	void DoorAniFinish(struct UStaticMeshComponent* InDoorCheckBox, bool Bright);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280A9E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10280A994
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
};

// Object: Class PlanPHRuntime.PlanPHGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UPlanPHGameplayStatics : UBlueprintFunctionLibrary
{

	// Object: Function PlanPHRuntime.PlanPHGameplayStatics.SpinEvaluate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102821760
	// Params: [ Num(3) Size(0xC) ]
	float SpinEvaluate(float S, float T);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10281CA98
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanPHRuntime.PlanPHGameplayStatics.SetPlayerMovementBlendTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10282165c
	// Params: [ Num(4) Size(0x11) ]
	bool SetPlayerMovementBlendTime(struct ASTExtraPlayerCharacter* PlayerChar, int nType, float BlendTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10281C97C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10281CA98
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function PlanPHRuntime.PlanPHGameplayStatics.GetActorBound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102821598
	// Params: [ Num(2) Size(0x14) ]
	void GetActorBound(struct AActor* Actor, struct FVector& Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10281CB08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10281C97C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PlanPHRuntime.PlanPHGameplayStatics.ChangeLightChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1028214e0
	// Params: [ Num(2) Size(0xC) ]
	void ChangeLightChannel(struct UPrimitiveComponent* InComponent, int InChannelBitMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10281C960
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10281CB08
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class PlanPHRuntime.PlanPHHomeArea
// Size: 0x5A8 (Inherited: 0x570)
struct APlanPHHomeArea : ALuaActor
{
	struct FVector BlockDimension; // 0x56C(0xC)
	struct FIntVector BlockNumXYZ; // 0x578(0xC)
	struct FIntVector MinGridIndexXYZ; // 0x584(0xC)
	struct FIntVector MaxGridIndexXYZ; // 0x590(0xC)
	struct UPlanPHHomeAreaVisualizationComponent* VisComponent; // 0x5A0(0x8)


	// Object: Function PlanPHRuntime.PlanPHHomeArea.UpdateEditableArea
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102821a5c
	// Params: [ Num(2) Size(0x18) ]
	void UpdateEditableArea(struct FIntVector InMinGridIndexXYZ, struct FIntVector InMaxGridIndexXYZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280D4CC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x102821D90
	// [Call #10] RVA: 0x10516D168
};

// Object: Class PlanPHRuntime.PlanPHHomeAreaVisualizationComponent
// Size: 0x9E0 (Inherited: 0x9D0)
struct UPlanPHHomeAreaVisualizationComponent : UPrimitiveComponent
{
	uint8_t Pad_0x9D0[0x10]; // 0x9D0(0x10)


	// Object: Function PlanPHRuntime.PlanPHHomeAreaVisualizationComponent.ShowGrids
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102821c78
	// Params: [ Num(1) Size(0x1) ]
	void ShowGrids(bool InBShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280CEA8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102822114
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class PlanPHRuntime.PlanPHMapData
// Size: 0xB8 (Inherited: 0x98)
struct UPlanPHMapData : UMapDataBase
{
	struct TArray<struct ASTExtraPlayerCharacter*> PlayerCharacterArrayC; // 0x98(0x10)
	struct TArray<struct FVector> OffsetLocations; // 0xA8(0x10)


	// Object: Function PlanPHRuntime.PlanPHMapData.RemovePlayerItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102821fa4
	// Params: [ Num(2) Size(0x9) ]
	bool RemovePlayerItem(struct ASTExtraPlayerCharacter* PlayerCharacterItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10281BE68
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10516EACC

	// Object: Function PlanPHRuntime.PlanPHMapData.AddPlayerItem
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102821e68
	// Params: [ Num(5) Size(0x25) ]
	bool AddPlayerItem(struct ASTExtraPlayerCharacter* PlayerCharacterItem, struct UWidget* PlayerInfoBPItem, struct UWidget* PlayerInfoRotWidgetItem, struct FVector OffsetLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10281BDA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10281BE68
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class PlanPHRuntime.PlanPHSpectatorPawn
// Size: 0x5A8 (Inherited: 0x538)
struct APlanPHSpectatorPawn : ASpectatorPawn
{
	uint8_t Pad_0x538[0x58]; // 0x538(0x58)
	struct FString LuaFilePath; // 0x590(0x10)
	float PlaneMoveMaxSpeed; // 0x5A0(0x4)
	float VerticalMoveMaxSpeed; // 0x5A4(0x4)


	// Object: Function PlanPHRuntime.PlanPHSpectatorPawn.OnSpectatorRestart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnSpectatorRestart();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanPHRuntime.PlanPHSpectatorPawn.MoveRight
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1028222ac
	// Params: [ Num(1) Size(0x4) ]
	void MoveRight(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x102822694

	// Object: Function PlanPHRuntime.PlanPHSpectatorPawn.MoveForward
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102822228
	// Params: [ Num(1) Size(0x4) ]
	void MoveForward(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class PlanPHRuntime.PlanPHVisualGridComponent
// Size: 0xA30 (Inherited: 0x9D0)
struct UPlanPHVisualGridComponent : UPrimitiveComponent
{
	struct FVector BlockDimension; // 0x9C8(0xC)
	struct FIntVector BlockNumXYZ; // 0x9D4(0xC)
	struct FLinearColor XColor; // 0x9E0(0x10)
	struct FLinearColor YColor; // 0x9F0(0x10)
	struct FLinearColor ZColor; // 0xA00(0x10)
	float LineThickness; // 0xA10(0x4)
	uint8_t Pad_0xA1C[0x4]; // 0xA1C(0x4)
	bool bShouldShowGrids; // 0xA20(0x1)
	uint8_t Pad_0xA21[0xF]; // 0xA21(0xF)


	// Object: Function PlanPHRuntime.PlanPHVisualGridComponent.ShowGrids
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10282252c
	// Params: [ Num(1) Size(0x1) ]
	void ShowGrids(bool InBShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280D764
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10518366C
	// [Call #9] RVA: 0x10518366C

	// Object: Function PlanPHRuntime.PlanPHVisualGridComponent.RefreshGrids
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102822518
	// Params: [ Num(0) Size(0x0) ]
	void RefreshGrids();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280D764
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10518366C
	// [Call #9] RVA: 0x10518366C
};

