#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_ExplicitMenuSwitchTable_type.BP_STRUCT_ExplicitMenuSwitchTable_type
// Size: 0xC (Inherited: 0x0)
struct FBP_STRUCT_ExplicitMenuSwitchTable_type
{
	int ID_0_7968950070B6BF9030F4C9B10FE59CF4; // 0x0(0x4)
	int MenuID_1_34555A404892A56F3281DD1D0D15BC44; // 0x4(0x4)
	int Open_2_05BAF64071DEC1497EAE9170059D495E; // 0x8(0x4)
};

