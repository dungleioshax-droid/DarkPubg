#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_TransColumns_type.BP_STRUCT_TransColumns_type
// Size: 0x20 (Inherited: 0x0)
struct FBP_STRUCT_TransColumns_type
{
	struct FString Columns_0_47AC24714CA709ABE62AB2B97B02C861; // 0x0(0x10)
	struct FString Table_1_B0FEB2B8486D4078687135A2F1589ADF; // 0x10(0x10)
};

