#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_DiySuitColorConfig_type.BP_STRUCT_DiySuitColorConfig_type
// Size: 0x78 (Inherited: 0x0)
struct FBP_STRUCT_DiySuitColorConfig_type
{
	int ItemID_1_15B6748029F10AF4167429B5070FACB4; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString BPUrl_2_1E617EC03A4F456D2C223D0106670E5C; // 0x8(0x10)
	int Cost_3_63AB73C07271FCFF75FDA1880D66A384; // 0x18(0x4)
	int ID_4_0CD2D0C023DDAD912AEEEF92052D66D4; // 0x1C(0x4)
	struct FString ColorName_9_56C1CD807D19C79E1E3D3EDE01B12E25; // 0x20(0x10)
	struct TArray<int> MaskColor1_a_11_14512C805333B5405D0FD0FD032BE651; // 0x30(0x10)
	struct TArray<int> MaskColor2_a_12_6E69ECC05EBDA3E75D0FD734032BE551; // 0x40(0x10)
	struct TArray<int> MaskColor3_a_13_4882AD006A47928E5D0F3AA4032BEC51; // 0x50(0x10)
	float GrayScale_f_15_0D6CFD80123EC6A658D3D8300FFAF166; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> UIShowColor_a_16_100C6D00219953BA2ABB948401FA2891; // 0x68(0x10)
};

