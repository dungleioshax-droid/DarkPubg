#pragma once

#include <cstdint>

// Object: ScriptStruct TemBPNode.TemBPDataAddr
// Size: 0x18 (Inherited: 0x0)
struct FTemBPDataAddr
{
	uint64_t Value; // 0x0(0x8)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: Class TemBPNode.TemBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UTemBPLibrary : UBlueprintFunctionLibrary
{

	// Object: Function TemBPNode.TemBPLibrary.TempUIMsgInvokeRef
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102058bc0
	// Params: [ Num(4) Size(0x38) ]
	void TempUIMsgInvokeRef(struct UObject* ObjContext, struct FString MsgName, struct FString ModuleName, struct TArray<struct FTemBPDataAddr>& ParamArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057A98
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190648
	// [Call #19] RVA: 0x105190870

	// Object: Function TemBPNode.TemBPLibrary.TempBridgeEventInvokeRef
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102058a3c
	// Params: [ Num(4) Size(0x38) ]
	void TempBridgeEventInvokeRef(struct UObject* ObjContext, struct FString EventType, struct FString EventID, struct TArray<struct FTemBPDataAddr>& ParamArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057EC0
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function TemBPNode.TemBPLibrary.AddrFromWild
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102058a30
	// Params: [ Num(3) Size(0x40) ]
	struct FTemBPDataAddr AddrFromWild(struct FString DataType, struct FTemBPDataAddr& InAny);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057EC0
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function TemBPNode.TemBPLibrary.AddrFromSet
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102058a24
	// Params: [ Num(3) Size(0x78) ]
	struct FTemBPDataAddr AddrFromSet(struct FString DataType, struct TSet<int>& InAny);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057EC0
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function TemBPNode.TemBPLibrary.AddrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102058a18
	// Params: [ Num(3) Size(0x78) ]
	struct FTemBPDataAddr AddrFromMap(struct FString DataType, struct TMap<int, int>& InAny);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057EC0
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function TemBPNode.TemBPLibrary.AddrFromArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102058a0c
	// Params: [ Num(3) Size(0x38) ]
	struct FTemBPDataAddr AddrFromArray(struct FString DataType, struct TArray<int>& InAny);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102057EC0
	// [Call #10] RVA: 0x10205994C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10205994C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
};

// Object: Class TemBPNode.LuaTemBPData
// Size: 0x28 (Inherited: 0x28)
struct ULuaTemBPData : UObject
{
};

// Object: Class TemBPNode.LuaTemBPData_bool
// Size: 0x30 (Inherited: 0x28)
struct ULuaTemBPData_bool : ULuaTemBPData
{
	bool Data; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: Class TemBPNode.LuaTemBPData_int
// Size: 0x30 (Inherited: 0x28)
struct ULuaTemBPData_int : ULuaTemBPData
{
	int Data; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class TemBPNode.LuaTemBPData_float
// Size: 0x30 (Inherited: 0x28)
struct ULuaTemBPData_float : ULuaTemBPData
{
	float Data; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class TemBPNode.LuaTemBPData_string
// Size: 0x38 (Inherited: 0x28)
struct ULuaTemBPData_string : ULuaTemBPData
{
	struct FString Data; // 0x28(0x10)
};

// Object: Class TemBPNode.LuaTemBPData_object
// Size: 0x30 (Inherited: 0x28)
struct ULuaTemBPData_object : ULuaTemBPData
{
	struct UObject* Data; // 0x28(0x8)
};

