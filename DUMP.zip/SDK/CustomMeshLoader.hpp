#pragma once

#include <cstdint>

// Object: Class CustomMeshLoader.CustomMeshLoaderBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCustomMeshLoaderBPLibrary : UBlueprintFunctionLibrary
{

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSModelFromMemory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102c6c12c
	// Params: [ Num(4) Size(0x38) ]
	struct UStaticMesh* LoadSModelFromMemory(struct TArray<uint8_t>& Data, struct FString MeshName, struct TArray<struct UMaterialInstance*>& Materials);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102C52BDC
	// [Call #8] RVA: 0x102C6C894
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x102C6C894
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSModelFileAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102c6bfd8
	// Params: [ Num(3) Size(0x30) ]
	void LoadSModelFileAsync(struct FString FilePath, struct FString MeshName, DelegateProperty& OnComplete);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102C53F70
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSModelFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6beec
	// Params: [ Num(3) Size(0x28) ]
	struct UStaticMesh* LoadSModelFile(struct FString FilePath, struct FString MeshName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C52838
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FD9E48
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102C53F70
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSKModelFromMemory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102c6bd80
	// Params: [ Num(4) Size(0x38) ]
	struct USkeletalMesh* LoadSKModelFromMemory(struct TArray<uint8_t>& Data, struct FString MeshName, struct TArray<struct UMaterialInterface*>& Materials);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102C5F838
	// [Call #8] RVA: 0x101FD7AD0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101FD7AD0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102C52838
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSKModelFileToAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102c6bc30
	// Params: [ Num(4) Size(0x38) ]
	struct USkeletalMesh* LoadSKModelFileToAsset(struct FString FilePath, struct FString AssetPath, struct TArray<struct UMaterialInterface*>& Materials);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102C5F200
	// [Call #8] RVA: 0x101FD7AD0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101FD7AD0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x102C5F838

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.LoadSKModelFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102c6bae0
	// Params: [ Num(4) Size(0x38) ]
	struct USkeletalMesh* LoadSKModelFile(struct FString FilePath, struct FString MeshName, struct TArray<struct UMaterialInterface*>& Materials);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102C5EEC4
	// [Call #8] RVA: 0x101FD7AD0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101FD7AD0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x102C5F200
	// [Call #22] RVA: 0x101FD7AD0
	// [Call #23] RVA: 0x101F8130C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.IsValidSModelFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102c6ba48
	// Params: [ Num(2) Size(0x11) ]
	bool IsValidSModelFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C541C0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102C5EEC4
	// [Call #14] RVA: 0x101FD7AD0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101FD7AD0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.IsValidSKModelFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102c6b9b0
	// Params: [ Num(2) Size(0x11) ]
	bool IsValidSKModelFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C60568
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C541C0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102C5EEC4
	// [Call #20] RVA: 0x101FD7AD0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.GetSModelFileInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102c6b818
	// Params: [ Num(5) Size(0x1D) ]
	bool GetSModelFileInfo(struct FString FilePath, int& OutSectionCount, int& OutMaterialCount, int& OutVertexCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C56288
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102C60568
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpStaticMeshVertexDataByPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6b688
	// Params: [ Num(5) Size(0x38) ]
	struct FString DumpStaticMeshVertexDataByPath(struct FString MeshAssetPath, struct FString OutputFilePath, int LODIndex, int MaxVertices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C56568
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpStaticMeshVertexData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6b510
	// Params: [ Num(5) Size(0x30) ]
	struct FString DumpStaticMeshVertexData(struct UStaticMesh* Mesh, struct FString OutputFilePath, int LODIndex, int MaxVertices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C543E8
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpSKModelVertexData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6b380
	// Params: [ Num(5) Size(0x38) ]
	struct FString DumpSKModelVertexData(struct FString SKModelPath, struct FString OutputFilePath, int LODIndex, int MaxVertices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C5BD38
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpSkeletonDataFromMesh
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6b284
	// Params: [ Num(3) Size(0x28) ]
	struct FString DumpSkeletonDataFromMesh(struct USkeletalMesh* Mesh, struct FString OutputFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C5BC24
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102C5BD38
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpSkeletonData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6b188
	// Params: [ Num(3) Size(0x28) ]
	struct FString DumpSkeletonData(struct USkeleton* Skeleton, struct FString OutputFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C5A95C
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102C5BC24
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpSkeletalMeshVertexDataByPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6aff8
	// Params: [ Num(5) Size(0x38) ]
	struct FString DumpSkeletalMeshVertexDataByPath(struct FString MeshAssetPath, struct FString OutputFilePath, int LODIndex, int MaxVertices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C594CC
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x102C5A95C
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpSkeletalMeshVertexData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6ae80
	// Params: [ Num(5) Size(0x30) ]
	struct FString DumpSkeletalMeshVertexData(struct USkeletalMesh* Mesh, struct FString OutputFilePath, int LODIndex, int MaxVertices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C56660
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpAnimSequenceDataByPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6ad6c
	// Params: [ Num(3) Size(0x30) ]
	struct FString DumpAnimSequenceDataByPath(struct FString AnimAssetPath, struct FString OutputFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C5A860
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x102C56660
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function CustomMeshLoader.CustomMeshLoaderBPLibrary.DumpAnimSequenceData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c6ac70
	// Params: [ Num(3) Size(0x28) ]
	struct FString DumpAnimSequenceData(struct UAnimSequence* AnimSequence, struct FString OutputFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C595E4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102C5A860
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
};

