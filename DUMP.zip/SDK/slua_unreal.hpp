#pragma once

#include <cstdint>

// Object: Enum slua_unreal.EPropertyClass
enum class EPropertyClass : uint8_t
{
	Byte = 0,
	Int8 = 1,
	Int16 = 2,
	Int = 3,
	Int64 = 4,
	UInt16 = 5,
	UInt32 = 6,
	UInt64 = 7,
	UnsizedInt = 8,
	UnsizedUInt = 9,
	Float = 10,
	Double = 11,
	Bool = 12,
	SoftClass = 13,
	WeakObject = 14,
	LazyObject = 15,
	SoftObject = 16,
	Class = 17,
	Object = 18,
	Interface = 19,
	Name = 20,
	Str = 21,
	Array = 22,
	Map = 23,
	Set = 24,
	Struct = 25,
	Delegate = 26,
	MulticastDelegate = 27,
	Text = 28,
	Enum = 29,
	EPropertyClass_MAX = 30
};

// Object: ScriptStruct slua_unreal.SluaBPVar
// Size: 0x20 (Inherited: 0x0)
struct FSluaBPVar
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct slua_unreal.LuaNetSerialization
// Size: 0x50 (Inherited: 0x0)
struct FLuaNetSerialization
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct slua_unreal.LuaPatchRPCFrame
// Size: 0x40 (Inherited: 0x0)
struct FLuaPatchRPCFrame
{
	uint8_t Pad_0x0[0x40]; // 0x0(0x40)
};

// Object: ScriptStruct slua_unreal.unctionProfileCallInfo
// Size: 0x30 (Inherited: 0x0)
struct FunctionProfileCallInfo
{
	struct FLuaFunctionDefine functionDefine; // 0x0(0xC)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	int64_t begTime; // 0x10(0x8)
	bool bIsCoroutineBegin; // 0x18(0x1)
	uint8_t Pad_0x19[0x17]; // 0x19(0x17)
};

// Object: ScriptStruct slua_unreal.LuaFunctionDefine
// Size: 0xC (Inherited: 0x0)
struct FLuaFunctionDefine
{
	uint32_t fileNameIndex; // 0x0(0x4)
	uint32_t functionNameIndex; // 0x4(0x4)
	int lineDefined; // 0x8(0x4)
};

// Object: ScriptStruct slua_unreal.unctionProfileNode
// Size: 0x30 (Inherited: 0x0)
struct FunctionProfileNode
{
	struct FLuaFunctionDefine functionDefine; // 0x0(0xC)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	int64_t costTime; // 0x10(0x8)
	int countOfCalls; // 0x18(0x4)
	int layerIdx; // 0x1C(0x4)
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
};

// Object: ScriptStruct slua_unreal.ileMemInfo
// Size: 0x10 (Inherited: 0x0)
struct FileMemInfo
{
	uint32_t fileNameIndex; // 0x0(0x4)
	int LineNumber; // 0x4(0x4)
	float Size; // 0x8(0x4)
	float difference; // 0xC(0x4)
};

// Object: Class slua_unreal.LatentDelegate
// Size: 0x30 (Inherited: 0x28)
struct ULatentDelegate : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function slua_unreal.LatentDelegate.OnLatentCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102217690
	// Params: [ Num(1) Size(0x4) ]
	void OnLatentCallback(int threadRef);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10215E594
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102217A08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10215EBB8
};

// Object: Class slua_unreal.LuaActor
// Size: 0x570 (Inherited: 0x4B0)
struct ALuaActor : AActor
{
	uint8_t Pad_0x4B0[0x58]; // 0x4B0(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x508(0x50)
	struct FString LuaFilePath; // 0x558(0x10)
	uint8_t Pad_0x568[0x8]; // 0x568(0x8)


	// Object: Function slua_unreal.LuaActor.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022178e0
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190648
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x102217C3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function slua_unreal.LuaActor.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102217864
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10215EBB8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190648
	// [Call #8] RVA: 0x10508F76C
};

// Object: Class slua_unreal.LuaActorComponent
// Size: 0x238 (Inherited: 0x178)
struct ULuaActorComponent : UActorComponent
{
	uint8_t Pad_0x178[0x58]; // 0x178(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x1D0(0x50)
	struct FString LuaFilePath; // 0x220(0x10)
	uint8_t Pad_0x230[0x8]; // 0x230(0x8)


	// Object: Function slua_unreal.LuaActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102217b5c
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function slua_unreal.LuaActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102217ae0
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10215EDFC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870
};

// Object: Class slua_unreal.LuaCharacter
// Size: 0x9A0 (Inherited: 0x8F0)
struct ALuaCharacter : ACharacter
{
	uint8_t Pad_0x8F0[0x50]; // 0x8F0(0x50)
	struct FLuaNetSerialization LuaNetSerialization; // 0x940(0x50)
	struct FString LuaFilePath; // 0x990(0x10)
};

// Object: Class slua_unreal.LuaDelegate
// Size: 0x180 (Inherited: 0x28)
struct ULuaDelegate : UObject
{
	uint8_t Pad_0x28[0x158]; // 0x28(0x158)


	// Object: Function slua_unreal.LuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102217e18
	// Params: [ Num(0) Size(0x0) ]
	void EventTrigger();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class slua_unreal.LuaGameMode
// Size: 0x5E8 (Inherited: 0x580)
struct ALuaGameMode : AGameMode
{
	uint8_t Pad_0x580[0x58]; // 0x580(0x58)
	struct FString LuaFilePath; // 0x5D8(0x10)
};

// Object: Class slua_unreal.LuaGameState
// Size: 0x5C8 (Inherited: 0x510)
struct ALuaGameState : AGameState
{
	uint8_t Pad_0x510[0x58]; // 0x510(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x568(0x50)
	struct FString LuaFilePath; // 0x5B8(0x10)
};

// Object: Class slua_unreal.LuaInstancedActorComponent
// Size: 0x1E8 (Inherited: 0x178)
struct ULuaInstancedActorComponent : UActorComponent
{
	uint8_t Pad_0x178[0x58]; // 0x178(0x58)
	struct FString LuaFilePath; // 0x1D0(0x10)
	uint8_t Pad_0x1E0[0x8]; // 0x1E0(0x8)


	// Object: Function slua_unreal.LuaInstancedActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10221820c
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102218520
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10216F5B4

	// Object: Function slua_unreal.LuaInstancedActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102218190
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10216F404
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x102218520
};

// Object: Class slua_unreal.LuaLevelScriptActor
// Size: 0x520 (Inherited: 0x4B0)
struct ALuaLevelScriptActor : ALevelScriptActor
{
	uint8_t Pad_0x4B0[0x58]; // 0x4B0(0x58)
	struct FString LuaFilePath; // 0x508(0x10)
	uint8_t Pad_0x518[0x8]; // 0x518(0x8)


	// Object: Function slua_unreal.LuaLevelScriptActor.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102218440
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102217628
	// [Call #6] RVA: 0x105184F34
	// [Call #7] RVA: 0x1036A6C08
	// [Call #8] RVA: 0x101FEA05C

	// Object: Function slua_unreal.LuaLevelScriptActor.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022183c4
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10216F5B4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x102217628
	// [Call #9] RVA: 0x105184F34
};

// Object: Class slua_unreal.LuaOverrider
// Size: 0x28 (Inherited: 0x28)
struct ULuaOverrider : UObject
{

	// Object: Function slua_unreal.LuaOverrider.TriggerAnimNotify
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void TriggerAnimNotify();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function slua_unreal.LuaOverrider.InputVectorAxis
	// Flags: [Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x102218978
	// Params: [ Num(1) Size(0xC) ]
	void InputVectorAxis(struct FVector& AxisValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function slua_unreal.LuaOverrider.InputTouch
	// Flags: [Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x1022188ac
	// Params: [ Num(2) Size(0x10) ]
	void InputTouch(enum class ETouchIndex FingerIndex, struct FVector& Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function slua_unreal.LuaOverrider.InputGesture
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102218828
	// Params: [ Num(1) Size(0x4) ]
	void InputGesture(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function slua_unreal.LuaOverrider.InputAxis
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1022187a4
	// Params: [ Num(1) Size(0x4) ]
	void InputAxis(float AxisValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function slua_unreal.LuaOverrider.InputAction
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1022186b4
	// Params: [ Num(1) Size(0x18) ]
	void InputAction(struct FKey Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C8F20
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class slua_unreal.LuaOverriderInterface
// Size: 0x28 (Inherited: 0x28)
struct ILuaOverriderInterface : IInterface
{

	// Object: Function slua_unreal.LuaOverriderInterface.GetLuaFilePath
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102218cb4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLuaFilePath();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10516EABC
	// [Call #9] RVA: 0x102218DA8
	// [Call #10] RVA: 0x1051871D4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
};

// Object: Class slua_unreal.LuaPatchRPCComponent
// Size: 0x190 (Inherited: 0x178)
struct ULuaPatchRPCComponent : UActorComponent
{
	uint8_t Pad_0x178[0x18]; // 0x178(0x18)


	// Object: Function slua_unreal.LuaPatchRPCComponent.ServerUnreliable_LuaPatchRPC
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	// Offset: 0x102219a0c
	// Params: [ Num(1) Size(0x40) ]
	void ServerUnreliable_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function slua_unreal.LuaPatchRPCComponent.Server_LuaPatchRPC
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x102219954
	// Params: [ Num(1) Size(0x40) ]
	void Server_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function slua_unreal.LuaPatchRPCComponent.MulticastUnreliable_LuaPatchRPC
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10221989c
	// Params: [ Num(1) Size(0x40) ]
	void MulticastUnreliable_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C

	// Object: Function slua_unreal.LuaPatchRPCComponent.MulticastPerConnectionUnreliable_LuaPatchRPC
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x1022197e4
	// Params: [ Num(1) Size(0x40) ]
	void MulticastPerConnectionUnreliable_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C

	// Object: Function slua_unreal.LuaPatchRPCComponent.MulticastPerConnection_LuaPatchRPC
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x10221972c
	// Params: [ Num(1) Size(0x40) ]
	void MulticastPerConnection_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C

	// Object: Function slua_unreal.LuaPatchRPCComponent.Multicast_LuaPatchRPC
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x102219674
	// Params: [ Num(1) Size(0x40) ]
	void Multicast_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C

	// Object: Function slua_unreal.LuaPatchRPCComponent.ClientUnreliable_LuaPatchRPC
	// Flags: [Net|Native|Event|Public|NetClient]
	// Offset: 0x1022195bc
	// Params: [ Num(1) Size(0x40) ]
	void ClientUnreliable_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C

	// Object: Function slua_unreal.LuaPatchRPCComponent.Client_LuaPatchRPC
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x102219504
	// Params: [ Num(1) Size(0x40) ]
	void Client_LuaPatchRPC(struct FLuaPatchRPCFrame Frame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C0D88
	// [Call #4] RVA: 0x1021C0D88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C0D88
	// [Call #9] RVA: 0x1021C0D88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C0D88
	// [Call #14] RVA: 0x1021C0D88
	// [Call #15] RVA: 0x106C8459C
};

// Object: Class slua_unreal.LuaPawn
// Size: 0x5C8 (Inherited: 0x510)
struct ALuaPawn : APawn
{
	uint8_t Pad_0x510[0x58]; // 0x510(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x568(0x50)
	struct FString LuaFilePath; // 0x5B8(0x10)
};

// Object: Class slua_unreal.LuaPlayerController
// Size: 0x8E0 (Inherited: 0x828)
struct ALuaPlayerController : APlayerController
{
	uint8_t Pad_0x828[0x58]; // 0x828(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x880(0x50)
	struct FString LuaFilePath; // 0x8D0(0x10)
};

// Object: Class slua_unreal.LuaPlayerState
// Size: 0x5F8 (Inherited: 0x540)
struct ALuaPlayerState : APlayerState
{
	uint8_t Pad_0x540[0x58]; // 0x540(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x598(0x50)
	struct FString LuaFilePath; // 0x5E8(0x10)
};

// Object: Class slua_unreal.LuaObject
// Size: 0x90 (Inherited: 0x28)
struct ULuaObject : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString LuaFilePath; // 0x80(0x10)
};

// Object: Class slua_unreal.LuaUserWidget
// Size: 0x2C8 (Inherited: 0x260)
struct ULuaUserWidget : UUserWidget
{
	uint8_t Pad_0x260[0x58]; // 0x260(0x58)
	struct FString LuaFilePath; // 0x2B8(0x10)
};

// Object: Class slua_unreal.SluaBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct USluaBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function slua_unreal.SluaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221b270
	// Params: [ Num(3) Size(0x38) ]
	struct FString GetStringFromVar(struct FSluaBPVar Value, int Index);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1021E810C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x1021DB65C
	// [Call #14] RVA: 0x1021DB65C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x10519022C

	// Object: Function slua_unreal.SluaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221b170
	// Params: [ Num(3) Size(0x30) ]
	struct UObject* GetObjectFromVar(struct FSluaBPVar Value, int Index);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1021E8230
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1021DB640
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10217475C
	// [Call #19] RVA: 0x1021E810C
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x1021DB65C
	// [Call #26] RVA: 0x1021DB65C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function slua_unreal.SluaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221b070
	// Params: [ Num(3) Size(0x28) ]
	float GetNumberFromVar(struct FSluaBPVar Value, int Index);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1021E7F20
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1021DB640
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10217475C
	// [Call #19] RVA: 0x1021E8230
	// [Call #20] RVA: 0x1021DB65C
	// [Call #21] RVA: 0x1021DB65C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x1021DB640
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221af70
	// Params: [ Num(3) Size(0x28) ]
	int GetIntFromVar(struct FSluaBPVar Value, int Index);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1021E7E2C
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1021DB640
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10217475C
	// [Call #19] RVA: 0x1021E7F20
	// [Call #20] RVA: 0x1021DB65C
	// [Call #21] RVA: 0x1021DB65C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x1021DB640
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221ae70
	// Params: [ Num(3) Size(0x25) ]
	bool GetBoolFromVar(struct FSluaBPVar Value, int Index);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1021E8014
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1021DB640
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10217475C
	// [Call #19] RVA: 0x1021E7E2C
	// [Call #20] RVA: 0x1021DB65C
	// [Call #21] RVA: 0x1021DB65C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x1021DB640
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221ad78
	// Params: [ Num(2) Size(0x30) ]
	struct FSluaBPVar CreateVarFromString(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1021E7B44
	// [Call #5] RVA: 0x1021747A0
	// [Call #6] RVA: 0x1021DB65C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1021DB640
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10217475C
	// [Call #20] RVA: 0x1021E8014
	// [Call #21] RVA: 0x1021DB65C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x1021DB65C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x1021DB640
	// [Call #27] RVA: 0x10516D168
	// [Call #28] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221acac
	// Params: [ Num(3) Size(0x30) ]
	struct FSluaBPVar CreateVarFromObject(struct UObject* WorldContextObject, struct UObject* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021E7C8C
	// [Call #6] RVA: 0x1021747A0
	// [Call #7] RVA: 0x1021DB65C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x1021E7B44
	// [Call #12] RVA: 0x1021747A0
	// [Call #13] RVA: 0x1021DB65C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1021DB640
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221ac1c
	// Params: [ Num(2) Size(0x28) ]
	struct FSluaBPVar CreateVarFromNumber(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021E7BE4
	// [Call #4] RVA: 0x1021747A0
	// [Call #5] RVA: 0x1021DB65C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1021E7C8C
	// [Call #11] RVA: 0x1021747A0
	// [Call #12] RVA: 0x1021DB65C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x1021E7B44
	// [Call #17] RVA: 0x1021747A0
	// [Call #18] RVA: 0x1021DB65C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221ab8c
	// Params: [ Num(2) Size(0x28) ]
	struct FSluaBPVar CreateVarFromInt(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021E7AF0
	// [Call #4] RVA: 0x1021747A0
	// [Call #5] RVA: 0x1021DB65C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021E7BE4
	// [Call #9] RVA: 0x1021747A0
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1021E7C8C
	// [Call #16] RVA: 0x1021747A0
	// [Call #17] RVA: 0x1021DB65C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221aaf4
	// Params: [ Num(2) Size(0x28) ]
	struct FSluaBPVar CreateVarFromBool(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021E7C38
	// [Call #4] RVA: 0x1021747A0
	// [Call #5] RVA: 0x1021DB65C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021E7AF0
	// [Call #9] RVA: 0x1021747A0
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021E7BE4
	// [Call #14] RVA: 0x1021747A0
	// [Call #15] RVA: 0x1021DB65C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function slua_unreal.SluaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10221a8b4
	// Params: [ Num(5) Size(0x58) ]
	struct FSluaBPVar CallToLuaWithArgs(struct UObject* WorldContextObject, struct FString FunctionName, struct TArray<struct FSluaBPVar>& Args, struct FString StateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x1021E764C
	// [Call #12] RVA: 0x1021747A0
	// [Call #13] RVA: 0x1021DB65C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x10221C840
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x10221C840
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x106C8459C

	// Object: Function slua_unreal.SluaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10221a6e4
	// Params: [ Num(4) Size(0x48) ]
	struct FSluaBPVar CallToLua(struct UObject* WorldContextObject, struct FString FunctionName, struct FString StateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x1021E78B0
	// [Call #10] RVA: 0x1021747A0
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4
	// [Call #27] RVA: 0x10516D168
};

