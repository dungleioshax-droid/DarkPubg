#pragma once

#include <cstdint>

// Object: Enum Skill.UTSkillStopReason
enum class EUTSkillStopReason : uint8_t
{
	SkillStopReason_None = 0,
	SkillStopReason_Finished = 1,
	SkillStopReason_Failed = 2,
	SkillStopReason_Interrupted = 3,
	SkillStopReason_PlayerDieInterrupted = 4,
	SkillStopReason_PlayerDisconnect = 5,
	SkillStopReason_PlayerCancel = 6,
	SkillStopReason_MAX = 7
};

// Object: Enum Skill.UTSkillEventType
enum class EUTSkillEventType : uint8_t
{
	SET_KEY_DOWN = 0,
	SET_KEY_UP = 1,
	SET_COLLIDE_TARGET = 2,
	SET_MISS_TARGET = 3,
	SET_HIT_TARGET = 4,
	SET_KILL_TARGET = 5,
	SET_COLLIDE_ACTOR = 6,
	SET_FINDPATH_FINISH = 7,
	SET_SKILL_ACTIVE = 8,
	SET_SKILL_CAST = 9,
	SET_SKILL_INIT = 10,
	SET_PHASE_START = 11,
	SET_PHASE_FINISH = 12,
	SET_PHASE_FINISH_EARLY = 13,
	SET_PHASE_INTERRUPT = 14,
	SET_SKILL_FINISH = 15,
	SET_SKILL_CANCEL = 16,
	SET_SKILL_CLOSE = 17,
	SET_NO_TARGET = 18,
	SET_SKILL_BREAK = 19,
	SET_NO_LOCATION = 20,
	SET_ATTEMPT_ACTIVE = 21,
	SET_SKILL_ACTIVE_AND_BUTTONSLOT = 22,
	SET_SKILL_CLOSE_AND_BUTTONSLOT = 23,
	SET_PHASE_JUMP = 24,
	SET_MAX = 25
};

// Object: Enum Skill.ESkillBaseWidgetType
enum class ESkillBaseWidgetType : uint8_t
{
	None = 0,
	SkillEffect = 1,
	SkillCondition = 2,
	SkillPicker = 3,
	SkillLocationPicker = 4,
	ESkillBaseWidgetType_MAX = 5
};

// Object: Enum Skill.ESkillCanBePlayedResult
enum class ESkillCanBePlayedResult : uint8_t
{
	Success = 0,
	Fail_Default = 1,
	Fail_ProneUseConsumables = 2,
	Fail_PawnState = 3,
	Fail_CD = 4,
	Fail_Disable = 5,
	Fail_NoToken = 6,
	Fail_CheckCondition = 7,
	ESkillCanBePlayedResult_MAX = 8
};

// Object: Enum Skill.ESkillCastType
enum class ESkillCastType : uint8_t
{
	Normal = 1,
	Trigger = 2,
	Passive = 3,
	Max = 4
};

// Object: Enum Skill.ESkillBlackboardResetRule
enum class ESkillBlackboardResetRule : uint8_t
{
	ESBBRR_None = 0,
	ESBBRR_SkillInit = 1,
	ESBBRR_SkillStart = 2,
	ESBBRR_SkillEnd = 3,
	ESBBRR_MAX = 4
};

// Object: Enum Skill.ECDOperationType
enum class ECDOperationType : uint8_t
{
	CD_Set = 0,
	CD_Add = 1,
	CD_Mul = 2,
	CD_MAX = 3
};

// Object: Enum Skill.ECDCompare
enum class ECDCompare : uint8_t
{
	CDC_Bigger = 0,
	CDC_Equal = 1,
	CDC_Smaller = 2,
	CDC_MAX = 3
};

// Object: Enum Skill.ECDRole
enum class ECDRole : uint8_t
{
	CDR_Default = 0,
	CDR_ClientPreAct = 1,
	CDR_ClientOnly = 2,
	CDR_MAX = 3
};

// Object: Enum Skill.ESkillConditionRole
enum class ESkillConditionRole : uint8_t
{
	ESCR_All = 0,
	ESCR_Authority = 1,
	ESCR_Autonomous = 2,
	ESCR_Simulated = 3,
	ESCR_AutonomousSimulated = 4,
	ESCR_AutonomousAuthority = 5,
	ESCR_MAX = 6
};

// Object: Enum Skill.ESkillActionRole
enum class ESkillActionRole : uint8_t
{
	ESAR_All = 0,
	ESAR_Authority = 1,
	ESAR_Autonomous = 2,
	ESAR_Simulated = 3,
	ESAR_AutonomousSimulated = 4,
	ESAR_AutonomousAuthority = 5,
	ESAR_AuthoritySimulated = 6,
	ESAR_MAX = 7
};

// Object: Enum Skill.ESkillAddForceDirection
enum class ESkillAddForceDirection : uint8_t
{
	ESkillDir_SelfToTarget = 0,
	ESkillDir_TargetToSelf = 1,
	ESkillDir_SelfDir = 2,
	ESkillDir_TargetDir = 3,
	ESkillDir_TargetZ = 4,
	ESkillDir_SelfZ = 5,
	ESkillDir_MAX = 6
};

// Object: Enum Skill.ESkillStage
enum class ESkillStage : uint8_t
{
	None = 1,
	Prepare = 2,
	Start = 3,
	Stop = 4,
	ESkillStage_MAX = 5
};

// Object: Enum Skill.ESkillAttrOperator
enum class ESkillAttrOperator : uint8_t
{
	None = 0,
	Plus = 1,
	Multiply = 2,
	Set = 3,
	ESkillAttrOperator_MAX = 4
};

// Object: Enum Skill.FSkillType
enum class EFSkillType : uint8_t
{
	None = 0,
	Medicine = 1,
	Damage = 2,
	FSkillType_MAX = 3
};

// Object: Enum Skill.ESkillIconStatus
enum class ESkillIconStatus : uint8_t
{
	IConBtnNone = 0,
	IconBtnNormal = 1,
	IconBtnActive = 2,
	IconBtnInCD = 3,
	IconBtnDown = 4,
	IconBtnUp = 5,
	IconBtnClick = 6,
	IconBtnHovered = 7,
	IconBtnUnHovered = 8,
	ESkillIconStatus_MAX = 9
};

// Object: Enum Skill.UTSkillTargetType
enum class EUTSkillTargetType : uint8_t
{
	STT_FRIEND = 0,
	STT_ENEMY = 1,
	STT_ALL = 2,
	STT_MAX = 3
};

// Object: Enum Skill.UTPickerTargetType
enum class EUTPickerTargetType : uint8_t
{
	PTT_FRIEND = 0,
	PTT_ENEMY = 1,
	PTT_ALL = 2,
	PTT_Self = 3,
	PTT_MAX = 4
};

// Object: Enum Skill.ETriggerSkillFailed
enum class ETriggerSkillFailed : uint8_t
{
	TriggerSkillFailed_NoSkill = 0,
	TriggerSkillFailed_VerifyFailed = 1,
	TriggerSkillFailed_MAX = 2
};

// Object: Enum Skill.ESkillMutexType
enum class ESkillMutexType : uint8_t
{
	ESMT_Y = 0,
	ESMT_X = 1,
	ESMT_XY = 2,
	ESMT_MAX = 3
};

// Object: Enum Skill.ESkillEndConditionType
enum class ESkillEndConditionType : uint8_t
{
	ESECT_MyHP = 0,
	ESECT_MyHPAndSD = 1,
	ESECT_FrinedHP = 2,
	ESECT_ExistsEnemy = 3,
	ESECT_ExistsEnemy2 = 4,
	ESECT_ExistsEnemyAndFriends = 5,
	ESECT_AnyTime = 6,
	ESECT_None = 7,
	ESECT_MAX = 8
};

// Object: Enum Skill.ESkillConditionType
enum class ESkillConditionType : uint8_t
{
	ESCT_MyHP = 0,
	ESCT_MyHPAndSD = 1,
	ESCT_MyHPAndSDNoEmeny = 2,
	ESCT_FrinedHP = 3,
	ESCT_ExistsEnemy = 4,
	ESCT_ExistsEnemy2 = 5,
	ESCT_ExistsEnemyAndFriends = 6,
	ESCT_AnyTime = 7,
	ESCT_None = 8,
	ESCT_MAX = 9
};

// Object: Enum Skill.UTSkillPhaseType
enum class EUTSkillPhaseType : uint8_t
{
	SPT_SEQUENCE = 0,
	SPT_WAIT = 1,
	SPT_FINAL_SKILL_PHASE = 2,
	SPT_Keep = 3,
	SPT_JUMP = 4,
	SPT_MAX = 5
};

// Object: Enum Skill.UTSkillPickerRole
enum class EUTSkillPickerRole : uint8_t
{
	SPR_Authority = 0,
	SPR_Autonomous = 1,
	SPR_Both = 2,
	SPR_MAX = 3
};

// Object: Enum Skill.UTSkillPickerType
enum class EUTSkillPickerType : uint8_t
{
	SPT_SELF = 0,
	SPT_TARGET = 1,
	SPT_VIEWPOINT = 2,
	SPT_VIEWPOINT_STATIC = 3,
	SPT_RECT = 4,
	SPT_CIRCLE = 5,
	SPT_CAPSULE = 6,
	SPT_FAN = 7,
	SPT_CROSSHAIR = 8,
	SPT_CUSTOM = 9,
	SPT_DESTINATION = 10,
	SPT_VIEWPOINT_NORMAL = 11,
	SPT_BLACKBOARD = 12,
	SPT_SELFVEHICLE = 13,
	SPT_DEFAULT = 14,
	SPT_MAX = 15
};

// Object: Enum Skill.ESkillDebugEventType
enum class ESkillDebugEventType : uint8_t
{
	ES_SkillStart = 0,
	ES_SkillPhaseStart = 1,
	ES_SkillInterrupt = 2,
	ES_OutputStats = 3,
	ES_SkillEnd = 4,
	ES_MAX = 5
};

// Object: ScriptStruct Skill.LuaEventRegistWrap
// Size: 0x40 (Inherited: 0x0)
struct FLuaEventRegistWrap
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
	struct UObject* Outer; // 0x28(0x8)
	uint8_t Pad_0x30[0x10]; // 0x30(0x10)
};

// Object: ScriptStruct Skill.MultiSharedDelegateWrap
// Size: 0x20 (Inherited: 0x0)
struct FMultiSharedDelegateWrap
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UObject* Outer; // 0x8(0x8)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct Skill.SharedDelegateWrap
// Size: 0x20 (Inherited: 0x0)
struct FSharedDelegateWrap
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UObject* Outer; // 0x8(0x8)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct Skill.SkillMetaData
// Size: 0x60 (Inherited: 0x0)
struct FSkillMetaData
{
	struct FString SkillName; // 0x0(0x10)
	struct TMap<int, struct FActionsMetaData> PhaseToActionsMetaData; // 0x10(0x50)
};

// Object: ScriptStruct Skill.ActionsMetaData
// Size: 0x50 (Inherited: 0x0)
struct FActionsMetaData
{
	struct TMap<struct FString, struct FActionMetaData> ActionMetaData; // 0x0(0x50)
};

// Object: ScriptStruct Skill.ActionMetaData
// Size: 0x20 (Inherited: 0x0)
struct FActionMetaData
{
	uint8_t ActionType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString Value; // 0x8(0x10)
	int Count; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct Skill.UTSkillActionCreateData
// Size: 0x8 (Inherited: 0x0)
struct FUTSkillActionCreateData
{
	enum class ESkillActionRole ActionRole; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float delayTime; // 0x4(0x4)
};

// Object: ScriptStruct Skill.UTSkillBlackboardParameter
// Size: 0xA8 (Inherited: 0x98)
struct FUTSkillBlackboardParameter : FUAEBlackboardParameter
{
	struct TArray<uint8_t> ResetRuleArray; // 0x98(0x10)
};

// Object: ScriptStruct Skill.TeammateSkillCDRepData
// Size: 0x10 (Inherited: 0x0)
struct FTeammateSkillCDRepData
{
	int SkillID; // 0x0(0x4)
	float CDStartTime; // 0x4(0x4)
	float CDEndTime; // 0x8(0x4)
	int UseCount; // 0xC(0x4)
};

// Object: ScriptStruct Skill.SkillCDRepData
// Size: 0x18 (Inherited: 0x0)
struct FSkillCDRepData
{
	int SkillID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FUTSkillSyncData_CD> CDSyncDatas; // 0x8(0x10)
};

// Object: ScriptStruct Skill.UTSkillSyncData_CD
// Size: 0x18 (Inherited: 0x0)
struct FUTSkillSyncData_CD
{
	int SkillCDIndex; // 0x0(0x4)
	float SkillTimeScale; // 0x4(0x4)
	struct FSkillNetBytesData CDSyncDatas; // 0x8(0x10)
};

// Object: ScriptStruct Skill.SkillNetBytesData
// Size: 0x10 (Inherited: 0x0)
struct FSkillNetBytesData
{
	struct TArray<uint8_t> Data; // 0x0(0x10)
};

// Object: ScriptStruct Skill.UTSkillComboInfo
// Size: 0xC (Inherited: 0x0)
struct FUTSkillComboInfo
{
	int ComboNextSkillID; // 0x0(0x4)
	bool bLongPressToCombo; // 0x4(0x1)
	bool bClickToCombo; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	float ClickTimeLimitBeforeSkillStop; // 0x8(0x4)
};

// Object: ScriptStruct Skill.UTSkillComboState
// Size: 0x18 (Inherited: 0x0)
struct FUTSkillComboState
{
	int CurSkillID; // 0x0(0x4)
	int CurInstID; // 0x4(0x4)
	struct FTimerHandle TimerHandle; // 0x8(0x8)
	float LocalStopTime; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Skill.UTSkillBBUploadData
// Size: 0x10 (Inherited: 0x0)
struct FUTSkillBBUploadData
{
	struct TArray<struct FName> KeyNames; // 0x0(0x10)
};

// Object: ScriptStruct Skill.SkillConditionWarpper
// Size: 0x8 (Inherited: 0x0)
struct FSkillConditionWarpper
{
	struct UUTSkillCondition* SkillCondition; // 0x0(0x8)
};

// Object: ScriptStruct Skill.UTSkillEventHistory
// Size: 0x50 (Inherited: 0x0)
struct FUTSkillEventHistory
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct Skill.UTSkillExecQueue
// Size: 0xB0 (Inherited: 0x0)
struct FUTSkillExecQueue
{
	uint8_t Pad_0x0[0xB0]; // 0x0(0xB0)
};

// Object: ScriptStruct Skill.UTSkillInstance
// Size: 0xE0 (Inherited: 0x0)
struct FUTSkillInstance
{
	int SkillID; // 0x0(0x4)
	int CurPhaseIndex; // 0x4(0x4)
	int LastPhaseIndex; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	uint64_t InstanceID; // 0x10(0x8)
	int SkillSlot; // 0x18(0x4)
	int Level; // 0x1C(0x4)
	int ActiveState; // 0x20(0x4)
	int SkillCDIndex; // 0x24(0x4)
	uint8_t StopReason; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FUTSkillCreateData SkillBaseData; // 0x30(0x70)
	struct TWeakObjectPtr<struct AUTSkill> CurSkill; // 0xA0(0x8)
	struct TWeakObjectPtr<struct UUTSkillWidget> CurSkillWidget; // 0xA8(0x8)
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerComp; // 0xB0(0x8)
	struct TArray<struct TWeakObjectPtr<struct AActor>> SkillActors; // 0xB8(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> SkillSharePickedTargets; // 0xC8(0x10)
	bool bGsListener; // 0xD8(0x1)
	uint8_t Pad_0xD9[0x7]; // 0xD9(0x7)
};

// Object: ScriptStruct Skill.UTSkillCreateData
// Size: 0x70 (Inherited: 0x0)
struct FUTSkillCreateData
{
	int SkillGroupIndex; // 0x0(0x4)
	float Interval; // 0x4(0x4)
	float IntervalSincePrevFinish; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString CoolDownMessage; // 0x10(0x10)
	int CoolDownMessageID; // 0x20(0x4)
	bool bEnableRepeat; // 0x24(0x1)
	bool bEnableCombo; // 0x25(0x1)
	uint8_t Pad_0x26[0x2]; // 0x26(0x2)
	struct FUTSkillComboInfo ComboInfo; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<struct UUTSkillPhase*> Phases; // 0x38(0x10)
	struct UUTSkillEffect* SkillActiveAction; // 0x48(0x8)
	struct UUTSkillEffect* SkillCloseAction; // 0x50(0x8)
	struct TArray<struct UUTSkillCDBase*> SkillCDs; // 0x58(0x10)
	uint8_t Pad_0x68[0x8]; // 0x68(0x8)
};

// Object: ScriptStruct Skill.SkillParamater
// Size: 0x20 (Inherited: 0x0)
struct FSkillParamater
{
	bool bUseTag; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FName SkillTag; // 0x8(0x8)
	uint8_t SkillType; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	float CDRecoveryScale; // 0x14(0x4)
	float SkillRuntimeScale; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct Skill.SkillParamaterModifier
// Size: 0x20 (Inherited: 0x20)
struct FSkillParamaterModifier : FSkillParamater
{
	uint8_t CDRecoveryScaleOP; // 0x1C(0x1)
	uint8_t SkillRuntimeScaleOp; // 0x1D(0x1)
};

// Object: ScriptStruct Skill.SkillDynamicRepData
// Size: 0xE0 (Inherited: 0x0)
struct FSkillDynamicRepData
{
	struct TArray<int> SkillData; // 0x0(0x10)
	uint8_t Pad_0x10[0xD0]; // 0x10(0xD0)
};

// Object: ScriptStruct Skill.SkillAttrRepData
// Size: 0xE0 (Inherited: 0x0)
struct FSkillAttrRepData
{
	struct TArray<struct FSkillAttrData> SkillData; // 0x0(0x10)
	uint8_t Pad_0x10[0xD0]; // 0x10(0xD0)
};

// Object: ScriptStruct Skill.SkillAttrData
// Size: 0xC (Inherited: 0x0)
struct FSkillAttrData
{
	int SkillID; // 0x0(0x4)
	int SkillLevel; // 0x4(0x4)
	int SkillSkinID; // 0x8(0x4)
};

// Object: ScriptStruct Skill.SkillActiveRepData
// Size: 0xE0 (Inherited: 0x0)
struct FSkillActiveRepData
{
	struct TArray<struct FSkillActiveData> SkillData; // 0x0(0x10)
	uint8_t Pad_0x10[0xD0]; // 0x10(0xD0)
};

// Object: ScriptStruct Skill.SkillActiveData
// Size: 0xC (Inherited: 0x0)
struct FSkillActiveData
{
	int SkillID; // 0x0(0x4)
	int SkillButtonSlot; // 0x4(0x4)
	bool bActive; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
};

// Object: ScriptStruct Skill.UTSkillRuntimeData
// Size: 0x20 (Inherited: 0x0)
struct FUTSkillRuntimeData
{
	bool bSkillActived; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int SkillButtonSlot; // 0x4(0x4)
	bool bShowSkillMainWidget; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct TArray<struct UUTSkillCDBase*> SkillCDs; // 0x10(0x10)
};

// Object: ScriptStruct Skill.UTReplaceSkillData
// Size: 0x8 (Inherited: 0x0)
struct FUTReplaceSkillData
{
	int OldSkillID; // 0x0(0x4)
	int NewSkillID; // 0x4(0x4)
};

// Object: ScriptStruct Skill.SkillSinglePhaseData
// Size: 0xF0 (Inherited: 0x0)
struct FSkillSinglePhaseData
{
	struct TArray<struct FUTSkillSynSinglePhaseData> SkillData; // 0x0(0x10)
	struct TArray<struct FUTSkillSynSinglePhaseData> LastSkillData; // 0x10(0x10)
	uint8_t Pad_0x20[0xD0]; // 0x20(0xD0)
};

// Object: ScriptStruct Skill.UTSkillSynSinglePhaseData
// Size: 0x30 (Inherited: 0x0)
struct FUTSkillSynSinglePhaseData
{
	uint64_t InstanceID; // 0x0(0x8)
	int SkillID; // 0x8(0x4)
	int CurSkillPhase; // 0xC(0x4)
	uint8_t StopReason; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct FSkillNetBytesData BlackboardBytesData; // 0x18(0x10)
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: ScriptStruct Skill.MultiSkillSynData
// Size: 0xF0 (Inherited: 0x0)
struct FMultiSkillSynData
{
	struct TArray<struct FUTMultiSkillSynData> SkillData; // 0x0(0x10)
	struct TArray<struct FUTMultiSkillSynData> LastSkillData; // 0x10(0x10)
	uint8_t Pad_0x20[0xD0]; // 0x20(0xD0)
};

// Object: ScriptStruct Skill.UTMultiSkillSynData
// Size: 0x40 (Inherited: 0x0)
struct FUTMultiSkillSynData
{
	bool bEnableRepeat; // 0x0(0x1)
	uint8_t StopReason; // 0x1(0x1)
	uint8_t Pad_0x2[0x6]; // 0x2(0x6)
	uint64_t InstanceID; // 0x8(0x8)
	int SkillID; // 0x10(0x4)
	int PhaseIndexes; // 0x14(0x4)
	struct FSkillNetBytesData PhaseIndexArray; // 0x18(0x10)
	struct FSkillNetBytesData BlackboardBytesData; // 0x28(0x10)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
};

// Object: ScriptStruct Skill.UTSkillSimulateData
// Size: 0x20 (Inherited: 0x0)
struct FUTSkillSimulateData
{
	uint64_t InstanceID; // 0x0(0x8)
	int SkillID; // 0x8(0x4)
	bool bSinglePhaseRep; // 0xC(0x1)
	uint8_t StopReason; // 0xD(0x1)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	struct TArray<int> SimlatePhaseIndexs; // 0x10(0x10)
};

// Object: ScriptStruct Skill.UTSkillHitEnvInfo
// Size: 0x30 (Inherited: 0x0)
struct FUTSkillHitEnvInfo
{
	struct TArray<struct AActor*> ToPawn; // 0x0(0x10)
	struct AActor* FromPawn; // 0x10(0x8)
	int SkillID; // 0x18(0x4)
	int SkillPhaseID; // 0x1C(0x4)
	enum class EPhysicalSurface HitSurfaceType; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	struct FVector HitEnvLocation; // 0x24(0xC)
};

// Object: ScriptStruct Skill.UTSkillHitInfo
// Size: 0x38 (Inherited: 0x0)
struct FUTSkillHitInfo
{
	struct TArray<struct AActor*> ToPawn; // 0x0(0x10)
	struct AActor* FromPawn; // 0x10(0x8)
	int SkillID; // 0x18(0x4)
	int SkillPhaseID; // 0x1C(0x4)
	float TimeSeconds; // 0x20(0x4)
	bool IsHeadShot; // 0x24(0x1)
	enum class EPhysicalSurface HitSurfaceType; // 0x25(0x1)
	uint8_t Pad_0x26[0x2]; // 0x26(0x2)
	struct FVector HitEnvLocation; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct Skill.SkillLocationFilterContext
// Size: 0x10 (Inherited: 0x0)
struct FSkillLocationFilterContext
{
	struct AActor* OwnerPawn; // 0x0(0x8)
	struct AUTSkill* OwnerSkill; // 0x8(0x8)
};

// Object: ScriptStruct Skill.SkillLimitKeySet
// Size: 0x50 (Inherited: 0x0)
struct FSkillLimitKeySet
{
	struct TSet<struct FString> KeySet; // 0x0(0x50)
};

// Object: ScriptStruct Skill.SkillDisableKeySet
// Size: 0x50 (Inherited: 0x0)
struct FSkillDisableKeySet
{
	struct TSet<struct FString> KeySet; // 0x0(0x50)
};

// Object: ScriptStruct Skill.UTSkillLastCastInfo
// Size: 0xC (Inherited: 0x0)
struct FUTSkillLastCastInfo
{
	int SkillID; // 0x0(0x4)
	float LastCastTime; // 0x4(0x4)
	float LastCastFinishTime; // 0x8(0x4)
};

// Object: ScriptStruct Skill.UTSkillAutoTriggerCondition
// Size: 0x28 (Inherited: 0x0)
struct FUTSkillAutoTriggerCondition
{
	enum class ESkillConditionType Condition; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int Param_W; // 0x4(0x4)
	int Param_X; // 0x8(0x4)
	int Param_Y; // 0xC(0x4)
	int Param_Z; // 0x10(0x4)
	enum class ESkillEndConditionType EndCondition; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	int Param_A; // 0x18(0x4)
	int Param_B; // 0x1C(0x4)
	int Param_C; // 0x20(0x4)
	int Param_D; // 0x24(0x4)
};

// Object: ScriptStruct Skill.UTSkillPhaseCreateData
// Size: 0x78 (Inherited: 0x0)
struct FUTSkillPhaseCreateData
{
	float PhaseDuration; // 0x0(0x4)
	float AltPhaseDuration; // 0x4(0x4)
	bool bMustHasTarget; // 0x8(0x1)
	bool bCoolDown; // 0x9(0x1)
	bool bCoolDownAfterPhase; // 0xA(0x1)
	bool bAllowSimulateEvent; // 0xB(0x1)
	bool bKeepTickState; // 0xC(0x1)
	bool bKeepTickStateWithConditionCheck; // 0xD(0x1)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	int CoolDownIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct UUTSkillCondition*> PhaseConditions; // 0x18(0x10)
	struct UUTSkillPicker* Picker; // 0x28(0x8)
	struct TArray<struct UUTSkillEffect*> Actions; // 0x30(0x10)
	struct TArray<struct UUTSkillEffect*> HurtAppearances; // 0x40(0x10)
	uint8_t PhaseType; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	int JumpPhaseIndex; // 0x54(0x4)
	struct TArray<struct FUAEBlackboardKeySelector> SyncBBKArray; // 0x58(0x10)
	struct TArray<struct UUTSkillEventEffectMapForEditor*> EditorEventEffectMap; // 0x68(0x10)
};

// Object: ScriptStruct Skill.UTSkillEventActionMap
// Size: 0x30 (Inherited: 0x0)
struct FUTSkillEventActionMap
{
	enum class EUTSkillEventType SkillEventType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UUTSkillEffect* Action; // 0x8(0x8)
	struct TArray<struct UUTSkillCondition*> Conditions; // 0x10(0x10)
	struct TArray<struct UUTSkillCondition*> TargetConditions; // 0x20(0x10)
};

// Object: ScriptStruct Skill.UTSkillPickedTarget
// Size: 0x38 (Inherited: 0x0)
struct FUTSkillPickedTarget
{
	struct TWeakObjectPtr<struct AActor> Target; // 0x0(0x8)
	struct TWeakObjectPtr<struct UPrimitiveComponent> TargetComponent; // 0x8(0x8)
	bool IsHeadShot; // 0x10(0x1)
	uint8_t HitPos; // 0x11(0x1)
	uint8_t Pad_0x12[0x6]; // 0x12(0x6)
	struct FName BoneName; // 0x18(0x8)
	struct FVector HitEnvLocation; // 0x20(0xC)
	float HitAngleCos; // 0x2C(0x4)
	enum class EPhysicalSurface HitPhysMatType; // 0x30(0x1)
	bool IgnoreTakeDamage; // 0x31(0x1)
	uint8_t Pad_0x32[0x6]; // 0x32(0x6)
};

// Object: ScriptStruct Skill.UTSkillPickerCreateData
// Size: 0x50 (Inherited: 0x0)
struct FUTSkillPickerCreateData
{
	uint8_t PickerType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FUAEBlackboardKeySelector PickerOriginBlackboardKey; // 0x8(0x8)
	uint8_t PickerTargetType; // 0x10(0x1)
	uint8_t PickerTargetRole; // 0x11(0x1)
	uint8_t Pad_0x12[0x2]; // 0x12(0x2)
	int PickerMaxCount; // 0x14(0x4)
	bool bIncludeOwner; // 0x18(0x1)
	bool bIgnoreEnableAnyDamageTagIfOwnerIsSelf; // 0x19(0x1)
	bool bOnlyHero; // 0x1A(0x1)
	bool bPickDoor; // 0x1B(0x1)
	bool bPickImplImpactInterface; // 0x1C(0x1)
	bool bForceSimPick; // 0x1D(0x1)
	bool bEnableTrace; // 0x1E(0x1)
	bool bEnableVehicleTrace; // 0x1F(0x1)
	bool bIsUsingViewRotation; // 0x20(0x1)
	bool bIgnoreViewRotationPitch; // 0x21(0x1)
	bool bPickByTrace; // 0x22(0x1)
	bool IsCheckHeadshot; // 0x23(0x1)
	bool bUseNewOffset; // 0x24(0x1)
	bool bIgnoreOwnerVehicleWhenTracePlayer; // 0x25(0x1)
	bool bIgnoreTargetVehicleWhenTracePlayer; // 0x26(0x1)
	bool bIgnoreDriverCharacter; // 0x27(0x1)
	bool bOwnerActorMustBuilding; // 0x28(0x1)
	bool bUse2DAngle; // 0x29(0x1)
	bool bSortByDistInNarrowAngle; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x1]; // 0x2B(0x1)
	float NarrowAngleInDegree; // 0x2C(0x4)
	bool bSortByDistInNarrowBox; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	struct FVector NarrowBoxExtent; // 0x34(0xC)
	struct FVector TargetLocationOffset; // 0x40(0xC)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct Skill.SkillFuncNameSelector
// Size: 0x10 (Inherited: 0x0)
struct FSkillFuncNameSelector
{
	struct FName SelectedKeyName; // 0x0(0x8)
	bool bLuaFunction; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Skill.SkillFlowExecutionStep
// Size: 0x70 (Inherited: 0x0)
struct FSkillFlowExecutionStep
{
	uint8_t Pad_0x0[0x70]; // 0x0(0x70)
};

// Object: ScriptStruct Skill.SkillFlowStatsLog
// Size: 0x20 (Inherited: 0x0)
struct FSkillFlowStatsLog
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: Class Skill.PrivateNodeLuaInterface
// Size: 0x28 (Inherited: 0x28)
struct IPrivateNodeLuaInterface : ILuaOverriderInterface
{

	// Object: Function Skill.PrivateNodeLuaInterface.SetPrivateUniqueKey
	// Flags: [Native|Public]
	// Offset: 0x1022920f0
	// Params: [ Num(1) Size(0x10) ]
	void SetPrivateUniqueKey(struct FString NewKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519077C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function Skill.PrivateNodeLuaInterface.GetPrivateUniqueKey
	// Flags: [Native|Public]
	// Offset: 0x102292084
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetPrivateUniqueKey();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519077C
};

// Object: Class Skill.UniqueKeyOwnerLuaInterface
// Size: 0x28 (Inherited: 0x28)
struct IUniqueKeyOwnerLuaInterface : ILuaOverriderInterface
{
};

// Object: Class Skill.SharedDelegate
// Size: 0x48 (Inherited: 0x28)
struct USharedDelegate : UObject
{
	struct UObject* FunctionOuter; // 0x28(0x8)
	struct FName FunctionName; // 0x30(0x8)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)


	// Object: Function Skill.SharedDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022926d4
	// Params: [ Num(0) Size(0x0) ]
	void EventTrigger();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class Skill.LuaEventSharedDelegate
// Size: 0x48 (Inherited: 0x48)
struct ULuaEventSharedDelegate : USharedDelegate
{
};

// Object: Class Skill.SharedDelegateManager
// Size: 0x140 (Inherited: 0x30)
struct USharedDelegateManager : UWorldSubsystem
{
	struct TMap<struct FSharedDelegateWrap, struct USharedDelegate*> DelegateMap; // 0x30(0x50)
	struct TMap<struct FMultiSharedDelegateWrap, struct USharedDelegate*> MultiDelegateMap; // 0x80(0x50)
	struct TMap<struct FLuaEventRegistWrap, struct ULuaEventSharedDelegate*> LuaEventRegistMap; // 0xD0(0x50)
	struct TArray<struct USharedDelegate*> CacheSharedDelegates; // 0x120(0x10)
	struct TArray<struct ULuaEventSharedDelegate*> CacheLuaEventSharedDelegates; // 0x130(0x10)
};

// Object: Class Skill.SkillNodeLuaInterface
// Size: 0x28 (Inherited: 0x28)
struct ISkillNodeLuaInterface : IInterface
{
};

// Object: Class Skill.UTSkillBaseWidget
// Size: 0x78 (Inherited: 0x28)
struct UUTSkillBaseWidget : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
	bool bWidgetEnabled; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
	struct FString EffectName; // 0x50(0x10)
	struct AActor* BuffTargetActor; // 0x60(0x8)
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // 0x68(0x8)
	struct UActorComponent* CurOwnerActorComponent; // 0x70(0x8)


	// Object: Function Skill.UTSkillBaseWidget.IsSetValueAsNewDataWhenNotExist
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10229e254
	// Params: [ Num(2) Size(0x9) ]
	bool IsSetValueAsNewDataWhenNotExist(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Skill.UTSkillBaseWidget.GetUAEBlackboard
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10229e218
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEBlackboard* GetUAEBlackboard();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Skill.UTSkillBaseWidget.GetOwnerSkillManager
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10229e1dc
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillManagerComponent* GetOwnerSkillManager();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Skill.UTSkillBaseWidget.GetOwnerSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10229e1a8
	// Params: [ Num(1) Size(0x4) ]
	int GetOwnerSkillID();
	// [Call #1] RVA: 0x102260FA0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Skill.UTSkillBaseWidget.GetOwnerPawn
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10229e16c
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwnerPawn();
	// [Call #1] RVA: 0x102260FA0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

// Object: Class Skill.SkillTriggerData
// Size: 0x90 (Inherited: 0x78)
struct USkillTriggerData : UUTSkillBaseWidget
{
	struct TArray<struct FUAEBlackboardKeySelector> UploadSkillTriggerData; // 0x78(0x10)
	enum class EUTSkillEventType CurSkillEvent; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)


	// Object: Function Skill.SkillTriggerData.GetSkillEventType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102292e28
	// Params: [ Num(1) Size(0x1) ]
	enum class EUTSkillEventType GetSkillEventType();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class Skill.SkillTriggerData_Lua
// Size: 0x1B8 (Inherited: 0x90)
struct USkillTriggerData_Lua : USkillTriggerData
{
	uint8_t Pad_0x90[0xC0]; // 0x90(0xC0)
	struct TMap<struct FString, struct FString> ActionParams; // 0x150(0x50)
	bool bEnableLuaPrivateData; // 0x1A0(0x1)
	uint8_t Pad_0x1A1[0x7]; // 0x1A1(0x7)
	struct FString LuaFilePath; // 0x1A8(0x10)
};

// Object: Class Skill.UTSkill
// Size: 0x7F8 (Inherited: 0x570)
struct AUTSkill : ALuaActor
{
	uint8_t Pad_0x570[0x20]; // 0x570(0x20)
	bool bNeedSync; // 0x590(0x1)
	uint8_t Pad_0x591[0x7]; // 0x591(0x7)
	struct FString SkillName; // 0x598(0x10)
	struct FName SkillGroup; // 0x5A8(0x8)
	bool bSinglePhaseRep; // 0x5B0(0x1)
	uint8_t SkillCastType; // 0x5B1(0x1)
	bool bShouldMonopolize; // 0x5B2(0x1)
	bool bMonopolizeSelf; // 0x5B3(0x1)
	bool bConsumeDelayTask; // 0x5B4(0x1)
	uint8_t Pad_0x5B5[0x3]; // 0x5B5(0x3)
	int SkillID; // 0x5B8(0x4)
	int SkillTemplateID; // 0x5BC(0x4)
	struct TSet<int> SkillTags; // 0x5C0(0x50)
	bool bMeleeSkill; // 0x610(0x1)
	bool bMoveSkill; // 0x611(0x1)
	bool bCheckFirstPhaseConditions; // 0x612(0x1)
	bool bNeedCheckSimulateCondition; // 0x613(0x1)
	bool bNeedAutonomousClientSimulate; // 0x614(0x1)
	bool bAutoShowRegisteredSkillUI; // 0x615(0x1)
	bool bKeepCastingWhenDisconnect; // 0x616(0x1)
	uint8_t Pad_0x617[0x1]; // 0x617(0x1)
	struct FUTSkillCreateData BaseData; // 0x618(0x70)
	bool bCoolDownWhenStop; // 0x688(0x1)
	uint8_t Pad_0x689[0x3]; // 0x689(0x3)
	int CoolDownWhenStopIndex; // 0x68C(0x4)
	bool bUseNewSkillCD; // 0x690(0x1)
	uint8_t Pad_0x691[0x7]; // 0x691(0x7)
	struct TArray<struct FUTSkillBlackboardParameter> SkillBlackboardParamList; // 0x698(0x10)
	bool bSetBlackboardDefaultData; // 0x6A8(0x1)
	bool bGsListener; // 0x6A9(0x1)
	bool bRecycleWhenStop; // 0x6AA(0x1)
	bool bHasBlackboradSync; // 0x6AB(0x1)
	uint8_t Pad_0x6AC[0x4]; // 0x6AC(0x4)
	struct FString SkillTimeScaleAttrName; // 0x6B0(0x10)
	struct FName SkillTimeScaleBlackboardKey; // 0x6C0(0x8)
	struct USkillTriggerData* SkillTriggerData; // 0x6C8(0x8)
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // 0x6D0(0x50)
	int InstancedNodesTotalSize; // 0x720(0x4)
	uint8_t Pad_0x724[0x4]; // 0x724(0x4)
	struct TArray<struct FString> ParentFolderPath; // 0x728(0x10)
	int CurComponentNameIndex; // 0x738(0x4)
	uint8_t Pad_0x73C[0xA4]; // 0x73C(0xA4)
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> SpecificSkillCompRef; // 0x7E0(0x8)
	struct TWeakObjectPtr<struct UUAEBlackboard> SpecificBlackBlackRef; // 0x7E8(0x8)
	struct UActorComponent* CurOwnerActorComponent; // 0x7F0(0x8)


	// Object: Function Skill.UTSkill.VerifyServerSkillData
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102293fe8
	// Params: [ Num(3) Size(0xA) ]
	bool VerifyServerSkillData(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType InEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkill.StopSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102293f28
	// Params: [ Num(2) Size(0xC) ]
	void StopSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkill.ResetSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102293e68
	// Params: [ Num(2) Size(0xC) ]
	void ResetSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.OnEvent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102293d5c
	// Params: [ Num(4) Size(0x11) ]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType, int PhaseIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.JumpToPhase
	// Flags: [Native|Public]
	// Offset: 0x102293c8c
	// Params: [ Num(3) Size(0xD) ]
	bool JumpToPhase(struct UUTSkillManagerComponent* SkillManagerComponent, int PhaseId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.IsMeleeSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102293c50
	// Params: [ Num(1) Size(0x1) ]
	bool IsMeleeSkill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102293bbc
	// Params: [ Num(2) Size(0x9) ]
	bool IsEnableSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.IsCDOK
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293aec
	// Params: [ Num(3) Size(0xD) ]
	bool IsCDOK(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.HandleVerifyServerSkillDataFail
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102293a2c
	// Params: [ Num(2) Size(0x9) ]
	void HandleVerifyServerSkillDataFail(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType InEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetSpecificSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022939f8
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillManagerComponent* GetSpecificSkillManager();
	// [Call #1] RVA: 0x10225EFE8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetSpecificBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022939c4
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEBlackboard* GetSpecificBlackboard();
	// [Call #1] RVA: 0x10225F024
	// [Call #2] RVA: 0x10225EFE8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetSkillPhaseByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293914
	// Params: [ Num(2) Size(0x18) ]
	struct UUTSkillPhase* GetSkillPhaseByName(struct FString PhaseName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10225F024
	// [Call #7] RVA: 0x10225EFE8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.GetSkillPhase
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293880
	// Params: [ Num(2) Size(0x10) ]
	struct UUTSkillPhase* GetSkillPhase(int PhaseIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10225F024
	// [Call #9] RVA: 0x10225EFE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetSkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102293844
	// Params: [ Num(1) Size(0x4) ]
	int GetSkillID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10225F024
	// [Call #9] RVA: 0x10225EFE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.GetSkillEffectByPhaseName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293740
	// Params: [ Num(3) Size(0x28) ]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseName(struct FString PhaseName, struct FString EffectName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetSkillEffectByPhaseIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293654
	// Params: [ Num(3) Size(0x20) ]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseIndex(int PhaseIndex, struct FString EffectName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Skill.UTSkill.GetSkillDurationScale
	// Flags: [Native|Public]
	// Offset: 0x1022935c0
	// Params: [ Num(2) Size(0xC) ]
	float GetSkillDurationScale(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Skill.UTSkill.GetCurSkillPhaseIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10229352c
	// Params: [ Num(2) Size(0xC) ]
	int GetCurSkillPhaseIndex(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkill.GetCurSkillPhase
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293498
	// Params: [ Num(2) Size(0x10) ]
	struct UUTSkillPhase* GetCurSkillPhase(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.GetCoolDownTime
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022933c8
	// Params: [ Num(3) Size(0x10) ]
	float GetCoolDownTime(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.DoSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102293308
	// Params: [ Num(2) Size(0xC) ]
	void DoSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkill.CanBePlayed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102293274
	// Params: [ Num(2) Size(0x9) ]
	uint8_t CanBePlayed(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillEffect
// Size: 0x88 (Inherited: 0x78)
struct UUTSkillEffect : UUTSkillBaseWidget
{
	struct TArray<struct UObject*> CacheSoftObject; // 0x78(0x10)


	// Object: Function Skill.UTSkillEffect.UpdateAction
	// Flags: [Native|Public]
	// Offset: 0x10229e9d0
	// Params: [ Num(2) Size(0xC) ]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillEffect.UndoAction
	// Flags: [Native|Public]
	// Offset: 0x10229e94c
	// Params: [ Num(1) Size(0x8) ]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillEffect.PreCloseSkill
	// Flags: [Native|Public]
	// Offset: 0x10229e890
	// Params: [ Num(2) Size(0x10) ]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkillEffect.PostInitSkill
	// Flags: [Native|Public]
	// Offset: 0x10229e7d4
	// Params: [ Num(2) Size(0x10) ]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillEffect.PostActiveSkill
	// Flags: [Native|Public]
	// Offset: 0x10229e718
	// Params: [ Num(2) Size(0x10) ]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillEffect.OnAsyncLoadSoftPathDone
	// Flags: [Final|Native|Public]
	// Offset: 0x10229e704
	// Params: [ Num(0) Size(0x0) ]
	void OnAsyncLoadSoftPathDone();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillEffect.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10229e6d0
	// Params: [ Num(1) Size(0x8) ]
	struct AUTSkill* GetOwnerSkill();
	// [Call #1] RVA: 0x1022611F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillEffect.DoHurtAppearance
	// Flags: [Native|Public]
	// Offset: 0x10229e614
	// Params: [ Num(2) Size(0x10) ]
	void DoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022611F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillEffect.DoAction
	// Flags: [Native|Public]
	// Offset: 0x10229e53c
	// Params: [ Num(3) Size(0xA) ]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent, bool bCheckSkillStopped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022611F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
};

// Object: Class Skill.UTSkillAction
// Size: 0xA8 (Inherited: 0x88)
struct UUTSkillAction : UUTSkillEffect
{
	struct FUTSkillActionCreateData BaseData; // 0x88(0x8)
	struct UUTSkillAction* OwnerPeriodAction; // 0x90(0x8)
	uint8_t Pad_0x98[0x8]; // 0x98(0x8)
	struct UObject* EventObj; // 0xA0(0x8)


	// Object: Function Skill.UTSkillAction.UpdateAction_Internal
	// Flags: [Native|Public]
	// Offset: 0x1022951bc
	// Params: [ Num(1) Size(0x4) ]
	void UpdateAction_Internal(float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction.UpdateAction
	// Flags: [Final|Native|Public]
	// Offset: 0x102295104
	// Params: [ Num(2) Size(0xC) ]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225FD3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction.UndoAction_Internal
	// Flags: [Native|Public]
	// Offset: 0x1022950e8
	// Params: [ Num(0) Size(0x0) ]
	void UndoAction_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225FD3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction.UndoAction
	// Flags: [Final|Native|Public]
	// Offset: 0x10229506c
	// Params: [ Num(1) Size(0x8) ]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225FA30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225FD3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction.TimerRealDoAction
	// Flags: [Final|Native|Public]
	// Offset: 0x102294fac
	// Params: [ Num(2) Size(0x9) ]
	void TimerRealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent, bool bCheckSkillStopped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225FA14
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225FA30
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10225FD3C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Skill.UTSkillAction.Reset_Internal
	// Flags: [Native|Public]
	// Offset: 0x102294f90
	// Params: [ Num(0) Size(0x0) ]
	void Reset_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225FA14
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225FA30
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10225FD3C

	// Object: Function Skill.UTSkillAction.Reset
	// Flags: [Final|Native|Public]
	// Offset: 0x102294f14
	// Params: [ Num(1) Size(0x8) ]
	void Reset(struct UActorComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225FDAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225FA14
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10225FA30
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillAction.RealDoHurtAppearance_Internal
	// Flags: [Native|Public]
	// Offset: 0x102294e58
	// Params: [ Num(2) Size(0x10) ]
	void RealDoHurtAppearance_Internal(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10225FDAC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225FA14
	// [Call #13] RVA: 0x10516D168

	// Object: Function Skill.UTSkillAction.RealDoHurtAppearance
	// Flags: [Final|Native|Public]
	// Offset: 0x102294da4
	// Params: [ Num(2) Size(0x10) ]
	void RealDoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225F564
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225FDAC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillAction.RealDoAction_Internal
	// Flags: [Native|Public]
	// Offset: 0x102294d68
	// Params: [ Num(1) Size(0x1) ]
	bool RealDoAction_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225F564
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225FDAC

	// Object: Function Skill.UTSkillAction.RealDoAction
	// Flags: [Final|Native|Public]
	// Offset: 0x102294c98
	// Params: [ Num(3) Size(0xA) ]
	bool RealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent, bool bCheckSkillStopped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225F8E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10225F564
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillAction.OnAsyncLoadAssetDone
	// Flags: [Final|Native|Public]
	// Offset: 0x102294ba0
	// Params: [ Num(3) Size(0x11) ]
	void OnAsyncLoadAssetDone(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* SkillAppearanceVictim, bool bSkillAppearance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022601FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225F8E8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillAction.JudgeNeedPhaseWait
	// Flags: [Native|Public]
	// Offset: 0x102294b64
	// Params: [ Num(1) Size(0x1) ]
	bool JudgeNeedPhaseWait();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022601FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225F8E8

	// Object: Function Skill.UTSkillAction.DoHurtAppearance
	// Flags: [Final|Native|Public]
	// Offset: 0x102294ab0
	// Params: [ Num(2) Size(0x10) ]
	void DoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225F1D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022601FC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillAction.DoAction
	// Flags: [Native|Public]
	// Offset: 0x1022949d8
	// Params: [ Num(3) Size(0xA) ]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent, bool bCheckSkillStopped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10225F1D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillAction_Lua
// Size: 0x1D0 (Inherited: 0xA8)
struct UUTSkillAction_Lua : UUTSkillAction
{
	uint8_t Pad_0xA8[0xC0]; // 0xA8(0xC0)
	struct TMap<struct FString, struct FString> ActionParams; // 0x168(0x50)
	bool bEnableLuaPrivateData; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x7]; // 0x1B9(0x7)
	struct FString LuaFilePath; // 0x1C0(0x10)
};

// Object: Class Skill.UTSkillAction_LuaContainer
// Size: 0x1E0 (Inherited: 0x1D0)
struct UUTSkillAction_LuaContainer : UUTSkillAction_Lua
{
	struct UUTSkillAction* Action; // 0x1D0(0x8)
	bool bDefaultDoAction; // 0x1D8(0x1)
	bool bDefaultUpdateAction; // 0x1D9(0x1)
	bool bDefaultResetAction; // 0x1DA(0x1)
	bool bDefaultUndoAction; // 0x1DB(0x1)
	uint8_t Pad_0x1DC[0x4]; // 0x1DC(0x4)


	// Object: Function Skill.UTSkillAction_LuaContainer.UpdateActionInContainer
	// Flags: [Final|Native|Public]
	// Offset: 0x102295a54
	// Params: [ Num(2) Size(0xC) ]
	void UpdateActionInContainer(struct UActorComponent* SkillManagerComponent, float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10228E75C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction_LuaContainer.UndoActionInContainer
	// Flags: [Final|Native|Public]
	// Offset: 0x1022959d8
	// Params: [ Num(1) Size(0x8) ]
	void UndoActionInContainer(struct UActorComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10228E7BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10228E75C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Skill.UTSkillAction_LuaContainer.ResetActionInContainer
	// Flags: [Final|Native|Public]
	// Offset: 0x10229595c
	// Params: [ Num(1) Size(0x8) ]
	void ResetActionInContainer(struct UActorComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10228E81C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10228E7BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10228E75C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function Skill.UTSkillAction_LuaContainer.RealDoActionInContainer
	// Flags: [Final|Native|Public]
	// Offset: 0x1022958d0
	// Params: [ Num(2) Size(0x9) ]
	bool RealDoActionInContainer(struct UActorComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10228E6D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10228E81C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10228E7BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10228E75C
};

// Object: Class Skill.UTSkillBlackboardInterface
// Size: 0x28 (Inherited: 0x28)
struct IUTSkillBlackboardInterface : IInterface
{

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10229814c
	// Params: [ Num(3) Size(0x18) ]
	void SetValueAsWeakObject(int SkillID, struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102298038
	// Params: [ Num(3) Size(0x1C) ]
	void SetValueAsVector(int SkillID, struct FName& KeyName, struct FVector VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsUInt
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102297f24
	// Params: [ Num(3) Size(0x14) ]
	void SetValueAsUInt(int SkillID, struct FName& KeyName, uint32_t UIntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297da0
	// Params: [ Num(3) Size(0x20) ]
	void SetValueAsString(int SkillID, struct FName& KeyName, struct FString StringValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102297c8c
	// Params: [ Num(3) Size(0x1C) ]
	void SetValueAsRotator(int SkillID, struct FName& KeyName, struct FRotator VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297b78
	// Params: [ Num(3) Size(0x18) ]
	void SetValueAsObject(int SkillID, struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297a64
	// Params: [ Num(3) Size(0x18) ]
	void SetValueAsName(int SkillID, struct FName& KeyName, struct FName NameValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297950
	// Params: [ Num(3) Size(0x14) ]
	void SetValueAsInt(int SkillID, struct FName& KeyName, int IntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10229783c
	// Params: [ Num(3) Size(0x14) ]
	void SetValueAsFloat(int SkillID, struct FName& KeyName, float FloatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297728
	// Params: [ Num(3) Size(0x11) ]
	void SetValueAsEnum(int SkillID, struct FName& KeyName, uint8_t EnumValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102297614
	// Params: [ Num(3) Size(0x18) ]
	void SetValueAsClass(int SkillID, struct FName& KeyName, struct UObject* ClassValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022974f8
	// Params: [ Num(3) Size(0x11) ]
	void SetValueAsBool(int SkillID, struct FName& KeyName, bool BoolValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102297418
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistWeakObject(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistVector
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102297338
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistVector(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistUInt
	// Flags: [Native|Public|HasOutParms|Const]
	// Offset: 0x102297258
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistUInt(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102297178
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistString(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistRotator
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102297098
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistRotator(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296fb8
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistObject(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296ed8
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistName(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296df8
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistInt(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296d18
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistFloat(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296c38
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistEnum(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296b58
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistClass(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.IsExistBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296a78
	// Params: [ Num(3) Size(0x11) ]
	bool IsExistBool(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296998
	// Params: [ Num(3) Size(0x18) ]
	struct UObject* GetValueAsWeakObject(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsWeakActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022968b8
	// Params: [ Num(3) Size(0x18) ]
	struct AActor* GetValueAsWeakActor(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022967d4
	// Params: [ Num(3) Size(0x1C) ]
	struct FVector GetValueAsVector(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsUInt
	// Flags: [Native|Public|HasOutParms|Const]
	// Offset: 0x1022966f4
	// Params: [ Num(3) Size(0x14) ]
	uint32_t GetValueAsUInt(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022965ec
	// Params: [ Num(3) Size(0x20) ]
	struct FString GetValueAsString(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296508
	// Params: [ Num(3) Size(0x1C) ]
	struct FRotator GetValueAsRotator(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296428
	// Params: [ Num(3) Size(0x18) ]
	struct UObject* GetValueAsObject(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296348
	// Params: [ Num(3) Size(0x18) ]
	struct FName GetValueAsName(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296268
	// Params: [ Num(3) Size(0x14) ]
	int GetValueAsInt(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102296188
	// Params: [ Num(3) Size(0x14) ]
	float GetValueAsFloat(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022960a8
	// Params: [ Num(3) Size(0x11) ]
	uint8_t GetValueAsEnum(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102295fc8
	// Params: [ Num(3) Size(0x18) ]
	struct UObject* GetValueAsClass(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102295ee8
	// Params: [ Num(3) Size(0x11) ]
	bool GetValueAsBool(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetValueAsActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102295e08
	// Params: [ Num(3) Size(0x18) ]
	struct AActor* GetValueAsActor(int SkillID, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillBlackboardInterface.GetUAEBlackboardBySkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102295d74
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEBlackboard* GetUAEBlackboardBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillCDBase
// Size: 0xC0 (Inherited: 0x90)
struct UUTSkillCDBase : ULuaObject
{
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerSkillManager; // 0x90(0x8)
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // 0x98(0x8)
	float TimeScale; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct TArray<uint8_t> SyncContent; // 0xA8(0x10)
	bool bIgnoreCastSkillCheck; // 0xB8(0x1)
	uint8_t CDRole; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x6]; // 0xBA(0x6)


	// Object: Function Skill.UTSkillCDBase.BindLua
	// Flags: [Final|Native|Public]
	// Offset: 0x102298f90
	// Params: [ Num(1) Size(0x10) ]
	void BindLua(struct FString luaPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1022763A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x1051903D0
	// [Call #15] RVA: 0x10508F76C
};

// Object: Class Skill.UTSkillCondition
// Size: 0x80 (Inherited: 0x78)
struct UUTSkillCondition : UUTSkillBaseWidget
{
	bool bTickCheckCondition; // 0x78(0x1)
	enum class ESkillConditionRole ConditionRole; // 0x79(0x1)
	uint8_t Pad_0x7A[0x6]; // 0x7A(0x6)


	// Object: Function Skill.UTSkillCondition.PreCloseSkill
	// Flags: [Native|Public]
	// Offset: 0x10229d99c
	// Params: [ Num(2) Size(0x10) ]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillCondition.PostInitSkill
	// Flags: [Native|Public]
	// Offset: 0x10229d8e0
	// Params: [ Num(2) Size(0x10) ]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkillCondition.PostActiveSkill
	// Flags: [Native|Public]
	// Offset: 0x10229d824
	// Params: [ Num(2) Size(0x10) ]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillCondition.IsTargetOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10229d758
	// Params: [ Num(3) Size(0x11) ]
	bool IsTargetOK(struct UActorComponent* SkillManagerComponent, struct AActor* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillCondition.IsOK_Internal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x10229d71c
	// Params: [ Num(1) Size(0x1) ]
	bool IsOK_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillCondition.IsOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10229d688
	// Params: [ Num(2) Size(0x9) ]
	bool IsOK(struct UActorComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillCondition.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10229d654
	// Params: [ Num(1) Size(0x8) ]
	struct AUTSkill* GetOwnerSkill();
	// [Call #1] RVA: 0x10227298C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillCondition_Lua
// Size: 0x1A8 (Inherited: 0x80)
struct UUTSkillCondition_Lua : UUTSkillCondition
{
	uint8_t Pad_0x80[0xC0]; // 0x80(0xC0)
	struct TMap<struct FString, struct FString> ConditionParams; // 0x140(0x50)
	bool bEnableLuaPrivateData; // 0x190(0x1)
	uint8_t Pad_0x191[0x7]; // 0x191(0x7)
	struct FString LuaFilePath; // 0x198(0x10)
};

// Object: Class Skill.UTSkillEvent
// Size: 0x30 (Inherited: 0x28)
struct UUTSkillEvent : UObject
{
	enum class EUTSkillEventType SkillEventType; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: Class Skill.UTSkillEventEffectMapForEditor
// Size: 0xC0 (Inherited: 0x78)
struct UUTSkillEventEffectMapForEditor : UUTSkillBaseWidget
{
	enum class EUTSkillEventType SkillEventType; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
	struct TArray<struct FName> InterestedOwnerTags; // 0x80(0x10)
	struct UUTSkillEffect* SkillEffect; // 0x90(0x8)
	bool bUndoExecute; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
	struct TArray<struct FSkillConditionWarpper> Conditions; // 0xA0(0x10)
	struct TArray<struct FSkillConditionWarpper> TargetConditions; // 0xB0(0x10)
};

// Object: Class Skill.UTSkillInstancedNodeContainerInterface
// Size: 0x28 (Inherited: 0x28)
struct IUTSkillInstancedNodeContainerInterface : IInterface
{
};

// Object: Class Skill.UTSkillInstancedNodeInterface
// Size: 0x28 (Inherited: 0x28)
struct IUTSkillInstancedNodeInterface : IInterface
{

	// Object: Function Skill.UTSkillInstancedNodeInterface.PostOverrideLua
	// Flags: [Native|Public]
	// Offset: 0x10229f5ac
	// Params: [ Num(0) Size(0x0) ]
	void PostOverrideLua();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102292260
	// [Call #5] RVA: 0x105185230
	// [Call #6] RVA: 0x1051903D0
	// [Call #7] RVA: 0x102292260
	// [Call #8] RVA: 0x105185230
};

// Object: Class Skill.UTSkillInterface
// Size: 0x28 (Inherited: 0x28)
struct IUTSkillInterface : IInterface
{

	// Object: Function Skill.UTSkillInterface.IsNeedCheckAutoSkill
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a0b48
	// Params: [ Num(1) Size(0x1) ]
	bool IsNeedCheckAutoSkill();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillInterface.HasSkillToken
	// Flags: [Native|Public]
	// Offset: 0x1022a0ab4
	// Params: [ Num(2) Size(0x5) ]
	bool HasSkillToken(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillInterface.HandleSkillStart
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a0a30
	// Params: [ Num(1) Size(0x4) ]
	void HandleSkillStart(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillInterface.HandleSkillEnd
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a0970
	// Params: [ Num(2) Size(0x5) ]
	void HandleSkillEnd(int SkillID, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillInterface.GetSkillManager
	// Flags: [Native|Public|Const]
	// Offset: 0x1022a0934
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillManagerComponent* GetSkillManager();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillInterface.ClearSkillToken
	// Flags: [Native|Public]
	// Offset: 0x1022a08b0
	// Params: [ Num(1) Size(0x4) ]
	void ClearSkillToken(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function Skill.UTSkillInterface.ClearAllSkillToken
	// Flags: [Native|Public]
	// Offset: 0x1022a0894
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllSkillToken();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillInterface.AddSkillToken
	// Flags: [Native|Public]
	// Offset: 0x1022a0810
	// Params: [ Num(1) Size(0x4) ]
	void AddSkillToken(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
};

// Object: Class Skill.UTSkillLocationPickerFilter
// Size: 0x28 (Inherited: 0x28)
struct UUTSkillLocationPickerFilter : UObject
{

	// Object: Function Skill.UTSkillLocationPickerFilter.CheckAdjustLocation
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x1022a11d8
	// Params: [ Num(4) Size(0x29) ]
	bool CheckAdjustLocation(struct FSkillLocationFilterContext& Context, struct FVector& InLocation, struct FVector& OutLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
};

// Object: Class Skill.UTSkillLocationPicker
// Size: 0x88 (Inherited: 0x78)
struct UUTSkillLocationPicker : UUTSkillBaseWidget
{
	struct TArray<struct UUTSkillLocationPickerFilter*> CheckAdjustFilters; // 0x78(0x10)
};

// Object: Class Skill.UTSkillManagerComponent
// Size: 0xF50 (Inherited: 0x238)
struct UUTSkillManagerComponent : ULuaActorComponent
{
	uint8_t Pad_0x238[0x58]; // 0x238(0x58)
	struct APawn* OwnerPawn; // 0x290(0x8)
	uint8_t Pad_0x298[0x14]; // 0x298(0x14)
	int NetAutoSkillID; // 0x2AC(0x4)
	uint8_t Pad_0x2B0[0x8]; // 0x2B0(0x8)
	bool bEnableSkillCoolDown; // 0x2B8(0x1)
	bool bGMDirectTriggerSkill; // 0x2B9(0x1)
	uint8_t Pad_0x2BA[0x6]; // 0x2BA(0x6)
	struct AActor* OwnerActor; // 0x2C0(0x8)
	bool DestroySkillsOnDie; // 0x2C8(0x1)
	uint8_t Pad_0x2C9[0x7]; // 0x2C9(0x7)
	struct TMap<int, struct TWeakObjectPtr<struct AUTSkill>> SkillIDToSkills; // 0x2D0(0x50)
	struct TMap<int, struct UUAEBlackboard*> SkillIDBlackboardMap; // 0x320(0x50)
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> ActorBlackboardMap; // 0x370(0x50)
	struct FScriptMulticastDelegate ChangeActorBlackboard; // 0x3C0(0x10)
	struct TMap<int, struct FUTSkillRuntimeData> SkillBaseDataMaps; // 0x3D0(0x50)
	struct TArray<struct FUTSkillLastCastInfo> LastCastArray; // 0x420(0x10)
	struct FScriptMulticastDelegate OnSkillCast; // 0x430(0x10)
	struct FSkillActiveRepData SyncSkillActiveStateDatas; // 0x440(0xE0)
	struct FSkillAttrRepData SyncSkillAttrRepData; // 0x520(0xE0)
	struct FSkillDynamicRepData SyncDynamicRepData; // 0x600(0xE0)
	struct TMap<int, int> IDToSyncSkillCDDatas; // 0x6E0(0x50)
	struct TMap<int, int> ButtonSlotToSkillID; // 0x730(0x50)
	struct FTeammateSkillCDRepData TeammateSkillCDRepData; // 0x780(0x10)
	struct TMap<int, int> SkillID2PackageIndex; // 0x790(0x50)
	struct TArray<struct FSkillCDRepData> SyncSkillCDDatas; // 0x7E0(0x10)
	uint8_t Pad_0x7F0[0x90]; // 0x7F0(0x90)
	struct FUTSkillHitInfo SkillHitInfo; // 0x880(0x38)
	struct FUTSkillHitEnvInfo SkillHitEnvInfo; // 0x8B8(0x30)
	struct TArray<struct FString> MutexMontageGroupBeenPlayed; // 0x8E8(0x10)
	uint8_t Pad_0x8F8[0x4]; // 0x8F8(0x4)
	int SkillSynRandomSeed; // 0x8FC(0x4)
	struct FRandomStream SkillSynRandStream; // 0x900(0x8)
	int SkillSynRandomSeedExpireCount; // 0x908(0x4)
	uint8_t Pad_0x90C[0x4]; // 0x90C(0x4)
	struct TArray<struct FSkillParamater> SkillParamaters; // 0x910(0x10)
	struct FScriptMulticastDelegate OnSkillInitSignature; // 0x920(0x10)
	struct FScriptMulticastDelegate InitOneSkillEvent; // 0x930(0x10)
	struct FScriptMulticastDelegate SkillStartEvent; // 0x940(0x10)
	struct FScriptMulticastDelegate SkillStopEvent; // 0x950(0x10)
	struct FScriptMulticastDelegate SkillPhaseChangeEvent; // 0x960(0x10)
	struct FScriptMulticastDelegate SkillLevelChangeEvent; // 0x970(0x10)
	struct FScriptMulticastDelegate SkillSkinIDChangeEvent; // 0x980(0x10)
	struct FScriptMulticastDelegate SkillDoCoolDownEvent; // 0x990(0x10)
	struct FScriptMulticastDelegate SkillUpdateCDEvent; // 0x9A0(0x10)
	struct TArray<int> PendingRemoveSkillID; // 0x9B0(0x10)
	uint8_t Pad_0x9C0[0x50]; // 0x9C0(0x50)
	struct TArray<struct FUTReplaceSkillData> ReplacedSkillDatas; // 0xA10(0x10)
	struct TMap<int, struct FSkillDisableKeySet> DisableSkillTagsMap; // 0xA20(0x50)
	struct TMap<int, struct FSkillDisableKeySet> DisableSkillIDsMap; // 0xA70(0x50)
	struct FScriptMulticastDelegate OnSkillDisableChangeDelegate; // 0xAC0(0x10)
	struct TMap<int, struct FSkillLimitKeySet> LimitSkillTagsMap; // 0xAD0(0x50)
	struct TMap<int, struct FSkillLimitKeySet> LimitSkillIDMap; // 0xB20(0x50)
	struct FMultiSkillSynData NewSkillSynData; // 0xB70(0xF0)
	struct FSkillSinglePhaseData NewSkillSinglePhaseData; // 0xC60(0xF0)
	uint8_t Pad_0xD50[0x8]; // 0xD50(0x8)
	struct FScriptMulticastDelegate OnSkillEventDelegate; // 0xD58(0x10)
	struct TMap<uint64_t, struct FUTSkillSimulateData> SkillSimulateDataMap; // 0xD68(0x50)
	struct TSet<uint64_t> AsyncLoadingSkillInst; // 0xDB8(0x50)
	struct FUTSkillExecQueue SkillExecQueue; // 0xE08(0xB0)
	struct FUTSkillEventHistory SkillEventHistory; // 0xEB8(0x50)
	struct FUTSkillComboState SkillComboState; // 0xF08(0x18)
	int AsyncSkillComboSkillID; // 0xF20(0x4)
	uint8_t Pad_0xF24[0x4]; // 0xF24(0x4)
	uint64_t NetClientSimulateInstID; // 0xF28(0x8)
	uint8_t Pad_0xF30[0x10]; // 0xF30(0x10)
	struct FScriptMulticastDelegate CreativeSkillDelegate; // 0xF40(0x10)


	// Object: Function Skill.UTSkillManagerComponent.UpdateSyncSkillCDData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a7d6c
	// Params: [ Num(1) Size(0x4) ]
	void UpdateSyncSkillCDData(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102265AB4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillManagerComponent.UnRegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a7cf0
	// Params: [ Num(1) Size(0x8) ]
	void UnRegisterActorBlackBorad(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102266124
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102265AB4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Skill.UTSkillManagerComponent.TryDeleteOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a7be4
	// Params: [ Num(3) Size(0x6) ]
	void TryDeleteOneSkill(int SkillID, bool IsImmediately, bool bResetCD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102267A1C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102266124
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102265AB4
	// [Call #14] RVA: 0x10519022C

	// Object: Function Skill.UTSkillManagerComponent.TryAddOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a7ae0
	// Params: [ Num(3) Size(0xC) ]
	void TryAddOneSkill(int SkillID, bool bActive, int ButtonSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022677FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102267A1C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.TriggerSkillWithParams
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a7998
	// Params: [ Num(4) Size(0x1A) ]
	bool TriggerSkillWithParams(int SkillID, struct TArray<struct FString>& InKeyStrings, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022677FC

	// Object: Function Skill.UTSkillManagerComponent.TriggerSkillWithID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a78c4
	// Params: [ Num(3) Size(0x6) ]
	bool TriggerSkillWithID(int SkillID, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.TriggerLocalEventWithID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a77f4
	// Params: [ Num(3) Size(0x9) ]
	bool TriggerLocalEventWithID(enum class EUTSkillEventType SkillEventType, int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.TriggerEventWithID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a7724
	// Params: [ Num(3) Size(0x9) ]
	bool TriggerEventWithID(enum class EUTSkillEventType SkillEventType, int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.TriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a7664
	// Params: [ Num(2) Size(0x5) ]
	void TriggerEvent(int SkillID, enum class EUTSkillEventType EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.TraceTarget
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1022a74d0
	// Params: [ Num(6) Size(0x29) ]
	bool TraceTarget(struct FVector StartTrace, struct FVector EndTrace, uint8_t TargetType, float Radius, struct AActor*& TargetActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SyncOneSkillState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a73c4
	// Params: [ Num(3) Size(0x8) ]
	void SyncOneSkillState(bool RepSkillCD, bool RepSkillActiveState, int RequestID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10225B60C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.StopSkillAll
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a7340
	// Params: [ Num(1) Size(0x1) ]
	void StopSkillAll(uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10225B60C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.StopSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a7280
	// Params: [ Num(2) Size(0x5) ]
	void StopSkill(int SkillID, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10225B60C

	// Object: Function Skill.UTSkillManagerComponent.StopCurSkill
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a7204
	// Params: [ Num(1) Size(0x1) ]
	void StopCurSkill(uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102268488
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.StopAllMonopolizeSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a7180
	// Params: [ Num(1) Size(0x1) ]
	void StopAllMonopolizeSkill(uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102268488
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SetupOwnerAndSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a714c
	// Params: [ Num(1) Size(0x1) ]
	bool SetupOwnerAndSystem();
	// [Call #1] RVA: 0x10226B1F4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102268488
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SetSkillTagsLimit
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a6ffc
	// Params: [ Num(3) Size(0x28) ]
	void SetSkillTagsLimit(struct TArray<int>& SkillTags, bool bLimit, struct FString TriggerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226C9EC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10226B1F4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SetSkillTagsDisable
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a6eac
	// Params: [ Num(3) Size(0x28) ]
	void SetSkillTagsDisable(struct TArray<int>& SkillTags, bool bDisable, struct FString TriggerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226C6C0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10226C9EC

	// Object: Function Skill.UTSkillManagerComponent.SetSkillSkinID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a6de8
	// Params: [ Num(3) Size(0x9) ]
	bool SetSkillSkinID(int SkillID, int InSkillSkinID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102262568
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10226C6C0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.SetSkillOwner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a6d64
	// Params: [ Num(1) Size(0x8) ]
	void SetSkillOwner(struct AActor* tempActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102262568
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10226C6C0
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillManagerComponent.SetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a6ca0
	// Params: [ Num(3) Size(0x9) ]
	bool SetSkillLevel(int SkillID, int SkillLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102262448
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102262568
	// [Call #13] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.SetSkillIDsLimit
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a6b50
	// Params: [ Num(3) Size(0x28) ]
	void SetSkillIDsLimit(struct TArray<int>& SkillIDs, bool bLimit, struct FString TriggerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226CC80
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102262448
	// [Call #18] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.SetSkillIDsDisable
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a6a00
	// Params: [ Num(3) Size(0x28) ]
	void SetSkillIDsDisable(struct TArray<int>& SkillIDs, bool bDisable, struct FString TriggerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226C95C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10226CC80

	// Object: Function Skill.UTSkillManagerComponent.SetSkillCDTimeScale
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void SetSkillCDTimeScale(int SkillID, float Scale, int ScaleType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.SetSkillCDIndexTimeScale
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0x10) ]
	void SetSkillCDIndexTimeScale(int SkillID, int SkillCDIndex, float Scale, int ScaleType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.SetSkillActive
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a68a0
	// Params: [ Num(5) Size(0xD) ]
	bool SetSkillActive(int SkillID, bool bActive, bool bForceSet, int ButtonSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SetAutoSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a6824
	// Params: [ Num(1) Size(0x4) ]
	void SetAutoSkillID(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225D1E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.SetAllSkillCDTimeScale
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void SetAllSkillCDTimeScale(float Scale);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithParamsAndTssData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a663c
	// Params: [ Num(6) Size(0x38) ]
	void ServerTriggerEvent_WithParamsAndTssData(int SkillID, enum class EUTSkillEventType EventType, uint64_t InstID, struct TArray<uint8_t> Content, struct TArray<uint8_t> TssData, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10225D1E4

	// Object: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a64a8
	// Params: [ Num(5) Size(0x28) ]
	void ServerTriggerEvent_WithParams(int SkillID, enum class EUTSkillEventType EventType, uint64_t InstID, struct TArray<uint8_t> Content, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithIDAndTssData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a6314
	// Params: [ Num(5) Size(0x28) ]
	void ServerTriggerEvent_WithIDAndTssData(int SkillID, enum class EUTSkillEventType EventType, uint64_t InstID, struct TArray<uint8_t> TssData, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithID
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a61e0
	// Params: [ Num(4) Size(0x18) ]
	void ServerTriggerEvent_WithID(int SkillID, enum class EUTSkillEventType EventType, uint64_t InstID, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.ServerTriggerEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a6120
	// Params: [ Num(2) Size(0x5) ]
	void ServerTriggerEvent(int SkillID, enum class EUTSkillEventType EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerStopSkillCombo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1022a609c
	// Params: [ Num(1) Size(0x4) ]
	void ServerStopSkillCombo(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerStopSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1022a5fdc
	// Params: [ Num(2) Size(0x5) ]
	void ServerStopSkill(int SkillID, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerStopAllSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a5f58
	// Params: [ Num(1) Size(0x1) ]
	void ServerStopAllSkill(uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerStopAllMonopolizeSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a5ed4
	// Params: [ Num(1) Size(0x1) ]
	void ServerStopAllMonopolizeSkill(uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ServerStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a5e00
	// Params: [ Num(3) Size(0x6) ]
	bool ServerStartSkill(int SkillID, bool bAutoCast);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.ServerNotifyRandomSeed
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	// Offset: 0x1022a5d7c
	// Params: [ Num(1) Size(0x4) ]
	void ServerNotifyRandomSeed(int Seed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ResetTeammateSkillCDData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a5d68
	// Params: [ Num(0) Size(0x0) ]
	void ResetTeammateSkillCDData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ResetSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a5cac
	// Params: [ Num(2) Size(0x8) ]
	void ResetSkillCoolDown(int SkillID, int CDIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ResetSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a5b90
	// Params: [ Num(3) Size(0x3) ]
	void ResetSkill(bool bStopAllSkill, bool bDeactivateAllSkill, bool bResetSkillCD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ResetAllSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a5b74
	// Params: [ Num(0) Size(0x0) ]
	void ResetAllSkillCoolDown();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.RequestSkillStates
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1022a5a9c
	// Params: [ Num(2) Size(0x2) ]
	void RequestSkillStates(bool RepSkillCD, bool RepSkillActiveState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.RepSkillHitInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a5a88
	// Params: [ Num(0) Size(0x0) ]
	void RepSkillHitInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.RepLastCastTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5a74
	// Params: [ Num(0) Size(0x0) ]
	void RepLastCastTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ReplaceSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a59c0
	// Params: [ Num(2) Size(0x8) ]
	void ReplaceSkill(int OldSkillID, int NewSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226C0C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.RemoveReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a5944
	// Params: [ Num(1) Size(0x4) ]
	void RemoveReplacedSkill(int OldSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226C188
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10226C0C8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.RemoveAllSkillUIWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a5930
	// Params: [ Num(0) Size(0x0) ]
	void RemoveAllSkillUIWidget();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226C188
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10226C0C8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.RegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a587c
	// Params: [ Num(2) Size(0x10) ]
	void RegisterActorBlackBorad(struct AActor* InActor, struct UUAEBlackboard* RegisterBlackboard);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022660A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10226C188
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10226C0C8
	// [Call #14] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.RefreshSkillRepData
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5868
	// Params: [ Num(0) Size(0x0) ]
	void RefreshSkillRepData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022660A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10226C188
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10226C0C8

	// Object: Function Skill.UTSkillManagerComponent.RecordSkillException
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a56c0
	// Params: [ Num(5) Size(0x30) ]
	void RecordSkillException(struct AActor* InActor, int InSkillID, enum class ENetRole InRole, struct FString InNetMode, struct FString InFuncName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.RandRangeSyn
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a55fc
	// Params: [ Num(3) Size(0xC) ]
	int RandRangeSyn(int StartIndex, int EndIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022AFD10
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillManagerComponent.QuerySkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a5568
	// Params: [ Num(2) Size(0x10) ]
	struct AUTSkill* QuerySkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022AFD10
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.QueryOrNewSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a54d4
	// Params: [ Num(2) Size(0x10) ]
	struct AUTSkill* QueryOrNewSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022AFD10
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.PreTriggerSkillEvent
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a5450
	// Params: [ Num(1) Size(0x4) ]
	void PreTriggerSkillEvent(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1022AFD10

	// Object: Function Skill.UTSkillManagerComponent.PostTriggerSkillEvent
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a53cc
	// Params: [ Num(1) Size(0x4) ]
	void PostTriggerSkillEvent(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.PlayHurtSkillEffect
	// Flags: [Native|Public]
	// Offset: 0x1022a52e8
	// Params: [ Num(1) Size(0x38) ]
	void PlayHurtSkillEffect(struct FUTSkillHitInfo TheSkillHitInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102279B2C
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnStopSkill
	// Flags: [Native|Public]
	// Offset: 0x1022a5228
	// Params: [ Num(2) Size(0x9) ]
	void OnStopSkill(struct AUTSkill* Skill, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRespawned
	// Flags: [Native|Public]
	// Offset: 0x1022a520c
	// Params: [ Num(0) Size(0x0) ]
	void OnRespawned();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRep_SkillHitInfo
	// Flags: [Native|Public]
	// Offset: 0x1022a51f0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SkillHitInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRep_SkillCDDatas
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a51dc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SkillCDDatas();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRep_SkillAttrRepData
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a51c8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SkillAttrRepData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRep_SkillActiveState
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a51b4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SkillActiveState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.OnRep_ReplaceSkill
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a51a0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ReplaceSkill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.OnRep_NewSkillSynData
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a518c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_NewSkillSynData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.OnRep_NewSkillSinglePhaseData
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5178
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_NewSkillSinglePhaseData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.OnRep_NetClientSimulateInstID
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5164
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_NetClientSimulateInstID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC

	// Object: Function Skill.UTSkillManagerComponent.OnRep_NetAutoSkillID
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5150
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_NetAutoSkillID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC

	// Object: Function Skill.UTSkillManagerComponent.OnRep_EnableSkillEncrypt
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a513c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_EnableSkillEncrypt();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C
	// [Call #8] RVA: 0x101F811FC

	// Object: Function Skill.UTSkillManagerComponent.OnRep_DynamicRepData
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5128
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_DynamicRepData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102279B2C

	// Object: Function Skill.UTSkillManagerComponent.OnRep_AsyncSkillComboSkillID
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a5114
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_AsyncSkillComboSkillID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.OnRecycled
	// Flags: [Native|Public]
	// Offset: 0x1022a50f8
	// Params: [ Num(0) Size(0x0) ]
	void OnRecycled();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.OnInterruptSkill
	// Flags: [Native|Public]
	// Offset: 0x1022a5038
	// Params: [ Num(2) Size(0x9) ]
	void OnInterruptSkill(struct AUTSkill* Skill, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.NewUAEBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a4fbc
	// Params: [ Num(1) Size(0x4) ]
	void NewUAEBlackboard(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102265FE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.NeedSimulateStoppedNewSkill
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a4f28
	// Params: [ Num(2) Size(0x5) ]
	bool NeedSimulateStoppedNewSkill(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102265FE8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.LocalTriggerNewSkillFail
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a4e74
	// Params: [ Num(2) Size(0x10) ]
	void LocalTriggerNewSkillFail(struct AUTSkill* InNewSkill, uint64_t InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226ABF0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102265FE8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.LocalStopSkillAllWithExcludeArray
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a4d78
	// Params: [ Num(2) Size(0x11) ]
	void LocalStopSkillAllWithExcludeArray(struct TArray<int>& InExcludeArry, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10226ABF0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsSkillNeedPackageVerify
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022a4ce4
	// Params: [ Num(2) Size(0x5) ]
	bool IsSkillNeedPackageVerify(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10226ABF0

	// Object: Function Skill.UTSkillManagerComponent.IsSkillInit
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022a4c58
	// Params: [ Num(2) Size(0x5) ]
	bool IsSkillInit(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102268F40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.IsSkillIDDisable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a4bcc
	// Params: [ Num(2) Size(0x5) ]
	bool IsSkillIDDisable(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225B3EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102268F40
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsSkillCanUse
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022a4b98
	// Params: [ Num(1) Size(0x1) ]
	bool IsSkillCanUse();
	// [Call #1] RVA: 0x102268E58
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10225B3EC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102268F40
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsSkillActived
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022a4b0c
	// Params: [ Num(2) Size(0x5) ]
	bool IsSkillActived(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022659CC
	// [Call #4] RVA: 0x102268E58
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10225B3EC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102268F40
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsReadyToCastSkill
	// Flags: [Native|Public]
	// Offset: 0x1022a4a78
	// Params: [ Num(2) Size(0x5) ]
	bool IsReadyToCastSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022659CC
	// [Call #6] RVA: 0x102268E58
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10225B3EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102268F40

	// Object: Function Skill.UTSkillManagerComponent.IsPendingCastSkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a49e4
	// Params: [ Num(2) Size(0x5) ]
	bool IsPendingCastSkillID(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022659CC
	// [Call #8] RVA: 0x102268E58
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsPendingCastSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a49a8
	// Params: [ Num(1) Size(0x1) ]
	bool IsPendingCastSkill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022659CC
	// [Call #8] RVA: 0x102268E58

	// Object: Function Skill.UTSkillManagerComponent.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022a496c
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnableSkillCoolDown();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022659CC
	// [Call #8] RVA: 0x102268E58

	// Object: Function Skill.UTSkillManagerComponent.IsCurrentUseSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a48e0
	// Params: [ Num(2) Size(0x5) ]
	bool IsCurrentUseSkillID(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226AE98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsCastingSkillTag
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a484c
	// Params: [ Num(2) Size(0x5) ]
	bool IsCastingSkillTag(int InSkillTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226AE98
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.IsCastingSkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a47b8
	// Params: [ Num(2) Size(0x5) ]
	bool IsCastingSkillID(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226AE98

	// Object: Function Skill.UTSkillManagerComponent.IsCastingSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a477c
	// Params: [ Num(1) Size(0x1) ]
	bool IsCastingSkill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226AE98

	// Object: Function Skill.UTSkillManagerComponent.HasSkillEventFromLastCast
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a46b4
	// Params: [ Num(3) Size(0x6) ]
	bool HasSkillEventFromLastCast(int SkillID, enum class EUTSkillEventType EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226F340
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.HandleTriggerParamsEventFail
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x5) ]
	void HandleTriggerParamsEventFail(int SkillID, enum class EUTSkillEventType EventType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.HandleTriggerParamsEvent
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x6) ]
	bool HandleTriggerParamsEvent(int SkillID, enum class EUTSkillEventType EventType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.HandleSkillStop
	// Flags: [Native|Public]
	// Offset: 0x1022a45b8
	// Params: [ Num(3) Size(0x11) ]
	void HandleSkillStop(int SkillID, struct AUTSkill* InSkill, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10226F340
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.HandleSkillStart
	// Flags: [Native|Public]
	// Offset: 0x1022a44f8
	// Params: [ Num(2) Size(0x10) ]
	void HandleSkillStart(int SkillID, struct AUTSkill* InSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.HandleGMDirectTriggerSkillEvent
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x9) ]
	bool HandleGMDirectTriggerSkillEvent(int SkillID, int SkillPlayRet);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Skill.UTSkillManagerComponent.GetUAEBlackboardBySkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a4464
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEBlackboard* GetUAEBlackboardBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetUAEBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a43d8
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEBlackboard* GetUAEBlackboard(struct AUTSkill* InSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226608C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.GetSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a4344
	// Params: [ Num(2) Size(0x10) ]
	struct UUTSkillWidget* GetSkillWidget(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226608C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillSynDataString
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a422c
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FString> GetSkillSynDataString(struct FString PrefixText, bool bWithLastData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226EE30
	// [Call #6] RVA: 0x101FA5F38
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10226608C

	// Object: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a41a0
	// Params: [ Num(2) Size(0x8) ]
	int GetSkillSlotBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226B52C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10226EE30
	// [Call #9] RVA: 0x101FA5F38
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a4114
	// Params: [ Num(2) Size(0xC) ]
	int GetSkillSlotBySkill(struct AUTSkill* Skill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225D0E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10226B52C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10226EE30
	// [Call #12] RVA: 0x101FA5F38
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.GetSkillSkinID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a4088
	// Params: [ Num(2) Size(0x8) ]
	int GetSkillSkinID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102262638
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10225D0E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10226B52C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillSinglePhaseDataString
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a3f70
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FString> GetSkillSinglePhaseDataString(struct FString PrefixText, bool bWithLastData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226F0E0
	// [Call #6] RVA: 0x101FA5F38
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102262638
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10225D0E4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillsByGroup
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3eb4
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct AUTSkill*> GetSkillsByGroup(struct FName SkillGroup);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022AFCC0
	// [Call #4] RVA: 0x10227CF8C
	// [Call #5] RVA: 0x10227CF8C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10226F0E0
	// [Call #12] RVA: 0x101FA5F38
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102262638

	// Object: Function Skill.UTSkillManagerComponent.GetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3e28
	// Params: [ Num(2) Size(0x8) ]
	int GetSkillLevel(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226251C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022AFCC0
	// [Call #7] RVA: 0x10227CF8C
	// [Call #8] RVA: 0x10227CF8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10226F0E0
	// [Call #15] RVA: 0x101FA5F38
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillManagerComponent.GetSkillIDByClass
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a3d94
	// Params: [ Num(2) Size(0xC) ]
	int GetSkillIDByClass(struct UObject* SkillClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226251C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022AFCC0
	// [Call #9] RVA: 0x10227CF8C
	// [Call #10] RVA: 0x10227CF8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.GetSkillExecString
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a3d30
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSkillExecString();
	// [Call #1] RVA: 0x10226D7A8
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10226251C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022AFCC0
	// [Call #14] RVA: 0x10227CF8C
	// [Call #15] RVA: 0x10227CF8C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.GetSkillEventTimestamp
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3c1c
	// Params: [ Num(4) Size(0xD) ]
	bool GetSkillEventTimestamp(int SkillID, enum class EUTSkillEventType EventType, float& OutTimestamp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226F338
	// [Call #8] RVA: 0x10226D7A8
	// [Call #9] RVA: 0x101FA5F38
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.GetSkillCurPhase
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a3b90
	// Params: [ Num(2) Size(0xC) ]
	int GetSkillCurPhase(struct AUTSkill* Skill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102267BCC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10226F338
	// [Call #11] RVA: 0x10226D7A8
	// [Call #12] RVA: 0x101FA5F38
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.GetSkillByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3a94
	// Params: [ Num(2) Size(0x18) ]
	struct AUTSkill* GetSkillByName(struct FString SkillName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102267BCC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillByClassName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3998
	// Params: [ Num(2) Size(0x18) ]
	struct AUTSkill* GetSkillByClassName(struct FString SkillClassName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetSkillButtonSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a390c
	// Params: [ Num(2) Size(0x8) ]
	int GetSkillButtonSlot(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102265EA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillManagerComponent.GetSkillBaseData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a3878
	// Params: [ Num(2) Size(0x28) ]
	struct FUTSkillRuntimeData GetSkillBaseData(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225B848
	// [Call #4] RVA: 0x1022ADB20
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102265EA8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.GetSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a37e4
	// Params: [ Num(2) Size(0x10) ]
	struct AUTSkill* GetSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10225B848
	// [Call #6] RVA: 0x1022ADB20
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102265EA8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8130C

	// Object: Function Skill.UTSkillManagerComponent.GetReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a3758
	// Params: [ Num(2) Size(0x8) ]
	int GetReplacedSkill(int OldSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226C1E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225B848
	// [Call #9] RVA: 0x1022ADB20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102265EA8

	// Object: Function Skill.UTSkillManagerComponent.GetRealOwnerRoleSafety
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a371c
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRoleSafety();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10226C1E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225B848
	// [Call #9] RVA: 0x1022ADB20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetMutexRelation
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1022a3650
	// Params: [ Num(3) Size(0x11) ]
	enum class ESkillMutexType GetMutexRelation(struct AUTSkill* CurSkill, struct AUTSkill* NewSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226C1E8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetLastCastTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a35c4
	// Params: [ Num(2) Size(0x8) ]
	float GetLastCastTime(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225B544
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10226C1E8

	// Object: Function Skill.UTSkillManagerComponent.GetLastCastFinishTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a3538
	// Params: [ Num(2) Size(0x8) ]
	float GetLastCastFinishTime(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225B590
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10225B544
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetCurSkills
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a34d4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AUTSkill*> GetCurSkills();
	// [Call #1] RVA: 0x10226B23C
	// [Call #2] RVA: 0x1022AFCC0
	// [Call #3] RVA: 0x10227CF8C
	// [Call #4] RVA: 0x10227CF8C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10225B590
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10225B544
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetCurSkillPhase
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a34a0
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillPhase* GetCurSkillPhase();
	// [Call #1] RVA: 0x102269D10
	// [Call #2] RVA: 0x10226B23C
	// [Call #3] RVA: 0x1022AFCC0
	// [Call #4] RVA: 0x10227CF8C
	// [Call #5] RVA: 0x10227CF8C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10225B590
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225B544
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetCurSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022a3414
	// Params: [ Num(2) Size(0xC) ]
	int GetCurSkillID(struct AUTSkill* Skill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102262318
	// [Call #4] RVA: 0x102269D10
	// [Call #5] RVA: 0x10226B23C
	// [Call #6] RVA: 0x1022AFCC0
	// [Call #7] RVA: 0x10227CF8C
	// [Call #8] RVA: 0x10227CF8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10225B590
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10225B544

	// Object: Function Skill.UTSkillManagerComponent.GetCurSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a33e0
	// Params: [ Num(1) Size(0x8) ]
	struct AUTSkill* GetCurSkill();
	// [Call #1] RVA: 0x1022622D0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102262318
	// [Call #5] RVA: 0x102269D10
	// [Call #6] RVA: 0x10226B23C
	// [Call #7] RVA: 0x1022AFCC0
	// [Call #8] RVA: 0x10227CF8C
	// [Call #9] RVA: 0x10227CF8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10225B590
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10225B544

	// Object: Function Skill.UTSkillManagerComponent.GetCurMonopolizeSkills
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a337c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GetCurMonopolizeSkills();
	// [Call #1] RVA: 0x1022653FC
	// [Call #2] RVA: 0x101FA6168
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1022622D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102262318
	// [Call #10] RVA: 0x102269D10
	// [Call #11] RVA: 0x10226B23C
	// [Call #12] RVA: 0x1022AFCC0
	// [Call #13] RVA: 0x10227CF8C
	// [Call #14] RVA: 0x10227CF8C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10225B590

	// Object: Function Skill.UTSkillManagerComponent.GetCurMonopolizedSkillPhase
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a3348
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillPhase* GetCurMonopolizedSkillPhase();
	// [Call #1] RVA: 0x102269B44
	// [Call #2] RVA: 0x1022653FC
	// [Call #3] RVA: 0x101FA6168
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1022622D0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102262318
	// [Call #11] RVA: 0x102269D10
	// [Call #12] RVA: 0x10226B23C
	// [Call #13] RVA: 0x1022AFCC0
	// [Call #14] RVA: 0x10227CF8C
	// [Call #15] RVA: 0x10227CF8C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.GetCurMonopolizedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a3314
	// Params: [ Num(1) Size(0x8) ]
	struct AUTSkill* GetCurMonopolizedSkill();
	// [Call #1] RVA: 0x102269C34
	// [Call #2] RVA: 0x102269B44
	// [Call #3] RVA: 0x1022653FC
	// [Call #4] RVA: 0x101FA6168
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1022622D0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102262318
	// [Call #12] RVA: 0x102269D10
	// [Call #13] RVA: 0x10226B23C
	// [Call #14] RVA: 0x1022AFCC0
	// [Call #15] RVA: 0x10227CF8C
	// [Call #16] RVA: 0x10227CF8C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.GetCurAllSkillIDs
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a32b0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GetCurAllSkillIDs();
	// [Call #1] RVA: 0x102266194
	// [Call #2] RVA: 0x10207FA04
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102269C34
	// [Call #7] RVA: 0x102269B44
	// [Call #8] RVA: 0x1022653FC
	// [Call #9] RVA: 0x101FA6168
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1022622D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102262318
	// [Call #17] RVA: 0x102269D10
	// [Call #18] RVA: 0x10226B23C

	// Object: Function Skill.UTSkillManagerComponent.GetCoolDownTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a31ec
	// Params: [ Num(3) Size(0xC) ]
	float GetCoolDownTime(int SkillID, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102268198
	// [Call #6] RVA: 0x102266194
	// [Call #7] RVA: 0x10207FA04
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102269C34
	// [Call #12] RVA: 0x102269B44
	// [Call #13] RVA: 0x1022653FC
	// [Call #14] RVA: 0x101FA6168
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1022622D0

	// Object: Function Skill.UTSkillManagerComponent.GetCastingSkillIDs
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022a3188
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GetCastingSkillIDs();
	// [Call #1] RVA: 0x102269144
	// [Call #2] RVA: 0x101FA6168
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102268198
	// [Call #11] RVA: 0x102266194
	// [Call #12] RVA: 0x10207FA04
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102269C34
	// [Call #17] RVA: 0x102269B44
	// [Call #18] RVA: 0x1022653FC
	// [Call #19] RVA: 0x101FA6168
	// [Call #20] RVA: 0x101F8BA44
	// [Call #21] RVA: 0x101F8BA44
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Skill.UTSkillManagerComponent.GetButtonSlotSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a30fc
	// Params: [ Num(2) Size(0x8) ]
	int GetButtonSlotSkillID(int ButtonSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102265ECC
	// [Call #4] RVA: 0x102269144
	// [Call #5] RVA: 0x101FA6168
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102268198
	// [Call #14] RVA: 0x102266194
	// [Call #15] RVA: 0x10207FA04
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x102269C34

	// Object: Function Skill.UTSkillManagerComponent.DynamicRemoveSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a3078
	// Params: [ Num(1) Size(0x4) ]
	void DynamicRemoveSkill(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102265ECC
	// [Call #6] RVA: 0x102269144
	// [Call #7] RVA: 0x101FA6168
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102268198

	// Object: Function Skill.UTSkillManagerComponent.DynamicAddSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a2ff4
	// Params: [ Num(1) Size(0x4) ]
	void DynamicAddSkill(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102265ECC
	// [Call #8] RVA: 0x102269144
	// [Call #9] RVA: 0x101FA6168
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClientTriggerEventSuccess_WithID
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x1022a2f34
	// Params: [ Num(2) Size(0x10) ]
	void ClientTriggerEventSuccess_WithID(int SkillID, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102265ECC

	// Object: Function Skill.UTSkillManagerComponent.ClientTriggerEventFailed_WithID
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x1022a2e38
	// Params: [ Num(3) Size(0x10) ]
	void ClientTriggerEventFailed_WithID(int SkillID, uint8_t FailedReason, uint64_t PackageIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClientStopPreActionSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1022a2d78
	// Params: [ Num(2) Size(0x10) ]
	void ClientStopPreActionSkill(int SkillID, uint64_t InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClientStopOneSkill
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a2c74
	// Params: [ Num(3) Size(0xA) ]
	void ClientStopOneSkill(uint64_t InstID, bool bSinglePhaseRep, uint8_t StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226E668
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClientStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a2bb0
	// Params: [ Num(2) Size(0x5) ]
	void ClientStartSkill(int SkillID, bool bAutoCast);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10226E668
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClientSimulateOneSkill
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a2a7c
	// Params: [ Num(4) Size(0x11) ]
	void ClientSimulateOneSkill(uint64_t InstID, int SkillID, int PhaseIndex, bool bSinglePhaseRep);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10226E5D0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClearSkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a2960
	// Params: [ Num(3) Size(0x3) ]
	void ClearSkill(bool bStopAllSkill, bool bDeactivateAllSkill, bool bResetSkillCD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10226E5D0

	// Object: Function Skill.UTSkillManagerComponent.ClearRepParams
	// Flags: [Native|Public]
	// Offset: 0x1022a2944
	// Params: [ Num(0) Size(0x0) ]
	void ClearRepParams();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.ClearInitParams
	// Flags: [Native|Public]
	// Offset: 0x1022a2928
	// Params: [ Num(0) Size(0x0) ]
	void ClearInitParams();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.CheckAIIsCDOKBySkillID
	// Flags: [Final|Native|Public]
	// Offset: 0x1022a2864
	// Params: [ Num(3) Size(0x9) ]
	bool CheckAIIsCDOKBySkillID(int SkillID, int CoolDownIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226F728
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Skill.UTSkillManagerComponent.CacheSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022a27a4
	// Params: [ Num(2) Size(0x10) ]
	void CacheSkillWidget(int SkillID, struct UUTSkillWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10226F728
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillManagerComponent.AddOrRemoveIngoreSkillIDWhenStopAllSkills
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a26ac
	// Params: [ Num(3) Size(0x9) ]
	void AddOrRemoveIngoreSkillIDWhenStopAllSkills(uint8_t InStopReason, int InSkillID, bool bAdd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226B998
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillNodeBlackboardInterface
// Size: 0x28 (Inherited: 0x28)
struct IUTSkillNodeBlackboardInterface : IInterface
{

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b3170
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsWeakObject(struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022b3098
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsUInt
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x1022b2fc0
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsUInt(struct FName& KeyName, uint32_t UIntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2e7c
	// Params: [ Num(2) Size(0x18) ]
	void SetValueAsString(struct FName& KeyName, struct FString StringValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022b2da4
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsRotator(struct FName& KeyName, struct FRotator VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2ccc
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2bf4
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsName(struct FName& KeyName, struct FName NameValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2b1c
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsInt(struct FName& KeyName, int IntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2a44
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsFloat(struct FName& KeyName, float FloatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b296c
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsEnum(struct FName& KeyName, uint8_t EnumValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b2894
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b27b4
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsBool(struct FName& KeyName, bool BoolValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsSetValueAsNewDataWhenNotExist
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b2710
	// Params: [ Num(2) Size(0x9) ]
	bool IsSetValueAsNewDataWhenNotExist(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b266c
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistWeakObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistVector
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b25c8
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistVector(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistUInt
	// Flags: [Native|Public|HasOutParms|Const]
	// Offset: 0x1022b2524
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistUInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b2480
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistString(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistRotator
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b23dc
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistRotator(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b2338
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b2294
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistName(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b21f0
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b214c
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistFloat(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b20a8
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistEnum(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b2004
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistClass(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.IsExistBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1f60
	// Params: [ Num(2) Size(0x9) ]
	bool IsExistBool(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1ebc
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsWeakObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsWeakActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1e18
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* GetValueAsWeakActor(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1d70
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetValueAsVector(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsUInt
	// Flags: [Native|Public|HasOutParms|Const]
	// Offset: 0x1022b1ccc
	// Params: [ Num(2) Size(0xC) ]
	uint32_t GetValueAsUInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1c00
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetValueAsString(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1b58
	// Params: [ Num(2) Size(0x14) ]
	struct FRotator GetValueAsRotator(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1ab4
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1a10
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetValueAsName(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b196c
	// Params: [ Num(2) Size(0xC) ]
	int GetValueAsInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b18c8
	// Params: [ Num(2) Size(0xC) ]
	float GetValueAsFloat(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1824
	// Params: [ Num(2) Size(0x9) ]
	uint8_t GetValueAsEnum(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1780
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsClass(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b16dc
	// Params: [ Num(2) Size(0x9) ]
	bool GetValueAsBool(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetValueAsActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b1638
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* GetValueAsActor(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.GetUAEBlackboard
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b15fc
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEBlackboard* GetUAEBlackboard();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.AddValueByKeySelector
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b152c
	// Params: [ Num(2) Size(0x10) ]
	void AddValueByKeySelector(enum class EUAEBlackboardType BBType, struct FUAEBlackboardKeySelector& Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillNodeBlackboardInterface.AddValueByKeName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b145c
	// Params: [ Num(2) Size(0x10) ]
	void AddValueByKeName(enum class EUAEBlackboardType BBType, struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillPhase
// Size: 0xE8 (Inherited: 0x28)
struct UUTSkillPhase : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
	struct FString PhaseName; // 0x40(0x10)
	bool bPhaseEnabled; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // 0x54(0x8)
	int PhaseIndex; // 0x5C(0x4)
	int ActionsTopHalfCount; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct FUTSkillPhaseCreateData BaseData; // 0x68(0x78)
	struct UUTSkillPicker* InEffectPickerOnAction; // 0xE0(0x8)


	// Object: Function Skill.UTSkillPhase.TryJumpToPhase
	// Flags: [Final|Native|Public]
	// Offset: 0x1022b47b4
	// Params: [ Num(3) Size(0xD) ]
	bool TryJumpToPhase(struct UUTSkillManagerComponent* SkillManagerComponent, int PhaseId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10226FE7C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillPhase.StopPhase
	// Flags: [Native|Public]
	// Offset: 0x1022b4730
	// Params: [ Num(1) Size(0x8) ]
	void StopPhase(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10226FE7C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillPhase.StartPhase
	// Flags: [Native|Public]
	// Offset: 0x1022b46ac
	// Params: [ Num(1) Size(0x8) ]
	void StartPhase(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10226FE7C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Skill.UTSkillPhase.RepeatPhase
	// Flags: [Native|Public]
	// Offset: 0x1022b4628
	// Params: [ Num(1) Size(0x8) ]
	void RepeatPhase(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10226FE7C

	// Object: Function Skill.UTSkillPhase.PlaySkillHurtEffect
	// Flags: [Native|Public]
	// Offset: 0x1022b455c
	// Params: [ Num(3) Size(0x11) ]
	bool PlaySkillHurtEffect(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillPhase.PlaySkillHurtAppearances
	// Flags: [Native|Public]
	// Offset: 0x1022b4490
	// Params: [ Num(3) Size(0x11) ]
	bool PlaySkillHurtAppearances(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillPhase.PickTargets
	// Flags: [Native|Public]
	// Offset: 0x1022b440c
	// Params: [ Num(1) Size(0x8) ]
	void PickTargets(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Skill.UTSkillPhase.OnEvent
	// Flags: [Native|Public]
	// Offset: 0x1022b433c
	// Params: [ Num(3) Size(0xA) ]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillPhase.OnCustomEvent
	// Flags: [Native|Public]
	// Offset: 0x1022b426c
	// Params: [ Num(3) Size(0xA) ]
	bool OnCustomEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class EUTSkillEventType TheEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillPhase.ForceStopPhase
	// Flags: [Native|Public]
	// Offset: 0x1022b41d8
	// Params: [ Num(2) Size(0x9) ]
	bool ForceStopPhase(struct UUTSkillManagerComponent* SkillManagerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillPhase.ClearAttachments
	// Flags: [Final|Native|Public]
	// Offset: 0x1022b41a4
	// Params: [ Num(1) Size(0x1) ]
	bool ClearAttachments();
	// [Call #1] RVA: 0x10226F970
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillPickerFilter
// Size: 0x28 (Inherited: 0x28)
struct UUTSkillPickerFilter : UObject
{

	// Object: Function Skill.UTSkillPickerFilter.IsValidFilterActor
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1022b52a8
	// Params: [ Num(3) Size(0x11) ]
	bool IsValidFilterActor(struct AActor* InActor, struct AActor* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function Skill.UTSkillPickerFilter.HandleFilterArray
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1022b51ac
	// Params: [ Num(2) Size(0x18) ]
	void HandleFilterArray(struct TArray<struct FUTSkillPickedTarget>& inArray, struct AActor* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10227CFEC
	// [Call #6] RVA: 0x10227CFEC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class Skill.UTSkillPicker
// Size: 0x108 (Inherited: 0x78)
struct UUTSkillPicker : UUTSkillBaseWidget
{
	struct FUTSkillPickerCreateData BaseData; // 0x78(0x50)
	struct TArray<struct UObject*> FilterTemplates; // 0xC8(0x10)
	uint8_t Pad_0xD8[0x10]; // 0xD8(0x10)
	struct TArray<struct FUTSkillPickedTarget> PickedResultTargets; // 0xE8(0x10)
	struct TArray<struct UUTSkillPickerFilter*> Filters; // 0xF8(0x10)


	// Object: Function Skill.UTSkillPicker.PickTargetsInner
	// Flags: [Native|Protected|HasDefaults|BlueprintCallable]
	// Offset: 0x1022b55ac
	// Params: [ Num(2) Size(0xD) ]
	bool PickTargetsInner(struct FVector OriginPoint);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102292260

	// Object: Function Skill.UTSkillPicker.PickTargets
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022b5520
	// Params: [ Num(2) Size(0xD) ]
	bool PickTargets(struct FVector OriginPoint);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10225D5B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
};

// Object: Class Skill.UTSkillFunctionBase
// Size: 0xA8 (Inherited: 0x78)
struct UUTSkillFunctionBase : UUTSkillBaseWidget
{
	struct FSkillFuncNameSelector DoActionFuncKey; // 0x78(0x10)
	struct FSkillFuncNameSelector UndoActionFuncKey; // 0x88(0x10)
	struct FSkillFuncNameSelector ConditionFuncKey; // 0x98(0x10)
};

// Object: Class Skill.UTSkillSpecificAction
// Size: 0x108 (Inherited: 0xA8)
struct UUTSkillSpecificAction : UUTSkillAction
{
	struct FSkillFuncNameSelector DoActionFuncKey; // 0xA8(0x10)
	struct FSkillFuncNameSelector ResetActionFuncKey; // 0xB8(0x10)
	struct FSkillFuncNameSelector UndoActionFuncKey; // 0xC8(0x10)
	struct FString DoActionLuaFunc; // 0xD8(0x10)
	struct FString ResetActionLuaFunc; // 0xE8(0x10)
	struct FString UndoActionLuaFunc; // 0xF8(0x10)


	// Object: Function Skill.UTSkillSpecificAction.UpdateAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022b5c78
	// Params: [ Num(1) Size(0x4) ]
	void UpdateAction_Internal(float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillSpecificAction.UndoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022b5c5c
	// Params: [ Num(0) Size(0x0) ]
	void UndoAction_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillSpecificAction.Reset_Internal
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022b5c40
	// Params: [ Num(0) Size(0x0) ]
	void Reset_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Skill.UTSkillSpecificAction.RealDoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022b5c04
	// Params: [ Num(1) Size(0x1) ]
	bool RealDoAction_Internal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Skill.UTSkillSpecificAction.PreCloseSkill
	// Flags: [Native|Public]
	// Offset: 0x1022b5b48
	// Params: [ Num(2) Size(0x10) ]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function Skill.UTSkillSpecificAction.PostInitSkill
	// Flags: [Native|Public]
	// Offset: 0x1022b5a8c
	// Params: [ Num(2) Size(0x10) ]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Skill.UTSkillSpecificAction.PostActiveSkill
	// Flags: [Native|Public]
	// Offset: 0x1022b59d0
	// Params: [ Num(2) Size(0x10) ]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class Skill.UTSkillSpecificCondition
// Size: 0xA0 (Inherited: 0x80)
struct UUTSkillSpecificCondition : UUTSkillCondition
{
	struct FSkillFuncNameSelector ConditionFuncKey; // 0x80(0x10)
	struct FString LuaConditionFunc; // 0x90(0x10)
};

// Object: Class Skill.SkillUtil
// Size: 0x28 (Inherited: 0x28)
struct USkillUtil : UBlueprintFunctionLibrary
{
};

// Object: Class Skill.UTSkillWidget
// Size: 0x4A0 (Inherited: 0x488)
struct UUTSkillWidget : ULuaUAEUserWidget
{
	struct UUTSkillManagerComponent* SkillManager; // 0x488(0x8)
	int SkillID; // 0x490(0x4)
	float TickInterval; // 0x494(0x4)
	bool bEnableTick; // 0x498(0x1)
	uint8_t Pad_0x499[0x7]; // 0x499(0x7)


	// Object: Function Skill.UTSkillWidget.SetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b6674
	// Params: [ Num(1) Size(0x8) ]
	void SetSkillManager(struct UUTSkillManagerComponent* Manager);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.SetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b65f8
	// Params: [ Num(1) Size(0x4) ]
	void SetSkillID(int InSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102272DD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.RemoveSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b65e4
	// Params: [ Num(0) Size(0x0) ]
	void RemoveSelf();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102272DD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.GetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b65c8
	// Params: [ Num(1) Size(0x8) ]
	struct UUTSkillManagerComponent* GetSkillManager();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102272DD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.GetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b6594
	// Params: [ Num(1) Size(0x4) ]
	int GetSkillID();
	// [Call #1] RVA: 0x102272DD8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102272DD0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.GetSkillCDBases
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b655c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UUTSkillCDBase*> GetSkillCDBases();
	// [Call #1] RVA: 0x102272E98
	// [Call #2] RVA: 0x102272DD8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102272DD0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.GetSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022b6528
	// Params: [ Num(1) Size(0x8) ]
	struct AUTSkill* GetSkill();
	// [Call #1] RVA: 0x102272DB0
	// [Call #2] RVA: 0x102272E98
	// [Call #3] RVA: 0x102272DD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102272DD0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function Skill.UTSkillWidget.GetLocalPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b64f4
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetLocalPlayerController();
	// [Call #1] RVA: 0x102272ECC
	// [Call #2] RVA: 0x102272DB0
	// [Call #3] RVA: 0x102272E98
	// [Call #4] RVA: 0x102272DD8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102272DD0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C

	// Object: Function Skill.UTSkillWidget.BindLua
	// Flags: [Final|Native|Public]
	// Offset: 0x1022b6410
	// Params: [ Num(1) Size(0x10) ]
	void BindLua(struct FString luaPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102272C64
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x102272ECC
	// [Call #13] RVA: 0x102272DB0
	// [Call #14] RVA: 0x102272E98
	// [Call #15] RVA: 0x102272DD8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102272DD0
};

