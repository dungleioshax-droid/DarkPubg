#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Login_Background_UIBP.Login_Background_UIBP_C
// Size: 0x278 (Inherited: 0x260)
struct ULogin_Background_UIBP_C : UUserWidget
{
	struct UGridPanel* BGRoot; // 0x260(0x8)
	struct UImage* Image_LoginBG; // 0x268(0x8)
	struct UWidgetSwitcher* Switcher; // 0x270(0x8)
};

