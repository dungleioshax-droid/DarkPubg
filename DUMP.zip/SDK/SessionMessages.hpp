#pragma once

#include <cstdint>

// Object: ScriptStruct SessionMessages.SessionServiceLogUnsubscribe
// Size: 0x1 (Inherited: 0x0)
struct FSessionServiceLogUnsubscribe
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct SessionMessages.SessionServiceLogSubscribe
// Size: 0x1 (Inherited: 0x0)
struct FSessionServiceLogSubscribe
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct SessionMessages.SessionServiceLog
// Size: 0x38 (Inherited: 0x0)
struct FSessionServiceLog
{
	struct FName Category; // 0x0(0x8)
	struct FString Data; // 0x8(0x10)
	struct FGuid InstanceID; // 0x18(0x10)
	double TimeSeconds; // 0x28(0x8)
	uint8_t Verbosity; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: ScriptStruct SessionMessages.SessionServicePong
// Size: 0x98 (Inherited: 0x0)
struct FSessionServicePong
{
	bool Authorized; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString BuildDate; // 0x8(0x10)
	struct FString DeviceName; // 0x18(0x10)
	struct FGuid InstanceID; // 0x28(0x10)
	struct FString InstanceName; // 0x38(0x10)
	bool IsConsoleBuild; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
	struct FString PlatformName; // 0x50(0x10)
	struct FGuid SessionId; // 0x60(0x10)
	struct FString SessionName; // 0x70(0x10)
	struct FString SessionOwner; // 0x80(0x10)
	bool Standalone; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
};

// Object: ScriptStruct SessionMessages.SessionServicePing
// Size: 0x10 (Inherited: 0x0)
struct FSessionServicePing
{
	struct FString UserName; // 0x0(0x10)
};

