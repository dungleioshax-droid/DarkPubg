#pragma once

#include <cstdint>

// Object: Enum ACLPlugin.ACLCompressionLevel
enum class EACLCompressionLevel : uint8_t
{
	ACLCL_Lowest = 0,
	ACLCL_Low = 1,
	ACLCL_Medium = 2,
	ACLCL_High = 3,
	ACLCL_Highest = 4,
	ACLCL_MAX = 5
};

// Object: Enum ACLPlugin.ACLVectorFormat
enum class EACLVectorFormat : uint8_t
{
	ACLVF_Vector3_96 = 0,
	ACLVF_Vector3_Variable = 1,
	ACLVF_Vector3_MAX = 2
};

// Object: Enum ACLPlugin.ACLRotationFormat
enum class EACLRotationFormat : uint8_t
{
	ACLRF_Quat_128 = 0,
	ACLRF_QuatDropW_96 = 1,
	ACLRF_QuatDropW_Variable = 2,
	ACLRF_MAX = 3
};

// Object: Class ACLPlugin.ACLStatsDumpCommandlet
// Size: 0x80 (Inherited: 0x80)
struct UACLStatsDumpCommandlet : UCommandlet
{
};

// Object: Class ACLPlugin.AnimCompress_ACLBase
// Size: 0x40 (Inherited: 0x40)
struct UAnimCompress_ACLBase : UAnimCompress
{
};

// Object: Class ACLPlugin.AnimCompress_ACL
// Size: 0x58 (Inherited: 0x40)
struct UAnimCompress_ACL : UAnimCompress_ACLBase
{
	enum class EACLCompressionLevel CompressionLevel; // 0x40(0x1)
	uint8_t Pad_0x41[0x3]; // 0x41(0x3)
	float DefaultVirtualVertexDistance; // 0x44(0x4)
	float SafeVirtualVertexDistance; // 0x48(0x4)
	float SafetyFallbackThreshold; // 0x4C(0x4)
	float ErrorThreshold; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: Class ACLPlugin.AnimCompress_ACLCustom
// Size: 0x68 (Inherited: 0x40)
struct UAnimCompress_ACLCustom : UAnimCompress_ACLBase
{
	float DefaultVirtualVertexDistance; // 0x40(0x4)
	float SafeVirtualVertexDistance; // 0x44(0x4)
	enum class EACLCompressionLevel CompressionLevel; // 0x48(0x1)
	enum class EACLRotationFormat RotationFormat; // 0x49(0x1)
	enum class EACLVectorFormat TranslationFormat; // 0x4A(0x1)
	enum class EACLVectorFormat ScaleFormat; // 0x4B(0x1)
	float ErrorThreshold; // 0x4C(0x4)
	float ConstantRotationThresholdAngle; // 0x50(0x4)
	float ConstantTranslationThreshold; // 0x54(0x4)
	float ConstantScaleThreshold; // 0x58(0x4)
	uint8_t bClipRangeReduceRotations : 1; // 0x5C(0x1), Mask(0x1)
	uint8_t bClipRangeReduceTranslations : 1; // 0x5C(0x1), Mask(0x2)
	uint8_t bClipRangeReduceScales : 1; // 0x5C(0x1), Mask(0x4)
	uint8_t bEnableSegmenting : 1; // 0x5C(0x1), Mask(0x8)
	uint8_t bSegmentRangeReduceRotations : 1; // 0x5C(0x1), Mask(0x10)
	uint8_t bSegmentRangeReduceTranslations : 1; // 0x5C(0x1), Mask(0x20)
	uint8_t bSegmentRangeReduceScales : 1; // 0x5C(0x1), Mask(0x40)
	uint8_t BitPad_0x5C_7 : 1; // 0x5C(0x1)
	uint8_t Pad_0x5D[0x1]; // 0x5D(0x1)
	uint16_t IdealNumKeyFramesPerSegment; // 0x5E(0x2)
	uint16_t MaxNumKeyFramesPerSegment; // 0x60(0x2)
	uint8_t Pad_0x62[0x6]; // 0x62(0x6)
};

