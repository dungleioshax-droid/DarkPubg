#pragma once

#include <cstdint>

// Object: Enum Slate.ETextFlowDirection
enum class ETextFlowDirection : uint8_t
{
	Auto = 0,
	LeftToRight = 1,
	RightToLeft = 2,
	ETextFlowDirection_MAX = 3
};

// Object: Enum Slate.ETextWrappingPolicy
enum class ETextWrappingPolicy : uint8_t
{
	DefaultWrapping = 0,
	AllowPerCharacterWrapping = 1,
	AllowPerWordHyphenWrapping = 2,
	ETextWrappingPolicy_MAX = 3
};

// Object: Enum Slate.ETextVerticalJustify
enum class ETextVerticalJustify : uint8_t
{
	Top = 0,
	Middle = 1,
	Down = 2,
	ETextVerticalJustify_MAX = 3
};

// Object: Enum Slate.ETextJustify
enum class ETextJustify : uint8_t
{
	Left = 0,
	Center = 1,
	Right = 2,
	ETextJustify_MAX = 3
};

// Object: Enum Slate.EJoystickOperatingMode
enum class EJoystickOperatingMode : uint8_t
{
	JSNormal = 0,
	JSEightDirection = 1,
	JSEasyGoStraight = 2,
	EJoystickOperatingMode_MAX = 3
};

// Object: Enum Slate.EDescendantScrollDestination
enum class EDescendantScrollDestination : uint8_t
{
	IntoView = 0,
	TopOrLeft = 1,
	Center = 2,
	EDescendantScrollDestination_MAX = 3
};

// Object: Enum Slate.ETableViewMode
enum class ETableViewMode : uint8_t
{
	List = 0,
	Tile = 1,
	Tree = 2,
	ETableViewMode_MAX = 3
};

// Object: Enum Slate.ESelectionMode
enum class ESelectionMode : uint8_t
{
	None = 0,
	Single = 1,
	SingleToggle = 2,
	Multi = 3,
	ESelectionMode_MAX = 4
};

// Object: Enum Slate.EProgressBarFillType
enum class EProgressBarFillType : uint8_t
{
	LeftToRight = 0,
	RightToLeft = 1,
	FillFromCenter = 2,
	TopToBottom = 3,
	BottomToTop = 4,
	EProgressBarFillType_MAX = 5
};

// Object: Enum Slate.EStretch
enum class EStretch : uint8_t
{
	None = 0,
	Fill = 1,
	ScaleToFit = 2,
	ScaleToFitX = 3,
	ScaleToFitY = 4,
	ScaleToFill = 5,
	ScaleBySafeZone = 6,
	UserSpecified = 7,
	EStretch_MAX = 8
};

// Object: Enum Slate.EStretchDirection
enum class EStretchDirection : uint8_t
{
	Both = 0,
	DownOnly = 1,
	UpOnly = 2,
	EStretchDirection_MAX = 3
};

// Object: Enum Slate.EListItemAlignment
enum class EListItemAlignment : uint8_t
{
	EvenlyDistributed = 0,
	EvenlySize = 1,
	EvenlyWide = 2,
	LeftAligned = 3,
	RightAligned = 4,
	CenterAligned = 5,
	Fill = 6,
	EListItemAlignment_MAX = 7
};

// Object: Enum Slate.EJoystickIsInside
enum class EJoystickIsInside : uint8_t
{
	EJII_LeftAndVisualSize = 0,
	EJII_VisualSize = 1,
	EJII_DynamicSize = 2,
	EJII_MAX = 3
};

// Object: Enum Slate.EMultipleKeyBindingIndex
enum class EMultipleKeyBindingIndex : uint8_t
{
	Primary = 0,
	Secondary = 1,
	NumChords = 2,
	EMultipleKeyBindingIndex_MAX = 3
};

// Object: ScriptStruct Slate.InputChord
// Size: 0x20 (Inherited: 0x0)
struct FInputChord
{
	struct FKey Key; // 0x0(0x18)
	uint8_t bShift : 1; // 0x18(0x1), Mask(0x1)
	uint8_t bCtrl : 1; // 0x18(0x1), Mask(0x2)
	uint8_t bAlt : 1; // 0x18(0x1), Mask(0x4)
	uint8_t bCmd : 1; // 0x18(0x1), Mask(0x8)
	uint8_t BitPad_0x18_4 : 4; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct Slate.Anchors
// Size: 0x10 (Inherited: 0x0)
struct FAnchors
{
	struct FVector2D Minimum; // 0x0(0x8)
	struct FVector2D Maximum; // 0x8(0x8)
};

// Object: Class Slate.ButtonWidgetStyle
// Size: 0x368 (Inherited: 0x30)
struct UButtonWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FButtonStyle ButtonStyle; // 0x30(0x338)
};

// Object: Class Slate.CheckBoxWidgetStyle
// Size: 0x760 (Inherited: 0x30)
struct UCheckBoxWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FCheckBoxStyle CheckBoxStyle; // 0x30(0x730)
};

// Object: Class Slate.ComboBoxWidgetStyle
// Size: 0x538 (Inherited: 0x30)
struct UComboBoxWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FComboBoxStyle ComboBoxStyle; // 0x30(0x508)
};

// Object: Class Slate.ComboButtonWidgetStyle
// Size: 0x500 (Inherited: 0x30)
struct UComboButtonWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FComboButtonStyle ComboButtonStyle; // 0x30(0x4D0)
};

// Object: Class Slate.EditableTextBoxWidgetStyle
// Size: 0xA98 (Inherited: 0x30)
struct UEditableTextBoxWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FEditableTextBoxStyle EditableTextBoxStyle; // 0x30(0xA68)
};

// Object: Class Slate.EditableTextWidgetStyle
// Size: 0x2E0 (Inherited: 0x30)
struct UEditableTextWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FEditableTextStyle EditableTextStyle; // 0x30(0x2B0)
};

// Object: Class Slate.ProgressWidgetStyle
// Size: 0x260 (Inherited: 0x30)
struct UProgressWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FProgressBarStyle ProgressBarStyle; // 0x30(0x230)
};

// Object: Class Slate.ScrollBarWidgetStyle
// Size: 0x6B0 (Inherited: 0x30)
struct UScrollBarWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FScrollBarStyle ScrollBarStyle; // 0x30(0x680)
};

// Object: Class Slate.ScrollBoxWidgetStyle
// Size: 0x318 (Inherited: 0x30)
struct UScrollBoxWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FScrollBoxStyle ScrollBoxStyle; // 0x30(0x2E8)
};

// Object: Class Slate.SlateSettings
// Size: 0x30 (Inherited: 0x28)
struct USlateSettings : UObject
{
	bool bExplicitCanvasChildZOrder; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: Class Slate.SpinBoxWidgetStyle
// Size: 0x408 (Inherited: 0x30)
struct USpinBoxWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FSpinBoxStyle SpinBoxStyle; // 0x30(0x3D8)
};

// Object: Class Slate.TextBlockWidgetStyle
// Size: 0x280 (Inherited: 0x30)
struct UTextBlockWidgetStyle : USlateWidgetStyleContainerBase
{
	struct FTextBlockStyle TextBlockStyle; // 0x30(0x250)
};

