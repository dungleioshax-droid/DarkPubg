#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_AvatarWeaponHitFXData_type.BP_STRUCT_AvatarWeaponHitFXData_type
// Size: 0x14 (Inherited: 0x0)
struct FBP_STRUCT_AvatarWeaponHitFXData_type
{
	struct FString EffectPath_0_10BE9D8007788EA45AF4C54C06DC3028; // 0x0(0x10)
	int ID_1_5D54EA4001CDCE7777865F5B044D7534; // 0x10(0x4)
};

