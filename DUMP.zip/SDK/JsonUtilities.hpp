#pragma once

#include <cstdint>

// Object: ScriptStruct JsonUtilities.JsonObjectWrapper
// Size: 0x20 (Inherited: 0x0)
struct FJsonObjectWrapper
{
	struct FString jsonString; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: Class JsonUtilities.JsonUtilitiesDummyObject
// Size: 0x28 (Inherited: 0x28)
struct UJsonUtilitiesDummyObject : UObject
{
};

