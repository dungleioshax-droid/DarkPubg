#pragma once

#include <cstdint>

// Object: ScriptStruct STestKitMobile.STestMobileFillOptions
// Size: 0x2 (Inherited: 0x0)
struct FSTestMobileFillOptions
{
	bool bCommit; // 0x0(0x1)
	bool bClear; // 0x1(0x1)
};

// Object: ScriptStruct STestKitMobile.STestMobileDragOptions
// Size: 0x8 (Inherited: 0x0)
struct FSTestMobileDragOptions
{
	int Steps; // 0x0(0x4)
	bool bTouch; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct STestKitMobile.STestMobileTapOptions
// Size: 0x1 (Inherited: 0x0)
struct FSTestMobileTapOptions
{
	bool bTouch; // 0x0(0x1)
};

// Object: Class STestKitMobile.STestKitMobileLibrary
// Size: 0x28 (Inherited: 0x28)
struct USTestKitMobileLibrary : UBlueprintFunctionLibrary
{

	// Object: Function STestKitMobile.STestKitMobileLibrary.TapWidget
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b7cd8c
	// Params: [ Num(3) Size(0xA) ]
	bool TapWidget(struct UWidget* Widget, struct FSTestMobileTapOptions& Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B78BA0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function STestKitMobile.STestKitMobileLibrary.ShowConnectionPanel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7cd58
	// Params: [ Num(1) Size(0x1) ]
	bool ShowConnectionPanel();
	// [Call #1] RVA: 0x102B78580
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B78BA0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function STestKitMobile.STestKitMobileLibrary.RequestPairing
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7cd24
	// Params: [ Num(1) Size(0x1) ]
	bool RequestPairing();
	// [Call #1] RVA: 0x102B7856C
	// [Call #2] RVA: 0x102B78580
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B78BA0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function STestKitMobile.STestKitMobileLibrary.ReportResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7cb94
	// Params: [ Num(5) Size(0x39) ]
	bool ReportResult(struct FString RunId, bool bSuccess, struct FString Payload, struct FString Error);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B785D8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x102B7856C
	// [Call #18] RVA: 0x102B78580
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function STestKitMobile.STestKitMobileLibrary.ReportEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7caa8
	// Params: [ Num(3) Size(0x21) ]
	bool ReportEvent(struct FString RunId, struct FString EventJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B785AC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B785D8
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function STestKitMobile.STestKitMobileLibrary.IsRuntimeEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7ca74
	// Params: [ Num(1) Size(0x1) ]
	bool IsRuntimeEnabled();
	// [Call #1] RVA: 0x102B783E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B785AC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102B785D8
	// [Call #21] RVA: 0x101F8130C

	// Object: Function STestKitMobile.STestKitMobileLibrary.IsBridgeConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7ca40
	// Params: [ Num(1) Size(0x1) ]
	bool IsBridgeConnected();
	// [Call #1] RVA: 0x102B78428
	// [Call #2] RVA: 0x102B783E4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B785AC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function STestKitMobile.STestKitMobileLibrary.HitTestSelf
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c9c4
	// Params: [ Num(2) Size(0x9) ]
	bool HitTestSelf(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B79588
	// [Call #4] RVA: 0x102B78428
	// [Call #5] RVA: 0x102B783E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B785AC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.HideConnectionPanel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7c9b0
	// Params: [ Num(0) Size(0x0) ]
	void HideConnectionPanel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B79588
	// [Call #4] RVA: 0x102B78428
	// [Call #5] RVA: 0x102B783E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B785AC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetWidgetRect
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c930
	// Params: [ Num(2) Size(0x20) ]
	struct FVector4 GetWidgetRect(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B794D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B79588
	// [Call #7] RVA: 0x102B78428
	// [Call #8] RVA: 0x102B783E4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B785AC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetUIReferenceCaptureStatusJson
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c8cc
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUIReferenceCaptureStatusJson();
	// [Call #1] RVA: 0x102B7A7FC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B794D0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B79588
	// [Call #12] RVA: 0x102B78428
	// [Call #13] RVA: 0x102B783E4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetScreenCenter
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c850
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetScreenCenter(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B7949C
	// [Call #4] RVA: 0x102B7A7FC
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B794D0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B79588
	// [Call #15] RVA: 0x102B78428
	// [Call #16] RVA: 0x102B783E4

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetPairingCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c7ec
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetPairingCode();
	// [Call #1] RVA: 0x102B7847C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B7949C
	// [Call #9] RVA: 0x102B7A7FC
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102B794D0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B79588

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetDeviceId
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c788
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceId();
	// [Call #1] RVA: 0x102B784F4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B7847C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B7949C
	// [Call #14] RVA: 0x102B7A7FC
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x102B794D0

	// Object: Function STestKitMobile.STestKitMobileLibrary.GetBridgeStatusJson
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c724
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetBridgeStatusJson();
	// [Call #1] RVA: 0x102B78458
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B784F4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102B7847C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102B7949C
	// [Call #19] RVA: 0x102B7A7FC
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.FindWidgetInUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c5f8
	// Params: [ Num(4) Size(0x30) ]
	struct UWidget* FindWidgetInUI(struct FString UIName, struct FString WidgetName, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B788E4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102B78458
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x102B784F4
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x102B7847C
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function STestKitMobile.STestKitMobileLibrary.FindUserWidgetByUIName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c520
	// Params: [ Num(3) Size(0x20) ]
	struct UWidget* FindUserWidgetByUIName(struct FString UIName, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B7861C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B788E4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x102B78458
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function STestKitMobile.STestKitMobileLibrary.FillText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b7c3f8
	// Params: [ Num(4) Size(0x1B) ]
	bool FillText(struct UWidget* Widget, struct FString Text, struct FSTestMobileFillOptions& Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B791B0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B7861C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function STestKitMobile.STestKitMobileLibrary.DumpRuntimeWidgetTree
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7c300
	// Params: [ Num(3) Size(0x18) ]
	struct FString DumpRuntimeWidgetTree(bool bVisibleOnly, bool bIncludeText);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B796D0
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102B791B0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.DragWidget
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b7c1f4
	// Params: [ Num(4) Size(0x19) ]
	bool DragWidget(struct UWidget* From, struct UWidget* To, struct FSTestMobileDragOptions& Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B78E98
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B796D0
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function STestKitMobile.STestKitMobileLibrary.DragByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b7c0ac
	// Params: [ Num(5) Size(0x19) ]
	bool DragByOffset(struct UWidget* Widget, float Dx, float Dy, struct FSTestMobileDragOptions& Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B79158
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102B78E98

	// Object: Function STestKitMobile.STestKitMobileLibrary.DisconnectBridge
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7c098
	// Params: [ Num(0) Size(0x0) ]
	void DisconnectBridge();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B79158
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102B78E98

	// Object: Function STestKitMobile.STestKitMobileLibrary.ConnectBridge
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7bfb8
	// Params: [ Num(3) Size(0x12) ]
	bool ConnectBridge(struct FString BridgeUrl, bool bSaveUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B783FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B79158

	// Object: Function STestKitMobile.STestKitMobileLibrary.CollectVisibleWidgetBlueprintPaths
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7bf14
	// Params: [ Num(2) Size(0x18) ]
	struct FString CollectVisibleWidgetBlueprintPaths(int MaxDepth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B79FE8
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B783FC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function STestKitMobile.STestKitMobileLibrary.CollectVisibleWidgetBlueprintHierarchy
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b7be70
	// Params: [ Num(2) Size(0x18) ]
	struct FString CollectVisibleWidgetBlueprintHierarchy(int MaxDepth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B7A078
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B79FE8
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B783FC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function STestKitMobile.STestKitMobileLibrary.CaptureAndUploadUIReference
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7bcf0
	// Params: [ Num(5) Size(0x35) ]
	bool CaptureAndUploadUIReference(struct FString ServerURL, struct FString APIKey, struct FString Source, int JpegQuality);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B7A108
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B7A078
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function STestKitMobile.STestKitMobileLibrary.CaptureAndUploadConfiguredUIReference
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b7bc18
	// Params: [ Num(3) Size(0x15) ]
	bool CaptureAndUploadConfiguredUIReference(struct FString Source, int JpegQuality);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B7A704
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B7A108
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
};

