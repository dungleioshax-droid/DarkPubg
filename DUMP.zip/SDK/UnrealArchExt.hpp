#pragma once

#include <cstdint>

// Object: Enum UnrealArchExt.EWidgetCompareType
enum class EWidgetCompareType : uint8_t
{
	Equal = 0,
	NotEqual = 1,
	LessThan = 2,
	LargeThan = 3,
	EqualLessThan = 4,
	EqualLargeThan = 5,
	EWidgetCompareType_MAX = 6
};

// Object: Enum UnrealArchExt.EUserWidgetNameEqualPolitics
enum class EUserWidgetNameEqualPolitics : uint8_t
{
	Normal = 0,
	StartsWith = 1,
	Regex = 2,
	EUserWidgetNameEqualPolitics_MAX = 3
};

// Object: Enum UnrealArchExt.EUserWidgetFadingStatus
enum class EUserWidgetFadingStatus : uint8_t
{
	UserWidgetFadingStatus_None = 0,
	UserWidgetFadingStatus_FadingIn = 1,
	UserWidgetFadingStatus_FadingOut = 2,
	UserWidgetFadingStatus_MAX = 3
};

// Object: Enum UnrealArchExt.EUAEUIMsgCallType
enum class EUAEUIMsgCallType : uint8_t
{
	MCT_OnlySelf = 0,
	MCT_AllFunc = 1,
	MCT_MAX = 2
};

// Object: ScriptStruct UnrealArchExt.UserWidgetState
// Size: 0x28 (Inherited: 0x0)
struct FUserWidgetState
{
	struct FString WidgetName; // 0x0(0x10)
	struct FName ContainerName; // 0x10(0x8)
	int ZOrder; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct UUAEUserWidget* Widget; // 0x20(0x8)
};

// Object: ScriptStruct UnrealArchExt.UnixTimestampCallback
// Size: 0x18 (Inherited: 0x0)
struct FUnixTimestampCallback
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct UnrealArchExt.LogicManagerCreateParams
// Size: 0x18 (Inherited: 0x0)
struct FLogicManagerCreateParams
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
	struct UObject* pLogicManagerClass; // 0x10(0x8)
};

// Object: Class UnrealArchExt.UAEUserWidget
// Size: 0x418 (Inherited: 0x260)
struct UUAEUserWidget : UUserWidget
{
	struct UFrontendHUD* OwningFrontendHUD; // 0x260(0x8)
	struct ULogicManagerBase* OwningLogicManager; // 0x268(0x8)
	struct UUAEWidgetContainer* OwningWidgetContainer; // 0x270(0x8)
	struct UUAEUserWidget* ParentWidget; // 0x278(0x8)
	uint8_t Pad_0x280[0xA0]; // 0x280(0xA0)
	struct TArray<struct UProperty*> Params; // 0x320(0x10)
	uint8_t Pad_0x330[0x10]; // 0x330(0x10)
	struct FScriptMulticastDelegate widgetSizeNofity; // 0x340(0x10)
	struct FUserWidgetState DefaultUserWidgetState; // 0x350(0x28)
	struct FUserWidgetState CurrentUserWidgetState; // 0x378(0x28)
	float TickRate; // 0x3A0(0x4)
	bool bReceiveOnClickedEvent; // 0x3A4(0x1)
	bool bReceiveOnRightClickedEvent; // 0x3A5(0x1)
	bool bReceiveOnDoubleClickedEvent; // 0x3A6(0x1)
	bool bAutoSetScreenPosOnMouseEnter; // 0x3A7(0x1)
	struct FVector2D ScreenPos; // 0x3A8(0x8)
	struct FVector2D LastMouseEventScreenPos; // 0x3B0(0x8)
	uint8_t Pad_0x3B8[0x8]; // 0x3B8(0x8)
	uint8_t FadingStatus; // 0x3C0(0x1)
	uint8_t Pad_0x3C1[0x3]; // 0x3C1(0x3)
	float CurrentOpacity; // 0x3C4(0x4)
	float FadingInTime; // 0x3C8(0x4)
	float FadingOutTime; // 0x3CC(0x4)
	bool bNoFadeIn; // 0x3D0(0x1)
	bool bNoFadeOut; // 0x3D1(0x1)
	bool bShouldCollapse; // 0x3D2(0x1)
	bool bRegistUIMsg; // 0x3D3(0x1)
	uint8_t Pad_0x3D4[0x4]; // 0x3D4(0x4)
	struct FString UIMsgPrefix; // 0x3D8(0x10)
	struct TArray<struct FString> UIMsgFunctionList; // 0x3E8(0x10)
	bool bRegistedUIMsgToMoudle; // 0x3F8(0x1)
	uint8_t Pad_0x3F9[0x7]; // 0x3F9(0x7)
	struct FString MoudleToRegisted; // 0x400(0x10)
	uint8_t Pad_0x410[0x8]; // 0x410(0x8)


	// Object: Function UnrealArchExt.UAEUserWidget.Visible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1bb0
	// Params: [ Num(1) Size(0x1) ]
	bool Visible();
	// [Call #1] RVA: 0x1069B6290
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.UnRegistFromGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1b9c
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistFromGameFrontendHUD();
	// [Call #1] RVA: 0x1069B6290
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.SynchronizeBlueprintProperties
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void SynchronizeBlueprintProperties();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1b88
	// Params: [ Num(0) Size(0x0) ]
	void Show();
	// [Call #1] RVA: 0x1069B6290
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.SetParentWidgetRecursive
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1b0c
	// Params: [ Num(1) Size(0x8) ]
	void SetParentWidgetRecursive(struct UUAEUserWidget* InParentWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4180
	// [Call #4] RVA: 0x1069B6290
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.SetParentWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1a90
	// Params: [ Num(1) Size(0x8) ]
	void SetParentWidget(struct UUAEUserWidget* InParentWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4250
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069B4180
	// [Call #7] RVA: 0x1069B6290
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.SetOnWidgetShow
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c1a08
	// Params: [ Num(1) Size(0x10) ]
	void SetOnWidgetShow(DelegateProperty onShow);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B4B14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B4250
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B4180
	// [Call #11] RVA: 0x1069B6290
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEUserWidget.SetOnWidgetHide
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c1980
	// Params: [ Num(1) Size(0x10) ]
	void SetOnWidgetHide(DelegateProperty OnHide);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B4B30
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B4B14
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069B4250
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B4180
	// [Call #15] RVA: 0x1069B6290

	// Object: Function UnrealArchExt.UAEUserWidget.SetOnClearUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c18f8
	// Params: [ Num(1) Size(0x10) ]
	void SetOnClearUIStack(DelegateProperty onClear);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B4B4C
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B4B30
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1069B4B14
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069B4250
	// [Call #16] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.SetAdapation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c17cc
	// Params: [ Num(4) Size(0x10) ]
	void SetAdapation(float Left, float Top, float Right, float Bottom);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1069B4B4C
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B4B30
	// [Call #17] RVA: 0x101FD9E48

	// Object: Function UnrealArchExt.UAEUserWidget.RegistToGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1750
	// Params: [ Num(1) Size(0x8) ]
	void RegistToGameFrontendHUD(struct UFrontendHUD* GameFrontHUD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B6970
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069B4B4C
	// [Call #16] RVA: 0x101FD9E48

	// Object: Function UnrealArchExt.UAEUserWidget.Register
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1690
	// Params: [ Num(2) Size(0x9) ]
	void Register(struct ULogicManagerBase* LogicManager, bool bAddToViewport);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B3FE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B6970
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveShow();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveHide();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.ReceivedMountWidget
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1069c1674
	// Params: [ Num(0) Size(0x0) ]
	void ReceivedMountWidget();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B3FE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B6970
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.ReceivedInitWidget
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceivedInitWidget();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.ReCachedUIMsgFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1660
	// Params: [ Num(0) Size(0x0) ]
	void ReCachedUIMsgFunction();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B3FE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B6970
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.PushOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c15d0
	// Params: [ Num(1) Size(0x10) ]
	void PushOpenedUIStack(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5C74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069B3FE0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B6970
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.PopOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c1540
	// Params: [ Num(1) Size(0x10) ]
	void PopOpenedUIStack(struct FString curOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5C20
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B5C74
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1069B3FE0
	// [Call #18] RVA: 0x10516D168

	// Object: DelegateFunction UnrealArchExt.UAEUserWidget.OnWidgetShow__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void OnWidgetShow__DelegateSignature(struct FString ClassName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UnrealArchExt.UAEUserWidget.OnWidgetHide__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void OnWidgetHide__DelegateSignature(struct FString ClassName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.OnRightClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnRightClicked(struct FVector2D TempScreenPos);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.OnFadeOutFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1069c1524
	// Params: [ Num(0) Size(0x0) ]
	void OnFadeOutFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5C20
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B5C74
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1069B3FE0

	// Object: Function UnrealArchExt.UAEUserWidget.OnFadeInFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1069c1508
	// Params: [ Num(0) Size(0x0) ]
	void OnFadeInFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5C20
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B5C74
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1069B3FE0

	// Object: Function UnrealArchExt.UAEUserWidget.OnDoubleClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnDoubleClicked(struct FVector2D TempScreenPos);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.OnClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnClicked(struct FVector2D TempScreenPos);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UnrealArchExt.UAEUserWidget.OnClearUIStack__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnClearUIStack__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UnrealArchExt.UAEUserWidget.IntCompare
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1069c1408
	// Params: [ Num(4) Size(0xA) ]
	bool IntCompare(int A, int B, uint8_t CompareType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B68A8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B5C20
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B5C74
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function UnrealArchExt.UAEUserWidget.InitWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1384
	// Params: [ Num(1) Size(0x1) ]
	void InitWidget(bool Recursive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B38FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B68A8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B5C20
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function UnrealArchExt.UAEUserWidget.InitCustomWidget
	// Flags: [Native|Public]
	// Offset: 0x1069c12c8
	// Params: [ Num(2) Size(0x10) ]
	void InitCustomWidget(struct AActor* OwnerActor, struct UWidgetComponent* WidgetComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B38FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B68A8

	// Object: Function UnrealArchExt.UAEUserWidget.Hide
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c12b4
	// Params: [ Num(0) Size(0x0) ]
	void Hide();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B38FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B68A8

	// Object: Function UnrealArchExt.UAEUserWidget.HandleUIMessageBattle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c121c
	// Params: [ Num(1) Size(0x10) ]
	void HandleUIMessageBattle(struct FString UIMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5640
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B38FC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.HandleUIMessage
	// Flags: [Final|Native|Public]
	// Offset: 0x1069c1184
	// Params: [ Num(1) Size(0x10) ]
	void HandleUIMessage(struct FString UIMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B5468
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B5640
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.GetWidgetsByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c1040
	// Params: [ Num(4) Size(0x30) ]
	struct UWidget* GetWidgetsByName(struct FString WidgetName, struct FString OuterName, bool bUseContains);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B3D7C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069B5468
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1069B5640
	// [Call #22] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEUserWidget.GetWidgetContainsName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069c0f98
	// Params: [ Num(2) Size(0x18) ]
	struct UWidget* GetWidgetContainsName(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B3FA0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B3D7C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1069B5468

	// Object: Function UnrealArchExt.UAEUserWidget.GetParentWidget
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069c0f64
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEUserWidget* GetParentWidget();
	// [Call #1] RVA: 0x1069B47CC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B3FA0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B3D7C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.GetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069c0f28
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetOwningPlayer();
	// [Call #1] RVA: 0x1069B47CC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B3FA0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B3D7C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEUserWidget.GetOwningLogicManager
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069c0ef4
	// Params: [ Num(1) Size(0x8) ]
	struct ULogicManagerBase* GetOwningLogicManager();
	// [Call #1] RVA: 0x1069B47B0
	// [Call #2] RVA: 0x1069B47CC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B3FA0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069B3D7C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEUserWidget.GetOwningFrontendHUD
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069c0ec0
	// Params: [ Num(1) Size(0x8) ]
	struct UFrontendHUD* GetOwningFrontendHUD();
	// [Call #1] RVA: 0x1069B4690
	// [Call #2] RVA: 0x1069B47B0
	// [Call #3] RVA: 0x1069B47CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069B3FA0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.UAEUserWidget.GetImgDynamicMaterial
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1069c0e34
	// Params: [ Num(2) Size(0x10) ]
	struct UMaterialInstanceDynamic* GetImgDynamicMaterial(struct UImage* ImageMat);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B31DC
	// [Call #4] RVA: 0x1069B4690
	// [Call #5] RVA: 0x1069B47B0
	// [Call #6] RVA: 0x1069B47CC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B3FA0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.GetChildWidgetByEqualPolitics
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x1069c0d0c
	// Params: [ Num(4) Size(0x20) ]
	struct UUserWidget* GetChildWidgetByEqualPolitics(struct FString ChildName, uint8_t EqualPolitics, int RecursiveDepth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B518C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B31DC
	// [Call #14] RVA: 0x1069B4690
	// [Call #15] RVA: 0x1069B47B0

	// Object: Function UnrealArchExt.UAEUserWidget.GetChildWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c0c64
	// Params: [ Num(2) Size(0x18) ]
	struct UUserWidget* GetChildWidget(struct FString WName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4DC8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B518C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069B31DC

	// Object: Function UnrealArchExt.UAEUserWidget.GetAdapation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c0c2c
	// Params: [ Num(1) Size(0x10) ]
	struct FMargin GetAdapation();
	// [Call #1] RVA: 0x1069C2BF0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069B4DC8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B518C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.FloatCompare
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1069c0b2c
	// Params: [ Num(4) Size(0xA) ]
	bool FloatCompare(float A, float B, uint8_t CompareType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B6830
	// [Call #8] RVA: 0x1069C2BF0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069B4DC8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEUserWidget.DynamicRegistUIMsgToCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c0ab0
	// Params: [ Num(1) Size(0x8) ]
	void DynamicRegistUIMsgToCache(struct UUAEUserWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4BE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B6830
	// [Call #11] RVA: 0x1069C2BF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B4DC8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEUserWidget.DestroyWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c0a9c
	// Params: [ Num(0) Size(0x0) ]
	void DestroyWidget();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4BE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B6830
	// [Call #11] RVA: 0x1069C2BF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B4DC8
	// [Call #15] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEUserWidget.ClearOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069c0a88
	// Params: [ Num(0) Size(0x0) ]
	void ClearOpenedUIStack();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4BE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B6830
	// [Call #11] RVA: 0x1069C2BF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069B4DC8

	// Object: Function UnrealArchExt.UAEUserWidget.ClearFunctionCacheByMsgName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c09f0
	// Params: [ Num(1) Size(0x10) ]
	void ClearFunctionCacheByMsgName(struct FString InUIMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4B74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B4BE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B6830

	// Object: Function UnrealArchExt.UAEUserWidget.ClearFunctionCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c09dc
	// Params: [ Num(0) Size(0x0) ]
	void ClearFunctionCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4B74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B4BE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B6830

	// Object: Function UnrealArchExt.UAEUserWidget.ClearClassWidgetTree
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c09c8
	// Params: [ Num(0) Size(0x0) ]
	void ClearClassWidgetTree();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B4B74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069B4BE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B6830

	// Object: Function UnrealArchExt.UAEUserWidget.BindCustomUserEvent
	// Flags: [Native|Public]
	// Offset: 0x1069c090c
	// Params: [ Num(2) Size(0x10) ]
	void BindCustomUserEvent(struct AActor* OwnerActor, struct UWidgetComponent* WidgetComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B4B74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B4BE0
};

// Object: Class UnrealArchExt.LuaUAEUserWidget
// Size: 0x488 (Inherited: 0x418)
struct ULuaUAEUserWidget : UUAEUserWidget
{
	uint8_t Pad_0x418[0x58]; // 0x418(0x58)
	struct FString LuaFilePath; // 0x470(0x10)
	bool bEnableBlueprintTick; // 0x480(0x1)
	uint8_t Pad_0x481[0x7]; // 0x481(0x7)
};

// Object: Class UnrealArchExt.UAECanvasPanel
// Size: 0x130 (Inherited: 0x130)
struct UUAECanvasPanel : UCanvasPanel
{

	// Object: Function UnrealArchExt.UAECanvasPanel.ReceiveInitCanvasPanel
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1069bedb0
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveInitCanvasPanel();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10518559C
};

// Object: Class UnrealArchExt.BackendUtils
// Size: 0x30 (Inherited: 0x28)
struct UBackendUtils : UObject
{
	struct UBackendHUD* OwningBackendHUD; // 0x28(0x8)
};

// Object: Class UnrealArchExt.BackendHUD
// Size: 0xB0 (Inherited: 0x28)
struct UBackendHUD : UObject
{
	struct UEngine* Engine; // 0x28(0x8)
	struct FString BackendUtilsClassName; // 0x30(0x10)
	struct UBackendUtils* Utils; // 0x40(0x8)
	struct TArray<struct UFrontendHUD*> FrontendHUDList; // 0x48(0x10)
	struct TMap<uint32_t, struct TWeakObjectPtr<struct UFrontendHUD>> FrontendHUDMap; // 0x58(0x50)
	uint8_t Pad_0xA8[0x8]; // 0xA8(0x8)


	// Object: Function UnrealArchExt.BackendHUD.GetFrontendHUDByGameInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069b9bfc
	// Params: [ Num(2) Size(0x10) ]
	struct UFrontendHUD* GetFrontendHUDByGameInstance(struct UGameInstance* GameInstance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A2B38
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870

	// Object: Function UnrealArchExt.BackendHUD.GetFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069b9b70
	// Params: [ Num(2) Size(0x10) ]
	struct UFrontendHUD* GetFrontendHUD(int FrontendHUDIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A2B14
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069A2B38
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class UnrealArchExt.LogicManagerBase
// Size: 0x108 (Inherited: 0x28)
struct ULogicManagerBase : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
	struct UFrontendHUD* OwningFrontendHUD; // 0x38(0x8)
	uint8_t Pad_0x40[0x10]; // 0x40(0x10)
	bool bPersistentUI; // 0x50(0x1)
	bool bDynamicWidget; // 0x51(0x1)
	bool bKeepDynamicWidget; // 0x52(0x1)
	bool bUseNewHandleUIMessage; // 0x53(0x1)
	int iUIControlState; // 0x54(0x4)
	int DefaultSceneCameraIndex; // 0x58(0x4)
	uint8_t Pad_0x5C[0x14]; // 0x5C(0x14)
	struct TArray<struct FName> GameStatusList; // 0x70(0x10)
	struct TArray<struct FString> InvalidWorldNameList; // 0x80(0x10)
	uint8_t Pad_0x90[0x30]; // 0x90(0x30)
	struct TArray<struct UObject*> WidgetUClassList; // 0xC0(0x10)
	struct TArray<struct UUAEUserWidget*> WidgetList; // 0xD0(0x10)
	uint8_t Pad_0xE0[0x18]; // 0xE0(0x18)
	struct TArray<struct UObject*> DelayMessage_Obj; // 0xF8(0x10)


	// Object: Function UnrealArchExt.LogicManagerBase.SetEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bdf34
	// Params: [ Num(1) Size(0x1) ]
	void SetEnableRemoveDynamicWidgets(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069AFE88
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UnrealArchExt.LogicManagerBase.MarkWidgetClassPendingKill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bdeb8
	// Params: [ Num(1) Size(0x8) ]
	void MarkWidgetClassPendingKill(struct UUAEUserWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069AF2E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069AFE88
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UnrealArchExt.LogicManagerBase.IsNeedClear
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069bddc8
	// Params: [ Num(4) Size(0xD) ]
	bool IsNeedClear(float MaxLowLevelMemorySize, float MaxMiddleMemorySize, float MaxGCArrayObjectSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069AFE94
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069AF2E8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069AFE88
	// [Call #14] RVA: 0x10519022C

	// Object: Function UnrealArchExt.LogicManagerBase.IsEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1069bdd94
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnableRemoveDynamicWidgets();
	// [Call #1] RVA: 0x1069AFE7C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069AFE94
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069AF2E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069AFE88
	// [Call #15] RVA: 0x10519022C

	// Object: Function UnrealArchExt.LogicManagerBase.GetWidgetList
	// Flags: [Final|Native|Public]
	// Offset: 0x1069bdd30
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UUAEUserWidget*> GetWidgetList();
	// [Call #1] RVA: 0x1069AFCF0
	// [Call #2] RVA: 0x1069BE3AC
	// [Call #3] RVA: 0x103307444
	// [Call #4] RVA: 0x103307444
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1069AFE7C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069AFE94
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069AF2E8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.LogicManagerBase.GetWidgetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bdc88
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEUserWidget* GetWidgetByName(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069AFD44
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1069AFCF0
	// [Call #8] RVA: 0x1069BE3AC
	// [Call #9] RVA: 0x103307444
	// [Call #10] RVA: 0x103307444
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1069AFE7C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069AFE94

	// Object: Function UnrealArchExt.LogicManagerBase.GetWidgetByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bdbfc
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEUserWidget* GetWidgetByClass(struct UObject* InClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069AFE14
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069AFD44
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1069AFCF0
	// [Call #11] RVA: 0x1069BE3AC
	// [Call #12] RVA: 0x103307444
	// [Call #13] RVA: 0x103307444
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1069AFE7C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.LogicManagerBase.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bdbc8
	// Params: [ Num(1) Size(0x8) ]
	struct UFrontendHUD* GetOwningFrontendHUD();
	// [Call #1] RVA: 0x1069AE4C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069AFE14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069AFD44
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1069AFCF0
	// [Call #12] RVA: 0x1069BE3AC
	// [Call #13] RVA: 0x103307444
	// [Call #14] RVA: 0x103307444
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1069AFE7C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.LogicManagerBase.GetDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bdb94
	// Params: [ Num(1) Size(0x4) ]
	int GetDefaultSceneCamera();
	// [Call #1] RVA: 0x1069AFE74
	// [Call #2] RVA: 0x1069AE4C0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069AFE14
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069AFD44
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1069AFCF0
	// [Call #13] RVA: 0x1069BE3AC
	// [Call #14] RVA: 0x103307444
	// [Call #15] RVA: 0x103307444
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1069AFE7C

	// Object: Function UnrealArchExt.LogicManagerBase.DispatchUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bda34
	// Params: [ Num(3) Size(0x20) ]
	void DispatchUIMessage(struct FString UIMessage, struct UObject* Source, struct UUAEUserWidget* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1069AF384
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1069AFE74
	// [Call #17] RVA: 0x1069AE4C0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1069AFE14
};

// Object: Class UnrealArchExt.FrontendHUD
// Size: 0x230 (Inherited: 0x28)
struct UFrontendHUD : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
	struct UGameInstance* GameInstance; // 0x40(0x8)
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)
	struct FString FrontendUtilsClassName; // 0x50(0x10)
	struct UFrontendUtils* Utils; // 0x60(0x8)
	struct TArray<struct ULogicManagerBase*> LogicManagerList; // 0x68(0x10)
	struct TMap<struct FString, struct TWeakObjectPtr<struct ULogicManagerBase>> LogicManagerMap; // 0x78(0x50)
	uint8_t Pad_0xC8[0x10]; // 0xC8(0x10)
	int UnusedWidgetMinCount; // 0xD8(0x4)
	int UnusedWidgetMaxCount; // 0xDC(0x4)
	int UnusedWidgetKeepTime; // 0xE0(0x4)
	float MaxLowLevelMemoryLimit; // 0xE4(0x4)
	float MaxMiddleMemoryLimit; // 0xE8(0x4)
	float MaxGCArrayObjectSize; // 0xEC(0x4)
	struct FString CurrentGameStatus; // 0xF0(0x10)
	struct FString LastGameStatus; // 0x100(0x10)
	bool InComBatStatus; // 0x110(0x1)
	uint8_t Pad_0x111[0x7]; // 0x111(0x7)
	struct FString PendingGameStatus; // 0x118(0x10)
	struct FString LatestGameStatusURL; // 0x128(0x10)
	struct FScriptMulticastDelegate OnPreSwitchLobbyEntry; // 0x138(0x10)
	struct FScriptMulticastDelegate OnPostSwitchLobbyEntry; // 0x148(0x10)
	struct FScriptMulticastDelegate OnPostSwitchGameStatusStartEvent; // 0x158(0x10)
	struct FScriptMulticastDelegate OnPostSwitchGameStatusEvent; // 0x168(0x10)
	struct FScriptMulticastDelegate OnPreSwitchGameStatusEvent; // 0x178(0x10)
	uint8_t Pad_0x188[0x10]; // 0x188(0x10)
	struct FScriptMulticastDelegate OnGameStatusSwitchTerminate; // 0x198(0x10)
	struct FScriptMulticastDelegate OnPreSwitchGameStatusEndEvent; // 0x1A8(0x10)
	struct FScriptMulticastDelegate OnCreateLogicManagerListEvent; // 0x1B8(0x10)
	struct FScriptMulticastDelegate OnSetGameStatusEvent; // 0x1C8(0x10)
	struct FScriptMulticastDelegate OnAddLuaLogicManagerEvent; // 0x1D8(0x10)
	struct FScriptMulticastDelegate OnRemoveLuaLogicManagerEvent; // 0x1E8(0x10)
	struct FScriptMulticastDelegate OnRenderQualityChangedEvent; // 0x1F8(0x10)
	struct FScriptMulticastDelegate OnPostWorldCleanupEvent; // 0x208(0x10)
	struct UWorld* CurrentGameStatusWorld; // 0x218(0x8)
	uint8_t Pad_0x220[0x10]; // 0x220(0x10)


	// Object: Function UnrealArchExt.FrontendHUD.SwitchUIStatus
	// Flags: [Native|Public]
	// Offset: 0x1069bb154
	// Params: [ Num(1) Size(0x10) ]
	void SwitchUIStatus(struct FString InUIStatus);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UnrealArchExt.FrontendHUD.SwitchGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1069bb014
	// Params: [ Num(2) Size(0x20) ]
	void SwitchGameStatus(struct FString GameStatus, struct FString Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C
	// [Call #21] RVA: 0x105190870

	// Object: Function UnrealArchExt.FrontendHUD.StandAloneSwitchGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1069baed4
	// Params: [ Num(2) Size(0x20) ]
	void StandAloneSwitchGameStatus(struct FString InGameStatus, struct FString Options);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x104EEF504

	// Object: Function UnrealArchExt.FrontendHUD.OnRenderQualityChanged
	// Flags: [Final|Native|Public]
	// Offset: 0x1069bae50
	// Params: [ Num(1) Size(0x1) ]
	void OnRenderQualityChanged(bool bLoadMap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A627C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendHUD.OnPreLoadMap
	// Flags: [Native|Protected]
	// Offset: 0x1069badb0
	// Params: [ Num(1) Size(0x10) ]
	void OnPreLoadMap(struct FString MapName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069A627C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.FrontendHUD.OnPostLoadMapWithWorld
	// Flags: [Native|Protected]
	// Offset: 0x1069bad2c
	// Params: [ Num(1) Size(0x8) ]
	void OnPostLoadMapWithWorld(struct UWorld* World);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A627C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendHUD.OnGameViewportClientCreated
	// Flags: [Final|Native|Protected]
	// Offset: 0x1069bad18
	// Params: [ Num(0) Size(0x0) ]
	void OnGameViewportClientCreated();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A627C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendHUD.GetWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bacdc
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetWorld();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A627C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendHUD.GetUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069baca8
	// Params: [ Num(1) Size(0x8) ]
	struct UFrontendUtils* GetUtils();
	// [Call #1] RVA: 0x1069A5948
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069A627C

	// Object: Function UnrealArchExt.FrontendHUD.GetPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bac74
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetPlayerController();
	// [Call #1] RVA: 0x1069A55D8
	// [Call #2] RVA: 0x1069A5948
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1069A627C

	// Object: Function UnrealArchExt.FrontendHUD.GetLogicManagerByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bab80
	// Params: [ Num(2) Size(0x18) ]
	struct ULogicManagerBase* GetLogicManagerByName(struct FString LogicManagerTagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1069A57E8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1069A55D8
	// [Call #13] RVA: 0x1069A5948
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendHUD.GetLogicManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069baaf4
	// Params: [ Num(2) Size(0x10) ]
	struct ULogicManagerBase* GetLogicManager(int LogicManagerIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A5A3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x1069A57E8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1069A55D8
	// [Call #16] RVA: 0x1069A5948

	// Object: Function UnrealArchExt.FrontendHUD.GetGameViewportClient
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069baac0
	// Params: [ Num(1) Size(0x8) ]
	struct UGameViewportClient* GetGameViewportClient();
	// [Call #1] RVA: 0x1069A55C8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069A5A3C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1069A57E8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1069A55D8
	// [Call #17] RVA: 0x1069A5948

	// Object: Function UnrealArchExt.FrontendHUD.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069baa8c
	// Params: [ Num(1) Size(0x8) ]
	struct AGameMode* GetGameMode();
	// [Call #1] RVA: 0x1069A5600
	// [Call #2] RVA: 0x1069A55C8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A5A3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x1069A57E8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1069A55D8
	// [Call #18] RVA: 0x1069A5948

	// Object: Function UnrealArchExt.FrontendHUD.GetGameInstance
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1069baa58
	// Params: [ Num(1) Size(0x8) ]
	struct UGameInstance* GetGameInstance();
	// [Call #1] RVA: 0x1069A55A8
	// [Call #2] RVA: 0x1069A5600
	// [Call #3] RVA: 0x1069A55C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069A5A3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1069A57E8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1069A55D8

	// Object: Function UnrealArchExt.FrontendHUD.FindRegistedUIFunctionList
	// Flags: [Final|Native|Public]
	// Offset: 0x1069ba934
	// Params: [ Num(3) Size(0x30) ]
	struct TArray<struct TWeakObjectPtr<struct UObject>> FindRegistedUIFunctionList(struct FString strMsg, struct FString moduleMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A7060
	// [Call #6] RVA: 0x1069BD498
	// [Call #7] RVA: 0x1020584A0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x1020584A0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1069A55A8
	// [Call #15] RVA: 0x1069A5600
	// [Call #16] RVA: 0x1069A55C8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069A5A3C

	// Object: Function UnrealArchExt.FrontendHUD.EnableGuiTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069ba8b0
	// Params: [ Num(1) Size(0x1) ]
	void EnableGuiTest(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A7434
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069A7060
	// [Call #9] RVA: 0x1069BD498
	// [Call #10] RVA: 0x1020584A0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x1020584A0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1069A55A8
	// [Call #18] RVA: 0x1069A5600
	// [Call #19] RVA: 0x1069A55C8

	// Object: Function UnrealArchExt.FrontendHUD.DynamicRegistUIMsgToCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069ba7dc
	// Params: [ Num(2) Size(0x18) ]
	void DynamicRegistUIMsgToCache(struct UUAEUserWidget* Widget, struct FString module);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A6DF4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069A7434
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A7060
	// [Call #17] RVA: 0x1069BD498
	// [Call #18] RVA: 0x1020584A0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x1020584A0

	// Object: Function UnrealArchExt.FrontendHUD.ClearLogicManagerListByStatus
	// Flags: [Final|Native|Public]
	// Offset: 0x1069ba71c
	// Params: [ Num(2) Size(0x9) ]
	void ClearLogicManagerListByStatus(struct FName PendingStatus, bool bIsForceDelete);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A5A68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A6DF4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A7434
	// [Call #17] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendHUD.ClearLogicManagerByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069ba638
	// Params: [ Num(1) Size(0x10) ]
	void ClearLogicManagerByName(struct FString managerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1069A5628
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A5A68
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1069A6DF4
	// [Call #22] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.FrontendHUD.ClearInGameUI
	// Flags: [Final|Native|Public]
	// Offset: 0x1069ba624
	// Params: [ Num(0) Size(0x0) ]
	void ClearInGameUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1069A5628
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A5A68
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class UnrealArchExt.FrontendUtils
// Size: 0x378 (Inherited: 0x28)
struct UFrontendUtils : UObject
{
	struct UFrontendHUD* OwningFrontendHUD; // 0x28(0x8)
	struct FScriptMulticastDelegate SceneCameraSwitchedDelegate; // 0x30(0x10)
	struct FName CurrentSceneCameraName; // 0x40(0x8)
	struct TArray<struct ACameraActor*> SceneCameraList; // 0x48(0x10)
	struct TMap<struct FName, struct TWeakObjectPtr<struct ACameraActor>> SceneCameraMap; // 0x58(0x50)
	struct TArray<struct ADirectionalLight*> SceneDirectionalLightList; // 0xA8(0x10)
	struct TMap<struct FName, struct TWeakObjectPtr<struct ADirectionalLight>> SceneDirectionalLightMap; // 0xB8(0x50)
	struct TArray<struct APointLight*> ScenePointLightList; // 0x108(0x10)
	struct TMap<struct FName, struct TWeakObjectPtr<struct APointLight>> ScenePointLightMap; // 0x118(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct ASkyLight>> SceneSkyLightMap; // 0x168(0x50)
	uint8_t Pad_0x1B8[0x68]; // 0x1B8(0x68)
	struct FString GlobalUIContainerClassName; // 0x220(0x10)
	struct TArray<struct FName> GlobalUIContainerNames; // 0x230(0x10)
	struct TMap<struct FName, struct UUAEWidgetContainer*> GlobalUIContainers; // 0x240(0x50)
	struct TArray<struct UUAEWidgetContainer*> GlobalPushUIContainers; // 0x290(0x10)
	struct TMap<struct FName, struct UUAEWidgetContainer*> GlobalPushUIRelations; // 0x2A0(0x50)
	uint8_t Pad_0x2F0[0x38]; // 0x2F0(0x38)
	struct TMap<struct UUAEWidgetContainer*, bool> UIShowStatusMap; // 0x328(0x50)


	// Object: Function UnrealArchExt.FrontendUtils.SwitchSceneCameraToTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1069bc6f0
	// Params: [ Num(6) Size(0x3E) ]
	void SwitchSceneCameraToTransform(struct FTransform targetTrans, enum class ECameraProjectionMode ProjectionMode, float FOV, float BlendTime, bool bForce, bool bAutoFixAspect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069A7C08
	// [Call #14] RVA: 0x10519022C

	// Object: Function UnrealArchExt.FrontendUtils.SwitchSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bc5f4
	// Params: [ Num(3) Size(0xD) ]
	void SwitchSceneCamera(struct FName SceneCameraName, float BlendTime, bool bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069A78B0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendUtils.SetSceneSkyLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1069bc49c
	// Params: [ Num(4) Size(0x54) ]
	void SetSceneSkyLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069A950C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A78B0

	// Object: Function UnrealArchExt.FrontendUtils.SetScenePointLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1069bc2cc
	// Params: [ Num(6) Size(0x5C) ]
	void SetScenePointLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, int inverseSquareFalloff, float Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069A91FC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendUtils.SetSceneDirectionalLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1069bc134
	// Params: [ Num(5) Size(0x55) ]
	void SetSceneDirectionalLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, struct FLightingChannels Channel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069A8F90
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendUtils.SetAutoFixFovByAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bc074
	// Params: [ Num(2) Size(0x9) ]
	void SetAutoFixFovByAspectRatio(struct ACameraActor* CameraActor, bool bInAutoFixFov);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A7B24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069A8F90

	// Object: Function UnrealArchExt.FrontendUtils.RegisterSceneSkyLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbfc0
	// Params: [ Num(2) Size(0x10) ]
	void RegisterSceneSkyLight(struct FName sceneLightName, struct ASkyLight* Light);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A94C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A7B24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendUtils.RegisterScenePointLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbf0c
	// Params: [ Num(2) Size(0x10) ]
	void RegisterScenePointLight(struct FName sceneLightName, struct APointLight* Light);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A9180
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A94C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069A7B24

	// Object: Function UnrealArchExt.FrontendUtils.RegisterSceneDirectionalLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbe58
	// Params: [ Num(2) Size(0x10) ]
	void RegisterSceneDirectionalLight(struct FName sceneLightName, struct ADirectionalLight* Light);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A8F10
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A9180
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069A94C8
	// [Call #16] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendUtils.RegisterSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbda4
	// Params: [ Num(2) Size(0x10) ]
	void RegisterSceneCamera(struct FName SceneCameraName, struct ACameraActor* SceneCamera);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A81C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A8F10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069A9180
	// [Call #16] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendUtils.PopAllPushedUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbd90
	// Params: [ Num(0) Size(0x0) ]
	void PopAllPushedUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A81C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A8F10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069A9180

	// Object: Function UnrealArchExt.FrontendUtils.OnAllSceneCamerasRegistered
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1069bbd74
	// Params: [ Num(0) Size(0x0) ]
	void OnAllSceneCamerasRegistered();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A81C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069A8F10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069A9180

	// Object: Function UnrealArchExt.FrontendUtils.IsPushedPanel
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bbcd8
	// Params: [ Num(2) Size(0x9) ]
	bool IsPushedPanel(struct FName& managerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A8650
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069A81C0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069A8F10

	// Object: Function UnrealArchExt.FrontendUtils.IsNoRenderClient
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbca4
	// Params: [ Num(1) Size(0x1) ]
	bool IsNoRenderClient();
	// [Call #1] RVA: 0x1069A8810
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069A8650
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069A81C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069A8F10

	// Object: Function UnrealArchExt.FrontendUtils.GetUIStackTopSrcTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bbc40
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUIStackTopSrcTag();
	// [Call #1] RVA: 0x1069A8570
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1069A8810
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069A8650
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069A81C0
	// [Call #15] RVA: 0x10516D168

	// Object: Function UnrealArchExt.FrontendUtils.GetUIStackTopDstTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bbbdc
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUIStackTopDstTag();
	// [Call #1] RVA: 0x1069A85E0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1069A8570
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1069A8810
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069A8650
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendUtils.GetUIStackTop
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bbb78
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUIStackTop();
	// [Call #1] RVA: 0x1069A854C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1069A85E0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1069A8570
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1069A8810
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069A8650

	// Object: Function UnrealArchExt.FrontendUtils.GetSceneCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbb44
	// Params: [ Num(1) Size(0x8) ]
	struct UCameraComponent* GetSceneCameraComponent();
	// [Call #1] RVA: 0x1069A81A4
	// [Call #2] RVA: 0x1069A854C
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1069A85E0
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1069A8570
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1069A8810
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1069A8650

	// Object: Function UnrealArchExt.FrontendUtils.GetSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bbb10
	// Params: [ Num(1) Size(0x8) ]
	struct ACameraActor* GetSceneCamera();
	// [Call #1] RVA: 0x1069A80B4
	// [Call #2] RVA: 0x1069A81A4
	// [Call #3] RVA: 0x1069A854C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1069A85E0
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1069A8570
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1069A8810
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1069A8650

	// Object: Function UnrealArchExt.FrontendUtils.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bbadc
	// Params: [ Num(1) Size(0x8) ]
	struct UFrontendHUD* GetOwningFrontendHUD();
	// [Call #1] RVA: 0x1069A77BC
	// [Call #2] RVA: 0x1069A80B4
	// [Call #3] RVA: 0x1069A81A4
	// [Call #4] RVA: 0x1069A854C
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1069A85E0
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1069A8570
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1069A8810
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function UnrealArchExt.FrontendUtils.GetGlobalUIContainer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bba50
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEWidgetContainer* GetGlobalUIContainer(struct FName ContainerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A8288
	// [Call #4] RVA: 0x1069A77BC
	// [Call #5] RVA: 0x1069A80B4
	// [Call #6] RVA: 0x1069A81A4
	// [Call #7] RVA: 0x1069A854C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1069A85E0
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1069A8570
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function UnrealArchExt.FrontendUtils.GetAllActorsFromLevel
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1069bb96c
	// Params: [ Num(2) Size(0x18) ]
	void GetAllActorsFromLevel(struct ULevel* Level, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069A8E18
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069A8288
	// [Call #12] RVA: 0x1069A77BC
	// [Call #13] RVA: 0x1069A80B4
	// [Call #14] RVA: 0x1069A81A4
	// [Call #15] RVA: 0x1069A854C
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.FrontendUtils.EnableLobbyMainLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bb8e8
	// Params: [ Num(1) Size(0x1) ]
	void EnableLobbyMainLight(bool NewEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A96DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069A8E18
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069A8288
	// [Call #15] RVA: 0x1069A77BC
	// [Call #16] RVA: 0x1069A80B4

	// Object: Function UnrealArchExt.FrontendUtils.ClearAllSceneCameras
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bb8d4
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllSceneCameras();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069A96DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069A8E18
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069A8288
	// [Call #15] RVA: 0x1069A77BC
};

// Object: Class UnrealArchExt.TableTraver
// Size: 0x28 (Inherited: 0x28)
struct UTableTraver : UObject
{
};

// Object: Class UnrealArchExt.UAEDataTable
// Size: 0x120 (Inherited: 0x88)
struct UUAEDataTable : UDataTable
{
	uint8_t Pad_0x88[0x38]; // 0x88(0x38)
	struct TMap<struct FString, struct UProperty*> NameToProperty; // 0xC0(0x50)
	uint8_t Pad_0x110[0x10]; // 0x110(0x10)


	// Object: Function UnrealArchExt.UAEDataTable.SetTableData_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bf754
	// Params: [ Num(4) Size(0x31) ]
	bool SetTableData_String(struct FString KeyValue, struct FString TagName, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B1E48
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEDataTable.SetTableData_Int32
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bf618
	// Params: [ Num(4) Size(0x25) ]
	bool SetTableData_Int32(struct FString KeyValue, struct FString TagName, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B1CC0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069B1E48
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEDataTable.SetTableData_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069bf4dc
	// Params: [ Num(4) Size(0x25) ]
	bool SetTableData_Float(struct FString KeyValue, struct FString TagName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069B1D80
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1069B1CC0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEDataTable.GetTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bf478
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetTableName();
	// [Call #1] RVA: 0x1069B1860
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1069B1D80
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function UnrealArchExt.UAEDataTable.GetRealTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1069bf3a8
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRealTableName(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B18B4
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1069B1860
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1069B1D80
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function UnrealArchExt.UAEDataTable.ConditionAddEmptyRow
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1069bf30c
	// Params: [ Num(2) Size(0x9) ]
	bool ConditionAddEmptyRow(struct FName& RowName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B1B68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069B18B4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1069B1860
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
};

// Object: Class UnrealArchExt.UAEDataTableInterface
// Size: 0x28 (Inherited: 0x28)
struct IUAEDataTableInterface : IInterface
{
};

// Object: Class UnrealArchExt.UAEUserWidgetForDrag
// Size: 0x470 (Inherited: 0x418)
struct UUAEUserWidgetForDrag : UUAEUserWidget
{
	struct FName WidgetName; // 0x418(0x8)
	struct UUserWidget* DefaultDragVisualClass; // 0x420(0x8)
	uint8_t Pivot; // 0x428(0x1)
	uint8_t Pad_0x429[0x3]; // 0x429(0x3)
	struct FVector2D Offset; // 0x42C(0x8)
	uint8_t Pad_0x434[0x4]; // 0x434(0x4)
	struct UDragDropOperation* DragDropOperation; // 0x438(0x8)
	DelegateProperty OnOnDragDetectedDel; // 0x440(0x10)
	struct FScriptMulticastDelegate OnDragEnterDel; // 0x450(0x10)
	struct FScriptMulticastDelegate OnDragCancelledDel; // 0x460(0x10)


	// Object: Function UnrealArchExt.UAEUserWidgetForDrag.OnDragged
	// Flags: [Final|Native|Public]
	// Offset: 0x1069c3220
	// Params: [ Num(1) Size(0x8) ]
	void OnDragged(struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B8310
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10518559C
};

// Object: Class UnrealArchExt.UAEWidgetContainer
// Size: 0x430 (Inherited: 0x418)
struct UUAEWidgetContainer : UUAEUserWidget
{
	struct TArray<struct UWidget*> WidgetList; // 0x418(0x10)
	struct UCanvasPanel* ContainerCache; // 0x428(0x8)


	// Object: Function UnrealArchExt.UAEWidgetContainer.RemoveWidgetInternal
	// Flags: [Final|Native|Protected]
	// Offset: 0x1069c3b10
	// Params: [ Num(1) Size(0x8) ]
	void RemoveWidgetInternal(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B8F7C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEWidgetContainer.RemoveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c3a94
	// Params: [ Num(1) Size(0x8) ]
	void RemoveWidget(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B8F44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069B8F7C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UnrealArchExt.UAEWidgetContainer.AddWidgetWithZOrderInternal
	// Flags: [Final|Native|Protected]
	// Offset: 0x1069c39dc
	// Params: [ Num(2) Size(0xC) ]
	void AddWidgetWithZOrderInternal(struct UWidget* Widget, int ZOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B9044
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B8F44
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069B8F7C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function UnrealArchExt.UAEWidgetContainer.AddWidgetWithZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c3924
	// Params: [ Num(2) Size(0xC) ]
	void AddWidgetWithZOrder(struct UWidget* Widget, int ZOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069B8FE4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1069B9044
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B8F44
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B8F7C

	// Object: Function UnrealArchExt.UAEWidgetContainer.AddWidgetInternal
	// Flags: [Final|Native|Protected]
	// Offset: 0x1069c38a8
	// Params: [ Num(1) Size(0x8) ]
	void AddWidgetInternal(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B8EB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069B8FE4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1069B9044
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B8F44

	// Object: Function UnrealArchExt.UAEWidgetContainer.AddWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c382c
	// Params: [ Num(1) Size(0x8) ]
	void AddWidget(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069B8E6C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069B8EB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069B8FE4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069B9044
};

