#pragma once

#include <cstdint>

// Object: ScriptStruct GameFeatures.GameFeatureComponentEntry
// Size: 0x58 (Inherited: 0x0)
struct FGameFeatureComponentEntry
{
	struct UClass* ActorClass; // 0x0(0x28)
	struct UClass* ComponentClass; // 0x28(0x28)
	uint8_t bClientComponent : 1; // 0x50(0x1), Mask(0x1)
	uint8_t bServerComponent : 1; // 0x50(0x1), Mask(0x2)
	uint8_t BitPad_0x50_2 : 6; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
};

// Object: ScriptStruct GameFeatures.GameFeaturePluginStateMachineProperties
// Size: 0x70 (Inherited: 0x0)
struct FGameFeaturePluginStateMachineProperties
{
	uint8_t Pad_0x0[0x68]; // 0x0(0x68)
	struct UGameFeatureData* GameFeatureData; // 0x68(0x8)
};

// Object: Class GameFeatures.GameFeatureAction
// Size: 0x28 (Inherited: 0x28)
struct UGameFeatureAction : UObject
{
};

// Object: Class GameFeatures.GameFeatureAction_AddComponents
// Size: 0x50 (Inherited: 0x28)
struct UGameFeatureAction_AddComponents : UGameFeatureAction
{
	struct TArray<struct FGameFeatureComponentEntry> ComponentList; // 0x28(0x10)
	uint8_t Pad_0x38[0x18]; // 0x38(0x18)
};

// Object: Class GameFeatures.GameFeatureData
// Size: 0x50 (Inherited: 0x30)
struct UGameFeatureData : UPrimaryDataAsset
{
	struct TArray<struct UGameFeatureAction*> Actions; // 0x30(0x10)
	struct TArray<struct FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan; // 0x40(0x10)
};

// Object: Class GameFeatures.GameFeaturePluginStateMachine
// Size: 0x158 (Inherited: 0x28)
struct UGameFeaturePluginStateMachine : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
	struct FGameFeaturePluginStateMachineProperties StateProperties; // 0x48(0x70)
	uint8_t Pad_0xB8[0xA0]; // 0xB8(0xA0)
};

// Object: Class GameFeatures.GameFeaturesProjectPolicies
// Size: 0x28 (Inherited: 0x28)
struct UGameFeaturesProjectPolicies : UObject
{
};

// Object: Class GameFeatures.DefaultGameFeaturesProjectPolicies
// Size: 0x28 (Inherited: 0x28)
struct UDefaultGameFeaturesProjectPolicies : UGameFeaturesProjectPolicies
{
};

// Object: Class GameFeatures.GameFeaturesSubsystem
// Size: 0xF0 (Inherited: 0x30)
struct UGameFeaturesSubsystem : UEngineSubsystem
{
	struct TMap<struct FString, struct UGameFeaturePluginStateMachine*> GameFeaturePluginStateMachines; // 0x30(0x50)
	uint8_t Pad_0x80[0x50]; // 0x80(0x50)
	struct TArray<struct UGameFeatureStateChangeObserver*> Observers; // 0xD0(0x10)
	struct UGameFeaturesProjectPolicies* GameSpecificPolicies; // 0xE0(0x8)
	uint8_t Pad_0xE8[0x8]; // 0xE8(0x8)
};

// Object: Class GameFeatures.GameFeaturesSubsystemSettings
// Size: 0x80 (Inherited: 0x38)
struct UGameFeaturesSubsystemSettings : UDeveloperSettings
{
	struct FSoftClassPath GameFeaturesManagerClassName; // 0x38(0x18)
	struct TArray<struct FString> DisabledPlugins; // 0x50(0x10)
	struct TArray<struct FString> AdditionalPluginMetadataKeys; // 0x60(0x10)
	struct FString BuiltInGameFeaturePluginsFolder; // 0x70(0x10)
};

// Object: Class GameFeatures.GameFeatureStateChangeObserver
// Size: 0x28 (Inherited: 0x28)
struct UGameFeatureStateChangeObserver : UObject
{
};

