#pragma once

#include <cstdint>

// Object: Enum MovieSceneTracks.MovieScene3DPathSection_Axis
enum class EMovieScene3DPathSection_Axis : uint8_t
{
	X = 0,
	Y = 1,
	Z = 2,
	NEG_X = 3,
	NEG_Y = 4,
	NEG_Z = 5,
	MovieScene3DPathSection_MAX = 6
};

// Object: Enum MovieSceneTracks.EFireEventsAtPosition
enum class EFireEventsAtPosition : uint8_t
{
	AtStartOfEvaluation = 0,
	AtEndOfEvaluation = 1,
	AfterSpawn = 2,
	EFireEventsAtPosition_MAX = 3
};

// Object: Enum MovieSceneTracks.ELevelVisibility
enum class ELevelVisibility : uint8_t
{
	Visible = 0,
	Hidden = 1,
	ELevelVisibility_MAX = 2
};

// Object: Enum MovieSceneTracks.EParticleKey
enum class EParticleKey : uint8_t
{
	Activate = 0,
	Deactivate = 1,
	Trigger = 2,
	EParticleKey_MAX = 3
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DAttachSectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieScene3DAttachSectionTemplate : FMovieSceneEvalTemplate
{
	struct FGuid AttachGuid; // 0x18(0x10)
	struct FName AttachSocketName; // 0x28(0x8)
	struct FName AttachComponentName; // 0x30(0x8)
	uint8_t AttachmentLocationRule; // 0x38(0x1)
	uint8_t AttachmentRotationRule; // 0x39(0x1)
	uint8_t AttachmentScaleRule; // 0x3A(0x1)
	uint8_t DetachmentLocationRule; // 0x3B(0x1)
	uint8_t DetachmentRotationRule; // 0x3C(0x1)
	uint8_t DetachmentScaleRule; // 0x3D(0x1)
	uint8_t Pad_0x3E[0x2]; // 0x3E(0x2)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DPathSectionTemplate
// Size: 0xA0 (Inherited: 0x18)
struct FMovieScene3DPathSectionTemplate : FMovieSceneEvalTemplate
{
	struct FGuid PathGuid; // 0x18(0x10)
	struct FRichCurve TimingCurve; // 0x28(0x70)
	uint8_t FrontAxisEnum; // 0x98(0x1)
	uint8_t UpAxisEnum; // 0x99(0x1)
	uint8_t bFollow : 1; // 0x9A(0x1), Mask(0x1)
	uint8_t bReverse : 1; // 0x9A(0x1), Mask(0x2)
	uint8_t bForceUpright : 1; // 0x9A(0x1), Mask(0x4)
	uint8_t bUseConstantVelocity : 1; // 0x9A(0x1), Mask(0x8)
	uint8_t BitPad_0x9A_4 : 4; // 0x9A(0x1)
	uint8_t Pad_0x9B[0x5]; // 0x9B(0x5)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneTransformMask
// Size: 0x4 (Inherited: 0x0)
struct FMovieSceneTransformMask
{
	uint32_t Mask; // 0x0(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DTransformKeyStruct
// Size: 0x78 (Inherited: 0x8)
struct FMovieScene3DTransformKeyStruct : FMovieSceneKeyStruct
{
	struct FVector Location; // 0x8(0xC)
	struct FRotator Rotation; // 0x14(0xC)
	struct FVector Scale; // 0x20(0xC)
	float Time; // 0x2C(0x4)
	uint8_t Pad_0x30[0x48]; // 0x30(0x48)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DScaleKeyStruct
// Size: 0x30 (Inherited: 0x8)
struct FMovieScene3DScaleKeyStruct : FMovieSceneKeyStruct
{
	struct FVector Scale; // 0x8(0xC)
	float Time; // 0x14(0x4)
	uint8_t Pad_0x18[0x18]; // 0x18(0x18)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DRotationKeyStruct
// Size: 0x30 (Inherited: 0x8)
struct FMovieScene3DRotationKeyStruct : FMovieSceneKeyStruct
{
	struct FRotator Rotation; // 0x8(0xC)
	float Time; // 0x14(0x4)
	uint8_t Pad_0x18[0x18]; // 0x18(0x18)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DLocationKeyStruct
// Size: 0x30 (Inherited: 0x8)
struct FMovieScene3DLocationKeyStruct : FMovieSceneKeyStruct
{
	struct FVector Location; // 0x8(0xC)
	float Time; // 0x14(0x4)
	uint8_t Pad_0x18[0x18]; // 0x18(0x18)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneComponentTransformSectionTemplate
// Size: 0x488 (Inherited: 0x18)
struct FMovieSceneComponentTransformSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieScene3DTransformTemplateData TemplateData; // 0x18(0x470)
};

// Object: ScriptStruct MovieSceneTracks.MovieScene3DTransformTemplateData
// Size: 0x470 (Inherited: 0x0)
struct FMovieScene3DTransformTemplateData
{
	struct FRichCurve TranslationCurve[0x3]; // 0x0(0x150)
	struct FRichCurve RotationCurve[0x3]; // 0x150(0x150)
	struct FRichCurve ScaleCurve[0x3]; // 0x2A0(0x150)
	struct FRichCurve ManualWeight; // 0x3F0(0x70)
	uint8_t BlendType; // 0x460(0x1)
	uint8_t Pad_0x461[0x3]; // 0x461(0x3)
	struct FMovieSceneTransformMask Mask; // 0x464(0x4)
	bool bIgnoreGlobalTransform; // 0x468(0x1)
	uint8_t Pad_0x469[0x7]; // 0x469(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneActorReferenceSectionTemplate
// Size: 0xC0 (Inherited: 0x18)
struct FMovieSceneActorReferenceSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
	struct FIntegralCurve ActorGuidIndexCurve; // 0x40(0x70)
	struct TArray<struct FGuid> ActorGuids; // 0xB0(0x10)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneAudioSectionTemplate
// Size: 0x158 (Inherited: 0x18)
struct FMovieSceneAudioSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieSceneAudioSectionTemplateData AudioData; // 0x18(0x140)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneAudioSectionTemplateData
// Size: 0x140 (Inherited: 0x0)
struct FMovieSceneAudioSectionTemplateData
{
	struct USoundBase* Sound; // 0x0(0x8)
	float AudioStartOffset; // 0x8(0x4)
	struct FFloatRange AudioRange; // 0xC(0x10)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FRichCurve AudioPitchMultiplierCurve; // 0x20(0x70)
	struct FRichCurve AudioVolumeCurve; // 0x90(0x70)
	int RowIndex; // 0x100(0x4)
	bool bOverrideAttenuation; // 0x104(0x1)
	uint8_t Pad_0x105[0x3]; // 0x105(0x3)
	struct USoundAttenuation* AttenuationSettings; // 0x108(0x8)
	DelegateProperty OnQueueSubtitles; // 0x110(0x10)
	struct FScriptMulticastDelegate OnAudioFinished; // 0x120(0x10)
	struct FScriptMulticastDelegate OnAudioPlaybackPercent; // 0x130(0x10)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionData
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneCameraAnimSectionData
{
	struct UCameraAnim* CameraAnim; // 0x0(0x8)
	float PlayRate; // 0x8(0x4)
	float PlayScale; // 0xC(0x4)
	float BlendInTime; // 0x10(0x4)
	float BlendOutTime; // 0x14(0x4)
	bool bLooping; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneAdditiveCameraAnimationTrackTemplate
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneAdditiveCameraAnimationTrackTemplate : FMovieSceneEvalTemplate
{
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneAdditiveCameraAnimationTemplate
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneAdditiveCameraAnimationTemplate : FMovieSceneEvalTemplate
{
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieSceneCameraShakeSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate
{
	struct FMovieSceneCameraShakeSectionData SourceData; // 0x18(0x20)
	float SectionStartTime; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionData
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneCameraShakeSectionData
{
	struct UCameraShake* ShakeClass; // 0x0(0x8)
	float PlayScale; // 0x8(0x4)
	enum class ECameraAnimPlaySpace PlaySpace; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	struct FRotator UserDefinedPlaySpace; // 0x10(0xC)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieSceneCameraAnimSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate
{
	struct FMovieSceneCameraAnimSectionData SourceData; // 0x18(0x20)
	float SectionStartTime; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneCameraCutSectionTemplate
// Size: 0x70 (Inherited: 0x18)
struct FMovieSceneCameraCutSectionTemplate : FMovieSceneEvalTemplate
{
	struct FGuid CameraGuid; // 0x18(0x10)
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FTransform CutTransform; // 0x30(0x30)
	bool bHasCutTransform; // 0x60(0x1)
	uint8_t Pad_0x61[0xF]; // 0x61(0xF)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneColorKeyStruct
// Size: 0x60 (Inherited: 0x8)
struct FMovieSceneColorKeyStruct : FMovieSceneKeyStruct
{
	struct FLinearColor Color; // 0x8(0x10)
	float Time; // 0x18(0x4)
	uint8_t Pad_0x1C[0x44]; // 0x1C(0x44)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneColorSectionTemplate
// Size: 0x208 (Inherited: 0x40)
struct FMovieSceneColorSectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve Curves[0x4]; // 0x40(0x1C0)
	uint8_t BlendType; // 0x200(0x1)
	uint8_t Pad_0x201[0x7]; // 0x201(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneEventSectionData
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneEventSectionData
{
	struct TArray<float> KeyTimes; // 0x0(0x10)
	struct TArray<struct FEventPayload> KeyValues; // 0x10(0x10)
};

// Object: ScriptStruct MovieSceneTracks.EventPayload
// Size: 0x30 (Inherited: 0x0)
struct FEventPayload
{
	struct FName EventName; // 0x0(0x8)
	struct FMovieSceneEventParameters Parameters; // 0x8(0x28)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneEventParameters
// Size: 0x28 (Inherited: 0x0)
struct FMovieSceneEventParameters
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneEventSectionTemplate
// Size: 0x50 (Inherited: 0x18)
struct FMovieSceneEventSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieSceneEventSectionData EventData; // 0x18(0x20)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x38(0x10)
	uint8_t bFireEventsWhenForwards : 1; // 0x48(0x1), Mask(0x1)
	uint8_t bFireEventsWhenBackwards : 1; // 0x48(0x1), Mask(0x2)
	uint8_t BitPad_0x48_2 : 6; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneFadeSectionTemplate
// Size: 0xA0 (Inherited: 0x18)
struct FMovieSceneFadeSectionTemplate : FMovieSceneEvalTemplate
{
	struct FRichCurve FadeCurve; // 0x18(0x70)
	struct FLinearColor FadeColor; // 0x88(0x10)
	uint8_t bFadeAudio : 1; // 0x98(0x1), Mask(0x1)
	uint8_t BitPad_0x98_1 : 7; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneLevelVisibilitySectionTemplate
// Size: 0x30 (Inherited: 0x18)
struct FMovieSceneLevelVisibilitySectionTemplate : FMovieSceneEvalTemplate
{
	uint8_t Visibility; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
	struct TArray<struct FName> LevelNames; // 0x20(0x10)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneParameterSectionTemplate
// Size: 0x48 (Inherited: 0x18)
struct FMovieSceneParameterSectionTemplate : FMovieSceneEvalTemplate
{
	struct TArray<struct FScalarParameterNameAndCurve> Scalars; // 0x18(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> Vectors; // 0x28(0x10)
	struct TArray<struct FColorParameterNameAndCurves> Colors; // 0x38(0x10)
};

// Object: ScriptStruct MovieSceneTracks.ColorParameterNameAndCurves
// Size: 0x1D0 (Inherited: 0x0)
struct FColorParameterNameAndCurves
{
	struct FName ParameterName; // 0x0(0x8)
	int Index; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FRichCurve RedCurve; // 0x10(0x70)
	struct FRichCurve GreenCurve; // 0x80(0x70)
	struct FRichCurve BlueCurve; // 0xF0(0x70)
	struct FRichCurve AlphaCurve; // 0x160(0x70)
};

// Object: ScriptStruct MovieSceneTracks.VectorParameterNameAndCurves
// Size: 0x160 (Inherited: 0x0)
struct FVectorParameterNameAndCurves
{
	struct FName ParameterName; // 0x0(0x8)
	int Index; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FRichCurve XCurve; // 0x10(0x70)
	struct FRichCurve YCurve; // 0x80(0x70)
	struct FRichCurve ZCurve; // 0xF0(0x70)
};

// Object: ScriptStruct MovieSceneTracks.ScalarParameterNameAndCurve
// Size: 0x80 (Inherited: 0x0)
struct FScalarParameterNameAndCurve
{
	struct FName ParameterName; // 0x0(0x8)
	int Index; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FRichCurve ParameterCurve; // 0x10(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneMaterialParameterCollectionTemplate
// Size: 0x50 (Inherited: 0x48)
struct FMovieSceneMaterialParameterCollectionTemplate : FMovieSceneParameterSectionTemplate
{
	struct UMaterialParameterCollection* MPC; // 0x48(0x8)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneComponentMaterialSectionTemplate
// Size: 0x50 (Inherited: 0x48)
struct FMovieSceneComponentMaterialSectionTemplate : FMovieSceneParameterSectionTemplate
{
	int MaterialIndex; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneParticleParameterSectionTemplate
// Size: 0x48 (Inherited: 0x48)
struct FMovieSceneParticleParameterSectionTemplate : FMovieSceneParameterSectionTemplate
{
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneParticleSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneParticleSectionTemplate : FMovieSceneEvalTemplate
{
	struct FIntegralCurve ParticleKeys; // 0x18(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieScenePrimitiveMaterialTemplate
// Size: 0x98 (Inherited: 0x18)
struct FMovieScenePrimitiveMaterialTemplate : FMovieSceneEvalTemplate
{
	int MaterialIndex; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FStringCurve BoolCurve; // 0x20(0x78)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneTransformPropertySectionTemplate
// Size: 0x4B0 (Inherited: 0x40)
struct FMovieSceneTransformPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FMovieScene3DTransformTemplateData TemplateData; // 0x40(0x470)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVectorPropertySectionTemplate
// Size: 0x208 (Inherited: 0x40)
struct FMovieSceneVectorPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve ComponentCurves[0x4]; // 0x40(0x1C0)
	int NumChannelsUsed; // 0x200(0x4)
	uint8_t BlendType; // 0x204(0x1)
	uint8_t Pad_0x205[0x3]; // 0x205(0x3)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneStringPropertySectionTemplate
// Size: 0xB8 (Inherited: 0x40)
struct FMovieSceneStringPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FStringCurve StringCurve; // 0x40(0x78)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneIntegerPropertySectionTemplate
// Size: 0xB8 (Inherited: 0x40)
struct FMovieSceneIntegerPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FIntegralCurve IntegerCurve; // 0x40(0x70)
	uint8_t BlendType; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneEnumPropertySectionTemplate
// Size: 0xB0 (Inherited: 0x40)
struct FMovieSceneEnumPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FIntegralCurve EnumCurve; // 0x40(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneBytePropertySectionTemplate
// Size: 0xB0 (Inherited: 0x40)
struct FMovieSceneBytePropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FIntegralCurve ByteCurve; // 0x40(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneFloatPropertySectionTemplate
// Size: 0xB8 (Inherited: 0x40)
struct FMovieSceneFloatPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve FloatCurve; // 0x40(0x70)
	uint8_t BlendType; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneBoolPropertySectionTemplate
// Size: 0xB0 (Inherited: 0x40)
struct FMovieSceneBoolPropertySectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FIntegralCurve BoolCurve; // 0x40(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationParams
// Size: 0x90 (Inherited: 0x0)
struct FMovieSceneSkeletalAnimationParams
{
	struct UAnimSequenceBase* Animation; // 0x0(0x8)
	float StartOffset; // 0x8(0x4)
	float EndOffset; // 0xC(0x4)
	float PlayRate; // 0x10(0x4)
	uint8_t bReverse : 1; // 0x14(0x1), Mask(0x1)
	uint8_t BitPad_0x14_1 : 7; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	struct FName SlotName; // 0x18(0x8)
	struct FRichCurve Weight; // 0x20(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplate
// Size: 0xB0 (Inherited: 0x18)
struct FMovieSceneSkeletalAnimationSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieSceneSkeletalAnimationSectionTemplateParameters Params; // 0x18(0x98)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplateParameters
// Size: 0x98 (Inherited: 0x90)
struct FMovieSceneSkeletalAnimationSectionTemplateParameters : FMovieSceneSkeletalAnimationParams
{
	float SectionStartTime; // 0x90(0x4)
	float SectionEndTime; // 0x94(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneSlomoSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneSlomoSectionTemplate : FMovieSceneEvalTemplate
{
	struct FRichCurve SlomoCurve; // 0x18(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneSpawnSectionTemplate
// Size: 0x88 (Inherited: 0x18)
struct FMovieSceneSpawnSectionTemplate : FMovieSceneEvalTemplate
{
	struct FIntegralCurve Curve; // 0x18(0x70)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStructBase
// Size: 0x50 (Inherited: 0x8)
struct FMovieSceneVectorKeyStructBase : FMovieSceneKeyStruct
{
	uint8_t Pad_0x8[0x40]; // 0x8(0x40)
	float Time; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVector4KeyStruct
// Size: 0x60 (Inherited: 0x50)
struct FMovieSceneVector4KeyStruct : FMovieSceneVectorKeyStructBase
{
	struct FVector4 Vector; // 0x50(0x10)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStruct
// Size: 0x58 (Inherited: 0x50)
struct FMovieSceneVectorKeyStruct : FMovieSceneVectorKeyStructBase
{
	struct FVector Vector; // 0x4C(0xC)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVector2DKeyStruct
// Size: 0x58 (Inherited: 0x50)
struct FMovieSceneVector2DKeyStruct : FMovieSceneVectorKeyStructBase
{
	struct FVector2D Vector; // 0x4C(0x8)
};

// Object: ScriptStruct MovieSceneTracks.MovieSceneVisibilitySectionTemplate
// Size: 0xB8 (Inherited: 0xB0)
struct FMovieSceneVisibilitySectionTemplate : FMovieSceneBoolPropertySectionTemplate
{
	bool bTemporarilyHiddenInGame; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
};

// Object: Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0x80 (Inherited: 0x58)
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack
{
	struct FName PropertyName; // 0x58(0x8)
	struct FString PropertyPath; // 0x60(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x70(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0x28 (Inherited: 0x28)
struct IMovieSceneTransformOrigin : IInterface
{

	// Object: Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin
	// Flags: [Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x30) ]
	struct FTransform BP_GetTransformOrigin();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0xC0 (Inherited: 0xB0)
struct UMovieScene3DConstraintSection : UMovieSceneSection
{
	struct FGuid ConstraintId; // 0xB0(0x10)
};

// Object: Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0xD8 (Inherited: 0xC0)
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection
{
	struct FName AttachSocketName; // 0xC0(0x8)
	struct FName AttachComponentName; // 0xC8(0x8)
	uint8_t AttachmentLocationRule; // 0xD0(0x1)
	uint8_t AttachmentRotationRule; // 0xD1(0x1)
	uint8_t AttachmentScaleRule; // 0xD2(0x1)
	uint8_t DetachmentLocationRule; // 0xD3(0x1)
	uint8_t DetachmentRotationRule; // 0xD4(0x1)
	uint8_t DetachmentScaleRule; // 0xD5(0x1)
	uint8_t Pad_0xD6[0x2]; // 0xD6(0x2)
};

// Object: Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieScene3DConstraintTrack : UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack
{
};

// Object: Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x138 (Inherited: 0xC0)
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection
{
	struct FRichCurve TimingCurve; // 0xC0(0x70)
	uint8_t FrontAxisEnum; // 0x130(0x1)
	uint8_t UpAxisEnum; // 0x131(0x1)
	uint8_t bFollow : 1; // 0x132(0x1), Mask(0x1)
	uint8_t bReverse : 1; // 0x132(0x1), Mask(0x2)
	uint8_t bForceUpright : 1; // 0x132(0x1), Mask(0x4)
	uint8_t BitPad_0x132_3 : 5; // 0x132(0x1)
	bool bUseConstantVelocity; // 0x133(0x1)
	uint8_t Pad_0x134[0x4]; // 0x134(0x4)
};

// Object: Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack
{
};

// Object: Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0x528 (Inherited: 0xB0)
struct UMovieScene3DTransformSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FMovieSceneTransformMask TransformMask; // 0xB8(0x4)
	uint8_t Pad_0xBC[0x4]; // 0xBC(0x4)
	struct FRichCurve Translation[0x3]; // 0xC0(0x150)
	struct FRichCurve Rotation[0x3]; // 0x210(0x150)
	struct FRichCurve Scale[0x3]; // 0x360(0x150)
	struct FRichCurve ManualWeight; // 0x4B0(0x70)
	bool bIgnoreGlobalTransform; // 0x520(0x1)
	uint8_t Pad_0x521[0x7]; // 0x521(0x7)
};

// Object: Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x148 (Inherited: 0xB0)
struct UMovieSceneActorReferenceSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FIntegralCurve ActorGuidIndexCurve; // 0xB8(0x70)
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
	struct TArray<struct FString> ActorGuidStrings; // 0x138(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x1E8 (Inherited: 0xB0)
struct UMovieSceneAudioSection : UMovieSceneSection
{
	struct USoundBase* Sound; // 0xB0(0x8)
	float StartOffset; // 0xB8(0x4)
	float AudioStartTime; // 0xBC(0x4)
	float AudioDilationFactor; // 0xC0(0x4)
	float AudioVolume; // 0xC4(0x4)
	struct FRichCurve SoundVolume; // 0xC8(0x70)
	struct FRichCurve PitchMultiplier; // 0x138(0x70)
	bool bSuppressSubtitles; // 0x1A8(0x1)
	bool bOverrideAttenuation; // 0x1A9(0x1)
	uint8_t Pad_0x1AA[0x6]; // 0x1AA(0x6)
	struct USoundAttenuation* AttenuationSettings; // 0x1B0(0x8)
	DelegateProperty OnQueueSubtitles; // 0x1B8(0x10)
	struct FScriptMulticastDelegate OnAudioFinished; // 0x1C8(0x10)
	struct FScriptMulticastDelegate OnAudioPlaybackPercent; // 0x1D8(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> AudioSections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneBoolSection
// Size: 0x130 (Inherited: 0xB0)
struct UMovieSceneBoolSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	bool DefaultValue; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x7]; // 0xB9(0x7)
	struct FIntegralCurve BoolCurve; // 0xC0(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x128 (Inherited: 0xB0)
struct UMovieSceneByteSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FIntegralCurve ByteCurve; // 0xB8(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x88 (Inherited: 0x80)
struct UMovieSceneByteTrack : UMovieScenePropertyTrack
{
	struct UEnum* Enum; // 0x80(0x8)
};

// Object: Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0xF0 (Inherited: 0xB0)
struct UMovieSceneCameraAnimSection : UMovieSceneSection
{
	struct FMovieSceneCameraAnimSectionData AnimData; // 0xB0(0x20)
	struct UCameraAnim* CameraAnim; // 0xD0(0x8)
	float PlayRate; // 0xD8(0x4)
	float PlayScale; // 0xDC(0x4)
	float BlendInTime; // 0xE0(0x4)
	float BlendOutTime; // 0xE4(0x4)
	bool bLooping; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
};

// Object: Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneCameraAnimTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> CameraAnimSections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0xC0 (Inherited: 0xB0)
struct UMovieSceneCameraCutSection : UMovieSceneSection
{
	struct FGuid CameraGuid; // 0xB0(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0xF0 (Inherited: 0xB0)
struct UMovieSceneCameraShakeSection : UMovieSceneSection
{
	struct FMovieSceneCameraShakeSectionData ShakeData; // 0xB0(0x20)
	struct UCameraShake* ShakeClass; // 0xD0(0x8)
	float PlayScale; // 0xD8(0x4)
	enum class ECameraAnimPlaySpace PlaySpace; // 0xDC(0x1)
	uint8_t Pad_0xDD[0x3]; // 0xDD(0x3)
	struct FRotator UserDefinedPlaySpace; // 0xE0(0xC)
	uint8_t Pad_0xEC[0x4]; // 0xEC(0x4)
};

// Object: Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneSubSection
// Size: 0x118 (Inherited: 0xB0)
struct UMovieSceneSubSection : UMovieSceneSection
{
	struct FMovieSceneSectionParameters Parameters; // 0xB0(0x14)
	float StartOffset; // 0xC4(0x4)
	float TimeScale; // 0xC8(0x4)
	float PrerollTime; // 0xCC(0x4)
	struct UMovieSceneSequence* SubSequence; // 0xD0(0x8)
	struct TLazyObjectPtr<struct AActor> ActorToRecord; // 0xD8(0x1C)
	uint8_t Pad_0xF4[0x4]; // 0xF4(0x4)
	struct FString TargetSequenceName; // 0xF8(0x10)
	struct FDirectoryPath TargetPathToRecordTo; // 0x108(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x130 (Inherited: 0x118)
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection
{
	struct FText DisplayName; // 0x118(0x18)
};

// Object: Class MovieSceneTracks.MovieSceneSubTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneSubTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x278 (Inherited: 0xB0)
struct UMovieSceneColorSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve RedCurve; // 0xB8(0x70)
	struct FRichCurve GreenCurve; // 0x128(0x70)
	struct FRichCurve BlueCurve; // 0x198(0x70)
	struct FRichCurve AlphaCurve; // 0x208(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x88 (Inherited: 0x80)
struct UMovieSceneColorTrack : UMovieScenePropertyTrack
{
	bool bIsSlateColor; // 0x80(0x1)
	uint8_t Pad_0x81[0x7]; // 0x81(0x7)
};

// Object: Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x128 (Inherited: 0xB0)
struct UMovieSceneEnumSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FIntegralCurve EnumCurve; // 0xB8(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x88 (Inherited: 0x80)
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack
{
	struct UEnum* Enum; // 0x80(0x8)
};

// Object: Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x1C0 (Inherited: 0xB0)
struct UMovieSceneEventSection : UMovieSceneSection
{
	struct FNameCurve Events; // 0xB0(0x68)
	struct FMovieSceneEventSectionData EventData; // 0x118(0x20)
	uint8_t Pad_0x138[0x88]; // 0x138(0x88)
};

// Object: Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0x78 (Inherited: 0x58)
struct UMovieSceneEventTrack : UMovieSceneNameableTrack
{
	uint8_t bFireEventsWhenForwards : 1; // 0x55(0x1), Mask(0x1)
	uint8_t bFireEventsWhenBackwards : 1; // 0x55(0x1), Mask(0x2)
	uint8_t EventPosition; // 0x56(0x1)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x58(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x68(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x128 (Inherited: 0xB0)
struct UMovieSceneFloatSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve FloatCurve; // 0xB8(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x140 (Inherited: 0x128)
struct UMovieSceneFadeSection : UMovieSceneFloatSection
{
	struct FLinearColor FadeColor; // 0x128(0x10)
	uint8_t bFadeAudio : 1; // 0x138(0x1), Mask(0x1)
	uint8_t BitPad_0x138_1 : 7; // 0x138(0x1)
	uint8_t Pad_0x139[0x7]; // 0x139(0x7)
};

// Object: Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x128 (Inherited: 0xB0)
struct UMovieSceneIntegerSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FIntegralCurve IntegerCurve; // 0xB8(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0xC0 (Inherited: 0xB0)
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection
{
	uint8_t Visibility; // 0xAE(0x1)
	struct TArray<struct FName> LevelNames; // 0xB0(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0x70 (Inherited: 0x68)
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack
{
	struct UMaterialParameterCollection* MPC; // 0x68(0x8)
};

// Object: Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0x70 (Inherited: 0x68)
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack
{
	int MaterialIndex; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

// Object: Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0xE0 (Inherited: 0xB0)
struct UMovieSceneParameterSection : UMovieSceneSection
{
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // 0xB0(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // 0xC0(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // 0xD0(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x120 (Inherited: 0xB0)
struct UMovieSceneParticleSection : UMovieSceneSection
{
	struct FIntegralCurve ParticleKeys; // 0xB0(0x70)
};

// Object: Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> ParticleSections; // 0x58(0x10)
};

// Object: Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0x88 (Inherited: 0x80)
struct UMovieScenePrimitiveMaterialTrack : UMovieScenePropertyTrack
{
	int MaterialIndex; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
};

// Object: Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x168 (Inherited: 0xB0)
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection
{
	struct FMovieSceneSkeletalAnimationParams Params; // 0xB0(0x90)
	struct UAnimSequence* AnimSequence; // 0x140(0x8)
	struct UAnimSequenceBase* Animation; // 0x148(0x8)
	float StartOffset; // 0x150(0x4)
	float EndOffset; // 0x154(0x4)
	float PlayRate; // 0x158(0x4)
	uint8_t bReverse : 1; // 0x15C(0x1), Mask(0x1)
	uint8_t BitPad_0x15C_1 : 7; // 0x15C(0x1)
	uint8_t Pad_0x15D[0x3]; // 0x15D(0x3)
	struct FName SlotName; // 0x160(0x8)
};

// Object: Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0x58(0x10)
	bool bUseLegacySectionIndexBlend; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
};

// Object: Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x128 (Inherited: 0x128)
struct UMovieSceneSlomoSection : UMovieSceneFloatSection
{
};

// Object: Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneSpawnSection
// Size: 0x130 (Inherited: 0x130)
struct UMovieSceneSpawnSection : UMovieSceneBoolSection
{
};

// Object: Class MovieSceneTracks.MovieSceneSpawnTrack
// Size: 0x78 (Inherited: 0x58)
struct UMovieSceneSpawnTrack : UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
	struct FGuid ObjectGuid; // 0x68(0x10)
};

// Object: Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x130 (Inherited: 0xB0)
struct UMovieSceneStringSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FStringCurve StringCurve; // 0xB8(0x78)
};

// Object: Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneStringTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack
{
};

// Object: Class MovieSceneTracks.MovieSceneVectorSection
// Size: 0x280 (Inherited: 0xB0)
struct UMovieSceneVectorSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve Curves[0x4]; // 0xB8(0x1C0)
	int ChannelsUsed; // 0x278(0x4)
	uint8_t Pad_0x27C[0x4]; // 0x27C(0x4)
};

// Object: Class MovieSceneTracks.MovieSceneVectorTrack
// Size: 0x88 (Inherited: 0x80)
struct UMovieSceneVectorTrack : UMovieScenePropertyTrack
{
	int NumChannelsUsed; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
};

// Object: Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack
{
};

