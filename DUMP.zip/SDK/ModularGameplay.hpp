#pragma once

#include <cstdint>

// Object: Class ModularGameplay.GameFrameworkComponent
// Size: 0x178 (Inherited: 0x178)
struct UGameFrameworkComponent : UActorComponent
{
};

// Object: Class ModularGameplay.ControllerComponent
// Size: 0x178 (Inherited: 0x178)
struct UControllerComponent : UGameFrameworkComponent
{
};

// Object: Class ModularGameplay.GameFrameworkComponentManager
// Size: 0x120 (Inherited: 0x30)
struct UGameFrameworkComponentManager : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0xF0]; // 0x30(0xF0)


	// Object: Function ModularGameplay.GameFrameworkComponentManager.RemoveReceiver
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10270f734
	// Params: [ Num(1) Size(0x8) ]
	void RemoveReceiver(struct AActor* Receiver);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10270BAAC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870

	// Object: Function ModularGameplay.GameFrameworkComponentManager.AddReceiver
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10270f674
	// Params: [ Num(2) Size(0x9) ]
	void AddReceiver(struct AActor* Receiver, bool bAddOnlyInGameWorlds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10270B780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10270BAAC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class ModularGameplay.GameStateComponent
// Size: 0x178 (Inherited: 0x178)
struct UGameStateComponent : UGameFrameworkComponent
{
};

// Object: Class ModularGameplay.PawnComponent
// Size: 0x178 (Inherited: 0x178)
struct UPawnComponent : UGameFrameworkComponent
{
};

// Object: Class ModularGameplay.PlayerStateComponent
// Size: 0x178 (Inherited: 0x178)
struct UPlayerStateComponent : UGameFrameworkComponent
{
};

