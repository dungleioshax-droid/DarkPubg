#pragma once

#include <cstdint>

// Object: Enum BlockyLuaCore.EBlockyToolButtonType
enum class EBlockyToolButtonType : uint16_t
{
	BTBT_None = 0,
	BTBT_Copy = 1,
	BTBT_Eject = 2,
	BTBT_Comment = 4,
	BTBT_Paste = 8,
	BTBT_Disable = 16,
	BTBT_Delete = 32,
	BTBT_Define = 64,
	BTBT_Quote = 128,
	BTBT_Explain = 256,
	BTBT_Clone = 512,
	BTBT_GlobalComment = 1024,
	BTBT_MAX = 1025
};

// Object: Enum BlockyLuaCore.EBlockyLogMsgMode
enum class EBlockyLogMsgMode : uint8_t
{
	Error = 0,
	Warn = 1,
	Info = 2,
	EBlockyLogMsgMode_MAX = 3
};

// Object: Enum BlockyLuaCore.EVectorArithmeticOperationType
enum class EVectorArithmeticOperationType : uint8_t
{
	EVOT_Addition = 0,
	EVOT_Subtraction = 1,
	EVOT_Multiplication = 2,
	EVOT_Division = 3,
	EVOT_MAX = 4
};

// Object: Enum BlockyLuaCore.EIntegerArithmeticOperationType
enum class EIntegerArithmeticOperationType : uint8_t
{
	EIOT_None = 0,
	EIOT_Addition = 1,
	EIOT_Subtraction = 2,
	EIOT_Multiplication = 3,
	EIOT_Division = 4,
	EIOT_Remainder = 5,
	EIOT_Exponentiation = 6,
	EIOT_MAX = 7
};

// Object: Enum BlockyLuaCore.EArithmeticOperationType
enum class EArithmeticOperationType : uint8_t
{
	EOT_None = 0,
	EOT_Addition = 1,
	EOT_Subtraction = 2,
	EOT_Multiplication = 3,
	EOT_Division = 4,
	EOT_ExactDivision = 5,
	EOT_Remainder = 6,
	EOT_Exponentiation = 7,
	EOT_MAX = 8
};

// Object: Enum BlockyLuaCore.EBlockyBinaryOperation
enum class EBlockyBinaryOperation : uint8_t
{
	EBBO_Add = 0,
	EBBO_Subtract = 1,
	EBBO_Multiply = 2,
	EBBO_Divide = 3,
	EBBO_Modulus = 4,
	EBBO_Inequality = 5,
	EBBO_Equality = 6,
	EBBO_BitwiseOr = 7,
	EBBO_BitwiseAnd = 8,
	EBBO_BitwiseLeftShift = 9,
	EBBO_BitwiseRightShift = 10,
	EBBO_BooleanOr = 11,
	EBBO_BooleanAnd = 12,
	EBBO_LessThan = 13,
	EBBO_LessThanOrEqual = 14,
	EBBO_GreaterThan = 15,
	EBBO_GreaterThanOrEqual = 16,
	EBBO_Remainder = 17,
	EBBO_Exponentiation = 18,
	EBBO_ExactDivision = 19,
	EBBO_MAX = 20
};

// Object: Enum BlockyLuaCore.ESlotClickType
enum class ESlotClickType : uint16_t
{
	Default = 0,
	MenuItems = 1,
	InputWithType = 2,
	CustomSelection = 4,
	InputEnumWithIcon = 8,
	InputBoolean = 16,
	Variables = 32,
	Preset = 64,
	TypeFilter = 128,
	TypeString = 256,
	CustomVar = 512,
	All = 4095,
	ESlotClickType_MAX = 4096
};

// Object: Enum BlockyLuaCore.EBlockyValueType
enum class EBlockyValueType : uint8_t
{
	BVT_Boolean = 0,
	BVT_String = 1,
	BVT_Int8 = 2,
	BVT_UInt8 = 3,
	BVT_Int16 = 4,
	BVT_UInt16 = 5,
	BVT_Int32 = 6,
	BVT_UInt32 = 7,
	BVT_Int64 = 8,
	BVT_UInt64 = 9,
	BVT_Float = 10,
	BVT_Double = 11,
	BVT_MAX = 12
};

// Object: Enum BlockyLuaCore.EBlockyVisitMode
enum class EBlockyVisitMode : uint8_t
{
	BVM_Public = 0,
	BVM_Protected = 1,
	BVM_Private = 2,
	BVM_Local = 3,
	BVM_MAX = 4
};

// Object: Enum BlockyLuaCore.EBlockyVariableType
enum class EBlockyVariableType : uint8_t
{
	Var_BLIT_None = 0,
	Var_BLIT_DefineFunc = 1,
	Var_BLIT_Executeable = 2,
	Var_BLIT_Bool = 3,
	Var_BLIT_Int = 4,
	Var_BLIT_Float = 5,
	Var_BLIT_String = 6,
	Var_BLIT_Array = 7,
	Var_BLIT_Class = 8,
	Var_BLIT_CodeType = 9,
	Var_BLIT_Enum = 10,
	Var_BLIT_UInt = 11,
	Var_BLIT_Vector = 12,
	Var_BLIT_Rotator = 13,
	Var_BLIT_Color = 14,
	Var_BLIT_Integer = 15,
	Var_BLIT_Number = 16,
	Var_BLIT_Map = 17,
	Var_BLIT_PODType = 18,
	Var_BLIT_ToStringAll = 19,
	Var_BLIT_ArrayElementAll = 20,
	Var_BLIT_ArrayAll = 21,
	Var_BLIT_ALL = 22,
	Var_BLIT_MAX = 23
};

// Object: Enum BlockyLuaCore.EBlockyListItemType
enum class EBlockyListItemType : uint8_t
{
	BLIT_None = 0,
	BLIT_DefineFunc = 1,
	BLIT_Executeable = 2,
	BLIT_Bool = 3,
	BLIT_Int = 4,
	BLIT_Float = 5,
	BLIT_String = 6,
	BLIT_Array = 7,
	BLIT_Class = 8,
	BLIT_CodeType = 9,
	BLIT_Enum = 10,
	BLIT_UInt = 11,
	BLIT_Vector = 12,
	BLIT_Rotator = 13,
	BLIT_Color = 14,
	BLIT_Map = 15,
	BLIT_Integer = 16,
	BLIT_Number = 17,
	BLIT_PODType = 18,
	BLIT_ToStringAll = 19,
	BLIT_ArrayElementAll = 20,
	BLIT_ArrayAll = 21,
	BLIT_ALL = 22,
	BLIT_MAX = 23
};

// Object: Enum BlockyLuaCore.EBlockyBPToolButtonType
enum class EBlockyBPToolButtonType : uint8_t
{
	BP_BTBT_None = 0,
	BP_BTBT_Copy = 1,
	BP_BTBT_Eject = 2,
	BP_BTBT_Comment = 3,
	BP_BTBT_Paste = 4,
	BP_BTBT_Disable = 5,
	BP_BTBT_Delete = 6,
	BP_BTBT_Define = 7,
	BP_BTBT_Quote = 8,
	BP_BTBT_Explain = 9,
	BP_BTBT_Clone = 10,
	BP_BTBT_GlobalComment = 11,
	BP_BTBT_MAX = 12
};

// Object: Enum BlockyLuaCore.EBlockyBlockTypeGroup
enum class EBlockyBlockTypeGroup : uint8_t
{
	BBTG_Event = 0,
	BBTG_Action = 1,
	BBTG_Logic = 2,
	BBTG_Value = 3,
	BBTG_Undefine = 4,
	BBTG_Custom = 5,
	BBTG_Max = 6
};

// Object: Enum BlockyLuaCore.EBlockyCurrentGraphBlockyNumberType
enum class EBlockyCurrentGraphBlockyNumberType : uint8_t
{
	BCGBN_Total = 0,
	BCGBN_TotalEvent = 1,
	BCGBN_TotalAction = 2,
	BCGBN_TotalLogic = 3,
	BCGBN_TotalValue = 4,
	BCGBN_TotalVariable = 5,
	BCGBN_TotalCustomEvent = 6,
	BCGBN_TotalCustomAction = 7,
	BCGBN_TotalCustomValue = 8,
	BCGBN_MaxActionBlocksNumInEvent = 9,
	BCGBN_MaxBlocksNumInCustomEvent = 10,
	BCGBN_MaxBlocksNumInCustomAction = 11,
	BCGBN_MaxBlocksNumInCustomValue = 12,
	BCGBN_MAX = 13
};

// Object: Enum BlockyLuaCore.EBlockyLuaStubArgType
enum class EBlockyLuaStubArgType : uint8_t
{
	BlockyLuaStubArgType_Unknown = 0,
	BlockyLuaStubArgType_IntProperty = 1,
	BlockyLuaStubArgType_UInt32Property = 2,
	BlockyLuaStubArgType_Int64Property = 3,
	BlockyLuaStubArgType_UInt64Property = 4,
	BlockyLuaStubArgType_Int16Property = 5,
	BlockyLuaStubArgType_UInt16Property = 6,
	BlockyLuaStubArgType_Int8Property = 7,
	BlockyLuaStubArgType_ByteProperty = 8,
	BlockyLuaStubArgType_FloatProperty = 9,
	BlockyLuaStubArgType_DoubleProperty = 10,
	BlockyLuaStubArgType_BoolProperty = 11,
	BlockyLuaStubArgType_TextProperty = 12,
	BlockyLuaStubArgType_StrProperty = 13,
	BlockyLuaStubArgType_NameProperty = 14,
	BlockyLuaStubArgType_UObjectProperty = 15,
	BlockyLuaStubArgType_Struct = 16,
	BlockyLuaStubArgType_Handle = 17,
	BlockyLuaStubArgType_MAX = 18
};

// Object: Enum BlockyLuaCore.EBlockListShowType
enum class EBlockListShowType : uint8_t
{
	EBLS_All = 0,
	EBLS_Var = 1,
	EBLS_BlackBoard = 2,
	EBLS_CustomVar = 3,
	EBLS_MAX = 4
};

// Object: Enum BlockyLuaCore.ECustomBlockType
enum class ECustomBlockType : uint8_t
{
	ECBT_Action = 0,
	ECBT_Value = 1,
	ECBT_Event = 2,
	ECBT_MAX = 3
};

// Object: Enum BlockyLuaCore.EBlockyFunctionArgumentAttribute
enum class EBlockyFunctionArgumentAttribute : uint8_t
{
	EBFAA_Default = 0,
	EBFAA_In = 1,
	EBFAA_Out = 2,
	EBFAA_Ref = 3,
	EBFAA_MAX = 4
};

// Object: Enum BlockyLuaCore.ECompareOperationType
enum class ECompareOperationType : uint8_t
{
	EOT_Inequality = 0,
	EOT_Equality = 1,
	EOT_GreaterThan = 2,
	EOT_GreaterThanOrEqual = 3,
	EOT_LessThan = 4,
	EOT_LessThanOrEqual = 5
};

// Object: Enum BlockyLuaCore.EBlockyAccessType
enum class EBlockyAccessType : uint8_t
{
	EBAT_Global = 0,
	EBAT_Canvas = 1,
	EBAT_Local = 2,
	EBAT_CallBack = 3,
	EBAT_MAX = 4
};

// Object: Enum BlockyLuaCore.EBlockyUnaryOperation
enum class EBlockyUnaryOperation : uint8_t
{
	EBUO_Negative = 0,
	EBUO_BooleanNot = 1,
	EBUO_BitwiseNot = 2,
	EBUO_MAX = 3
};

// Object: Enum BlockyLuaCore.EBlockyVarInitType
enum class EBlockyVarInitType : uint8_t
{
	EBVIT_InputWithValue = 0,
	EBVIT_Preset = 1,
	EBVIT_ForbidInitialization = 2,
	EBVIT_CustomSelection = 3,
	EBVIT_MAX = 4
};

// Object: ScriptStruct BlockyLuaCore.CheckStringHandleData
// Size: 0x18 (Inherited: 0x0)
struct FCheckStringHandleData
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct BlockyLuaCore.MessageDataStruct
// Size: 0x28 (Inherited: 0x0)
struct FMessageDataStruct
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
};

// Object: ScriptStruct BlockyLuaCore.GraphSettingMap
// Size: 0x50 (Inherited: 0x0)
struct FGraphSettingMap
{
	struct TMap<struct FString, struct FGraphSetting> graphSettings; // 0x0(0x50)
};

// Object: ScriptStruct BlockyLuaCore.GraphSetting
// Size: 0x18 (Inherited: 0x0)
struct FGraphSetting
{
	bool CanCopy; // 0x0(0x1)
	bool CanReName; // 0x1(0x1)
	bool CanDel; // 0x2(0x1)
	bool CanSave; // 0x3(0x1)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<int> Tags; // 0x8(0x10)
};

// Object: ScriptStruct BlockyLuaCore.Type
// Size: 0x70 (Inherited: 0x0)
struct FType
{
	uint8_t Pad_0x0[0x58]; // 0x0(0x58)
	struct FString TypeName; // 0x58(0x10)
	uint8_t Pad_0x68[0x8]; // 0x68(0x8)
};

// Object: ScriptStruct BlockyLuaCore.BlockyLuaHandle
// Size: 0x8 (Inherited: 0x0)
struct FBlockyLuaHandle
{
	uint32_t Low; // 0x0(0x4)
	uint32_t High; // 0x4(0x4)
};

// Object: ScriptStruct BlockyLuaCore.BlockySlotString
// Size: 0x38 (Inherited: 0x0)
struct FBlockySlotString
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
	struct FString CustomStr; // 0x28(0x10)
};

// Object: ScriptStruct BlockyLuaCore.BlockOutputInfo
// Size: 0x40 (Inherited: 0x0)
struct FBlockOutputInfo
{
	struct TArray<struct FString> Infos; // 0x0(0x10)
	struct UBlockBase* SlotHostBlock; // 0x10(0x8)
	uint8_t Pad_0x18[0x18]; // 0x18(0x18)
	struct UBlockBase* TargetBlock; // 0x30(0x8)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
};

// Object: ScriptStruct BlockyLuaCore.GraphString
// Size: 0x40 (Inherited: 0x0)
struct FGraphString
{
	struct FGuid ID; // 0x0(0x10)
	struct FString Name; // 0x10(0x10)
	struct FString DisplayName; // 0x20(0x10)
	struct FString TemplateName; // 0x30(0x10)
};

// Object: ScriptStruct BlockyLuaCore.CustomConfigString
// Size: 0x28 (Inherited: 0x0)
struct FCustomConfigString
{
	struct FGuid ID; // 0x0(0x10)
	struct FString Name; // 0x10(0x10)
	enum class ECustomBlockType Type; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: ScriptStruct BlockyLuaCore.CustomVariableString
// Size: 0x28 (Inherited: 0x0)
struct FCustomVariableString
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
	struct FString Name; // 0x18(0x10)
};

// Object: ScriptStruct BlockyLuaCore.QuoteData
// Size: 0x28 (Inherited: 0x0)
struct FQuoteData
{
	struct FVector2D pos; // 0x0(0x8)
	struct FString BlockName; // 0x8(0x10)
	struct FString GraphName; // 0x18(0x10)
};

// Object: ScriptStruct BlockyLuaCore.Sequence
// Size: 0x10 (Inherited: 0x0)
struct FSequence
{
	struct TArray<struct FString> SequenceNames; // 0x0(0x10)
};

// Object: ScriptStruct BlockyLuaCore.BlockyBrushInfo
// Size: 0x60 (Inherited: 0x0)
struct FBlockyBrushInfo
{
	struct FString RectName; // 0x0(0x10)
	struct FString TexturePath; // 0x10(0x10)
	float TextureWidth; // 0x20(0x4)
	float TextureHeight; // 0x24(0x4)
	int DrawTypeInt; // 0x28(0x4)
	struct FVector2D StartUV; // 0x2C(0x8)
	struct FVector2D SizeUV; // 0x34(0x8)
	struct FMargin RectMargin; // 0x3C(0x10)
	int CrossDelta; // 0x4C(0x4)
	float RectAngle; // 0x50(0x4)
	struct FVector2D RectSize; // 0x54(0x8)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
};

// Object: ScriptStruct BlockyLuaCore.BlockRect
// Size: 0x10 (Inherited: 0x0)
struct FBlockRect
{
	struct FBlockPoint Position; // 0x0(0x8)
	struct FBlockPoint Size; // 0x8(0x8)
};

// Object: ScriptStruct BlockyLuaCore.BlockPoint
// Size: 0x8 (Inherited: 0x0)
struct FBlockPoint
{
	float X; // 0x0(0x4)
	float Y; // 0x4(0x4)
};

// Object: ScriptStruct BlockyLuaCore.PresetTypeData
// Size: 0x68 (Inherited: 0x0)
struct FPresetTypeData
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
	struct UVarDefiner* VarDefiner; // 0x10(0x8)
	struct TMap<struct FString, struct UPresetDesc*> Presets; // 0x18(0x50)
};

// Object: ScriptStruct BlockyLuaCore.BlockyLuaStub
// Size: 0x80 (Inherited: 0x0)
struct FBlockyLuaStub
{
	struct UObject* OverrideContext; // 0x0(0x8)
	struct UObject* Host; // 0x8(0x8)
	struct FString Name; // 0x10(0x10)
	struct TArray<uint8_t> ArgumentsData; // 0x20(0x10)
	struct TArray<uint8_t> ReturnData; // 0x30(0x10)
	struct TArray<struct FStubType> ArgTypes; // 0x40(0x10)
	struct FStubType ReturnType; // 0x50(0x10)
	uint8_t Pad_0x60[0x20]; // 0x60(0x20)
};

// Object: ScriptStruct BlockyLuaCore.StubType
// Size: 0x10 (Inherited: 0x0)
struct FStubType
{
	uint8_t Type; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UScriptStruct* Struct; // 0x8(0x8)
};

// Object: ScriptStruct BlockyLuaCore.BlockParam
// Size: 0x30 (Inherited: 0x0)
struct FBlockParam
{
	struct FString Name; // 0x0(0x10)
	struct FText DisplayName; // 0x10(0x18)
	bool bIsEnabled; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: ScriptStruct BlockyLuaCore.BlockPreviewBrush
// Size: 0x38 (Inherited: 0x0)
struct FBlockPreviewBrush
{
	struct UBrushData* Brush; // 0x0(0x8)
	struct UBlockBase* InsideHostBlock; // 0x8(0x8)
	uint8_t Pad_0x10[0x28]; // 0x10(0x28)
};

// Object: ScriptStruct BlockyLuaCore.FunctionParameter
// Size: 0xD8 (Inherited: 0x0)
struct FFunctionParameter
{
	struct UObject* BlockType; // 0x0(0x8)
	uint8_t Pad_0x8[0xD0]; // 0x8(0xD0)
};

// Object: ScriptStruct BlockyLuaCore.HotFixSlotHandle
// Size: 0x8 (Inherited: 0x0)
struct FHotFixSlotHandle
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct BlockyLuaCore.MsgData
// Size: 0x60 (Inherited: 0x0)
struct FMsgData
{
	struct FText Info; // 0x0(0x18)
	struct UBlockBase* SourceBlock; // 0x18(0x8)
	uint8_t Pad_0x20[0x40]; // 0x20(0x40)
};

// Object: ScriptStruct BlockyLuaCore.NamedVarData
// Size: 0x28 (Inherited: 0x0)
struct FNamedVarData
{
	enum class EBlockyAccessType Access; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UVarDefiner* Definer; // 0x8(0x8)
	bool bIsArray; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct FString InitValueString; // 0x18(0x10)
};

// Object: ScriptStruct BlockyLuaCore.DependResInfo
// Size: 0x30 (Inherited: 0x0)
struct FDependResInfo
{
	struct TArray<int> AssetIDs; // 0x0(0x10)
	struct TArray<int> FeatureIDs; // 0x10(0x10)
	struct TArray<struct FString> CustomAssetKeys; // 0x20(0x10)
};

// Object: Class BlockyLuaCore.BlockBase
// Size: 0x200 (Inherited: 0x28)
struct UBlockBase : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct UBlockBase* ParentBlock; // 0x30(0x8)
	struct UBlockBase* CommentBlock; // 0x38(0x8)
	struct UBlockyGraph* HostGraph; // 0x40(0x8)
	uint8_t Pad_0x48[0x28]; // 0x48(0x28)
	struct UBlockyGraphData* HostWidget; // 0x70(0x8)
	uint8_t Pad_0x78[0x10]; // 0x78(0x10)
	struct UFunctionDesc* FunctionDesc; // 0x88(0x8)
	struct FString DisplayName; // 0x90(0x10)
	uint8_t Pad_0xA0[0x148]; // 0xA0(0x148)
	struct FString QuoteVariableName; // 0x1E8(0x10)
	bool bIsDisable; // 0x1F8(0x1)
	uint8_t Pad_0x1F9[0x7]; // 0x1F9(0x7)


	// Object: Function BlockyLuaCore.BlockBase.SetIsDisable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106b4a320
	// Params: [ Num(1) Size(0x1) ]
	void SetIsDisable(bool Disable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.BlockBase.IsEvent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4a2dc
	// Params: [ Num(1) Size(0x1) ]
	bool IsEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.BlockBase.GetCenterPos
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4a2a8
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetCenterPos();
	// [Call #1] RVA: 0x106B53454
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.Executeable
// Size: 0x430 (Inherited: 0x200)
struct UExecuteable : UBlockBase
{
	uint8_t Pad_0x200[0x1C8]; // 0x200(0x1C8)
	struct TMap<struct FString, struct FBlockParam> BlockParams; // 0x3C8(0x50)
	struct TArray<struct UNamedVar*> FuncVars; // 0x418(0x10)
	uint8_t Pad_0x428[0x8]; // 0x428(0x8)


	// Object: Function BlockyLuaCore.Executeable.SupportFuncVar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b6cbbc
	// Params: [ Num(1) Size(0x1) ]
	bool SupportFuncVar();
	// [Call #1] RVA: 0x106A90EE4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x106B57610
	// [Call #8] RVA: 0x105184F34

	// Object: Function BlockyLuaCore.Executeable.ReEditFuncVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b6cb40
	// Params: [ Num(1) Size(0x8) ]
	void ReEditFuncVar(struct UNamedVar* var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A90FC4
	// [Call #4] RVA: 0x106A90EE4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.Executeable.DeleteFuncVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b6cac4
	// Params: [ Num(1) Size(0x8) ]
	void DeleteFuncVar(struct UNamedVar* var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A90FD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A90FC4
	// [Call #7] RVA: 0x106A90EE4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.Executeable.CreateFuncVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b6cab0
	// Params: [ Num(0) Size(0x0) ]
	void CreateFuncVar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A90FD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A90FC4
	// [Call #7] RVA: 0x106A90EE4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.AddArrayElement
// Size: 0x760 (Inherited: 0x430)
struct UAddArrayElement : UExecuteable
{
	uint8_t Pad_0x430[0x330]; // 0x430(0x330)
};

// Object: Class BlockyLuaCore.Arithmetic
// Size: 0x728 (Inherited: 0x200)
struct UArithmetic : UBlockBase
{
	uint8_t Pad_0x200[0x528]; // 0x200(0x528)
};

// Object: Class BlockyLuaCore.ArrayLength
// Size: 0x3A0 (Inherited: 0x200)
struct UArrayLength : UBlockBase
{
	uint8_t Pad_0x200[0x198]; // 0x200(0x198)
	struct UBrushData* BrushBGSelected; // 0x398(0x8)
};

// Object: Class BlockyLuaCore.ExpressionBase
// Size: 0x28 (Inherited: 0x28)
struct UExpressionBase : UBlueprintFunctionLibrary
{

	// Object: Function BlockyLuaCore.ExpressionBase.ReleaseExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d098
	// Params: [ Num(1) Size(0x8) ]
	void ReleaseExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B7A0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ExpressionBase.CreateExpressionBase
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d064
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateExpressionBase();
	// [Call #1] RVA: 0x106B1B774
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1B7A0
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.ArrayLengthExpression
// Size: 0x28 (Inherited: 0x28)
struct UArrayLengthExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.ArrayLengthExpression.SetTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b493b4
	// Params: [ Num(2) Size(0x10) ]
	void SetTarget(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1A840
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.ArrayLengthExpression.GetTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49338
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetTarget(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A838
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1A840
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ArrayLengthExpression.CreateArrayLengthExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49304
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateArrayLengthExpression();
	// [Call #1] RVA: 0x106B1A808
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1A838
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1A840
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.VarBase
// Size: 0x200 (Inherited: 0x200)
struct UVarBase : UBlockBase
{
};

// Object: Class BlockyLuaCore.NamedVar
// Size: 0x4F8 (Inherited: 0x200)
struct UNamedVar : UVarBase
{
	struct FText Name; // 0x200(0x18)
	uint8_t Pad_0x218[0x8]; // 0x218(0x8)
	struct FString NameInCode; // 0x220(0x10)
	bool IsValueValid; // 0x230(0x1)
	bool IsSourceValid; // 0x231(0x1)
	bool IsInitColorLoad; // 0x232(0x1)
	uint8_t Pad_0x233[0x5]; // 0x233(0x5)
	struct TArray<struct UNamedVar*> CopiedChildVarCache; // 0x238(0x10)
	uint8_t Pad_0x248[0x1D8]; // 0x248(0x1D8)
	bool bIsArray; // 0x420(0x1)
	uint8_t Pad_0x421[0x7]; // 0x421(0x7)
	struct FString InitValueString; // 0x428(0x10)
	struct UColorDesc* ColorDesc; // 0x438(0x8)
	struct TArray<struct UColorDesc*> ArrayColorDesc; // 0x440(0x10)
	int NowColorArrayIdx; // 0x450(0x4)
	bool NowColorIsArray; // 0x454(0x1)
	uint8_t Pad_0x455[0x3]; // 0x455(0x3)
	struct UNamedVar* Source; // 0x458(0x8)
	uint8_t Pad_0x460[0x40]; // 0x460(0x40)
	struct UBrushData* CopyBrush; // 0x4A0(0x8)
	uint8_t Pad_0x4A8[0x50]; // 0x4A8(0x50)


	// Object: Function BlockyLuaCore.NamedVar.UpdateColor
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void UpdateColor(struct FLinearColor& Color);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLuaCore.NamedVar.SetNameVarColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x106b7d628
	// Params: [ Num(1) Size(0x10) ]
	void SetNameVarColor(struct FLinearColor& Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC02A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.NamedVar.SetIsArray
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d5a4
	// Params: [ Num(1) Size(0x1) ]
	void SetIsArray(bool IsArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AB9718
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106AC02A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.NamedVar.SetInitValueString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d4c0
	// Params: [ Num(1) Size(0x10) ]
	void SetInitValueString(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106ABFBF4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106AB9718
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106AC02A4
	// [Call #18] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.NamedVar.SetDefiner
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d444
	// Params: [ Num(1) Size(0x8) ]
	void SetDefiner(struct UVarDefiner* Definer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106ABFBE4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106ABFBF4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106AB9718
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.NamedVar.SetAccessType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d3c0
	// Params: [ Num(1) Size(0x1) ]
	void SetAccessType(enum class EBlockyAccessType Access);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106ABFBD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106ABFBE4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106ABFBF4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106AB9718

	// Object: Function BlockyLuaCore.NamedVar.IsGlobalVar
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x106b7d38c
	// Params: [ Num(1) Size(0x1) ]
	bool IsGlobalVar();
	// [Call #1] RVA: 0x106ABFAC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106ABFBD0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106ABFBE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106ABFBF4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.NamedVar.IsCustomColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d358
	// Params: [ Num(1) Size(0x1) ]
	bool IsCustomColor();
	// [Call #1] RVA: 0x106AC0398
	// [Call #2] RVA: 0x106ABFAC8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106ABFBD0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106ABFBE4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106ABFBF4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.NamedVar.IsArray
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7d324
	// Params: [ Num(1) Size(0x1) ]
	bool IsArray();
	// [Call #1] RVA: 0x106ABFB58
	// [Call #2] RVA: 0x106AC0398
	// [Call #3] RVA: 0x106ABFAC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106ABFBD0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106ABFBE4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106ABFBF4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.NamedVar.InitColorDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d310
	// Params: [ Num(0) Size(0x0) ]
	void InitColorDesc();
	// [Call #1] RVA: 0x106ABFB58
	// [Call #2] RVA: 0x106AC0398
	// [Call #3] RVA: 0x106ABFAC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106ABFBD0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106ABFBE4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106ABFBF4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.NamedVar.GetNameVarColorDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7d244
	// Params: [ Num(3) Size(0x10) ]
	struct UColorDesc* GetNameVarColorDesc(int idx, bool IsArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106ABFD44
	// [Call #6] RVA: 0x106ABFB58
	// [Call #7] RVA: 0x106AC0398
	// [Call #8] RVA: 0x106ABFAC8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106ABFBD0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.NamedVar.GetNameVarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106b7d174
	// Params: [ Num(3) Size(0x18) ]
	struct FLinearColor GetNameVarColor(int idx, bool IsArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106ABFE30
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106ABFD44
	// [Call #11] RVA: 0x106ABFB58
	// [Call #12] RVA: 0x106AC0398
	// [Call #13] RVA: 0x106ABFAC8

	// Object: Function BlockyLuaCore.NamedVar.GetInitValueString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7d110
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetInitValueString();
	// [Call #1] RVA: 0x106ABFB6C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106ABFE30
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106ABFD44
	// [Call #16] RVA: 0x106ABFB58

	// Object: Function BlockyLuaCore.NamedVar.GetDefiner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7d0dc
	// Params: [ Num(1) Size(0x8) ]
	struct UVarDefiner* GetDefiner();
	// [Call #1] RVA: 0x106ABFB40
	// [Call #2] RVA: 0x106ABFB6C
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106ABFE30
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106ABFD44

	// Object: Function BlockyLuaCore.NamedVar.GetColorStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7cfe8
	// Params: [ Num(3) Size(0x18) ]
	struct FString GetColorStr(int idx, bool IsArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106AC0248
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106ABFB40
	// [Call #11] RVA: 0x106ABFB6C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106ABFE30

	// Object: Function BlockyLuaCore.NamedVar.GetAccessType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7cfa4
	// Params: [ Num(1) Size(0x1) ]
	enum class EBlockyAccessType GetAccessType();
	// [Call #1] RVA: 0x106ABFB24
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106AC0248
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106ABFB40
	// [Call #12] RVA: 0x106ABFB6C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.NamedVar.CallCustomSelectObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7cee8
	// Params: [ Num(2) Size(0x5) ]
	void CallCustomSelectObject(int idx, bool IsArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106AC03E0
	// [Call #6] RVA: 0x106ABFB24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106AC0248
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106ABFB40
	// [Call #17] RVA: 0x106ABFB6C

	// Object: Function BlockyLuaCore.NamedVar.AddColorToArray
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7ced4
	// Params: [ Num(0) Size(0x0) ]
	void AddColorToArray();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106AC03E0
	// [Call #6] RVA: 0x106ABFB24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106AC0248
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106ABFB40
};

// Object: Class BlockyLuaCore.ArrayNamedVar
// Size: 0x4F8 (Inherited: 0x4F8)
struct UArrayNamedVar : UNamedVar
{
};

// Object: Class BlockyLuaCore.BinaryOperatorExpression
// Size: 0x28 (Inherited: 0x28)
struct UBinaryOperatorExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.SetWithParentheses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49c04
	// Params: [ Num(2) Size(0x9) ]
	void SetWithParentheses(struct FBlockyLuaHandle ptr, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1A9E8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.SetRight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49b58
	// Params: [ Num(2) Size(0x10) ]
	void SetRight(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1A984
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1A9E8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.SetOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49aa8
	// Params: [ Num(2) Size(0x9) ]
	void SetOperation(struct FBlockyLuaHandle ptr, enum class EBlockyBinaryOperation BlockyOp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1A90C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1A984
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1A9E8
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.SetLeft
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b499fc
	// Params: [ Num(2) Size(0x10) ]
	void SetLeft(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1A920
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1A90C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1A984
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.GetWithParentheses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49980
	// Params: [ Num(2) Size(0x9) ]
	bool GetWithParentheses(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A904
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1A920
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1A90C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.GetRight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49904
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetRight(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A8FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1A904
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1A920
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1A90C

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.GetOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b49888
	// Params: [ Num(2) Size(0x9) ]
	enum class EBlockyBinaryOperation GetOperation(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A8E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1A8FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1A904
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1A920
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.GetLeft
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b4980c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLeft(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A8F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1A8E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1A8FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1A904
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BinaryOperatorExpression.CreateBinaryOperatorExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b497d8
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateBinaryOperatorExpression();
	// [Call #1] RVA: 0x106B1A8A4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1A8F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1A8E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1A8FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1A904
	// [Call #14] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.CategoryDefiner
// Size: 0xB8 (Inherited: 0x28)
struct UCategoryDefiner : UObject
{
	struct FString Type; // 0x28(0x10)
	struct FString Menu; // 0x38(0x10)
	struct TMap<struct FString, struct FString> ShowNameMap; // 0x48(0x50)
	struct FString ShowIcon; // 0x98(0x10)
	struct FString ShowIconSelected; // 0xA8(0x10)


	// Object: Function BlockyLuaCore.CategoryDefiner.GetCurrentLocateShowName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b648f0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCurrentLocateShowName();
	// [Call #1] RVA: 0x106A1ADB8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x106B64D64
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1B218
};

// Object: Class BlockyLuaCore.BlackboardDefiner
// Size: 0xD8 (Inherited: 0xB8)
struct UBlackboardDefiner : UCategoryDefiner
{
	uint8_t Pad_0xB8[0x20]; // 0xB8(0x20)
};

// Object: Class BlockyLuaCore.BlockyCommandData
// Size: 0x30 (Inherited: 0x28)
struct UBlockyCommandData : UObject
{
	struct UBlockBase* bLock; // 0x28(0x8)
};

// Object: Class BlockyLuaCore.BlockyAddOrRemoveFromSlotCommandData
// Size: 0xF0 (Inherited: 0x30)
struct UBlockyAddOrRemoveFromSlotCommandData : UBlockyCommandData
{
	struct FBlockPoint Position; // 0x30(0x8)
	struct UBlockBase* SlotHostBlock; // 0x38(0x8)
	uint8_t Pad_0x40[0x18]; // 0x40(0x18)
	struct UBlockBase* ConvertBlock; // 0x58(0x8)
	uint8_t Pad_0x60[0x18]; // 0x60(0x18)
	struct UBlockBase* ReplacedBlock; // 0x78(0x8)
	struct UBlockBase* ReplacedBlockSlotHostBlock; // 0x80(0x8)
	uint8_t Pad_0x88[0x68]; // 0x88(0x68)
};

// Object: Class BlockyLuaCore.BlockyAddOrRemoveFromTopCommandData
// Size: 0x80 (Inherited: 0x30)
struct UBlockyAddOrRemoveFromTopCommandData : UBlockyCommandData
{
	struct UBlockBase* TouchBlock; // 0x30(0x8)
	struct FBlockPoint Position; // 0x38(0x8)
	struct UBlockBase* TouchBlockHostSlotHost; // 0x40(0x8)
	uint8_t Pad_0x48[0x18]; // 0x48(0x18)
	struct UBlockBase* SlotHostBlock; // 0x60(0x8)
	uint8_t Pad_0x68[0x18]; // 0x68(0x18)
};

// Object: Class BlockyLuaCore.BlockyBindCommentCommandData
// Size: 0x40 (Inherited: 0x30)
struct UBlockyBindCommentCommandData : UBlockyCommandData
{
	struct FBlockPoint Position; // 0x30(0x8)
	struct UCommentBlock* CommentBlock; // 0x38(0x8)
};

// Object: Class BlockyLuaCore.BlockyBlockListItemObject
// Size: 0xE0 (Inherited: 0x28)
struct UBlockyBlockListItemObject : UObject
{
	struct FText Name; // 0x28(0x18)
	struct FString KeyName; // 0x40(0x10)
	struct FString SubGraphName; // 0x50(0x10)
	struct FString DisplayName; // 0x60(0x10)
	struct FString NameInCode; // 0x70(0x10)
	struct FBlockPoint Size; // 0x80(0x8)
	struct FBlockPoint TextSize; // 0x88(0x8)
	struct FString BlockClassName; // 0x90(0x10)
	uint8_t Pad_0xA0[0x10]; // 0xA0(0x10)
	bool Visible; // 0xB0(0x1)
	bool VisibleByTag; // 0xB1(0x1)
	uint8_t Pad_0xB2[0x6]; // 0xB2(0x6)
	struct UFunctionDesc* FunctionDesc; // 0xB8(0x8)
	bool bCollect; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x1F]; // 0xC1(0x1F)
};

// Object: Class BlockyLuaCore.BlockyBlockListItemObject_Custom
// Size: 0xE8 (Inherited: 0xE0)
struct UBlockyBlockListItemObject_Custom : UBlockyBlockListItemObject
{
	struct UCustomConfig* CustomConfig; // 0xE0(0x8)
};

// Object: Class BlockyLuaCore.BlockyBlockListItemObject_Preset
// Size: 0x2A8 (Inherited: 0xE0)
struct UBlockyBlockListItemObject_Preset : UBlockyBlockListItemObject
{
	struct UPresetDesc* SourcePreset; // 0xE0(0x8)
	uint8_t Pad_0xE8[0x1C0]; // 0xE8(0x1C0)
};

// Object: Class BlockyLuaCore.BlockyBlockListItemObject_Variable
// Size: 0xE8 (Inherited: 0xE0)
struct UBlockyBlockListItemObject_Variable : UBlockyBlockListItemObject
{
	struct UNamedVar* SourceVar; // 0xE0(0x8)
};

// Object: Class BlockyLuaCore.BlockyCategoryItemObject
// Size: 0xE8 (Inherited: 0x28)
struct UBlockyCategoryItemObject : UObject
{
	struct FText Name; // 0x28(0x18)
	struct FString Type; // 0x40(0x10)
	struct FString MenuType; // 0x50(0x10)
	struct TArray<struct UBlockyBlockListItemObject*> Items; // 0x60(0x10)
	struct TArray<struct UBlockyBlockListItemObject*> AddItems; // 0x70(0x10)
	struct TArray<struct UBlockyBlockListItemObject*> DelItems; // 0x80(0x10)
	struct TArray<struct UPresetDesc*> Presets; // 0x90(0x10)
	bool Visible; // 0xA0(0x1)
	bool VisibleByTag; // 0xA1(0x1)
	bool ShowNum; // 0xA2(0x1)
	uint8_t Pad_0xA3[0x5]; // 0xA3(0x5)
	struct UBrushData* Brush; // 0xA8(0x8)
	struct UBrushData* BrushSelected; // 0xB0(0x8)
	uint8_t Pad_0xB8[0x10]; // 0xB8(0x10)
	struct UBlackboardDefiner* Blackboard; // 0xC8(0x8)
	bool bIsPlayerBlackboard; // 0xD0(0x1)
	bool bIsShowRedDot; // 0xD1(0x1)
	uint8_t Pad_0xD2[0x16]; // 0xD2(0x16)


	// Object: Function BlockyLuaCore.BlockyCategoryItemObject.SetShowRedDotVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4aec4
	// Params: [ Num(1) Size(0x1) ]
	void SetShowRedDotVar(bool var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B2A3D4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyCategoryItemObject.InitShowRedDotVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ade0
	// Params: [ Num(1) Size(0x10) ]
	void InitShowRedDotVar(struct FString BlockName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B2A318
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B2A3D4
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyCategoryItemObject.GetSelectedIconBrush
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b4ad7c
	// Params: [ Num(1) Size(0xB8) ]
	struct FSlateBrush GetSelectedIconBrush();
	// [Call #1] RVA: 0x106B29E98
	// [Call #2] RVA: 0x101FE5E98
	// [Call #3] RVA: 0x101FEA144
	// [Call #4] RVA: 0x101FEA144
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B2A318
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B2A3D4
	// [Call #20] RVA: 0x10519022C
	// [Call #21] RVA: 0x105190870

	// Object: Function BlockyLuaCore.BlockyCategoryItemObject.GetNewBlockNums
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ad48
	// Params: [ Num(1) Size(0x4) ]
	int GetNewBlockNums();
	// [Call #1] RVA: 0x106B2A160
	// [Call #2] RVA: 0x106B29E98
	// [Call #3] RVA: 0x101FE5E98
	// [Call #4] RVA: 0x101FEA144
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106B2A318
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B2A3D4
	// [Call #21] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyCategoryItemObject.GetIconBrush
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b4ace4
	// Params: [ Num(1) Size(0xB8) ]
	struct FSlateBrush GetIconBrush();
	// [Call #1] RVA: 0x106B29BD0
	// [Call #2] RVA: 0x101FE5E98
	// [Call #3] RVA: 0x101FEA144
	// [Call #4] RVA: 0x101FEA144
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B2A160
	// [Call #7] RVA: 0x106B29E98
	// [Call #8] RVA: 0x101FE5E98
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106B2A318
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106B2A3D4
};

// Object: Class BlockyLuaCore.BlockyCommand
// Size: 0x100 (Inherited: 0x28)
struct UBlockyCommand : UObject
{
	uint8_t Pad_0x28[0xA8]; // 0x28(0xA8)
	struct UBlockyCommandData* UndoData; // 0xD0(0x8)
	struct UBlockyCommandData* RedoData; // 0xD8(0x8)
	struct UBlockyGraph* Graph; // 0xE0(0x8)
	struct TArray<struct UBlockyCommand*> AdditionCommands; // 0xE8(0x10)
	uint8_t Pad_0xF8[0x8]; // 0xF8(0x8)
};

// Object: Class BlockyLuaCore.BlockyCustomCommand
// Size: 0x100 (Inherited: 0x100)
struct UBlockyCustomCommand : UBlockyCommand
{
};

// Object: Class BlockyLuaCore.BlockyDeleteCommandData
// Size: 0xD0 (Inherited: 0x30)
struct UBlockyDeleteCommandData : UBlockyCommandData
{
	struct FBlockPoint Position; // 0x30(0x8)
	struct UBlockBase* NextBlock; // 0x38(0x8)
	uint8_t Pad_0x40[0x18]; // 0x40(0x18)
	struct UBlockBase* HostSlotBlock; // 0x58(0x8)
	uint8_t Pad_0x60[0x70]; // 0x60(0x70)
};

// Object: Class BlockyLuaCore.BlockyEditorInterface
// Size: 0x28 (Inherited: 0x28)
struct IBlockyEditorInterface : IInterface
{
};

// Object: Class BlockyLuaCore.BlockyExporter
// Size: 0x28 (Inherited: 0x28)
struct UBlockyExporter : UObject
{
};

// Object: Class BlockyLuaCore.BlockyGraph
// Size: 0x150 (Inherited: 0x28)
struct UBlockyGraph : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
	struct FString Name; // 0x38(0x10)
	struct FString Type; // 0x48(0x10)
	struct FString DisplayName; // 0x58(0x10)
	struct FString TemplateName; // 0x68(0x10)
	struct FString Description; // 0x78(0x10)
	struct FString CategoryMode; // 0x88(0x10)
	struct FString CapturePath; // 0x98(0x10)
	struct FString JsonPath; // 0xA8(0x10)
	bool bCanBeDuplicated; // 0xB8(0x1)
	bool bIsDisable; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x6]; // 0xBA(0x6)
	struct UBlockyGraphData* HostGraphData; // 0xC0(0x8)
	struct TArray<struct UBlockBase*> RootBlocks; // 0xC8(0x10)
	uint8_t Pad_0xD8[0x8]; // 0xD8(0x8)
	struct TArray<struct UNamedVar*> LocalVars; // 0xE0(0x10)
	int CurrentVisibleBlockNum; // 0xF0(0x4)
	uint8_t Pad_0xF4[0xC]; // 0xF4(0xC)
	struct UCanvasRenderTarget2D* RenderTarget; // 0x100(0x8)
	struct FVector2D ViewPosition; // 0x108(0x8)
	struct FBlockPoint ViewSize; // 0x110(0x8)
	float ViewScale; // 0x118(0x4)
	uint8_t Pad_0x11C[0x34]; // 0x11C(0x34)


	// Object: Function BlockyLuaCore.BlockyGraph.UpdateCustomBlockName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4c054
	// Params: [ Num(0) Size(0x0) ]
	void UpdateCustomBlockName();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraph.TryAdjustingBlockIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4bfd8
	// Params: [ Num(1) Size(0x8) ]
	void TryAdjustingBlockIntoView(struct UBlockyGraphData* GraphData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A20404
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraph.SetIsDisable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106b4bf4c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsDisable(bool Disable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A20404
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraph.SaveGraphToFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4be6c
	// Params: [ Num(2) Size(0x11) ]
	void SaveGraphToFile(struct FString Filename, bool IsNewFile);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A1F7F8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A20404
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraph.SaveGraphAsTemplate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b4bd70
	// Params: [ Num(3) Size(0x19) ]
	bool SaveGraphAsTemplate(struct TArray<uint8_t>& OutData, struct UCustomConfig* CustomConfig);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106AFE934
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A1F7F8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraph.SaveCsutomGraphAsTemplate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b4bcb8
	// Params: [ Num(2) Size(0x11) ]
	bool SaveCsutomGraphAsTemplate(struct TArray<uint8_t>& OutData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AFF830
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106AFE934
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraph.LoadGraphFromTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4bb84
	// Params: [ Num(2) Size(0x11) ]
	void LoadGraphFromTemplate(struct TArray<uint8_t> Data, bool IsLoadPresetsInGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FFC894
	// [Call #6] RVA: 0x106AFFE40
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106AFF830
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraph.IsCustomTemplateGraph
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4bb50
	// Params: [ Num(1) Size(0x1) ]
	bool IsCustomTemplateGraph();
	// [Call #1] RVA: 0x106A1F758
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FFC894
	// [Call #7] RVA: 0x106AFFE40
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106AFF830
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraph.IsCustomGraph
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4bb1c
	// Params: [ Num(1) Size(0x1) ]
	bool IsCustomGraph();
	// [Call #1] RVA: 0x106A1F1F8
	// [Call #2] RVA: 0x106A1F758
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FFC894
	// [Call #8] RVA: 0x106AFFE40
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106AFF830
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraph.IsBasicTemplateGraph
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4bae8
	// Params: [ Num(1) Size(0x1) ]
	bool IsBasicTemplateGraph();
	// [Call #1] RVA: 0x106A1F7A8
	// [Call #2] RVA: 0x106A1F1F8
	// [Call #3] RVA: 0x106A1F758
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FFC894
	// [Call #9] RVA: 0x106AFFE40
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106AFF830

	// Object: Function BlockyLuaCore.BlockyGraph.GetTriggerItemsByRootBlocks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ba84
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UBlockBase*> GetTriggerItemsByRootBlocks();
	// [Call #1] RVA: 0x106A2049C
	// [Call #2] RVA: 0x106B5350C
	// [Call #3] RVA: 0x1023089C4
	// [Call #4] RVA: 0x1023089C4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A1F7A8
	// [Call #7] RVA: 0x106A1F1F8
	// [Call #8] RVA: 0x106A1F758
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FFC894
	// [Call #14] RVA: 0x106AFFE40
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraph.GetTotalBlockNum
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4ba68
	// Params: [ Num(1) Size(0x4) ]
	int GetTotalBlockNum();
	// [Call #1] RVA: 0x106A2049C
	// [Call #2] RVA: 0x106B5350C
	// [Call #3] RVA: 0x1023089C4
	// [Call #4] RVA: 0x1023089C4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A1F7A8
	// [Call #7] RVA: 0x106A1F1F8
	// [Call #8] RVA: 0x106A1F758
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FFC894
	// [Call #14] RVA: 0x106AFFE40
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraph.CaptureScreenWithShot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106b4b9a4
	// Params: [ Num(3) Size(0x18) ]
	struct UTexture2D* CaptureScreenWithShot(struct UUserWidget* Widget, struct FVector2D rect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A1EC28
	// [Call #6] RVA: 0x106A2049C
	// [Call #7] RVA: 0x106B5350C
	// [Call #8] RVA: 0x1023089C4
	// [Call #9] RVA: 0x1023089C4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A1F7A8
	// [Call #12] RVA: 0x106A1F1F8
	// [Call #13] RVA: 0x106A1F758
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraph.CaptureScreenShot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4b928
	// Params: [ Num(1) Size(0x8) ]
	void CaptureScreenShot(struct UUserWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A1EAD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A1EC28
	// [Call #9] RVA: 0x106A2049C
	// [Call #10] RVA: 0x106B5350C
	// [Call #11] RVA: 0x1023089C4
	// [Call #12] RVA: 0x1023089C4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106A1F7A8
	// [Call #15] RVA: 0x106A1F1F8
	// [Call #16] RVA: 0x106A1F758

	// Object: Function BlockyLuaCore.BlockyGraph.CanSaveAsTemplate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b4b870
	// Params: [ Num(2) Size(0x11) ]
	bool CanSaveAsTemplate(struct FString& OutFailedReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A1FD30
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A1EAD4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A1EC28
	// [Call #15] RVA: 0x106A2049C
	// [Call #16] RVA: 0x106B5350C
	// [Call #17] RVA: 0x1023089C4

	// Object: Function BlockyLuaCore.BlockyGraph.CanBeRemove
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b4b7e4
	// Params: [ Num(2) Size(0x9) ]
	bool CanBeRemove(struct UBlockyGraphData* GraphData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A1F248
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A1FD30
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A1EAD4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraph.CanBeDuplicated
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b4b7b0
	// Params: [ Num(1) Size(0x1) ]
	bool CanBeDuplicated();
	// [Call #1] RVA: 0x106A1F174
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A1F248
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106A1FD30
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A1EAD4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.BlockyGraphWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct IBlockyGraphWidgetInterface : IInterface
{
};

// Object: Class BlockyLuaCore.BlockyGraphData
// Size: 0x6D0 (Inherited: 0x28)
struct UBlockyGraphData : UObject
{
	struct TScriptInterface<Class> GraphWidgetInterface; // 0x28(0x10)
	struct FVector2D ViewPosition; // 0x38(0x8)
	struct FBlockPoint ViewSize; // 0x40(0x8)
	float ViewScale; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct FVector2D DisplayBlockSize; // 0x50(0x8)
	uint8_t Pad_0x58[0x88]; // 0x58(0x88)
	bool bShowDeleteBlockUI; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
	struct UNamedVar* EditingVar; // 0xE8(0x8)
	struct TArray<struct UNamedVar*> GlobalVars; // 0xF0(0x10)
	struct TMap<struct FString, struct UPresetDesc*> PresetDescMap_Graph; // 0x100(0x50)
	struct UCustomConfig* EditingCustomConfig; // 0x150(0x8)
	struct TMap<struct FGuid, struct UCustomConfig*> TemplateCustomConfigs; // 0x158(0x50)
	struct TMap<struct FGuid, struct UCustomConfig*> GameEventConfigs; // 0x1A8(0x50)
	struct UExecuteable* CurrExeBlock; // 0x1F8(0x8)
	struct UExecuteable* EditingExeBlock; // 0x200(0x8)
	struct TArray<struct UBlockyGraph*> SubBlockyGraphs; // 0x208(0x10)
	struct TArray<struct UBlockyGraph*> BlockyGraphsCallStack; // 0x218(0x10)
	struct TMap<struct FString, struct FString> CacheData; // 0x228(0x50)
	struct FText Name; // 0x278(0x18)
	struct UBlockBase* CurrentPutSlotHostBlock; // 0x290(0x8)
	uint8_t Pad_0x298[0x18]; // 0x298(0x18)
	struct UBlockBase* CurrentPutSlotReplacedBlock; // 0x2B0(0x8)
	struct UBlockBase* CurrentTopPutBlock; // 0x2B8(0x8)
	uint8_t Pad_0x2C0[0x8]; // 0x2C0(0x8)
	struct UBlockBase* CurrentSettingBlock; // 0x2C8(0x8)
	struct USelectionData* CurrentSelection; // 0x2D0(0x8)
	struct USelectionData* CurrentPointAt; // 0x2D8(0x8)
	struct UExecuteablePreview* BlockPreview; // 0x2E0(0x8)
	struct FScriptMulticastDelegate OnSaveProgress; // 0x2E8(0x10)
	bool IsGraphDirty; // 0x2F8(0x1)
	bool IsLoading; // 0x2F9(0x1)
	uint8_t Pad_0x2FA[0xE]; // 0x2FA(0xE)
	struct UBrushData* DefaultRectBrush; // 0x308(0x8)
	struct UMaterial* PreViewMaterial; // 0x310(0x8)
	struct UBrushData* PreViewBrush; // 0x318(0x8)
	struct UBrushData* AnimateBrush; // 0x320(0x8)
	struct UMaterialInstanceDynamic* DeleteUIDynamicMaterial; // 0x328(0x8)
	struct UMaterialInstanceDynamic* DeleteRangeUIDynamicMaterial; // 0x330(0x8)
	struct UMaterialInstanceDynamic* DeleteUIBgDynamicMaterial; // 0x338(0x8)
	struct UBrushData* DeleteRangeUIDockingBrush; // 0x340(0x8)
	struct UBrushData* DeleteUIDockingBrush; // 0x348(0x8)
	struct UBrushData* DeleteUIBgBrush; // 0x350(0x8)
	uint8_t Pad_0x358[0x20]; // 0x358(0x20)
	struct UBlockBase* TouchBlockHostSlotHost; // 0x378(0x8)
	uint8_t Pad_0x380[0xE8]; // 0x380(0xE8)
	DelegateProperty OnOpenCustomPanel; // 0x468(0x10)
	DelegateProperty OnOpenCustomPopup; // 0x478(0x10)
	DelegateProperty OnOpenCustomSavePopup; // 0x488(0x10)
	DelegateProperty OnCloseCustomPopup; // 0x498(0x10)
	DelegateProperty OnOpenVariablePopup; // 0x4A8(0x10)
	DelegateProperty OnOpenBlackboardPopup; // 0x4B8(0x10)
	DelegateProperty OnCloseVariablePopup; // 0x4C8(0x10)
	DelegateProperty OnOpenVariable; // 0x4D8(0x10)
	DelegateProperty OnUpdateUndoRedoState; // 0x4E8(0x10)
	DelegateProperty OnShowTips; // 0x4F8(0x10)
	DelegateProperty OnShowInitUI; // 0x508(0x10)
	DelegateProperty OnOpenVariablePanel; // 0x518(0x10)
	DelegateProperty OnOpenCreateBlackboardPanel; // 0x528(0x10)
	DelegateProperty OnOpenEditBlackboardPanel; // 0x538(0x10)
	DelegateProperty OnOpenCreateCustomVarPanel; // 0x548(0x10)
	DelegateProperty OnOpenEditCustomVarPanel; // 0x558(0x10)
	DelegateProperty OpenDelCustomVarPanel; // 0x568(0x10)
	DelegateProperty OnQuoteBlock; // 0x578(0x10)
	DelegateProperty OnShowBlockSettingPop; // 0x588(0x10)
	DelegateProperty OnOpenCommentPopup; // 0x598(0x10)
	DelegateProperty OnCloseCommentPopup; // 0x5A8(0x10)
	DelegateProperty OnSetBlockLogNum; // 0x5B8(0x10)
	DelegateProperty OnSetBlockLogTabNum; // 0x5C8(0x10)
	DelegateProperty OnSetBlockLogText; // 0x5D8(0x10)
	DelegateProperty OnClearBlockLog; // 0x5E8(0x10)
	DelegateProperty OnOpenAnimationPopup; // 0x5F8(0x10)
	DelegateProperty OnCloseAnimationPopup; // 0x608(0x10)
	DelegateProperty OnShowBlockVariablePopup; // 0x618(0x10)
	uint8_t Pad_0x628[0x10]; // 0x628(0x10)
	struct TArray<struct FString> OpendItemStrings; // 0x638(0x10)
	struct FString CurSelectTriggerType; // 0x648(0x10)
	uint8_t Pad_0x658[0x1]; // 0x658(0x1)
	bool IsOpenedCaption; // 0x659(0x1)
	bool IsFirstFindPresetMap; // 0x65A(0x1)
	uint8_t Pad_0x65B[0x75]; // 0x65B(0x75)


	// Object: Function BlockyLuaCore.BlockyGraphData.UseTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50b50
	// Params: [ Num(1) Size(0x8) ]
	void UseTemplate(struct UBlockyGraph* templateGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22960
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateVariableMenu
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50b3c
	// Params: [ Num(0) Size(0x0) ]
	void UpdateVariableMenu();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22960
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateVariableItemNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50ad8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FText> UpdateVariableItemNames();
	// [Call #1] RVA: 0x106A2C2A4
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A22960
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateCustomMenu
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50ac4
	// Params: [ Num(0) Size(0x0) ]
	void UpdateCustomMenu();
	// [Call #1] RVA: 0x106A2C2A4
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A22960
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateCustomItemNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50a60
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FText> UpdateCustomItemNames();
	// [Call #1] RVA: 0x106A2C5D8
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2C2A4
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22960
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateAllPresetInGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50a4c
	// Params: [ Num(0) Size(0x0) ]
	void UpdateAllPresetInGraph();
	// [Call #1] RVA: 0x106A2C5D8
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2C2A4
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22960
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.UpdateAfterLoadBin
	// Flags: [Final|Native|Public]
	// Offset: 0x106b50a38
	// Params: [ Num(0) Size(0x0) ]
	void UpdateAfterLoadBin();
	// [Call #1] RVA: 0x106A2C5D8
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2C2A4
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22960
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyGraphData.Undo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50a24
	// Params: [ Num(0) Size(0x0) ]
	void Undo();
	// [Call #1] RVA: 0x106A2C5D8
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2C2A4
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22960
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.BlockyGraphData.TryCloseItemList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50a10
	// Params: [ Num(0) Size(0x0) ]
	void TryCloseItemList();
	// [Call #1] RVA: 0x106A2C5D8
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2C2A4
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22960
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.BlockyGraphData.ShowTips
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b50964
	// Params: [ Num(1) Size(0x18) ]
	void ShowTips(struct FText& Tips);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A08BF8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A2C5D8
	// [Call #9] RVA: 0x106B541B4
	// [Call #10] RVA: 0x1037BBE68
	// [Call #11] RVA: 0x1037BBE68
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A2C2A4
	// [Call #14] RVA: 0x106B541B4
	// [Call #15] RVA: 0x1037BBE68
	// [Call #16] RVA: 0x1037BBE68
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A22960

	// Object: Function BlockyLuaCore.BlockyGraphData.ShowBlockSettingPop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50950
	// Params: [ Num(0) Size(0x0) ]
	void ShowBlockSettingPop();
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A08BF8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A2C5D8
	// [Call #9] RVA: 0x106B541B4
	// [Call #10] RVA: 0x1037BBE68
	// [Call #11] RVA: 0x1037BBE68
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A2C2A4
	// [Call #14] RVA: 0x106B541B4
	// [Call #15] RVA: 0x1037BBE68
	// [Call #16] RVA: 0x1037BBE68
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.SetSlotString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b50864
	// Params: [ Num(1) Size(0x38) ]
	void SetSlotString(struct FBlockySlotString& slotStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A3E9E4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8CAC8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x104F0F380
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A08BF8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106A2C5D8
	// [Call #16] RVA: 0x106B541B4
	// [Call #17] RVA: 0x1037BBE68
	// [Call #18] RVA: 0x1037BBE68

	// Object: Function BlockyLuaCore.BlockyGraphData.SetGraphStrings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b507b4
	// Params: [ Num(1) Size(0x40) ]
	void SetGraphStrings(struct FGraphString& graphStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A3E8CC
	// [Call #4] RVA: 0x106A4840C
	// [Call #5] RVA: 0x106A4840C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A3E9E4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8CAC8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104F0F380
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A08BF8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8

	// Object: Function BlockyLuaCore.BlockyGraphData.SetCustomVariableString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b506cc
	// Params: [ Num(1) Size(0x28) ]
	void SetCustomVariableString(struct FCustomVariableString& variableStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A3E08C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8CAC8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A3E8CC
	// [Call #11] RVA: 0x106A4840C
	// [Call #12] RVA: 0x106A4840C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A3E9E4
	// [Call #17] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.SetCustomConfigString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b50614
	// Params: [ Num(1) Size(0x28) ]
	void SetCustomConfigString(struct FCustomConfigString& configStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A3E62C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A3E08C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8CAC8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A3E8CC
	// [Call #17] RVA: 0x106A4840C
	// [Call #18] RVA: 0x106A4840C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.SetCurrentSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50530
	// Params: [ Num(1) Size(0x10) ]
	void SetCurrentSubGraph(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A2638C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A3E62C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A3E08C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.SetCacheData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b50484
	// Params: [ Num(1) Size(0x50) ]
	void SetCacheData(struct TMap<struct FString, struct FString>& Data);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A20D0C
	// [Call #5] RVA: 0x101F87D64
	// [Call #6] RVA: 0x101F87D64
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106A2638C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A3E62C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.SetBlockLogText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50280
	// Params: [ Num(4) Size(0x30) ]
	void SetBlockLogText(uint8_t Mode, struct UBlockBase* BlockSource, struct FString SlotID, struct FString Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106A2FE44
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x101F8676C
	// [Call #26] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.SetBlockLogTabNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b501cc
	// Params: [ Num(2) Size(0x8) ]
	void SetBlockLogTabNum(int Mode, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A2FE3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106A2FE44
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.SetBlockLogNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b50118
	// Params: [ Num(2) Size(0x8) ]
	void SetBlockLogNum(int Mode, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A2FDE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A2FE3C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveGraphToJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b500b4
	// Params: [ Num(1) Size(0x10) ]
	struct FString SaveGraphToJsonText();
	// [Call #1] RVA: 0x106A33738
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A2FDE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A2FE3C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveGraphToBinFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b5001c
	// Params: [ Num(1) Size(0x10) ]
	void SaveGraphToBinFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A336B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x106A33738
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A2FDE0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A2FE3C

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveGraphToBin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ffb8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> SaveGraphToBin();
	// [Call #1] RVA: 0x106B01828
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A336B0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106A33738
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A2FDE0
	// [Call #22] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveGlobalVarToJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ff54
	// Params: [ Num(1) Size(0x10) ]
	struct FString SaveGlobalVarToJsonText();
	// [Call #1] RVA: 0x106A381A8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B01828
	// [Call #7] RVA: 0x1021B8BBC
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A336B0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106A33738
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveGlobalVarToBin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fef0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> SaveGlobalVarToBin();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.SaveCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fedc
	// Params: [ Num(0) Size(0x0) ]
	void SaveCustom();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.Save
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fec8
	// Params: [ Num(0) Size(0x0) ]
	void Save();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.ReturnToPreviewGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4feb4
	// Params: [ Num(0) Size(0x0) ]
	void ReturnToPreviewGraph();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.ReturnToMainGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fea0
	// Params: [ Num(0) Size(0x0) ]
	void ReturnToMainGraph();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.ResetGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fe8c
	// Params: [ Num(0) Size(0x0) ]
	void ResetGraph();
	// [Call #1] RVA: 0x106A37E40
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A381A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B01828
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106A336B0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A33738

	// Object: Function BlockyLuaCore.BlockyGraphData.RemoveSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fda8
	// Params: [ Num(1) Size(0x10) ]
	void RemoveSubGraph(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A297C0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106A37E40
	// [Call #13] RVA: 0x1021B8BBC
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106A381A8
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106B01828
	// [Call #23] RVA: 0x1021B8BBC
	// [Call #24] RVA: 0x101F8BA74

	// Object: Function BlockyLuaCore.BlockyGraphData.RefreshFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fd94
	// Params: [ Num(0) Size(0x0) ]
	void RefreshFont();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A297C0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106A37E40
	// [Call #13] RVA: 0x1021B8BBC
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106A381A8
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106B01828

	// Object: Function BlockyLuaCore.BlockyGraphData.ReEditVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fd18
	// Params: [ Num(1) Size(0x4) ]
	void ReEditVariable(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A23FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A297C0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106A37E40
	// [Call #16] RVA: 0x1021B8BBC
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.Redo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fd04
	// Params: [ Num(0) Size(0x0) ]
	void Redo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A23FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A297C0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106A37E40
	// [Call #16] RVA: 0x1021B8BBC
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.QuoteVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc88
	// Params: [ Num(1) Size(0x4) ]
	void QuoteVariable(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.QuoteCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc74
	// Params: [ Num(0) Size(0x0) ]
	void QuoteCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.Quote
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc60
	// Params: [ Num(0) Size(0x0) ]
	void Quote();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.Paste
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc4c
	// Params: [ Num(0) Size(0x0) ]
	void Paste();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.OpenGuideWebUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc38
	// Params: [ Num(0) Size(0x0) ]
	void OpenGuideWebUrl();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.OnLoadFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fc24
	// Params: [ Num(0) Size(0x0) ]
	void OnLoadFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0

	// Object: Function BlockyLuaCore.BlockyGraphData.MarkGraphDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fbfc
	// Params: [ Num(0) Size(0x0) ]
	void MarkGraphDirty();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A241A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A23FA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A297C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.LoadGraphFromJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fb18
	// Params: [ Num(1) Size(0x10) ]
	void LoadGraphFromJsonText(struct FString JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3640C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A241A8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.LoadGraphFromBinFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4fa80
	// Params: [ Num(1) Size(0x10) ]
	void LoadGraphFromBinFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A31E54
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A3640C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.LoadGlobalVarFromJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f99c
	// Params: [ Num(1) Size(0x10) ]
	void LoadGlobalVarFromJsonText(struct FString JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A385D8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A31E54
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x106A3640C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x104EEF504
	// [Call #26] RVA: 0x100036FE0
	// [Call #27] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.LoadByTicker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f988
	// Params: [ Num(0) Size(0x0) ]
	void LoadByTicker();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A385D8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A31E54
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x106A3640C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.BlockyGraphData.Load
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f974
	// Params: [ Num(0) Size(0x0) ]
	void Load();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A385D8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A31E54
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x106A3640C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.JumpToFocusSlotByIdStrAndIdx
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4f840
	// Params: [ Num(3) Size(0x20) ]
	struct UBlockBase* JumpToFocusSlotByIdStrAndIdx(struct FString blockId, uint8_t idx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106A3CC0C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106A385D8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.JumpToFocusSlotByIdStr
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4f6b4
	// Params: [ Num(3) Size(0x28) ]
	struct UBlockBase* JumpToFocusSlotByIdStr(struct FString blockId, struct FString TargetSlotIdStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A3C68C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x106A3CC0C

	// Object: Function BlockyLuaCore.BlockyGraphData.JumpToFocusBlockByIdStr
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4f5c0
	// Params: [ Num(2) Size(0x18) ]
	struct UBlockBase* JumpToFocusBlockByIdStr(struct FString blockId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C30C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106A3C68C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x100036FE0
	// [Call #27] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.BlockyGraphData.ItemHasOpend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f4cc
	// Params: [ Num(2) Size(0x11) ]
	bool ItemHasOpend(struct FString ItemStringName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A40244
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106A3C30C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.IsGraphChanged
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f498
	// Params: [ Num(1) Size(0x1) ]
	bool IsGraphChanged();
	// [Call #1] RVA: 0x106A38A04
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x106A40244
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106A3C30C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.IsFirstGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f464
	// Params: [ Num(1) Size(0x1) ]
	bool IsFirstGraph();
	// [Call #1] RVA: 0x106A29FCC
	// [Call #2] RVA: 0x106A38A04
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106A40244
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106A3C30C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.IsBlockGuideButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f430
	// Params: [ Num(1) Size(0x1) ]
	bool IsBlockGuideButton();
	// [Call #1] RVA: 0x106A27284
	// [Call #2] RVA: 0x106A29FCC
	// [Call #3] RVA: 0x106A38A04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A40244
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106A3C30C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.HasExecutableCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f3fc
	// Params: [ Num(1) Size(0x1) ]
	bool HasExecutableCode();
	// [Call #1] RVA: 0x106A3D8EC
	// [Call #2] RVA: 0x106A27284
	// [Call #3] RVA: 0x106A29FCC
	// [Call #4] RVA: 0x106A38A04
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x106A40244
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x106A3C30C

	// Object: Function BlockyLuaCore.BlockyGraphData.GM_LoadGraph_DS_FromFiles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f300
	// Params: [ Num(3) Size(0x21) ]
	bool GM_LoadGraph_DS_FromFiles(struct FString GraphFilePath, struct FString GlobalVarsFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A3BB78
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A3D8EC
	// [Call #12] RVA: 0x106A27284
	// [Call #13] RVA: 0x106A29FCC
	// [Call #14] RVA: 0x106A38A04
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C

	// Object: Function BlockyLuaCore.BlockyGraphData.GM_LoadGraph_DS
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f2ec
	// Params: [ Num(0) Size(0x0) ]
	void GM_LoadGraph_DS();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A3BB78
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A3D8EC
	// [Call #12] RVA: 0x106A27284
	// [Call #13] RVA: 0x106A29FCC
	// [Call #14] RVA: 0x106A38A04
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GM_GenerateAllBlocks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f238
	// Params: [ Num(2) Size(0x8) ]
	void GM_GenerateAllBlocks(int CombinedBlocksNum, int GraphBlocksNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A39F28
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A3BB78
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A3D8EC
	// [Call #17] RVA: 0x106A27284
	// [Call #18] RVA: 0x106A29FCC

	// Object: Function BlockyLuaCore.BlockyGraphData.GetTriggerList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b4f1d4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetTriggerList();
	// [Call #1] RVA: 0x106A2A330
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A39F28
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A3BB78
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A3D8EC

	// Object: Function BlockyLuaCore.BlockyGraphData.GetTLogType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f170
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetTLogType();
	// [Call #1] RVA: 0x106A39DB8
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A2A330
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A39F28
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A3BB78
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetTLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f10c
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, struct FString> GetTLog();
	// [Call #1] RVA: 0x106A39C48
	// [Call #2] RVA: 0x102BF5308
	// [Call #3] RVA: 0x101F87D64
	// [Call #4] RVA: 0x101F87D64
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A39DB8
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A2A330
	// [Call #12] RVA: 0x101FA5F38
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A39F28
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetQuoteVariableItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4f058
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct UBlockBase*> GetQuoteVariableItem(struct UBlockyGraph* Graph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A27F60
	// [Call #4] RVA: 0x106B5350C
	// [Call #5] RVA: 0x1023089C4
	// [Call #6] RVA: 0x1023089C4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A39C48
	// [Call #9] RVA: 0x102BF5308
	// [Call #10] RVA: 0x101F87D64
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A39DB8
	// [Call #14] RVA: 0x101FA5F38
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106A2A330
	// [Call #19] RVA: 0x101FA5F38
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x101F8B9F8
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.GetQuoteVariableGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4efa4
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct UBlockyGraph*> GetQuoteVariableGraph(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A27300
	// [Call #4] RVA: 0x106B54024
	// [Call #5] RVA: 0x106A47364
	// [Call #6] RVA: 0x106A47364
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A27F60
	// [Call #11] RVA: 0x106B5350C
	// [Call #12] RVA: 0x1023089C4
	// [Call #13] RVA: 0x1023089C4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106A39C48
	// [Call #16] RVA: 0x102BF5308
	// [Call #17] RVA: 0x101F87D64
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x106A39DB8
	// [Call #21] RVA: 0x101FA5F38
	// [Call #22] RVA: 0x101F8B9F8
	// [Call #23] RVA: 0x101F8B9F8
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetPresetDescArray
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4eee8
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct UPresetDesc*> GetPresetDescArray(bool LocalOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A359D0
	// [Call #4] RVA: 0x10242FAE8
	// [Call #5] RVA: 0x1023089F4
	// [Call #6] RVA: 0x1023089F4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A27300
	// [Call #11] RVA: 0x106B54024
	// [Call #12] RVA: 0x106A47364
	// [Call #13] RVA: 0x106A47364
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A27F60
	// [Call #18] RVA: 0x106B5350C
	// [Call #19] RVA: 0x1023089C4
	// [Call #20] RVA: 0x1023089C4
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x106A39C48

	// Object: Function BlockyLuaCore.BlockyGraphData.GetNewBlocksNumWithMenu
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4edf4
	// Params: [ Num(2) Size(0x14) ]
	int GetNewBlocksNumWithMenu(struct FString menuItemName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A2B46C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A359D0
	// [Call #15] RVA: 0x10242FAE8
	// [Call #16] RVA: 0x1023089F4
	// [Call #17] RVA: 0x1023089F4
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A27300
	// [Call #22] RVA: 0x106B54024
	// [Call #23] RVA: 0x106A47364

	// Object: Function BlockyLuaCore.BlockyGraphData.GetIsDisableComment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4edc0
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsDisableComment();
	// [Call #1] RVA: 0x106A402F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x106A2B46C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A359D0
	// [Call #16] RVA: 0x10242FAE8
	// [Call #17] RVA: 0x1023089F4
	// [Call #18] RVA: 0x1023089F4
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetGraphStrings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ed5c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FGraphString> GetGraphStrings();
	// [Call #1] RVA: 0x106A3E74C
	// [Call #2] RVA: 0x106B542F0
	// [Call #3] RVA: 0x106A483C0
	// [Call #4] RVA: 0x106A483C0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A402F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A2B46C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A359D0
	// [Call #21] RVA: 0x10242FAE8
	// [Call #22] RVA: 0x1023089F4
	// [Call #23] RVA: 0x1023089F4
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetGraphMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ecf8
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, struct FString> GetGraphMap();
	// [Call #1] RVA: 0x106A29FDC
	// [Call #2] RVA: 0x102BF5308
	// [Call #3] RVA: 0x101F87D64
	// [Call #4] RVA: 0x101F87D64
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A3E74C
	// [Call #7] RVA: 0x106B542F0
	// [Call #8] RVA: 0x106A483C0
	// [Call #9] RVA: 0x106A483C0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A402F0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106A2B46C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetFunctionDescArray
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ec94
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UFunctionDesc*> GetFunctionDescArray();
	// [Call #1] RVA: 0x106A3D354
	// [Call #2] RVA: 0x106B542A0
	// [Call #3] RVA: 0x106A484E4
	// [Call #4] RVA: 0x106A484E4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A29FDC
	// [Call #7] RVA: 0x102BF5308
	// [Call #8] RVA: 0x101F87D64
	// [Call #9] RVA: 0x101F87D64
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A3E74C
	// [Call #12] RVA: 0x106B542F0
	// [Call #13] RVA: 0x106A483C0
	// [Call #14] RVA: 0x106A483C0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A402F0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106A2B46C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetDeleteBlockUIRect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ec1c
	// Params: [ Num(1) Size(0x4) ]
	void GetDeleteBlockUIRect(float InRectWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A3D354
	// [Call #4] RVA: 0x106B542A0
	// [Call #5] RVA: 0x106A484E4
	// [Call #6] RVA: 0x106A484E4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A29FDC
	// [Call #9] RVA: 0x102BF5308
	// [Call #10] RVA: 0x101F87D64
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A3E74C
	// [Call #14] RVA: 0x106B542F0
	// [Call #15] RVA: 0x106A483C0
	// [Call #16] RVA: 0x106A483C0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106A402F0
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCustomVariableStrings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ebb8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FCustomVariableString> GetCustomVariableStrings();
	// [Call #1] RVA: 0x106A3DB9C
	// [Call #2] RVA: 0x106B54228
	// [Call #3] RVA: 0x106A48494
	// [Call #4] RVA: 0x106A48494
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A3D354
	// [Call #9] RVA: 0x106B542A0
	// [Call #10] RVA: 0x106A484E4
	// [Call #11] RVA: 0x106A484E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A29FDC
	// [Call #14] RVA: 0x102BF5308
	// [Call #15] RVA: 0x101F87D64
	// [Call #16] RVA: 0x101F87D64
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106A3E74C
	// [Call #19] RVA: 0x106B542F0
	// [Call #20] RVA: 0x106A483C0
	// [Call #21] RVA: 0x106A483C0
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106A402F0

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCustomNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4eb54
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FText> GetCustomNames();
	// [Call #1] RVA: 0x106A2C490
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A3DB9C
	// [Call #7] RVA: 0x106B54228
	// [Call #8] RVA: 0x106A48494
	// [Call #9] RVA: 0x106A48494
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A3D354
	// [Call #14] RVA: 0x106B542A0
	// [Call #15] RVA: 0x106A484E4
	// [Call #16] RVA: 0x106A484E4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106A29FDC
	// [Call #19] RVA: 0x102BF5308
	// [Call #20] RVA: 0x101F87D64
	// [Call #21] RVA: 0x101F87D64
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106A3E74C
	// [Call #24] RVA: 0x106B542F0
	// [Call #25] RVA: 0x106A483C0

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCustomEventConfigs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ea98
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct UCustomConfig*> GetCustomEventConfigs(bool isCloudGameEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A2276C
	// [Call #4] RVA: 0x106B54164
	// [Call #5] RVA: 0x106A48514
	// [Call #6] RVA: 0x106A48514
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A2C490
	// [Call #9] RVA: 0x106B541B4
	// [Call #10] RVA: 0x1037BBE68
	// [Call #11] RVA: 0x1037BBE68
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A3DB9C
	// [Call #14] RVA: 0x106B54228
	// [Call #15] RVA: 0x106A48494
	// [Call #16] RVA: 0x106A48494
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A3D354
	// [Call #21] RVA: 0x106B542A0
	// [Call #22] RVA: 0x106A484E4
	// [Call #23] RVA: 0x106A484E4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCustomConfigStrings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ea34
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FCustomConfigString> GetCustomConfigStrings();
	// [Call #1] RVA: 0x106A3E48C
	// [Call #2] RVA: 0x106B540EC
	// [Call #3] RVA: 0x106A48444
	// [Call #4] RVA: 0x106A48444
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2276C
	// [Call #9] RVA: 0x106B54164
	// [Call #10] RVA: 0x106A48514
	// [Call #11] RVA: 0x106A48514
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106A2C490
	// [Call #14] RVA: 0x106B541B4
	// [Call #15] RVA: 0x1037BBE68
	// [Call #16] RVA: 0x1037BBE68
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106A3DB9C
	// [Call #19] RVA: 0x106B54228
	// [Call #20] RVA: 0x106A48494
	// [Call #21] RVA: 0x106A48494
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCurrentGraphBlockyNumberByType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e9a8
	// Params: [ Num(2) Size(0x8) ]
	int GetCurrentGraphBlockyNumberByType(uint8_t Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A393AC
	// [Call #4] RVA: 0x106A3E48C
	// [Call #5] RVA: 0x106B540EC
	// [Call #6] RVA: 0x106A48444
	// [Call #7] RVA: 0x106A48444
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A2276C
	// [Call #12] RVA: 0x106B54164
	// [Call #13] RVA: 0x106A48514
	// [Call #14] RVA: 0x106A48514
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A2C490
	// [Call #17] RVA: 0x106B541B4
	// [Call #18] RVA: 0x1037BBE68
	// [Call #19] RVA: 0x1037BBE68
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A3DB9C
	// [Call #22] RVA: 0x106B54228
	// [Call #23] RVA: 0x106A48494

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCurrentGraph
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4e974
	// Params: [ Num(1) Size(0x8) ]
	struct UBlockyGraph* GetCurrentGraph();
	// [Call #1] RVA: 0x106A08FE4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A393AC
	// [Call #5] RVA: 0x106A3E48C
	// [Call #6] RVA: 0x106B540EC
	// [Call #7] RVA: 0x106A48444
	// [Call #8] RVA: 0x106A48444
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A2276C
	// [Call #13] RVA: 0x106B54164
	// [Call #14] RVA: 0x106A48514
	// [Call #15] RVA: 0x106A48514
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106A2C490
	// [Call #18] RVA: 0x106B541B4
	// [Call #19] RVA: 0x1037BBE68
	// [Call #20] RVA: 0x1037BBE68
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCurrentBlockyNumByMune
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e878
	// Params: [ Num(3) Size(0x24) ]
	int GetCurrentBlockyNumByMune(struct FString Menu, struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A38DF8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A08FE4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A393AC
	// [Call #15] RVA: 0x106A3E48C
	// [Call #16] RVA: 0x106B540EC
	// [Call #17] RVA: 0x106A48444
	// [Call #18] RVA: 0x106A48444
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetCacheData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b4e814
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, struct FString> GetCacheData();
	// [Call #1] RVA: 0x106A20DD4
	// [Call #2] RVA: 0x102BF5308
	// [Call #3] RVA: 0x101F87D64
	// [Call #4] RVA: 0x101F87D64
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A38DF8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A08FE4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106A393AC
	// [Call #20] RVA: 0x106A3E48C
	// [Call #21] RVA: 0x106B540EC

	// Object: Function BlockyLuaCore.BlockyGraphData.GetBlockyStringDatasInPairWithBlocks
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x106b4e6fc
	// Params: [ Num(2) Size(0x20) ]
	void GetBlockyStringDatasInPairWithBlocks(struct TArray<struct FBlockySlotString>& OutSlotStrings, struct TArray<struct UBlockBase*>& OutBlocks);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A3EF48
	// [Call #6] RVA: 0x1023089C4
	// [Call #7] RVA: 0x106A48370
	// [Call #8] RVA: 0x1023089C4
	// [Call #9] RVA: 0x106A48370
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A20DD4
	// [Call #12] RVA: 0x102BF5308
	// [Call #13] RVA: 0x101F87D64
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A38DF8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetBlockyStringDatasInPair
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4e698
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FBlockySlotString> GetBlockyStringDatasInPair();
	// [Call #1] RVA: 0x106A3EC24
	// [Call #2] RVA: 0x106B54074
	// [Call #3] RVA: 0x106A48370
	// [Call #4] RVA: 0x106A48370
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A3EF48
	// [Call #11] RVA: 0x1023089C4
	// [Call #12] RVA: 0x106A48370
	// [Call #13] RVA: 0x1023089C4
	// [Call #14] RVA: 0x106A48370
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A20DD4
	// [Call #17] RVA: 0x102BF5308
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x101F87D64
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.GetBlocks
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x106b4e634
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UBlockBase*> GetBlocks();
	// [Call #1] RVA: 0x106A3BFAC
	// [Call #2] RVA: 0x106B5350C
	// [Call #3] RVA: 0x1023089C4
	// [Call #4] RVA: 0x1023089C4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A3EC24
	// [Call #7] RVA: 0x106B54074
	// [Call #8] RVA: 0x106A48370
	// [Call #9] RVA: 0x106A48370
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A3EF48
	// [Call #16] RVA: 0x1023089C4
	// [Call #17] RVA: 0x106A48370
	// [Call #18] RVA: 0x1023089C4
	// [Call #19] RVA: 0x106A48370
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A20DD4
	// [Call #22] RVA: 0x102BF5308
	// [Call #23] RVA: 0x101F87D64
	// [Call #24] RVA: 0x101F87D64
	// [Call #25] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetAllBlockyInGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e5d0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UBlockBase*> GetAllBlockyInGraph();
	// [Call #1] RVA: 0x106A39E14
	// [Call #2] RVA: 0x106B5350C
	// [Call #3] RVA: 0x1023089C4
	// [Call #4] RVA: 0x1023089C4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A3BFAC
	// [Call #7] RVA: 0x106B5350C
	// [Call #8] RVA: 0x1023089C4
	// [Call #9] RVA: 0x1023089C4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A3EC24
	// [Call #12] RVA: 0x106B54074
	// [Call #13] RVA: 0x106A48370
	// [Call #14] RVA: 0x106A48370
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A3EF48
	// [Call #21] RVA: 0x1023089C4
	// [Call #22] RVA: 0x106A48370
	// [Call #23] RVA: 0x1023089C4
	// [Call #24] RVA: 0x106A48370
	// [Call #25] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.GetAllBlockIdStrings
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4e56c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetAllBlockIdStrings();
	// [Call #1] RVA: 0x106A3CFA4
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A39E14
	// [Call #7] RVA: 0x106B5350C
	// [Call #8] RVA: 0x1023089C4
	// [Call #9] RVA: 0x1023089C4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A3BFAC
	// [Call #12] RVA: 0x106B5350C
	// [Call #13] RVA: 0x1023089C4
	// [Call #14] RVA: 0x1023089C4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A3EC24
	// [Call #17] RVA: 0x106B54074
	// [Call #18] RVA: 0x106A48370
	// [Call #19] RVA: 0x106A48370
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.GetAllBlockByKeyName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e508
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, int> GetAllBlockByKeyName();
	// [Call #1] RVA: 0x106A39AE0
	// [Call #2] RVA: 0x1046E75B8
	// [Call #3] RVA: 0x101F81604
	// [Call #4] RVA: 0x101F81604
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A3CFA4
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A39E14
	// [Call #12] RVA: 0x106B5350C
	// [Call #13] RVA: 0x1023089C4
	// [Call #14] RVA: 0x1023089C4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A3BFAC
	// [Call #17] RVA: 0x106B5350C
	// [Call #18] RVA: 0x1023089C4
	// [Call #19] RVA: 0x1023089C4
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A3EC24
	// [Call #22] RVA: 0x106B54074
	// [Call #23] RVA: 0x106A48370
	// [Call #24] RVA: 0x106A48370
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.FocusToSlotByBlockySlotId
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4e3f8
	// Params: [ Num(2) Size(0x40) ]
	struct UBlockBase* FocusToSlotByBlockySlotId(struct FBlockySlotString SlotID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102448844
	// [Call #4] RVA: 0x106A3F104
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A39AE0
	// [Call #12] RVA: 0x1046E75B8
	// [Call #13] RVA: 0x101F81604
	// [Call #14] RVA: 0x101F81604
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A3CFA4
	// [Call #17] RVA: 0x101FA5F38
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A39E14
	// [Call #22] RVA: 0x106B5350C
	// [Call #23] RVA: 0x1023089C4
	// [Call #24] RVA: 0x1023089C4
	// [Call #25] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.FocusToSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e2d4
	// Params: [ Num(2) Size(0x18) ]
	void FocusToSlot(struct UBlockBase* TargetBlock, struct FString TargetSlotIdStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106A332C0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102448844
	// [Call #17] RVA: 0x106A3F104
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8CAC8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.FocusTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e258
	// Params: [ Num(1) Size(0x8) ]
	void FocusTo(struct UBlockBase* TargetBlock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A33230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106A332C0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102448844
	// [Call #20] RVA: 0x106A3F104
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyGraphData.FinishVariableEdit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e188
	// Params: [ Num(2) Size(0x2) ]
	void FinishVariableEdit(bool bSaveVar, bool bReEdit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A25908
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A33230
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106A332C0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.BlockyGraphData.FinishCustomEdit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e104
	// Params: [ Num(1) Size(0x1) ]
	void FinishCustomEdit(bool bSave);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A25ACC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A25908
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A33230
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.FinishBlockSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4e080
	// Params: [ Num(1) Size(0x1) ]
	void FinishBlockSetting(bool bSaveVar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A27230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A25ACC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A25908
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A33230

	// Object: Function BlockyLuaCore.BlockyGraphData.FindBlockByIdStr
	// Flags: [Final|Native|Public]
	// Offset: 0x106b4df8c
	// Params: [ Num(2) Size(0x18) ]
	struct UBlockBase* FindBlockByIdStr(struct FString blockId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.EmptyListItemSeleceted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4df78
	// Params: [ Num(0) Size(0x0) ]
	void EmptyListItemSeleceted();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC
	// [Call #18] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.Eject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4df64
	// Params: [ Num(0) Size(0x0) ]
	void Eject();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC

	// Object: Function BlockyLuaCore.BlockyGraphData.EditVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4df50
	// Params: [ Num(0) Size(0x0) ]
	void EditVariable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC

	// Object: Function BlockyLuaCore.BlockyGraphData.EditCustumBlockGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4df3c
	// Params: [ Num(0) Size(0x0) ]
	void EditCustumBlockGraph();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC

	// Object: Function BlockyLuaCore.BlockyGraphData.EditCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4df28
	// Params: [ Num(0) Size(0x0) ]
	void EditCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A3C288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A27230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A25ACC

	// Object: Function BlockyLuaCore.BlockyGraphData.DuplicateSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4de44
	// Params: [ Num(1) Size(0x10) ]
	void DuplicateSubGraph(struct FString SrcName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A29A80
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106A3C288
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.DuplicateBlock
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ddc8
	// Params: [ Num(1) Size(0x8) ]
	void DuplicateBlock(struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A2A988
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A29A80
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106A3C288

	// Object: Function BlockyLuaCore.BlockyGraphData.Disable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4ddb4
	// Params: [ Num(0) Size(0x0) ]
	void Disable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A2A988
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A29A80
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteVariableListItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4dd38
	// Params: [ Num(1) Size(0x4) ]
	void DeleteVariableListItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A2A988
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A29A80
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4dd24
	// Params: [ Num(0) Size(0x0) ]
	void DeleteSelected();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A2A988
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A29A80
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4dd10
	// Params: [ Num(0) Size(0x0) ]
	void DeleteCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A2A988
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A29A80
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteBlocks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4dcfc
	// Params: [ Num(0) Size(0x0) ]
	void DeleteBlocks();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A22FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A2A988
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106A29A80
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteBlockInGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4dc48
	// Params: [ Num(2) Size(0x10) ]
	void DeleteBlockInGraph(struct UBlockyGraph* InGraph, struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A21E0C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A22FA8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A2A988
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteBlockAndNextInGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4db94
	// Params: [ Num(2) Size(0x10) ]
	void DeleteBlockAndNextInGraph(struct UBlockyGraph* InGraph, struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A223D4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A21E0C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A22FA8

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteBlockAndNext
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4db18
	// Params: [ Num(1) Size(0x8) ]
	void DeleteBlockAndNext(struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A21908
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A223D4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A21E0C
	// [Call #14] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.DeleteBlock
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4da9c
	// Params: [ Num(1) Size(0x8) ]
	void DeleteBlock(struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A20E2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A21908
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A223D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A21E0C

	// Object: Function BlockyLuaCore.BlockyGraphData.DefineCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4da88
	// Params: [ Num(0) Size(0x0) ]
	void DefineCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A20E2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A21908
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A223D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.Define
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4da74
	// Params: [ Num(0) Size(0x0) ]
	void Define();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A20E2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A21908
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A223D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.CustomNumByType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d9e8
	// Params: [ Num(2) Size(0x8) ]
	int CustomNumByType(enum class ECustomBlockType CustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A2C7BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A20E2C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A21908
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A223D4

	// Object: Function BlockyLuaCore.BlockyGraphData.CurSelectSubBlockyGraphs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d984
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UBlockyGraph*> CurSelectSubBlockyGraphs();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A21908
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.Copy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d970
	// Params: [ Num(0) Size(0x0) ]
	void Copy();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A21908
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.Comment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d95c
	// Params: [ Num(0) Size(0x0) ]
	void Comment();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A21908

	// Object: Function BlockyLuaCore.BlockyGraphData.Clone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d948
	// Params: [ Num(0) Size(0x0) ]
	void Clone();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A21908

	// Object: Function BlockyLuaCore.BlockyGraphData.ClearUndoRedoDatas
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d934
	// Params: [ Num(0) Size(0x0) ]
	void ClearUndoRedoDatas();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A21908

	// Object: Function BlockyLuaCore.BlockyGraphData.ClearTextSizeCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d920
	// Params: [ Num(0) Size(0x0) ]
	void ClearTextSizeCache();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.ClearGraphDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d908
	// Params: [ Num(0) Size(0x0) ]
	void ClearGraphDirty();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.ClearBlockLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d8f4
	// Params: [ Num(0) Size(0x0) ]
	void ClearBlockLog();
	// [Call #1] RVA: 0x106A40260
	// [Call #2] RVA: 0x106B54024
	// [Call #3] RVA: 0x106A47364
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A2C7BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A20E2C
	// [Call #12] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.CheckReports
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d8c0
	// Params: [ Num(1) Size(0x1) ]
	bool CheckReports();
	// [Call #1] RVA: 0x106A3528C
	// [Call #2] RVA: 0x106A40260
	// [Call #3] RVA: 0x106B54024
	// [Call #4] RVA: 0x106A47364
	// [Call #5] RVA: 0x106A47364
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A2C7BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A20E2C

	// Object: Function BlockyLuaCore.BlockyGraphData.AsyncLoadGraphFromBinFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d7d4
	// Params: [ Num(2) Size(0x20) ]
	void AsyncLoadGraphFromBinFile(struct FString FilePath, DelegateProperty Callback);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A31D50
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106A3528C
	// [Call #11] RVA: 0x106A40260
	// [Call #12] RVA: 0x106B54024
	// [Call #13] RVA: 0x106A47364
	// [Call #14] RVA: 0x106A47364
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyGraphData.AddSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d624
	// Params: [ Num(3) Size(0x30) ]
	struct FString AddSubGraph(struct FString InName, struct FString InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A2893C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4
	// [Call #26] RVA: 0x101FD9E48
	// [Call #27] RVA: 0x10516D168
	// [Call #28] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyGraphData.AddOpendNameToArr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d540
	// Params: [ Num(1) Size(0x10) ]
	void AddOpendNameToArr(struct FString ItemStringName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A4019C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106A2893C
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x104EEF504
	// [Call #28] RVA: 0x101F8130C
	// [Call #29] RVA: 0x100036FE0

	// Object: Function BlockyLuaCore.BlockyGraphData.AddGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d3b4
	// Params: [ Num(3) Size(0x28) ]
	struct UBlockyGraph* AddGraph(struct FString InName, struct FString InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A295C8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F8122C
	// [Call #24] RVA: 0x106A4019C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.BlockyGraphData.AddGlobalComment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b4d3a0
	// Params: [ Num(0) Size(0x0) ]
	void AddGlobalComment();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A295C8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F8122C
	// [Call #24] RVA: 0x106A4019C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C
};

// Object: Class BlockyLuaCore.BlockyLuaCommandlet
// Size: 0x80 (Inherited: 0x80)
struct UBlockyLuaCommandlet : UCommandlet
{
};

// Object: Class BlockyLuaCore.BlockyLuaConfig
// Size: 0x15E8 (Inherited: 0x28)
struct UBlockyLuaConfig : UObject
{
	int MaxBlockCount; // 0x28(0x4)
	int MaxBlockCountInGraph; // 0x2C(0x4)
	int MaxBlockCountInViewport; // 0x30(0x4)
	int MaxBlockCountInOneBlock; // 0x34(0x4)
	float BlockOffsetFromBin_X; // 0x38(0x4)
	float BlockOffsetFromBin_Y; // 0x3C(0x4)
	struct TSet<struct FString> DisabledFuncSet; // 0x40(0x50)
	struct TSet<struct FString> BlockReginsSet; // 0x90(0x50)
	bool bShowGuideButton; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
	struct TMap<struct FString, struct FString> ReginsGuideUrlSet; // 0xE8(0x50)
	float GraphMinScale; // 0x138(0x4)
	float GraphMaxScale; // 0x13C(0x4)
	float DragCheckDelta; // 0x140(0x4)
	float EjectOffsetX; // 0x144(0x4)
	float EjectOffsetY; // 0x148(0x4)
	float PasteOffsetMaxCount; // 0x14C(0x4)
	struct FVector2D PasteOffset; // 0x150(0x8)
	struct FVector2D ExecuteableSnapPositionOffset; // 0x158(0x8)
	int DefaultArrayTypeFilterClickType; // 0x160(0x4)
	uint8_t Pad_0x164[0x4]; // 0x164(0x4)
	struct TArray<struct FString> NameInvalidChar; // 0x168(0x10)
	struct FString InvalidTranslateString; // 0x178(0x10)
	struct FString InvalidTranslateMaskString; // 0x188(0x10)
	struct FString ArrayInitStringStart; // 0x198(0x10)
	struct FString ArrayInitStringEnd; // 0x1A8(0x10)
	uint8_t ArrangeMaxTimePerFrame; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x7]; // 0x1B9(0x7)
	struct FSoftObjectPath FontName; // 0x1C0(0x18)
	int FontSize; // 0x1D8(0x4)
	uint8_t Pad_0x1DC[0x4]; // 0x1DC(0x4)
	struct FSlateFontInfo CustomDefaultFont; // 0x1E0(0x58)
	bool UseCustomFont; // 0x238(0x1)
	uint8_t Pad_0x239[0x3]; // 0x239(0x3)
	float RTLYOffset; // 0x23C(0x4)
	float LTRYOffset; // 0x240(0x4)
	struct FVector2D EmblemOffset; // 0x244(0x8)
	float DefaultBlockWidth; // 0x24C(0x4)
	float DefaultBlockHeight; // 0x250(0x4)
	struct FMargin BlockPadding; // 0x254(0x10)
	float BlockIconSize; // 0x264(0x4)
	struct FMargin BlockIconBorder; // 0x268(0x10)
	float BlockButtonSize; // 0x278(0x4)
	float BlockSettingButtonSize; // 0x27C(0x4)
	float BlockButtonClickSize; // 0x280(0x4)
	struct FMargin BlockButtonBorder; // 0x284(0x10)
	struct FMargin BlockTextBorder; // 0x294(0x10)
	struct FMargin BlockSlotBorder; // 0x2A4(0x10)
	float CrossDelta; // 0x2B4(0x4)
	float CornerDelta; // 0x2B8(0x4)
	float VariableIconSize; // 0x2BC(0x4)
	float VariableIconIndent; // 0x2C0(0x4)
	float VariableCopyIconSize; // 0x2C4(0x4)
	struct FVector2D StringInputBlockSize; // 0x2C8(0x8)
	float DefaultSlotWidth; // 0x2D0(0x4)
	float DefaultSlotHeight; // 0x2D4(0x4)
	struct FMargin SlotPadding; // 0x2D8(0x10)
	float SlotIconSize; // 0x2E8(0x4)
	struct FMargin SlotIconBorder; // 0x2EC(0x10)
	float TriangleIconSize; // 0x2FC(0x4)
	struct FMargin SlotTriangleBorder; // 0x300(0x10)
	float WarringIconSize; // 0x310(0x4)
	float ForbiddenIconSize; // 0x314(0x4)
	struct FMargin SlotWarringBorder; // 0x318(0x10)
	struct FMargin SlotForbiddenBorder; // 0x328(0x10)
	struct FMargin SlotTextBorder; // 0x338(0x10)
	float SlotTextSizeRefactor; // 0x348(0x4)
	struct FVector2D ColorBrushSize; // 0x34C(0x8)
	struct FVector2D ColorContentSize; // 0x354(0x8)
	float HookupSlotWidth; // 0x35C(0x4)
	float HookupSlotHeight; // 0x360(0x4)
	float HookupChildIndentation; // 0x364(0x4)
	float HookupLinkWidth; // 0x368(0x4)
	struct FVector2D CommentButtonSize; // 0x36C(0x8)
	struct FVector2D CommentTextSize; // 0x374(0x8)
	struct FVector2D CommentFlodSize; // 0x37C(0x8)
	struct FVector2D CommentTitleSize; // 0x384(0x8)
	float CommentLineLen; // 0x38C(0x4)
	int CommentBlinkCount; // 0x390(0x4)
	float CommentBlinkSpeed; // 0x394(0x4)
	float BlockListWidth; // 0x398(0x4)
	struct FMargin ListBlockSelectedIconPadding; // 0x39C(0x10)
	float ListBlockSelectedIconSize; // 0x3AC(0x4)
	float NextCategoryOffset; // 0x3B0(0x4)
	float NextCategoryOffset_Variable; // 0x3B4(0x4)
	float VarListXOffset; // 0x3B8(0x4)
	float DeleteBlocksYOffset; // 0x3BC(0x4)
	struct FVector2D DeleteBlocksSize; // 0x3C0(0x8)
	struct FVector2D CanDeleteSize; // 0x3C8(0x8)
	struct FVector2D BlockEmblemSize; // 0x3D0(0x8)
	float DisplayViewMaxBlockWidth; // 0x3D8(0x4)
	struct FLinearColor DefaultBackColor; // 0x3DC(0x10)
	struct FLinearColor DarkBackColor; // 0x3EC(0x10)
	struct FLinearColor KeyWordColor; // 0x3FC(0x10)
	struct FLinearColor IllegalWordColor; // 0x40C(0x10)
	struct FLinearColor FunctionBackColor; // 0x41C(0x10)
	float BlockSnapAreaLeft; // 0x42C(0x4)
	float BlockSnapAreaTop; // 0x430(0x4)
	float BlockSnapAreaWidth; // 0x434(0x4)
	float BlockSnapAreaHeight; // 0x438(0x4)
	uint8_t Pad_0x43C[0x4]; // 0x43C(0x4)
	struct FString PreViewMaterial; // 0x440(0x10)
	struct FString LocalizationNameSpace; // 0x450(0x10)
	struct FString DefaultRect; // 0x460(0x10)
	struct FString ActionRect; // 0x470(0x10)
	struct FString ActionRectSelected; // 0x480(0x10)
	struct FString ValueRect; // 0x490(0x10)
	struct FString ValueDisableRect; // 0x4A0(0x10)
	struct FString ValueSelectDisableRect; // 0x4B0(0x10)
	struct FString BoolBlock; // 0x4C0(0x10)
	struct FString BoolBlockEmpty; // 0x4D0(0x10)
	struct FString BoolBlockSelect; // 0x4E0(0x10)
	struct FString BoolBlockDisable; // 0x4F0(0x10)
	struct FString NumBlockEmpty; // 0x500(0x10)
	struct FString NumBlockSelect; // 0x510(0x10)
	struct FString NumBlockDisable; // 0x520(0x10)
	struct FString DeleteBlocksRect; // 0x530(0x10)
	struct FString SnapShowRect; // 0x540(0x10)
	struct FString ListItemSelected; // 0x550(0x10)
	struct FString SingleVarRect; // 0x560(0x10)
	struct FString ArrayVarRect; // 0x570(0x10)
	struct FString CallbackVarRect; // 0x580(0x10)
	struct FString VarRectDisable; // 0x590(0x10)
	struct FString VarOutline; // 0x5A0(0x10)
	struct FString GlobalVarIcon; // 0x5B0(0x10)
	struct FString CanvasVarIcon; // 0x5C0(0x10)
	struct FString LocalVarIcon; // 0x5D0(0x10)
	struct FString CallbackVarIcon; // 0x5E0(0x10)
	struct FString CustomIcon; // 0x5F0(0x10)
	struct FString CustomActionBG; // 0x600(0x10)
	struct FString CustomActionBG_Selected; // 0x610(0x10)
	struct FString CustomActionBG_Gray; // 0x620(0x10)
	struct FString CustomActionBG_Gray_Selected; // 0x630(0x10)
	struct FString CustomValueBG; // 0x640(0x10)
	struct FString CustomValueBG_Selected; // 0x650(0x10)
	struct FString CustomValueBG_Gray; // 0x660(0x10)
	struct FString CustomValueBG_Gray_Selected; // 0x670(0x10)
	struct FString CustomEventBG; // 0x680(0x10)
	struct FString CustomEventBG_Selected; // 0x690(0x10)
	struct FString CustomEventBG_Gray; // 0x6A0(0x10)
	struct FString CustomEventBG_Gray_Selected; // 0x6B0(0x10)
	struct FString CustomBlock_Emblem; // 0x6C0(0x10)
	struct FString CustomBlock_Emblem_Selected; // 0x6D0(0x10)
	struct FString CustomBlock_Emblem_Disable; // 0x6E0(0x10)
	struct FString CustomBlock_Emblem_DisableSelected; // 0x6F0(0x10)
	struct FString EventBlock_Emblem; // 0x700(0x10)
	struct FString EventBlock_Emblem_Selected; // 0x710(0x10)
	struct FString EventBlock_Emblem_Disable; // 0x720(0x10)
	struct FString EventBlock_Emblem_DisableSelected; // 0x730(0x10)
	struct FString LogicUp; // 0x740(0x10)
	struct FString LogicUpSelected; // 0x750(0x10)
	struct FString LogicUpGray; // 0x760(0x10)
	struct FString LogicUpSelectedGray; // 0x770(0x10)
	struct FString LogicMiddle; // 0x780(0x10)
	struct FString LogicMiddleSelected; // 0x790(0x10)
	struct FString LogicBottom; // 0x7A0(0x10)
	struct FString LogicBottomGray; // 0x7B0(0x10)
	struct FString LogicBottomSelected; // 0x7C0(0x10)
	struct FString LogicBottomSelectedGray; // 0x7D0(0x10)
	struct FString LogicSlot; // 0x7E0(0x10)
	struct FString LogicSlotGray; // 0x7F0(0x10)
	struct FString LogicSlotSelected; // 0x800(0x10)
	struct FString LogicSlotSelectedGray; // 0x810(0x10)
	struct FString HookupSlot; // 0x820(0x10)
	struct FString ButtonWithTextBg_Enable; // 0x830(0x10)
	struct FString ButtonWithTextBg_Selected; // 0x840(0x10)
	struct FString ButtonWithTextBg_Disable; // 0x850(0x10)
	struct FString ButtonWithTextBg_DisableSelected; // 0x860(0x10)
	struct FString SlotTriangle; // 0x870(0x10)
	struct FString SlotWarring; // 0x880(0x10)
	struct FString SlotForbidden; // 0x890(0x10)
	struct FString SlotIllegalInput; // 0x8A0(0x10)
	struct FString FunctionIcon; // 0x8B0(0x10)
	struct FString SettingIcon; // 0x8C0(0x10)
	struct FString ColorIcon; // 0x8D0(0x10)
	struct TArray<struct FLinearColor> DefaultHSVs; // 0x8E0(0x10)
	struct FString CopyIcon; // 0x8F0(0x10)
	struct FString CommentIcon; // 0x900(0x10)
	struct FString FlodIcon; // 0x910(0x10)
	struct FString UnbindIcon; // 0x920(0x10)
	struct FString SeparatorIcon; // 0x930(0x10)
	struct FString NoneIcon; // 0x940(0x10)
	struct FString DefaultCategoryIcon; // 0x950(0x10)
	struct FString DefaultCategorySelectedIcon; // 0x960(0x10)
	struct FString BlockyGlobalVarPath; // 0x970(0x10)
	struct FString BlockyGraphPath; // 0x980(0x10)
	struct FString GenerateCodePath; // 0x990(0x10)
	struct FString AssetPackageName; // 0x9A0(0x10)
	struct FString TextrueRectParamPath; // 0x9B0(0x10)
	struct FString FunctionPath; // 0x9C0(0x10)
	struct FString FunctionFolderPath; // 0x9D0(0x10)
	struct FString VariablePath; // 0x9E0(0x10)
	struct FString PresetsPath; // 0x9F0(0x10)
	struct FString PresetsFolderPath; // 0xA00(0x10)
	struct FString AllTypesPath; // 0xA10(0x10)
	struct FString TranslateStringPath; // 0xA20(0x10)
	struct FString BlockyNewStringPath; // 0xA30(0x10)
	struct FString SequencePath; // 0xA40(0x10)
	struct FString TLogParamPath; // 0xA50(0x10)
	int UndoMaxSteps; // 0xA60(0x4)
	int MaxStoredNumOfSearchHistory; // 0xA64(0x4)
	bool SearchUseCase; // 0xA68(0x1)
	uint8_t Pad_0xA69[0x3]; // 0xA69(0x3)
	struct FLinearColor SearchedKeyWordColor; // 0xA6C(0x10)
	int MaxTemplateDescriptionLen; // 0xA7C(0x4)
	float SaveCooldownDuration; // 0xA80(0x4)
	uint8_t Pad_0xA84[0x4]; // 0xA84(0x4)
	struct TMap<struct FString, struct UBrushData*> BlockyBrushDatas; // 0xA88(0x50)
	struct TMap<struct FString, struct FBlockyBrushInfo> BlockyBrushInfos; // 0xAD8(0x50)
	struct TMap<struct FString, struct FString> RTLBrushMap; // 0xB28(0x50)
	struct TArray<struct FString> BlockyBrushNames; // 0xB78(0x10)
	uint8_t Pad_0xB88[0xA0]; // 0xB88(0xA0)
	struct TMap<struct FString, struct UFunctionDesc*> Functions; // 0xC28(0x50)
	struct TMap<struct FString, struct UFunctionDesc*> FuncTemplates; // 0xC78(0x50)
	struct TMap<struct FString, struct UFunctionDesc*> TypeFilterFunctions; // 0xCC8(0x50)
	struct TArray<struct UBlackboardDefiner*> BlackboardDefiners; // 0xD18(0x10)
	struct TMap<struct FString, struct UVarDefiner*> VarDefiners; // 0xD28(0x50)
	struct TMap<struct FString, struct UCustomDefiner*> CustomDefiners; // 0xD78(0x50)
	struct TMap<struct FString, struct UCategoryDefiner*> CategoryDefiners; // 0xDC8(0x50)
	struct TMap<struct FString, struct UEnumDesc*> Enums; // 0xE18(0x50)
	struct TArray<struct UBlockyMenuItemObject*> MenuItems; // 0xE68(0x10)
	struct TMap<struct FString, struct UTypeConvertDesc*> TypeConverts; // 0xE78(0x50)
	struct TMap<struct FString, struct UPresetDesc*> PresetDescMap; // 0xEC8(0x50)
	struct TMap<struct FString, struct UPresetDesc*> CodeNameAndTypeKeyPresetDescMap; // 0xF18(0x50)
	struct TMap<struct FString, struct FPresetTypeData> TypeNameKeyPresetDescMap; // 0xF68(0x50)
	struct TArray<struct UBlockyMenuItemObject*> PresetMenuItems; // 0xFB8(0x10)
	struct TArray<struct UBlockyGraph*> TemplateGraphs; // 0xFC8(0x10)
	struct TSet<struct FString> AllTypes; // 0xFD8(0x50)
	struct TSet<struct FString> CustomVarTypes; // 0x1028(0x50)
	struct TMap<struct FString, struct FString> TipsMap; // 0x1078(0x50)
	struct TMap<struct FString, bool> BlockyNewsMap; // 0x10C8(0x50)
	struct TMap<struct FString, struct FString> TLogParamsMap; // 0x1118(0x50)
	struct TMap<struct FString, struct FString> TLogParamsTypeMap; // 0x1168(0x50)
	struct TArray<struct FString> MenuSequence; // 0x11B8(0x10)
	struct TMap<struct FString, struct FSequence> CategorySequence; // 0x11C8(0x50)
	struct TMap<struct FString, struct FSequence> ItemSequence; // 0x1218(0x50)
	uint8_t Pad_0x1268[0x18]; // 0x1268(0x18)
	struct FSlateFontInfo FontInfo; // 0x1280(0x58)
	uint8_t Pad_0x12D8[0x8]; // 0x12D8(0x8)
	struct TMap<struct FString, struct UVarDefiner*> AllTypesMap; // 0x12E0(0x50)
	struct TMap<struct FGuid, DelegateProperty> OnReceiveCheckStringResults; // 0x1330(0x50)
	DelegateProperty OnGetLocaleString; // 0x1380(0x10)
	DelegateProperty OnCallCustomSelectObject; // 0x1390(0x10)
	DelegateProperty OnReceiveCustomSelectObject; // 0x13A0(0x10)
	DelegateProperty OnCheckShowCustomSelection; // 0x13B0(0x10)
	DelegateProperty OnShowPresetPanelHandler; // 0x13C0(0x10)
	DelegateProperty OnCheckShowPresetFilterBtn; // 0x13D0(0x10)
	DelegateProperty OnModifyTip; // 0x13E0(0x10)
	DelegateProperty OnAddBlockyLog; // 0x13F0(0x10)
	DelegateProperty OnGetValidString; // 0x1400(0x10)
	DelegateProperty OnCheckStringValid; // 0x1410(0x10)
	DelegateProperty OnMessageData; // 0x1420(0x10)
	DelegateProperty OnIsCurrentCultureLTR; // 0x1430(0x10)
	DelegateProperty OnGetTextLen; // 0x1440(0x10)
	DelegateProperty OnPlayPresetSound; // 0x1450(0x10)
	DelegateProperty OnOpenGuide; // 0x1460(0x10)
	DelegateProperty OnSetGraphSetting; // 0x1470(0x10)
	DelegateProperty OnGetBlockNewState; // 0x1480(0x10)
	DelegateProperty OnSetBlockNewState; // 0x1490(0x10)
	DelegateProperty OnGetSearchHistorys; // 0x14A0(0x10)
	DelegateProperty OnSetSearchHistorys; // 0x14B0(0x10)
	DelegateProperty OnGetUrlIconAsset; // 0x14C0(0x10)
	DelegateProperty OnCallUrlIconAssetToLoad; // 0x14D0(0x10)
	DelegateProperty OnCallPresetSelectedCode; // 0x14E0(0x10)
	DelegateProperty OnGetPresetValidityDuration; // 0x14F0(0x10)
	DelegateProperty OnCallShortCutKey; // 0x1500(0x10)
	DelegateProperty OnUndoCustomCommand; // 0x1510(0x10)
	uint8_t Pad_0x1520[0x70]; // 0x1520(0x70)
	struct UHotfixUtility* HotfixUtility; // 0x1590(0x8)
	uint8_t Pad_0x1598[0x50]; // 0x1598(0x50)


	// Object: Function BlockyLuaCore.BlockyLuaConfig.SetCustomDefaultFont
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x106b5955c
	// Params: [ Num(1) Size(0x58) ]
	void SetCustomDefaultFont(struct FSlateFontInfo& DefaultFont);
	// [Call #1] RVA: 0x1051E3694
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A65724
	// [Call #5] RVA: 0x10206BEBC
	// [Call #6] RVA: 0x10206BEBC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.ReplaceChCharToMaskChar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b5948c
	// Params: [ Num(2) Size(0x20) ]
	struct FString ReplaceChCharToMaskChar(struct FString Source);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6535C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1051E3694
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A65724
	// [Call #14] RVA: 0x10206BEBC
	// [Call #15] RVA: 0x10206BEBC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.PlayPresetSound
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x106b593a8
	// Params: [ Num(1) Size(0x10) ]
	void PlayPresetSound(struct FString SoundPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A403A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A6535C
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1051E3694
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x106A65724
	// [Call #25] RVA: 0x10206BEBC

	// Object: Function BlockyLuaCore.BlockyLuaConfig.IsNameStringValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b59248
	// Params: [ Num(2) Size(0x11) ]
	bool IsNameStringValid(struct FString NameString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104EC51F4
	// [Call #4] RVA: 0x104EC3578
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106A403A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.IsBlackboardVar
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x106b591bc
	// Params: [ Num(2) Size(0x9) ]
	bool IsBlackboardVar(struct UVarDefiner* Definer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A65804
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104EC51F4
	// [Call #7] RVA: 0x104EC3578
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaConfig.GetValidString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b58e24
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetValidString(struct FString CheckString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F81474
	// [Call #4] RVA: 0x101F8145C
	// [Call #5] RVA: 0x101F81474
	// [Call #6] RVA: 0x101F814E8
	// [Call #7] RVA: 0x104ED8004
	// [Call #8] RVA: 0x101F814E8
	// [Call #9] RVA: 0x101F8145C
	// [Call #10] RVA: 0x101F81474
	// [Call #11] RVA: 0x101F814E8
	// [Call #12] RVA: 0x104ED8004
	// [Call #13] RVA: 0x101F814E8
	// [Call #14] RVA: 0x106C8DCEC
	// [Call #15] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.GetTranslateStringTest
	// Flags: [Final|Native|Public]
	// Offset: 0x106b58d54
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateStringTest(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B5BABC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F81474
	// [Call #13] RVA: 0x101F8145C
	// [Call #14] RVA: 0x101F81474
	// [Call #15] RVA: 0x101F814E8
	// [Call #16] RVA: 0x104ED8004
	// [Call #17] RVA: 0x101F814E8
	// [Call #18] RVA: 0x101F8145C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.GetTranslateString
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b58c48
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F87A78
	// [Call #4] RVA: 0x106A650F0
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B5BABC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaConfig.GetLocaleString
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b58b78
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetLocaleString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A650F0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F87A78
	// [Call #13] RVA: 0x106A650F0
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x106B5BABC

	// Object: Function BlockyLuaCore.BlockyLuaConfig.GetBlackboardDefiner
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x106b58aec
	// Params: [ Num(2) Size(0x10) ]
	struct UBlackboardDefiner* GetBlackboardDefiner(struct UVarDefiner* Definer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A65790
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A650F0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F87A78
	// [Call #16] RVA: 0x106A650F0
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.ClearCustomDefaultFont
	// Flags: [Final|Native|Public]
	// Offset: 0x106b58ad8
	// Params: [ Num(0) Size(0x0) ]
	void ClearCustomDefaultFont();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A65790
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A650F0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F87A78
	// [Call #16] RVA: 0x106A650F0
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.ClearAsyncTextureHandleMap
	// Flags: [Final|Native|Public]
	// Offset: 0x106b58ac4
	// Params: [ Num(0) Size(0x0) ]
	void ClearAsyncTextureHandleMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A65790
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A650F0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F87A78
	// [Call #16] RVA: 0x106A650F0
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyLuaConfig.CheckStringValidTest
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x106b589d4
	// Params: [ Num(2) Size(0x28) ]
	void CheckStringValidTest(struct FString CheckString, struct FCheckStringHandleData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A65FE0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A65790
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A650F0
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
};

// Object: Class BlockyLuaCore.BlockyLuaGameInstance
// Size: 0x2E8 (Inherited: 0x2E8)
struct UBlockyLuaGameInstance : UGameInstance
{
};

// Object: Class BlockyLuaCore.BlockyLuaUtility
// Size: 0x28 (Inherited: 0x28)
struct UBlockyLuaUtility : UBlueprintFunctionLibrary
{

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteUInt8
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b6226c
	// Params: [ Num(2) Size(0x9) ]
	void WriteUInt8(struct FBlockyLuaHandle ar, uint8_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1ADF8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteUInt64
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b621c0
	// Params: [ Num(2) Size(0x10) ]
	void WriteUInt64(struct FBlockyLuaHandle ar, uint64_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AE88
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1ADF8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteUInt32
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b62110
	// Params: [ Num(2) Size(0xC) ]
	void WriteUInt32(struct FBlockyLuaHandle ar, uint32_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AE58
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AE88
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1ADF8
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteUInt16
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b62060
	// Params: [ Num(2) Size(0xA) ]
	void WriteUInt16(struct FBlockyLuaHandle ar, uint16_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AE28
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AE58
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AE88
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteString
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61f44
	// Params: [ Num(2) Size(0x18) ]
	void WriteString(struct FBlockyLuaHandle ar, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1AD04
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1AE28
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteSingle
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61e94
	// Params: [ Num(2) Size(0xC) ]
	void WriteSingle(struct FBlockyLuaHandle ar, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AEB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1AD04
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteObjectPtr
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61de8
	// Params: [ Num(2) Size(0x10) ]
	void WriteObjectPtr(struct FBlockyLuaHandle ar, struct UObject* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AF48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AEB8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B1AD04
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteInt8
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61d38
	// Params: [ Num(2) Size(0x9) ]
	void WriteInt8(struct FBlockyLuaHandle ar, uint8_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AD38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AF48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AEB8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteInt64
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61c8c
	// Params: [ Num(2) Size(0x10) ]
	void WriteInt64(struct FBlockyLuaHandle ar, int64_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1ADC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AD38
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AF48
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteInt32
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61bdc
	// Params: [ Num(2) Size(0xC) ]
	void WriteInt32(struct FBlockyLuaHandle ar, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AD98
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1ADC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AD38
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteInt16
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61b2c
	// Params: [ Num(2) Size(0xA) ]
	void WriteInt16(struct FBlockyLuaHandle ar, int16_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AD68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AD98
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1ADC8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteHandle
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61a80
	// Params: [ Num(2) Size(0x10) ]
	void WriteHandle(struct FBlockyLuaHandle ar, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AF18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AD68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AD98
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteDouble
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b619d0
	// Params: [ Num(2) Size(0x10) ]
	void WriteDouble(struct FBlockyLuaHandle ar, double Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AEE8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AF18
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AD68
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.WriteBool
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61918
	// Params: [ Num(2) Size(0x9) ]
	void WriteBool(struct FBlockyLuaHandle ar, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AD08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AEE8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AF18
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadUInt8
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b6189c
	// Params: [ Num(2) Size(0x9) ]
	uint8_t ReadUInt8(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AB60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1AD08
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1AEE8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadUInt64
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61820
	// Params: [ Num(2) Size(0x10) ]
	uint64_t ReadUInt64(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1ABD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AB60
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1AD08
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1AEE8

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadUInt32
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b617a4
	// Params: [ Num(2) Size(0xC) ]
	uint32_t ReadUInt32(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1ABB0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1ABD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AB60
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1AD08

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadUInt16
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61728
	// Params: [ Num(2) Size(0xA) ]
	uint16_t ReadUInt16(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AB88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1ABB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1ABD8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AB60
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadString
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61684
	// Params: [ Num(2) Size(0x18) ]
	struct FString ReadString(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AA54
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1AB88
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1ABB0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1ABD8
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadSingle
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61608
	// Params: [ Num(2) Size(0xC) ]
	float ReadSingle(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AC00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AA54
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1AB88
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1ABB0
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadObjectPtr
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b6158c
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* ReadObjectPtr(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AC78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AC00
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AA54
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1AB88
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadInt8
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61510
	// Params: [ Num(2) Size(0x9) ]
	uint8_t ReadInt8(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AAC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AC78
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AC00
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AA54
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadInt64
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61494
	// Params: [ Num(2) Size(0x10) ]
	int64_t ReadInt64(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AB38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AAC0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AC78
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AC00
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadInt32
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61418
	// Params: [ Num(2) Size(0xC) ]
	int ReadInt32(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AB10
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AB38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AAC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AC78
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AC00

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadInt16
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b6139c
	// Params: [ Num(2) Size(0xA) ]
	int16_t ReadInt16(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AAE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AB10
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AB38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AAC0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AC78

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadHandle
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61320
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle ReadHandle(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AC50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AAE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AB10
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AB38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AAC0

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadDouble
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b612a4
	// Params: [ Num(2) Size(0x10) ]
	double ReadDouble(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AC28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AC50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AAE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AB10
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AB38

	// Object: Function BlockyLuaCore.BlockyLuaUtility.ReadBool
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61228
	// Params: [ Num(2) Size(0x9) ]
	bool ReadBool(struct FBlockyLuaHandle ar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AA90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AC28
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AC50
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AAE8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AB10

	// Object: Function BlockyLuaCore.BlockyLuaUtility.DestroyReturnWriter
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b611b4
	// Params: [ Num(1) Size(0x8) ]
	void DestroyReturnWriter(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1ACF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AA90
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AC28
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AC50
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AAE8

	// Object: Function BlockyLuaCore.BlockyLuaUtility.DestroyArgumentsReader
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61140
	// Params: [ Num(1) Size(0x8) ]
	void DestroyArgumentsReader(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AA3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1ACF0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AA90
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AC28
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AC50

	// Object: Function BlockyLuaCore.BlockyLuaUtility.CreateReturnWriter
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b610c4
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreateReturnWriter(struct FBlockyLuaHandle stubHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1AC9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AA3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1ACF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1AA90
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AC28

	// Object: Function BlockyLuaCore.BlockyLuaUtility.CreateArgumentsReader
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x106b61048
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreateArgumentsReader(struct FBlockyLuaHandle stubHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1A9F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AC9C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1AA3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1ACF0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1AA90
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject
// Size: 0x128 (Inherited: 0x28)
struct UBlockyMenuItemObject : UObject
{
	struct FText Name; // 0x28(0x18)
	struct TArray<struct UBlockyCategoryItemObject*> Categories; // 0x40(0x10)
	int CurrentCategoryIndex; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString DrawType; // 0x58(0x10)
	int DrawTopDelta; // 0x68(0x4)
	int DrawBottomDelta; // 0x6C(0x4)
	struct FString IconType; // 0x70(0x10)
	struct FString Type; // 0x80(0x10)
	bool Visible; // 0x90(0x1)
	bool VisibleByTag; // 0x91(0x1)
	uint8_t Pad_0x92[0x2]; // 0x92(0x2)
	float ItemInterval; // 0x94(0x4)
	float LineInterval; // 0x98(0x4)
	float VariableItemInterval; // 0x9C(0x4)
	float PaddingLeft; // 0xA0(0x4)
	struct FLinearColor CategoryStringColor; // 0xA4(0x10)
	uint8_t Pad_0xB4[0x10]; // 0xB4(0x10)
	float CategoryHeight; // 0xC4(0x4)
	float VariableCategoryHeight; // 0xC8(0x4)
	struct FLinearColor ItemStringColor; // 0xCC(0x10)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
	struct UBlockyGraphData* GraphData; // 0xE0(0x8)
	bool bShowRedDot; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
	struct UBrushData* DefaultRectBrush; // 0xF0(0x8)
	struct UBrushData* CurrentItemBrush; // 0xF8(0x8)
	struct UBrushData* CurrentIconBrush; // 0x100(0x8)
	struct UBrushData* SelectedIconBrush; // 0x108(0x8)
	uint8_t Pad_0x110[0x18]; // 0x110(0x18)


	// Object: Function BlockyLuaCore.BlockyMenuItemObject.SetShowRedDotVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b62ce4
	// Params: [ Num(1) Size(0x1) ]
	void SetShowRedDotVar(bool var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B2A520
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject.InitShowRedDotVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b62cd0
	// Params: [ Num(0) Size(0x0) ]
	void InitShowRedDotVar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B2A520
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject_BP
// Size: 0x138 (Inherited: 0x128)
struct UBlockyMenuItemObject_BP : UBlockyMenuItemObject
{
	struct UUserWidget* WidgetBP; // 0x128(0x8)
	bool bHideCategory; // 0x130(0x1)
	uint8_t Pad_0x131[0x7]; // 0x131(0x7)
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject_Custom
// Size: 0x138 (Inherited: 0x128)
struct UBlockyMenuItemObject_Custom : UBlockyMenuItemObject
{
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)


	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Custom.NewCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b630c4
	// Params: [ Num(0) Size(0x0) ]
	void NewCustom();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x1051903D0
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Custom.IsCurrentCategoryEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b63090
	// Params: [ Num(1) Size(0x1) ]
	bool IsCurrentCategoryEmpty();
	// [Call #1] RVA: 0x106B2B9F8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x1051903D0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Custom.GetCustomType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b6305c
	// Params: [ Num(1) Size(0x1) ]
	enum class ECustomBlockType GetCustomType();
	// [Call #1] RVA: 0x106B2B910
	// [Call #2] RVA: 0x106B2B9F8
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x1051903D0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Custom.ClosePopUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b63048
	// Params: [ Num(0) Size(0x0) ]
	void ClosePopUp();
	// [Call #1] RVA: 0x106B2B910
	// [Call #2] RVA: 0x106B2B9F8
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x1051903D0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject_Search
// Size: 0x190 (Inherited: 0x128)
struct UBlockyMenuItemObject_Search : UBlockyMenuItemObject
{
	struct FString SearchStr; // 0x128(0x10)
	uint8_t Pad_0x138[0x58]; // 0x138(0x58)
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject_TypeFilter
// Size: 0x128 (Inherited: 0x128)
struct UBlockyMenuItemObject_TypeFilter : UBlockyMenuItemObject
{
};

// Object: Class BlockyLuaCore.BlockyMenuItemObject_Variable
// Size: 0x160 (Inherited: 0x128)
struct UBlockyMenuItemObject_Variable : UBlockyMenuItemObject
{
	enum class EBlockyAccessType Access; // 0x128(0x1)
	enum class EBlockyAccessType CurSelectAccess; // 0x129(0x1)
	bool IsCustomVar; // 0x12A(0x1)
	enum class EBlockListShowType ShowType; // 0x12B(0x1)
	int TopCategory; // 0x12C(0x4)
	uint8_t Pad_0x130[0x10]; // 0x130(0x10)
	bool IsShowAllVariableItem; // 0x140(0x1)
	uint8_t Pad_0x141[0x1F]; // 0x141(0x1F)


	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.NewVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b638f8
	// Params: [ Num(0) Size(0x0) ]
	void NewVariable();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.NewCustomVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b638e4
	// Params: [ Num(0) Size(0x0) ]
	void NewCustomVariable();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.IsSlotCustomVarToShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b638b0
	// Params: [ Num(1) Size(0x1) ]
	bool IsSlotCustomVarToShow();
	// [Call #1] RVA: 0x106B2CEC4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.IsPlayerBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b6387c
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlayerBlackboard();
	// [Call #1] RVA: 0x106B2CF88
	// [Call #2] RVA: 0x106B2CEC4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.IsCurrentCategoryEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b63848
	// Params: [ Num(1) Size(0x1) ]
	bool IsCurrentCategoryEmpty();
	// [Call #1] RVA: 0x106B2CD7C
	// [Call #2] RVA: 0x106B2CF88
	// [Call #3] RVA: 0x106B2CEC4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.IsBlackBoardVariable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b63814
	// Params: [ Num(1) Size(0x1) ]
	bool IsBlackBoardVariable();
	// [Call #1] RVA: 0x106B2CD44
	// [Call #2] RVA: 0x106B2CD7C
	// [Call #3] RVA: 0x106B2CF88
	// [Call #4] RVA: 0x106B2CEC4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.FilterBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b63790
	// Params: [ Num(1) Size(0x1) ]
	void FilterBlackboard(bool bIsPlayerVar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B2CF60
	// [Call #4] RVA: 0x106B2CD44
	// [Call #5] RVA: 0x106B2CD7C
	// [Call #6] RVA: 0x106B2CF88
	// [Call #7] RVA: 0x106B2CEC4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.FilterAccess
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b63714
	// Params: [ Num(1) Size(0x1) ]
	void FilterAccess(enum class EBlockyAccessType InAccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B2CD98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B2CF60
	// [Call #7] RVA: 0x106B2CD44
	// [Call #8] RVA: 0x106B2CD7C
	// [Call #9] RVA: 0x106B2CF88
	// [Call #10] RVA: 0x106B2CEC4
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.BlockyMenuItemObject_Variable.CanSeeCustomVar
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b635e8
	// Params: [ Num(3) Size(0x3) ]
	void CanSeeCustomVar(bool& IsConfigContain, bool& IsOnlyShowCustom, bool& IsHiddenCustom);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B2CDA0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B2CD98
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B2CF60
	// [Call #14] RVA: 0x106B2CD44
};

// Object: Class BlockyLuaCore.BlockyMoveCommandData
// Size: 0x38 (Inherited: 0x30)
struct UBlockyMoveCommandData : UBlockyCommandData
{
	struct FBlockPoint Position; // 0x30(0x8)
};

// Object: Class BlockyLuaCore.ExeSequencerBase
// Size: 0x638 (Inherited: 0x430)
struct UExeSequencerBase : UExecuteable
{
	struct UBrushData* SlotBrush; // 0x430(0x8)
	struct UBrushData* TailBrush; // 0x438(0x8)
	uint8_t Pad_0x440[0x1F8]; // 0x440(0x1F8)
};

// Object: Class BlockyLuaCore.BlockyTimer
// Size: 0xE40 (Inherited: 0x638)
struct UBlockyTimer : UExeSequencerBase
{
	uint8_t Pad_0x638[0x800]; // 0x638(0x800)
	struct UBrushData* IconBrush; // 0xE38(0x8)
};

// Object: Class BlockyLuaCore.BlockyTimerParam
// Size: 0x208 (Inherited: 0x200)
struct UBlockyTimerParam : UBlockBase
{
	struct UBlockyTimer* HostTimer; // 0x200(0x8)
};

// Object: Class BlockyLuaCore.Break
// Size: 0x430 (Inherited: 0x430)
struct UBreak : UExecuteable
{
};

// Object: Class BlockyLuaCore.BrushData
// Size: 0x108 (Inherited: 0x28)
struct UBrushData : UObject
{
	struct FSlateBrush Brush; // 0x28(0xB8)
	struct UTexture2D* Texture; // 0xE0(0x8)
	float Angle; // 0xE8(0x4)
	struct FVector2D RectSize; // 0xEC(0x8)
	int CrossDelta; // 0xF4(0x4)
	uint8_t Pad_0xF8[0x10]; // 0xF8(0x10)
};

// Object: Class BlockyLuaCore.CallFunction
// Size: 0x6C8 (Inherited: 0x430)
struct UCallFunction : UExecuteable
{
	uint8_t Pad_0x430[0x20]; // 0x430(0x20)
	struct UBrushData* IconBrush; // 0x450(0x8)
	struct UBrushData* SelectionBG; // 0x458(0x8)
	uint8_t Pad_0x460[0x268]; // 0x460(0x268)
};

// Object: Class BlockyLuaCore.CastExpression
// Size: 0x28 (Inherited: 0x28)
struct UCastExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.CastExpression.SetTargetType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b64594
	// Params: [ Num(2) Size(0x10) ]
	void SetTargetType(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B10C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CastExpression.SetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b644e8
	// Params: [ Num(2) Size(0x10) ]
	void SetExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B1B4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1B10C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CastExpression.GetTargetType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6446c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetTargetType(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B040
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1B1B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1B10C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.CastExpression.GetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b643f0
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B040
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1B1B4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1B10C

	// Object: Function BlockyLuaCore.CastExpression.CreateCastExpression2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6433c
	// Params: [ Num(3) Size(0x18) ]
	struct FBlockyLuaHandle CreateCastExpression2(struct FBlockyLuaHandle TargetType, struct FBlockyLuaHandle expression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1AFB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1B104
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1B040
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1B1B4

	// Object: Function BlockyLuaCore.CastExpression.CreateCastExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b64308
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateCastExpression();
	// [Call #1] RVA: 0x106B1AF78
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1AFB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1B104
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1B040
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.ClassReferenceExpression
// Size: 0x28 (Inherited: 0x28)
struct UClassReferenceExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.ClassReferenceExpression.SetClass
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b64ba8
	// Params: [ Num(2) Size(0x10) ]
	void SetClass(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle klass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B268
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.ClassReferenceExpression.GetClass
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b64b2c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetClass(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B260
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1B268
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ClassReferenceExpression.CreateClassReferenceExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b64ab0
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreateClassReferenceExpression(struct FBlockyLuaHandle klass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B218
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B260
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1B268
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.ObjectDesc
// Size: 0x28 (Inherited: 0x28)
struct UObjectDesc : UObject
{
};

// Object: Class BlockyLuaCore.ColorDesc
// Size: 0x280 (Inherited: 0x28)
struct UColorDesc : UObjectDesc
{
	struct FString KeyName; // 0x28(0x10)
	struct FString Name; // 0x38(0x10)
	struct FString CodeName; // 0x48(0x10)
	struct FText Menu; // 0x58(0x18)
	struct FText Category; // 0x70(0x18)
	struct FLinearColor Color; // 0x88(0x10)
	bool IsSelected; // 0x98(0x1)
	uint8_t Pad_0x99[0x17]; // 0x99(0x17)
	bool Visible; // 0xB0(0x1)
	bool Removed; // 0xB1(0x1)
	bool Localed; // 0xB2(0x1)
	uint8_t Pad_0xB3[0x1CD]; // 0xB3(0x1CD)


	// Object: Function BlockyLuaCore.ColorDesc.NameContainsString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b64f84
	// Params: [ Num(2) Size(0x11) ]
	bool NameContainsString(struct FString filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC3704
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ColorDesc.IsNameEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b64f60
	// Params: [ Num(1) Size(0x1) ]
	bool IsNameEmpty();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC3704
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ColorDesc.IsCodeNameEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b64f3c
	// Params: [ Num(1) Size(0x1) ]
	bool IsCodeNameEmpty();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC3704
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ColorDesc.GetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b64f20
	// Params: [ Num(1) Size(0x70) ]
	struct FType GetType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC3704
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ColorDesc.GetLocaleName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b64ebc
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLocaleName();
	// [Call #1] RVA: 0x106AC36D0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106AC3704
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ColorDesc.GetHSVStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b64e58
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetHSVStr();
	// [Call #1] RVA: 0x106AC3670
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106AC36D0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106AC3704
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ColorDesc.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106b64e3c
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetColor();
	// [Call #1] RVA: 0x106AC3670
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106AC36D0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106AC3704
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.CommentBlock
// Size: 0x538 (Inherited: 0x430)
struct UCommentBlock : UExecuteable
{
	uint8_t Pad_0x430[0xF0]; // 0x430(0xF0)
	struct UBlockBase* CandidateParentBlock; // 0x520(0x8)
	uint8_t Pad_0x528[0x10]; // 0x528(0x10)
};

// Object: Class BlockyLuaCore.CommonUIFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCommonUIFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.VarDefinerTypeCanBeArray
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b6640c
	// Params: [ Num(2) Size(0x9) ]
	bool VarDefinerTypeCanBeArray(struct UVarDefiner* Definer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6CA88
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.SetIsVirtualKeyboardVisible
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b66390
	// Params: [ Num(1) Size(0x1) ]
	void SetIsVirtualKeyboardVisible(bool Visible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6DEA0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A6CA88
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.LimitTextLength
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b6622c
	// Params: [ Num(4) Size(0x39) ]
	bool LimitTextLength(struct FText& InputText, int MaxCharCount, struct FText& OutText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104F0F380
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106A6D554
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A6DEA0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A6CA88

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.LimitTextEmojiInput
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b66158
	// Params: [ Num(2) Size(0x30) ]
	struct FText LimitTextEmojiInput(struct FText& InputText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A6D720
	// [Call #5] RVA: 0x104F0F4CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104F0F380
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106A6D554
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.IsNameStringValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b660c0
	// Params: [ Num(2) Size(0x11) ]
	bool IsNameStringValid(struct FString NameString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6CF7C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A6D720
	// [Call #11] RVA: 0x104F0F4CC
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x104F0F380
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.IsFuncDisabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65fdc
	// Params: [ Num(2) Size(0x11) ]
	bool IsFuncDisabled(struct FString FuncName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A6DE68
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A6CF7C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104F0F380
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A6D720
	// [Call #22] RVA: 0x104F0F4CC
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x101FBDBE8
	// [Call #26] RVA: 0x101FBDBE8
	// [Call #27] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.IsDeveloperMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65fa8
	// Params: [ Num(1) Size(0x1) ]
	bool IsDeveloperMode();
	// [Call #1] RVA: 0x106A6D070
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x106A6DE68
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A6CF7C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x104F0F380
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x106A6D720
	// [Call #23] RVA: 0x104F0F4CC
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x101FBDBE8

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetTranslateString_BP
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65ee8
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateString_BP(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6CE88
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106A6D070
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106A6DE68
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x106A6CF7C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetTranslateString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65e28
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6CE54
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A6CE88
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x106A6D070
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x101F8122C
	// [Call #23] RVA: 0x106A6DE68
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetTextLen
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65d7c
	// Params: [ Num(2) Size(0x1C) ]
	int GetTextLen(struct FText& Text);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A6DC34
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A6CE54
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106A6CE88
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x106A6D070

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetPresetDescs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b65cd8
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct UPresetDesc*> GetPresetDescs(struct UVarDefiner* Definer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6C7A4
	// [Call #4] RVA: 0x10242FAE8
	// [Call #5] RVA: 0x1023089F4
	// [Call #6] RVA: 0x1023089F4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x104F0F380
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A6DC34
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A6CE54
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetLocaleText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65c04
	// Params: [ Num(2) Size(0x30) ]
	struct FText GetLocaleText(struct FText& KeyString);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A6CF24
	// [Call #5] RVA: 0x104F0F4CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A6C7A4
	// [Call #14] RVA: 0x10242FAE8
	// [Call #15] RVA: 0x1023089F4
	// [Call #16] RVA: 0x1023089F4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104F0F380
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106A6DC34
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetLocaleString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65b44
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetLocaleString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6CE20
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106A6CF24
	// [Call #14] RVA: 0x104F0F4CC
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x106A6C7A4
	// [Call #23] RVA: 0x10242FAE8
	// [Call #24] RVA: 0x1023089F4
	// [Call #25] RVA: 0x1023089F4
	// [Call #26] RVA: 0x106C8459C
	// [Call #27] RVA: 0x104F0F380

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetIsVirtualKeyboardVisible
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65b10
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsVirtualKeyboardVisible();
	// [Call #1] RVA: 0x106A6E028
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A6CE20
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106A6CF24
	// [Call #15] RVA: 0x104F0F4CC
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x106A6C7A4
	// [Call #24] RVA: 0x10242FAE8
	// [Call #25] RVA: 0x1023089F4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetCustomVarNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65adc
	// Params: [ Num(1) Size(0x4) ]
	int GetCustomVarNum();
	// [Call #1] RVA: 0x106A6E73C
	// [Call #2] RVA: 0x106A6E028
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A6CE20
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A6CF24
	// [Call #16] RVA: 0x104F0F4CC
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetArrayInitStringStart
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65a78
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetArrayInitStringStart();
	// [Call #1] RVA: 0x106A6DDB0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A6E73C
	// [Call #7] RVA: 0x106A6E028
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A6CE20
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A6CF24
	// [Call #21] RVA: 0x104F0F4CC
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x101FBDBE8

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetArrayInitStringEnd
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65a14
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetArrayInitStringEnd();
	// [Call #1] RVA: 0x106A6DE0C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A6DDB0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A6E73C
	// [Call #12] RVA: 0x106A6E028
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A6CE20
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104F0F380
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GetAllDefiners
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b659b0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UVarDefiner*> GetAllDefiners();
	// [Call #1] RVA: 0x106A6C63C
	// [Call #2] RVA: 0x106B68A38
	// [Call #3] RVA: 0x106A9EAF0
	// [Call #4] RVA: 0x106A9EAF0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A6DE0C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A6DDB0
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A6E73C
	// [Call #17] RVA: 0x106A6E028
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106A6CE20
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.GenerateNextNameWithSuffix
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65838
	// Params: [ Num(4) Size(0x38) ]
	struct FString GenerateNextNameWithSuffix(struct TArray<struct FString>& ExistingNames, struct FString InputName, bool InDuplicate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106A6D078
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A6C63C
	// [Call #17] RVA: 0x106B68A38
	// [Call #18] RVA: 0x106A9EAF0
	// [Call #19] RVA: 0x106A9EAF0
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x106A6DE0C
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.FormatNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65778
	// Params: [ Num(2) Size(0x20) ]
	struct FString FormatNumber(struct FString Input);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6E140
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A6D078
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8B9F8
	// [Call #24] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.DisplayNameToTranslate
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b656d4
	// Params: [ Num(2) Size(0x18) ]
	struct FString DisplayNameToTranslate(struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6E868
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A6E140
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.CollectAllObjects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b656c0
	// Params: [ Num(0) Size(0x0) ]
	void CollectAllObjects();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A6E868
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A6E140
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.CheckNameValid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65568
	// Params: [ Num(3) Size(0x29) ]
	bool CheckNameValid(struct FString InName, struct FText& ErrorMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106A6CB3C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106A6E868
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.CommonUIFunctionLibrary.CheckNameHasInvalidChar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b65484
	// Params: [ Num(2) Size(0x11) ]
	bool CheckNameHasInvalidChar(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106A6CD2C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F380
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106A6CB3C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101FBDBE8
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C
};

// Object: Class BlockyLuaCore.ConfigDataAsset
// Size: 0x130 (Inherited: 0x30)
struct UConfigDataAsset : UDataAsset
{
	struct FString AllType; // 0x30(0x10)
	struct FString TextureRectParam; // 0x40(0x10)
	struct FString Function; // 0x50(0x10)
	struct TArray<struct FString> FunctionList; // 0x60(0x10)
	struct FString Variable; // 0x70(0x10)
	struct FString Sequence; // 0x80(0x10)
	struct FString Preset; // 0x90(0x10)
	struct TMap<struct FString, struct FString> PresetMap; // 0xA0(0x50)
	struct FString TranslateString; // 0xF0(0x10)
	struct TArray<struct FString> ModeList; // 0x100(0x10)
	struct FString BlockyNew; // 0x110(0x10)
	struct FString TLogParams; // 0x120(0x10)


	// Object: Function BlockyLuaCore.ConfigDataAsset.SaveToAsset
	// Flags: [Final|Native|Public]
	// Offset: 0x106b66c7c
	// Params: [ Num(1) Size(0x10) ]
	void SaveToAsset(struct FString PackageName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A8BD44
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.Continue
// Size: 0x430 (Inherited: 0x430)
struct UContinue : UExecuteable
{
};

// Object: Class BlockyLuaCore.CreateFunction
// Size: 0x6E0 (Inherited: 0x6C8)
struct UCreateFunction : UCallFunction
{
	uint8_t Pad_0x6C8[0x18]; // 0x6C8(0x18)
};

// Object: Class BlockyLuaCore.CreateObjectExpression
// Size: 0x28 (Inherited: 0x28)
struct UCreateObjectExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.CreateObjectExpression.SetTypeName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b673bc
	// Params: [ Num(2) Size(0x18) ]
	void SetTypeName(struct FBlockyLuaHandle ptr, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1B4A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CreateObjectExpression.SetParameters
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b672a0
	// Params: [ Num(2) Size(0x18) ]
	void SetParameters(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1B4AC
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x106B1B4A4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CreateObjectExpression.GetTypeName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b671fc
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetTypeName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B380
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B68AD8
	// [Call #13] RVA: 0x106B1B4AC
	// [Call #14] RVA: 0x106B43E9C
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106B43E9C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x106B43E9C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.CreateObjectExpression.GetParameters
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b67158
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetParameters(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B3D4
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1B380
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B68AD8
	// [Call #20] RVA: 0x106B1B4AC
	// [Call #21] RVA: 0x106B43E9C
	// [Call #22] RVA: 0x106B43E9C
	// [Call #23] RVA: 0x106B43E9C
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0

	// Object: Function BlockyLuaCore.CreateObjectExpression.CreateCreateObjectExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b67074
	// Params: [ Num(2) Size(0x18) ]
	struct FBlockyLuaHandle CreateCreateObjectExpression(struct FString TypeName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B1B320
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1B3D4
	// [Call #15] RVA: 0x106B68A88
	// [Call #16] RVA: 0x106B43E9C
	// [Call #17] RVA: 0x106B43E9C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1B380
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
};

// Object: Class BlockyLuaCore.CreateSubDefineFunction
// Size: 0x9A0 (Inherited: 0x638)
struct UCreateSubDefineFunction : UExeSequencerBase
{
	uint8_t Pad_0x638[0x360]; // 0x638(0x360)
	struct UBrushData* IconBrush; // 0x998(0x8)
};

// Object: Class BlockyLuaCore.CustomAction
// Size: 0x488 (Inherited: 0x430)
struct UCustomAction : UExecuteable
{
	uint8_t Pad_0x430[0x8]; // 0x430(0x8)
	struct UCustomConfig* Config; // 0x438(0x8)
	struct FGuid ConfigName; // 0x440(0x10)
	struct UBrushData* BrushBGSelected; // 0x450(0x8)
	struct UBrushData* IconBrush; // 0x458(0x8)
	struct UBrushData* BrushBG; // 0x460(0x8)
	uint8_t Pad_0x468[0x20]; // 0x468(0x20)
};

// Object: Class BlockyLuaCore.CustomActionImp
// Size: 0x678 (Inherited: 0x638)
struct UCustomActionImp : UExeSequencerBase
{
	uint8_t Pad_0x638[0x18]; // 0x638(0x18)
	struct UCustomConfig* Config; // 0x650(0x8)
	struct FGuid ConfigName; // 0x658(0x10)
	struct UBrushData* IconBrush; // 0x668(0x8)
	struct UBrushData* BrushBG; // 0x670(0x8)
};

// Object: Class BlockyLuaCore.CustomParam
// Size: 0x70 (Inherited: 0x28)
struct UCustomParam : UObject
{
	struct FString Name; // 0x28(0x10)
	struct FString Description; // 0x38(0x10)
	bool bIsArray; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
	struct UVarDefiner* Definer; // 0x50(0x8)
	uint8_t Pad_0x58[0x18]; // 0x58(0x18)


	// Object: Function BlockyLuaCore.CustomParam.CopyFrom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67a98
	// Params: [ Num(1) Size(0x8) ]
	void CopyFrom(struct UCustomParam* Other);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A7EDAC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x106B680E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106A7F094
};

// Object: Class BlockyLuaCore.CustomConfig
// Size: 0xA0 (Inherited: 0x28)
struct UCustomConfig : UObject
{
	struct FGuid Name; // 0x28(0x10)
	struct FString DisplayName; // 0x38(0x10)
	enum class ECustomBlockType Type; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
	struct FString Description; // 0x50(0x10)
	struct TArray<struct UCustomParam*> Params; // 0x60(0x10)
	struct UCustomParam* Return; // 0x70(0x8)
	struct UFunctionDesc* CustomDesc; // 0x78(0x8)
	struct UFunctionDesc* CustomImplDesc; // 0x80(0x8)
	uint8_t Pad_0x88[0x18]; // 0x88(0x18)


	// Object: Function BlockyLuaCore.CustomConfig.UpdateDesc
	// Flags: [Final|Native|Public]
	// Offset: 0x106b67eac
	// Params: [ Num(0) Size(0x0) ]
	void UpdateDesc();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CustomConfig.SetParamNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67e30
	// Params: [ Num(1) Size(0x4) ]
	void SetParamNum(int paramNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A7EF34
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CustomConfig.InitResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67dfc
	// Params: [ Num(1) Size(0x8) ]
	struct UCustomParam* InitResult();
	// [Call #1] RVA: 0x106A7F064
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A7EF34
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CustomConfig.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67de8
	// Params: [ Num(0) Size(0x0) ]
	void Init();
	// [Call #1] RVA: 0x106A7F064
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A7EF34
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CustomConfig.GetParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67d5c
	// Params: [ Num(2) Size(0x10) ]
	struct UCustomParam* GetParam(int idx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A7EFEC
	// [Call #4] RVA: 0x106A7F064
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106A7EF34
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CustomConfig.GetCustomGraphName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b67cf8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCustomGraphName();
	// [Call #1] RVA: 0x106A7BF50
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A7EFEC
	// [Call #9] RVA: 0x106A7F064
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A7EF34
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function BlockyLuaCore.CustomConfig.CopyFrom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b67c7c
	// Params: [ Num(1) Size(0x8) ]
	void CopyFrom(struct UCustomConfig* Other);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A7F094
	// [Call #4] RVA: 0x106A7BF50
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106A7EFEC
	// [Call #12] RVA: 0x106A7F064
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106A7EF34
};

// Object: Class BlockyLuaCore.CustomInterface
// Size: 0x28 (Inherited: 0x28)
struct ICustomInterface : IInterface
{
};

// Object: Class BlockyLuaCore.CustomDefiner
// Size: 0xE8 (Inherited: 0xB8)
struct UCustomDefiner : UCategoryDefiner
{
	struct FString HotfixUserData; // 0xB8(0x10)
	struct FString TemplateFunc; // 0xC8(0x10)
	struct FString TemplateImplFunc; // 0xD8(0x10)
};

// Object: Class BlockyLuaCore.DefineFunction
// Size: 0x480 (Inherited: 0x430)
struct UDefineFunction : UExecuteable
{
	struct FText Name; // 0x430(0x18)
	uint8_t Pad_0x448[0x38]; // 0x448(0x38)
};

// Object: Class BlockyLuaCore.CustomEvent
// Size: 0x500 (Inherited: 0x480)
struct UCustomEvent : UDefineFunction
{
	uint8_t Pad_0x480[0x8]; // 0x480(0x8)
	struct UCustomConfig* Config; // 0x488(0x8)
	struct FGuid ConfigName; // 0x490(0x10)
	struct UBrushData* IconBrush; // 0x4A0(0x8)
	struct UBrushData* BrushBG; // 0x4A8(0x8)
	uint8_t Pad_0x4B0[0x50]; // 0x4B0(0x50)
};

// Object: Class BlockyLuaCore.CustomImpInterface
// Size: 0x28 (Inherited: 0x28)
struct ICustomImpInterface : IInterface
{
};

// Object: Class BlockyLuaCore.CustomValue
// Size: 0x250 (Inherited: 0x200)
struct UCustomValue : UVarBase
{
	uint8_t Pad_0x200[0x8]; // 0x200(0x8)
	struct UCustomConfig* Config; // 0x208(0x8)
	struct FGuid ConfigName; // 0x210(0x10)
	struct UBrushData* BrushBGSelected; // 0x220(0x8)
	struct UBrushData* BrushBG; // 0x228(0x8)
	uint8_t Pad_0x230[0x20]; // 0x230(0x20)
};

// Object: Class BlockyLuaCore.CustomValueImp
// Size: 0x810 (Inherited: 0x638)
struct UCustomValueImp : UExeSequencerBase
{
	uint8_t Pad_0x638[0x1B0]; // 0x638(0x1B0)
	struct UCustomConfig* Config; // 0x7E8(0x8)
	struct FGuid ConfigName; // 0x7F0(0x10)
	struct UBrushData* IconBrush; // 0x800(0x8)
	struct UBrushData* BrushBG; // 0x808(0x8)
};

// Object: Class BlockyLuaCore.DefaultValueCommandData
// Size: 0x88 (Inherited: 0x30)
struct UDefaultValueCommandData : UBlockyCommandData
{
	uint8_t Pad_0x30[0x58]; // 0x30(0x58)
};

// Object: Class BlockyLuaCore.DefaultValueExpression
// Size: 0x28 (Inherited: 0x28)
struct UDefaultValueExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.DefaultValueExpression.SetType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6c348
	// Params: [ Num(2) Size(0x10) ]
	void SetType(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B710
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function BlockyLuaCore.DefaultValueExpression.GetType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6c2cc
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetType(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B6AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1B710
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.DefaultValueExpression.CreateDefaultValueExpression2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6c250
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreateDefaultValueExpression2(struct FBlockyLuaHandle typeRef);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B664
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B6AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1B710
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function BlockyLuaCore.DefaultValueExpression.CreateDefaultValueExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6c1d4
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreateDefaultValueExpression(struct FBlockyLuaHandle typeClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B5E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B664
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1B6AC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1B710
	// [Call #15] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.DoNum
// Size: 0x970 (Inherited: 0x638)
struct UDoNum : UExeSequencerBase
{
	uint8_t Pad_0x638[0x330]; // 0x638(0x330)
	struct UBrushData* IconBrush; // 0x968(0x8)
};

// Object: Class BlockyLuaCore.EnumDesc
// Size: 0xA0 (Inherited: 0x28)
struct UEnumDesc : UObject
{
	struct FString HotfixUserData; // 0x28(0x10)
	struct UEnum* EnumPtr; // 0x38(0x8)
	uint8_t Pad_0x40[0x60]; // 0x40(0x60)
};

// Object: Class BlockyLuaCore.ExecuteablePreview
// Size: 0x460 (Inherited: 0x430)
struct UExecuteablePreview : UExecuteable
{
	struct TArray<struct FBlockPreviewBrush> Rects; // 0x430(0x10)
	struct UBrushData* DisableIconBrush; // 0x440(0x8)
	uint8_t Pad_0x448[0x18]; // 0x448(0x18)
};

// Object: Class BlockyLuaCore.ForEach
// Size: 0xB28 (Inherited: 0x638)
struct UForEach : UExeSequencerBase
{
	uint8_t Pad_0x638[0x4E8]; // 0x638(0x4E8)
	struct UBrushData* IconBrush; // 0xB20(0x8)
};

// Object: Class BlockyLuaCore.FunctionDesc
// Size: 0x248 (Inherited: 0x28)
struct UFunctionDesc : UObject
{
	struct FString HotfixUserData; // 0x28(0x10)
	struct FString KeyName; // 0x38(0x10)
	struct FString CodeName; // 0x48(0x10)
	uint8_t Pad_0x58[0x58]; // 0x58(0x58)
	struct FString Host; // 0xB0(0x10)
	struct FString Description; // 0xC0(0x10)
	uint8_t Pad_0xD0[0x70]; // 0xD0(0x70)
	struct UObject* BlockClass; // 0x140(0x8)
	uint8_t Pad_0x148[0x10]; // 0x148(0x10)
	struct TArray<struct FFunctionParameter> Parameters; // 0x158(0x10)
	struct TArray<struct FFunctionParameter> AddEventParameters; // 0x168(0x10)
	struct TMap<struct FString, struct FString> ModuleRequires; // 0x178(0x50)
	uint8_t Pad_0x1C8[0x80]; // 0x1C8(0x80)


	// Object: Function BlockyLuaCore.FunctionDesc.GetMenu
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b6d3d0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetMenu();
	// [Call #1] RVA: 0x106B784EC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190648
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x106B57610
	// [Call #12] RVA: 0x105185230

	// Object: Function BlockyLuaCore.FunctionDesc.GetCategory
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b6d36c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCategory();
	// [Call #1] RVA: 0x106B78490
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B784EC
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190648
};

// Object: Class BlockyLuaCore.FunctionInvokeArgumentExpression
// Size: 0x28 (Inherited: 0x28)
struct UFunctionInvokeArgumentExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.SetOperationType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6da38
	// Params: [ Num(2) Size(0x9) ]
	void SetOperationType(struct FBlockyLuaHandle ptr, enum class EBlockyFunctionArgumentAttribute Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B8B8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.SetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d98c
	// Params: [ Num(2) Size(0x10) ]
	void SetExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1B854
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1B8B8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.SetAdditionPostCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d870
	// Params: [ Num(2) Size(0x18) ]
	void SetAdditionPostCode(struct FBlockyLuaHandle ptr, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1B8CC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1B854
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.GetOperationType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d7f4
	// Params: [ Num(2) Size(0x9) ]
	enum class EBlockyFunctionArgumentAttribute GetOperationType(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B7EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B1B8CC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1B854

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.GetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d778
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B7E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B7EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106B1B8CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.GetAdditionPostCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d6d4
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetAdditionPostCode(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B800
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1B7E4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1B7EC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C

	// Object: Function BlockyLuaCore.FunctionInvokeArgumentExpression.CreateFunctionInvokeArgumentExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6d6a0
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateFunctionInvokeArgumentExpression();
	// [Call #1] RVA: 0x106B1B7AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1B800
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1B7E4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1B7EC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.FunctionInvokeExpression
// Size: 0x28 (Inherited: 0x28)
struct UFunctionInvokeExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.SetReturnValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e460
	// Params: [ Num(2) Size(0x10) ]
	void SetReturnValue(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1BBF4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.SetHost
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e3b4
	// Params: [ Num(2) Size(0x10) ]
	void SetHost(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1BA50
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1BBF4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.SetFunctionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e298
	// Params: [ Num(2) Size(0x18) ]
	void SetFunctionName(struct FBlockyLuaHandle ptr, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1BAB4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1BA50
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.SetComment
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e1ec
	// Params: [ Num(2) Size(0x10) ]
	void SetComment(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1BC58
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1BAB4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.SetArguments
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e0d0
	// Params: [ Num(2) Size(0x18) ]
	void SetArguments(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1BABC
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1BC58
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.GetReturnValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6e054
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetReturnValue(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BA40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B68AD8
	// [Call #9] RVA: 0x106B1BABC
	// [Call #10] RVA: 0x106B43E9C
	// [Call #11] RVA: 0x106B43E9C
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1BC58

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.GetHost
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6dfd8
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetHost(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B914
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1BA40
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B68AD8
	// [Call #12] RVA: 0x106B1BABC
	// [Call #13] RVA: 0x106B43E9C
	// [Call #14] RVA: 0x106B43E9C
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x106B43E9C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.GetFunctionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6df34
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetFunctionName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B91C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1B914
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1BA40
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B68AD8

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.GetComment
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6deb8
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetComment(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BA48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1B91C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1B914
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1BA40
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.GetArguments
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6de14
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetArguments(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1B970
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1BA48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1B91C
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B1B914

	// Object: Function BlockyLuaCore.FunctionInvokeExpression.CreateFunctionInvokeExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b6dde0
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateFunctionInvokeExpression();
	// [Call #1] RVA: 0x106B1B8D4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1B970
	// [Call #5] RVA: 0x106B68A88
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1BA48
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1B91C
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.GetArrayElement
// Size: 0x3B0 (Inherited: 0x200)
struct UGetArrayElement : UBlockBase
{
	uint8_t Pad_0x200[0x1A8]; // 0x200(0x1A8)
	struct UBrushData* BrushBGSelected; // 0x3A8(0x8)
};

// Object: Class BlockyLuaCore.HotfixUtility
// Size: 0x80 (Inherited: 0x28)
struct UHotfixUtility : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)


	// Object: Function BlockyLuaCore.HotfixUtility.UVarDefiner_GetCurrentLocateShowName
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b766f4
	// Params: [ Num(2) Size(0x18) ]
	struct FString UVarDefiner_GetCurrentLocateShowName(struct UVarDefiner* pThis);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.HotfixUtility.UPresetDesc_GetLocaleName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b76638
	// Params: [ Num(2) Size(0x18) ]
	struct FString UPresetDesc_GetLocaleName(struct UPresetDesc* PresetDesc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.HotfixUtility.UNumFromTo_UpdateParameterDisplayName_Index_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b76524
	// Params: [ Num(3) Size(0x28) ]
	struct FString UNumFromTo_UpdateParameterDisplayName_Index_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UNumFromTo_UpdateParameterDisplayName_CurrNum_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b76410
	// Params: [ Num(3) Size(0x28) ]
	struct FString UNumFromTo_UpdateParameterDisplayName_CurrNum_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UNumFromTo_SetFunctionDesc_NamedVarBlock_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b762ac
	// Params: [ Num(4) Size(0x30) ]
	struct FString UNumFromTo_SetFunctionDesc_NamedVarBlock_DisplayName(struct UFunctionDesc* Desc, int& ParamIdx, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UNumFromTo_InitializeBlock_IndexBlock_Name
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b76198
	// Params: [ Num(3) Size(0x28) ]
	struct FString UNumFromTo_InitializeBlock_IndexBlock_Name(struct UNumFromTo* NumFromTo, struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UNumFromTo_InitializeBlock_CurrentBlock_Name
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b76084
	// Params: [ Num(3) Size(0x28) ]
	struct FString UNumFromTo_InitializeBlock_CurrentBlock_Name(struct UNumFromTo* NumFromTo, struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UNamedVar_UpdateFormater_VarFormatNameText
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75fc8
	// Params: [ Num(2) Size(0x18) ]
	struct FString UNamedVar_UpdateFormater_VarFormatNameText(struct UNamedVar* var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_UpdateParameterDisplayName_ForeachIndex_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75eb4
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_UpdateParameterDisplayName_ForeachIndex_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_UpdateParameterDisplayName_ForeachElement_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75da0
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_UpdateParameterDisplayName_ForeachElement_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_UpdateParameterDisplayName_ElementNormalDisplay
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75c8c
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_UpdateParameterDisplayName_ElementNormalDisplay(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_UpdateParameterDisplayName_ElementDisableDisplay
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75b78
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_UpdateParameterDisplayName_ElementDisableDisplay(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_SetFunctionDesc_ForeachIndex_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75a64
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_SetFunctionDesc_ForeachIndex_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_SetFunctionDesc_ForeachElement_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75950
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_SetFunctionDesc_ForeachElement_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_SetFunctionDesc_ElementNormalDisplay
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b7583c
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_SetFunctionDesc_ElementNormalDisplay(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UForEach_SetFunctionDesc_ElementDisableDisplay
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75728
	// Params: [ Num(3) Size(0x28) ]
	struct FString UForEach_SetFunctionDesc_ElementDisableDisplay(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UExecuteable_SetFunctionDesc_ParamDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b755c4
	// Params: [ Num(4) Size(0x30) ]
	struct FString UExecuteable_SetFunctionDesc_ParamDisplayName(struct UFunctionDesc* Desc, int& ParamIdx, struct FString ParamDisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UEnumDesc_GetCurrentLocaleEnumValueName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b75418
	// Params: [ Num(5) Size(0x38) ]
	struct FString UEnumDesc_GetCurrentLocaleEnumValueName(struct UEnumDesc* EnumDesc, struct FName& enumValueName, struct FString enumValueLocName, bool useDefaultWhenNotFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UEnumDesc_GetCurrentLocaleEnumTypeName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b752bc
	// Params: [ Num(4) Size(0x30) ]
	struct FString UEnumDesc_GetCurrentLocaleEnumTypeName(struct UEnumDesc* EnumDesc, struct FString EnumTypeName, bool useDefaultWhenNotFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UDoNum_UpdateParameterDisplayName_CurrentIndexSlotDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b751a8
	// Params: [ Num(3) Size(0x28) ]
	struct FString UDoNum_UpdateParameterDisplayName_CurrentIndexSlotDisplayName(struct UFunctionDesc* Desc, struct FString CurrentIndexDisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UDoNum_SetFunctionDesc_CurrentIndexSlotDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b75094
	// Params: [ Num(3) Size(0x28) ]
	struct FString UDoNum_SetFunctionDesc_CurrentIndexSlotDisplayName(struct UFunctionDesc* Desc, struct FString CurrentIndexDisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UDefineFunction_SetFunctionDesc_ParamName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b74f30
	// Params: [ Num(4) Size(0x30) ]
	struct FString UDefineFunction_SetFunctionDesc_ParamName(struct UFunctionDesc* Desc, int& ParamIdx, struct FString ParamName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UCommonUIFunctionLibrary_GetTranslateString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74e58
	// Params: [ Num(2) Size(0x20) ]
	struct FString UCommonUIFunctionLibrary_GetTranslateString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UCommonUIFunctionLibrary_GetLocaleString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74d80
	// Params: [ Num(2) Size(0x20) ]
	struct FString UCommonUIFunctionLibrary_GetLocaleString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UColorDesc_GetLocaleName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74ccc
	// Params: [ Num(2) Size(0x18) ]
	struct FString UColorDesc_GetLocaleName(struct UColorDesc* ColorDesc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B26028
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyTimer_UpdateParameterDisplayName_CurrentCount_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74bb8
	// Params: [ Num(3) Size(0x28) ]
	struct FString UBlockyTimer_UpdateParameterDisplayName_CurrentCount_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B26028
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8156C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyTimer_SetFunctionDesc_CurrentCount_DisplayName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74aa4
	// Params: [ Num(3) Size(0x28) ]
	struct FString UBlockyTimer_SetFunctionDesc_CurrentCount_DisplayName(struct UFunctionDesc* Desc, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockySearchWidget_RefreshTabContainerView_ContentName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b749e8
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockySearchWidget_RefreshTabContainerView_ContentName(struct UUserWidget* pThis);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockySearchWidget_RefreshTabContainerView_CategoryName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b748f4
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockySearchWidget_RefreshTabContainerView_CategoryName(struct UUserWidget* pThis, struct UBlockyCategoryItemObject* Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuWidget_UpdateMenus_MenuWidgetName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74800
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockyMenuWidget_UpdateMenus_MenuWidgetName(struct UUserWidget* pThis, struct UBlockyMenuItemObject* MenuItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Search_SearchMatchingResults_ItemObjectString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b7470c
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockyMenuItemObject_Search_SearchMatchingResults_ItemObjectString(struct UBlockyMenuItemObject_Search* MenuItem, struct UBlockyBlockListItemObject* ItemObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Search_PaintSearchedItems_CategoryName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74618
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockyMenuItemObject_Search_PaintSearchedItems_CategoryName(struct UBlockyMenuItemObject_Search* MenuItem, struct UBlockyCategoryItemObject* CategoryItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Search_PaintSearchedContentTitle
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b745ac
	// Params: [ Num(1) Size(0x10) ]
	struct FString UBlockyMenuItemObject_Search_PaintSearchedContentTitle();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Search_GetBlockSearchString_NamedVarName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b744f0
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyMenuItemObject_Search_GetBlockSearchString_NamedVarName(struct UNamedVar* var);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Search_GetBlockSearchString_Block
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74434
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyMenuItemObject_Search_GetBlockSearchString_Block(struct UBlockBase* InBlock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyMenuItemObject_Paint_CategoryName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74340
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockyMenuItemObject_Paint_CategoryName(struct UBlockyMenuItemObject* MenuItem, struct UBlockyCategoryItemObject* CategoryItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyGraphData_GetCustomNames_CustomName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b74284
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyGraphData_GetCustomNames_CustomName(struct UCustomConfig* Custom);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyGraph_LoadGraphFromXnd_OnLocalVarBlockLoaded
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b741c8
	// Params: [ Num(2) Size(0x10) ]
	void UBlockyGraph_LoadGraphFromXnd_OnLocalVarBlockLoaded(struct UBlockyGraph* pThis, struct UNamedVar* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyGraph_LoadGraphFromXnd_OnBlockLoaded
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b7410c
	// Params: [ Num(2) Size(0x10) ]
	void UBlockyGraph_LoadGraphFromXnd_OnBlockLoaded(struct UBlockyGraph* pThis, struct UBlockBase* bLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_TypeFilterMenuName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b73fa8
	// Params: [ Num(4) Size(0x30) ]
	struct FString UBlockyEditor_OnClickSlot_TypeFilterMenuName(struct UBlockBase* slotHost, struct FHotFixSlotHandle& Handle, struct FString menuName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_TypeFilterCategoryName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b73e44
	// Params: [ Num(4) Size(0x30) ]
	struct FString UBlockyEditor_OnClickSlot_TypeFilterCategoryName(struct UBlockBase* slotHost, struct FHotFixSlotHandle& Handle, struct FString CategoryName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_SelectFromSceneWidget_DefaultShowName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b73ce0
	// Params: [ Num(4) Size(0x30) ]
	struct FString UBlockyEditor_OnClickSlot_SelectFromSceneWidget_DefaultShowName(struct UBlockBase* slotHost, struct FHotFixSlotHandle& Handle, struct FString slotCustomClickTypeName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_EnumName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b73b40
	// Params: [ Num(5) Size(0x38) ]
	struct FString UBlockyEditor_OnClickSlot_EnumName(struct UBlockBase* slotHost, struct UEnumDesc* EnumDesc, struct FName& EnumName, struct FString EnumString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_CategoryItemName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b73a2c
	// Params: [ Num(3) Size(0x28) ]
	struct FString UBlockyEditor_OnClickSlot_CategoryItemName(struct UBlockBase* slotHost, struct FString CategoryName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_OnClickSlot_BPMenuItemName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b73918
	// Params: [ Num(3) Size(0x28) ]
	struct FString UBlockyEditor_OnClickSlot_BPMenuItemName(struct UBlockBase* slotHost, struct FString menuName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyEditor_GetLocaleString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b73840
	// Params: [ Num(2) Size(0x20) ]
	struct FString UBlockyEditor_GetLocaleString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyCategoryWidget_FilterWithBlockyMenuItem_WidgetName
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b7374c
	// Params: [ Num(3) Size(0x20) ]
	struct FString UBlockyCategoryWidget_FilterWithBlockyMenuItem_WidgetName(struct UUserWidget* pThis, struct UBlockyCategoryItemObject* Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyBlockListItemObject_Variable_GetStingUsedToSearch
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b73690
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyBlockListItemObject_Variable_GetStingUsedToSearch(struct UBlockyBlockListItemObject_Variable* ItemObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyBlockListItemObject_GetStingUsedToSearch
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b735d4
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyBlockListItemObject_GetStingUsedToSearch(struct UBlockyBlockListItemObject* ItemObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.UBlockyBlockListItemObject_Custom_GetStingUsedToSearch
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b73518
	// Params: [ Num(2) Size(0x18) ]
	struct FString UBlockyBlockListItemObject_Custom_GetStingUsedToSearch(struct UBlockyBlockListItemObject_Custom* ItemObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_IsValidPreset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b73448
	// Params: [ Num(3) Size(0x11) ]
	bool Slot_IsValidPreset(struct FHotFixSlotHandle& Handle, struct UPresetDesc* Preset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27D20
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_IsValidItem
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b73378
	// Params: [ Num(3) Size(0x11) ]
	bool Slot_IsValidItem(struct FHotFixSlotHandle& Handle, struct UBlockyBlockListItemObject* Item);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27D08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B27D20
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_IsValidHandle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b732ec
	// Params: [ Num(2) Size(0x9) ]
	bool Slot_IsValidHandle(struct FHotFixSlotHandle& Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B27D50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27D08
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27D20

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_IsValidBlock
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b7321c
	// Params: [ Num(3) Size(0x11) ]
	bool Slot_IsValidBlock(struct FHotFixSlotHandle& Handle, struct UBlockBase* blk);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27CF0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27D50
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27D08

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_HasClickType
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b7314c
	// Params: [ Num(3) Size(0xD) ]
	bool Slot_HasClickType(struct FHotFixSlotHandle& Handle, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27CD0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B27CF0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27D50

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotPresetDesc
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b730c0
	// Params: [ Num(2) Size(0x10) ]
	struct UPresetDesc* Slot_GetSlotPresetDesc(struct FHotFixSlotHandle& Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B27B04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27CD0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27CF0

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72fbc
	// Params: [ Num(3) Size(0x21) ]
	bool Slot_GetSlotName(struct FHotFixSlotHandle& Handle, struct FText& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B27B9C
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B27B04
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B27CD0

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotItemType
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72eb8
	// Params: [ Num(3) Size(0x79) ]
	bool Slot_GetSlotItemType(struct FHotFixSlotHandle& Handle, struct FType& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106A42EC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B27C0C
	// [Call #7] RVA: 0x106A45834
	// [Call #8] RVA: 0x106A45834
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B27B9C
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotGetColorValue
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72ddc
	// Params: [ Num(3) Size(0x19) ]
	bool Slot_GetSlotGetColorValue(struct FHotFixSlotHandle& Handle, struct FLinearColor& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27B60
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106A42EC8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B27C0C
	// [Call #12] RVA: 0x106A45834
	// [Call #13] RVA: 0x106A45834
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104F0F380

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotDisplayName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72cdc
	// Params: [ Num(3) Size(0x19) ]
	bool Slot_GetSlotDisplayName(struct FHotFixSlotHandle& Handle, struct FString& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27BD4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27B60
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106A42EC8

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotDefaultValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72bdc
	// Params: [ Num(3) Size(0x19) ]
	bool Slot_GetSlotDefaultValue(struct FHotFixSlotHandle& Handle, struct FString& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27B28
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27BD4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotCustomClickTypeName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72adc
	// Params: [ Num(3) Size(0x19) ]
	bool Slot_GetSlotCustomClickTypeName(struct FHotFixSlotHandle& Handle, struct FString& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27C98
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27B28
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotCustomClickType
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b729dc
	// Params: [ Num(3) Size(0x19) ]
	bool Slot_GetSlotCustomClickType(struct FHotFixSlotHandle& Handle, struct FString& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27C60
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27C98
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotColorDesc
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72950
	// Params: [ Num(2) Size(0x10) ]
	struct UColorDesc* Slot_GetSlotColorDesc(struct FHotFixSlotHandle& Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B27B18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27C60
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B27C98

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetSlotClickType
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72870
	// Params: [ Num(3) Size(0xD) ]
	bool Slot_GetSlotClickType(struct FHotFixSlotHandle& Handle, int& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B27C44
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27B18
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27C60
	// [Call #14] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_GetHostBlock
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b727e4
	// Params: [ Num(2) Size(0x10) ]
	struct UBlockBase* Slot_GetHostBlock(struct FHotFixSlotHandle& Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B27AEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B27C44
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B27B18
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.Slot_CanSetBlock
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b726dc
	// Params: [ Num(4) Size(0x19) ]
	bool Slot_CanSetBlock(struct FHotFixSlotHandle& Handle, struct UBlockBase* Host, struct UBlockBase* blk);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B27D38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B27AEC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.SetTypeValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b725f4
	// Params: [ Num(2) Size(0x74) ]
	void SetTypeValue(struct FType& Type, int NewValue);
	// [Call #1] RVA: 0x106A42EC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B27AE4
	// [Call #7] RVA: 0x106A45834
	// [Call #8] RVA: 0x106A45834
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B27D38
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.GetTypeValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b72548
	// Params: [ Num(2) Size(0x74) ]
	int GetTypeValue(struct FType& Type);
	// [Call #1] RVA: 0x106A42EC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B27ADC
	// [Call #5] RVA: 0x106A45834
	// [Call #6] RVA: 0x106A45834
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106A42EC8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B27AE4
	// [Call #14] RVA: 0x106A45834
	// [Call #15] RVA: 0x106A45834
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.HotfixUtility.GetTranslateString_ShowTips
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b72470
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateString_ShowTips(struct FString Tip);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x106A42EC8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B27ADC
	// [Call #13] RVA: 0x106A45834
	// [Call #14] RVA: 0x106A45834
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106A42EC8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B27AE4
	// [Call #22] RVA: 0x106A45834

	// Object: Function BlockyLuaCore.HotfixUtility.GetTranslateString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b72398
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetTranslateString(struct FString String);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106A42EC8
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B27ADC
	// [Call #21] RVA: 0x106A45834
	// [Call #22] RVA: 0x106A45834

	// Object: Function BlockyLuaCore.HotfixUtility.GetDisplayNameString_SlotDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b7221c
	// Params: [ Num(4) Size(0x38) ]
	struct FString GetDisplayNameString_SlotDisplayName(struct FHotFixSlotHandle& Handle, struct FString SlotDisplayName, struct FString SlotName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.FPresetTypeData_GetLocalTypeName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b72130
	// Params: [ Num(2) Size(0x78) ]
	struct FString FPresetTypeData_GetLocalTypeName(struct FPresetTypeData& PresetTypeData);
	// [Call #1] RVA: 0x106A9C194
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106A9C43C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106A9C43C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.FMsgData_CreateMessageData_InfoString_ReplaceTriggerName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b71fb8
	// Params: [ Num(4) Size(0x38) ]
	struct FString FMsgData_CreateMessageData_InfoString_ReplaceTriggerName(struct UFunctionDesc* Desc, struct FString ListItemFormatString, struct FString& InfoString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106A9C194
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106A9C43C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.FMsgData_CreateMessageData_InfoString_ReplaceBlockName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b71e40
	// Params: [ Num(4) Size(0x38) ]
	struct FString FMsgData_CreateMessageData_InfoString_ReplaceBlockName(struct UBlockBase* bLock, struct FString ListItemFormatString, struct FString& InfoString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.FMsgData_CreateMessageData_GetInfoTranslateString
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b71cdc
	// Params: [ Num(4) Size(0x30) ]
	struct FString FMsgData_CreateMessageData_GetInfoTranslateString(struct UBlockBase* bLock, struct FHotFixSlotHandle& Slot, struct FString Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.FLocaleFormatter_UpdateVarFormatters_SeparatorStr
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b71c04
	// Params: [ Num(2) Size(0x20) ]
	struct FString FLocaleFormatter_UpdateVarFormatters_SeparatorStr(struct FString str);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.FLocaleFormatter_InitializeListItemFormats_ListItemFormatString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b71ae4
	// Params: [ Num(3) Size(0x28) ]
	struct FString FLocaleFormatter_InitializeListItemFormats_ListItemFormatString(struct FString ListItemFormatString, bool bNeedLocalization);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.HotfixUtility.FLocaleFormatter_InitializeFormats_FormatString
	// Flags: [RequiredAPI|Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x106b719c4
	// Params: [ Num(3) Size(0x28) ]
	struct FString FLocaleFormatter_InitializeFormats_FormatString(struct FString FormatString, bool bNeedLocalization);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.HotfixUtility.FLocaleFormatter_FFormatData_SlotIdx_OnPaintListItem_ParamDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b71860
	// Params: [ Num(4) Size(0x30) ]
	struct FString FLocaleFormatter_FFormatData_SlotIdx_OnPaintListItem_ParamDisplayName(struct UBlockyBlockListItemObject* ListItemObject, int& ParamIdx, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function BlockyLuaCore.HotfixUtility.FLocaleFormatter_FFormatData_SlotIdx_OnArrangeListItem_ParamDisplayName
	// Flags: [RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x106b716fc
	// Params: [ Num(4) Size(0x30) ]
	struct FString FLocaleFormatter_FFormatData_SlotIdx_OnArrangeListItem_ParamDisplayName(struct UBlockyBlockListItemObject* ListItemObject, int& ParamIdx, struct FString DisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.IfElse
// Size: 0x458 (Inherited: 0x430)
struct UIfElse : UExecuteable
{
	struct UIfElseCondition* IfCondition; // 0x430(0x8)
	struct TArray<struct UIfElseCondition*> ElseConditions; // 0x438(0x10)
	uint8_t Pad_0x448[0x10]; // 0x448(0x10)
};

// Object: Class BlockyLuaCore.IfElseCondition
// Size: 0x830 (Inherited: 0x638)
struct UIfElseCondition : UExeSequencerBase
{
	struct UIfElse* ParentIfElse; // 0x638(0x8)
	uint8_t Pad_0x640[0x1F0]; // 0x640(0x1F0)
};

// Object: Class BlockyLuaCore.IndexerOperatorExpression
// Size: 0x28 (Inherited: 0x28)
struct UIndexerOperatorExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.IndexerOperatorExpression.SetTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7c00c
	// Params: [ Num(2) Size(0x10) ]
	void SetTarget(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1BDC8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.IndexerOperatorExpression.SetIndices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7bef0
	// Params: [ Num(2) Size(0x18) ]
	void SetIndices(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1BE2C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1BDC8
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLuaCore.IndexerOperatorExpression.GetTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7be74
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetTarget(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BCF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B68AD8
	// [Call #9] RVA: 0x106B1BE2C
	// [Call #10] RVA: 0x106B43E9C
	// [Call #11] RVA: 0x106B43E9C
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1BDC8

	// Object: Function BlockyLuaCore.IndexerOperatorExpression.GetIndices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7bdd0
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetIndices(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BCF8
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1BCF0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B68AD8
	// [Call #16] RVA: 0x106B1BE2C
	// [Call #17] RVA: 0x106B43E9C
	// [Call #18] RVA: 0x106B43E9C
	// [Call #19] RVA: 0x106B43E9C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x106B43E9C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.IndexerOperatorExpression.CreateIndexerOperatorExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7bd9c
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateIndexerOperatorExpression();
	// [Call #1] RVA: 0x106B1BCBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1BCF8
	// [Call #5] RVA: 0x106B68A88
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1BCF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B68AD8
	// [Call #17] RVA: 0x106B1BE2C
	// [Call #18] RVA: 0x106B43E9C
	// [Call #19] RVA: 0x106B43E9C
	// [Call #20] RVA: 0x106B43E9C
	// [Call #21] RVA: 0x104EEF504
};

// Object: Class BlockyLuaCore.InsertArrayElement
// Size: 0x770 (Inherited: 0x430)
struct UInsertArrayElement : UExecuteable
{
	uint8_t Pad_0x430[0x340]; // 0x430(0x340)
};

// Object: Class BlockyLuaCore.JsonSerializable
// Size: 0x28 (Inherited: 0x28)
struct UJsonSerializable : UObject
{
};

// Object: Class BlockyLuaCore.LogicBase
// Size: 0x208 (Inherited: 0x200)
struct ULogicBase : UBlockBase
{
	struct UBrushData* BrushBGSelected; // 0x200(0x8)
};

// Object: Class BlockyLuaCore.LogicAnd
// Size: 0x548 (Inherited: 0x208)
struct ULogicAnd : ULogicBase
{
	uint8_t Pad_0x208[0x340]; // 0x208(0x340)
};

// Object: Class BlockyLuaCore.LogicCompare
// Size: 0x6D0 (Inherited: 0x208)
struct ULogicCompare : ULogicBase
{
	uint8_t Pad_0x208[0x4C8]; // 0x208(0x4C8)
};

// Object: Class BlockyLuaCore.LogicNot
// Size: 0x3A0 (Inherited: 0x208)
struct ULogicNot : ULogicBase
{
	uint8_t Pad_0x208[0x198]; // 0x208(0x198)
};

// Object: Class BlockyLuaCore.LogicOr
// Size: 0x548 (Inherited: 0x208)
struct ULogicOr : ULogicBase
{
	uint8_t Pad_0x208[0x340]; // 0x208(0x340)
};

// Object: Class BlockyLuaCore.Member
// Size: 0x3B0 (Inherited: 0x208)
struct UMember : ULogicBase
{
	uint8_t Pad_0x208[0x1A8]; // 0x208(0x1A8)
};

// Object: Class BlockyLuaCore.NullExpression
// Size: 0x28 (Inherited: 0x28)
struct UNullExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.NullExpression.CreateNullExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7dd34
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateNullExpression();
	// [Call #1] RVA: 0x106B1BEF8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class BlockyLuaCore.NumFromTo
// Size: 0x1008 (Inherited: 0x638)
struct UNumFromTo : UExeSequencerBase
{
	uint8_t Pad_0x638[0x808]; // 0x638(0x808)
	struct UBrushData* IconBrush; // 0xE40(0x8)
	uint8_t Pad_0xE48[0x1C0]; // 0xE48(0x1C0)
};

// Object: Class BlockyLuaCore.PostCustomEvent
// Size: 0x5F0 (Inherited: 0x430)
struct UPostCustomEvent : UExecuteable
{
	uint8_t Pad_0x430[0x1C0]; // 0x430(0x1C0)
};

// Object: Class BlockyLuaCore.PresetDesc
// Size: 0x330 (Inherited: 0x28)
struct UPresetDesc : UObjectDesc
{
	struct FString HotfixUserData; // 0x28(0x10)
	struct FString KeyName; // 0x38(0x10)
	struct FString Name; // 0x48(0x10)
	struct FString CodeName; // 0x58(0x10)
	struct TArray<int> Tag; // 0x68(0x10)
	struct FString Icon; // 0x78(0x10)
	struct FText Menu; // 0x88(0x18)
	struct FText Category; // 0xA0(0x18)
	bool isValidityPreset; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	int PresetValidityDuration; // 0xBC(0x4)
	struct FString AnimationPath; // 0xC0(0x10)
	struct FString SoundPath; // 0xD0(0x10)
	bool IsSelected; // 0xE0(0x1)
	bool IsDSNeedSave; // 0xE1(0x1)
	uint8_t Pad_0xE2[0x16]; // 0xE2(0x16)
	bool Visible; // 0xF8(0x1)
	bool Removed; // 0xF9(0x1)
	bool Localed; // 0xFA(0x1)
	bool IsCustomVar; // 0xFB(0x1)
	bool IsCustomVarArray; // 0xFC(0x1)
	bool isNeedSelectCheck; // 0xFD(0x1)
	uint8_t Pad_0xFE[0x2]; // 0xFE(0x2)
	struct FDependResInfo ResInfo; // 0x100(0x30)
	struct FString CustomVarType; // 0x130(0x10)
	struct TArray<uint8_t> CustomExtraData; // 0x140(0x10)
	uint8_t DynamicType; // 0x150(0x1)
	bool Exclude; // 0x151(0x1)
	uint8_t Pad_0x152[0x2]; // 0x152(0x2)
	int SortOrder; // 0x154(0x4)
	struct TArray<struct FString> ReferencedByBlockIDs; // 0x158(0x10)
	uint8_t Pad_0x168[0x1C8]; // 0x168(0x1C8)


	// Object: Function BlockyLuaCore.PresetDesc.NameContainsString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7e3a8
	// Params: [ Num(2) Size(0x11) ]
	bool NameContainsString(struct FString filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC37B8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.IsNameEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7e384
	// Params: [ Num(1) Size(0x1) ]
	bool IsNameEmpty();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC37B8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.IsCodeNameEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7e360
	// Params: [ Num(1) Size(0x1) ]
	bool IsCodeNameEmpty();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC37B8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.HasIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7e33c
	// Params: [ Num(1) Size(0x1) ]
	bool HasIcon();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC37B8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.GetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7e320
	// Params: [ Num(1) Size(0x70) ]
	struct FType GetType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106AC37B8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.GetPresetValidityDurationValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106b7e2ec
	// Params: [ Num(1) Size(0x4) ]
	int GetPresetValidityDurationValue();
	// [Call #1] RVA: 0x106AC3838
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106AC37B8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PresetDesc.GetLocaleName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b7e288
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLocaleName();
	// [Call #1] RVA: 0x106AC3784
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106AC3838
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106AC37B8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.PrimitiveExpression
// Size: 0x28 (Inherited: 0x28)
struct UPrimitiveExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.PrimitiveExpression.GetValueType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ef3c
	// Params: [ Num(2) Size(0x9) ]
	enum class EBlockyValueType GetValueType(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C28C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PrimitiveExpression.GetValueString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106b7ee60
	// Params: [ Num(2) Size(0x18) ]
	void GetValueString(struct FBlockyLuaHandle ptr, struct FString& str);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C288
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1C28C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_UInt8
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ede4
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_UInt8(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BFB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1C288
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1C28C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_UInt64
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ed68
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_UInt64(struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C164
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1BFB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1C288
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1C28C

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_UInt32
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ecec
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_UInt32(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C0D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C164
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1BFB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1C288
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_UInt16
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ec70
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_UInt16(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C044
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C0D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C164
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1BFB4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Str
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ebd4
	// Params: [ Num(2) Size(0x18) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Str(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BF24
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C044
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C0D4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1C164
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Int8
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7eb58
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Int8(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BF6C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1BF24
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C044
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1C0D4
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Int64
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7eadc
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Int64(struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C11C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1BF6C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1C044
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Int32
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ea60
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Int32(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C08C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C11C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1BF6C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1BF24
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Int16
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7e9e4
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Int16(int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1BFFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C08C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C11C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1BF6C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1BF24

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Float
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7e968
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Float(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C1AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1BFFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C08C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C11C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1BF6C

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Double
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7e8ec
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Double(struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C1F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C1AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1BFFC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C08C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1C11C

	// Object: Function BlockyLuaCore.PrimitiveExpression.CreatePrimitiveExpression_Bool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7e868
	// Params: [ Num(2) Size(0xC) ]
	struct FBlockyLuaHandle CreatePrimitiveExpression_Bool(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C240
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C1F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C1AC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1BFFC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.PrimitiveExpression.Clear
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7e7f4
	// Params: [ Num(1) Size(0x8) ]
	void Clear(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C284
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C240
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C1F4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C1AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1BFFC
};

// Object: Class BlockyLuaCore.RepeatFunction
// Size: 0x768 (Inherited: 0x6C8)
struct URepeatFunction : UCallFunction
{
	uint8_t Pad_0x6C8[0xA0]; // 0x6C8(0xA0)
};

// Object: Class BlockyLuaCore.Return
// Size: 0x430 (Inherited: 0x430)
struct UReturn : UExecuteable
{
};

// Object: Class BlockyLuaCore.SelectionData
// Size: 0x50 (Inherited: 0x28)
struct USelectionData : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
	struct UBlockBase* bLock; // 0x40(0x8)
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function BlockyLuaCore.SelectionData.IsCurrentSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b7f6dc
	// Params: [ Num(1) Size(0x1) ]
	bool IsCurrentSlot();
	// [Call #1] RVA: 0x106B1F6FC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106B7F934
	// [Call #6] RVA: 0x106B1C294
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.SelfReferenceExpression
// Size: 0x28 (Inherited: 0x28)
struct USelfReferenceExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.SelfReferenceExpression.CreateSelfReferenceExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7f878
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateSelfReferenceExpression();
	// [Call #1] RVA: 0x106B1C294
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class BlockyLuaCore.SetArrayElement
// Size: 0x770 (Inherited: 0x430)
struct USetArrayElement : UExecuteable
{
	uint8_t Pad_0x430[0x340]; // 0x430(0x340)
};

// Object: Class BlockyLuaCore.SetVar
// Size: 0x770 (Inherited: 0x430)
struct USetVar : UExecuteable
{
	uint8_t Pad_0x430[0x330]; // 0x430(0x330)
	struct UBrushData* IconBrush; // 0x760(0x8)
	struct UBrushData* SelectionBG; // 0x768(0x8)
};

// Object: Class BlockyLuaCore.SnippetExpression
// Size: 0x28 (Inherited: 0x28)
struct USnippetExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.SnippetExpression.GetSnippetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7fce4
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetSnippetString(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C2F4
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10508F76C

	// Object: Function BlockyLuaCore.SnippetExpression.GetParameters
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7fc40
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetParameters(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C348
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C2F4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.SnippetExpression.CreateDefaultValueExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7fc0c
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateDefaultValueExpression();
	// [Call #1] RVA: 0x106B1C2C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C348
	// [Call #5] RVA: 0x106B68A88
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1C2F4
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.StatementBase
// Size: 0x28 (Inherited: 0x28)
struct UStatementBase : UBlueprintFunctionLibrary
{

	// Object: Function BlockyLuaCore.StatementBase.SetNextExpr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80094
	// Params: [ Num(2) Size(0x10) ]
	void SetNextExpr(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle nextExpr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C468
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.StatementBase.ReleaseExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80020
	// Params: [ Num(1) Size(0x8) ]
	void ReleaseExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C448
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1C468
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.StatementBase.GetNextExpr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ffa4
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetNextExpr(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C45C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C448
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1C468
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.StatementBase.CreateStatementBase
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b7ff70
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateStatementBase();
	// [Call #1] RVA: 0x106B1C418
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C45C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1C448
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C468
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.VariableDeclaration
// Size: 0x28 (Inherited: 0x28)
struct UVariableDeclaration : UStatementBase
{

	// Object: Function BlockyLuaCore.VariableDeclaration.SetVisitMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8082c
	// Params: [ Num(2) Size(0x9) ]
	void SetVisitMode(struct FBlockyLuaHandle ptr, enum class EBlockyVisitMode visitMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C594
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VariableDeclaration.SetVariableName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80710
	// Params: [ Num(2) Size(0x18) ]
	void SetVariableName(struct FBlockyLuaHandle ptr, struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1C5A0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1C594
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLuaCore.VariableDeclaration.SetInitValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80664
	// Params: [ Num(2) Size(0x10) ]
	void SetInitValue(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle initValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C5B0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1C5A0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.VariableDeclaration.SetComment
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b805b8
	// Params: [ Num(2) Size(0x10) ]
	void SetComment(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Comment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C618
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C5B0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B1C5A0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.VariableDeclaration.GetVisitMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8053c
	// Params: [ Num(2) Size(0x9) ]
	enum class EBlockyVisitMode GetVisitMode(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C510
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1C618
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1C5B0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.VariableDeclaration.GetVariableName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80498
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetVariableName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C51C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C510
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1C618
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.VariableDeclaration.GetInitValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8041c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetInitValue(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C57C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C51C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1C510
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1C618

	// Object: Function BlockyLuaCore.VariableDeclaration.GetComment
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b803a0
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetComment(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C588
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C57C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C51C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1C510
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.VariableDeclaration.CreateVariableDeclaration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8036c
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateVariableDeclaration();
	// [Call #1] RVA: 0x106B1C4D0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C588
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1C57C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C51C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1C510
};

// Object: Class BlockyLuaCore.AssignOperatorStatement
// Size: 0x28 (Inherited: 0x28)
struct UAssignOperatorStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.AssignOperatorStatement.SetTo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80e34
	// Params: [ Num(2) Size(0x10) ]
	void SetTo(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle To);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C6CC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.AssignOperatorStatement.SetFrom
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80d88
	// Params: [ Num(2) Size(0x10) ]
	void SetFrom(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle From);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1C734
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C6CC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.AssignOperatorStatement.GetTo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80d0c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetTo(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C6B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1C734
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1C6CC
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.AssignOperatorStatement.GetFrom
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80c90
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetFrom(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C6C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C6B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1C734
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1C6CC

	// Object: Function BlockyLuaCore.AssignOperatorStatement.CreateAssignOperatorStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b80c5c
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateAssignOperatorStatement();
	// [Call #1] RVA: 0x106B1C680
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C6C0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1C6B4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1C734
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.ExecuteSequenceStatement
// Size: 0x28 (Inherited: 0x28)
struct UExecuteSequenceStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ExecuteSequenceStatement.SetSequence
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81228
	// Params: [ Num(2) Size(0x18) ]
	void SetSequence(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> Sequence);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1C890
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ExecuteSequenceStatement.GetSequence
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81184
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetSequence(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C7D0
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B68AD8
	// [Call #13] RVA: 0x106B1C890
	// [Call #14] RVA: 0x106B43E9C
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106B43E9C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x106B43E9C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C
	// [Call #22] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ExecuteSequenceStatement.CreateExecuteSequenceStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81150
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateExecuteSequenceStatement();
	// [Call #1] RVA: 0x106B1C79C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C7D0
	// [Call #5] RVA: 0x106B68A88
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B68AD8
	// [Call #14] RVA: 0x106B1C890
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106B43E9C
	// [Call #17] RVA: 0x106B43E9C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x106B43E9C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.ReturnStatement
// Size: 0x28 (Inherited: 0x28)
struct UReturnStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ReturnStatement.CreateReturnStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8152c
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateReturnStatement();
	// [Call #1] RVA: 0x106B1C954
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106B81ED4
	// [Call #6] RVA: 0x106B1C984
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1C9C4
};

// Object: Class BlockyLuaCore.IfStatement
// Size: 0x28 (Inherited: 0x28)
struct UIfStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.IfStatement.SetTrueStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81b80
	// Params: [ Num(2) Size(0x10) ]
	void SetTrueStatement(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle trueStatement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CAF8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.IfStatement.SetFalseStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81ad4
	// Params: [ Num(2) Size(0x10) ]
	void SetFalseStatement(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle falseStatement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CB60
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CAF8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.IfStatement.SetElseIfs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b819b8
	// Params: [ Num(2) Size(0x18) ]
	void SetElseIfs(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> elseIfs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1CBC8
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1CB60
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.IfStatement.SetCondition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8190c
	// Params: [ Num(2) Size(0x10) ]
	void SetCondition(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Condition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CA90
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B68AD8
	// [Call #11] RVA: 0x106B1CBC8
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106B43E9C
	// [Call #14] RVA: 0x106B43E9C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x106B43E9C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.IfStatement.GetTrueStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81890
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetTrueStatement(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C9D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1CA90
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B68AD8
	// [Call #14] RVA: 0x106B1CBC8
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106B43E9C
	// [Call #17] RVA: 0x106B43E9C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x106B43E9C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.IfStatement.GetFalseStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81814
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetFalseStatement(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C9DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C9D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1CA90
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B68AD8

	// Object: Function BlockyLuaCore.IfStatement.GetElseIfs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81770
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetElseIfs(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C9E8
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1C9DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1C9D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1CA90

	// Object: Function BlockyLuaCore.IfStatement.GetCondition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b816f4
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetCondition(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1C9C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1C9E8
	// [Call #7] RVA: 0x106B68A88
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1C9DC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1C9D0
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.IfStatement.CreateIfStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b816c0
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateIfStatement();
	// [Call #1] RVA: 0x106B1C984
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1C9C4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1C9E8
	// [Call #8] RVA: 0x106B68A88
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x106B43E9C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1C9DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1C9D0
};

// Object: Class BlockyLuaCore.ForLoopStatement
// Size: 0x28 (Inherited: 0x28)
struct UForLoopStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ForLoopStatement.SetStepExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82594
	// Params: [ Num(2) Size(0x10) ]
	void SetStepExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle stepExpression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CE34
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ForLoopStatement.SetLoopIndexName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82478
	// Params: [ Num(2) Size(0x18) ]
	void SetLoopIndexName(struct FBlockyLuaHandle ptr, struct FString loopIndexName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1CF04
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1CE34
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ForLoopStatement.SetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b823cc
	// Params: [ Num(2) Size(0x10) ]
	void SetLoopBody(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle loopBody);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CE9C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1CF04
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForLoopStatement.SetEndExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82320
	// Params: [ Num(2) Size(0x10) ]
	void SetEndExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle endExpression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CDCC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CE9C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B1CF04
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504

	// Object: Function BlockyLuaCore.ForLoopStatement.SetBeginExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82274
	// Params: [ Num(2) Size(0x10) ]
	void SetBeginExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle beginExpression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1CD64
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CDCC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1CE9C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForLoopStatement.GetStepExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b821f8
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetStepExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CCEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1CD64
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1CDCC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForLoopStatement.GetLoopIndexName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82154
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetLoopIndexName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CD04
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CCEC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1CD64
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForLoopStatement.GetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b820d8
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLoopBody(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CCF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1CD04
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1CCEC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1CD64

	// Object: Function BlockyLuaCore.ForLoopStatement.GetEndExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8205c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetEndExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CCE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1CCF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1CD04
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1CCEC
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.ForLoopStatement.GetBeginExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81fe0
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetBeginExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CCD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1CCE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1CCF8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1CD04
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.ForLoopStatement.CreateForLoopStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b81fac
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateForLoopStatement();
	// [Call #1] RVA: 0x106B1CC8C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1CCD4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1CCE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CCF8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1CD04
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
};

// Object: Class BlockyLuaCore.ForeachLoopStatement
// Size: 0x28 (Inherited: 0x28)
struct UForeachLoopStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ForeachLoopStatement.SetLoopItemName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82f30
	// Params: [ Num(2) Size(0x18) ]
	void SetLoopItemName(struct FBlockyLuaHandle ptr, struct FString loopIndexName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1D11C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ForeachLoopStatement.SetLoopItemExp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82e84
	// Params: [ Num(2) Size(0x10) ]
	void SetLoopItemExp(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle loopItemExp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D03C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1D11C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ForeachLoopStatement.SetLoopIndexName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82d68
	// Params: [ Num(2) Size(0x18) ]
	void SetLoopIndexName(struct FBlockyLuaHandle ptr, struct FString loopIndexName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1D10C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1D03C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForeachLoopStatement.SetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82cbc
	// Params: [ Num(2) Size(0x10) ]
	void SetLoopBody(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle loopBody);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D0A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1D10C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForeachLoopStatement.GetLoopItemName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82c18
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetLoopItemName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CFDC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1D0A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x106B1D10C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0

	// Object: Function BlockyLuaCore.ForeachLoopStatement.GetLoopItemExp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82b9c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLoopItemExp(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CF64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1CFDC
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1D0A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForeachLoopStatement.GetLoopIndexName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82af8
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetLoopIndexName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CF7C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1CF64
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1CFDC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.ForeachLoopStatement.GetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82a7c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLoopBody(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1CF70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1CF7C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1CF64
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1CFDC
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.ForeachLoopStatement.CreateForeachLoopStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b82a48
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateForeachLoopStatement();
	// [Call #1] RVA: 0x106B1CF14
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1CF70
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1CF7C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1CF64
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1CFDC
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
};

// Object: Class BlockyLuaCore.WhileLoopStatement
// Size: 0x28 (Inherited: 0x28)
struct UWhileLoopStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.WhileLoopStatement.SetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b835a4
	// Params: [ Num(2) Size(0x10) ]
	void SetLoopBody(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle loopBody);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D1EC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.WhileLoopStatement.SetCondition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b834f8
	// Params: [ Num(2) Size(0x10) ]
	void SetCondition(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Condition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D184
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D1EC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.WhileLoopStatement.GetLoopBody
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8347c
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLoopBody(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D178
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1D184
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1D1EC
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.WhileLoopStatement.GetCondition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83400
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetCondition(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D16C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1D178
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D184
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1D1EC

	// Object: Function BlockyLuaCore.WhileLoopStatement.CreateWhileLoopStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b833cc
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateWhileLoopStatement();
	// [Call #1] RVA: 0x106B1D12C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1D16C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1D178
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1D184
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.ContinueStatement
// Size: 0x28 (Inherited: 0x28)
struct UContinueStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ContinueStatement.CreateContinueStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b838c0
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateContinueStatement();
	// [Call #1] RVA: 0x106B1D254
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106B83B10
	// [Call #6] RVA: 0x106B1D28C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
};

// Object: Class BlockyLuaCore.BreakStatement
// Size: 0x28 (Inherited: 0x28)
struct UBreakStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.BreakStatement.CreateBreakStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83a54
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateBreakStatement();
	// [Call #1] RVA: 0x106B1D28C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106B840C0
	// [Call #6] RVA: 0x106B1D2BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B1D2FC
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
};

// Object: Class BlockyLuaCore.CommentStatement
// Size: 0x28 (Inherited: 0x28)
struct UCommentStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.CommentStatement.SetNewLine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83e58
	// Params: [ Num(2) Size(0x9) ]
	void SetNewLine(struct FBlockyLuaHandle ptr, bool newLine);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D384
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.CommentStatement.SetCommentString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83d3c
	// Params: [ Num(2) Size(0x18) ]
	void SetCommentString(struct FBlockyLuaHandle ptr, struct FString commentString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1D374
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1D384
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLuaCore.CommentStatement.GetNewLine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83cc0
	// Params: [ Num(2) Size(0x9) ]
	bool GetNewLine(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D35C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B1D374
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1D384

	// Object: Function BlockyLuaCore.CommentStatement.GetCommentString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83c1c
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetCommentString(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D2FC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D35C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B1D374
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.CommentStatement.CreateCommentStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b83be8
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateCommentStatement();
	// [Call #1] RVA: 0x106B1D2BC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1D2FC
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D35C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106B1D374
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
};

// Object: Class BlockyLuaCore.ExpressionStatement
// Size: 0x28 (Inherited: 0x28)
struct UExpressionStatement : UStatementBase
{

	// Object: Function BlockyLuaCore.ExpressionStatement.SetNextStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b84370
	// Params: [ Num(2) Size(0x10) ]
	void SetNextStatement(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle nextStatement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D444
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ExpressionStatement.SetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b842c4
	// Params: [ Num(2) Size(0x10) ]
	void SetExpression(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle expression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D3DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D444
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.ExpressionStatement.GetNextStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b84248
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetNextStatement(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D3D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1D3DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1D444
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.ExpressionStatement.GetExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b841cc
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetExpression(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D3C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1D3D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D3DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1D444

	// Object: Function BlockyLuaCore.ExpressionStatement.CreateExpressionStatement
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b84198
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateExpressionStatement();
	// [Call #1] RVA: 0x106B1D390
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1D3C4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1D3D0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1D3DC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.StatementsData
// Size: 0x28 (Inherited: 0x28)
struct UStatementsData : UBlueprintFunctionLibrary
{
};

// Object: Class BlockyLuaCore.StringAppend
// Size: 0x540 (Inherited: 0x200)
struct UStringAppend : UBlockBase
{
	uint8_t Pad_0x200[0x340]; // 0x200(0x340)
};

// Object: Class BlockyLuaCore.StringAppendExpression
// Size: 0x28 (Inherited: 0x28)
struct UStringAppendExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.StringAppendExpression.SetRight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b88af0
	// Params: [ Num(2) Size(0x10) ]
	void SetRight(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D624
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.StringAppendExpression.SetLeft
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b88a44
	// Params: [ Num(2) Size(0x10) ]
	void SetLeft(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D5C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D624
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.StringAppendExpression.SetExtras
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b88928
	// Params: [ Num(2) Size(0x18) ]
	void SetExtras(struct FBlockyLuaHandle ptr, struct TArray<struct FBlockyLuaHandle> Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B68AD8
	// [Call #6] RVA: 0x106B1D688
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106B43E9C
	// [Call #9] RVA: 0x106B43E9C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B1D5C0
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.StringAppendExpression.GetRight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b888ac
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetRight(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D4E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B68AD8
	// [Call #9] RVA: 0x106B1D688
	// [Call #10] RVA: 0x106B43E9C
	// [Call #11] RVA: 0x106B43E9C
	// [Call #12] RVA: 0x106B43E9C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1D5C0

	// Object: Function BlockyLuaCore.StringAppendExpression.GetLeft
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b88830
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetLeft(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D4E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1D4E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B68AD8
	// [Call #12] RVA: 0x106B1D688
	// [Call #13] RVA: 0x106B43E9C
	// [Call #14] RVA: 0x106B43E9C
	// [Call #15] RVA: 0x106B43E9C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x106B43E9C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.StringAppendExpression.GetExtras
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8878c
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBlockyLuaHandle> GetExtras(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D4F0
	// [Call #4] RVA: 0x106B68A88
	// [Call #5] RVA: 0x106B43E9C
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D4E0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1D4E8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B68AD8

	// Object: Function BlockyLuaCore.StringAppendExpression.CreateStringAppendExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b88758
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateStringAppendExpression();
	// [Call #1] RVA: 0x106B1D4AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1D4F0
	// [Call #5] RVA: 0x106B68A88
	// [Call #6] RVA: 0x106B43E9C
	// [Call #7] RVA: 0x106B43E9C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D4E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1D4E8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.SubGraphCommandData
// Size: 0x90 (Inherited: 0x30)
struct USubGraphCommandData : UBlockyCommandData
{
	struct FString Name; // 0x30(0x10)
	struct FString Type; // 0x40(0x10)
	struct FString SrcName; // 0x50(0x10)
	struct TArray<int> InCallStackPos; // 0x60(0x10)
	int IdxInSubBLocky; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct UBlockyGraph* OpGraph; // 0x78(0x8)
	struct FString SavedName; // 0x80(0x10)
};

// Object: Class BlockyLuaCore.TemplateCommandData
// Size: 0x58 (Inherited: 0x30)
struct UTemplateCommandData : UBlockyCommandData
{
	struct UBlockyGraph* Template; // 0x30(0x8)
	struct FString CreatedGraphName; // 0x38(0x10)
	struct FString CreatedGraphType; // 0x48(0x10)
};

// Object: Class BlockyLuaCore.TypeConvertDesc
// Size: 0x68 (Inherited: 0x28)
struct UTypeConvertDesc : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FString HotfixUserData; // 0x30(0x10)
	uint8_t Pad_0x40[0x20]; // 0x40(0x20)
	struct UFunctionDesc* FunctionDesc; // 0x60(0x8)
};

// Object: Class BlockyLuaCore.TypeFilter
// Size: 0x398 (Inherited: 0x200)
struct UTypeFilter : UBlockBase
{
	uint8_t Pad_0x200[0x198]; // 0x200(0x198)
};

// Object: Class BlockyLuaCore.TypeReference
// Size: 0x28 (Inherited: 0x28)
struct UTypeReference : UBlueprintFunctionLibrary
{

	// Object: Function BlockyLuaCore.TypeReference.SetTypeName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89730
	// Params: [ Num(2) Size(0x18) ]
	void SetTypeName(struct FBlockyLuaHandle Self, struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B1D82C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.TypeReference.ReleaseTypeReference
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b896bc
	// Params: [ Num(1) Size(0x8) ]
	void ReleaseTypeReference(struct FBlockyLuaHandle Self);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D784
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B1D82C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.TypeReference.GetTypeName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89618
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetTypeName(struct FBlockyLuaHandle Self);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D830
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D784
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B1D82C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLuaCore.TypeReference.FindClass
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89534
	// Params: [ Num(2) Size(0x18) ]
	struct FBlockyLuaHandle FindClass(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B1D79C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1D830
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1D784
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.TypeReference.CreateTypeReference3
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8943c
	// Params: [ Num(4) Size(0x18) ]
	struct FBlockyLuaHandle CreateTypeReference3(struct FBlockyLuaHandle klass, int numOfPointer, bool isRefer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1B0A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B1D79C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B1D830
	// [Call #22] RVA: 0x101F8156C

	// Object: Function BlockyLuaCore.TypeReference.CreateTypeReference
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89408
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateTypeReference();
	// [Call #1] RVA: 0x106B1D75C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1B0A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106B1D79C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function BlockyLuaCore.TypeReference.AsStub
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106b89354
	// Params: [ Num(2) Size(0x88) ]
	struct FBlockyLuaStub AsStub(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D754
	// [Call #4] RVA: 0x106B8B3A4
	// [Call #5] RVA: 0x106A41C80
	// [Call #6] RVA: 0x106A41C80
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B1D75C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1B0A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.TypeString
// Size: 0x200 (Inherited: 0x200)
struct UTypeString : UBlockBase
{
};

// Object: Class BlockyLuaCore.UnaryOperatorExpression
// Size: 0x28 (Inherited: 0x28)
struct UUnaryOperatorExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.UnaryOperatorExpression.SetValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89eb4
	// Params: [ Num(2) Size(0x10) ]
	void SetValue(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D8D4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.UnaryOperatorExpression.SetOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89e04
	// Params: [ Num(2) Size(0x9) ]
	void SetOperation(struct FBlockyLuaHandle ptr, enum class EBlockyUnaryOperation Op);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D8BC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1D8D4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.UnaryOperatorExpression.GetValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89d88
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetValue(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D950
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B1D8BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B1D8D4
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function BlockyLuaCore.UnaryOperatorExpression.GetOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89d0c
	// Params: [ Num(2) Size(0x9) ]
	enum class EBlockyUnaryOperation GetOperation(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D938
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1D950
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D8BC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B1D8D4

	// Object: Function BlockyLuaCore.UnaryOperatorExpression.CreateUnaryOperatorExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b89cd8
	// Params: [ Num(1) Size(0x8) ]
	struct FBlockyLuaHandle CreateUnaryOperatorExpression();
	// [Call #1] RVA: 0x106B1D888
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B1D938
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B1D950
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1D8BC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
};

// Object: Class BlockyLuaCore.VarDefiner
// Size: 0x188 (Inherited: 0x28)
struct UVarDefiner : UObject
{
	struct FType BPType; // 0x28(0x70)
	struct FString HotfixUserData; // 0x98(0x10)
	uint8_t Pad_0xA8[0x10]; // 0xA8(0x10)
	struct TMap<struct FString, struct FString> ShowNameMap; // 0xB8(0x50)
	struct FString ShowIcon; // 0x108(0x10)
	struct FString ShowIconSelected; // 0x118(0x10)
	struct FString DefaultValueString; // 0x128(0x10)
	bool bHideInCustom; // 0x138(0x1)
	enum class EBlockyVarInitType InitType; // 0x139(0x1)
	uint8_t Pad_0x13A[0x6]; // 0x13A(0x6)
	struct TArray<struct FString> ExcludePresetCategories; // 0x140(0x10)
	struct TArray<struct FString> ExcludePresetCodeNames; // 0x150(0x10)
	uint8_t Pad_0x160[0x28]; // 0x160(0x28)


	// Object: Function BlockyLuaCore.VarDefiner.SetType
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x106b8a4bc
	// Params: [ Num(1) Size(0x70) ]
	void SetType(struct FType& Value);
	// [Call #1] RVA: 0x106A42EC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106A728E0
	// [Call #5] RVA: 0x106A45834
	// [Call #6] RVA: 0x106A45834
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VarDefiner.GetVarTypeEnum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b8a488
	// Params: [ Num(1) Size(0x1) ]
	enum class EBlockyVariableType GetVarTypeEnum();
	// [Call #1] RVA: 0x106A7295C
	// [Call #2] RVA: 0x106A42EC8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106A728E0
	// [Call #6] RVA: 0x106A45834
	// [Call #7] RVA: 0x106A45834
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VarDefiner.GetTypeEnum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b8a454
	// Params: [ Num(1) Size(0x1) ]
	enum class EBlockyListItemType GetTypeEnum();
	// [Call #1] RVA: 0x106A7294C
	// [Call #2] RVA: 0x106A7295C
	// [Call #3] RVA: 0x106A42EC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106A728E0
	// [Call #7] RVA: 0x106A45834
	// [Call #8] RVA: 0x106A45834
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VarDefiner.GetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b8a41c
	// Params: [ Num(1) Size(0x70) ]
	struct FType GetType();
	// [Call #1] RVA: 0x106A728D8
	// [Call #2] RVA: 0x106A7294C
	// [Call #3] RVA: 0x106A7295C
	// [Call #4] RVA: 0x106A42EC8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106A728E0
	// [Call #8] RVA: 0x106A45834
	// [Call #9] RVA: 0x106A45834
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VarDefiner.GetFirstShowName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b8a3b8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFirstShowName();
	// [Call #1] RVA: 0x106A1C17C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A728D8
	// [Call #7] RVA: 0x106A7294C
	// [Call #8] RVA: 0x106A7295C
	// [Call #9] RVA: 0x106A42EC8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106A728E0
	// [Call #13] RVA: 0x106A45834
	// [Call #14] RVA: 0x106A45834
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function BlockyLuaCore.VarDefiner.GetCurrentLocateShowName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106b8a354
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCurrentLocateShowName();
	// [Call #1] RVA: 0x106A2C170
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106A1C17C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106A728D8
	// [Call #12] RVA: 0x106A7294C
	// [Call #13] RVA: 0x106A7295C
	// [Call #14] RVA: 0x106A42EC8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106A728E0
	// [Call #18] RVA: 0x106A45834
	// [Call #19] RVA: 0x106A45834
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C
};

// Object: Class BlockyLuaCore.VariableReferenceExpression
// Size: 0x28 (Inherited: 0x28)
struct UVariableReferenceExpression : UExpressionBase
{

	// Object: Function BlockyLuaCore.VariableReferenceExpression.SetVariableName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8ab64
	// Params: [ Num(2) Size(0x18) ]
	void SetVariableName(struct FBlockyLuaHandle ptr, struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1DA4C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VariableReferenceExpression.SetHost
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8aab8
	// Params: [ Num(2) Size(0x10) ]
	void SetHost(struct FBlockyLuaHandle ptr, struct FBlockyLuaHandle Host);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1DA5C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B1DA4C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VariableReferenceExpression.GetVariableName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8aa14
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetVariableName(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D9F8
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B1DA5C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1DA4C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function BlockyLuaCore.VariableReferenceExpression.GetHost
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8a998
	// Params: [ Num(2) Size(0x10) ]
	struct FBlockyLuaHandle GetHost(struct FBlockyLuaHandle ptr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1DA54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B1D9F8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B1DA5C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.VariableReferenceExpression.CreateVariableReferenceExpression2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8a8c0
	// Params: [ Num(3) Size(0x20) ]
	struct FBlockyLuaHandle CreateVariableReferenceExpression2(struct FBlockyLuaHandle Host, struct FString VariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B1D9A0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1DA54
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B1D9F8
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLuaCore.VariableReferenceExpression.CreateVariableReferenceExpression
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106b8a824
	// Params: [ Num(2) Size(0x18) ]
	struct FBlockyLuaHandle CreateVariableReferenceExpression(struct FString VariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B1D958
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B1D9A0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B1DA54
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class BlockyLuaCore.While
// Size: 0x7D8 (Inherited: 0x638)
struct UWhile : UExeSequencerBase
{
	uint8_t Pad_0x638[0x198]; // 0x638(0x198)
	struct UBrushData* IconBrush; // 0x7D0(0x8)
};

