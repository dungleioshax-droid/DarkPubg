#pragma once

#include <cstdint>

// Object: Enum Foliage.EFoliageScaling
enum class EFoliageScaling : uint8_t
{
	Uniform = 0,
	Free = 1,
	LockXY = 2,
	LockXZ = 3,
	LockYZ = 4,
	EFoliageScaling_MAX = 5
};

// Object: Enum Foliage.EVertexColorMaskChannel
enum class EVertexColorMaskChannel : uint8_t
{
	Red = 0,
	Green = 1,
	Blue = 2,
	Alpha = 3,
	MAX_None = 4,
	EVertexColorMaskChannel_MAX = 5
};

// Object: Enum Foliage.FoliageVertexColorMask
enum class EFoliageVertexColorMask : uint8_t
{
	FOLIAGEVERTEXCOLORMASK_Disabled = 0,
	FOLIAGEVERTEXCOLORMASK_Red = 1,
	FOLIAGEVERTEXCOLORMASK_Green = 2,
	FOLIAGEVERTEXCOLORMASK_Blue = 3,
	FOLIAGEVERTEXCOLORMASK_Alpha = 4,
	FOLIAGEVERTEXCOLORMASK_MAX = 5
};

// Object: Enum Foliage.ESimulationQuery
enum class ESimulationQuery : uint8_t
{
	CollisionOverlap = 1,
	ShadeOverlap = 2,
	AnyOverlap = 3,
	ESimulationQuery_MAX = 4
};

// Object: Enum Foliage.ESimulationOverlap
enum class ESimulationOverlap : uint8_t
{
	CollisionOverlap = 0,
	ShadeOverlap = 1,
	None = 2,
	ESimulationOverlap_MAX = 3
};

// Object: ScriptStruct Foliage.FoliageVertexColorChannelMask
// Size: 0xC (Inherited: 0x0)
struct FFoliageVertexColorChannelMask
{
	uint8_t UseMask : 1; // 0x0(0x1), Mask(0x1)
	uint8_t BitPad_0x0_1 : 7; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float MaskThreshold; // 0x4(0x4)
	uint8_t InvertMask : 1; // 0x8(0x1), Mask(0x1)
	uint8_t BitPad_0x8_1 : 7; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
};

// Object: ScriptStruct Foliage.FoliageTypeObject
// Size: 0x20 (Inherited: 0x0)
struct FFoliageTypeObject
{
	struct UObject* FoliageTypeObject; // 0x0(0x8)
	struct UFoliageType* TypeInstance; // 0x8(0x8)
	bool bIsAsset; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct UFoliageType_InstancedStaticMesh* Type; // 0x18(0x8)
};

// Object: ScriptStruct Foliage.ProceduralFoliageInstance
// Size: 0x60 (Inherited: 0x0)
struct FProceduralFoliageInstance
{
	struct FVector Location; // 0x0(0xC)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FQuat Rotation; // 0x10(0x10)
	struct FVector Normal; // 0x20(0xC)
	float Age; // 0x2C(0x4)
	float Scale; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct UFoliageType* Type; // 0x38(0x8)
	uint8_t Pad_0x40[0x20]; // 0x40(0x20)
};

// Object: Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0xE30 (Inherited: 0xE10)
struct UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent
{
	struct FScriptMulticastDelegate OnInstanceTakePointDamage; // 0xE08(0x10)
	struct FScriptMulticastDelegate OnInstanceTakeRadialDamage; // 0xE18(0x10)
};

// Object: Class Foliage.FoliageStatistics
// Size: 0x28 (Inherited: 0x28)
struct UFoliageStatistics : UBlueprintFunctionLibrary
{

	// Object: Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105bc93fc
	// Params: [ Num(5) Size(0x24) ]
	int FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105BBEDB8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105bc9300
	// Params: [ Num(4) Size(0x30) ]
	int FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105BBF270
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105BBEDB8
};

// Object: Class Foliage.FoliageType
// Size: 0x420 (Inherited: 0x28)
struct UFoliageType : UObject
{
	struct FGuid UpdateGuid; // 0x28(0x10)
	float Density; // 0x38(0x4)
	float DensityAdjustmentFactor; // 0x3C(0x4)
	float Radius; // 0x40(0x4)
	uint8_t Scaling; // 0x44(0x1)
	uint8_t Pad_0x45[0x3]; // 0x45(0x3)
	struct FFloatInterval ScaleX; // 0x48(0x8)
	struct FFloatInterval ScaleY; // 0x50(0x8)
	struct FFloatInterval ScaleZ; // 0x58(0x8)
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x4]; // 0x60(0x30)
	enum class EFoliageVertexColorMask VertexColorMask; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float VertexColorMaskThreshold; // 0x94(0x4)
	uint8_t VertexColorMaskInvert : 1; // 0x98(0x1), Mask(0x1)
	uint8_t BitPad_0x98_1 : 7; // 0x98(0x1)
	uint8_t Pad_0x99[0x3]; // 0x99(0x3)
	struct FFloatInterval ZOffset; // 0x9C(0x8)
	uint8_t AlignToNormal : 1; // 0xA4(0x1), Mask(0x1)
	uint8_t BitPad_0xA4_1 : 7; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	float AlignMaxAngle; // 0xA8(0x4)
	uint8_t RandomYaw : 1; // 0xAC(0x1), Mask(0x1)
	uint8_t BitPad_0xAC_1 : 7; // 0xAC(0x1)
	uint8_t Pad_0xAD[0x3]; // 0xAD(0x3)
	float RandomPitchAngle; // 0xB0(0x4)
	struct FFloatInterval GroundSlopeAngle; // 0xB4(0x8)
	struct FFloatInterval Height; // 0xBC(0x8)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
	struct TArray<struct FName> LandscapeLayers; // 0xC8(0x10)
	struct FName LandscapeLayer; // 0xD8(0x8)
	uint8_t CollisionWithWorld : 1; // 0xE0(0x1), Mask(0x1)
	uint8_t BitPad_0xE0_1 : 7; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x3]; // 0xE1(0x3)
	struct FVector CollisionScale; // 0xE4(0xC)
	float MinimumLayerWeight; // 0xF0(0x4)
	struct FBoxSphereBounds MeshBounds; // 0xF4(0x1C)
	struct FVector LowBoundOriginRadius; // 0x110(0xC)
	enum class EComponentMobility Mobility; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	struct FInt32Interval CullDistance; // 0x120(0x8)
	int LowDeviceForcedLodModel; // 0x128(0x4)
	uint8_t bEnableStaticLighting : 1; // 0x12C(0x1), Mask(0x1)
	uint8_t CastShadow : 1; // 0x12C(0x1), Mask(0x2)
	uint8_t bAffectDynamicIndirectLighting : 1; // 0x12C(0x1), Mask(0x4)
	uint8_t bAffectDistanceFieldLighting : 1; // 0x12C(0x1), Mask(0x8)
	uint8_t bCastDynamicShadow : 1; // 0x12C(0x1), Mask(0x10)
	uint8_t bCastStaticShadow : 1; // 0x12C(0x1), Mask(0x20)
	uint8_t bCastShadowAsTwoSided : 1; // 0x12C(0x1), Mask(0x40)
	uint8_t bReceivesDecals : 1; // 0x12C(0x1), Mask(0x80)
	uint8_t bOverrideLightMapRes : 1; // 0x12D(0x1), Mask(0x1)
	uint8_t BitPad_0x12D_1 : 7; // 0x12D(0x1)
	uint8_t Pad_0x12E[0x2]; // 0x12E(0x2)
	int OverriddenLightMapRes; // 0x130(0x4)
	uint8_t LightmapType; // 0x134(0x1)
	uint8_t bUseAsOccluder : 1; // 0x135(0x1), Mask(0x1)
	uint8_t BitPad_0x135_1 : 7; // 0x135(0x1)
	uint8_t Pad_0x136[0xA]; // 0x136(0xA)
	struct FBodyInstance BodyInstance; // 0x140(0x210)
	enum class EHasCustomNavigableGeometry CustomNavigableGeometry; // 0x350(0x1)
	struct FLightingChannels LightingChannels; // 0x351(0x1)
	uint8_t bRenderCustomDepth : 1; // 0x352(0x1), Mask(0x1)
	uint8_t BitPad_0x352_1 : 7; // 0x352(0x1)
	uint8_t Pad_0x353[0x1]; // 0x353(0x1)
	int CustomDepthStencilValue; // 0x354(0x4)
	float CollisionRadius; // 0x358(0x4)
	float ShadeRadius; // 0x35C(0x4)
	int NumSteps; // 0x360(0x4)
	float InitialSeedDensity; // 0x364(0x4)
	float AverageSpreadDistance; // 0x368(0x4)
	float SpreadVariance; // 0x36C(0x4)
	int SeedsPerStep; // 0x370(0x4)
	int DistributionSeed; // 0x374(0x4)
	float MaxInitialSeedOffset; // 0x378(0x4)
	bool bCanGrowInShade; // 0x37C(0x1)
	bool bSpawnsInShade; // 0x37D(0x1)
	uint8_t Pad_0x37E[0x2]; // 0x37E(0x2)
	float MaxInitialAge; // 0x380(0x4)
	float MaxAge; // 0x384(0x4)
	float OverlapPriority; // 0x388(0x4)
	struct FFloatInterval ProceduralScale; // 0x38C(0x8)
	uint8_t Pad_0x394[0x4]; // 0x394(0x4)
	struct FRuntimeFloatCurve ScaleCurve; // 0x398(0x78)
	int ChangeCount; // 0x410(0x4)
	uint8_t ReapplyDensity : 1; // 0x414(0x1), Mask(0x1)
	uint8_t ReapplyRadius : 1; // 0x414(0x1), Mask(0x2)
	uint8_t ReapplyAlignToNormal : 1; // 0x414(0x1), Mask(0x4)
	uint8_t ReapplyRandomYaw : 1; // 0x414(0x1), Mask(0x8)
	uint8_t ReapplyScaling : 1; // 0x414(0x1), Mask(0x10)
	uint8_t ReapplyScaleX : 1; // 0x414(0x1), Mask(0x20)
	uint8_t ReapplyScaleY : 1; // 0x414(0x1), Mask(0x40)
	uint8_t ReapplyScaleZ : 1; // 0x414(0x1), Mask(0x80)
	uint8_t ReapplyRandomPitchAngle : 1; // 0x415(0x1), Mask(0x1)
	uint8_t ReapplyGroundSlope : 1; // 0x415(0x1), Mask(0x2)
	uint8_t ReapplyHeight : 1; // 0x415(0x1), Mask(0x4)
	uint8_t ReapplyLandscapeLayers : 1; // 0x415(0x1), Mask(0x8)
	uint8_t ReapplyZOffset : 1; // 0x415(0x1), Mask(0x10)
	uint8_t ReapplyCollisionWithWorld : 1; // 0x415(0x1), Mask(0x20)
	uint8_t ReapplyVertexColorMask : 1; // 0x415(0x1), Mask(0x40)
	uint8_t bEnableDensityScaling : 1; // 0x415(0x1), Mask(0x80)
	uint8_t Pad_0x416[0xA]; // 0x416(0xA)
};

// Object: Class Foliage.FoliageType_Actor
// Size: 0x430 (Inherited: 0x420)
struct UFoliageType_Actor : UFoliageType
{
	struct AActor* ActorClass; // 0x418(0x8)
	bool bShouldAttachToBaseComponent; // 0x420(0x1)
	uint8_t Pad_0x429[0x7]; // 0x429(0x7)
};

// Object: Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x440 (Inherited: 0x420)
struct UFoliageType_InstancedStaticMesh : UFoliageType
{
	struct UStaticMesh* Mesh; // 0x418(0x8)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x420(0x10)
	struct UFoliageInstancedStaticMeshComponent* ComponentClass; // 0x430(0x8)
};

// Object: Class Foliage.InstancedFoliageActor
// Size: 0x500 (Inherited: 0x4B0)
struct AInstancedFoliageActor : AActor
{
	uint8_t Pad_0x4B0[0x50]; // 0x4B0(0x50)
};

// Object: Class Foliage.InteractiveFoliageActor
// Size: 0x520 (Inherited: 0x4C0)
struct AInteractiveFoliageActor : AStaticMeshActor
{
	struct UCapsuleComponent* CapsuleComponent; // 0x4C0(0x8)
	struct FVector TouchingActorEntryPosition; // 0x4C8(0xC)
	struct FVector FoliageVelocity; // 0x4D4(0xC)
	struct FVector FoliageForce; // 0x4E0(0xC)
	struct FVector FoliagePosition; // 0x4EC(0xC)
	float FoliageDamageImpulseScale; // 0x4F8(0x4)
	float FoliageTouchImpulseScale; // 0x4FC(0x4)
	float FoliageStiffness; // 0x500(0x4)
	float FoliageStiffnessQuadratic; // 0x504(0x4)
	float FoliageDamping; // 0x508(0x4)
	float MaxDamageImpulse; // 0x50C(0x4)
	float MaxTouchImpulse; // 0x510(0x4)
	float MaxForce; // 0x514(0x4)
	float Mass; // 0x518(0x4)
	uint8_t Pad_0x51C[0x4]; // 0x51C(0x4)


	// Object: Function Foliage.InteractiveFoliageActor.CapsuleTouched
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x105bca02c
	// Params: [ Num(6) Size(0xA8) ]
	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105BBE380
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
};

// Object: Class Foliage.InteractiveFoliageComponent
// Size: 0xBD0 (Inherited: 0xBD0)
struct UInteractiveFoliageComponent : UStaticMeshComponent
{
};

// Object: Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x4E8 (Inherited: 0x4E0)
struct AProceduralFoliageBlockingVolume : AVolume
{
	struct AProceduralFoliageVolume* ProceduralFoliageVolume; // 0x4E0(0x8)
};

// Object: Class Foliage.ProceduralFoliageComponent
// Size: 0x1A0 (Inherited: 0x178)
struct UProceduralFoliageComponent : UActorComponent
{
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x178(0x8)
	float TileOverlap; // 0x180(0x4)
	uint8_t Pad_0x184[0x4]; // 0x184(0x4)
	struct AVolume* SpawningVolume; // 0x188(0x8)
	struct FGuid ProceduralGuid; // 0x190(0x10)
};

// Object: Class Foliage.ProceduralFoliageSpawner
// Size: 0x70 (Inherited: 0x28)
struct UProceduralFoliageSpawner : UObject
{
	int RandomSeed; // 0x28(0x4)
	float TileSize; // 0x2C(0x4)
	int NumUniqueTiles; // 0x30(0x4)
	float MinimumQuadTreeSize; // 0x34(0x4)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
	struct TArray<struct FFoliageTypeObject> FoliageTypes; // 0x40(0x10)
	bool bNeedsSimulation; // 0x50(0x1)
	uint8_t Pad_0x51[0x1F]; // 0x51(0x1F)


	// Object: Function Foliage.ProceduralFoliageSpawner.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105bca84c
	// Params: [ Num(1) Size(0x4) ]
	void Simulate(int NumSteps);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105BC1E04
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870
};

// Object: Class Foliage.ProceduralFoliageTile
// Size: 0x158 (Inherited: 0x28)
struct UProceduralFoliageTile : UObject
{
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x28(0x8)
	uint8_t Pad_0x30[0xA0]; // 0x30(0xA0)
	struct TArray<struct FProceduralFoliageInstance> InstancesArray; // 0xD0(0x10)
	uint8_t Pad_0xE0[0x78]; // 0xE0(0x78)
};

// Object: Class Foliage.ProceduralFoliageVolume
// Size: 0x4E8 (Inherited: 0x4E0)
struct AProceduralFoliageVolume : AVolume
{
	struct UProceduralFoliageComponent* ProceduralComponent; // 0x4E0(0x8)
};

