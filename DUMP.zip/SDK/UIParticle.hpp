#pragma once

#include <cstdint>

// Object: Enum UIParticle.EUIParticlePropertyType
enum class EUIParticlePropertyType : uint8_t
{
	Float = 0,
	FloatRange = 1,
	FloatCurve = 2,
	FloatCurveRange = 3,
	Vector2D = 4,
	Vector2DRange = 5,
	LinearColorCurve = 6,
	LinearColorCurveRange = 7,
	EUIParticlePropertyType_MAX = 8
};

// Object: Enum UIParticle.EParticleDrawEffect
enum class EParticleDrawEffect : uint8_t
{
	None = 0,
	NoBlending = 1,
	PreMultipliedAlpha = 2,
	NoGamma = 4,
	InvertAlpha = 8,
	NoPixelSnapping = 16,
	DisabledEffect = 32,
	IgnoreTextureAlpha = 64,
	ReverseGamma = 128,
	EParticleDrawEffect_MAX = 129
};

// Object: Enum UIParticle.EPositionType
enum class EPositionType : uint8_t
{
	FREE = 0,
	RELATIVE = 1,
	EPositionType_MAX = 2
};

// Object: Enum UIParticle.EEmitterType
enum class EEmitterType : uint8_t
{
	Gravity = 0,
	Radial = 1,
	Curve = 2,
	EEmitterType_MAX = 3
};

// Object: Enum UIParticle.ECurveType
enum class ECurveType : uint8_t
{
	ParticleLifePercent = 0,
	ParticleLifeTime = 1,
	EmitLifeTime = 2,
	ECurveType_MAX = 3
};

// Object: ScriptStruct UIParticle.EasyParticleChildEmitterArray
// Size: 0x38 (Inherited: 0x0)
struct FEasyParticleChildEmitterArray
{
	struct UUIParticleEmitterAsset* ChildrenAsset; // 0x0(0x8)
	struct FDateTime EmitterStartTime; // 0x8(0x8)
	uint8_t Pad_0x10[0x28]; // 0x10(0x28)
};

// Object: ScriptStruct UIParticle.UIParticleEmitterInfo
// Size: 0x18 (Inherited: 0x0)
struct FUIParticleEmitterInfo
{
	bool Disable; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float ActiveDelay; // 0x4(0x4)
	int ZOrder; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct UUIParticleEmitterAsset* Asset; // 0x10(0x8)
};

// Object: ScriptStruct UIParticle.ScalarParamCurve
// Size: 0x700 (Inherited: 0x0)
struct FScalarParamCurve
{
	struct FName ScalarParamName; // 0x0(0x8)
	struct FUIParticleProperty Value; // 0x8(0x6F8)
};

// Object: ScriptStruct UIParticle.UIParticleProperty
// Size: 0x6F8 (Inherited: 0x0)
struct FUIParticleProperty
{
	uint8_t Type; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float FloatValue; // 0x4(0x4)
	struct FRange_Float FloatRangeValue; // 0x8(0x8)
	struct FUIParticleFloatCurve FloatCurveValue; // 0x10(0x78)
	struct FRange_FloatCurve FloatCurveRangeValue; // 0x88(0xF0)
	struct FVector2D Vector2DValue; // 0x178(0x8)
	struct FRange_Vector2D Vector2DRangeValue; // 0x180(0x14)
	uint8_t Pad_0x194[0x4]; // 0x194(0x4)
	struct FUIParticleLinearColorCurve LinearColorCurveValue; // 0x198(0x1C8)
	struct FRange_LinearColorCurve LinearColorCurveRangeValue; // 0x360(0x398)
};

// Object: ScriptStruct UIParticle.Range_LinearColorCurve
// Size: 0x398 (Inherited: 0x0)
struct FRange_LinearColorCurve
{
	struct FUIParticleLinearColorCurve Min; // 0x0(0x1C8)
	struct FUIParticleLinearColorCurve Max; // 0x1C8(0x1C8)
	bool RandomKey_R_G; // 0x390(0x1)
	bool RandomKey_R_B; // 0x391(0x1)
	bool RandomKey_R_A; // 0x392(0x1)
	bool RandomKey_G_B; // 0x393(0x1)
	bool RandomKey_G_A; // 0x394(0x1)
	bool RandomKey_B_A; // 0x395(0x1)
	uint8_t Pad_0x396[0x2]; // 0x396(0x2)
};

// Object: ScriptStruct UIParticle.UIParticleLinearColorCurve
// Size: 0x1C8 (Inherited: 0x0)
struct FUIParticleLinearColorCurve
{
	struct FRichCurve ColorCurves[0x4]; // 0x0(0x1C0)
	uint8_t CurveType; // 0x1C0(0x1)
	bool Loop; // 0x1C1(0x1)
	uint8_t Pad_0x1C2[0x6]; // 0x1C2(0x6)
};

// Object: ScriptStruct UIParticle.Range_Vector2D
// Size: 0x14 (Inherited: 0x0)
struct FRange_Vector2D
{
	struct FVector2D Min; // 0x0(0x8)
	struct FVector2D Max; // 0x8(0x8)
	bool RandomKey_X_Y; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
};

// Object: ScriptStruct UIParticle.Range_FloatCurve
// Size: 0xF0 (Inherited: 0x0)
struct FRange_FloatCurve
{
	struct FUIParticleFloatCurve Min; // 0x0(0x78)
	struct FUIParticleFloatCurve Max; // 0x78(0x78)
};

// Object: ScriptStruct UIParticle.UIParticleFloatCurve
// Size: 0x78 (Inherited: 0x0)
struct FUIParticleFloatCurve
{
	struct FRichCurve CurveData; // 0x0(0x70)
	uint8_t CurveType; // 0x70(0x1)
	bool Loop; // 0x71(0x1)
	uint8_t Pad_0x72[0x6]; // 0x72(0x6)
};

// Object: ScriptStruct UIParticle.Range_Float
// Size: 0x8 (Inherited: 0x0)
struct FRange_Float
{
	float Min; // 0x0(0x4)
	float Max; // 0x4(0x4)
};

// Object: ScriptStruct UIParticle.Size_Vector2DCurve
// Size: 0xDF0 (Inherited: 0x0)
struct FSize_Vector2DCurve
{
	struct FUIParticleProperty Min; // 0x0(0x6F8)
	struct FUIParticleProperty Max; // 0x6F8(0x6F8)
};

// Object: ScriptStruct UIParticle.Posotion_Vector2DCurve
// Size: 0xDF0 (Inherited: 0x0)
struct FPosotion_Vector2DCurve
{
	struct FUIParticleProperty X; // 0x0(0x6F8)
	struct FUIParticleProperty Y; // 0x6F8(0x6F8)
};

// Object: ScriptStruct UIParticle.ScalarParamFloat
// Size: 0x10 (Inherited: 0x0)
struct FScalarParamFloat
{
	struct FName ScalarParamName; // 0x0(0x8)
	struct FRange_Float Value; // 0x8(0x8)
};

// Object: ScriptStruct UIParticle.ChildEmitter
// Size: 0x18 (Inherited: 0x0)
struct FChildEmitter
{
	float ActivityInParentLifeTime; // 0x0(0x4)
	bool FollowParentPosition; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	float FollowParentSpeedPercent; // 0x8(0x4)
	int ZOrderOffset; // 0xC(0x4)
	struct UUIParticleEmitterAsset* ChildrenAsset; // 0x10(0x8)
};

// Object: ScriptStruct UIParticle.LerpKeyColor
// Size: 0x10 (Inherited: 0x0)
struct FLerpKeyColor
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct UIParticle.LerpKeyVector2D
// Size: 0x8 (Inherited: 0x0)
struct FLerpKeyVector2D
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: Class UIParticle.UIParticle
// Size: 0x130 (Inherited: 0x100)
struct UUIParticle : UWidget
{
	struct UUIParticleAsset* Asset; // 0x100(0x8)
	struct FScriptMulticastDelegate EventOnEnd; // 0x108(0x10)
	uint8_t bPlayParticle : 1; // 0x118(0x1), Mask(0x1)
	uint8_t BitPad_0x118_1 : 7; // 0x118(0x1)
	bool IsPlaying; // 0x119(0x1)
	uint8_t Pad_0x11A[0x16]; // 0x11A(0x16)


	// Object: Function UIParticle.UIParticle.StopEmit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed2f8
	// Params: [ Num(0) Size(0x0) ]
	void StopEmit();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function UIParticle.UIParticle.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed2e4
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function UIParticle.UIParticle.SetPlayParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed260
	// Params: [ Num(1) Size(0x1) ]
	void SetPlayParticle(bool InPlayParticle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FE8858
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UIParticle.UIParticle.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed24c
	// Params: [ Num(0) Size(0x0) ]
	void Play();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FE8858
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class UIParticle.UIParticleAsset
// Size: 0x38 (Inherited: 0x28)
struct UUIParticleAsset : UObject
{
	struct TArray<struct FUIParticleEmitterInfo> Emitters; // 0x28(0x10)
};

// Object: Class UIParticle.UIParticleEmitter
// Size: 0x130 (Inherited: 0x100)
struct UUIParticleEmitter : UWidget
{
	struct UUIParticleEmitterAsset* Asset; // 0x100(0x8)
	struct FScriptMulticastDelegate EventOnEnd; // 0x108(0x10)
	uint8_t bPlayParticle : 1; // 0x118(0x1), Mask(0x1)
	uint8_t BitPad_0x118_1 : 7; // 0x118(0x1)
	bool IsPlaying; // 0x119(0x1)
	uint8_t Pad_0x11A[0x16]; // 0x11A(0x16)


	// Object: Function UIParticle.UIParticleEmitter.StopEmit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed820
	// Params: [ Num(0) Size(0x0) ]
	void StopEmit();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function UIParticle.UIParticleEmitter.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed80c
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function UIParticle.UIParticleEmitter.SetPlayParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed788
	// Params: [ Num(1) Size(0x1) ]
	void SetPlayParticle(bool InPlayParticle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FE8CE8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UIParticle.UIParticleEmitter.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fed774
	// Params: [ Num(0) Size(0x0) ]
	void Play();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FE8CE8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class UIParticle.UIParticleEmitterAsset
// Size: 0xBCD0 (Inherited: 0x28)
struct UUIParticleEmitterAsset : UObject
{
	uint8_t EmitterType; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float EmitSeconds; // 0x2C(0x4)
	struct FUIParticleProperty MaxParticleCount; // 0x30(0x6F8)
	struct FUIParticleProperty SpawnParticlePerSecond; // 0x728(0x6F8)
	struct FUIParticleProperty ParticleEmitAngle; // 0xE20(0x6F8)
	struct FRange_Vector2D EmitPosRange; // 0x1518(0x14)
	uint8_t Pad_0x152C[0x4]; // 0x152C(0x4)
	struct FPosotion_Vector2DCurve EmitPosition; // 0x1530(0xDF0)
	bool AutoEmitPosRange; // 0x2320(0x1)
	bool AutoScale; // 0x2321(0x1)
	bool ScaleByX; // 0x2322(0x1)
	uint8_t Pad_0x2323[0x1]; // 0x2323(0x1)
	struct FVector2D DesignSize; // 0x2324(0x8)
	uint8_t PositionType; // 0x232C(0x1)
	uint8_t Pad_0x232D[0x3]; // 0x232D(0x3)
	struct FUIParticleProperty LifeSpan; // 0x2330(0x6F8)
	struct FUIParticleProperty Size; // 0x2A28(0x6F8)
	struct FUIParticleProperty Pivot; // 0x3120(0x6F8)
	struct FUIParticleProperty RotationStart; // 0x3818(0x6F8)
	struct FUIParticleProperty RotationSpeed; // 0x3F10(0x6F8)
	struct FUIParticleProperty Color; // 0x4608(0x6F8)
	struct UObject* ResourceObject; // 0x4D00(0x8)
	bool RotationFollowSpeed; // 0x4D08(0x1)
	bool UseSeparateSize; // 0x4D09(0x1)
	uint8_t Pad_0x4D0A[0x6]; // 0x4D0A(0x6)
	struct FUIParticleProperty Gravity; // 0x4D10(0x6F8)
	struct FUIParticleProperty StartSpeed; // 0x5408(0x6F8)
	struct FUIParticleProperty AirResistance; // 0x5B00(0x6F8)
	struct FUIParticleProperty RadialAcceleration; // 0x61F8(0x6F8)
	struct FUIParticleProperty TangentialAcceleration; // 0x68F0(0x6F8)
	struct FUIParticleProperty Radius; // 0x6FE8(0x6F8)
	struct FUIParticleProperty DegreePerSecond; // 0x76E0(0x6F8)
	struct FUIParticleProperty PositionX; // 0x7DD8(0x6F8)
	struct FUIParticleProperty PositionY; // 0x84D0(0x6F8)
	struct TArray<struct FChildEmitter> ChildrenEmitters; // 0x8BC8(0x10)
	struct TArray<struct FScalarParamCurve> ScalarParams; // 0x8BD8(0x10)
	struct TArray<struct FScalarParamCurve> ScalarParamsWhenStart; // 0x8BE8(0x10)
	uint8_t DrawEffect; // 0x8BF8(0x1)
	bool UseScaleFollowSpeedDirection; // 0x8BF9(0x1)
	uint8_t Pad_0x8BFA[0x6]; // 0x8BFA(0x6)
	struct FUIParticleProperty ScaleFollowSpeedDirection; // 0x8C00(0x6F8)
	bool UseScaleFollowSpeedVertical; // 0x92F8(0x1)
	uint8_t Pad_0x92F9[0x7]; // 0x92F9(0x7)
	struct FUIParticleProperty ScaleFollowSpeedVertical; // 0x9300(0x6F8)
	struct FUIParticleProperty DirectionScale; // 0x99F8(0x6F8)
	struct FUIParticleProperty VerticalDirectionScale; // 0xA0F0(0x6F8)
	struct FUIParticleProperty SineDirectionStart; // 0xA7E8(0x6F8)
	struct FUIParticleProperty SineDirectionSpeed; // 0xAEE0(0x6F8)
	struct FUIParticleProperty SineDirectionRange; // 0xB5D8(0x6F8)
};

