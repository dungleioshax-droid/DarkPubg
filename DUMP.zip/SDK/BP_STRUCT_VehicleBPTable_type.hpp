#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehicleBPTable_type.BP_STRUCT_VehicleBPTable_type
// Size: 0x40 (Inherited: 0x0)
struct FBP_STRUCT_VehicleBPTable_type
{
	int ID_0_0D9DF74051BBD583279703B701F172E4; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Path_2_2F72974026FE3BC32110651501735958; // 0x8(0x10)
	struct FString CName_3_138BC5001BE2FE5E5E66B36807255925; // 0x18(0x10)
	int VehicleShapeID_4_2C43E38070C85DC025E56CC303F69884; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString LobbyPath_5_4594B5404A7DACE145FA22A607895AE8; // 0x30(0x10)
};

