#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_RegionNo_type.BP_STRUCT_RegionNo_type
// Size: 0x8 (Inherited: 0x0)
struct FBP_STRUCT_RegionNo_type
{
	int country_0_3B96D2C060DA453F186EAF900DC8C429; // 0x0(0x4)
	int region_1_1913AEC0609F05AD760068620AD117AE; // 0x4(0x4)
};

