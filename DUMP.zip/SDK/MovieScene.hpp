#pragma once

#include <cstdint>

// Object: Enum MovieScene.EMovieSceneKeyInterpolation
enum class EMovieSceneKeyInterpolation : uint8_t
{
	Auto = 0,
	User = 1,
	Break = 2,
	Linear = 3,
	Constant = 4,
	EMovieSceneKeyInterpolation_MAX = 5
};

// Object: Enum MovieScene.EMovieSceneBlendType
enum class EMovieSceneBlendType : uint8_t
{
	Absolute = 1,
	Additive = 2,
	Relative = 4,
	EMovieSceneBlendType_MAX = 5
};

// Object: Enum MovieScene.EMovieSceneBuiltInEasing
enum class EMovieSceneBuiltInEasing : uint8_t
{
	Linear = 0,
	SinIn = 1,
	SinOut = 2,
	SinInOut = 3,
	QuadIn = 4,
	QuadOut = 5,
	QuadInOut = 6,
	CubicIn = 7,
	CubicOut = 8,
	CubicInOut = 9,
	QuartIn = 10,
	QuartOut = 11,
	QuartInOut = 12,
	QuintIn = 13,
	QuintOut = 14,
	QuintInOut = 15,
	ExpoIn = 16,
	ExpoOut = 17,
	ExpoInOut = 18,
	CircIn = 19,
	CircOut = 20,
	CircInOut = 21,
	EMovieSceneBuiltInEasing_MAX = 22
};

// Object: Enum MovieScene.EEvaluationMethod
enum class EEvaluationMethod : uint8_t
{
	Static = 0,
	Swept = 1,
	EEvaluationMethod_MAX = 2
};

// Object: Enum MovieScene.EMovieScenePlayerStatus
enum class EMovieScenePlayerStatus : uint8_t
{
	Stopped = 0,
	Playing = 1,
	Recording = 2,
	Scrubbing = 3,
	Jumping = 4,
	Stepping = 5,
	Paused = 6,
	MAX = 7
};

// Object: Enum MovieScene.EMovieSceneObjectBindingSpace
enum class EMovieSceneObjectBindingSpace : uint8_t
{
	Local = 0,
	Root = 1,
	EMovieSceneObjectBindingSpace_MAX = 2
};

// Object: Enum MovieScene.EMovieSceneCompletionMode
enum class EMovieSceneCompletionMode : uint8_t
{
	KeepState = 0,
	RestoreState = 1,
	EMovieSceneCompletionMode_MAX = 2
};

// Object: Enum MovieScene.ESectionEvaluationFlags
enum class ESectionEvaluationFlags : uint8_t
{
	None = 0,
	PreRoll = 1,
	PostRoll = 2,
	ESectionEvaluationFlags_MAX = 3
};

// Object: Enum MovieScene.ESpawnUserQualitySettingLevel
enum class ESpawnUserQualitySettingLevel : uint8_t
{
	UserQualitySettingLevel_Low = 0,
	UserQualitySettingLevel_Middle = 1,
	UserQualitySettingLevel_High = 2,
	UserQualitySettingLevel_MAX = 3
};

// Object: Enum MovieScene.ESpawnDeviceLevel
enum class ESpawnDeviceLevel : uint8_t
{
	DeviceLevel_Low = 0,
	DeviceLevel_Middle = 1,
	DeviceLevel_High = 2,
	DeviceLevel_MAX = 3
};

// Object: Enum MovieScene.ESpawnOwnership
enum class ESpawnOwnership : uint8_t
{
	InnerSequence = 0,
	MasterSequence = 1,
	External = 2,
	ESpawnOwnership_MAX = 3
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceID
// Size: 0x4 (Inherited: 0x0)
struct FMovieSceneSequenceID
{
	uint32_t Value; // 0x0(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplateBase
// Size: 0x10 (Inherited: 0x0)
struct FMovieSceneEvalTemplateBase
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplate
// Size: 0x18 (Inherited: 0x10)
struct FMovieSceneEvalTemplate : FMovieSceneEvalTemplateBase
{
	uint8_t CompletionMode; // 0x9(0x1)
	struct UMovieSceneSection* SourceSection; // 0x10(0x8)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackImplementation
// Size: 0x10 (Inherited: 0x10)
struct FMovieSceneTrackImplementation : FMovieSceneEvalTemplateBase
{
};

// Object: ScriptStruct MovieScene.MovieSceneObjectBindingID
// Size: 0x18 (Inherited: 0x0)
struct FMovieSceneObjectBindingID
{
	int SequenceID; // 0x0(0x4)
	uint8_t Space; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct FGuid Guid; // 0x8(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackLabels
// Size: 0x10 (Inherited: 0x0)
struct FMovieSceneTrackLabels
{
	struct TArray<struct FString> Strings; // 0x0(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneEditorData
// Size: 0x70 (Inherited: 0x0)
struct FMovieSceneEditorData
{
	struct TMap<struct FString, struct FMovieSceneExpansionState> ExpansionStates; // 0x0(0x50)
	struct FFloatRange WorkingRange; // 0x50(0x10)
	struct FFloatRange ViewRange; // 0x60(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneExpansionState
// Size: 0x1 (Inherited: 0x0)
struct FMovieSceneExpansionState
{
	bool bExpanded; // 0x0(0x1)
};

// Object: ScriptStruct MovieScene.MovieSceneBinding
// Size: 0x30 (Inherited: 0x0)
struct FMovieSceneBinding
{
	struct FGuid ObjectGuid; // 0x0(0x10)
	struct FString BindingName; // 0x10(0x10)
	struct TArray<struct UMovieSceneTrack*> Tracks; // 0x20(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneBindingOverrideData
// Size: 0x24 (Inherited: 0x0)
struct FMovieSceneBindingOverrideData
{
	struct FMovieSceneObjectBindingID ObjectBindingId; // 0x0(0x18)
	struct TWeakObjectPtr<struct UObject> Object; // 0x18(0x8)
	bool bOverridesDefault; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
};

// Object: ScriptStruct MovieScene.OptionalMovieSceneBlendType
// Size: 0x2 (Inherited: 0x0)
struct FOptionalMovieSceneBlendType
{
	uint8_t BlendType; // 0x0(0x1)
	bool bIsValid; // 0x1(0x1)
};

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplatePtr
// Size: 0x38 (Inherited: 0x0)
struct FMovieSceneEvalTemplatePtr
{
	uint8_t Pad_0x0[0x38]; // 0x0(0x38)
};

// Object: ScriptStruct MovieScene.MovieSceneEmptyStruct
// Size: 0x1 (Inherited: 0x0)
struct FMovieSceneEmptyStruct
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationField
// Size: 0x30 (Inherited: 0x0)
struct FMovieSceneEvaluationField
{
	struct TArray<struct FFloatRange> Ranges; // 0x0(0x10)
	struct TArray<struct FMovieSceneEvaluationGroup> Groups; // 0x10(0x10)
	struct TArray<struct FMovieSceneEvaluationMetaData> MetaData; // 0x20(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationMetaData
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneEvaluationMetaData
{
	struct TArray<struct FMovieSceneSequenceID> ActiveSequences; // 0x0(0x10)
	struct TArray<struct FMovieSceneOrderedEvaluationKey> ActiveEntities; // 0x10(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneOrderedEvaluationKey
// Size: 0x10 (Inherited: 0x0)
struct FMovieSceneOrderedEvaluationKey
{
	struct FMovieSceneEvaluationKey Key; // 0x0(0xC)
	uint32_t EvaluationIndex; // 0xC(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationKey
// Size: 0xC (Inherited: 0x0)
struct FMovieSceneEvaluationKey
{
	struct FMovieSceneSequenceID SequenceID; // 0x0(0x4)
	struct FMovieSceneTrackIdentifier TrackIdentifier; // 0x4(0x4)
	uint32_t SectionIdentifier; // 0x8(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackIdentifier
// Size: 0x4 (Inherited: 0x0)
struct FMovieSceneTrackIdentifier
{
	uint32_t Value; // 0x0(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationGroup
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneEvaluationGroup
{
	struct TArray<struct FMovieSceneEvaluationGroupLUTIndex> LUTIndices; // 0x0(0x10)
	struct TArray<struct FMovieSceneEvaluationFieldSegmentPtr> SegmentPtrLUT; // 0x10(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationFieldTrackPtr
// Size: 0x8 (Inherited: 0x0)
struct FMovieSceneEvaluationFieldTrackPtr
{
	struct FMovieSceneSequenceID SequenceID; // 0x0(0x4)
	struct FMovieSceneTrackIdentifier TrackIdentifier; // 0x4(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationFieldSegmentPtr
// Size: 0xC (Inherited: 0x8)
struct FMovieSceneEvaluationFieldSegmentPtr : FMovieSceneEvaluationFieldTrackPtr
{
	int SegmentIndex; // 0x8(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationGroupLUTIndex
// Size: 0xC (Inherited: 0x0)
struct FMovieSceneEvaluationGroupLUTIndex
{
	int LUTOffset; // 0x0(0x4)
	int NumInitPtrs; // 0x4(0x4)
	int NumEvalPtrs; // 0x8(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTemplate
// Size: 0x220 (Inherited: 0x0)
struct FMovieSceneEvaluationTemplate
{
	struct TMap<uint32_t, struct FMovieSceneEvaluationTrack> Tracks; // 0x0(0x50)
	uint8_t Pad_0x50[0x50]; // 0x50(0x50)
	struct FMovieSceneEvaluationField EvaluationField; // 0xA0(0x30)
	struct FMovieSceneSequenceHierarchy Hierarchy; // 0xD0(0xA0)
	struct FMovieSceneTemplateGenerationLedger TemplateLedger; // 0x170(0xA8)
	uint8_t bHasLegacyTrackInstances : 1; // 0x218(0x1), Mask(0x1)
	uint8_t bKeepStaleTracks : 1; // 0x218(0x1), Mask(0x2)
	uint8_t BitPad_0x218_2 : 6; // 0x218(0x1)
	uint8_t Pad_0x219[0x7]; // 0x219(0x7)
};

// Object: ScriptStruct MovieScene.MovieSceneTemplateGenerationLedger
// Size: 0xA8 (Inherited: 0x0)
struct FMovieSceneTemplateGenerationLedger
{
	struct FMovieSceneTrackIdentifier LastTrackIdentifier; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TMap<struct FMovieSceneTrackIdentifier, int> TrackReferenceCounts; // 0x8(0x50)
	struct TMap<struct FGuid, struct FMovieSceneTrackIdentifiers> TrackSignatureToTrackIdentifier; // 0x58(0x50)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackIdentifiers
// Size: 0x10 (Inherited: 0x0)
struct FMovieSceneTrackIdentifiers
{
	struct TArray<struct FMovieSceneTrackIdentifier> Data; // 0x0(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceHierarchy
// Size: 0xA0 (Inherited: 0x0)
struct FMovieSceneSequenceHierarchy
{
	struct TMap<uint32_t, struct FMovieSceneSubSequenceData> SubSequences; // 0x0(0x50)
	struct TMap<uint32_t, struct FMovieSceneSequenceHierarchyNode> Hierarchy; // 0x50(0x50)
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceHierarchyNode
// Size: 0x18 (Inherited: 0x0)
struct FMovieSceneSequenceHierarchyNode
{
	struct FMovieSceneSequenceID ParentID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FMovieSceneSequenceID> Children; // 0x8(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneSubSequenceData
// Size: 0x50 (Inherited: 0x0)
struct FMovieSceneSubSequenceData
{
	struct UMovieSceneSequence* Sequence; // 0x0(0x8)
	struct UObject* SequenceKeyObject; // 0x8(0x8)
	struct FMovieSceneSequenceTransform RootToSequenceTransform; // 0x10(0x8)
	struct FGuid SourceSequenceSignature; // 0x18(0x10)
	struct FMovieSceneSequenceID DeterministicSequenceID; // 0x28(0x4)
	struct FFloatRange PreRollRange; // 0x2C(0x10)
	struct FFloatRange PostRollRange; // 0x3C(0x10)
	int HierarchicalBias; // 0x4C(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceTransform
// Size: 0x8 (Inherited: 0x0)
struct FMovieSceneSequenceTransform
{
	float TimeScale; // 0x0(0x4)
	float Offset; // 0x4(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTrack
// Size: 0x80 (Inherited: 0x0)
struct FMovieSceneEvaluationTrack
{
	struct FGuid ObjectBindingId; // 0x0(0x10)
	uint16_t EvaluationPriority; // 0x10(0x2)
	uint8_t EvaluationMethod; // 0x12(0x1)
	uint8_t Pad_0x13[0x5]; // 0x13(0x5)
	struct TArray<struct FMovieSceneSegment> Segments; // 0x18(0x10)
	struct TArray<struct FMovieSceneEvalTemplatePtr> ChildTemplates; // 0x28(0x10)
	struct FMovieSceneTrackImplementationPtr TrackTemplate; // 0x38(0x38)
	struct FName EvaluationGroup; // 0x70(0x8)
	uint8_t bEvaluateInPreroll : 1; // 0x78(0x1), Mask(0x1)
	uint8_t bEvaluateInPostroll : 1; // 0x78(0x1), Mask(0x2)
	uint8_t BitPad_0x78_2 : 6; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackImplementationPtr
// Size: 0x38 (Inherited: 0x0)
struct FMovieSceneTrackImplementationPtr
{
	uint8_t Pad_0x0[0x38]; // 0x0(0x38)
};

// Object: ScriptStruct MovieScene.MovieSceneSegment
// Size: 0x50 (Inherited: 0x0)
struct FMovieSceneSegment
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct MovieScene.CachedMovieSceneEvaluationTemplate
// Size: 0x220 (Inherited: 0x220)
struct FCachedMovieSceneEvaluationTemplate : FMovieSceneEvaluationTemplate
{
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceCachedSignature
// Size: 0x18 (Inherited: 0x0)
struct FMovieSceneSequenceCachedSignature
{
	struct TWeakObjectPtr<struct UMovieSceneSequence> Sequence; // 0x0(0x8)
	struct FGuid CachedSignature; // 0x8(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneKeyStruct
// Size: 0x8 (Inherited: 0x0)
struct FMovieSceneKeyStruct
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct MovieScene.MovieSceneLegacyTrackInstanceTemplate
// Size: 0x20 (Inherited: 0x18)
struct FMovieSceneLegacyTrackInstanceTemplate : FMovieSceneEvalTemplate
{
	struct UMovieSceneTrack* Track; // 0x18(0x8)
};

// Object: ScriptStruct MovieScene.MovieScenePossessable
// Size: 0x38 (Inherited: 0x0)
struct FMovieScenePossessable
{
	struct FGuid Guid; // 0x0(0x10)
	struct FString Name; // 0x10(0x10)
	struct UObject* PossessedObjectClass; // 0x20(0x8)
	struct FGuid ParentGuid; // 0x28(0x10)
};

// Object: ScriptStruct MovieScene.MovieScenePropertySectionTemplate
// Size: 0x40 (Inherited: 0x18)
struct FMovieScenePropertySectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieScenePropertySectionData PropertyData; // 0x18(0x28)
};

// Object: ScriptStruct MovieScene.MovieScenePropertySectionData
// Size: 0x28 (Inherited: 0x0)
struct FMovieScenePropertySectionData
{
	struct FName PropertyName; // 0x0(0x8)
	struct FString PropertyPath; // 0x8(0x10)
	struct FName FunctionName; // 0x18(0x8)
	struct FName NotifyFunctionName; // 0x20(0x8)
};

// Object: ScriptStruct MovieScene.MovieSceneEasingSettings
// Size: 0x38 (Inherited: 0x0)
struct FMovieSceneEasingSettings
{
	float AutoEaseInTime; // 0x0(0x4)
	float AutoEaseOutTime; // 0x4(0x4)
	struct TScriptInterface<Class> EaseIn; // 0x8(0x10)
	bool bManualEaseIn; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	float ManualEaseInTime; // 0x1C(0x4)
	struct TScriptInterface<Class> EaseOut; // 0x20(0x10)
	bool bManualEaseOut; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	float ManualEaseOutTime; // 0x34(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneSectionEvalOptions
// Size: 0x2 (Inherited: 0x0)
struct FMovieSceneSectionEvalOptions
{
	bool bCanEditCompletionMode; // 0x0(0x1)
	uint8_t CompletionMode; // 0x1(0x1)
};

// Object: ScriptStruct MovieScene.MovieSceneSectionParameters
// Size: 0x14 (Inherited: 0x0)
struct FMovieSceneSectionParameters
{
	float StartOffset; // 0x0(0x4)
	float TimeScale; // 0x4(0x4)
	int HierarchicalBias; // 0x8(0x4)
	float PrerollTime; // 0xC(0x4)
	float PostrollTime; // 0x10(0x4)
};

// Object: ScriptStruct MovieScene.SectionEvaluationData
// Size: 0xC (Inherited: 0x0)
struct FSectionEvaluationData
{
	int ImplIndex; // 0x0(0x4)
	float ForcedTime; // 0x4(0x4)
	uint8_t Flags; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
};

// Object: ScriptStruct MovieScene.MovieSceneSequencePlaybackSettings
// Size: 0x28 (Inherited: 0x0)
struct FMovieSceneSequencePlaybackSettings
{
	int LoopCount; // 0x0(0x4)
	float PlayRate; // 0x4(0x4)
	bool bRandomStartTime; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float StartTime; // 0xC(0x4)
	bool bRestoreState; // 0x10(0x1)
	bool bDisableMovementInput; // 0x11(0x1)
	bool bDisableLookAtInput; // 0x12(0x1)
	bool bHidePlayer; // 0x13(0x1)
	bool bHideHud; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	struct TScriptInterface<Class> BindingOverrides; // 0x18(0x10)
};

// Object: ScriptStruct MovieScene.MovieSceneSpawnable
// Size: 0x40 (Inherited: 0x0)
struct FMovieSceneSpawnable
{
	struct FGuid Guid; // 0x0(0x10)
	struct FString Name; // 0x10(0x10)
	struct UObject* ObjectTemplate; // 0x20(0x8)
	struct TArray<struct FGuid> ChildPossessables; // 0x28(0x10)
	uint8_t Ownership; // 0x38(0x1)
	uint8_t DeviceLevel; // 0x39(0x1)
	uint8_t UserQualitySettingLevel; // 0x3A(0x1)
	uint8_t UnValidDeviceLevel; // 0x3B(0x1)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackEvalOptions
// Size: 0x4 (Inherited: 0x0)
struct FMovieSceneTrackEvalOptions
{
	uint8_t bCanEvaluateNearestSection : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bEvalNearestSection : 1; // 0x0(0x1), Mask(0x2)
	uint8_t bEvaluateInPreroll : 1; // 0x0(0x1), Mask(0x4)
	uint8_t bEvaluateInPostroll : 1; // 0x0(0x1), Mask(0x8)
	uint8_t bEvaluateNearestSection : 1; // 0x0(0x1), Mask(0x10)
	uint8_t BitPad_0x0_5 : 3; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
};

// Object: ScriptStruct MovieScene.MovieSceneTrackCompilationParams
// Size: 0x2 (Inherited: 0x0)
struct FMovieSceneTrackCompilationParams
{
	bool bForEditorPreview; // 0x0(0x1)
	bool bDuringBlueprintCompile; // 0x1(0x1)
};

// Object: Class MovieScene.MovieSceneSignedObject
// Size: 0x50 (Inherited: 0x28)
struct UMovieSceneSignedObject : UObject
{
	struct FGuid Signature; // 0x28(0x10)
	uint8_t Pad_0x38[0x18]; // 0x38(0x18)
};

// Object: Class MovieScene.MovieSceneSection
// Size: 0xB0 (Inherited: 0x50)
struct UMovieSceneSection : UMovieSceneSignedObject
{
	struct FMovieSceneSectionEvalOptions EvalOptions; // 0x50(0x2)
	uint8_t Pad_0x52[0x6]; // 0x52(0x6)
	struct FMovieSceneEasingSettings Easing; // 0x58(0x38)
	float StartTime; // 0x90(0x4)
	float EndTime; // 0x94(0x4)
	int RowIndex; // 0x98(0x4)
	int OverlapPriority; // 0x9C(0x4)
	uint8_t bIsActive : 1; // 0xA0(0x1), Mask(0x1)
	uint8_t bIsLocked : 1; // 0xA0(0x1), Mask(0x2)
	uint8_t bIsInfinite : 1; // 0xA0(0x1), Mask(0x4)
	uint8_t bUseTimeToWeight : 1; // 0xA0(0x1), Mask(0x8)
	uint8_t BitPad_0xA0_4 : 4; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float PrerollTime; // 0xA4(0x4)
	float PostrollTime; // 0xA8(0x4)
	struct FOptionalMovieSceneBlendType BlendType; // 0xAC(0x2)
	uint8_t Pad_0xAE[0x2]; // 0xAE(0x2)
};

// Object: Class MovieScene.MovieSceneTrack
// Size: 0x58 (Inherited: 0x50)
struct UMovieSceneTrack : UMovieSceneSignedObject
{
	struct FMovieSceneTrackEvalOptions EvalOptions; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: Class MovieScene.MovieSceneNameableTrack
// Size: 0x58 (Inherited: 0x58)
struct UMovieSceneNameableTrack : UMovieSceneTrack
{
};

// Object: Class MovieScene.MovieSceneSequence
// Size: 0x2E8 (Inherited: 0x50)
struct UMovieSceneSequence : UMovieSceneSignedObject
{
	struct FCachedMovieSceneEvaluationTemplate EvaluationTemplate; // 0x50(0x220)
	struct FMovieSceneTrackCompilationParams TemplateParameters; // 0x270(0x2)
	uint8_t Pad_0x272[0x6]; // 0x272(0x6)
	struct TMap<struct UObject*, struct FCachedMovieSceneEvaluationTemplate> InstancedSubSequenceEvaluationTemplates; // 0x278(0x50)
	bool bParentContextsAreSignificant; // 0x2C8(0x1)
	uint8_t Pad_0x2C9[0x1F]; // 0x2C9(0x1F)
};

// Object: Class MovieScene.MovieSceneSequencePlayer
// Size: 0x7B8 (Inherited: 0x28)
struct UMovieSceneSequencePlayer : UObject
{
	uint8_t Pad_0x28[0x348]; // 0x28(0x348)
	struct FScriptMulticastDelegate OnPlay; // 0x370(0x10)
	struct FScriptMulticastDelegate OnPlayReverse; // 0x380(0x10)
	struct FScriptMulticastDelegate OnStop; // 0x390(0x10)
	struct FScriptMulticastDelegate OnPreStop; // 0x3A0(0x10)
	bool FreezeEndFrame; // 0x3B0(0x1)
	uint8_t Pad_0x3B1[0x7]; // 0x3B1(0x7)
	struct FScriptMulticastDelegate OnPause; // 0x3B8(0x10)
	struct FScriptMulticastDelegate OnFinished; // 0x3C8(0x10)
	struct FScriptMulticastDelegate OnObjectSpawnedEvent; // 0x3D8(0x10)
	enum class EMovieScenePlayerStatus status; // 0x3E8(0x1)
	uint8_t bReversePlayback : 1; // 0x3E9(0x1), Mask(0x1)
	uint8_t bPendingFirstUpdate : 1; // 0x3E9(0x1), Mask(0x2)
	uint8_t BitPad_0x3E9_2 : 6; // 0x3E9(0x1)
	uint8_t Pad_0x3EA[0x6]; // 0x3EA(0x6)
	struct UMovieSceneSequence* Sequence; // 0x3F0(0x8)
	float TimeCursorPosition; // 0x3F8(0x4)
	float StartTime; // 0x3FC(0x4)
	float EndTime; // 0x400(0x4)
	int CurrentNumLoops; // 0x404(0x4)
	uint8_t Pad_0x408[0x10]; // 0x408(0x10)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x418(0x28)
	uint8_t Pad_0x440[0x378]; // 0x440(0x378)


	// Object: Function MovieScene.MovieSceneSequencePlayer.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4de48
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MovieScene.MovieSceneSequencePlayer.StartPlayingNextTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4de34
	// Params: [ Num(0) Size(0x0) ]
	void StartPlayingNextTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4ddb8
	// Params: [ Num(1) Size(0x4) ]
	void SetPlayRate(float PlayRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C30980
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlayLoopCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dd3c
	// Params: [ Num(1) Size(0x4) ]
	void SetPlayLoopCount(int NumLoops);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C30988
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C30980
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dc88
	// Params: [ Num(2) Size(0x8) ]
	void SetPlaybackRange(float NewStartTime, float NewEndTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C30990
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C30988
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30980
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dc0c
	// Params: [ Num(1) Size(0x4) ]
	void SetPlaybackPosition(float NewPlaybackPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C308E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C30990
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30988
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105C30980

	// Object: Function MovieScene.MovieSceneSequencePlayer.Scrub
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dbf8
	// Params: [ Num(0) Size(0x0) ]
	void Scrub();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C308E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C30990
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30988
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105C30980

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayReverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dbe4
	// Params: [ Num(0) Size(0x0) ]
	void PlayReverse();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C308E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C30990
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30988
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105C30980

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4db68
	// Params: [ Num(1) Size(0x4) ]
	void PlayLooping(int NumLoops);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C302EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C308E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30990
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105C30988

	// Object: Function MovieScene.MovieSceneSequencePlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4db54
	// Params: [ Num(0) Size(0x0) ]
	void Play();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C302EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C308E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30990
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105C30988

	// Object: Function MovieScene.MovieSceneSequencePlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4db40
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C302EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C308E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C30990
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToPositionEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4dac4
	// Params: [ Num(1) Size(0x4) ]
	void JumpToPositionEx(float NewPlaybackPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C3094C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C302EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105C308E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4da48
	// Params: [ Num(1) Size(0x4) ]
	void JumpToPosition(float NewPlaybackPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C30914
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C3094C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105C302EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105C308E0

	// Object: Function MovieScene.MovieSceneSequencePlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4da14
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x105C302F4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105C30914
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105C3094C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C302EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function MovieScene.MovieSceneSequencePlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d9e0
	// Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
	// [Call #1] RVA: 0x105C30870
	// [Call #2] RVA: 0x105C302F4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C30914
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C3094C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C302EC

	// Object: Function MovieScene.MovieSceneSequencePlayer.GoToEndAndStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4d9cc
	// Params: [ Num(0) Size(0x0) ]
	void GoToEndAndStop();
	// [Call #1] RVA: 0x105C30870
	// [Call #2] RVA: 0x105C302F4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C30914
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C3094C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C302EC

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d998
	// Params: [ Num(1) Size(0x4) ]
	float GetPlayRate();
	// [Call #1] RVA: 0x105C30978
	// [Call #2] RVA: 0x105C30870
	// [Call #3] RVA: 0x105C302F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C30914
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105C3094C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105C302EC

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackStart
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d97c
	// Params: [ Num(1) Size(0x4) ]
	float GetPlaybackStart();
	// [Call #1] RVA: 0x105C30978
	// [Call #2] RVA: 0x105C30870
	// [Call #3] RVA: 0x105C302F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105C30914
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105C3094C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105C302EC

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d948
	// Params: [ Num(1) Size(0x4) ]
	float GetPlaybackPosition();
	// [Call #1] RVA: 0x105C3090C
	// [Call #2] RVA: 0x105C30978
	// [Call #3] RVA: 0x105C30870
	// [Call #4] RVA: 0x105C302F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105C30914
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C3094C
	// [Call #11] RVA: 0x10516D168

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackEnd
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d92c
	// Params: [ Num(1) Size(0x4) ]
	float GetPlaybackEnd();
	// [Call #1] RVA: 0x105C3090C
	// [Call #2] RVA: 0x105C30978
	// [Call #3] RVA: 0x105C30870
	// [Call #4] RVA: 0x105C302F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105C30914
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C3094C

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c4d8f8
	// Params: [ Num(1) Size(0x4) ]
	float GetLength();
	// [Call #1] RVA: 0x105C302DC
	// [Call #2] RVA: 0x105C3090C
	// [Call #3] RVA: 0x105C30978
	// [Call #4] RVA: 0x105C30870
	// [Call #5] RVA: 0x105C302F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105C30914
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C3094C

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4d820
	// Params: [ Num(2) Size(0x28) ]
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C310C4
	// [Call #4] RVA: 0x102446ACC
	// [Call #5] RVA: 0x101F8BAA4
	// [Call #6] RVA: 0x101F8BAA4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x105C302DC
	// [Call #9] RVA: 0x105C3090C
	// [Call #10] RVA: 0x105C30978
	// [Call #11] RVA: 0x105C30870
	// [Call #12] RVA: 0x105C302F4

	// Object: Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c4d80c
	// Params: [ Num(0) Size(0x0) ]
	void ChangePlaybackDirection();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105C310C4
	// [Call #4] RVA: 0x102446ACC
	// [Call #5] RVA: 0x101F8BAA4
	// [Call #6] RVA: 0x101F8BAA4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x105C302DC
	// [Call #9] RVA: 0x105C3090C
	// [Call #10] RVA: 0x105C30978
	// [Call #11] RVA: 0x105C30870
	// [Call #12] RVA: 0x105C302F4
};

// Object: Class MovieScene.MovieScene
// Size: 0xD8 (Inherited: 0x50)
struct UMovieScene : UMovieSceneSignedObject
{
	struct TArray<struct FMovieSceneSpawnable> Spawnables; // 0x50(0x10)
	struct TArray<struct FMovieScenePossessable> Possessables; // 0x60(0x10)
	struct TArray<struct FMovieSceneBinding> ObjectBindings; // 0x70(0x10)
	struct TArray<struct UMovieSceneTrack*> MasterTracks; // 0x80(0x10)
	struct UMovieSceneTrack* CameraCutTrack; // 0x90(0x8)
	struct FFloatRange SelectionRange; // 0x98(0x10)
	struct FFloatRange PlaybackRange; // 0xA8(0x10)
	bool bForceFixedFrameIntervalPlayback; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	float FixedFrameInterval; // 0xBC(0x4)
	float InTime; // 0xC0(0x4)
	float OutTime; // 0xC4(0x4)
	float StartTime; // 0xC8(0x4)
	float EndTime; // 0xCC(0x4)
	bool bLowDeviceFrameRateLimitEnabled; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	int LowDeviceFrameLimit; // 0xD4(0x4)
};

// Object: Class MovieScene.MovieSceneBindingOverrides
// Size: 0x98 (Inherited: 0x28)
struct UMovieSceneBindingOverrides : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData; // 0x30(0x10)
	uint8_t Pad_0x40[0x58]; // 0x40(0x58)
};

// Object: Class MovieScene.MovieSceneBindingOverridesInterface
// Size: 0x28 (Inherited: 0x28)
struct IMovieSceneBindingOverridesInterface : IInterface
{
};

// Object: Class MovieScene.MovieSceneBindingOwnerInterface
// Size: 0x28 (Inherited: 0x28)
struct IMovieSceneBindingOwnerInterface : IInterface
{
};

// Object: Class MovieScene.MovieSceneBuiltInEasingFunction
// Size: 0x38 (Inherited: 0x28)
struct UMovieSceneBuiltInEasingFunction : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	uint8_t Type; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: Class MovieScene.MovieSceneEasingExternalCurve
// Size: 0x38 (Inherited: 0x28)
struct UMovieSceneEasingExternalCurve : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct UCurveFloat* Curve; // 0x30(0x8)
};

// Object: Class MovieScene.MovieSceneEasingFunction
// Size: 0x28 (Inherited: 0x28)
struct IMovieSceneEasingFunction : IInterface
{

	// Object: Function MovieScene.MovieSceneEasingFunction.OnEvaluate
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x8) ]
	float OnEvaluate(float Interp);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class MovieScene.MovieSceneFolder
// Size: 0x70 (Inherited: 0x28)
struct UMovieSceneFolder : UObject
{
	struct FName FolderName; // 0x28(0x8)
	struct TArray<struct UMovieSceneFolder*> ChildFolders; // 0x30(0x10)
	struct TArray<struct UMovieSceneTrack*> ChildMasterTracks; // 0x40(0x10)
	struct TArray<struct FString> ChildObjectBindingStrings; // 0x50(0x10)
	uint8_t Pad_0x60[0x10]; // 0x60(0x10)
};

// Object: Class MovieScene.MovieSceneSegmentCompilerTestTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneSegmentCompilerTestTrack : UMovieSceneTrack
{
	bool bHighPassFilter; // 0x55(0x1)
	struct TArray<struct UMovieSceneSection*> SectionArray; // 0x58(0x10)
};

// Object: Class MovieScene.MovieSceneSegmentCompilerTestSection
// Size: 0xB0 (Inherited: 0xB0)
struct UMovieSceneSegmentCompilerTestSection : UMovieSceneSection
{
};

