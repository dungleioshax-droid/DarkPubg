#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_CorpsBadge_type.BP_STRUCT_CorpsBadge_type
// Size: 0x40 (Inherited: 0x0)
struct FBP_STRUCT_CorpsBadge_type
{
	struct FString BigIconPath_0_10CC26002C2272C4426923F90B6405C8; // 0x0(0x10)
	int ID_1_5727FF4053D9C66568AE85A909693024; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString IconPath_2_038F818050E2694643DA924F014A58A8; // 0x18(0x10)
	struct FString Name_3_56563C4042608BF33377F2DB0931BF55; // 0x28(0x10)
	int TabPosi_4_17AFE880638188BE77062DBF05E20589; // 0x38(0x4)
	int UnLockLv_5_04857F8051FE2B7A53B16D630C5CAF66; // 0x3C(0x4)
};

