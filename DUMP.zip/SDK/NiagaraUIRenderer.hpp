#pragma once

#include <cstdint>

// Object: Class NiagaraUIRenderer.NiagaraSystemWidget
// Size: 0x198 (Inherited: 0x100)
struct UNiagaraSystemWidget : UWidget
{
	struct UNiagaraSystem* NiagaraSystemReference; // 0x100(0x8)
	struct TMap<struct UMaterialInterface*, struct UMaterialInterface*> MaterialRemapList; // 0x108(0x50)
	struct FVector2D Offset2D; // 0x158(0x8)
	struct FRotator Rotation3D; // 0x160(0xC)
	bool AutoActivate; // 0x16C(0x1)
	bool TickWhenPaused; // 0x16D(0x1)
	bool FakeDepthScale; // 0x16E(0x1)
	uint8_t Pad_0x16F[0x1]; // 0x16F(0x1)
	float FakeDepthScaleDistance; // 0x170(0x4)
	uint8_t bIsActivated : 1; // 0x174(0x1), Mask(0x1)
	uint8_t BitPad_0x174_1 : 7; // 0x174(0x1)
	uint8_t Pad_0x175[0x13]; // 0x175(0x13)
	struct ANiagaraUIActor* NiagaraActor; // 0x188(0x8)
	struct UNiagaraUIComponent* NiagaraComponent; // 0x190(0x8)


	// Object: Function NiagaraUIRenderer.NiagaraSystemWidget.SetIsActivated
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102c3687c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsActivated(bool bInIsActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function NiagaraUIRenderer.NiagaraSystemWidget.GetNiagaraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102c36848
	// Params: [ Num(1) Size(0x8) ]
	struct UNiagaraUIComponent* GetNiagaraComponent();
	// [Call #1] RVA: 0x102C31C48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function NiagaraUIRenderer.NiagaraSystemWidget.GetIsActivated
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c36814
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsActivated();
	// [Call #1] RVA: 0x102C31BF0
	// [Call #2] RVA: 0x102C31C48
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function NiagaraUIRenderer.NiagaraSystemWidget.DeactivateSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c36800
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateSystem();
	// [Call #1] RVA: 0x102C31BF0
	// [Call #2] RVA: 0x102C31C48
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function NiagaraUIRenderer.NiagaraSystemWidget.ActivateSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c3677c
	// Params: [ Num(1) Size(0x1) ]
	void ActivateSystem(bool Reset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C31BC0
	// [Call #4] RVA: 0x102C31BF0
	// [Call #5] RVA: 0x102C31C48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class NiagaraUIRenderer.NiagaraUIActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct ANiagaraUIActor : AActor
{
};

// Object: Class NiagaraUIRenderer.NiagaraUIComponent
// Size: 0xBB0 (Inherited: 0xB90)
struct UNiagaraUIComponent : UNiagaraComponent
{
	uint8_t Pad_0xB90[0x20]; // 0xB90(0x20)
};

