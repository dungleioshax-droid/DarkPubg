#pragma once

#include <cstdint>

// Object: Enum MaterialShaderQualitySettings.EMobileCSMQuality
enum class EMobileCSMQuality : uint8_t
{
	NoFiltering = 0,
	PCF_1x1 = 1,
	PCF_2x2 = 2,
	EMobileCSMQuality_MAX = 3
};

// Object: ScriptStruct MaterialShaderQualitySettings.MaterialQualityOverrides
// Size: 0x8 (Inherited: 0x0)
struct FMaterialQualityOverrides
{
	bool bEnableOverride; // 0x0(0x1)
	bool bForceFullyRough; // 0x1(0x1)
	bool bForceNonMetal; // 0x2(0x1)
	bool bForceDisableLMDirectionality; // 0x3(0x1)
	bool bForceLQReflections; // 0x4(0x1)
	uint8_t MobileCSMQuality; // 0x5(0x1)
	uint8_t MobilePointLightShadowQuality; // 0x6(0x1)
	uint8_t MobilePhotonShadowQuality; // 0x7(0x1)
};

// Object: Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Size: 0x78 (Inherited: 0x28)
struct UMaterialShaderQualitySettings : UObject
{
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap; // 0x28(0x50)
};

// Object: Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Size: 0x40 (Inherited: 0x28)
struct UShaderPlatformQualitySettings : UObject
{
	struct FMaterialQualityOverrides QualityOverrides[0x3]; // 0x28(0x18)
};

