#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Reconnect_UIBP.Reconnect_UIBP_C
// Size: 0x278 (Inherited: 0x260)
struct UReconnect_UIBP_C : UUserWidget
{
	struct UButton* Button_Bg; // 0x260(0x8)
	struct UCanvasPanel* CanvasPanel_1; // 0x268(0x8)
	struct UTextBlock* TextBlock_Tips; // 0x270(0x8)
};

