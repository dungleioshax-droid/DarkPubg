#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LevelUnLockSystemConfig_type.BP_STRUCT_LevelUnLockSystemConfig_type
// Size: 0x28 (Inherited: 0x0)
struct FBP_STRUCT_LevelUnLockSystemConfig_type
{
	struct FString IconPath_3_7C9B52C036EC4BE564B11987066BCFF8; // 0x0(0x10)
	int SystemID_4_462B11C04FA0BAF74638CAB20CA227C4; // 0x10(0x4)
	int SystemName_5_7736CEC05B30C1C15DE54FAB02285C95; // 0x14(0x4)
	struct FString CheckFunction_6_22E4F6407D715825528B5EC70961BBFE; // 0x18(0x10)
};

