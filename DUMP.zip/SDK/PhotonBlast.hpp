#pragma once

#include <cstdint>

// Object: Enum PhotonBlast.EDestructionDamageType
enum class EDestructionDamageType : uint8_t
{
	EDestructionDamage_ShootWeapon = 0,
	EDestructionDamage_Projectile = 1,
	EDestructionDamage_Melee = 2,
	EDestructionDamage_Grenade = 3,
	EDestructionDamage_Vehicle = 4,
	EDestructionDamage_VehicleTrigger = 5,
	EDestructionDamage_VehicleExplosion = 6,
	EDestructionDamage_DropActor = 7,
	EDestructionDamage_GasLineExplosion = 8,
	EDestructionDamage_Other = 9,
	EDestructionDamage_Max = 15
};

// Object: Enum PhotonBlast.EEffectType
enum class EEffectType : uint8_t
{
	None_Type = 0,
	BrokenEffect = 1,
	SimulationEffect = 2,
	AnimationEffect = 3,
	EEffectType_MAX = 4
};

// Object: Enum PhotonBlast.EPhotonFracturedMeshFragmentState
enum class EPhotonFracturedMeshFragmentState : uint8_t
{
	PhotonFracturedMesh_Initial = 0,
	PhotonFracturedMesh_UnderDestruction = 1,
	PhotonFracturedMesh_Damaged = 2,
	PhotonFractureMesh_DamagedByCollapse = 3,
	EPhotonFracturedMeshFragmentState_MAX = 4
};

// Object: Enum PhotonBlast.EPhotonDestructibleKey
enum class EPhotonDestructibleKey : uint8_t
{
	Reset = 0,
	Trigger = 1,
	EPhotonDestructibleKey_MAX = 2
};

// Object: Enum PhotonBlast.ESlicedAxis
enum class ESlicedAxis : uint8_t
{
	SlicedAxis_X = 0,
	SlicedAxis_Y = 1,
	SlicedAxis_Z = 2,
	SlicedAxis_NX = 3,
	SlicedAxis_NY = 4,
	SlicedAxis_NZ = 5,
	SlicedAxis_MAX = 6
};

// Object: Enum PhotonBlast.EPhotonCollisionType
enum class EPhotonCollisionType : uint8_t
{
	PhotonCollisionType_Simple = 0,
	PhotonCollisionType_Complex = 1,
	PhotonCollisionType_MAX = 2
};

// Object: Enum PhotonBlast.EPhotonDestructibleAction
enum class EPhotonDestructibleAction : uint8_t
{
	PhotonDestructibleAction_Hide = 0,
	PhotonDestructibleAction_Detach = 1,
	PhotonDestructibleAction_Slide = 2,
	PhotonDestructibleAction_MAX = 3
};

// Object: Enum PhotonBlast.EPhotonDestructibleState
enum class EPhotonDestructibleState : uint8_t
{
	PhotonPDState_UnBroken = 0,
	PhotonPDState_Broken = 1,
	PhotonPDState_AllHidden = 2,
	PhotonPDState_Collapse = 3,
	PhotonPDState_Recovery = 4,
	PhotonPDState_Invalid = 5,
	PhotonPDState_MAX = 6
};

// Object: Enum PhotonBlast.EPhotonMeshFragmentType
enum class EPhotonMeshFragmentType : uint8_t
{
	Indestructible = 0,
	Disappear = 1,
	Collapse = 2,
	EPhotonMeshFragmentType_MAX = 3
};

// Object: Enum PhotonBlast.EPhotonMeshDestructionTriggerMode
enum class EPhotonMeshDestructionTriggerMode : uint8_t
{
	Disabled = 0,
	TriggerEveryActivation = 1,
	EPhotonMeshDestructionTriggerMode_MAX = 2
};

// Object: ScriptStruct PhotonBlast.PhotonInstanceImpactData
// Size: 0x10 (Inherited: 0x0)
struct FPhotonInstanceImpactData
{
	struct FVector_NetQuantize10 WorldImpactVelocity; // 0x0(0xC)
	uint8_t TargetFragmentsState; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct PhotonBlast.ReplicationEvent
// Size: 0x18 (Inherited: 0x0)
struct FReplicationEvent
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct PhotonBlast.ClusterReplicationProxy
// Size: 0x10 (Inherited: 0x0)
struct FClusterReplicationProxy
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct PhotonBlast.MovieScenePhotonDestructibleSectionTemplate
// Size: 0x248 (Inherited: 0x18)
struct FMovieScenePhotonDestructibleSectionTemplate : FMovieSceneEvalTemplate
{
	struct FIntegralCurve PhotonDestructibleKeys; // 0x18(0x70)
	struct FRichCurve TimeSpeedCurve; // 0x88(0x70)
	struct FRichCurve SpreadSpeedCurve; // 0xF8(0x70)
	struct FRichCurve VelocitySpeedCurve; // 0x168(0x70)
	struct FRichCurve RotationSpeedCurve; // 0x1D8(0x70)
};

// Object: ScriptStruct PhotonBlast.PhotonDestructibleMeshPhysicsDetachData
// Size: 0xC0 (Inherited: 0x0)
struct FPhotonDestructibleMeshPhysicsDetachData
{
	float TimeSpeed; // 0x0(0x4)
	struct FVector Gravity; // 0x4(0xC)
	float SpreadSpeed; // 0x10(0x4)
	float VelocitySpeed; // 0x14(0x4)
	float RotationSpeed; // 0x18(0x4)
	float VisibleTime; // 0x1C(0x4)
	int SlideSmallestChunks; // 0x20(0x4)
	float SlideRemoveSmallestSize; // 0x24(0x4)
	bool bEnableReverse; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float MaxReverseTime; // 0x2C(0x4)
	bool bUseCustomRandomValue; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct FRawDistributionVector CustomRandomDirection; // 0x38(0x50)
	struct FRawDistributionFloat CustomRandomW; // 0x88(0x38)
};

// Object: ScriptStruct PhotonBlast.PhotonDestructibleImpactParam
// Size: 0x8 (Inherited: 0x0)
struct FPhotonDestructibleImpactParam
{
	float ImpactDamageHp; // 0x0(0x4)
	float ImpactDamageSpreadRadius; // 0x4(0x4)
};

// Object: ScriptStruct PhotonBlast.PhotonSlideReplicationData
// Size: 0x28 (Inherited: 0x0)
struct FPhotonSlideReplicationData
{
	struct TArray<struct FChunkTransformData> ChunkTransformData; // 0x0(0x10)
	uint8_t TargetDestructibleState; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct TArray<uint8_t> TargetFragmentsState; // 0x18(0x10)
};

// Object: ScriptStruct PhotonBlast.ChunkTransformData
// Size: 0x34 (Inherited: 0x0)
struct FChunkTransformData
{
	struct FVector_NetQuantize100 LinearVelocity; // 0x0(0xC)
	struct FVector_NetQuantize100 AngularVelocity; // 0xC(0xC)
	struct FVector_NetQuantize100 Location; // 0x18(0xC)
	struct FRotator Rotation; // 0x24(0xC)
	bool ReplicateVelocity; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
};

// Object: ScriptStruct PhotonBlast.PhotonDetachReplicationData
// Size: 0x30 (Inherited: 0x0)
struct FPhotonDetachReplicationData
{
	struct FVector4 LocalImpactPointAndSpreadStrength; // 0x0(0x10)
	struct FVector4 LocalImpactVelocityAndRotateStrength; // 0x10(0x10)
	uint8_t FragmentState; // 0x20(0x1)
	uint8_t Pad_0x21[0xF]; // 0x21(0xF)
};

// Object: ScriptStruct PhotonBlast.PhotonHideReplicationData
// Size: 0x30 (Inherited: 0x0)
struct FPhotonHideReplicationData
{
	struct FVector_NetQuantize10 LocalImpactPoint; // 0x0(0xC)
	struct FVector_NetQuantize10 LocalImpactVelocity; // 0xC(0xC)
	struct TArray<uint8_t> TargetFragmentsState; // 0x18(0x10)
	float ImpactTime; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct PhotonBlast.FragmentConvexElem
// Size: 0x10 (Inherited: 0x0)
struct FFragmentConvexElem
{
	struct TArray<struct FKConvexElem> ConvexElem; // 0x0(0x10)
};

// Object: ScriptStruct PhotonBlast.SupportGraph
// Size: 0x18 (Inherited: 0x0)
struct FSupportGraph
{
	struct TArray<struct FEdgeNode> EdgeDatas; // 0x0(0x10)
	int Size; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct PhotonBlast.EdgeNode
// Size: 0x18 (Inherited: 0x0)
struct FEdgeNode
{
	struct TArray<int> Edges; // 0x0(0x10)
	int Size; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct PhotonBlast.PhotonDestructibleImpactData
// Size: 0x40 (Inherited: 0x0)
struct FPhotonDestructibleImpactData
{
	struct FVector4 LocalImpactPointAndSpreadSpeed; // 0x0(0x10)
	bool Visible; // 0x10(0x1)
	uint8_t Pad_0x11[0xF]; // 0x11(0xF)
	struct FVector4 LocalImpactVelocityAndRotateSpeed; // 0x20(0x10)
	uint8_t TargetFragmentsState; // 0x30(0x1)
	uint8_t Pad_0x31[0xF]; // 0x31(0xF)
};

// Object: ScriptStruct PhotonBlast.PhotonDestructibleFragmentStateData
// Size: 0x30 (Inherited: 0x0)
struct FPhotonDestructibleFragmentStateData
{
	struct FVector_NetQuantize10 LocalImpactPoint; // 0x0(0xC)
	struct FVector_NetQuantize10 LocalImpactVelocity; // 0xC(0xC)
	float ImpactTime; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<uint8_t> TargetFragmentsState; // 0x20(0x10)
};

// Object: Class PhotonBlast.PhotonDestructibleMeshActor
// Size: 0x4C0 (Inherited: 0x4B0)
struct APhotonDestructibleMeshActor : AActor
{
	struct UPhotonDestructibleMeshComponent* PhotonDestructibleMeshComponent; // 0x4B0(0x8)
	uint8_t DestructibleMeshActorReplication : 1; // 0x4B8(0x1), Mask(0x1)
	uint8_t BitPad_0x4B8_1 : 7; // 0x4B8(0x1)
	uint8_t Pad_0x4B9[0x7]; // 0x4B9(0x7)
};

// Object: Class PhotonBlast.PhotonReplicationStaticMeshComponent
// Size: 0xCB0 (Inherited: 0xBD0)
struct UPhotonReplicationStaticMeshComponent : UStaticMeshComponent
{
	uint8_t Pad_0xBD0[0x58]; // 0xBD0(0x58)
	int ClusterUniqueID; // 0xC28(0x4)
	bool bCanMove; // 0xC2C(0x1)
	uint8_t AOIEntityType; // 0xC2D(0x1)
	uint8_t AOIEntityState; // 0xC2E(0x1)
	uint8_t ClusterReplicationOpen : 1; // 0xC2F(0x1), Mask(0x1)
	uint8_t BitPad_0xC2F_1 : 7; // 0xC2F(0x1)
	struct UDestructionSubsystem* SubsystemPtr; // 0xC30(0x8)
	uint8_t Pad_0xC38[0x8]; // 0xC38(0x8)
	struct FLuaNetSerialization LuaNetSerialization; // 0xC40(0x50)
	struct FString LuaFilePath; // 0xC90(0x10)
	uint8_t Pad_0xCA0[0x10]; // 0xCA0(0x10)


	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509e54
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.UnRegisterFromCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509e40
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterFromCluster();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.SetMoveable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102509db4
	// Params: [ Num(1) Size(0x1) ]
	void SetMoveable(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.SetClusterUniqueID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509d30
	// Params: [ Num(1) Size(0x4) ]
	void SetClusterUniqueID(int InClusterID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.SetClusterEntityState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509cb8
	// Params: [ Num(1) Size(0x1) ]
	void SetClusterEntityState(uint8_t EntityState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509c3c
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AC0E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.RegisterToCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509c28
	// Params: [ Num(0) Size(0x0) ]
	void RegisterToCluster();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AC0E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationStaticMeshComponent.MarkPropDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509bac
	// Params: [ Num(1) Size(0x4) ]
	void MarkPropDirty(int PropIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AC06C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1024AC0E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class PhotonBlast.PhotonDestructibleMeshComponent
// Size: 0xF40 (Inherited: 0xCB0)
struct UPhotonDestructibleMeshComponent : UPhotonReplicationStaticMeshComponent
{
	uint8_t EnableImpactDamage : 1; // 0xCB0(0x1), Mask(0x1)
	uint8_t BitPad_0xCB0_1 : 7; // 0xCB0(0x1)
	uint8_t Pad_0xCB1[0x3]; // 0xCB1(0x3)
	struct FPhotonDestructibleImpactParam ImpactParam; // 0xCB4(0x8)
	uint8_t SynchronizeChunkData : 1; // 0xCBC(0x1), Mask(0x1)
	uint8_t BitPad_0xCBC_1 : 7; // 0xCBC(0x1)
	uint8_t Pad_0xCBD[0x3]; // 0xCBD(0x3)
	struct UPhotonDestructibleMesh* PhotonDestructibleMesh; // 0xCC0(0x8)
	enum class ECollisionEnabled FragmentsCollisionEnabled; // 0xCC8(0x1)
	uint8_t Pad_0xCC9[0x7]; // 0xCC9(0x7)
	struct FName FragmentsCollisionProfileName; // 0xCD0(0x8)
	uint8_t InitialVisible : 1; // 0xCD8(0x1), Mask(0x1)
	uint8_t BitPad_0xCD8_1 : 7; // 0xCD8(0x1)
	uint8_t Pad_0xCD9[0x7]; // 0xCD9(0x7)
	struct FPhotonHideReplicationData HideReplicationData; // 0xCE0(0x30)
	struct FPhotonDetachReplicationData DetachReplicationData; // 0xD10(0x30)
	struct FPhotonSlideReplicationData SlideReplicationData; // 0xD40(0x28)
	float FragmentsMaxHp; // 0xD68(0x4)
	uint8_t EnableCheckedSupportedFloor : 1; // 0xD6C(0x1), Mask(0x1)
	uint8_t EnableSeverImpactPoint : 1; // 0xD6C(0x1), Mask(0x2)
	uint8_t BitPad_0xD6C_2 : 6; // 0xD6C(0x1)
	uint8_t Pad_0xD6D[0x1D3]; // 0xD6D(0x1D3)


	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.SetupFragmentsMaxHp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025012f0
	// Params: [ Num(1) Size(0x4) ]
	void SetupFragmentsMaxHp(float Hp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024B48D8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.SetServerDamagedDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x10250126c
	// Params: [ Num(1) Size(0x10) ]
	void SetServerDamagedDelegate(DelegateProperty InDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1024B48D8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.SetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025011ac
	// Params: [ Num(2) Size(0x9) ]
	void SetFracturedMesh(struct UPhotonDestructibleMesh* InFracturedMesh, bool Force);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024AD474
	// [Call #6] RVA: 0x101FD9E48
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024B48D8
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.Server_OnComponentHitAction
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102501024
	// Params: [ Num(5) Size(0xB0) ]
	void Server_OnComponentHitAction(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1024B9274
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1024AD474

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.Server_DamageFragmentsByRadius
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102500e6c
	// Params: [ Num(6) Size(0x2A) ]
	bool Server_DamageFragmentsByRadius(struct FVector4& WorldImpactVelocityAndRotateStrength, struct FVector4& WorldImpactPointAndSpreadStrength, float Hp, float Radius, bool Attenuation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024B96FC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.Server_DamageFragmentsByHp
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102500c8c
	// Params: [ Num(5) Size(0x41) ]
	bool Server_DamageFragmentsByHp(struct TArray<int>& FragmentsIndex, struct TArray<float>& Hp, struct FVector4& WorldImpactPointAndSpreadStrength, struct FVector4& WorldImpactVelocityAndRotateSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024B9B24
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.OnRep_SlideData
	// Flags: [Final|Native|Public]
	// Offset: 0x102500c78
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SlideData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024B9B24
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.OnRep_ImpactData
	// Flags: [Final|Native|Public]
	// Offset: 0x102500c64
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ImpactData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024B9B24
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.OnRep_FragmentsState
	// Flags: [Final|Native|Public]
	// Offset: 0x102500c50
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_FragmentsState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024B9B24
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.IsFragmentCanDestroy
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102500bbc
	// Params: [ Num(2) Size(0x5) ]
	bool IsFragmentCanDestroy(int FragmentItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024B9B24

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.IsFragmentCanBeDamaged
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102500b10
	// Params: [ Num(2) Size(0x5) ]
	bool IsFragmentCanBeDamaged(int FragmentItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetPhotonDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102500af4
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025009c0
	// Params: [ Num(4) Size(0x42) ]
	bool GetFragmentTransform(int FragmentIndex, struct FTransform& OutTransform, bool WorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024B8AAC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentsWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1025008ec
	// Params: [ Num(3) Size(0x11) ]
	bool GetFragmentsWorldPosition(int FragmentIndex, struct FVector& FragmentPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024B9FF4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1024B8AAC

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentsNotDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025007e8
	// Params: [ Num(3) Size(0x12) ]
	bool GetFragmentsNotDamaged(struct TArray<int>& Fragments, bool IsReturnNotDestroyedFragments);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024B49B0
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1024B9FF4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentsDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102500730
	// Params: [ Num(2) Size(0x11) ]
	bool GetFragmentsDamaged(struct TArray<int>& Fragments);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024B4B40
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024B49B0
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentsByRadius
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102500534
	// Params: [ Num(6) Size(0x35) ]
	bool GetFragmentsByRadius(struct FVector& HitPoint, float Radius, struct TArray<int>& FragmentsIndex, struct TArray<float>& ImpactDistance, int DamageType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentItemCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102500518
	// Params: [ Num(1) Size(0x4) ]
	int GetFragmentItemCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFragmentBounds
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102500400
	// Params: [ Num(4) Size(0x22) ]
	bool GetFragmentBounds(int FragmentIndex, struct FBox& OutBox, bool WorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024B8D3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.GetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025003dc
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonFracturedMesh* GetFracturedMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024B8D3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.ClientGetFragmentsNotDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025002d8
	// Params: [ Num(3) Size(0x12) ]
	bool ClientGetFragmentsNotDamaged(struct TArray<int>& Fragments, bool IsReturnNotDestroyedFragments);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024AD594
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1024B8D3C

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.ClientGetFragmentsDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102500220
	// Params: [ Num(2) Size(0x11) ]
	bool ClientGetFragmentsDamaged(struct TArray<int>& Fragments);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AD658
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024AD594
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonDestructibleMeshComponent.ClientDamageAndInitalFragments
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102500100
	// Params: [ Num(2) Size(0x20) ]
	void ClientDamageAndInitalFragments(struct TArray<int>& DamagedFragmentItemIndex, struct TArray<int>& InitialFragmentItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1024AD658
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class PhotonBlast.PhotonReplicationInstancedStaticMeshComponent
// Size: 0xE00 (Inherited: 0xD20)
struct UPhotonReplicationInstancedStaticMeshComponent : UInstancedStaticMeshComponent
{
	uint8_t Pad_0xD20[0x58]; // 0xD20(0x58)
	int ClusterUniqueID; // 0xD78(0x4)
	bool bCanMove; // 0xD7C(0x1)
	uint8_t AOIEntityType; // 0xD7D(0x1)
	uint8_t AOIEntityState; // 0xD7E(0x1)
	uint8_t ClusterReplicationOpen : 1; // 0xD7F(0x1), Mask(0x1)
	uint8_t BitPad_0xD7F_1 : 7; // 0xD7F(0x1)
	struct UDestructionSubsystem* SubsystemPtr; // 0xD80(0x8)
	uint8_t Pad_0xD88[0x8]; // 0xD88(0x8)
	struct FLuaNetSerialization LuaNetSerialization; // 0xD90(0x50)
	struct FString LuaFilePath; // 0xDE0(0x10)
	uint8_t Pad_0xDF0[0x10]; // 0xDF0(0x10)


	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509250
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.UnRegisterFromCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10250923c
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterFromCluster();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.SetMoveable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025091b0
	// Params: [ Num(1) Size(0x1) ]
	void SetMoveable(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.SetClusterUniqueID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10250912c
	// Params: [ Num(1) Size(0x4) ]
	void SetClusterUniqueID(int InClusterID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.SetClusterEntityState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025090b4
	// Params: [ Num(1) Size(0x1) ]
	void SetClusterEntityState(uint8_t EntityState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509038
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AB878
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.RegisterToCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509024
	// Params: [ Num(0) Size(0x0) ]
	void RegisterToCluster();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AB878
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationInstancedStaticMeshComponent.MarkPropDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102508fa8
	// Params: [ Num(1) Size(0x4) ]
	void MarkPropDirty(int PropIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024AB7FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1024AB878
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class PhotonBlast.PhotonInstancedDestructibleMeshComponent
// Size: 0xFD0 (Inherited: 0xE00)
struct UPhotonInstancedDestructibleMeshComponent : UPhotonReplicationInstancedStaticMeshComponent
{
	uint8_t EnableImpactDamage : 1; // 0xE00(0x1), Mask(0x1)
	uint8_t BitPad_0xE00_1 : 7; // 0xE00(0x1)
	uint8_t Pad_0xE01[0x3]; // 0xE01(0x3)
	struct FPhotonDestructibleImpactParam ImpactParam; // 0xE04(0x8)
	uint8_t Pad_0xE0C[0x4]; // 0xE0C(0x4)
	struct UPhotonDestructibleMesh* PhotonDestructibleMesh; // 0xE10(0x8)
	enum class ECollisionEnabled FragmentsCollisionEnabled; // 0xE18(0x1)
	uint8_t Pad_0xE19[0x7]; // 0xE19(0x7)
	struct FName FragmentsCollisionProfileName; // 0xE20(0x8)
	struct TArray<struct FPhotonDestructibleFragmentStateData> HideInstanceReplicationData; // 0xE28(0x10)
	struct TArray<struct FPhotonDestructibleImpactData> DetachInstanceReplicationData; // 0xE38(0x10)
	float FragmentsMaxHp; // 0xE48(0x4)
	uint8_t EnableCheckedSupportedFloor : 1; // 0xE4C(0x1), Mask(0x1)
	uint8_t EnableSeverImpactPoint : 1; // 0xE4C(0x1), Mask(0x2)
	uint8_t BitPad_0xE4C_2 : 6; // 0xE4C(0x1)
	uint8_t Pad_0xE4D[0x183]; // 0xE4D(0x183)


	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.SetupFragmentsMaxHp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102508518
	// Params: [ Num(1) Size(0x4) ]
	void SetupFragmentsMaxHp(float Hp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024E2F5C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.SetServerDamagedDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x102508494
	// Params: [ Num(1) Size(0x10) ]
	void SetServerDamagedDelegate(DelegateProperty InDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1024E2F5C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.SetPhysMaterialOverride
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102508410
	// Params: [ Num(1) Size(0x8) ]
	void SetPhysMaterialOverride(struct UPhysicalMaterial* NewPhysMaterial);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1024E2F5C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.SetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102508350
	// Params: [ Num(2) Size(0x9) ]
	void SetFracturedMesh(struct UPhotonDestructibleMesh* InFracturedMesh, bool Force);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024E3094
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD9E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1024E2F5C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.Server_OnComponentHitAction
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1025081c8
	// Params: [ Num(5) Size(0xB0) ]
	void Server_OnComponentHitAction(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1024E5DBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1024E3094

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.Server_DamageFragmentsByRadius
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102508010
	// Params: [ Num(6) Size(0x2A) ]
	bool Server_DamageFragmentsByRadius(struct FVector4& WorldImpactVelocity, struct FVector4& WorldHitPointAndSpreadSpeed, float Hp, float Radius, bool Attenuation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024E62D8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.ReplaceAllInstances
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102507edc
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<int> ReplaceAllInstances(struct TArray<struct FTransform>& InstanceTransforms, bool bShouldReturnIndices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FA6168
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101FA6AF8
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101FA6AF8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.OnRep_ImpactData
	// Flags: [Final|Native|Public]
	// Offset: 0x102507ec8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ImpactData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FA6168
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101FA6AF8
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101FA6AF8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.OnRep_FragmentsState
	// Flags: [Final|Native|Public]
	// Offset: 0x102507eb4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_FragmentsState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FA6168
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101FA6AF8
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101FA6AF8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.IsFragmentCanDestroy
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507de8
	// Params: [ Num(3) Size(0x9) ]
	bool IsFragmentCanDestroy(int InstanceIndex, int FragmentItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FA6168
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101FA6AF8
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101FA6AF8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetPhotonDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507dcc
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FA6168
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101FA6AF8
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101FA6AF8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetInstancesOverlappingSphere
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507c80
	// Params: [ Num(4) Size(0x28) ]
	struct TArray<int> GetInstancesOverlappingSphere(struct FVector& Center, float Radius, bool bSphereInWorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FA6168
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetInstanceItemCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507c64
	// Params: [ Num(1) Size(0x4) ]
	int GetInstanceItemCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FA6168
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507af8
	// Params: [ Num(5) Size(0x42) ]
	bool GetFragmentTransform(int InstanceIndex, int FragmentIndex, struct FTransform& OutTransform, bool WorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024E5570
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentsWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1025079ec
	// Params: [ Num(4) Size(0x15) ]
	bool GetFragmentsWorldPosition(int InstanceIndex, int FragmentIndex, struct FVector& FragmentPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024E708C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentsNotDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025078ac
	// Params: [ Num(4) Size(0x1A) ]
	bool GetFragmentsNotDamaged(int InstanceIndex, struct TArray<int>& FragmentsNoDamaged, bool IsReturnNotDestroyedFragments);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024E7B94
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1024E708C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentsDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025077b8
	// Params: [ Num(3) Size(0x19) ]
	bool GetFragmentsDamaged(int InstanceIndex, struct TArray<int>& FragmentsDamaged);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024E7CE4
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1024E7B94
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentItemCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507790
	// Params: [ Num(1) Size(0x4) ]
	int GetFragmentItemCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024E7CE4
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1024E7B94
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8BA44

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFragmentBounds
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10250763c
	// Params: [ Num(5) Size(0x26) ]
	bool GetFragmentBounds(int InstanceIndex, int FragmentIndex, struct FBox& OutBox, bool WorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024E71CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1024E7CE4
	// [Call #15] RVA: 0x101F8BA44

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.GetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102507618
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonFracturedMesh* GetFracturedMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024E71CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.AddInstanceWorldSpace
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102507564
	// Params: [ Num(2) Size(0x34) ]
	int AddInstanceWorldSpace(struct FTransform& WorldTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024E2A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1024E71CC

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.AddInstances
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025073e0
	// Params: [ Num(4) Size(0x28) ]
	struct TArray<int> AddInstances(struct TArray<struct FTransform>& InstanceTransforms, bool bShouldReturnIndices, bool bMarkRenderStateDirty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FA6168
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101FA6AF8
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101FA6AF8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1024E2A9C

	// Object: Function PhotonBlast.PhotonInstancedDestructibleMeshComponent.AddInstance
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102507324
	// Params: [ Num(2) Size(0x34) ]
	int AddInstance(struct FTransform& InstanceTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FA6168
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101FA6AF8
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101FA6AF8
	// [Call #14] RVA: 0x106C8459C
};

// Object: Class PhotonBlast.PhotonHierarchicalInstancedDestructibleMeshComponent
// Size: 0x10B0 (Inherited: 0xFD0)
struct UPhotonHierarchicalInstancedDestructibleMeshComponent : UPhotonInstancedDestructibleMeshComponent
{
	uint8_t Pad_0xFD0[0x10]; // 0xFD0(0x10)
	struct TArray<int> SortedInstances; // 0xFE0(0x10)
	int NumBuiltInstances; // 0xFF0(0x4)
	uint8_t Pad_0xFF4[0x4]; // 0xFF4(0x4)
	struct FBox BuiltInstanceBounds; // 0xFF8(0x1C)
	struct FBox UnbuiltInstanceBounds; // 0x1014(0x1C)
	struct TArray<struct FBox> UnbuiltInstanceBoundsList; // 0x1030(0x10)
	struct TArray<int> UnbuiltInstanceIndexList; // 0x1040(0x10)
	uint8_t bEnableDensityScaling : 1; // 0x1050(0x1), Mask(0x1)
	uint8_t BitPad_0x1050_1 : 7; // 0x1050(0x1)
	uint8_t Pad_0x1051[0x27]; // 0x1051(0x27)
	int OcclusionLayerNumNodes; // 0x1078(0x4)
	struct FBoxSphereBounds CacheMeshExtendedBounds; // 0x107C(0x1C)
	uint8_t Pad_0x1098[0x8]; // 0x1098(0x8)
	int MinInstancesToSplitNode; // 0x10A0(0x4)
	uint8_t Pad_0x10A4[0xC]; // 0x10A4(0xC)


	// Object: Function PhotonBlast.PhotonHierarchicalInstancedDestructibleMeshComponent.ShowInstances
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102502604
	// Params: [ Num(3) Size(0x21) ]
	bool ShowInstances(struct TArray<int>& InstanceIndices, struct TArray<struct FTransform>& InstanceTransforms);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FA6AF8
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101FA6AF8
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedDestructibleMeshComponent.RemoveInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102502544
	// Params: [ Num(2) Size(0x11) ]
	bool RemoveInstances(struct TArray<int>& InstancesToRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FA6AF8
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101FA6AF8
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
};

// Object: Class PhotonBlast.ClusterReplicationVolume
// Size: 0x530 (Inherited: 0x4E0)
struct AClusterReplicationVolume : AVolume
{
	bool bForReplication; // 0x4E0(0x1)
	bool bForClusterDivide; // 0x4E1(0x1)
	uint8_t Pad_0x4E2[0x6]; // 0x4E2(0x6)
	struct FClusterAOIConfig ClusterConfig; // 0x4E8(0x38)
	struct FClusterReplicationProxy ClusterReplication; // 0x520(0x10)
};

// Object: Class PhotonBlast.ClusterReplicationSelectVolume
// Size: 0x4E8 (Inherited: 0x4E0)
struct AClusterReplicationSelectVolume : AVolume
{
	int16_t LevelGroup; // 0x4E0(0x2)
	uint8_t Pad_0x4E2[0x6]; // 0x4E2(0x6)
};

// Object: Class PhotonBlast.MovieScenePhotonDestructibleSection
// Size: 0x2E0 (Inherited: 0xB0)
struct UMovieScenePhotonDestructibleSection : UMovieSceneSection
{
	struct FIntegralCurve PhotonDestructibleKeys; // 0xB0(0x70)
	struct FRichCurve TimeSpeedCurve; // 0x120(0x70)
	struct FRichCurve SpreadSpeedCurve; // 0x190(0x70)
	struct FRichCurve VelocitySpeedCurve; // 0x200(0x70)
	struct FRichCurve RotationSpeedCurve; // 0x270(0x70)
};

// Object: Class PhotonBlast.MovieScenePhotonDestructibleTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieScenePhotonDestructibleTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> PhotonDestructibleSections; // 0x58(0x10)
};

// Object: Class PhotonBlast.PhotonDestructibleMesh
// Size: 0x3F0 (Inherited: 0x270)
struct UPhotonDestructibleMesh : UStaticMesh
{
	struct UPhotonFracturedMesh* FracturedMesh; // 0x270(0x8)
	enum class EPhotonDestructibleAction DestructibleAction; // 0x278(0x1)
	uint8_t UseDefaultParameter : 1; // 0x279(0x1), Mask(0x1)
	uint8_t BitPad_0x279_1 : 7; // 0x279(0x1)
	enum class EPhotonCollisionType FragmentCollisonType; // 0x27A(0x1)
	uint8_t Pad_0x27B[0x5]; // 0x27B(0x5)
	struct FPhotonDestructibleMeshPhysicsDetachData PhysicsDetachData; // 0x280(0xC0)
	uint8_t Pad_0x340[0xB0]; // 0x340(0xB0)
};

// Object: Class PhotonBlast.DestructionSubsystem
// Size: 0x5B8 (Inherited: 0x5B8)
struct UDestructionSubsystem : UClusterReplicationSubsystem
{
};

// Object: Class PhotonBlast.PhotonFracturedMesh
// Size: 0x100 (Inherited: 0x28)
struct UPhotonFracturedMesh : UObject
{
	struct TArray<struct UPhotonFracturedFragmentInfo*> FracturedFragmentInfo; // 0x28(0x10)
	struct TArray<int> InsideMaterialIndex; // 0x38(0x10)
	struct TMap<int, struct UPhotonFracturedFragmentInfo*> FragmentIndex2FragmentInfo; // 0x48(0x50)
	struct TMap<struct FName, struct UPhotonFracturedFragmentInfo*> FragmentName2FragmentInfo; // 0x98(0x50)
	struct FSupportGraph SupportGraph; // 0xE8(0x18)
};

// Object: Class PhotonBlast.PhotonFracturedMeshSettings
// Size: 0x28 (Inherited: 0x28)
struct UPhotonFracturedMeshSettings : UObject
{
};

// Object: Class PhotonBlast.PhotonFEdgeData
// Size: 0x28 (Inherited: 0x28)
struct UPhotonFEdgeData : UObject
{
};

// Object: Class PhotonBlast.PhotonFracturedFragmentInfo
// Size: 0x70 (Inherited: 0x28)
struct UPhotonFracturedFragmentInfo : UObject
{
	int FragmentItemIndex; // 0x28(0x4)
	float MassOverride; // 0x2C(0x4)
	struct FFragmentConvexElem ConvexElemForCollision; // 0x30(0x10)
	struct FVector CenterPoint; // 0x40(0xC)
	struct FBox LocalBoundBox; // 0x4C(0x1C)
	uint8_t CanDestroy : 1; // 0x68(0x1), Mask(0x1)
	uint8_t ConnectFloor : 1; // 0x68(0x1), Mask(0x2)
	uint8_t BitPad_0x68_2 : 6; // 0x68(0x1)
	uint8_t Pad_0x69[0x3]; // 0x69(0x3)
	int ChunkIndex; // 0x6C(0x4)
};

// Object: Class PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent
// Size: 0xF20 (Inherited: 0xE10)
struct UPhotonHierarchicalInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent
{
	struct UPhotonDestructibleMesh* PhotonDestructibleMesh; // 0xE08(0x8)
	struct UStaticMesh* EffectStaticMesh; // 0xE10(0x8)
	struct USkeletalMesh* EffectSkeleMesh; // 0xE18(0x8)
	struct UAnimInstance* AnimClass; // 0xE20(0x8)
	struct AActor* EffectActorClass; // 0xE28(0x8)
	struct TArray<struct FPhotonInstanceImpactData> InstanceImpactData; // 0xE30(0x10)
	float InstanceMaxHp; // 0xE40(0x4)
	enum class EEffectType EffectType; // 0xE44(0x1)
	float EffectDurationTime; // 0xE48(0x4)
	struct FName EffectCollisionProfileName; // 0xE50(0x8)
	uint8_t bCullEffect : 1; // 0xE58(0x1), Mask(0x1)
	uint8_t BitPad_0xE59_1 : 7; // 0xE59(0x1)
	uint8_t Pad_0xE5A[0x2]; // 0xE5A(0x2)
	float CullDistance; // 0xE5C(0x4)
	uint8_t bUseExactVelocity : 1; // 0xE60(0x1), Mask(0x1)
	uint8_t BitPad_0xE60_1 : 7; // 0xE60(0x1)
	uint8_t Pad_0xE61[0x3]; // 0xE61(0x3)
	float VelocityLength; // 0xE64(0x4)
	float MinVelocityExplosion; // 0xE68(0x4)
	float MaxVelocityExplosion; // 0xE6C(0x4)
	struct UAkAudioEvent* HitSound; // 0xE70(0x8)
	struct TSet<uint8_t> ExceptDamageTypes; // 0xE78(0x50)
	bool bVehicleHitUseClientPreShow; // 0xEC8(0x1)
	uint8_t Pad_0xEC9[0x3]; // 0xEC9(0x3)
	float bVehicleHitScale; // 0xECC(0x4)
	bool bUpdateSurrendActorPosition; // 0xED0(0x1)
	bool bForceNetUpdate; // 0xED1(0x1)
	uint8_t Pad_0xED2[0x4E]; // 0xED2(0x4E)


	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.UpdatePickupAndDeadBoxInRange
	// Flags: [Final|Native|Protected|HasDefaults|BlueprintCallable]
	// Offset: 0x102503998
	// Params: [ Num(1) Size(0xC) ]
	void UpdatePickupAndDeadBoxInRange(struct FVector Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024D6E98
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.SetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102503920
	// Params: [ Num(1) Size(0x8) ]
	void SetFracturedMesh(struct UPhotonDestructibleMesh* InPhotonDestructibleMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1024D6E98
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.ServerGetInstanceIndexsNotDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102503868
	// Params: [ Num(2) Size(0x11) ]
	bool ServerGetInstanceIndexsNotDamaged(struct TArray<int>& InstancesNoDamaged);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024D8788
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024D6E98
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.ServerGetInstanceIndexsDamaged
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025037b0
	// Params: [ Num(2) Size(0x11) ]
	bool ServerGetInstanceIndexsDamaged(struct TArray<int>& InstancesDamaged);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024D8840
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024D8788
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1024D6E98

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.Server_InstanceByHp
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1025035f4
	// Params: [ Num(5) Size(0x2E) ]
	bool Server_InstanceByHp(struct TArray<int>& InstancedIndex, struct TArray<float>& DamagesHp, struct FVector& WorldImpactVelocity, uint8_t DamageType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024D7F80
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1024D8840
	// [Call #18] RVA: 0x101F8BA44

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.Server_InstanceAndWorldVelocityByHp
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1025033f8
	// Params: [ Num(6) Size(0x35) ]
	bool Server_InstanceAndWorldVelocityByHp(struct TArray<int>& InstancedIndex, struct TArray<float>& DamagesHp, struct FVector& WorldImpactPoint, uint8_t DamageType, float Strength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1024D8150
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.Server_DamageFragmentsByRadius
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10250329c
	// Params: [ Num(5) Size(0x21) ]
	bool Server_DamageFragmentsByRadius(struct FVector& WorldImpactVelocity, struct FVector& WorldHitPointAndSpreadSpeed, float Hp, float Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1024D7B74
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: DelegateFunction PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.OnTriggerServerEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x28) ]
	void OnTriggerServerEvent__DelegateSignature(struct ASTExtraVehicleBase* VehicleActor, struct UPrimitiveComponent* HitComp, struct UPhotonHierarchicalInstancedStaticMeshComponent* MeshComponent, struct FVector& DesPos, int TriggerIndex);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.OnTriggeredByComp
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102503170
	// Params: [ Num(3) Size(0x58) ]
	void OnTriggeredByComp(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FTriggerEvent& TriggerEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024D5C20
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: DelegateFunction PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.OnTriggerClientEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x28) ]
	void OnTriggerClientEvent__DelegateSignature(struct ASTExtraVehicleBase* VehicleActor, struct UPrimitiveComponent* HitComp, struct UPhotonHierarchicalInstancedStaticMeshComponent* MeshComponent, struct FVector& DesPos, int TriggerIndex);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.OnRep_ImpactData
	// Flags: [Final|Native|Public]
	// Offset: 0x10250315c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ImpactData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1024D5C20
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.OnLocalVehicleHit
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x102502fec
	// Params: [ Num(3) Size(0x30) ]
	void OnLocalVehicleHit(struct TArray<int>& InstanceIndex, struct FVector4& WorldImpactPointAndSpreadSpeed, struct FVector4& WorldImpactVelocityAndRotateSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.GetPhotonDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102502fd0
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.GetInstanceByRadius
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102502e3c
	// Params: [ Num(5) Size(0x22) ]
	bool GetInstanceByRadius(struct FVector& HitPoint, float Radius, struct TArray<int>& InstancedIndex, uint8_t DamageType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.GetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102502e18
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonFracturedMesh* GetFracturedMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.GenerateEffectInstanceWorldSpace
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102502cf8
	// Params: [ Num(2) Size(0x20) ]
	void GenerateEffectInstanceWorldSpace(struct TArray<int>& InstanceIndex, struct TArray<struct FVector>& WorldImpactVelocityAndRotateSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.GenerateEffectInstanceLocalSpace
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102502bd8
	// Params: [ Num(2) Size(0x20) ]
	void GenerateEffectInstanceLocalSpace(struct TArray<int>& InstanceIndex, struct TArray<struct FVector>& LocalImpactVelocityAndRotateSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.ClientCorrectVehicleHit
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x102502b28
	// Params: [ Num(1) Size(0x10) ]
	void ClientCorrectVehicleHit(struct TArray<int>& InstanceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
};

// Object: Class PhotonBlast.PhotonParticleModuleTypeDataMesh
// Size: 0x180 (Inherited: 0xE8)
struct UPhotonParticleModuleTypeDataMesh : UParticleModuleTypeDataMesh
{
	uint8_t DestructionTriggerMode; // 0xE5(0x1)
	float TriggerDelay; // 0xE8(0x4)
	float ImpactSpreadStrength; // 0xEC(0x4)
	float ImpactVelocityMagnitude; // 0xF0(0x4)
	struct FVector ImpactVelocityDirection; // 0xF4(0xC)
	float ImpactRotationStrength; // 0x100(0x4)
	bool bOverrideDetachGravity; // 0x104(0x1)
	uint8_t Pad_0x106[0x2]; // 0x106(0x2)
	struct FVector DetachGravity; // 0x108(0xC)
	bool bOverrideDetachTimeSpeed; // 0x114(0x1)
	uint8_t Pad_0x115[0x3]; // 0x115(0x3)
	float DetachTimeSpeed; // 0x118(0x4)
	uint8_t Pad_0x11C[0x64]; // 0x11C(0x64)
};

// Object: Class PhotonBlast.PhotonReplicationSkeletalMeshComponent
// Size: 0x1430 (Inherited: 0x1350)
struct UPhotonReplicationSkeletalMeshComponent : USkeletalMeshComponent
{
	uint8_t Pad_0x1350[0x58]; // 0x1350(0x58)
	int ClusterUniqueID; // 0x13A8(0x4)
	bool bCanMove; // 0x13AC(0x1)
	uint8_t AOIEntityType; // 0x13AD(0x1)
	uint8_t AOIEntityState; // 0x13AE(0x1)
	uint8_t ClusterReplicationOpen : 1; // 0x13AF(0x1), Mask(0x1)
	uint8_t BitPad_0x13AF_1 : 7; // 0x13AF(0x1)
	struct UDestructionSubsystem* SubsystemPtr; // 0x13B0(0x8)
	uint8_t Pad_0x13B8[0x8]; // 0x13B8(0x8)
	struct FLuaNetSerialization LuaNetSerialization; // 0x13C0(0x50)
	struct FString LuaFilePath; // 0x1410(0x10)
	uint8_t Pad_0x1420[0x10]; // 0x1420(0x10)


	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509830
	// Params: [ Num(0) Size(0x0) ]
	void UnRegistLuaTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.UnRegisterFromCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10250981c
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterFromCluster();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.SetMoveable
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102509790
	// Params: [ Num(1) Size(0x1) ]
	void SetMoveable(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.SetClusterUniqueID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10250970c
	// Params: [ Num(1) Size(0x4) ]
	void SetClusterUniqueID(int InClusterID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.SetClusterEntityState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509690
	// Params: [ Num(1) Size(0x1) ]
	void SetClusterEntityState(uint8_t EntityState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509614
	// Params: [ Num(1) Size(0x4) ]
	void RegistLuaTick(float TickInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024ABCD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.RegisterToCluster
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509600
	// Params: [ Num(0) Size(0x0) ]
	void RegisterToCluster();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024ABCD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.PhotonReplicationSkeletalMeshComponent.MarkPropDirty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102509584
	// Params: [ Num(1) Size(0x4) ]
	void MarkPropDirty(int PropIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1024ABC58
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1024ABCD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
};

// Object: Class PhotonBlast.PhotonStaticeMeshActor
// Size: 0x668 (Inherited: 0x660)
struct APhotonStaticeMeshActor : ADecoratorActor
{
	uint8_t Pad_0x660[0x8]; // 0x660(0x8)
};

// Object: Class PhotonBlast.ReusableStaticMeshActor
// Size: 0x4D0 (Inherited: 0x4C0)
struct AReusableStaticMeshActor : AStaticMeshActor
{
	uint8_t Pad_0x4C0[0x10]; // 0x4C0(0x10)


	// Object: Function PhotonBlast.ReusableStaticMeshActor.OnSpawn
	// Flags: [Native|Protected]
	// Offset: 0x10250a2e8
	// Params: [ Num(0) Size(0x0) ]
	void OnSpawn();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250A5B0
	// [Call #6] RVA: 0x10519022C

	// Object: Function PhotonBlast.ReusableStaticMeshActor.OnRecycle
	// Flags: [Native|Protected]
	// Offset: 0x10250a2cc
	// Params: [ Num(0) Size(0x0) ]
	void OnRecycle();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250A5B0
	// [Call #6] RVA: 0x10519022C
};

// Object: Class PhotonBlast.ReusableSkeletalMeshActor
// Size: 0x548 (Inherited: 0x538)
struct AReusableSkeletalMeshActor : ASkeletalMeshActor
{
	uint8_t Pad_0x538[0x10]; // 0x538(0x10)


	// Object: Function PhotonBlast.ReusableSkeletalMeshActor.OnSpawn
	// Flags: [Native|Protected]
	// Offset: 0x10250a4c8
	// Params: [ Num(0) Size(0x0) ]
	void OnSpawn();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250A790
	// [Call #6] RVA: 0x10519022C

	// Object: Function PhotonBlast.ReusableSkeletalMeshActor.OnRecycle
	// Flags: [Native|Protected]
	// Offset: 0x10250a4ac
	// Params: [ Num(0) Size(0x0) ]
	void OnRecycle();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250A790
	// [Call #6] RVA: 0x10519022C
};

// Object: Class PhotonBlast.ReusableDestructibleMeshActor
// Size: 0x4D0 (Inherited: 0x4C0)
struct AReusableDestructibleMeshActor : APhotonDestructibleMeshActor
{
	uint8_t Pad_0x4C0[0x10]; // 0x4C0(0x10)


	// Object: Function PhotonBlast.ReusableDestructibleMeshActor.OnSpawn
	// Flags: [Native|Protected]
	// Offset: 0x10250a6a8
	// Params: [ Num(0) Size(0x0) ]
	void OnSpawn();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250AA3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function PhotonBlast.ReusableDestructibleMeshActor.OnRecycle
	// Flags: [Native|Protected]
	// Offset: 0x10250a68c
	// Params: [ Num(0) Size(0x0) ]
	void OnRecycle();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10250AA3C
	// [Call #6] RVA: 0x10516D168
};

// Object: Class PhotonBlast.PhotonStaticMeshComponent
// Size: 0xC00 (Inherited: 0xBD0)
struct UPhotonStaticMeshComponent : UStaticMeshComponent
{
	struct UPhotonDestructibleMesh* PhotonDestructibleMesh; // 0xBC8(0x8)
	struct UStaticMesh* EffectStaticMesh; // 0xBD0(0x8)
	float InstanceMaxHp; // 0xBD8(0x4)
	enum class EEffectType EffectType; // 0xBDC(0x1)
	float EffectDurationTime; // 0xBE0(0x4)
	struct FName EffectCollisionProfileName; // 0xBE8(0x8)
	bool bVehicleHitUseClientPreShow; // 0xBF0(0x1)
	uint8_t Pad_0xBF2[0x2]; // 0xBF2(0x2)
	float bVehicleHitScale; // 0xBF4(0x4)
	uint8_t Pad_0xBF8[0x8]; // 0xBF8(0x8)


	// Object: Function PhotonBlast.PhotonStaticMeshComponent.SetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10250a8a8
	// Params: [ Num(1) Size(0x8) ]
	void SetFracturedMesh(struct UPhotonDestructibleMesh* InPhotonDestructibleMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function PhotonBlast.PhotonStaticMeshComponent.GetPhotonDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10250a88c
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function PhotonBlast.PhotonStaticMeshComponent.GetFracturedMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10250a868
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotonFracturedMesh* GetFracturedMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

