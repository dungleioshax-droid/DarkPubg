#pragma once

#include <cstdint>

// Object: ScriptStruct GeometryCache.TrackRenderData
// Size: 0x50 (Inherited: 0x0)
struct FTrackRenderData
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct GeometryCache.GeometryCacheMeshData
// Size: 0x50 (Inherited: 0x0)
struct FGeometryCacheMeshData
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct GeometryCache.GeometryCacheMeshBatchInfo
// Size: 0xC (Inherited: 0x0)
struct FGeometryCacheMeshBatchInfo
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: Class GeometryCache.GeometryCache
// Size: 0x68 (Inherited: 0x28)
struct UGeometryCache : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct TArray<struct UMaterialInterface*> Materials; // 0x30(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks; // 0x40(0x10)
	uint8_t Pad_0x50[0x18]; // 0x50(0x18)
};

// Object: Class GeometryCache.GeometryCacheActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct AGeometryCacheActor : AActor
{
	struct UGeometryCacheComponent* GeometryCacheComponent; // 0x4B0(0x8)


	// Object: Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1a50
	// Params: [ Num(1) Size(0x8) ]
	struct UGeometryCacheComponent* GetGeometryCacheComponent();
	// [Call #1] RVA: 0x105F9D864
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105FA1938
	// [Call #6] RVA: 0x105184F34
	// [Call #7] RVA: 0x105190648
	// [Call #8] RVA: 0x1036A6C08
	// [Call #9] RVA: 0x105FA24CC
};

// Object: Class GeometryCache.GeometryCacheComponent
// Size: 0xA90 (Inherited: 0xA20)
struct UGeometryCacheComponent : UMeshComponent
{
	struct UGeometryCache* GeometryCache; // 0xA20(0x8)
	bool bRunning; // 0xA28(0x1)
	bool bLooping; // 0xA29(0x1)
	uint8_t Pad_0xA2A[0x2]; // 0xA2A(0x2)
	float StartTimeOffset; // 0xA2C(0x4)
	float PlaybackSpeed; // 0xA30(0x4)
	int NumTracks; // 0xA34(0x4)
	float ElapsedTime; // 0xA38(0x4)
	uint8_t Pad_0xA3C[0x54]; // 0xA3C(0x54)


	// Object: Function GeometryCache.GeometryCacheComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa2024
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1fa8
	// Params: [ Num(1) Size(0x4) ]
	void SetStartTimeOffset(float NewStartTimeOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105F9E37C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1f2c
	// Params: [ Num(1) Size(0x4) ]
	void SetPlaybackSpeed(float NewPlaybackSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105F9E11C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105F9E37C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GeometryCache.GeometryCacheComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1ea8
	// Params: [ Num(1) Size(0x1) ]
	void SetLooping(bool bNewLooping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105F9E0F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105F9E11C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105F9E37C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105fa1e14
	// Params: [ Num(2) Size(0x9) ]
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105F9E37C
	// [Call #12] RVA: 0x10519022C

	// Object: Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1e00
	// Params: [ Num(0) Size(0x0) ]
	void PlayReversedFromEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105F9E37C

	// Object: Function GeometryCache.GeometryCacheComponent.PlayReversed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1dec
	// Params: [ Num(0) Size(0x0) ]
	void PlayReversed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105F9E37C

	// Object: Function GeometryCache.GeometryCacheComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1dd8
	// Params: [ Num(0) Size(0x0) ]
	void PlayFromStart();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105F9E37C

	// Object: Function GeometryCache.GeometryCacheComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1dc4
	// Params: [ Num(0) Size(0x0) ]
	void Play();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105F9E37C

	// Object: Function GeometryCache.GeometryCacheComponent.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fa1db0
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9E0F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E11C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1d7c
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlayingReversed();
	// [Call #1] RVA: 0x105F9E0F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105F9E0F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105F9E11C

	// Object: Function GeometryCache.GeometryCacheComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1d48
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x105F9E0E0
	// [Call #2] RVA: 0x105F9E0F8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105F9E0F0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105F9E11C

	// Object: Function GeometryCache.GeometryCacheComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1d14
	// Params: [ Num(1) Size(0x1) ]
	bool IsLooping();
	// [Call #1] RVA: 0x105F9E0E8
	// [Call #2] RVA: 0x105F9E0E0
	// [Call #3] RVA: 0x105F9E0F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105F9E0F0
	// [Call #9] RVA: 0x10516D168

	// Object: Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1ce0
	// Params: [ Num(1) Size(0x4) ]
	float GetStartTimeOffset();
	// [Call #1] RVA: 0x105F9E374
	// [Call #2] RVA: 0x105F9E0E8
	// [Call #3] RVA: 0x105F9E0E0
	// [Call #4] RVA: 0x105F9E0F8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105F9E0F0

	// Object: Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fa1cac
	// Params: [ Num(1) Size(0x4) ]
	float GetPlaybackSpeed();
	// [Call #1] RVA: 0x105F9DDC0
	// [Call #2] RVA: 0x105F9E374
	// [Call #3] RVA: 0x105F9E0E8
	// [Call #4] RVA: 0x105F9E0E0
	// [Call #5] RVA: 0x105F9E0F8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class GeometryCache.GeometryCacheTrack
// Size: 0x50 (Inherited: 0x28)
struct UGeometryCacheTrack : UObject
{
	uint8_t Pad_0x28[0x28]; // 0x28(0x28)
};

// Object: Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x70 (Inherited: 0x50)
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack
{
	uint32_t NumMeshSamples; // 0x4C(0x4)
	uint8_t Pad_0x54[0x1C]; // 0x54(0x1C)


	// Object: Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x105fa2824
	// Params: [ Num(2) Size(0x54) ]
	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105F9F96C
	// [Call #6] RVA: 0x105FA08CC
	// [Call #7] RVA: 0x105FA08CC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x105FA2BB8
};

// Object: Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0xA0 (Inherited: 0x50)
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack
{
	uint8_t Pad_0x50[0x50]; // 0x50(0x50)


	// Object: Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x105fa2a80
	// Params: [ Num(1) Size(0x50) ]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105F9FCB4
	// [Call #4] RVA: 0x105FA08CC
	// [Call #5] RVA: 0x105FA08CC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105FA2DC8
	// [Call #11] RVA: 0x10516D168
};

// Object: Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0xA0 (Inherited: 0x50)
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack
{
	uint8_t Pad_0x50[0x50]; // 0x50(0x50)


	// Object: Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x105fa2c90
	// Params: [ Num(1) Size(0x50) ]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105F9FDD4
	// [Call #4] RVA: 0x105FA08CC
	// [Call #5] RVA: 0x105FA08CC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x104FD0740
	// [Call #11] RVA: 0x1036A6C08
	// [Call #12] RVA: 0x105093FD0
};

