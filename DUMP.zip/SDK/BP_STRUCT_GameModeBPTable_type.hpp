#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_GameModeBPTable_type.BP_STRUCT_GameModeBPTable_type
// Size: 0x28 (Inherited: 0x0)
struct FBP_STRUCT_GameModeBPTable_type
{
	int ID_0_5A5311F84AF5AD63F284598DF413D62D; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString CName_1_120D6DB74537DE28D87E4BAD2052E558; // 0x8(0x10)
	struct FString Path_2_D808EF6946A66B7E51F6318FC7CCE098; // 0x18(0x10)
};

