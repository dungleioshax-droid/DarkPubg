#pragma once

#include <cstdint>

// Object: Class bp_plugin.bp_pluginBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct Ubp_pluginBPLibrary : UBlueprintFunctionLibrary
{

	// Object: Function bp_plugin.bp_pluginBPLibrary.bp_pluginSendEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c01260
	// Params: [ Num(1) Size(0x10) ]
	void bp_pluginSendEvent(struct FString jsonEventCmd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C004A8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function bp_plugin.bp_pluginBPLibrary.bp_pluginRequestInstallWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c0118c
	// Params: [ Num(3) Size(0x1C) ]
	int bp_pluginRequestInstallWidget(int wigetType, struct FString authInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C00BD0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102C004A8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function bp_plugin.bp_pluginBPLibrary.bp_pluginLaunchMeemoFunction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c010f4
	// Params: [ Num(2) Size(0x14) ]
	float bp_pluginLaunchMeemoFunction(struct FString Param);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C0042C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102C00BD0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102C004A8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function bp_plugin.bp_pluginBPLibrary.bp_pluginIsInForeground
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c010c0
	// Params: [ Num(1) Size(0x1) ]
	bool bp_pluginIsInForeground();
	// [Call #1] RVA: 0x102C00598
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C0042C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C00BD0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102C004A8
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function bp_plugin.bp_pluginBPLibrary.bp_pluginGetInstalledWidgetType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102c0108c
	// Params: [ Num(1) Size(0x4) ]
	int bp_pluginGetInstalledWidgetType();
	// [Call #1] RVA: 0x102C00520
	// [Call #2] RVA: 0x102C00598
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C0042C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102C00BD0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102C004A8
	// [Call #20] RVA: 0x101F8130C
};

