#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass CameraPostProcessActor.CameraPostProcessActor_C
// Size: 0xA70 (Inherited: 0x4B0)
struct ACameraPostProcessActor_C : AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4B0(0x8)
	struct USceneComponent* DefaultSceneRoot; // 0x4B8(0x8)
	float Timeline_LerpPPSettings_104_7E99B53D425173C51E1B2D83BB82148A; // 0x4C0(0x4)
	float Timeline_LerpPPSettings_103_7E99B53D425173C51E1B2D83BB82148A; // 0x4C4(0x4)
	float Timeline_LerpPPSettings_102_7E99B53D425173C51E1B2D83BB82148A; // 0x4C8(0x4)
	float Timeline_LerpPPSettings_101_7E99B53D425173C51E1B2D83BB82148A; // 0x4CC(0x4)
	enum class ETimelineDirection Timeline_LerpPPSettings__Direction_7E99B53D425173C51E1B2D83BB82148A; // 0x4D0(0x1)
	uint8_t Pad_0x4D1[0x7]; // 0x4D1(0x7)
	struct UTimelineComponent* Timeline_LerpPPSettings; // 0x4D8(0x8)
	struct APostProcessVolume* currentPostProcessVolumn; // 0x4E0(0x8)
	int isLerp; // 0x4E8(0x4)
	uint8_t Pad_0x4EC[0x4]; // 0x4EC(0x4)
	struct TArray<enum class EDepthOfFieldMethod> depthOfFieldMethodArray; // 0x4F0(0x10)
	float LerpAlpha; // 0x500(0x4)
	bool isReverse; // 0x504(0x1)
	uint8_t Pad_0x505[0xB]; // 0x505(0xB)
	struct FPostProcessSettings previousPPSettingsStruct; // 0x510(0x560)


	// Object: Function CameraPostProcessActor.CameraPostProcessActor_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void UserConstructionScript();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CameraPostProcessActor.CameraPostProcessActor_C.Timeline_LerpPPSettings__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Timeline_LerpPPSettings__FinishedFunc();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CameraPostProcessActor.CameraPostProcessActor_C.Timeline_LerpPPSettings__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Timeline_LerpPPSettings__UpdateFunc();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CameraPostProcessActor.CameraPostProcessActor_C.Event LerpPostProcessSettings
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x131) ]
	void Event LerpPostProcessSettings(struct APostProcessVolume* currentPPVolumn, struct FBP_STRUCT_CameraPostProcessSettings_type targetPPSettingsStruct, float Time, int ID, bool isReverse);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CameraPostProcessActor.CameraPostProcessActor_C.ExecuteUbergraph_CameraPostProcessActor
	// Flags: [HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_CameraPostProcessActor(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

