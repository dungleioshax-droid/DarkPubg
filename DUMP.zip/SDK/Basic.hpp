#pragma once

#include <cstdint>

// Object: Enum Basic.EAttrOperator
enum class EAttrOperator : uint8_t
{
	Plus = 0,
	Multiply = 1,
	Set = 2,
	EAttrOperator_MAX = 3
};

// Object: Enum Basic.EAttrModifyRefType
enum class EAttrModifyRefType : uint8_t
{
	Val = 0,
	Rate = 1,
	Abs = 2,
	Set = 3,
	EAttrModifyRefType_MAX = 4
};

// Object: Enum Basic.EAttrVariableType
enum class EAttrVariableType : uint8_t
{
	Byte = 0,
	Int = 1,
	Float = 2,
	Num = 3,
	EAttrVariableType_MAX = 4
};

// Object: Enum Basic.EActorRegAttrTableType
enum class EActorRegAttrTableType : uint8_t
{
	EATY_NONE = 0,
	EATY_PLAYER = 1,
	EATY_ZOMBIE = 2,
	EATY_WEAPON = 3,
	EATY_VEHICLE = 4,
	EATY_MAX = 5
};

// Object: Enum Basic.EBattleItemDropReason
enum class EBattleItemDropReason : uint8_t
{
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	AutoEquipFailed = 3,
	CapacityExceeded = 4,
	UsedUp = 5,
	Force = 6,
	Replaced = 7,
	VehicleGroup = 8,
	Throwaway = 9,
	WeaponExchangeDropAttach = 10,
	EBattleItemDropReason_MAX = 11
};

// Object: Enum Basic.EBattleItemAdditionalDataType
enum class EBattleItemAdditionalDataType : uint8_t
{
	None = 0,
	TargetLogicSocket = 1,
	Weapon_Durability_Backpack = 2,
	Weapon_BulletNum_Backpack = 3,
	Weapon_UpgradeInfo_Backpack = 4,
	RemainingDuability = 5,
	EquipmentAvatar = 6,
	WeaponAvatar = 7,
	CustomColor = 8,
	CustomPattern = 9,
	CurElectricty = 10,
	AutoUse = 11,
	LimitPlayerKey = 12,
	MaxElectricty = 14,
	ConsumeSpeed = 15,
	ChipSlot1 = 16,
	ChipSlot2 = 17,
	ChipSlot3 = 18,
	CustomNum = 21,
	AUTO_EQUIP_ARMOE_ATTACHMENT = 22,
	AUTO_EQUIP_WEAPON_ATTACHMENT = 23,
	RollOnDead = 24,
	AutoEquipFromBackpack = 25,
	BUsing = 26,
	IsEquiping = 27,
	AvatarItem = 28,
	Affix = 29,
	VehicleHPRatio = 30,
	VehicleFuelRatio = 31,
	VehicleEnergyRatio = 32,
	ExtraData01 = 33,
	ExtraData02 = 34,
	OwnerInfo = 35,
	DropPlanInfo = 36,
	PveAffix = 37,
	ShapeInfo = 38,
	GunPoint = 100,
	Grip = 101,
	Magazine = 102,
	Gunstock = 103,
	OpticalSight = 104,
	MasterGun = 107,
	Ammo = 108,
	Pendant = 109,
	AngledOpticalSight = 110,
	ACCore = 111,
	Bezel = 112,
	GunLock = 113,
	TacticalAttach = 114,
	EBattleItemAdditionalDataType_MAX = 115
};

// Object: Enum Basic.EAnimLayerType
enum class EAnimLayerType : uint8_t
{
	EAnimLayer_Char = 0,
	EAnimLayer_Avatar = 10,
	EAnimLayer_AvatarAdditive = 11,
	EAnimLayer_AvatarSpecialMove = 12,
	EAnimLayer_Weapon = 20,
	EAnimLayer_WeaponAdditive = 21,
	EAnimLayer_WeaponAdditive2 = 22,
	EAnimLayer_WeaponDIYAvatar = 23,
	EAnimLayer_WeaponDIYAvatarAdditive = 24,
	EAnimLayer_Skill = 50,
	EAnimLayer_SkillAdditive = 51,
	EAnimLayer_Skill2 = 52,
	EAnimLayer_Max = 53
};

// Object: Enum Basic.EBattleItemUseReason
enum class EBattleItemUseReason : uint8_t
{
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	Swapped = 3,
	Initial = 4,
	EquipAndRecovery = 5,
	SwappedWithPackageWeapon = 6,
	EquipAndRecoveryToSafetyBox = 7,
	SkillUse = 8,
	EBattleItemUseReason_MAX = 9
};

// Object: Enum Basic.EItemStoreArea
enum class EItemStoreArea : uint8_t
{
	InBag = 0,
	InSafetyBox = 1,
	EItemStoreArea_MAX = 2
};

// Object: Enum Basic.EBattleItemDisuseReason
enum class EBattleItemDisuseReason : uint8_t
{
	Manually = 0,
	Associated = 1,
	Excluded = 2,
	Swapped = 3,
	Dropped = 4,
	Force = 5,
	Replace = 6,
	VehicleGroup = 7,
	PutBack = 8,
	PutIntoSafetyBox = 9,
	ReplacedAndPutBack = 10,
	EBattleItemDisuseReason_MAX = 11
};

// Object: Enum Basic.EBattleItemPickupReason
enum class EBattleItemPickupReason : uint8_t
{
	Manually = 0,
	Associated = 1,
	AutoPickup = 2,
	Initial = 3,
	ForceIntoBackpack = 4,
	AutoPickupAttachment = 5,
	SplitStack = 6,
	StorageBoxToBag = 7,
	FromStore = 8,
	EBattleItemPickupReason_MAX = 9
};

// Object: Enum Basic.EAttrModifyRecordType
enum class EAttrModifyRecordType : uint16_t
{
	Record_None = 0,
	SetValue_Respone = 100,
	SetValue_OnRepModSim = 101,
	SetValue_CaculateAttr1 = 111,
	SetValue_CaculateAttr2 = 112,
	SetValue_ClampAttr = 113,
	SetValue_InterfaceSet = 121,
	SetValue_Lua = 131,
	Remove_DisableAttr = 200,
	Remove_RemoveDynamic = 201,
	Remove_OnRepDynamic = 202,
	Modify_EnableAttrIndex = 301,
	Modify_AddDynamic = 302,
	EAttrModifyRecordType_MAX = 303
};

// Object: Enum Basic.EAttrModifyChannel
enum class EAttrModifyChannel : uint8_t
{
	SimulatedProxy = 1,
	AutonomousProxy = 2,
	Authority = 3,
	AllChannel = 10,
	EAttrModifyChannel_MAX = 11
};

// Object: Enum Basic.EBattleItemClientPickupType
enum class EBattleItemClientPickupType : uint8_t
{
	Defalut = 0,
	ForceIntoBackpack = 1,
	PickupIntoSafetyBox = 2,
	EBattleItemClientPickupType_MAX = 3
};

// Object: Enum Basic.EColdModeItemType
enum class EColdModeItemType : uint8_t
{
	firewood = 0,
	meat = 1,
	EColdModeItemType_MAX = 2
};

// Object: Enum Basic.EItemAttrs
enum class EItemAttrs : uint8_t
{
	ItemAttr_CannotManualDrop = 0,
	ItemAttr_RespawnNotDrop = 1,
	ItemAttr_TransformNotDrop = 2,
	ItemAttr_NotAddInTombBox = 3,
	ItemAttr_CanCarryInBattle = 4,
	ItemAttr_CannotMoveToVehicleBackpack = 5,
	ItemAttr_MAX = 6
};

// Object: Enum Basic.EBattleItemPickupRule
enum class EBattleItemPickupRule : uint8_t
{
	All = 0,
	Self = 1,
	Team = 2,
	Group = 3,
	AllCanSeeSelfCanPickUp = 4,
	None = 99,
	EBattleItemPickupRule_MAX = 100
};

// Object: Enum Basic.EBattleItemEquiptType
enum class EBattleItemEquiptType : uint16_t
{
	Bag = 501,
	Helmet = 502,
	Armor = 503,
	EBattleItemEquiptType_MAX = 504
};

// Object: Enum Basic.EStackModifyValueType
enum class EStackModifyValueType : uint8_t
{
	None = 0,
	Bool = 1,
	Byte = 2,
	Int32 = 3,
	Int64 = 4,
	Float = 5,
	Vector2D = 6,
	Vector = 7,
	Vector4 = 8,
	IntPoint = 9,
	IntVector = 10,
	Rotator = 11,
	Quat = 12,
	Transform = 13,
	LinearColor = 14,
	Color = 15,
	Name = 16,
	String = 17,
	Struct = 18,
	EStackModifyValueType_MAX = 19
};

// Object: Enum Basic.EItemAssociationType
enum class EItemAssociationType : uint8_t
{
	None = 0,
	Parent = 1,
	ChipSlot1 = 2,
	ChipSlot2 = 3,
	ChipSlot3 = 4,
	AssociationName = 5,
	Pendant = 6,
	Weapon_Durability_Backpack = 7,
	EItemAssociationType_MAX = 8
};

// Object: Enum Basic.ESkillPropSubType
enum class ESkillPropSubType : uint16_t
{
	ESkillPropSubType_None = 1200,
	ESkillPropSubType_1201 = 1201,
	ESkillPropSubType_MAX = 1202
};

// Object: Enum Basic.EBuffConditionFalseExecutePolicy
enum class EBuffConditionFalseExecutePolicy : uint8_t
{
	None = 0,
	EndAction = 2,
	EBuffConditionFalseExecutePolicy_MAX = 3
};

// Object: Enum Basic.EBuffSharedType
enum class EBuffSharedType : uint8_t
{
	None = 0,
	Target = 1,
	Boolean = 2,
	UInt8 = 3,
	Float = 4,
	Int32 = 5,
	Vector = 6,
	Rotator = 7,
	Name = 8,
	String = 9,
	EBuffSharedType_MAX = 10
};

// Object: Enum Basic.EBuffConditionEvalMode
enum class EBuffConditionEvalMode : uint8_t
{
	EveryTime = 0,
	OnChanged = 1,
	EBuffConditionEvalMode_MAX = 2
};

// Object: Enum Basic.EDeviceLevel
enum class EDeviceLevel : uint8_t
{
	DeviceLevel_Low = 0,
	DeviceLevel_Middle = 1,
	DeviceLevel_Hight = 2,
	DeviceLevel_MAX = 3
};

// Object: Enum Basic.EBuffEnabledRole
enum class EBuffEnabledRole : uint8_t
{
	ROLE_None = 0,
	ROLE_SimulatedProxy = 1,
	ROLE_AutonomousProxy = 2,
	ROLE_Authority = 3,
	ROLE_Client = 4,
	Role_AutonomousAuthority = 5,
	Role_AuthoritySimulated = 6,
	EBuffEnabledRole_MAX = 7
};

// Object: Enum Basic.EBuffClientSyncType
enum class EBuffClientSyncType : uint8_t
{
	None = 0,
	All = 1,
	Autonomous = 2,
	EBuffClientSyncType_MAX = 3
};

// Object: Enum Basic.EBuffConditionAndOr
enum class EBuffConditionAndOr : uint8_t
{
	And = 0,
	Or = 1,
	EBuffConditionAndOr_MAX = 2
};

// Object: Enum Basic.EBuffConditionExecuteTimeType
enum class EBuffConditionExecuteTimeType : uint8_t
{
	FirstTime = 0,
	EveryTime = 1,
	EBuffConditionExecuteTimeType_MAX = 2
};

// Object: Enum Basic.EBuffConditionFalseExecuteTypeNew
enum class EBuffConditionFalseExecuteTypeNew : uint8_t
{
	None = 0,
	EndAction = 2,
	EBuffConditionFalseExecuteTypeNew_MAX = 3
};

// Object: Enum Basic.EBuffConditionFalseExecuteType
enum class EBuffConditionFalseExecuteType : uint8_t
{
	None = 0,
	Disabled = 1,
	DisabledEnd = 2,
	EBuffConditionFalseExecuteType_MAX = 3
};

// Object: Enum Basic.EBuffConditionTrueExecuteType
enum class EBuffConditionTrueExecuteType : uint8_t
{
	Enabled = 0,
	ReAction = 1,
	EBuffConditionTrueExecuteType_MAX = 2
};

// Object: Enum Basic.EBuffConditionInitializeType
enum class EBuffConditionInitializeType : uint8_t
{
	None = 0,
	Disabled = 1,
	DisabledWhenFalse = 2,
	EBuffConditionInitializeType_MAX = 3
};

// Object: Enum Basic.EBuffTargetSubType
enum class EBuffTargetSubType : uint8_t
{
	EBuffTargetSubType_Other = 0,
	EBuffTargetSubType_Rifle = 1,
	EBuffTargetSubType_SingleShotSniper = 2,
	EBuffTargetSubType_BurstShotSniper = 3,
	EBuffTargetSubType_Submachine = 4,
	EBuffTargetSubType_ShotGun = 5,
	EBuffTargetSubType_MachineGun = 6,
	EBuffTargetSubType_Pistol = 7,
	EBuffTargetSubType_Melee = 8,
	EBuffTargetSubType_Crossbow = 9,
	EBuffTargetSubType_All = 32,
	EBuffTargetSubType_MAX = 33
};

// Object: Enum Basic.EBuffShowInUIType
enum class EBuffShowInUIType : uint8_t
{
	None = 0,
	DurationTime = 1,
	CDTime = 2,
	EBuffShowInUIType_MAX = 3
};

// Object: Enum Basic.EBuffTargetSocketType
enum class EBuffTargetSocketType : uint8_t
{
	Character = 0,
	Weapon = 1,
	World = 2,
	Vehicle = 3,
	EBuffTargetSocketType_MAX = 4
};

// Object: Enum Basic.EBuffTargetType
enum class EBuffTargetType : uint8_t
{
	Character = 0,
	Weapon = 1,
	Player = 2,
	Monster = 3,
	MonsterPlayer = 4,
	Vehicle = 5,
	AllWeapons = 6,
	EBuffTargetType_MAX = 7
};

// Object: Enum Basic.EBuffReActionType
enum class EBuffReActionType : uint8_t
{
	None = 0,
	OverWOrAddL = 1,
	ResetTime = 2,
	ResetLayer = 3,
	LayerChange = 4,
	InitWeapon = 5,
	EBuffReActionType_MAX = 6
};

// Object: Enum Basic.EBuffRefreshType
enum class EBuffRefreshType : uint8_t
{
	None = 0,
	ResetTime = 1,
	ResetTimeOnOverFlow = 2,
	ResetLayerOnOverFlow = 3,
	ResetAllOnOverFlow = 4,
	AppendTime = 5,
	EBuffRefreshType_MAX = 6
};

// Object: Enum Basic.EMultiSkillHandleType
enum class EMultiSkillHandleType : uint8_t
{
	UseNewer = 0,
	UseOlder = 1,
	StackEffect = 2,
	RefreshOlder = 4,
	EMultiSkillHandleType_MAX = 5
};

// Object: Enum Basic.EMultiCauserHandleType
enum class EMultiCauserHandleType : uint8_t
{
	UseNewer = 0,
	UseOlder = 1,
	StackEffect = 2,
	RefreshOlder = 4,
	EMultiCauserHandleType_MAX = 5
};

// Object: Enum Basic.EBuffTargetSourceType
enum class EBuffTargetSourceType : uint8_t
{
	Self = 0,
	PrevActionSet = 1,
	AreaOfTeammate = 2,
	AreaOfMonster = 3,
	Causer = 4,
	SelfAndAreaOfTeammate = 5,
	EBuffTargetSourceType_MAX = 6
};

// Object: Enum Basic.ESTExtraNetPriorityIssueID
enum class ESTExtraNetPriorityIssueID : uint8_t
{
	kNone = 0,
	kMove = 1,
	kStateChange = 2,
	ESTExtraNetPriorityIssueID_MAX = 3
};

// Object: Enum Basic.ESTExtraNetPriorityFlags
enum class ESTExtraNetPriorityFlags : uint16_t
{
	kPriority1 = 0,
	kPriority2 = 1,
	kPriority3 = 2,
	kPriority4 = 3,
	kMaxNum = 4,
	kPriorityNormal = 255,
	ESTExtraNetPriorityFlags_MAX = 256
};

// Object: Enum Basic.ETickOptimizationAnimUROMode
enum class ETickOptimizationAnimUROMode : uint8_t
{
	ScreenSize = 0,
	LOD = 1,
	MinLOD = 2,
	ETickOptimizationAnimUROMode_MAX = 3
};

// Object: Enum Basic.ETickOptimizationDistanceMode
enum class ETickOptimizationDistanceMode : uint8_t
{
	None = 0,
	Sphere = 1,
	ETickOptimizationDistanceMode_MAX = 2
};

// Object: Enum Basic.ELostConnectionToDSReason
enum class ELostConnectionToDSReason : uint8_t
{
	LostConnectionToDSReason_None = 0,
	LostConnectionToDSReason_TravelFailure_Default = 1,
	LostConnectionToDSReason_LocalConnectionLost = 2,
	LostConnectionToDSReason_LocalDetectedTimeout = 3,
	LostConnectionToDSReason_NMTFailure_Default = 4,
	LostConnectionToDSReason_MAX = 5
};

// Object: Enum Basic.ECommonCompare
enum class ECommonCompare : uint8_t
{
	Greater = 0,
	Equal = 1,
	Less = 2,
	GreaterOrEqual = 3,
	LessOrEqual = 4,
	ECommonCompare_MAX = 5
};

// Object: Enum Basic.EAngleRotationDirectionType
enum class EAngleRotationDirectionType : uint8_t
{
	EAutoMinAngle = 0,
	ERight = 1,
	ELeft = 2,
	EAngleRotationDirectionType_MAX = 3
};

// Object: ScriptStruct Basic.AttrModifyItem
// Size: 0x48 (Inherited: 0x0)
struct FAttrModifyItem
{
	struct TArray<struct FCacheAffactTargetInfo> AffectTargetsCachInfo; // 0x0(0x10)
	struct FString AttrModifyItemName; // 0x10(0x10)
	struct FString AttrName; // 0x20(0x10)
	int AttrID; // 0x30(0x4)
	int CompareId; // 0x34(0x4)
	uint8_t ModifierOp; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	float ModifierValue; // 0x3C(0x4)
	bool IsEnable; // 0x40(0x1)
	bool ClientSimulate; // 0x41(0x1)
	uint8_t Pad_0x42[0x6]; // 0x42(0x6)
};

// Object: ScriptStruct Basic.CacheAffactTargetInfo
// Size: 0x10 (Inherited: 0x0)
struct FCacheAffactTargetInfo
{
	struct TWeakObjectPtr<struct AActor> AffectTarget; // 0x0(0x8)
	float FinalAddValue; // 0x8(0x4)
	uint32_t CModifyUid; // 0xC(0x4)
};

// Object: ScriptStruct Basic.AttrModifyRecordItem
// Size: 0x28 (Inherited: 0x0)
struct FAttrModifyRecordItem
{
	struct FAttrDesc AttrDesc; // 0x0(0x18)
	struct TArray<struct FAttrModifyRecordDetails> DetailsArray; // 0x18(0x10)
};

// Object: ScriptStruct Basic.AttrModifyRecordDetails
// Size: 0x28 (Inherited: 0x0)
struct FAttrModifyRecordDetails
{
	struct FString ModifyDesc; // 0x0(0x10)
	int NextIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FAttrModifyRecordDetail> Data; // 0x18(0x10)
};

// Object: ScriptStruct Basic.AttrModifyRecordDetail
// Size: 0x10 (Inherited: 0x0)
struct FAttrModifyRecordDetail
{
	float PreModifyValue; // 0x0(0x4)
	float AfterModifyValue; // 0x4(0x4)
	float WorldTime; // 0x8(0x4)
	int ModifyType; // 0xC(0x4)
};

// Object: ScriptStruct Basic.AttrDesc
// Size: 0x18 (Inherited: 0x0)
struct FAttrDesc
{
	struct FString AttrName; // 0x0(0x10)
	bool bNeedSync; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	float CurValue; // 0x14(0x4)
};

// Object: ScriptStruct Basic.AttrDynamicModifyItem
// Size: 0x28 (Inherited: 0x0)
struct FAttrDynamicModifyItem
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
	struct TWeakObjectPtr<struct UObject> Causer; // 0x1C(0x8)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct Basic.AttrDynamicModifyTarget
// Size: 0x18 (Inherited: 0x0)
struct FAttrDynamicModifyTarget
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct TArray<struct FAttrDynamicModifyItem> List; // 0x8(0x10)
};

// Object: ScriptStruct Basic.AttrAffected
// Size: 0x18 (Inherited: 0x0)
struct FAttrAffected
{
	struct FString AttrName; // 0x0(0x10)
	struct AActor* AffectedActor; // 0x10(0x8)
};

// Object: ScriptStruct Basic.AttrRegisterItem
// Size: 0x38 (Inherited: 0x0)
struct FAttrRegisterItem
{
	int AttrID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString AttrName; // 0x8(0x10)
	uint8_t AttrVariableType; // 0x18(0x1)
	bool HasReplicatedTag; // 0x19(0x1)
	uint8_t Pad_0x1A[0x1E]; // 0x1A(0x1E)
};

// Object: ScriptStruct Basic.ModAttrSimulateSyncItem
// Size: 0x8 (Inherited: 0x0)
struct FModAttrSimulateSyncItem
{
	int AttrID; // 0x0(0x4)
	float FinalValue; // 0x4(0x4)
};

// Object: ScriptStruct Basic.RelateAttributeGroup
// Size: 0x50 (Inherited: 0x0)
struct FRelateAttributeGroup
{
	struct TMap<int, struct FString> RelateAttributes; // 0x0(0x50)
};

// Object: ScriptStruct Basic.AttributeExpand
// Size: 0x48 (Inherited: 0x0)
struct FAttributeExpand
{
	struct FString AttrName; // 0x0(0x10)
	struct FString AttrDesc; // 0x10(0x10)
	int RelateTypeId; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString RelateGroup; // 0x28(0x10)
	float Value; // 0x38(0x4)
	int nValue; // 0x3C(0x4)
	uint8_t bValue; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
};

// Object: ScriptStruct Basic.AttrDynamicModifier
// Size: 0xA8 (Inherited: 0x0)
struct FAttrDynamicModifier
{
	struct TMap<struct FString, struct FAttrDynamicModifyTarget> ModifyAttrs; // 0x0(0x50)
	struct TMap<struct FString, struct FAttrDynamicModifyConfig> ModifyConfigs; // 0x50(0x50)
	struct UAttrModifyComponent* Component; // 0xA0(0x8)
};

// Object: ScriptStruct Basic.AttrDynamicModifyConfig
// Size: 0x38 (Inherited: 0x0)
struct FAttrDynamicModifyConfig
{
	bool IsOneceModify; // 0x0(0x1)
	bool HasLimitAttr; // 0x1(0x1)
	bool HasMaxAttr; // 0x2(0x1)
	uint8_t Pad_0x3[0x5]; // 0x3(0x5)
	struct FString AttrName; // 0x8(0x10)
	struct FString LimitAttrName; // 0x18(0x10)
	struct FString MaxAttrName; // 0x28(0x10)
};

// Object: ScriptStruct Basic.ItemDefineID
// Size: 0x18 (Inherited: 0x0)
struct FItemDefineID
{
	int Type; // 0x0(0x4)
	int TypeSpecificID; // 0x4(0x4)
	bool bValidItem; // 0x8(0x1)
	bool bValidInstance; // 0x9(0x1)
	uint8_t Pad_0xA[0x6]; // 0xA(0x6)
	uint64_t InstanceID; // 0x10(0x8)
};

// Object: ScriptStruct Basic.ClientBaseInfo
// Size: 0x158 (Inherited: 0x0)
struct FClientBaseInfo
{
	struct FString OpenID; // 0x0(0x10)
	uint64_t RoleID; // 0x10(0x8)
	struct FString GameSvrId; // 0x18(0x10)
	struct FString GameAppID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	uint64_t GameID; // 0x58(0x8)
	struct FString BattleServerIP; // 0x60(0x10)
	uint32_t BattleServerPort; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct FString UserName; // 0x78(0x10)
	struct FString PicUrl; // 0x88(0x10)
	uint32_t PlayerKey; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct TArray<int> MrpcsData; // 0xA0(0x10)
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct TMap<int, struct FString> AdvConfig; // 0xB8(0x50)
	struct TMap<struct FString, struct UTexture2D*> AdvTextureList; // 0x108(0x50)
};

// Object: ScriptStruct Basic.BuffSyncBrief
// Size: 0x38 (Inherited: 0x0)
struct FBuffSyncBrief
{
	int InstID; // 0x0(0x4)
	uint8_t LayerCount; // 0x4(0x1)
	uint8_t LayerMax; // 0x5(0x1)
	uint8_t Level; // 0x6(0x1)
	uint8_t Pad_0x7[0x1]; // 0x7(0x1)
	int BuffID; // 0x8(0x4)
	int CauseSkillID; // 0xC(0x4)
	struct AActor* CauseActor; // 0x10(0x8)
	float SyncTime; // 0x18(0x4)
	float Duration; // 0x1C(0x4)
	float EndTime; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<float> CDDataArray; // 0x28(0x10)
};

// Object: ScriptStruct Basic.BuffReplaceData
// Size: 0x8 (Inherited: 0x0)
struct FBuffReplaceData
{
	int ID; // 0x0(0x4)
	bool bBuffInst; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Basic.BuffIncNetArray
// Size: 0x20 (Inherited: 0x0)
struct FBuffIncNetArray
{
	struct TArray<struct FBuffNetArrayUnit> IncArray; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct Basic.BuffNetArrayUnit
// Size: 0x40 (Inherited: 0x0)
struct FBuffNetArrayUnit
{
	struct FBuffSyncBrief Unit; // 0x0(0x38)
	bool bMarkDelete; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
};

// Object: ScriptStruct Basic.BattleItemAdditionalData
// Size: 0x28 (Inherited: 0x0)
struct FBattleItemAdditionalData
{
	uint8_t EDataType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int IntData; // 0x4(0x4)
	struct FString StringData; // 0x8(0x10)
	float FloatData; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	uint64_t Uint64Data; // 0x20(0x8)
};

// Object: ScriptStruct Basic.ItemAssociation
// Size: 0x28 (Inherited: 0x0)
struct FItemAssociation
{
	int AssociationType; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FItemDefineID AssociationTargetDefineID; // 0x8(0x18)
	struct UItemHandleBase* AssociationTargetHandle; // 0x20(0x8)
};

// Object: ScriptStruct Basic.BattleItemUseTarget
// Size: 0x28 (Inherited: 0x0)
struct FBattleItemUseTarget
{
	struct FItemDefineID TargetDefineID; // 0x0(0x18)
	int TargetAssociationType; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct AActor* TargetActor; // 0x20(0x8)
};

// Object: ScriptStruct Basic.ItemData
// Size: 0x58 (Inherited: 0x0)
struct FItemData
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct FItemDefineID DefineID; // 0x8(0x18)
	struct FString Name; // 0x20(0x10)
	struct FString Desc; // 0x30(0x10)
	struct FString Icon; // 0x40(0x10)
	struct UItemHandleBase* ItemHandle; // 0x50(0x8)
};

// Object: ScriptStruct Basic.BattleItemData
// Size: 0xC0 (Inherited: 0x58)
struct FBattleItemData : FItemData
{
	int Count; // 0x58(0x4)
	bool bEquipping; // 0x5C(0x1)
	uint8_t Pad_0x5D[0x3]; // 0x5D(0x3)
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // 0x60(0x10)
	int Durability; // 0x70(0x4)
	uint8_t ItemStoreArea; // 0x74(0x1)
	uint8_t Pad_0x75[0x3]; // 0x75(0x3)
	int64_t Priority; // 0x78(0x8)
	struct FBattleItemFeatureData FeatureData; // 0x80(0x30)
	struct TArray<struct FItemAssociation> Associations; // 0xB0(0x10)
};

// Object: ScriptStruct Basic.BattleItemFeatureData
// Size: 0x30 (Inherited: 0x0)
struct FBattleItemFeatureData
{
	float UnitWeight; // 0x0(0x4)
	int MaxCount; // 0x4(0x4)
	int CountLimit; // 0x8(0x4)
	bool bUnique; // 0xC(0x1)
	bool bStackable; // 0xD(0x1)
	bool bEquippable; // 0xE(0x1)
	bool bConsumable; // 0xF(0x1)
	bool bAutoEquipAndDrop; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	int ItemAttrsFlag; // 0x14(0x4)
	int SortingPriority; // 0x18(0x4)
	int Worth; // 0x1C(0x4)
	int ItemCapacity; // 0x20(0x4)
	int ItemDurability; // 0x24(0x4)
	int itemType; // 0x28(0x4)
	int ItemSubType; // 0x2C(0x4)
};

// Object: ScriptStruct Basic.BattleItemPickupInfo
// Size: 0x58 (Inherited: 0x0)
struct FBattleItemPickupInfo
{
	struct UObject* Source; // 0x0(0x8)
	int Count; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // 0x10(0x10)
	bool bAutoEquip; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
	struct FBattleItemUseTarget AutoEquipTarget; // 0x28(0x28)
	bool bDropOnDead; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
};

// Object: ScriptStruct Basic.BattleItemSpectatingData
// Size: 0x8 (Inherited: 0x0)
struct FBattleItemSpectatingData
{
	int TypeSpecificID; // 0x0(0x4)
	int AdditionalData; // 0x4(0x4)
};

// Object: ScriptStruct Basic.ItemFixTableItem
// Size: 0x18 (Inherited: 0x0)
struct FItemFixTableItem
{
	int ValidTimes; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString ExTime; // 0x8(0x10)
};

// Object: ScriptStruct Basic.AttrModifyRepItem
// Size: 0x10 (Inherited: 0x0)
struct FAttrModifyRepItem
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct AActor* TargetActor; // 0x8(0x8)
};

// Object: ScriptStruct Basic.AttrRowData
// Size: 0x28 (Inherited: 0x0)
struct FAttrRowData
{
	int AttrGroup; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString AttrName; // 0x8(0x10)
	uint8_t AttrVariableType; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	float OriginalValue; // 0x1C(0x4)
	float MinValue; // 0x20(0x4)
	float MaxValue; // 0x24(0x4)
};

// Object: ScriptStruct Basic.AttrModifyGroupItem
// Size: 0x10 (Inherited: 0x0)
struct FAttrModifyGroupItem
{
	struct TArray<struct FAttrModifyItem> AttrModifyItem; // 0x0(0x10)
};

// Object: ScriptStruct Basic.PlayerThrowInfo
// Size: 0x18 (Inherited: 0x0)
struct FPlayerThrowInfo
{
	struct TArray<struct FBattleItemSpectatingData> PlayerThrowInfo; // 0x0(0x10)
	uint32_t PlayerKey; // 0x10(0x4)
	uint32_t TeamID; // 0x14(0x4)
};

// Object: ScriptStruct Basic.PlayerBackPackInfo
// Size: 0x28 (Inherited: 0x0)
struct FPlayerBackPackInfo
{
	struct TArray<struct FBattleItemSpectatingData> PlayerBackPackInfo; // 0x0(0x10)
	int MainWeapon1TypeSpecificID; // 0x10(0x4)
	int MainWeapon1AmmoNuminClip; // 0x14(0x4)
	int MainWeapon2TypeSpecificID; // 0x18(0x4)
	int MainWeapon2AmmoNuminClip; // 0x1C(0x4)
	uint32_t PlayerKey; // 0x20(0x4)
	uint32_t TeamID; // 0x24(0x4)
};

// Object: ScriptStruct Basic.BattleItemPickupAfterLand
// Size: 0x78 (Inherited: 0x0)
struct FBattleItemPickupAfterLand
{
	struct FItemDefineID DefineID; // 0x0(0x18)
	struct FBattleItemPickupInfo PickupInfo; // 0x18(0x58)
	uint8_t Reason; // 0x70(0x1)
	uint8_t BattleItemClientPickupType; // 0x71(0x1)
	uint8_t Pad_0x72[0x6]; // 0x72(0x6)
};

// Object: ScriptStruct Basic.TagItemList
// Size: 0x10 (Inherited: 0x0)
struct FTagItemList
{
	struct TArray<int> tagList; // 0x0(0x10)
};

// Object: ScriptStruct Basic.TagOneItem
// Size: 0x8 (Inherited: 0x0)
struct FTagOneItem
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct Basic.PickupProposeData
// Size: 0x128 (Inherited: 0x0)
struct FPickupProposeData
{
	struct TArray<struct FPickupFirstCount> TaskPickFirst; // 0x0(0x10)
	int closeSubType; // 0x10(0x4)
	int crossbowSubType; // 0x14(0x4)
	int pistolSubType; // 0x18(0x4)
	int gunType; // 0x1C(0x4)
	int specialType; // 0x20(0x4)
	int specialType2; // 0x24(0x4)
	int ID2Type; // 0x28(0x4)
	int pistolClipSubType; // 0x2C(0x4)
	int SubMachineGunClipSubType; // 0x30(0x4)
	int SniperClipSubType; // 0x34(0x4)
	int RifleClipSubType; // 0x38(0x4)
	int gasSubID; // 0x3C(0x4)
	int backSubType; // 0x40(0x4)
	int MedicalSubType; // 0x44(0x4)
	int BandageID; // 0x48(0x4)
	int EnergyDrinksID; // 0x4C(0x4)
	int AdrenalineID; // 0x50(0x4)
	int AnodyneID; // 0x54(0x4)
	int Medical1ID; // 0x58(0x4)
	int Medical2ID; // 0x5C(0x4)
	struct TArray<int> SideMirrorList; // 0x60(0x10)
	struct TArray<int> MirrorList; // 0x70(0x10)
	int ViscidityBomb; // 0x80(0x4)
	int DefaultMedicineNum; // 0x84(0x4)
	int helmetSubType; // 0x88(0x4)
	int armorSubType; // 0x8C(0x4)
	int ScoreItemSubType; // 0x90(0x4)
	int SpecialNoDropItemSubType; // 0x94(0x4)
	int IceDrinkItemSubType; // 0x98(0x4)
	int IsAutoPickUpTaskSubType; // 0x9C(0x4)
	int CapacityThreshold; // 0xA0(0x4)
	int GlideSubType; // 0xA4(0x4)
	int ParachuteItemSubType; // 0xA8(0x4)
	int revivalCardID; // 0xAC(0x4)
	float revivalCardValidTime; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct TArray<int> firewoodPriority; // 0xB8(0x10)
	struct TArray<int> meatPriority; // 0xC8(0x10)
	struct TArray<int> UAVList; // 0xD8(0x10)
	struct TArray<int> ElectricityList; // 0xE8(0x10)
	struct TArray<int> ToUseInBackpackSubList; // 0xF8(0x10)
	struct TArray<int> ToUseInBackpackIDList; // 0x108(0x10)
	struct TArray<int> notExtractItemIDList; // 0x118(0x10)
};

// Object: ScriptStruct Basic.PickupFirstCount
// Size: 0x8 (Inherited: 0x0)
struct FPickupFirstCount
{
	int pickID; // 0x0(0x4)
	int Count; // 0x4(0x4)
};

// Object: ScriptStruct Basic.PickupSettingForTPlan
// Size: 0x1E8 (Inherited: 0x0)
struct FPickupSettingForTPlan
{
	int LimitSkillProps; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TMap<int, int> LimitBulletMap_XT; // 0x8(0x50)
	struct TMap<int, int> LimitDrugMap_XT; // 0x58(0x50)
	struct TMap<int, int> LimitThrowObjMap_XT; // 0xA8(0x50)
	struct TMap<int, int> LimitMultipleMirrorMap_XT; // 0xF8(0x50)
	struct TMap<int, int> LimitNormalInfillingMap_XT; // 0x148(0x50)
	struct TMap<int, int> LimitHalloweenInfillingMap_XT; // 0x198(0x50)
};

// Object: ScriptStruct Basic.PickupSetting
// Size: 0x1A8 (Inherited: 0x0)
struct FPickupSetting
{
	int LimitViscidityBomb; // 0x0(0x4)
	bool AutoPickupPistol; // 0x4(0x1)
	bool AutoPickupLevel3Backpack; // 0x5(0x1)
	bool AutoPickupSideMirror; // 0x6(0x1)
	bool AutoPickupSkillProps; // 0x7(0x1)
	int LimitSkillProps; // 0x8(0x4)
	bool AutoPickMirror; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	int AutoPickClipType; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TMap<int, int> LimitDrugMap; // 0x18(0x50)
	struct TMap<int, int> LimitThrowObjMap; // 0x68(0x50)
	struct TMap<int, int> LimitMultipleMirrorMap; // 0xB8(0x50)
	struct TMap<int, int> LimitFixConsumeItemMap; // 0x108(0x50)
	struct TMap<int, int> LimitSeasonItemMap; // 0x158(0x50)
};

// Object: ScriptStruct Basic.SpecPickItem
// Size: 0xC (Inherited: 0x0)
struct FSpecPickItem
{
	int item_id; // 0x0(0x4)
	int cur_count; // 0x4(0x4)
	int total_count; // 0x8(0x4)
};

// Object: ScriptStruct Basic.ItemRecordData
// Size: 0x100 (Inherited: 0x0)
struct FItemRecordData
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	int itemType; // 0x8(0x4)
	int ItemSubType; // 0xC(0x4)
	int BPID; // 0x10(0x4)
	int WeightforOrder; // 0x14(0x4)
	int Worth; // 0x18(0x4)
	int ItemCapacity; // 0x1C(0x4)
	int Durability; // 0x20(0x4)
	int ItemSoundID; // 0x24(0x4)
	int ItemQuality; // 0x28(0x4)
	int ItemPickupRule; // 0x2C(0x4)
	int AIFullVaule; // 0x30(0x4)
	float Weight; // 0x34(0x4)
	int MaxCount; // 0x38(0x4)
	bool AutoEquipandDrop; // 0x3C(0x1)
	bool Consumable; // 0x3D(0x1)
	bool Equipable; // 0x3E(0x1)
	uint8_t Pad_0x3F[0x1]; // 0x3F(0x1)
	struct FString ItemName; // 0x40(0x10)
	struct FString ItemBigIcon; // 0x50(0x10)
	struct FString ItemDesc; // 0x60(0x10)
	struct FString ItemSmallIcon; // 0x70(0x10)
	struct FString KillWhiteIcon; // 0x80(0x10)
	struct FString ItemWhiteIcon; // 0x90(0x10)
	struct FString RedEmotionSoundPath; // 0xA0(0x10)
	struct FString PickupDesc; // 0xB0(0x10)
	struct FString BackpackSimple; // 0xC0(0x10)
	struct FString SpecialIcon; // 0xD0(0x10)
	struct FString ItemBigIcon2; // 0xE0(0x10)
	struct FString ItemSmallIcon2; // 0xF0(0x10)
};

// Object: ScriptStruct Basic.ArmorAttachItemUnit
// Size: 0x20 (Inherited: 0x0)
struct FArmorAttachItemUnit
{
	struct FItemDefineID DefineID; // 0x0(0x18)
	uint8_t SlotAdditionalType; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct Basic.BPClassItemMap
// Size: 0x50 (Inherited: 0x0)
struct FBPClassItemMap
{
	struct TMap<struct FString, struct FString> BPClassModOverridePath; // 0x0(0x50)
};

// Object: ScriptStruct Basic.BPClassItem
// Size: 0xB0 (Inherited: 0x0)
struct FBPClassItem
{
	struct FString ClassTagName; // 0x0(0x10)
	struct UClass* NativeClass; // 0x10(0x28)
	struct UClass* BPClass; // 0x38(0x28)
	struct TMap<struct FString, struct FString> BPClassModOverridePath; // 0x60(0x50)
};

// Object: ScriptStruct Basic.BudgetSchedulerChannelConfig
// Size: 0x18 (Inherited: 0x0)
struct FBudgetSchedulerChannelConfig
{
	struct FName ChannelName; // 0x0(0x8)
	float BudgetMsPerFrame; // 0x8(0x4)
	int MaxPerFrame; // 0xC(0x4)
	bool bEnabled; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct Basic.SkillTableRow
// Size: 0x108 (Inherited: 0x0)
struct FSkillTableRow
{
	int SkillID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Name; // 0x8(0x10)
	struct FString IconPath; // 0x18(0x10)
	int SkillType; // 0x28(0x4)
	float Coeff1; // 0x2C(0x4)
	float CoolTime; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FString BPPath; // 0x38(0x10)
	struct FString Desc; // 0x48(0x10)
	struct TArray<int> BuffIDs; // 0x58(0x10)
	struct TMap<int, int> BuffLoadTypes; // 0x68(0x50)
	uint8_t Pad_0xB8[0x50]; // 0xB8(0x50)
};

// Object: ScriptStruct Basic.BuffTableRow
// Size: 0x130 (Inherited: 0x0)
struct FBuffTableRow
{
	int BuffID; // 0x0(0x4)
	int MaxLayer; // 0x4(0x4)
	float Duration; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString BuffType; // 0x10(0x10)
	struct FString Name; // 0x20(0x10)
	struct FString IconPath; // 0x30(0x10)
	struct FString BPPath; // 0x40(0x10)
	struct FString Desc; // 0x50(0x10)
	struct TSet<struct FString> MutexBuffTypes; // 0x60(0x50)
	struct TSet<struct FString> ExcludeBuffTypes; // 0xB0(0x50)
	uint8_t RefreshType; // 0x100(0x1)
	uint8_t ReActionType; // 0x101(0x1)
	uint8_t TargetType; // 0x102(0x1)
	uint8_t MultiCauserHanleType; // 0x103(0x1)
	uint8_t MultiSkillHandleType; // 0x104(0x1)
	uint8_t ClientSyncType; // 0x105(0x1)
	uint8_t Pad_0x106[0x2]; // 0x106(0x2)
	float ClientSyncInterval; // 0x108(0x4)
	bool ExistForever; // 0x10C(0x1)
	bool IsOnece; // 0x10D(0x1)
	bool IsClientOwnLife; // 0x10E(0x1)
	uint8_t NeedShowInUIType; // 0x10F(0x1)
	int LocalizeDescID; // 0x110(0x4)
	int TipsOnAddBuff; // 0x114(0x4)
	int ModeOpen; // 0x118(0x4)
	uint8_t Pad_0x11C[0x4]; // 0x11C(0x4)
	struct FString ModeStrings; // 0x120(0x10)
};

// Object: ScriptStruct Basic.GameModeEnvData
// Size: 0x50 (Inherited: 0x0)
struct FGameModeEnvData
{
	int ModeID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString ModType; // 0x8(0x10)
	struct FString ModType2; // 0x18(0x10)
	int MapID; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString MapType; // 0x30(0x10)
	struct FString SubMod; // 0x40(0x10)
};

// Object: ScriptStruct Basic.RecordItemID
// Size: 0x18 (Inherited: 0x0)
struct FRecordItemID
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct Basic.StackModifyValue
// Size: 0x8 (Inherited: 0x0)
struct FStackModifyValue
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct Basic.StackModifyStructValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyStructValue : FStackModifyValue
{
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: ScriptStruct Basic.StackModifyStringValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyStringValue : FStackModifyValue
{
	struct FString Value; // 0x8(0x10)
};

// Object: ScriptStruct Basic.StackModifyNameValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyNameValue : FStackModifyValue
{
	struct FName Value; // 0x8(0x8)
};

// Object: ScriptStruct Basic.StackModifyColorValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyColorValue : FStackModifyValue
{
	struct FColor Value; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Basic.StackModifyLinearColorValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyLinearColorValue : FStackModifyValue
{
	struct FLinearColor Value; // 0x8(0x10)
};

// Object: ScriptStruct Basic.StackModifyTransformValue
// Size: 0x40 (Inherited: 0x8)
struct FStackModifyTransformValue : FStackModifyValue
{
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FTransform Value; // 0x10(0x30)
};

// Object: ScriptStruct Basic.StackModifyQuatValue
// Size: 0x20 (Inherited: 0x8)
struct FStackModifyQuatValue : FStackModifyValue
{
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FQuat Value; // 0x10(0x10)
};

// Object: ScriptStruct Basic.StackModifyRotatorValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyRotatorValue : FStackModifyValue
{
	struct FRotator Value; // 0x8(0xC)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.StackModifyIntVectorValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyIntVectorValue : FStackModifyValue
{
	struct FIntVector Value; // 0x8(0xC)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.StackModifyIntPointValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyIntPointValue : FStackModifyValue
{
	struct FIntPoint Value; // 0x8(0x8)
};

// Object: ScriptStruct Basic.StackModifyVector4Value
// Size: 0x20 (Inherited: 0x8)
struct FStackModifyVector4Value : FStackModifyValue
{
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FVector4 Value; // 0x10(0x10)
};

// Object: ScriptStruct Basic.StackModifyVectorValue
// Size: 0x18 (Inherited: 0x8)
struct FStackModifyVectorValue : FStackModifyValue
{
	struct FVector Value; // 0x8(0xC)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.StackModifyVector2DValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyVector2DValue : FStackModifyValue
{
	struct FVector2D Value; // 0x8(0x8)
};

// Object: ScriptStruct Basic.StackModifyFloatValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyFloatValue : FStackModifyValue
{
	float Value; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Basic.StackModifyInt64Value
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyInt64Value : FStackModifyValue
{
	int64_t Value; // 0x8(0x8)
};

// Object: ScriptStruct Basic.StackModifyInt32Value
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyInt32Value : FStackModifyValue
{
	int Value; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Basic.StackModifyByteValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyByteValue : FStackModifyValue
{
	uint8_t Value; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Basic.StackModifyBoolValue
// Size: 0x10 (Inherited: 0x8)
struct FStackModifyBoolValue : FStackModifyValue
{
	bool Value; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Basic.LuaEventTypeToIDSet
// Size: 0x50 (Inherited: 0x0)
struct FLuaEventTypeToIDSet
{
	struct TMap<struct FString, struct FLuaEventTypeIDSet> EventTypeToIDSet; // 0x0(0x50)
};

// Object: ScriptStruct Basic.LuaEventTypeIDSet
// Size: 0x50 (Inherited: 0x0)
struct FLuaEventTypeIDSet
{
	struct TSet<struct FString> EventIDSet; // 0x0(0x50)
};

// Object: ScriptStruct Basic.LuaEventTypeContainer
// Size: 0x50 (Inherited: 0x0)
struct FLuaEventTypeContainer
{
	struct TMap<struct FString, int> EventIDContainer; // 0x0(0x50)
};

// Object: ScriptStruct Basic.EventTypeContainer
// Size: 0x50 (Inherited: 0x0)
struct FEventTypeContainer
{
	struct TMap<struct FString, struct FEventIDContainer> EventIDContainer; // 0x0(0x50)
};

// Object: ScriptStruct Basic.EventIDContainer
// Size: 0x10 (Inherited: 0x0)
struct FEventIDContainer
{
	struct TArray<struct FEventValueContainer> EventValueContainer; // 0x0(0x10)
};

// Object: ScriptStruct Basic.EventValueContainer
// Size: 0x38 (Inherited: 0x0)
struct FEventValueContainer
{
	struct TWeakObjectPtr<struct UObject> ObjContext; // 0x0(0x8)
	struct FString FunctionName; // 0x8(0x10)
	struct FString EventType; // 0x18(0x10)
	struct FString EventID; // 0x28(0x10)
};

// Object: ScriptStruct Basic.NetRelevancyGroupManager
// Size: 0x50 (Inherited: 0x0)
struct FNetRelevancyGroupManager
{
	struct TMap<struct FNetRelevancyGroupID, struct UNetRelevancyGroup*> RelevancyGroups; // 0x0(0x50)
};

// Object: ScriptStruct Basic.NetRelevancyGroupID
// Size: 0x4 (Inherited: 0x0)
struct FNetRelevancyGroupID
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
};

// Object: ScriptStruct Basic.BuffTriggerWrapperItem
// Size: 0x8 (Inherited: 0x0)
struct FBuffTriggerWrapperItem
{
	struct FTriggerIndex TriggerIndex; // 0x0(0x4)
	uint8_t ConditionFalsePolicy; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Basic.TriggerIndex
// Size: 0x4 (Inherited: 0x0)
struct FTriggerIndex
{
	int Index; // 0x0(0x4)
};

// Object: ScriptStruct Basic.BuffCheckConditionWrapperItem
// Size: 0x8 (Inherited: 0x0)
struct FBuffCheckConditionWrapperItem
{
	struct FConditionIndex ConditionIndex; // 0x0(0x4)
	uint8_t FalseExecType; // 0x4(0x1)
	uint8_t FalseActionType; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
};

// Object: ScriptStruct Basic.ConditionIndex
// Size: 0x4 (Inherited: 0x0)
struct FConditionIndex
{
	int Index; // 0x0(0x4)
};

// Object: ScriptStruct Basic.BuffConditionActionItem
// Size: 0x8 (Inherited: 0x0)
struct FBuffConditionActionItem
{
	int Index; // 0x0(0x4)
	uint8_t InitializeType; // 0x4(0x1)
	uint8_t TrueExecType; // 0x5(0x1)
	uint8_t FalseExecType; // 0x6(0x1)
	uint8_t Pad_0x7[0x1]; // 0x7(0x1)
};

// Object: ScriptStruct Basic.STBuffInstancedItem
// Size: 0xD0 (Inherited: 0x0)
struct FSTBuffInstancedItem
{
	int InstID; // 0x0(0x4)
	int BuffID; // 0x4(0x4)
	int BuffIndex; // 0x8(0x4)
	int LayerCount; // 0xC(0x4)
	int Level; // 0x10(0x4)
	bool PendingRemove; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	float EndTime; // 0x18(0x4)
	float DSEndTime; // 0x1C(0x4)
	float Duration; // 0x20(0x4)
	int LayerMax; // 0x24(0x4)
	struct TArray<float> CDDataArray; // 0x28(0x10)
	struct TWeakObjectPtr<struct AActor> Causer; // 0x38(0x8)
	struct TWeakObjectPtr<struct AActor> Owner; // 0x40(0x8)
	struct TWeakObjectPtr<struct USTBuff> Buff; // 0x48(0x8)
	struct TWeakObjectPtr<struct UActorComponent> OwnerSystem; // 0x50(0x8)
	int CauseSkillID; // 0x58(0x4)
	float LastSyncClientTime; // 0x5C(0x4)
	bool IsNeedSyncClient; // 0x60(0x1)
	uint8_t Pad_0x61[0x6F]; // 0x61(0x6F)
};

// Object: ScriptStruct Basic.BuffShared
// Size: 0x8 (Inherited: 0x0)
struct FBuffShared
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct Basic.BuffStringShared
// Size: 0x18 (Inherited: 0x8)
struct FBuffStringShared : FBuffShared
{
	struct FString Value; // 0x8(0x10)
};

// Object: ScriptStruct Basic.BuffNameShared
// Size: 0x10 (Inherited: 0x8)
struct FBuffNameShared : FBuffShared
{
	struct FName Value; // 0x8(0x8)
};

// Object: ScriptStruct Basic.BuffRotatorShared
// Size: 0x18 (Inherited: 0x8)
struct FBuffRotatorShared : FBuffShared
{
	struct FRotator Value; // 0x8(0xC)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.BuffVectorShared
// Size: 0x18 (Inherited: 0x8)
struct FBuffVectorShared : FBuffShared
{
	struct FVector Value; // 0x8(0xC)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.BuffInt32Shared
// Size: 0x10 (Inherited: 0x8)
struct FBuffInt32Shared : FBuffShared
{
	int Value; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Basic.BuffFloatShared
// Size: 0x10 (Inherited: 0x8)
struct FBuffFloatShared : FBuffShared
{
	float Value; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Basic.BuffUInt8Shared
// Size: 0x10 (Inherited: 0x8)
struct FBuffUInt8Shared : FBuffShared
{
	uint8_t Value; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Basic.BuffBooleanShared
// Size: 0x10 (Inherited: 0x8)
struct FBuffBooleanShared : FBuffShared
{
	bool Value; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Basic.BuffTargetShared
// Size: 0x18 (Inherited: 0x8)
struct FBuffTargetShared : FBuffShared
{
	struct TArray<struct TWeakObjectPtr<struct AActor>> Actors; // 0x8(0x10)
};

// Object: ScriptStruct Basic.TriggerConditionConfig
// Size: 0x10 (Inherited: 0x0)
struct FTriggerConditionConfig
{
	struct USTBuffCondition* Condition; // 0x0(0x8)
	uint8_t EvalMode; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Basic.MultiStringMap
// Size: 0x50 (Inherited: 0x0)
struct FMultiStringMap
{
	struct TMap<int, struct FStringMap> StringMap; // 0x0(0x50)
};

// Object: ScriptStruct Basic.StringMap
// Size: 0x50 (Inherited: 0x0)
struct FStringMap
{
	struct TMap<struct FString, struct FString> Data; // 0x0(0x50)
};

// Object: ScriptStruct Basic.TickOptimizationTickSettings
// Size: 0x8 (Inherited: 0x0)
struct FTickOptimizationTickSettings
{
	bool bEnabled; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float Interval; // 0x4(0x4)
};

// Object: ScriptStruct Basic.AnimChildComponentData
// Size: 0xC (Inherited: 0x0)
struct FAnimChildComponentData
{
	struct TWeakObjectPtr<struct UUAEAnimListComponentBase> ChildComp; // 0x0(0x8)
	uint8_t Pad_0x8[0x4]; // 0x8(0x4)
};

// Object: ScriptStruct Basic.AnimListMapValueData
// Size: 0x10 (Inherited: 0x0)
struct FAnimListMapValueData
{
	struct TArray<struct FAnimListData> AnimListMapValue; // 0x0(0x10)
};

// Object: ScriptStruct Basic.AnimListData
// Size: 0x10 (Inherited: 0x0)
struct FAnimListData
{
	int LayerID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UAnimationAsset* Animation; // 0x8(0x8)
};

// Object: ScriptStruct Basic.GameEngineTickStat
// Size: 0x8 (Inherited: 0x0)
struct FGameEngineTickStat
{
	float Duration; // 0x0(0x4)
	float AvgTickDelta; // 0x4(0x4)
};

// Object: ScriptStruct Basic.TravelFailureInfo
// Size: 0x20 (Inherited: 0x0)
struct FTravelFailureInfo
{
	struct UWorld* World; // 0x0(0x8)
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FString ErrorMessage; // 0x10(0x10)
};

// Object: ScriptStruct Basic.NetworkFailureInfo
// Size: 0x28 (Inherited: 0x0)
struct FNetworkFailureInfo
{
	struct UWorld* World; // 0x0(0x8)
	struct UNetDriver* NetDriver; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
	struct FString ErrorMessage; // 0x18(0x10)
};

// Object: ScriptStruct Basic.LoadClassArrayParams
// Size: 0x20 (Inherited: 0x0)
struct FLoadClassArrayParams
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct Basic.TableNameToName
// Size: 0x48 (Inherited: 0x0)
struct FTableNameToName
{
	struct FName tableName; // 0x0(0x8)
	struct FName ID; // 0x8(0x8)
	struct FName Name; // 0x10(0x8)
	struct FName Path; // 0x18(0x8)
	struct FName PathHigh; // 0x20(0x8)
	struct FName LobbyPath; // 0x28(0x8)
	struct FName LobbyPathHigh; // 0x30(0x8)
	struct FName WrapperPath; // 0x38(0x8)
	struct FName Custom1; // 0x40(0x8)
};

// Object: ScriptStruct Basic.BPTableItem
// Size: 0x58 (Inherited: 0x0)
struct FBPTableItem
{
	int ID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Name; // 0x8(0x10)
	struct FString Path; // 0x18(0x10)
	struct FString LobbyPath; // 0x28(0x10)
	struct FString WrapperPath; // 0x38(0x10)
	struct FString Custom1; // 0x48(0x10)
};

// Object: ScriptStruct Basic.DSNetSaturateCollectInfo
// Size: 0x20 (Inherited: 0x0)
struct FDSNetSaturateCollectInfo
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct Basic.UnLoadLevelActorCollection
// Size: 0x18 (Inherited: 0x0)
struct FUnLoadLevelActorCollection
{
	struct TArray<struct AActor*> LevelActors; // 0x0(0x10)
	float CollectionTime; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Basic.DistanceSegmentConfig
// Size: 0x8 (Inherited: 0x0)
struct FDistanceSegmentConfig
{
	float RadiusSquared; // 0x0(0x4)
	int NumberLimit; // 0x4(0x4)
};

// Object: ScriptStruct Basic.DistanceSegmentItem
// Size: 0xC (Inherited: 0x0)
struct FDistanceSegmentItem
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct Basic.RPCShareSerializationFunctionPresetConfig
// Size: 0x30 (Inherited: 0x0)
struct FRPCShareSerializationFunctionPresetConfig
{
	struct FSoftClassPath ClassPath; // 0x0(0x18)
	struct FString FunctionName; // 0x18(0x10)
	bool bEligible; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: ScriptStruct Basic.PendingRegionNetworkObject
// Size: 0x20 (Inherited: 0x0)
struct FPendingRegionNetworkObject
{
	struct UObject* RegionObject; // 0x0(0x8)
	struct FRegionID OldRegionID; // 0x8(0xC)
	struct FRegionID NewRegionID; // 0x14(0xC)
};

// Object: ScriptStruct Basic.DSNetReportInfo
// Size: 0x1C (Inherited: 0x0)
struct FDSNetReportInfo
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
};

// Object: Class Basic.PlayerActorChannelExActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct APlayerActorChannelExActor : AActor
{
};

// Object: Class Basic.PlayerReliableSequentialSyncActor
// Size: 0x4C0 (Inherited: 0x4B0)
struct APlayerReliableSequentialSyncActor : APlayerActorChannelExActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	struct APlayerController* OwningController; // 0x4B8(0x8)


	// Object: Function Basic.PlayerReliableSequentialSyncActor.OnActorSpawned
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427bb2c
	// Params: [ Num(1) Size(0x8) ]
	void OnActorSpawned(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104210320
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870
};

// Object: Class Basic.OnlyActorComponent
// Size: 0x180 (Inherited: 0x178)
struct UOnlyActorComponent : UActorComponent
{
	uint8_t bCanEverUpdate; // 0x178(0x1)
	uint8_t Pad_0x179[0x7]; // 0x179(0x7)
};

// Object: Class Basic.UAENetActor
// Size: 0x580 (Inherited: 0x570)
struct AUAENetActor : ALuaActor
{
	uint8_t Pad_0x570[0x8]; // 0x570(0x8)
	int iRegionActor; // 0x578(0x4)
	bool bStaticAddNetworkActor; // 0x57C(0x1)
	uint8_t AutoDormancyType; // 0x57D(0x1)
	uint8_t Pad_0x57E[0x2]; // 0x57E(0x2)


	// Object: Function Basic.UAENetActor.ReceivedPlayerActiveRegionsChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void ReceivedPlayerActiveRegionsChanged(bool bEnter);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class Basic.UAEAnimListComponentBase
// Size: 0x2C8 (Inherited: 0x178)
struct UUAEAnimListComponentBase : UActorComponent
{
	uint8_t Pad_0x178[0xB0]; // 0x178(0xB0)
	struct TMap<int, struct FAnimListMapValueData> AnimListMap; // 0x228(0x50)
	struct TArray<struct UAnimationAsset*> AnimationCacheList; // 0x278(0x10)
	uint8_t Pad_0x288[0x38]; // 0x288(0x38)
	bool bDisableAnimListOnDS; // 0x2C0(0x1)
	uint8_t Pad_0x2C1[0x7]; // 0x2C1(0x7)
};

// Object: Class Basic.ItemHandleBase
// Size: 0xA8 (Inherited: 0x28)
struct UItemHandleBase : UObject
{
	int Count; // 0x28(0x4)
	int MaxCount; // 0x2C(0x4)
	bool bUnique; // 0x30(0x1)
	bool bStackable; // 0x31(0x1)
	bool bSingle; // 0x32(0x1)
	uint8_t Pad_0x33[0x5]; // 0x33(0x5)
	struct TMap<int, struct FItemAssociation> AssociationMap; // 0x38(0x50)
	struct FItemDefineID DefineID; // 0x88(0x18)
	uint8_t Pad_0xA0[0x8]; // 0xA0(0x8)


	// Object: Function Basic.ItemHandleBase.SetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104272930
	// Params: [ Num(2) Size(0x30) ]
	void SetAssociation(int AssociationType, struct FItemAssociation Association);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102E2DFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1023CD6B4
	// [Call #7] RVA: 0x1041F0318
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.ItemHandleBase.RemoveAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042728b4
	// Params: [ Num(1) Size(0x4) ]
	void RemoveAssociation(int AssociationType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041F03A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102E2DFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023CD6B4
	// [Call #10] RVA: 0x1041F0318
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.ItemHandleBase.Init
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104272820
	// Params: [ Num(1) Size(0x18) ]
	void Init(struct FItemDefineID InDefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041F03A8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102E2DFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1023CD6B4
	// [Call #14] RVA: 0x1041F0318
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Basic.ItemHandleBase.GetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042727cc
	// Params: [ Num(1) Size(0x18) ]
	struct FItemDefineID GetDefineID();
	// [Call #1] RVA: 0x1041E5664
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041E5664
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041F03A8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102E2DFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1023CD6B4
	// [Call #15] RVA: 0x1041F0318

	// Object: Function Basic.ItemHandleBase.GetAssociationMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104272768
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<int, struct FItemAssociation> GetAssociationMap();
	// [Call #1] RVA: 0x1041F03EC
	// [Call #2] RVA: 0x104277BEC
	// [Call #3] RVA: 0x102D5C478
	// [Call #4] RVA: 0x102D5C478
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041E5664
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041F03A8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102E2DFBC
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.ItemHandleBase.GetAssociationListByTargetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042726b4
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FItemAssociation> GetAssociationListByTargetType(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041F0198
	// [Call #4] RVA: 0x104277B9C
	// [Call #5] RVA: 0x1023C5288
	// [Call #6] RVA: 0x1023C5288
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1041F03EC
	// [Call #9] RVA: 0x104277BEC
	// [Call #10] RVA: 0x102D5C478
	// [Call #11] RVA: 0x102D5C478
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041E5664
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Basic.ItemHandleBase.GetAssociationByTargetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104272608
	// Params: [ Num(2) Size(0x40) ]
	struct FItemAssociation GetAssociationByTargetDefineID(struct FItemDefineID TargetDefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x1041F0274
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041F0198
	// [Call #9] RVA: 0x104277B9C
	// [Call #10] RVA: 0x1023C5288
	// [Call #11] RVA: 0x1023C5288
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1041F03EC
	// [Call #14] RVA: 0x104277BEC
	// [Call #15] RVA: 0x102D5C478
	// [Call #16] RVA: 0x102D5C478
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1041E5664
	// [Call #19] RVA: 0x1041EFFBC
	// [Call #20] RVA: 0x10516D168

	// Object: Function Basic.ItemHandleBase.GetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10427256c
	// Params: [ Num(2) Size(0x30) ]
	struct FItemAssociation GetAssociation(int AssociationType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041F011C
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E5664
	// [Call #8] RVA: 0x1041F0274
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041F0198
	// [Call #12] RVA: 0x104277B9C
	// [Call #13] RVA: 0x1023C5288
	// [Call #14] RVA: 0x1023C5288
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1041F03EC
	// [Call #17] RVA: 0x104277BEC
	// [Call #18] RVA: 0x102D5C478
	// [Call #19] RVA: 0x102D5C478

	// Object: Function Basic.ItemHandleBase.Constuct
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1042724d4
	// Params: [ Num(1) Size(0x18) ]
	void Constuct(struct FItemDefineID& InDefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041F011C
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041E5664
	// [Call #11] RVA: 0x1041F0274
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041F0198

	// Object: Function Basic.ItemHandleBase.CollectionNeedLoadSoftPath
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104272424
	// Params: [ Num(1) Size(0x10) ]
	void CollectionNeedLoadSoftPath(struct TArray<struct FSoftObjectPath>& OutSoftPathList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102102810
	// [Call #4] RVA: 0x102102810
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041F011C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.ItemHandleBase.AddAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104272358
	// Params: [ Num(2) Size(0x30) ]
	void AddAssociation(int AssociationType, struct FItemAssociation Association);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102E2DFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1023CD6B4
	// [Call #7] RVA: 0x1041F00B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102102810
	// [Call #11] RVA: 0x102102810
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
};

// Object: Class Basic.BattleItemHandleBase
// Size: 0x138 (Inherited: 0xA8)
struct UBattleItemHandleBase : UItemHandleBase
{
	uint8_t Pad_0xA8[0x58]; // 0xA8(0x58)
	struct FString LuaFilePath; // 0x100(0x10)
	bool bEquipping; // 0x110(0x1)
	uint8_t ItemStoreArea; // 0x111(0x1)
	uint8_t Pad_0x112[0x6]; // 0x112(0x6)
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // 0x118(0x10)
	bool bDropOnDead; // 0x128(0x1)
	bool bDropWhenDisuse; // 0x129(0x1)
	uint8_t Pad_0x12A[0x2]; // 0x12A(0x2)
	float UnitWeight; // 0x12C(0x4)
	bool bEquippable; // 0x130(0x1)
	bool bConsumable; // 0x131(0x1)
	bool bAutoEquipAndDrop; // 0x132(0x1)
	uint8_t Pad_0x133[0x1]; // 0x133(0x1)
	int ItemAttrsFlag; // 0x134(0x4)


	// Object: Function Basic.BattleItemHandleBase.UpdateAttributeModify
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265b80
	// Params: [ Num(1) Size(0x1) ]
	void UpdateAttributeModify(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.BattleItemHandleBase.UnEquip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104265b4c
	// Params: [ Num(1) Size(0x1) ]
	bool UnEquip();
	// [Call #1] RVA: 0x1041E5D28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.BattleItemHandleBase.ShouldDropInDisuse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265994
	// Params: [ Num(6) Size(0x46) ]
	bool ShouldDropInDisuse(struct TScriptInterface<Class>& ItemContainer, struct FItemDefineID CurrentPickupItemDefineID, struct FItemDefineID ThisItemDefineID, int KeptCount, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041EFFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x1041E5664
	// [Call #15] RVA: 0x1041E5D28
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.HanldePickupAssociationData
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1042658d4
	// Params: [ Num(2) Size(0x11) ]
	bool HanldePickupAssociationData(struct TArray<struct FBattleItemAdditionalData>& PickupAdditionalData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1023C52B8
	// [Call #4] RVA: 0x1023C52B8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041E5664
	// [Call #19] RVA: 0x1041E5664

	// Object: Function Basic.BattleItemHandleBase.HanldeDropAssociationData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265898
	// Params: [ Num(1) Size(0x1) ]
	bool HanldeDropAssociationData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1023C52B8
	// [Call #4] RVA: 0x1023C52B8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.HanldeCleared
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10426585c
	// Params: [ Num(1) Size(0x1) ]
	bool HanldeCleared();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1023C52B8
	// [Call #4] RVA: 0x1023C52B8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.HandleUse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10426577c
	// Params: [ Num(3) Size(0x2A) ]
	bool HandleUse(struct FBattleItemUseTarget Target, uint8_t Reason);
	// [Call #1] RVA: 0x10240685C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10282C31C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168

	// Object: Function Basic.BattleItemHandleBase.HandlePickup
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265600
	// Params: [ Num(4) Size(0x6A) ]
	bool HandlePickup(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemPickupInfo PickupInfo, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102406800
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10282C278
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10240685C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10282C31C

	// Object: Function Basic.BattleItemHandleBase.HandleEnable
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265564
	// Params: [ Num(2) Size(0x2) ]
	bool HandleEnable(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102406800
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10282C278
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x1023C52B8
	// [Call #14] RVA: 0x1023C52B8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10240685C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.BattleItemHandleBase.HandleDrop
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265494
	// Params: [ Num(3) Size(0x6) ]
	bool HandleDrop(int InCount, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102406800
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.HandleDisuse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265400
	// Params: [ Num(2) Size(0x2) ]
	bool HandleDisuse(uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function Basic.BattleItemHandleBase.HandleChangeItemStoreArea
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10426536c
	// Params: [ Num(2) Size(0x2) ]
	bool HandleChangeItemStoreArea(uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.HandleBindToTargetItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265330
	// Params: [ Num(1) Size(0x1) ]
	bool HandleBindToTargetItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.GetWorldInternal
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	// Offset: 0x1042652f4
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetWorldInternal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.GetCurrentWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042652c0
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetCurrentWorld();
	// [Call #1] RVA: 0x1041E57F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168

	// Object: Function Basic.BattleItemHandleBase.ExtractItemData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x104265254
	// Params: [ Num(1) Size(0xC0) ]
	struct FBattleItemData ExtractItemData();
	// [Call #1] RVA: 0x102E460E4
	// [Call #2] RVA: 0x1041E56B0
	// [Call #3] RVA: 0x1041E56B0
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1041E57F8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.ClearAdditionalDataByType
	// Flags: [Final|Native|Public]
	// Offset: 0x1042651d8
	// Params: [ Num(1) Size(0x1) ]
	void ClearAdditionalDataByType(uint8_t DataType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041E612C
	// [Call #4] RVA: 0x102E460E4
	// [Call #5] RVA: 0x1041E56B0
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1041E57F8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.ClearAdditionalData
	// Flags: [Final|Native|Public]
	// Offset: 0x1042651c4
	// Params: [ Num(0) Size(0x0) ]
	void ClearAdditionalData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041E612C
	// [Call #4] RVA: 0x102E460E4
	// [Call #5] RVA: 0x1041E56B0
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1041E57F8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.BattleItemHandleBase.CheckCanUse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104265094
	// Params: [ Num(4) Size(0x3A) ]
	bool CheckCanUse(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemUseTarget Target, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10240685C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10282C31C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041E612C
	// [Call #12] RVA: 0x102E460E4
	// [Call #13] RVA: 0x1041E56B0
	// [Call #14] RVA: 0x1041E56B0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1041E57F8
};

// Object: Class Basic.UAEGameInstance
// Size: 0x568 (Inherited: 0x2E8)
struct UUAEGameInstance : UGameInstance
{
	struct FClientBaseInfo ClientBaseInfo; // 0x2E8(0x158)
	struct FScriptMulticastDelegate EnginePreTick; // 0x440(0x10)
	uint8_t Pad_0x450[0x68]; // 0x450(0x68)
	struct UFrontendHUD* AssociatedFrontendHUD; // 0x4B8(0x8)
	uint8_t Pad_0x4C0[0x8]; // 0x4C0(0x8)
	struct ULuaStateWrapper* LuaStateWrapper; // 0x4C8(0x8)
	bool bStandAloneFromLobby; // 0x4D0(0x1)
	uint8_t Pad_0x4D1[0x27]; // 0x4D1(0x27)
	struct FScriptMulticastDelegate OnPreBattleResult; // 0x4F8(0x10)
	uint8_t Pad_0x508[0x10]; // 0x508(0x10)
	struct TArray<struct FString> HighWeatherNames; // 0x518(0x10)
	int HighWeatherMinRenderQuality; // 0x528(0x4)
	int HighWeatherMaxRenderQuality; // 0x52C(0x4)
	int ModeID; // 0x530(0x4)
	uint8_t Pad_0x534[0x4]; // 0x534(0x4)
	struct FString ModType; // 0x538(0x10)
	struct FString ModType2; // 0x548(0x10)
	struct TArray<struct FString> ExtraModules; // 0x558(0x10)


	// Object: Function Basic.UAEGameInstance.SetModeID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429511c
	// Params: [ Num(1) Size(0x4) ]
	void SetModeID(int InModeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104214770
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.UAEGameInstance.SetLuaStateWrapper
	// Flags: [Final|Native|Public]
	// Offset: 0x1042950a0
	// Params: [ Num(1) Size(0x8) ]
	void SetLuaStateWrapper(struct ULuaStateWrapper* TLuaStateWrapper);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104217880
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104214770
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.UAEGameInstance.SetExtraModules
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104294fbc
	// Params: [ Num(1) Size(0x10) ]
	void SetExtraModules(struct TArray<struct FString> InExtraModules);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F86A94
	// [Call #4] RVA: 0x104214A38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104217880
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104214770
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x10519022C

	// Object: Function Basic.UAEGameInstance.OpenAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104294fa8
	// Params: [ Num(0) Size(0x0) ]
	void OpenAssetLoadLog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F86A94
	// [Call #4] RVA: 0x104214A38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104217880
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104214770
	// [Call #18] RVA: 0x10519022C

	// Object: DelegateFunction Basic.UAEGameInstance.OnPreBattleResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnPreBattleResult__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.UAEGameInstance.LuaLeakDetect
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x104294f94
	// Params: [ Num(0) Size(0x0) ]
	void LuaLeakDetect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F86A94
	// [Call #4] RVA: 0x104214A38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104217880
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104214770
	// [Call #18] RVA: 0x10519022C

	// Object: Function Basic.UAEGameInstance.LuaDoString
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x104294efc
	// Params: [ Num(1) Size(0x10) ]
	void LuaDoString(struct FString LuaString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104217700
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F86A94
	// [Call #10] RVA: 0x104214A38
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104217880
	// [Call #21] RVA: 0x10516D168

	// Object: Function Basic.UAEGameInstance.GetWeatherTime
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294ec0
	// Params: [ Num(1) Size(0x4) ]
	float GetWeatherTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104217700
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F86A94
	// [Call #10] RVA: 0x104214A38
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104217880

	// Object: Function Basic.UAEGameInstance.GetWeatherLevelName
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294e54
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetWeatherLevelName();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104217700
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F86A94
	// [Call #14] RVA: 0x104214A38
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Basic.UAEGameInstance.GetWeatherID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294e18
	// Params: [ Num(1) Size(0x4) ]
	int GetWeatherID();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104217700
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F86A94
	// [Call #14] RVA: 0x104214A38
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x101F8B9F8

	// Object: Function Basic.UAEGameInstance.GetModType2
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104294db4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetModType2();
	// [Call #1] RVA: 0x1042149E4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104217700
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.UAEGameInstance.GetModType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104294d50
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetModType();
	// [Call #1] RVA: 0x104214990
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1042149E4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104217700
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Basic.UAEGameInstance.GetModeID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104294d1c
	// Params: [ Num(1) Size(0x4) ]
	int GetModeID();
	// [Call #1] RVA: 0x104214988
	// [Call #2] RVA: 0x104214990
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1042149E4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104217700
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.UAEGameInstance.GetLuaStateWrapper
	// Flags: [Final|Native|Public]
	// Offset: 0x104294ce8
	// Params: [ Num(1) Size(0x8) ]
	struct ULuaStateWrapper* GetLuaStateWrapper();
	// [Call #1] RVA: 0x104217888
	// [Call #2] RVA: 0x104214988
	// [Call #3] RVA: 0x104214990
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1042149E4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.UAEGameInstance.GetLoadWeatherName
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294c10
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetLoadWeatherName(struct FString InWeatherName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x104217888
	// [Call #10] RVA: 0x104214988
	// [Call #11] RVA: 0x104214990
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1042149E4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Basic.UAEGameInstance.GetIsHighWeatherLevel
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294b60
	// Params: [ Num(2) Size(0x11) ]
	bool GetIsHighWeatherLevel(struct FString InWeatherLevelName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104217888
	// [Call #15] RVA: 0x104214988
	// [Call #16] RVA: 0x104214990
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Basic.UAEGameInstance.GetGameID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104294aec
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetGameID();
	// [Call #1] RVA: 0x104EBEAEC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x104217888
	// [Call #20] RVA: 0x104214988

	// Object: Function Basic.UAEGameInstance.GetExtraModulesString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104294a88
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetExtraModulesString();
	// [Call #1] RVA: 0x104214A48
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104EBEAEC
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Basic.UAEGameInstance.GetExtraModules
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104294a50
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetExtraModules();
	// [Call #1] RVA: 0x104214A40
	// [Call #2] RVA: 0x104214A48
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104EBEAEC
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Basic.UAEGameInstance.GetDeviceLevel
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104294a14
	// Params: [ Num(1) Size(0x4) ]
	int GetDeviceLevel();
	// [Call #1] RVA: 0x104214A40
	// [Call #2] RVA: 0x104214A48
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104EBEAEC
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.UAEGameInstance.GetDataTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429496c
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEDataTable* GetDataTable_Mod(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042163A8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104214A40
	// [Call #8] RVA: 0x104214A48
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x104EBEAEC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Basic.UAEGameInstance.GetDataTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042948c4
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEDataTable* GetDataTable(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104214E6C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1042163A8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x104214A40
	// [Call #14] RVA: 0x104214A48
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.UAEGameInstance.GetAssociatedFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104294890
	// Params: [ Num(1) Size(0x8) ]
	struct UFrontendHUD* GetAssociatedFrontendHUD();
	// [Call #1] RVA: 0x1042176B8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104214E6C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1042163A8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104214A40
	// [Call #15] RVA: 0x104214A48
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function Basic.UAEGameInstance.CloseAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x10429487c
	// Params: [ Num(0) Size(0x0) ]
	void CloseAssetLoadLog();
	// [Call #1] RVA: 0x1042176B8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104214E6C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1042163A8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104214A40
	// [Call #15] RVA: 0x104214A48
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
};

// Object: Class Basic.UAENetBunchQueueSystem
// Size: 0x30 (Inherited: 0x30)
struct UUAENetBunchQueueSystem : UWorldSubsystem
{
};

// Object: Class Basic.UAEBaseSkillCondition
// Size: 0x88 (Inherited: 0x80)
struct UUAEBaseSkillCondition : UUTSkillCondition
{
	struct APawn* OwnerPawnForBuff; // 0x80(0x8)
};

// Object: Class Basic.AttrModifyComponent
// Size: 0x958 (Inherited: 0x178)
struct UAttrModifyComponent : UActorComponent
{
	uint8_t Pad_0x178[0xF0]; // 0x178(0xF0)
	int ConfigAutoAddAttId; // 0x268(0x4)
	uint8_t Pad_0x26C[0xA4]; // 0x26C(0xA4)
	struct TArray<struct FAttrModifyItem> ConfigAttrModifyList; // 0x310(0x10)
	uint8_t Pad_0x320[0xA0]; // 0x320(0xA0)
	uint32_t AttrModifyStateList; // 0x3C0(0x4)
	uint8_t Pad_0x3C4[0x74]; // 0x3C4(0x74)
	struct FRepAttributeModify DynamicModifierRep; // 0x438(0x18)
	struct FRepAttributeModify DynamicModifierRepOnlyOwner; // 0x450(0x18)
	uint8_t Pad_0x468[0x20]; // 0x468(0x20)
	struct FScriptMulticastDelegate OnAttrModified; // 0x488(0x10)
	struct FScriptMulticastDelegate OnAttrRemoved; // 0x498(0x10)
	struct FAttrDynamicModifier DynamicModifier; // 0x4A8(0xA8)
	uint8_t Pad_0x550[0x50]; // 0x550(0x50)
	struct TArray<struct FAttributeExpand> AttributeExpands; // 0x5A0(0x10)
	bool bAddReserveNum; // 0x5B0(0x1)
	uint8_t Pad_0x5B1[0x7]; // 0x5B1(0x7)
	struct TMap<struct FString, struct FRelateAttributeGroup> RelateAttributeGroup; // 0x5B8(0x50)
	uint8_t ActorAttrType; // 0x608(0x1)
	uint8_t Pad_0x609[0x10F]; // 0x609(0x10F)
	struct TArray<struct FModAttrSimulateSyncItem> ModSimulateSyncList; // 0x718(0x10)
	uint8_t Pad_0x728[0x108]; // 0x728(0x108)
	struct FScriptMulticastDelegate OnNeedSetSpeedOverLimit; // 0x830(0x10)
	uint8_t Pad_0x840[0xF8]; // 0x840(0xF8)
	struct TArray<struct FAttrModifyRecordItem> ExceptionAttrModifyRecords_DS; // 0x938(0x10)
	struct TArray<struct FAttrModifyRecordItem> ExceptionAttrModifyRecords_Client; // 0x948(0x10)


	// Object: Function Basic.AttrModifyComponent.SwitchAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104261b60
	// Params: [ Num(3) Size(0x6) ]
	bool SwitchAttrModifierByIndex(int ModifyConfigIndex, bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DF364
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.AttrModifyComponent.SwitchAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104261a70
	// Params: [ Num(3) Size(0x12) ]
	bool SwitchAttrModifier(struct FString AttrModifyItemName, bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DF26C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DF364
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.AttrModifyComponent.StartTimerToSyncRecordAttrValue
	// Flags: [Final|Native|Public]
	// Offset: 0x1042619f4
	// Params: [ Num(1) Size(0x4) ]
	void StartTimerToSyncRecordAttrValue(float Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041E254C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041DF26C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041DF364

	// Object: Function Basic.AttrModifyComponent.SetValueToAttributeSafety
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042618dc
	// Params: [ Num(3) Size(0x18) ]
	void SetValueToAttributeSafety(struct FString AttrName, float Value, int ModifyRecordType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041DDD94
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E254C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DF26C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.SetOrignalValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104261804
	// Params: [ Num(2) Size(0x14) ]
	void SetOrignalValueToAttribute(struct FString AttrName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DE1E8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DDD94
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.SetOrignalValueAndBaseValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426172c
	// Params: [ Num(2) Size(0x14) ]
	void SetOrignalValueAndBaseValue(struct FString AttrName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DE324
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DE1E8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.SetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	// Offset: 0x104261670
	// Params: [ Num(2) Size(0x5) ]
	void SetAttrModifyStateValue(int Index, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DB5C4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041DE324
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DE1E8
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.SetAttributeMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104261598
	// Params: [ Num(2) Size(0x14) ]
	void SetAttributeMinValue(struct FString AttrName, float MinValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DE4F0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DB5C4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DE324
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.SetAttributeMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042614c0
	// Params: [ Num(2) Size(0x14) ]
	void SetAttributeMaxValue(struct FString AttrName, float MaxValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DE3A8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DE4F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.ServerSendExceptionType
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x1042613e0
	// Params: [ Num(2) Size(0x14) ]
	void ServerSendExceptionType(struct FString AttrName, int ExceptionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DE3A8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.ServerRequestRecordAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104261340
	// Params: [ Num(1) Size(0x10) ]
	void ServerRequestRecordAttrValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041DE3A8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.ResponeAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104261260
	// Params: [ Num(2) Size(0x14) ]
	void ResponeAttrValue(struct FString AttrName, float FinalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.RequestAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1042611c0
	// Params: [ Num(1) Size(0x10) ]
	void RequestAttrValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.RemoveModifyItemFromCache
	// Flags: [Final|Native|Public]
	// Offset: 0x104261134
	// Params: [ Num(2) Size(0x5) ]
	bool RemoveModifyItemFromCache(uint32_t ModifyUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DBC48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.RemoveAttrListener
	// Flags: [Final|Native|Public]
	// Offset: 0x10426101c
	// Params: [ Num(2) Size(0x30) ]
	void RemoveAttrListener(struct FString AttrName, struct FSluaBPVar Listener);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021DB640
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1041DB054
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x1021DB65C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041DBC48
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.RemoveAllDynamicModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260f98
	// Params: [ Num(1) Size(0x1) ]
	void RemoveAllDynamicModifier(bool bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DA744
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1021DB640
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10217475C
	// [Call #10] RVA: 0x1041DB054
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x1021DB65C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x1021DB65C
	// [Call #15] RVA: 0x1021DB65C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1041DBC48

	// Object: Function Basic.AttrModifyComponent.RegisterModifyAbleAttr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104260e94
	// Params: [ Num(3) Size(0x12) ]
	bool RegisterModifyAbleAttr(struct TArray<struct FAttrRegisterItem>& AttrRegists, bool bSetAttrByOrigin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DAAFC
	// [Call #6] RVA: 0x102249914
	// [Call #7] RVA: 0x102249914
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DA744
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1021DB640
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10217475C
	// [Call #18] RVA: 0x1041DB054
	// [Call #19] RVA: 0x1021DB65C
	// [Call #20] RVA: 0x1021DB65C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.RegistAttrModifyRecordList
	// Flags: [Final|Native|Public]
	// Offset: 0x104260dbc
	// Params: [ Num(2) Size(0x14) ]
	void RegistAttrModifyRecordList(struct FString AttrName, int RecordLen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041E2414
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DAAFC
	// [Call #14] RVA: 0x102249914
	// [Call #15] RVA: 0x102249914
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DA744

	// Object: Function Basic.AttrModifyComponent.RegCurrentModAttrs
	// Flags: [Final|Native|Public]
	// Offset: 0x104260da8
	// Params: [ Num(0) Size(0x0) ]
	void RegCurrentModAttrs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041E2414
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DAAFC
	// [Call #14] RVA: 0x102249914
	// [Call #15] RVA: 0x102249914
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.RefreshAttributeModify
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260d10
	// Params: [ Num(1) Size(0x10) ]
	void RefreshAttributeModify(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DE6CC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041E2414
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DAAFC

	// Object: Function Basic.AttrModifyComponent.PushAttrModifyRecordItem
	// Flags: [Final|Native|Public]
	// Offset: 0x104260b68
	// Params: [ Num(5) Size(0x30) ]
	void PushAttrModifyRecordItem(struct FString AttrName, float PreValue, float CurValue, int ModifyRecordType, struct FString ModifyDesc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DC0EC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DE6CC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.OnRep_ModSimulateSyncList
	// Flags: [Final|Native|Public]
	// Offset: 0x104260b54
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ModSimulateSyncList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DC0EC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DE6CC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.OnRep_ExceptionAttrModifyRecords
	// Flags: [Final|Native|Public]
	// Offset: 0x104260b40
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ExceptionAttrModifyRecords();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DC0EC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DE6CC
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.OnRep_DynamicModifier
	// Flags: [Final|Native|Public]
	// Offset: 0x104260b2c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_DynamicModifier();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DC0EC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041DE6CC
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.OnRep_AttrModifyStateList
	// Flags: [Final|Native|Public]
	// Offset: 0x104260b18
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_AttrModifyStateList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DC0EC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: DelegateFunction Basic.AttrModifyComponent.OnNeedSetSpeedOverLimit__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnNeedSetSpeedOverLimit__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction Basic.AttrModifyComponent.OnAttrModifiedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void OnAttrModifiedEvent__DelegateSignature(struct TArray<struct FAttrAffected>& AffectedAttrS);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.AttrModifyComponent.LuaSetValueToAttributeSafety
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260a40
	// Params: [ Num(2) Size(0x14) ]
	void LuaSetValueToAttributeSafety(struct FString AttrName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DDD8C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.IsAttrModifyStateValidIndex
	// Flags: [Final|Native|Public]
	// Offset: 0x1042609b4
	// Params: [ Num(2) Size(0x5) ]
	bool IsAttrModifyStateValidIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DAF98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041DDD8C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.InitializeRelateAttributeExpands
	// Flags: [Final|Native|Public]
	// Offset: 0x1042609a0
	// Params: [ Num(0) Size(0x0) ]
	void InitializeRelateAttributeExpands();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DAF98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041DDD8C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.HasDynamicModifier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042608f8
	// Params: [ Num(2) Size(0x11) ]
	bool HasDynamicModifier(struct FString AttrModifyId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DD8D4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DAF98
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041DDD8C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.HandleExceptionAttrModify
	// Flags: [Final|Native|Public]
	// Offset: 0x104260820
	// Params: [ Num(2) Size(0x14) ]
	void HandleExceptionAttrModify(struct FString AttrName, int ExceptionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041E29AC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DD8D4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041DAF98
	// [Call #18] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	// Offset: 0x1042607ec
	// Params: [ Num(1) Size(0x8) ]
	struct UAttrModifyModDataSubsystem* GetSubsystem();
	// [Call #1] RVA: 0x1041DEB20
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E29AC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DD8D4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DAF98

	// Object: Function Basic.AttrModifyComponent.GetMaxAttrName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426071c
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetMaxAttrName(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DE6E0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041DEB20
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041E29AC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1041DD8D4

	// Object: Function Basic.AttrModifyComponent.GetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	// Offset: 0x104260690
	// Params: [ Num(2) Size(0x5) ]
	bool GetAttrModifyStateValue(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DC6B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DE6E0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1041DEB20
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041E29AC
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.GetAttrModifyStateNum
	// Flags: [Final|Native|Public]
	// Offset: 0x104260674
	// Params: [ Num(1) Size(0x4) ]
	int GetAttrModifyStateNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DC6B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DE6E0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1041DEB20
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041E29AC

	// Object: Function Basic.AttrModifyComponent.GetAttrModifyItemByItemName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426055c
	// Params: [ Num(2) Size(0x58) ]
	struct FAttrModifyItem GetAttrModifyItemByItemName(struct FString ItemName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1041DF8D4
	// [Call #5] RVA: 0x1042690C4
	// [Call #6] RVA: 0x102E2DF8C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102E2DF8C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041DC6B8
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1041DE6E0
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.GetAttributeValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042604b4
	// Params: [ Num(2) Size(0x14) ]
	float GetAttributeValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DE5BC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1041DF8D4
	// [Call #11] RVA: 0x1042690C4
	// [Call #12] RVA: 0x102E2DF8C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102E2DF8C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1041DC6B8

	// Object: Function Basic.AttrModifyComponent.GetAttributeOrignalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426040c
	// Params: [ Num(2) Size(0x14) ]
	float GetAttributeOrignalValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DE644
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DE5BC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x1041DF8D4
	// [Call #17] RVA: 0x1042690C4
	// [Call #18] RVA: 0x102E2DF8C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x102E2DF8C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0

	// Object: Function Basic.AttrModifyComponent.GetAttributeMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260364
	// Params: [ Num(2) Size(0x14) ]
	float GetAttributeMaxValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DE688
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DE644
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DE5BC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.GetAttrDynamicModifyTargetString
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104260278
	// Params: [ Num(2) Size(0x28) ]
	struct FString GetAttrDynamicModifyTargetString(struct FAttrDynamicModifyTarget& DynamicModifyTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DFEF4
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x103A86C68
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x103A86C68
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DE688
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DE644
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.GetAttrDynamicModifyItemString
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104260194
	// Params: [ Num(2) Size(0x38) ]
	struct FString GetAttrDynamicModifyItemString(struct FAttrDynamicModifyItem& DynamicModifyItem);
	// [Call #1] RVA: 0x103A844B8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041DFF38
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DFEF4
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x103A86C68
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x103A86C68
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1041DE688
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.EnableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260108
	// Params: [ Num(2) Size(0x5) ]
	bool EnableAttrModifierByIndex(int ModifyConfigIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DB2A8
	// [Call #4] RVA: 0x103A844B8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041DFF38
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041DFEF4
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x103A86C68
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x103A86C68

	// Object: Function Basic.AttrModifyComponent.EnableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104260060
	// Params: [ Num(2) Size(0x11) ]
	bool EnableAttrModifier(struct FString AttrModifyItemName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DF264
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DB2A8
	// [Call #10] RVA: 0x103A844B8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DFF38
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.AttrModifyComponent.DisableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10425ffd4
	// Params: [ Num(2) Size(0x5) ]
	bool DisableAttrModifierByIndex(int ModifyConfigIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DB608
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DF264
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DB2A8
	// [Call #13] RVA: 0x103A844B8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041DFF38
	// [Call #17] RVA: 0x101F8156C

	// Object: Function Basic.AttrModifyComponent.DisableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10425ff2c
	// Params: [ Num(2) Size(0x11) ]
	bool DisableAttrModifier(struct FString AttrModifyItemName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DF35C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DB608
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DF264
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DB2A8

	// Object: Function Basic.AttrModifyComponent.DisableAllAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10425fe98
	// Params: [ Num(2) Size(0x2) ]
	bool DisableAllAttrModifier(bool bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DA6B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DF35C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DB608
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DF264
	// [Call #16] RVA: 0x101F8130C

	// Object: Function Basic.AttrModifyComponent.ConditionSyncRecordAttrValue
	// Flags: [Final|Native|Public]
	// Offset: 0x10425fe84
	// Params: [ Num(0) Size(0x0) ]
	void ConditionSyncRecordAttrValue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041DA6B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DF35C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041DB608
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DF264

	// Object: Function Basic.AttrModifyComponent.ClientSyncRecordAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10425fde4
	// Params: [ Num(1) Size(0x10) ]
	void ClientSyncRecordAttrValue(struct TArray<struct FAttrDesc> AttrDescs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041FABC0
	// [Call #4] RVA: 0x1041FABC0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041DA6B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041DF35C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.ClientSendRecordData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10425fcf4
	// Params: [ Num(2) Size(0x2C) ]
	void ClientSendRecordData(struct FAttrModifyRecordItem RecordItem, int ExceptionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041F3354
	// [Call #6] RVA: 0x1041F3354
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041FABC0
	// [Call #11] RVA: 0x1041FABC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DA6B4

	// Object: Function Basic.AttrModifyComponent.ClearAllAttrModify
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10425fce0
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllAttrModify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041F3354
	// [Call #6] RVA: 0x1041F3354
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041FABC0
	// [Call #11] RVA: 0x1041FABC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041DA6B4

	// Object: Function Basic.AttrModifyComponent.AddValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10425fc08
	// Params: [ Num(2) Size(0x14) ]
	void AddValueToAttribute(struct FString AttrName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041DD964
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041F3354
	// [Call #14] RVA: 0x1041F3354
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041FABC0

	// Object: Function Basic.AttrModifyComponent.AddModifyItemAndCache
	// Flags: [Final|Native|Public]
	// Offset: 0x10425fa10
	// Params: [ Num(7) Size(0x30) ]
	uint32_t AddModifyItemAndCache(struct FString AttrName, uint8_t CModifyType, float CValue, bool bEnable, struct UObject* Causer, bool bOldModify);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041DFE30
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyComponent.AddDynamicModifier
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10425f910
	// Params: [ Num(2) Size(0x49) ]
	void AddDynamicModifier(struct FAttrModifyItem& AttrModifyItem, bool RepOnlyOwner);
	// [Call #1] RVA: 0x102E2DE5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041DC6F4
	// [Call #7] RVA: 0x102E2DF8C
	// [Call #8] RVA: 0x102E2DF8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.AddBModifyAndCacheWithCParam
	// Flags: [Final|Native|Public]
	// Offset: 0x10425f7a0
	// Params: [ Num(5) Size(0x20) ]
	uint32_t AddBModifyAndCacheWithCParam(struct FString AttrName, uint8_t CModifyType, float CValue, bool ClientSimulate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DFE08
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102E2DE5C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041DC6F4
	// [Call #19] RVA: 0x102E2DF8C

	// Object: Function Basic.AttrModifyComponent.AddBModifyAndCache
	// Flags: [Final|Native|Public]
	// Offset: 0x10425f630
	// Params: [ Num(5) Size(0x20) ]
	uint32_t AddBModifyAndCache(struct FString AttrName, uint8_t ModifyType, float Value, bool ClientSimulate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041DFB00
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyComponent.AddAttrListener
	// Flags: [Final|Native|Public]
	// Offset: 0x10425f518
	// Params: [ Num(2) Size(0x30) ]
	void AddAttrListener(struct FString AttrName, struct FSluaBPVar Listener);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021DB640
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1041DAFC0
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x1021DB65C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1041DFB00
	// [Call #24] RVA: 0x101F8130C
};

// Object: Class Basic.AttrModifyInterface
// Size: 0x28 (Inherited: 0x28)
struct IAttrModifyInterface : IInterface
{

	// Object: Function Basic.AttrModifyInterface.SetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042630f0
	// Params: [ Num(3) Size(0x18) ]
	void SetAttrValue(struct FString AttrName, float NewVal, int Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.AttrModifyInterface.RequestAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104263050
	// Params: [ Num(1) Size(0x10) ]
	void RequestAttrValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Basic.AttrModifyInterface.RegisterModifiedAttributes
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104263034
	// Params: [ Num(0) Size(0x0) ]
	void RegisterModifiedAttributes();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Basic.AttrModifyInterface.GetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104262f84
	// Params: [ Num(2) Size(0x14) ]
	float GetAttrValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.AttrModifyInterface.GetAttrModifyRelevantActors
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104262f18
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetAttrModifyRelevantActors();
	// [Call #1] RVA: 0x10212ECFC
	// [Call #2] RVA: 0x101F811FC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyInterface.GetAttrModifyComponent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104262edc
	// Params: [ Num(1) Size(0x8) ]
	struct UAttrModifyComponent* GetAttrModifyComponent();
	// [Call #1] RVA: 0x10212ECFC
	// [Call #2] RVA: 0x101F811FC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyInterface.GetAttributeValue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104262e2c
	// Params: [ Num(2) Size(0x14) ]
	float GetAttributeValue(struct FString AttrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10212ECFC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.AttrModifyInterface.AddAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104262d0c
	// Params: [ Num(3) Size(0x18) ]
	void AddAttrValue(struct FString AttrName, float AddVal, int Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10212ECFC
	// [Call #16] RVA: 0x101F811FC
};

// Object: Class Basic.AttrModifyModDataSubsystem
// Size: 0x188 (Inherited: 0x30)
struct UAttrModifyModDataSubsystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x158]; // 0x30(0x158)
};

// Object: Class Basic.BCDataTable
// Size: 0xB0 (Inherited: 0x28)
struct UBCDataTable : UObject
{
	struct UScriptStruct* BigRowStruct; // 0x28(0x8)
	uint8_t Pad_0x30[0x68]; // 0x30(0x68)
	struct UUAEDataTable* FixedTable; // 0x98(0x8)
	uint8_t Pad_0xA0[0x10]; // 0xA0(0x10)
};

// Object: Class Basic.BlueprintFunctionOverride
// Size: 0x90 (Inherited: 0x28)
struct UBlueprintFunctionOverride : UBlueprintFunctionLibrary
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString LuaFilePath; // 0x80(0x10)
};

// Object: Class Basic.LuaDataAsset
// Size: 0x98 (Inherited: 0x30)
struct ULuaDataAsset : UDataAsset
{
	uint8_t Pad_0x30[0x58]; // 0x30(0x58)
	struct FString LuaFilePath; // 0x88(0x10)
};

// Object: Class Basic.BPClassManager
// Size: 0x1F8 (Inherited: 0x98)
struct UBPClassManager : ULuaDataAsset
{
	struct TArray<struct FBPClassItem> BPClassList; // 0x98(0x10)
	struct TMap<struct UObject*, struct UClass*> BPClassLookUp; // 0xA8(0x50)
	struct TMap<struct UObject*, struct FBPClassItemMap> BPClassLookUpOverride; // 0xF8(0x50)
	struct TMap<struct FString, struct UClass*> BPClassNameLookUp; // 0x148(0x50)
	struct TMap<struct FString, struct FBPClassItemMap> BPClassNameLookUpOverride; // 0x198(0x50)
	struct FString BPClassManagerPath; // 0x1E8(0x10)


	// Object: Function Basic.BPClassManager.ModifyClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426d018
	// Params: [ Num(3) Size(0x28) ]
	void ModifyClass(struct UObject* InNativeClass, struct FString BPClassPath, struct FString ModTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1041E72BC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function Basic.BPClassManager.GetUClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426cf8c
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetUClass(int KeyIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041E72B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x1041E72BC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function Basic.BPClassManager.GetBPClassOverrideByName
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10426ce88
	// Params: [ Num(3) Size(0x28) ]
	struct UObject* GetBPClassOverrideByName(struct FString ClassTagName, struct FString ModTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041E72B4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.BPClassManager.GetBPClassOverride
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10426cd9c
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* GetBPClassOverride(struct UObject* InNativeClass, struct FString ModTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.BPClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10426cd68
	// Params: [ Num(1) Size(0x8) ]
	struct UBPClassManager* Get();
	// [Call #1] RVA: 0x1041E63C8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
};

// Object: Class Basic.BudgetSchedulerSettings
// Size: 0x48 (Inherited: 0x38)
struct UBudgetSchedulerSettings : UDeveloperSettings
{
	struct TArray<struct FBudgetSchedulerChannelConfig> Channels; // 0x38(0x10)
};

// Object: Class Basic.BuffConfigSubsystem
// Size: 0x1B0 (Inherited: 0x30)
struct UBuffConfigSubsystem : UBattleSubsystem
{
	uint8_t Pad_0x30[0x20]; // 0x30(0x20)
	struct TMap<struct FString, struct UObject*> BuffClassMap; // 0x50(0x50)
	uint8_t Pad_0xA0[0x110]; // 0xA0(0x110)


	// Object: Function Basic.BuffConfigSubsystem.ReloadTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426d7a0
	// Params: [ Num(1) Size(0x8) ]
	void ReloadTable(struct UWorld* World);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104190074
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870

	// Object: Function Basic.BuffConfigSubsystem.ClearTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10426d78c
	// Params: [ Num(0) Size(0x0) ]
	void ClearTable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104190074
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870
};

// Object: Class Basic.BuffNodeLuaInterface
// Size: 0x28 (Inherited: 0x28)
struct IBuffNodeLuaInterface : IInterface
{
};

// Object: Class Basic.BuffUtils
// Size: 0x28 (Inherited: 0x28)
struct UBuffUtils : UBlueprintFunctionLibrary
{

	// Object: Function Basic.BuffUtils.IsRoleOK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10426dacc
	// Params: [ Num(3) Size(0x11) ]
	bool IsRoleOK(uint8_t EnabledRole, struct UActorComponent* OwnerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104193300
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10426DDF8
};

// Object: Class Basic.DelayReplicationInterface
// Size: 0x28 (Inherited: 0x28)
struct IDelayReplicationInterface : IInterface
{

	// Object: Function Basic.DelayReplicationInterface.ReSendRPCAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426dd0c
	// Params: [ Num(0) Size(0x0) ]
	void ReSendRPCAfterBeginPlay();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function Basic.DelayReplicationInterface.ReCallRepAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426dcf0
	// Params: [ Num(0) Size(0x0) ]
	void ReCallRepAfterBeginPlay();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
};

// Object: Class Basic.PathCompressionRef
// Size: 0x78 (Inherited: 0x30)
struct UPathCompressionRef : UDataAsset
{
	struct TArray<struct FName> NodeNames; // 0x30(0x10)
	struct TArray<uint32_t> ParentIndices; // 0x40(0x10)
	struct FString Dict; // 0x50(0x10)
	struct FSoftObjectPath DataTableRef; // 0x60(0x18)
};

// Object: Class Basic.GameModeEnvInterface
// Size: 0x28 (Inherited: 0x28)
struct IGameModeEnvInterface : IInterface
{
};

// Object: Class Basic.GameModeEnvUtil
// Size: 0x28 (Inherited: 0x28)
struct UGameModeEnvUtil : UBlueprintFunctionLibrary
{

	// Object: Function Basic.GameModeEnvUtil.GetModeID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10426e298
	// Params: [ Num(2) Size(0x14) ]
	int GetModeID(struct FString GameModeClassPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1041EC114
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10508F76C

	// Object: Function Basic.GameModeEnvUtil.GetGameModeEnvData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10426e1a0
	// Params: [ Num(3) Size(0x59) ]
	bool GetGameModeEnvData(int InModeID, struct FGameModeEnvData& OutData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EB9A8
	// [Call #6] RVA: 0x10423C468
	// [Call #7] RVA: 0x10423C468
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1041EC114
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C
};

// Object: Class Basic.StackModifyAttrInterface
// Size: 0x28 (Inherited: 0x28)
struct IStackModifyAttrInterface : IInterface
{

	// Object: Function Basic.StackModifyAttrInterface.PushVectorModify
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104271388
	// Params: [ Num(3) Size(0x1C) ]
	void PushVectorModify(int ModifyKey, struct FName PropertyName, struct FVector& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.StackModifyAttrInterface.PushVector4Modify
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104271274
	// Params: [ Num(3) Size(0x20) ]
	void PushVector4Modify(int ModifyKey, struct FName PropertyName, struct FVector4& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.StackModifyAttrInterface.PushVector2DModify
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10427117c
	// Params: [ Num(3) Size(0x18) ]
	void PushVector2DModify(int ModifyKey, struct FName PropertyName, struct FVector2D InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.PushTransformModify
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104271058
	// Params: [ Num(3) Size(0x40) ]
	void PushTransformModify(int ModifyKey, struct FName PropertyName, struct FTransform& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.PushStringModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104270f40
	// Params: [ Num(3) Size(0x20) ]
	void PushStringModify(int ModifyKey, struct FName PropertyName, struct FString InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushRotatorModify
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104270e38
	// Params: [ Num(3) Size(0x1C) ]
	void PushRotatorModify(int ModifyKey, struct FName PropertyName, struct FRotator& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.PushQuatModify
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104270d30
	// Params: [ Num(3) Size(0x20) ]
	void PushQuatModify(int ModifyKey, struct FName PropertyName, struct FQuat& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.PushNameModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104270c38
	// Params: [ Num(3) Size(0x18) ]
	void PushNameModify(int ModifyKey, struct FName PropertyName, struct FName InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushLinearColorModify
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104270b3c
	// Params: [ Num(3) Size(0x20) ]
	void PushLinearColorModify(int ModifyKey, struct FName PropertyName, struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushIntVectorModify
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104270a40
	// Params: [ Num(3) Size(0x1C) ]
	void PushIntVectorModify(int ModifyKey, struct FName PropertyName, struct FIntVector InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushIntPointModify
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10427094c
	// Params: [ Num(3) Size(0x18) ]
	void PushIntPointModify(int ModifyKey, struct FName PropertyName, struct FIntPoint InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushInt32Modify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104270850
	// Params: [ Num(3) Size(0x14) ]
	void PushInt32Modify(int ModifyKey, struct FName PropertyName, int InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushFloatModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104270754
	// Params: [ Num(3) Size(0x14) ]
	void PushFloatModify(int ModifyKey, struct FName PropertyName, float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushColorModify
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10427065c
	// Params: [ Num(3) Size(0x14) ]
	void PushColorModify(int ModifyKey, struct FName PropertyName, struct FColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushByteModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104270560
	// Params: [ Num(3) Size(0x11) ]
	void PushByteModify(int ModifyKey, struct FName PropertyName, uint8_t InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PushBoolModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427045c
	// Params: [ Num(3) Size(0x11) ]
	void PushBoolModify(int ModifyKey, struct FName PropertyName, bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.PopStackModifyAttr
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427038c
	// Params: [ Num(3) Size(0x11) ]
	bool PopStackModifyAttr(int ModifyKey, struct FName PropertyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.HasStackModify
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042702f8
	// Params: [ Num(2) Size(0x9) ]
	bool HasStackModify(struct FName PropertyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedVector4
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104270218
	// Params: [ Num(3) Size(0x30) ]
	struct FVector4 GetModifiedVector4(struct FName PropertyName, struct FVector4 OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedVector2D
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10427014c
	// Params: [ Num(3) Size(0x18) ]
	struct FVector2D GetModifiedVector2D(struct FName PropertyName, struct FVector2D OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedVector
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104270078
	// Params: [ Num(3) Size(0x20) ]
	struct FVector GetModifiedVector(struct FName PropertyName, struct FVector OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedTransform
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426ff70
	// Params: [ Num(3) Size(0x70) ]
	struct FTransform GetModifiedTransform(struct FName PropertyName, struct FTransform OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedString
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426fe10
	// Params: [ Num(3) Size(0x28) ]
	struct FString GetModifiedString(struct FName PropertyName, struct FString OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedRotator
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426fd3c
	// Params: [ Num(3) Size(0x20) ]
	struct FRotator GetModifiedRotator(struct FName PropertyName, struct FRotator OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedQuat
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426fc60
	// Params: [ Num(3) Size(0x30) ]
	struct FQuat GetModifiedQuat(struct FName PropertyName, struct FQuat OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedName
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426fb94
	// Params: [ Num(3) Size(0x18) ]
	struct FName GetModifiedName(struct FName PropertyName, struct FName OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedLinearColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426fac0
	// Params: [ Num(3) Size(0x28) ]
	struct FLinearColor GetModifiedLinearColor(struct FName PropertyName, struct FLinearColor OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedIntVector
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426f9e8
	// Params: [ Num(3) Size(0x20) ]
	struct FIntVector GetModifiedIntVector(struct FName PropertyName, struct FIntVector OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedIntPoint
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426f920
	// Params: [ Num(3) Size(0x18) ]
	struct FIntPoint GetModifiedIntPoint(struct FName PropertyName, struct FIntPoint OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedInt32
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426f850
	// Params: [ Num(3) Size(0x10) ]
	int GetModifiedInt32(struct FName PropertyName, int OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedFloat
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426f780
	// Params: [ Num(3) Size(0x10) ]
	float GetModifiedFloat(struct FName PropertyName, float OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10426f6b4
	// Params: [ Num(3) Size(0x10) ]
	struct FColor GetModifiedColor(struct FName PropertyName, struct FColor OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedByte
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426f5e4
	// Params: [ Num(3) Size(0xA) ]
	uint8_t GetModifiedByte(struct FName PropertyName, uint8_t OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.StackModifyAttrInterface.GetModifiedBool
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10426f50c
	// Params: [ Num(3) Size(0xA) ]
	bool GetModifiedBool(struct FName PropertyName, bool OriginalValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class Basic.ItemContainerInterface
// Size: 0x28 (Inherited: 0x28)
struct IItemContainerInterface : IInterface
{

	// Object: Function Basic.ItemContainerInterface.GetOwningObject
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104273318
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetOwningObject();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Basic.ItemContainerInterface.GetItemHandleListByDefineID
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104273248
	// Params: [ Num(2) Size(0x28) ]
	struct TArray<struct UItemHandleBase*> GetItemHandleListByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041F0E90
	// [Call #5] RVA: 0x10282C770
	// [Call #6] RVA: 0x10282C770
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.ItemContainerInterface.GetItemHandleByDefineID
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1042731a0
	// Params: [ Num(2) Size(0x20) ]
	struct UItemHandleBase* GetItemHandleByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041F0E90
	// [Call #8] RVA: 0x10282C770
	// [Call #9] RVA: 0x10282C770
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Basic.ItemContainerInterface.GetItemDefineIDList
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104273134
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FItemDefineID> GetItemDefineIDList();
	// [Call #1] RVA: 0x1041717A8
	// [Call #2] RVA: 0x10282C7A0
	// [Call #3] RVA: 0x10282C7A0
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041F0E90
	// [Call #12] RVA: 0x10282C770
	// [Call #13] RVA: 0x10282C770
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.ItemContainerInterface.GetFirstItemDefineBySpecificID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104273090
	// Params: [ Num(2) Size(0x20) ]
	struct FItemDefineID GetFirstItemDefineBySpecificID(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041717A8
	// [Call #4] RVA: 0x10282C7A0
	// [Call #5] RVA: 0x10282C7A0
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041F0E90
};

// Object: Class Basic.ItemContainerOwnerInterface
// Size: 0x28 (Inherited: 0x28)
struct IItemContainerOwnerInterface : IInterface
{

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyUpdateCustomAccessoriesData
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104273a48
	// Params: [ Num(4) Size(0xD) ]
	void NotifyUpdateCustomAccessoriesData(int WeaponItemId, int Index, int ItemId, bool bIsSetOrRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyUpdateCapacity
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104273918
	// Params: [ Num(4) Size(0x10) ]
	void NotifyUpdateCapacity(float InBackPackCapacity, float InOccupiedCapacity, float InSafetyBoxCapacity, float InSafetyBoxOccupiedCapacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyItemUpdated
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104273808
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemUpdated(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyItemRemoved
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1042736f8
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemRemoved(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E55E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E56B0
	// [Call #17] RVA: 0x1041E56B0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyItemEmpty
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1042736dc
	// Params: [ Num(0) Size(0x0) ]
	void NotifyItemEmpty();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E55E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E56B0
	// [Call #17] RVA: 0x1041E56B0
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.ItemContainerOwnerInterface.NotifyItemAdded
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1042735cc
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemAdded(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E55E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E56B0
	// [Call #17] RVA: 0x1041E56B0
	// [Call #18] RVA: 0x106C8459C
};

// Object: Class Basic.ItemFactoryInterface
// Size: 0x28 (Inherited: 0x28)
struct IItemFactoryInterface : IInterface
{
};

// Object: Class Basic.LuaAsyncTasksSubsystem
// Size: 0x38 (Inherited: 0x30)
struct ULuaAsyncTasksSubsystem : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)


	// Object: Function Basic.LuaAsyncTasksSubsystem.IsNeedClear
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1042793c8
	// Params: [ Num(4) Size(0x29) ]
	bool IsNeedClear(float ClearMemorySize, float ClearArrayObjectSize, struct FSluaBPVar& Callback);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021DB640
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A58BC
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class Basic.LuaAsyncTaskSubsystem
// Size: 0x38 (Inherited: 0x30)
struct ULuaAsyncTaskSubsystem : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)


	// Object: Function Basic.LuaAsyncTaskSubsystem.IsNeedClear
	// Flags: [Final|Native|Public]
	// Offset: 0x104279668
	// Params: [ Num(3) Size(0x29) ]
	bool IsNeedClear(struct UFrontendHUD* FrontendHUD, struct FSluaBPVar Callback);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021DB640
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10217475C
	// [Call #7] RVA: 0x1041A62CC
	// [Call #8] RVA: 0x1021DB65C
	// [Call #9] RVA: 0x1021DB65C
	// [Call #10] RVA: 0x1021DB65C
	// [Call #11] RVA: 0x1021DB65C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10508F76C
};

// Object: Class Basic.LuaEventBridgeFunction
// Size: 0x28 (Inherited: 0x28)
struct ULuaEventBridgeFunction : UBlueprintFunctionLibrary
{

	// Object: Function Basic.LuaEventBridgeFunction.UnRegisterEventByTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10427a15c
	// Params: [ Num(1) Size(0x8) ]
	void UnRegisterEventByTarget(struct UObject* ObjContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A871C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10427AA88

	// Object: Function Basic.LuaEventBridgeFunction.UnRegisterEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104279ff8
	// Params: [ Num(4) Size(0x2C) ]
	void UnRegisterEvent(struct FString FEventType, struct FString EventID, struct UObject* ObjContext, int EventHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A8314
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041A871C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function Basic.LuaEventBridgeFunction.RegistEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104279e78
	// Params: [ Num(5) Size(0x3C) ]
	int RegistEvent(struct FString EventType, struct FString EventID, struct UObject* ObjContext, struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A76B8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
};

// Object: Class Basic.LuaEventBridge
// Size: 0x158 (Inherited: 0x28)
struct ULuaEventBridge : UObject
{
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // 0x28(0x8)
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
	struct TMap<struct FString, struct FEventTypeContainer> RegisterEventMap; // 0x38(0x50)
	struct TMap<struct FString, struct FLuaEventTypeContainer> LuaRegisterEventMap; // 0x88(0x50)
	struct TMap<uint32_t, struct FLuaEventTypeToIDSet> FilterKeyRegisterMap; // 0xD8(0x50)
	struct TArray<struct ULuaTemBPData*> CurrentParamArray; // 0x128(0x10)
	struct TArray<struct UProperty*> Params; // 0x138(0x10)
	uint8_t Pad_0x148[0x10]; // 0x148(0x10)


	// Object: Function Basic.LuaEventBridge.SyncLuaRegisterEventNum
	// Flags: [Final|Native|Public]
	// Offset: 0x10427a79c
	// Params: [ Num(3) Size(0x24) ]
	void SyncLuaRegisterEventNum(struct FString EventType, struct FString EventID, int Number);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041A9498
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Basic.LuaEventBridge.GetCurrentParam
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10427a764
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct ULuaTemBPData*> GetCurrentParam();
	// [Call #1] RVA: 0x1041AA20C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A9498
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function Basic.LuaEventBridge.DeactivateEventsByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10427a6d8
	// Params: [ Num(1) Size(0x4) ]
	void DeactivateEventsByFilterKey(uint32_t& FilterKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A9684
	// [Call #4] RVA: 0x1041AA20C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041A9498
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C

	// Object: Function Basic.LuaEventBridge.CheckNeedPostEventWithFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10427a544
	// Params: [ Num(5) Size(0x2A) ]
	bool CheckNeedPostEventWithFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventID, bool bCheckNeedPostLua);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A96D4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041A9684
	// [Call #18] RVA: 0x1041AA20C

	// Object: Function Basic.LuaEventBridge.ActiveEventByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10427a3b8
	// Params: [ Num(4) Size(0x29) ]
	void ActiveEventByFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventID, bool bActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A95B4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class Basic.LuaEventSubsystem
// Size: 0x170 (Inherited: 0x30)
struct ULuaEventSubsystem : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0x80]; // 0x30(0x80)
	struct TArray<struct ULuaTemBPData*> CurrentParamArray; // 0xB0(0x10)
	uint8_t Pad_0xC0[0xA0]; // 0xC0(0xA0)
	struct FName LastEventTriggerObjectName; // 0x160(0x8)
	struct FName LastEventTriggerFunctionName; // 0x168(0x8)


	// Object: Function Basic.LuaEventSubsystem.UnRegistEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10427af30
	// Params: [ Num(1) Size(0x4) ]
	void UnRegistEvent(int EventHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A83B0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function Basic.LuaEventSubsystem.SetBridgeFunction
	// Flags: [Final|Native|Public]
	// Offset: 0x10427ace8
	// Params: [ Num(4) Size(0x80) ]
	void SetBridgeFunction(struct FSluaBPVar OnRegistEvent, struct FSluaBPVar OnUnRegistEvent, struct FSluaBPVar OnPostEvent, struct FSluaBPVar OnPostBlueprintEvent);
	// [Call #1] RVA: 0x1021DB640
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1021DB640
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1021DB640
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1021DB640
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10217475C
	// [Call #14] RVA: 0x10217475C
	// [Call #15] RVA: 0x10217475C
	// [Call #16] RVA: 0x10217475C
	// [Call #17] RVA: 0x1041AA9EC
	// [Call #18] RVA: 0x1021DB65C
	// [Call #19] RVA: 0x1021DB65C
	// [Call #20] RVA: 0x1021DB65C
	// [Call #21] RVA: 0x1021DB65C
	// [Call #22] RVA: 0x1021DB65C
	// [Call #23] RVA: 0x1021DB65C
	// [Call #24] RVA: 0x1021DB65C
	// [Call #25] RVA: 0x1021DB65C
	// [Call #26] RVA: 0x1021DB65C
	// [Call #27] RVA: 0x1021DB65C
	// [Call #28] RVA: 0x1021DB65C
	// [Call #29] RVA: 0x1021DB65C
	// [Call #30] RVA: 0x1021DB65C
	// [Call #31] RVA: 0x1021DB65C
	// [Call #32] RVA: 0x1021DB65C
	// [Call #33] RVA: 0x1021DB65C
	// [Call #34] RVA: 0x106C8459C

	// Object: Function Basic.LuaEventSubsystem.RegistEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10427ab58
	// Params: [ Num(5) Size(0x3C) ]
	int RegistEvent(struct FString EventID, struct FString EventType, struct UObject* Object, struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A7768
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1021DB640
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1021DB640
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1021DB640
	// [Call #24] RVA: 0x10516D168
};

// Object: Class Basic.ModTable
// Size: 0x120 (Inherited: 0x28)
struct UModTable : UObject
{
	uint8_t Pad_0x28[0xF8]; // 0x28(0xF8)
};

// Object: Class Basic.NetRelevancyGroup
// Size: 0x60 (Inherited: 0x28)
struct UNetRelevancyGroup : UObject
{
	struct FNetRelevancyGroupID GroupID; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct UUAENetConnection*> Connections; // 0x30(0x10)
	uint8_t Pad_0x40[0x20]; // 0x40(0x20)
};

// Object: Class Basic.OnlyActorCompManagerComponent
// Size: 0x1D8 (Inherited: 0x178)
struct UOnlyActorCompManagerComponent : UActorComponent
{
	struct TMap<struct FString, struct UOnlyActorComponent*> CacheComponents; // 0x178(0x50)
	struct TArray<struct UOnlyActorComponent*> CacheUpdateComponents; // 0x1C8(0x10)
};

// Object: Class Basic.OnlyActorComponentManagerInterface
// Size: 0x28 (Inherited: 0x28)
struct IOnlyActorComponentManagerInterface : IInterface
{
};

// Object: Class Basic.OwnerRelevancyDependencyInterface
// Size: 0x28 (Inherited: 0x28)
struct IOwnerRelevancyDependencyInterface : IInterface
{
};

// Object: Class Basic.PlayerActorChannelEx
// Size: 0x580 (Inherited: 0x580)
struct UPlayerActorChannelEx : UActorChannel
{
};

// Object: Class Basic.PlayerReliableSequentialSyncActorChannel
// Size: 0x580 (Inherited: 0x580)
struct UPlayerReliableSequentialSyncActorChannel : UPlayerActorChannelEx
{
};

// Object: Class Basic.RenderFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct URenderFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Basic.RenderFunctionLibrary.MarkComponentRenderStateDirty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10427be0c
	// Params: [ Num(1) Size(0x8) ]
	void MarkComponentRenderStateDirty(struct UActorComponent* Comp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425987C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870
};

// Object: Class Basic.RepPropertyModOptim
// Size: 0x88 (Inherited: 0x28)
struct URepPropertyModOptim : UObject
{
	uint8_t Pad_0x28[0x60]; // 0x28(0x60)
};

// Object: Class Basic.STBaseBuffCarrierInterface
// Size: 0x28 (Inherited: 0x28)
struct ISTBaseBuffCarrierInterface : IInterface
{

	// Object: Function Basic.STBaseBuffCarrierInterface.SetEndTime
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c988
	// Params: [ Num(3) Size(0x9) ]
	bool SetEndTime(int InstID, float EndTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.STBaseBuffCarrierInterface.RemoveBuffBySkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c880
	// Params: [ Num(4) Size(0x11) ]
	bool RemoveBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Basic.STBaseBuffCarrierInterface.RemoveBuffByID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c73c
	// Params: [ Num(5) Size(0x19) ]
	bool RemoveBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.HasSkillID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c6a8
	// Params: [ Num(2) Size(0x5) ]
	bool HasSkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.STBaseBuffCarrierInterface.HasBuffID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c614
	// Params: [ Num(2) Size(0x5) ]
	bool HasBuffID(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.GetBuffIDsBySkillID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c578
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<int> GetBuffIDsBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.GetBuffDuration
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c4ac
	// Params: [ Num(3) Size(0xC) ]
	float GetBuffDuration(int InstID, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10207FA04
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.GetBuffComponent
	// Flags: [Native|Public|Const]
	// Offset: 0x10427c470
	// Params: [ Num(1) Size(0x8) ]
	struct USTBuffSystemComponent* GetBuffComponent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10207FA04
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.ChangeBuffDuration
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c3a0
	// Params: [ Num(3) Size(0x9) ]
	bool ChangeBuffDuration(int InstID, float Duration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.AddBuffBySkill
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c25c
	// Params: [ Num(5) Size(0x15) ]
	bool AddBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer, int Level);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.STBaseBuffCarrierInterface.AddBuffByID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427c0dc
	// Params: [ Num(6) Size(0x20) ]
	int AddBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID, int Level);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class Basic.STBuff
// Size: 0x150 (Inherited: 0x28)
struct USTBuff : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
	int BuffID; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString BuffName; // 0x48(0x10)
	struct FString Desc; // 0x58(0x10)
	int LayerMax; // 0x68(0x4)
	float Duration; // 0x6C(0x4)
	float ClientSyncInterval; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct TArray<float> CDConfigArray; // 0x78(0x10)
	bool bNeedSyncCD; // 0x88(0x1)
	uint8_t ClientSyncType; // 0x89(0x1)
	uint8_t TargetType; // 0x8A(0x1)
	uint8_t RefreshType; // 0x8B(0x1)
	uint8_t ReActionType; // 0x8C(0x1)
	uint8_t MultiCauserHandleType; // 0x8D(0x1)
	uint8_t MultiSkillHandleType; // 0x8E(0x1)
	bool IsExecuteOnece; // 0x8F(0x1)
	bool RemoveAllLayer; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct TArray<struct USTBuffTriggerBase*> TriggerBases; // 0x98(0x10)
	struct TArray<struct USTBuffCheckConditionWrapper*> Conditions; // 0xA8(0x10)
	struct TArray<struct USTBuffAction*> Actions; // 0xB8(0x10)
	uint8_t NeedShowBuffTypeInBuffList; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x3]; // 0xC9(0x3)
	int LocalizeDescID; // 0xCC(0x4)
	struct FString IconPath; // 0xD0(0x10)
	bool IsClientOwnLife; // 0xE0(0x1)
	bool ExistForever; // 0xE1(0x1)
	uint8_t Pad_0xE2[0x2]; // 0xE2(0x2)
	int TipsOnAddBuff; // 0xE4(0x4)
	struct FString TimeFormula; // 0xE8(0x10)
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // 0xF8(0x50)
	int InstancedNodesTotalSize; // 0x148(0x4)
	uint8_t Pad_0x14C[0x4]; // 0x14C(0x4)


	// Object: Function Basic.STBuff.Tick
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10427d330
	// Params: [ Num(5) Size(0x28) ]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime, float TimeSeconds, struct TArray<int>& TickActionList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10419533C
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Basic.STBuff.ResetActionExecute
	// Flags: [Final|Native|Public]
	// Offset: 0x10427d278
	// Params: [ Num(2) Size(0xC) ]
	void ResetActionExecute(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196280
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10419533C
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x101F8BA44
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.STBuff.OnCreate
	// Flags: [Final|Native|Public]
	// Offset: 0x10427d1c0
	// Params: [ Num(2) Size(0xC) ]
	void OnCreate(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195BC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104196280
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.STBuff.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10427d108
	// Params: [ Num(2) Size(0xC) ]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194E98
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195BC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104196280

	// Object: Function Basic.STBuff.InitBuffAction
	// Flags: [Final|Native|Public]
	// Offset: 0x10427d0f4
	// Params: [ Num(0) Size(0x0) ]
	void InitBuffAction();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194E98
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195BC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104196280

	// Object: Function Basic.STBuff.End
	// Flags: [Final|Native|Public]
	// Offset: 0x10427d03c
	// Params: [ Num(2) Size(0xC) ]
	void End(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041958D4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104194E98
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195BC8

	// Object: Function Basic.STBuff.Destroy
	// Flags: [Final|Native|Public]
	// Offset: 0x10427cf84
	// Params: [ Num(2) Size(0xC) ]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195F94
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041958D4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104194E98

	// Object: Function Basic.STBuff.ChangeNotify
	// Flags: [Final|Native|Public]
	// Offset: 0x10427cebc
	// Params: [ Num(3) Size(0xD) ]
	bool ChangeNotify(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196810
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195F94
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041958D4
};

// Object: Class Basic.STBuffNodeInstanceData
// Size: 0x58 (Inherited: 0x28)
struct USTBuffNodeInstanceData : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
	struct UActorComponent* CurOwnerActorComponent; // 0x40(0x8)
	int CurInstID; // 0x48(0x4)
	struct TWeakObjectPtr<struct USTBuff> OwnerBuff; // 0x4C(0x8)
	int ArrayIndex; // 0x54(0x4)


	// Object: Function Basic.STBuffNodeInstanceData.GetBuffInstLevel
	// Flags: [Final|Native|Public]
	// Offset: 0x104286dcc
	// Params: [ Num(1) Size(0x4) ]
	int GetBuffInstLevel();
	// [Call #1] RVA: 0x10419C2A4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10425E1E0
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0
	// [Call #8] RVA: 0x10425E1E0
	// [Call #9] RVA: 0x105184F34
};

// Object: Class Basic.STBuffAction
// Size: 0xA8 (Inherited: 0x58)
struct USTBuffAction : USTBuffNodeInstanceData
{
	uint8_t Pad_0x58[0x8]; // 0x58(0x8)
	uint8_t ActionRole; // 0x60(0x1)
	uint8_t Pad_0x61[0x3]; // 0x61(0x3)
	float ExecuteDelay; // 0x64(0x4)
	struct TArray<struct FBuffCheckConditionWrapperItem> ConditionSettings; // 0x68(0x10)
	struct TArray<struct FBuffTriggerWrapperItem> TriggerSettings; // 0x78(0x10)
	bool bEnableTick; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	float Interval; // 0x8C(0x4)
	float FirstTickStartTime; // 0x90(0x4)
	bool bTickByPeriod; // 0x94(0x1)
	bool AutoEnabled; // 0x95(0x1)
	uint8_t Pad_0x96[0x2]; // 0x96(0x2)
	struct TArray<struct UObject*> CacheSoftObject; // 0x98(0x10)


	// Object: Function Basic.STBuffAction.ToString
	// Flags: [Native|Public]
	// Offset: 0x10427e700
	// Params: [ Num(1) Size(0x10) ]
	struct FString ToString();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction.Tick2
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e60c
	// Params: [ Num(3) Size(0x10) ]
	void Tick2(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104195600
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction.Tick
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e518
	// Params: [ Num(3) Size(0x10) ]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104195758
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104195600
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.STBuffAction.SetEnabled
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e420
	// Params: [ Num(3) Size(0xD) ]
	void SetEnabled(struct UActorComponent* BuffSystemComponent, int InstID, bool Enabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041972BC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104195758
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.STBuffAction.ResetExecute
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e328
	// Params: [ Num(3) Size(0xD) ]
	void ResetExecute(struct UActorComponent* BuffSystemComponent, int InstID, bool IgnoreEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041965E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041972BC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.OnTick
	// Flags: [Native|Protected]
	// Offset: 0x10427e2a4
	// Params: [ Num(1) Size(0x4) ]
	void OnTick(float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041965E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.OnResetExecute
	// Flags: [Native|Protected]
	// Offset: 0x10427e218
	// Params: [ Num(1) Size(0x1) ]
	void OnResetExecute(bool IgnoreEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041965E4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x10427e1fc
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041965E4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Basic.STBuffAction.OnExecute
	// Flags: [Native|Protected]
	// Offset: 0x10427e1e0
	// Params: [ Num(0) Size(0x0) ]
	void OnExecute();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041965E4

	// Object: Function Basic.STBuffAction.OnEnd
	// Flags: [Native|Protected]
	// Offset: 0x10427e1c4
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041965E4

	// Object: Function Basic.STBuffAction.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x10427e1a8
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.OnCheckLinkActionEnabled
	// Flags: [Native|Protected]
	// Offset: 0x10427e18c
	// Params: [ Num(0) Size(0x0) ]
	void OnCheckLinkActionEnabled();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function Basic.STBuffAction.OnChangeNotify
	// Flags: [Native|Protected]
	// Offset: 0x10427e170
	// Params: [ Num(0) Size(0x0) ]
	void OnChangeNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.OnAsyncLoadSoftPathDone
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427e15c
	// Params: [ Num(0) Size(0x0) ]
	void OnAsyncLoadSoftPathDone();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.IsRoleOK
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e0d0
	// Params: [ Num(2) Size(0x9) ]
	bool IsRoleOK(struct UActorComponent* OwnerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104196CD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10427e018
	// Params: [ Num(2) Size(0xC) ]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041950D0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104196CD4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffAction.GetRealOwnerRole
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427dfdc
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRole();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041950D0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104196CD4

	// Object: Function Basic.STBuffAction.GetOwner
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427dfa8
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwner();
	// [Call #1] RVA: 0x104197350
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041950D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104196CD4

	// Object: Function Basic.STBuffAction.GetCauser
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427df74
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetCauser();
	// [Call #1] RVA: 0x104197394
	// [Call #2] RVA: 0x104197350
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041950D0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104196CD4

	// Object: Function Basic.STBuffAction.Execute
	// Flags: [Final|Native|Public]
	// Offset: 0x10427debc
	// Params: [ Num(2) Size(0xC) ]
	void Execute(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195E68
	// [Call #6] RVA: 0x104197394
	// [Call #7] RVA: 0x104197350
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041950D0
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.STBuffAction.End
	// Flags: [Final|Native|Public]
	// Offset: 0x10427de04
	// Params: [ Num(2) Size(0xC) ]
	void End(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195AE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195E68
	// [Call #11] RVA: 0x104197394
	// [Call #12] RVA: 0x104197350
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.STBuffAction.Destroy
	// Flags: [Final|Native|Public]
	// Offset: 0x10427dd4c
	// Params: [ Num(2) Size(0xC) ]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196130
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195AE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195E68
	// [Call #16] RVA: 0x104197394

	// Object: Function Basic.STBuffAction.CheckLinkActionEnabled
	// Flags: [Final|Native|Public]
	// Offset: 0x10427dc94
	// Params: [ Num(2) Size(0xC) ]
	void CheckLinkActionEnabled(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041952E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104196130
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195AE0

	// Object: Function Basic.STBuffAction.ChangeNotify
	// Flags: [Final|Native|Public]
	// Offset: 0x10427dbdc
	// Params: [ Num(2) Size(0xC) ]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419695C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041952E8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104196130
};

// Object: Class Basic.STBuffAction_Lua
// Size: 0x1D0 (Inherited: 0xA8)
struct USTBuffAction_Lua : USTBuffAction
{
	uint8_t Pad_0xA8[0xC0]; // 0xA8(0xC0)
	struct TMap<struct FString, struct FString> ActionParams; // 0x168(0x50)
	bool bEnableLuaPrivateData; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x7]; // 0x1B9(0x7)
	struct FString LuaFilePath; // 0x1C0(0x10)


	// Object: Function Basic.STBuffAction_Lua.ToString
	// Flags: [Native|Public]
	// Offset: 0x10427f054
	// Params: [ Num(1) Size(0x10) ]
	struct FString ToString();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnTick
	// Flags: [Native|Public]
	// Offset: 0x10427efd0
	// Params: [ Num(1) Size(0x4) ]
	void OnTick(float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnInitialize
	// Flags: [Native|Public]
	// Offset: 0x10427efb4
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnExecute
	// Flags: [Native|Public]
	// Offset: 0x10427ef98
	// Params: [ Num(0) Size(0x0) ]
	void OnExecute();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnEnd
	// Flags: [Native|Public]
	// Offset: 0x10427ef7c
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnDestroy
	// Flags: [Native|Public]
	// Offset: 0x10427ef60
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.STBuffAction_Lua.OnChangeNotify
	// Flags: [Native|Public]
	// Offset: 0x10427ef44
	// Params: [ Num(0) Size(0x0) ]
	void OnChangeNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class Basic.STBuffCheckConditionWrapper
// Size: 0x80 (Inherited: 0x58)
struct USTBuffCheckConditionWrapper : USTBuffNodeInstanceData
{
	uint8_t ExecuteRole; // 0x58(0x1)
	uint8_t Pad_0x59[0x7]; // 0x59(0x7)
	struct USTBuffCondition* Condition; // 0x60(0x8)
	float ConditionTickInterval; // 0x68(0x4)
	float Probality; // 0x6C(0x4)
	uint8_t ExecuteTimeType; // 0x70(0x1)
	bool IsDoOnFalse; // 0x71(0x1)
	bool IsNeedTick; // 0x72(0x1)
	bool IsNeedExecute; // 0x73(0x1)
	bool IsSetFalseWhenExecute; // 0x74(0x1)
	uint8_t Pad_0x75[0x3]; // 0x75(0x3)
	float ExecuteDelay; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)


	// Object: Function Basic.STBuffCheckConditionWrapper.Tick
	// Flags: [Final|Native|Public]
	// Offset: 0x10427fae8
	// Params: [ Num(3) Size(0x10) ]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104195518
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.STBuffCheckConditionWrapper.ResetExecute
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f9f0
	// Params: [ Num(3) Size(0xD) ]
	void ResetExecute(struct UActorComponent* BuffSystemComponent, int InstID, bool IgnoreEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10419647C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104195518
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.STBuffCheckConditionWrapper.OnTick
	// Flags: [Native|Protected]
	// Offset: 0x10427f96c
	// Params: [ Num(1) Size(0x4) ]
	void OnTick(float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x10427f950
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x10427f934
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Basic.STBuffCheckConditionWrapper.OnConditionTrue
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427f920
	// Params: [ Num(0) Size(0x0) ]
	void OnConditionTrue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.OnConditionFalse
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427f90c
	// Params: [ Num(0) Size(0x0) ]
	void OnConditionFalse();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Basic.STBuffCheckConditionWrapper.OnChangeNotify
	// Flags: [Native|Protected]
	// Offset: 0x10427f8f0
	// Params: [ Num(0) Size(0x0) ]
	void OnChangeNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419647C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.IsRoleOK
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f864
	// Params: [ Num(2) Size(0x9) ]
	bool IsRoleOK(struct UActorComponent* OwnerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104198758
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.InitLinkActionEnableState
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f7ac
	// Params: [ Num(2) Size(0xC) ]
	void InitLinkActionEnableState(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195200
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104198758
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffCheckConditionWrapper.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f6f4
	// Params: [ Num(2) Size(0xC) ]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195044
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195200
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104198758

	// Object: Function Basic.STBuffCheckConditionWrapper.GetRealOwnerRole
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10427f6b8
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRole();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195044
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195200
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104198758

	// Object: Function Basic.STBuffCheckConditionWrapper.Execute
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f600
	// Params: [ Num(2) Size(0xC) ]
	void Execute(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195DAC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195044
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195200

	// Object: Function Basic.STBuffCheckConditionWrapper.End
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f548
	// Params: [ Num(2) Size(0xC) ]
	void End(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195A24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195DAC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195044

	// Object: Function Basic.STBuffCheckConditionWrapper.Destroy
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f490
	// Params: [ Num(2) Size(0xC) ]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041960B0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195A24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195DAC

	// Object: Function Basic.STBuffCheckConditionWrapper.CheckCondition
	// Flags: [Final|Native|Protected]
	// Offset: 0x10427f47c
	// Params: [ Num(0) Size(0x0) ]
	void CheckCondition();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041960B0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195A24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195DAC

	// Object: Function Basic.STBuffCheckConditionWrapper.ChangeNotify
	// Flags: [Final|Native|Public]
	// Offset: 0x10427f3c4
	// Params: [ Num(2) Size(0xC) ]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041968C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041960B0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104195A24
};

// Object: Class Basic.STBuffCondition
// Size: 0x58 (Inherited: 0x28)
struct USTBuffCondition : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
	uint8_t AndOrPrev; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
	struct USTBuffNodeInstanceData* OwnerInstanceData; // 0x50(0x8)


	// Object: Function Basic.STBuffCondition.OnResetExecute
	// Flags: [Native|Protected]
	// Offset: 0x104280370
	// Params: [ Num(1) Size(0x1) ]
	void OnResetExecute(bool IgnoreEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x104280354
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.OnEnd
	// Flags: [Native|Public]
	// Offset: 0x104280338
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x10428031c
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.GetOwner
	// Flags: [Final|Native|Protected]
	// Offset: 0x1042802e8
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwner();
	// [Call #1] RVA: 0x104198FF4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.GetCauser
	// Flags: [Final|Native|Protected]
	// Offset: 0x1042802b4
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetCauser();
	// [Call #1] RVA: 0x104199038
	// [Call #2] RVA: 0x104198FF4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.Copy
	// Flags: [Native|Public]
	// Offset: 0x104280220
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuffCondition* Copy(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104199038
	// [Call #4] RVA: 0x104198FF4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function Basic.STBuffCondition.CheckIsTrue
	// Flags: [Native|Protected]
	// Offset: 0x1042801e4
	// Params: [ Num(1) Size(0x1) ]
	bool CheckIsTrue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104199038
	// [Call #4] RVA: 0x104198FF4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffCondition.ChangeNotify
	// Flags: [Native|Protected]
	// Offset: 0x1042801c8
	// Params: [ Num(0) Size(0x0) ]
	void ChangeNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104199038
	// [Call #4] RVA: 0x104198FF4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
};

// Object: Class Basic.STBuffConditionComplex
// Size: 0x68 (Inherited: 0x58)
struct USTBuffConditionComplex : USTBuffCondition
{
	struct TArray<struct USTBuffCondition*> Conditions; // 0x58(0x10)


	// Object: Function Basic.STBuffConditionComplex.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x10428087c
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x104280D38

	// Object: Function Basic.STBuffConditionComplex.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x104280860
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x104280D38

	// Object: Function Basic.STBuffConditionComplex.Copy
	// Flags: [Native|Public]
	// Offset: 0x1042807cc
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuffCondition* Copy(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionComplex.CheckIsTrue
	// Flags: [Native|Protected]
	// Offset: 0x104280790
	// Params: [ Num(1) Size(0x1) ]
	bool CheckIsTrue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Basic.STBuffConditionNot
// Size: 0x60 (Inherited: 0x58)
struct USTBuffConditionNot : USTBuffCondition
{
	struct USTBuffCondition* Condition; // 0x58(0x8)


	// Object: Function Basic.STBuffConditionNot.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x104280bbc
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10518366C
	// [Call #8] RVA: 0x10518366C

	// Object: Function Basic.STBuffConditionNot.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x104280ba0
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function Basic.STBuffConditionNot.Copy
	// Flags: [Native|Public]
	// Offset: 0x104280b0c
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuffCondition* Copy(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionNot.CheckIsTrue
	// Flags: [Native|Protected]
	// Offset: 0x104280ad0
	// Params: [ Num(1) Size(0x1) ]
	bool CheckIsTrue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Basic.STBuffCondition_Lua
// Size: 0x180 (Inherited: 0x58)
struct USTBuffCondition_Lua : USTBuffCondition
{
	uint8_t Pad_0x58[0xC0]; // 0x58(0xC0)
	struct TMap<struct FString, struct FString> ActionParams; // 0x118(0x50)
	bool bEnableLuaPrivateData; // 0x168(0x1)
	uint8_t Pad_0x169[0x7]; // 0x169(0x7)
	struct FString LuaFilePath; // 0x170(0x10)


	// Object: Function Basic.STBuffCondition_Lua.OnInitialize
	// Flags: [Native|Public]
	// Offset: 0x10428556c
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10425E1E0
	// [Call #7] RVA: 0x105184F34

	// Object: Function Basic.STBuffCondition_Lua.OnDestroy
	// Flags: [Native|Public]
	// Offset: 0x104285550
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10425E1E0
	// [Call #7] RVA: 0x105184F34

	// Object: Function Basic.STBuffCondition_Lua.CheckIsTrue
	// Flags: [Native|Public]
	// Offset: 0x104285514
	// Params: [ Num(1) Size(0x1) ]
	bool CheckIsTrue();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class Basic.STBuffConditionAction
// Size: 0xD0 (Inherited: 0xA8)
struct USTBuffConditionAction : USTBuffAction
{
	struct USTBuffCondition* Condition; // 0xA8(0x8)
	float ConditionTickInterval; // 0xB0(0x4)
	float Probality; // 0xB4(0x4)
	uint8_t ExecuteTimeType; // 0xB8(0x1)
	bool IsDoOnFalse; // 0xB9(0x1)
	bool IsNeedTick; // 0xBA(0x1)
	bool IsNeedExecute; // 0xBB(0x1)
	bool IsSetFalseWhenExecute; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
	struct TArray<struct FBuffConditionActionItem> LinkActions; // 0xC0(0x10)


	// Object: Function Basic.STBuffConditionAction.OnTick
	// Flags: [Native|Protected]
	// Offset: 0x1042859a8
	// Params: [ Num(1) Size(0x4) ]
	void OnTick(float DetalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x10428598c
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x104285970
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.OnConditionTrue
	// Flags: [Final|Native|Protected]
	// Offset: 0x10428595c
	// Params: [ Num(0) Size(0x0) ]
	void OnConditionTrue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.OnConditionFalse
	// Flags: [Final|Native|Protected]
	// Offset: 0x104285948
	// Params: [ Num(0) Size(0x0) ]
	void OnConditionFalse();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.OnChangeNotify
	// Flags: [Native|Protected]
	// Offset: 0x10428592c
	// Params: [ Num(0) Size(0x0) ]
	void OnChangeNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Basic.STBuffConditionAction.CheckCondition
	// Flags: [Final|Native|Protected]
	// Offset: 0x104285918
	// Params: [ Num(0) Size(0x0) ]
	void CheckCondition();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Basic.STBuffEvent
// Size: 0x70 (Inherited: 0x28)
struct USTBuffEvent : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
	struct USTBuffNodeInstanceData* OwnerInstanceData; // 0x48(0x8)
	struct USTBuffEvent* OwnerEvent; // 0x50(0x8)
	uint8_t ExecuteRole; // 0x58(0x1)
	bool bStateEvent; // 0x59(0x1)
	uint8_t Pad_0x5A[0x6]; // 0x5A(0x6)
	struct FString StateSharedKey; // 0x60(0x10)


	// Object: Function Basic.STBuffEvent.TriggerEvent
	// Flags: [Native|Public]
	// Offset: 0x1042861ec
	// Params: [ Num(0) Size(0x0) ]
	void TriggerEvent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.STBuffEvent.ToString
	// Flags: [Native|Public]
	// Offset: 0x104286180
	// Params: [ Num(1) Size(0x10) ]
	struct FString ToString();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffEvent.SetTimer
	// Flags: [Final|Native|Public]
	// Offset: 0x104286040
	// Params: [ Num(4) Size(0x14) ]
	void SetTimer(struct FName FunctionName, float InRate, bool InbLoop, float InFirstDelay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419AE48
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function Basic.STBuffEvent.OnInitialize
	// Flags: [Native|Public]
	// Offset: 0x104286024
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419AE48
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffEvent.OnEnd
	// Flags: [Native|Public]
	// Offset: 0x104286008
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419AE48
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffEvent.OnDestroy
	// Flags: [Native|Public]
	// Offset: 0x104285fec
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10419AE48
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffEvent.IsRoleOK
	// Flags: [Final|Native|Public]
	// Offset: 0x104285f60
	// Params: [ Num(2) Size(0x9) ]
	bool IsRoleOK(struct UActorComponent* OwnerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419A908
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419AE48

	// Object: Function Basic.STBuffEvent.GetRealOwnerRole
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104285f24
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRole();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419A908
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419AE48

	// Object: Function Basic.STBuffEvent.GetOwner
	// Flags: [Final|Native|Public]
	// Offset: 0x104285ef0
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwner();
	// [Call #1] RVA: 0x10419B240
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10419A908
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffEvent.GetCauser
	// Flags: [Final|Native|Public]
	// Offset: 0x104285ebc
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetCauser();
	// [Call #1] RVA: 0x10419B284
	// [Call #2] RVA: 0x10419B240
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419A908
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffEvent.Copy
	// Flags: [Native|Public]
	// Offset: 0x104285e28
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuffEvent* Copy(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419B284
	// [Call #4] RVA: 0x10419B240
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10419A908
	// [Call #8] RVA: 0x10516D168

	// Object: Function Basic.STBuffEvent.ClearTimer
	// Flags: [Final|Native|Public]
	// Offset: 0x104285dac
	// Params: [ Num(1) Size(0x8) ]
	void ClearTimer(struct FName FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419B068
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10419B284
	// [Call #7] RVA: 0x10419B240
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10419A908

	// Object: Function Basic.STBuffEvent.ClearAllTimer
	// Flags: [Final|Native|Public]
	// Offset: 0x104285d98
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllTimer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419B068
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10419B284
	// [Call #7] RVA: 0x10419B240
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10419A908
};

// Object: Class Basic.STBuffEvent_Lua
// Size: 0x198 (Inherited: 0x70)
struct USTBuffEvent_Lua : USTBuffEvent
{
	uint8_t Pad_0x70[0xC0]; // 0x70(0xC0)
	struct TMap<struct FString, struct FString> ActionParams; // 0x130(0x50)
	bool bEnableLuaPrivateData; // 0x180(0x1)
	uint8_t Pad_0x181[0x7]; // 0x181(0x7)
	struct FString LuaFilePath; // 0x188(0x10)


	// Object: Function Basic.STBuffEvent_Lua.ToString
	// Flags: [Native|Public]
	// Offset: 0x104286708
	// Params: [ Num(1) Size(0x10) ]
	struct FString ToString();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x104286B1C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class Basic.STBuffEvent_Multi
// Size: 0x80 (Inherited: 0x70)
struct USTBuffEvent_Multi : USTBuffEvent
{
	struct TArray<struct USTBuffEvent*> Events; // 0x70(0x10)


	// Object: Function Basic.STBuffEvent_Multi.OnInitialize
	// Flags: [Native|Public]
	// Offset: 0x1042869ac
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function Basic.STBuffEvent_Multi.OnEnd
	// Flags: [Native|Public]
	// Offset: 0x104286990
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function Basic.STBuffEvent_Multi.OnDestroy
	// Flags: [Native|Public]
	// Offset: 0x104286974
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function Basic.STBuffEvent_Multi.Copy
	// Flags: [Native|Public]
	// Offset: 0x1042868e0
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuffEvent* Copy(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Basic.STBuffEvent_OnEnd
// Size: 0x70 (Inherited: 0x70)
struct USTBuffEvent_OnEnd : USTBuffEvent
{
};

// Object: Class Basic.STBuffSharedInterface
// Size: 0x28 (Inherited: 0x28)
struct ISTBuffSharedInterface : IInterface
{

	// Object: Function Basic.STBuffSharedInterface.SetVectorShared
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10428889c
	// Params: [ Num(2) Size(0x1C) ]
	void SetVectorShared(struct FString SharedName, struct FVector& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffSharedInterface.SetUInt8Shared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042887bc
	// Params: [ Num(2) Size(0x11) ]
	void SetUInt8Shared(struct FString SharedName, uint8_t InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.STBuffSharedInterface.SetTargetShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1042886b8
	// Params: [ Num(2) Size(0x20) ]
	void SetTargetShared(struct FString SharedName, struct TArray<struct AActor*>& InActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Basic.STBuffSharedInterface.SetStringShared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042885c4
	// Params: [ Num(2) Size(0x20) ]
	void SetStringShared(struct FString SharedName, struct FString InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.SetRotatorShared
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1042884d8
	// Params: [ Num(2) Size(0x1C) ]
	void SetRotatorShared(struct FString SharedName, struct FRotator& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Basic.STBuffSharedInterface.SetNameShared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042883f8
	// Params: [ Num(2) Size(0x18) ]
	void SetNameShared(struct FString SharedName, struct FName InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.SetInt32Shared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104288318
	// Params: [ Num(2) Size(0x14) ]
	void SetInt32Shared(struct FString SharedName, int InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.SetFloatShared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104288238
	// Params: [ Num(2) Size(0x14) ]
	void SetFloatShared(struct FString SharedName, float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.SetBooleanShared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104288150
	// Params: [ Num(2) Size(0x11) ]
	void SetBooleanShared(struct FString SharedName, bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.RemoveShared
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1042880b0
	// Params: [ Num(1) Size(0x10) ]
	void RemoveShared(struct FString SharedName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Basic.STBuffSharedInterface.GetVectorShared
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104287fb4
	// Params: [ Num(3) Size(0x1D) ]
	bool GetVectorShared(struct FString SharedName, struct FVector& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.GetUInt8Shared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287eb4
	// Params: [ Num(3) Size(0x12) ]
	bool GetUInt8Shared(struct FString SharedName, uint8_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.GetTargetShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287da0
	// Params: [ Num(3) Size(0x21) ]
	bool GetTargetShared(struct FString SharedName, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.STBuffSharedInterface.GetStringShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287c8c
	// Params: [ Num(3) Size(0x21) ]
	bool GetStringShared(struct FString SharedName, struct FString& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.STBuffSharedInterface.GetRotatorShared
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104287b90
	// Params: [ Num(3) Size(0x1D) ]
	bool GetRotatorShared(struct FString SharedName, struct FRotator& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Basic.STBuffSharedInterface.GetNameShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287a90
	// Params: [ Num(3) Size(0x19) ]
	bool GetNameShared(struct FString SharedName, struct FName& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.GetInt32Shared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287990
	// Params: [ Num(3) Size(0x15) ]
	bool GetInt32Shared(struct FString SharedName, int& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.GetFloatShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287890
	// Params: [ Num(3) Size(0x15) ]
	bool GetFloatShared(struct FString SharedName, float& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSharedInterface.GetBooleanShared
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104287790
	// Params: [ Num(3) Size(0x12) ]
	bool GetBooleanShared(struct FString SharedName, bool& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class Basic.STBuffSystemComponent
// Size: 0x4A0 (Inherited: 0x178)
struct USTBuffSystemComponent : UActorComponent
{
	uint8_t Pad_0x178[0x8]; // 0x178(0x8)
	float RPCSyncInterval; // 0x180(0x4)
	uint8_t Pad_0x184[0x4]; // 0x184(0x4)
	struct FScriptMulticastDelegate OnClientAddBuffEvent; // 0x188(0x10)
	struct FScriptMulticastDelegate OnClientRemoveBuffEvent; // 0x198(0x10)
	struct FScriptMulticastDelegate OnClientUpdateBuffEvent; // 0x1A8(0x10)
	struct FScriptMulticastDelegate OnAddBuffEvent; // 0x1B8(0x10)
	struct FScriptMulticastDelegate OnRemoveBuffEvent; // 0x1C8(0x10)
	struct FScriptMulticastDelegate OnUpdateBuffEvent; // 0x1D8(0x10)
	struct TMap<int, struct UUAEBlackboard*> BuffBlackboardMap; // 0x1E8(0x50)
	struct FBuffIncNetArray SyncBriefs; // 0x238(0x20)
	struct FBuffIncNetArray SyncRefBriefs; // 0x258(0x20)
	struct FBuffIncNetArray OwnerSyncBriefs; // 0x278(0x20)
	struct FBuffIncNetArray OwnerSyncRefBriefs; // 0x298(0x20)
	struct FBuffIncNetArray DsBuffBriefs; // 0x2B8(0x20)
	struct TSet<int> BriefRemoveInstIds; // 0x2D8(0x50)
	struct TMap<struct FBuffReplaceData, struct FBuffReplaceData> BuffReplaceData; // 0x328(0x50)
	uint8_t Pad_0x378[0x128]; // 0x378(0x128)


	// Object: Function Basic.STBuffSystemComponent.UpdateClientBuff
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10428aa54
	// Params: [ Num(1) Size(0x38) ]
	void UpdateClientBuff(struct FBuffSyncBrief& Brief);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A1768
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.STBuffSystemComponent.SetEndTime
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a98c
	// Params: [ Num(3) Size(0x9) ]
	bool SetEndTime(int InstID, float EndTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194560
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A1768
	// [Call #9] RVA: 0x101F8C2E4
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.STBuffSystemComponent.SetBuffReplaceData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428a8c0
	// Params: [ Num(3) Size(0x11) ]
	bool SetBuffReplaceData(struct FBuffReplaceData From, struct FBuffReplaceData To);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041A27F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104194560
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041A1768
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x101F8C2E4

	// Object: Function Basic.STBuffSystemComponent.RemoveBuffBySkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428a7c0
	// Params: [ Num(4) Size(0x11) ]
	bool RemoveBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10419422C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041A27F4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.RemoveBuff
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a690
	// Params: [ Num(4) Size(0x14) ]
	void RemoveBuff(int BuffID, int LayerCount, struct AActor* Causer, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104193D18
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10419422C

	// Object: Function Basic.STBuffSystemComponent.RemoveAllBuffsWithExcludeArray
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10428a5e8
	// Params: [ Num(1) Size(0x10) ]
	void RemoveAllBuffsWithExcludeArray(struct TArray<int>& InExcludeArry);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419FBBC
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104193D18
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.RemoveAllBuffs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428a564
	// Params: [ Num(1) Size(0x1) ]
	void RemoveAllBuffs(bool bClearAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419FA4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10419FBBC
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104193D18

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnUpdateBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void OnUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.STBuffSystemComponent.OnRep_SyncBriefs
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a550
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SyncBriefs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419FA4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10419FBBC
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSystemComponent.OnRep_OwnerSyncBriefs
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a53c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_OwnerSyncBriefs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419FA4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10419FBBC
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnRemoveBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void OnRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnClientUpdateBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void OnClientUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnClientRemoveBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void OnClientRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnClientAddBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void OnClientAddBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction Basic.STBuffSystemComponent.OnAddBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0x18) ]
	void OnAddBuffEvent__DelegateSignature(int BuffID, int SkillID, bool IsExist, struct AActor* Causer);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.STBuffSystemComponent.IsCDOK
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428a478
	// Params: [ Num(3) Size(0x9) ]
	bool IsCDOK(int InstID, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041A2620
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10419FA4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10419FBBC
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.IsBuffInstExist
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a3ec
	// Params: [ Num(2) Size(0x5) ]
	bool IsBuffInstExist(int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041969F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A2620
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10419FA4C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSystemComponent.HasSkillID
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a360
	// Params: [ Num(2) Size(0x5) ]
	bool HasSkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041947A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041969F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041A2620
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffSystemComponent.HasBuff
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a2d4
	// Params: [ Num(2) Size(0x5) ]
	bool HasBuff(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041946FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041947A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041969F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041A2620

	// Object: Function Basic.STBuffSystemComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a2a0
	// Params: [ Num(1) Size(0x8) ]
	struct UBuffConfigSubsystem* GetSubsystem();
	// [Call #1] RVA: 0x10419E244
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041946FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041947A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041969F0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.GetSTBuffByBuffID
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a214
	// Params: [ Num(2) Size(0x10) ]
	struct USTBuff* GetSTBuffByBuffID(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419F8A0
	// [Call #4] RVA: 0x10419E244
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041946FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041947A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041969F0

	// Object: Function Basic.STBuffSystemComponent.GetRealOwnerRoleSafety
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10428a1d8
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRoleSafety();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10419F8A0
	// [Call #4] RVA: 0x10419E244
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041946FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041947A0
	// [Call #11] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.GetBuffReplaceDataByID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428a104
	// Params: [ Num(3) Size(0x10) ]
	struct FBuffReplaceData GetBuffReplaceDataByID(int ID, bool bBuffInst);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419EBE4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10419F8A0
	// [Call #9] RVA: 0x10419E244
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041946FC

	// Object: Function Basic.STBuffSystemComponent.GetBuffLayerCount
	// Flags: [Final|Native|Public]
	// Offset: 0x10428a040
	// Params: [ Num(3) Size(0xC) ]
	int GetBuffLayerCount(int InstID, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419F9F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10419EBE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10419F8A0

	// Object: Function Basic.STBuffSystemComponent.GetBuffInfoBySkillID
	// Flags: [Final|Native|Public]
	// Offset: 0x104289f8c
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBuffSyncBrief> GetBuffInfoBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A2154
	// [Call #4] RVA: 0x10428F0D4
	// [Call #5] RVA: 0x1041BA674
	// [Call #6] RVA: 0x1041BA674
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419F9F0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10419EBE4

	// Object: Function Basic.STBuffSystemComponent.GetBuffInfoByBuffID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104289ed8
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBuffSyncBrief> GetBuffInfoByBuffID(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A2088
	// [Call #4] RVA: 0x10428F0D4
	// [Call #5] RVA: 0x1041BA674
	// [Call #6] RVA: 0x1041BA674
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041A2154
	// [Call #11] RVA: 0x10428F0D4
	// [Call #12] RVA: 0x1041BA674
	// [Call #13] RVA: 0x1041BA674
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10419F9F0

	// Object: Function Basic.STBuffSystemComponent.GetBuffInfo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104289dc8
	// Params: [ Num(3) Size(0x41) ]
	bool GetBuffInfo(int InstID, struct FBuffSyncBrief& OutBuff);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041A2220
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041A2088
	// [Call #12] RVA: 0x10428F0D4
	// [Call #13] RVA: 0x1041BA674
	// [Call #14] RVA: 0x1041BA674
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041A2154
	// [Call #19] RVA: 0x10428F0D4
	// [Call #20] RVA: 0x1041BA674

	// Object: Function Basic.STBuffSystemComponent.GetBuffIDsBySkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104289d34
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<int> GetBuffIDsBySkillID(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104194884
	// [Call #4] RVA: 0x10207FA04
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041A2220
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041A2088
	// [Call #16] RVA: 0x10428F0D4
	// [Call #17] RVA: 0x1041BA674
	// [Call #18] RVA: 0x1041BA674
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.STBuffSystemComponent.GetBuffDuration
	// Flags: [Final|Native|Public]
	// Offset: 0x104289c70
	// Params: [ Num(3) Size(0xC) ]
	float GetBuffDuration(int InstID, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194644
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104194884
	// [Call #9] RVA: 0x10207FA04
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041A2220
	// [Call #15] RVA: 0x101F8C2E4

	// Object: Function Basic.STBuffSystemComponent.GetBuffDSEndTime
	// Flags: [Final|Native|Public]
	// Offset: 0x104289bac
	// Params: [ Num(3) Size(0xC) ]
	float GetBuffDSEndTime(int InstID, int CauseSkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419F8E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104194644
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104194884
	// [Call #14] RVA: 0x10207FA04
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.GetBuffCDInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104289af8
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<float> GetBuffCDInfo(int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A22F4
	// [Call #4] RVA: 0x1026D01C0
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419F8E8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104194644

	// Object: Function Basic.STBuffSystemComponent.GetAllBuffInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104289a94
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FBuffSyncBrief> GetAllBuffInfo();
	// [Call #1] RVA: 0x1041A1EF8
	// [Call #2] RVA: 0x10428F0D4
	// [Call #3] RVA: 0x1041BA674
	// [Call #4] RVA: 0x1041BA674
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A22F4
	// [Call #9] RVA: 0x1026D01C0
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10419F8E8
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.DoCooldown
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10428999c
	// Params: [ Num(3) Size(0x9) ]
	void DoCooldown(int InstID, int Index, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041A23A4
	// [Call #8] RVA: 0x1041A1EF8
	// [Call #9] RVA: 0x10428F0D4
	// [Call #10] RVA: 0x1041BA674
	// [Call #11] RVA: 0x1041BA674
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041A22F4
	// [Call #16] RVA: 0x1026D01C0
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.ClearBuffs
	// Flags: [Final|Native|Public]
	// Offset: 0x104289988
	// Params: [ Num(0) Size(0x0) ]
	void ClearBuffs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041A23A4
	// [Call #8] RVA: 0x1041A1EF8
	// [Call #9] RVA: 0x10428F0D4
	// [Call #10] RVA: 0x1041BA674
	// [Call #11] RVA: 0x1041BA674
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041A22F4
	// [Call #16] RVA: 0x1026D01C0
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.STBuffSystemComponent.ChangeLevel
	// Flags: [Final|Native|Public]
	// Offset: 0x1042898c4
	// Params: [ Num(3) Size(0x9) ]
	bool ChangeLevel(int InstID, int NewLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10419F944
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041A23A4
	// [Call #13] RVA: 0x1041A1EF8
	// [Call #14] RVA: 0x10428F0D4
	// [Call #15] RVA: 0x1041BA674
	// [Call #16] RVA: 0x1041BA674
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Basic.STBuffSystemComponent.ChangeDuration
	// Flags: [Final|Native|Public]
	// Offset: 0x1042897fc
	// Params: [ Num(3) Size(0x9) ]
	bool ChangeDuration(int InstID, float Duration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194468
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10419F944
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.AddBuffBySkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042896c0
	// Params: [ Num(5) Size(0x15) ]
	bool AddBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer, int Level);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104193EB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104194468
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.STBuffSystemComponent.AddBuff
	// Flags: [Final|Native|Public]
	// Offset: 0x104289548
	// Params: [ Num(6) Size(0x20) ]
	int AddBuff(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID, int Level);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104193790
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class Basic.STBuffTriggerBase
// Size: 0x70 (Inherited: 0x58)
struct USTBuffTriggerBase : USTBuffNodeInstanceData
{
	bool bTriggerOnCreate; // 0x58(0x1)
	uint8_t ExecuteRole; // 0x59(0x1)
	uint8_t Pad_0x5A[0x6]; // 0x5A(0x6)
	struct FTriggerConditionConfig ConditionConfig; // 0x60(0x10)


	// Object: Function Basic.STBuffTriggerBase.Tick
	// Flags: [Final|Native|Public]
	// Offset: 0x10428c008
	// Params: [ Num(3) Size(0x10) ]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10419548C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.STBuffTriggerBase.ResetExecute
	// Flags: [Final|Native|Public]
	// Offset: 0x10428bf50
	// Params: [ Num(2) Size(0xC) ]
	void ResetExecute(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196344
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419548C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffTriggerBase.OnTriggerCreate
	// Flags: [Native|Protected]
	// Offset: 0x10428bf34
	// Params: [ Num(0) Size(0x0) ]
	void OnTriggerCreate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196344
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10419548C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.STBuffTriggerBase.OnTick
	// Flags: [Native|Protected]
	// Offset: 0x10428beb0
	// Params: [ Num(1) Size(0x4) ]
	void OnTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104196344
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10419548C

	// Object: Function Basic.STBuffTriggerBase.OnInitialize
	// Flags: [Native|Protected]
	// Offset: 0x10428be94
	// Params: [ Num(0) Size(0x0) ]
	void OnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104196344
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10419548C

	// Object: Function Basic.STBuffTriggerBase.OnEnd
	// Flags: [Native|Protected]
	// Offset: 0x10428be78
	// Params: [ Num(0) Size(0x0) ]
	void OnEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104196344
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffTriggerBase.OnDestroy
	// Flags: [Native|Protected]
	// Offset: 0x10428be5c
	// Params: [ Num(0) Size(0x0) ]
	void OnDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104196344
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Basic.STBuffTriggerBase.OnCreate
	// Flags: [Final|Native|Public]
	// Offset: 0x10428bda4
	// Params: [ Num(2) Size(0xC) ]
	void OnCreate(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195D24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104196344

	// Object: Function Basic.STBuffTriggerBase.IsRoleOK
	// Flags: [Final|Native|Public]
	// Offset: 0x10428bd18
	// Params: [ Num(2) Size(0x9) ]
	bool IsRoleOK(struct UActorComponent* OwnerComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A2E88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104195D24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffTriggerBase.IsNeedTick
	// Flags: [Native|Public|Const]
	// Offset: 0x10428bcdc
	// Params: [ Num(1) Size(0x1) ]
	bool IsNeedTick();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041A2E88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104195D24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffTriggerBase.InitLinkActionEnableState
	// Flags: [Final|Native|Public]
	// Offset: 0x10428bc24
	// Params: [ Num(2) Size(0xC) ]
	void InitLinkActionEnableState(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041951B4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041A2E88
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104195D24

	// Object: Function Basic.STBuffTriggerBase.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10428bb6c
	// Params: [ Num(2) Size(0xC) ]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194FE4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041951B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041A2E88

	// Object: Function Basic.STBuffTriggerBase.GetRealOwnerRole
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10428bb30
	// Params: [ Num(1) Size(0x1) ]
	enum class ENetRole GetRealOwnerRole();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104194FE4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041951B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Basic.STBuffTriggerBase.End
	// Flags: [Final|Native|Public]
	// Offset: 0x10428ba78
	// Params: [ Num(2) Size(0xC) ]
	void End(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104195990
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104194FE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041951B4

	// Object: Function Basic.STBuffTriggerBase.Destroy
	// Flags: [Final|Native|Public]
	// Offset: 0x10428b9c0
	// Params: [ Num(2) Size(0xC) ]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104196050
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104195990
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104194FE4
};

// Object: Class Basic.STBuffTrigger_Event
// Size: 0x78 (Inherited: 0x70)
struct USTBuffTrigger_Event : USTBuffTriggerBase
{
	struct USTBuffEvent* Event; // 0x70(0x8)
};

// Object: Class Basic.STBuffTrigger_OnAdd
// Size: 0x70 (Inherited: 0x70)
struct USTBuffTrigger_OnAdd : USTBuffTriggerBase
{
};

// Object: Class Basic.STBuffTrigger_Timer
// Size: 0x78 (Inherited: 0x70)
struct USTBuffTrigger_Timer : USTBuffTriggerBase
{
	float TickInterval; // 0x70(0x4)
	bool bTriggerOnAdd; // 0x74(0x1)
	uint8_t Pad_0x75[0x3]; // 0x75(0x3)
};

// Object: Class Basic.UStringMap
// Size: 0x78 (Inherited: 0x28)
struct UUStringMap : UObject
{
	struct FStringMap Map; // 0x28(0x50)
};

// Object: Class Basic.STExtraNetPriorityConfig
// Size: 0xE8 (Inherited: 0x30)
struct USTExtraNetPriorityConfig : UWorldSubsystem
{
	bool ExtraNetPriorityEnabled; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct TMap<uint8_t, float> ExtraNetPriorityFactor; // 0x38(0x50)
	bool EnemyExtraNetPriorityEnabled; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	float EnemyExtraNetPriorityFactor; // 0x8C(0x4)
	struct TMap<uint8_t, uint8_t> NetPriorityIssue; // 0x90(0x50)
	float MoveExtraNetPriorityVelocitySquared; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
};

// Object: Class Basic.STExtraNetPriorityInterface
// Size: 0x28 (Inherited: 0x28)
struct ISTExtraNetPriorityInterface : IInterface
{
};

// Object: Class Basic.DataTableRowDesc
// Size: 0x98 (Inherited: 0x28)
struct UDataTableRowDesc : UObject
{
	uint8_t Pad_0x28[0x70]; // 0x28(0x70)
};

// Object: Class Basic.DataTableProxy
// Size: 0x190 (Inherited: 0x28)
struct UDataTableProxy : UObject
{
	struct TArray<struct UDataTable*> ModDataTables; // 0x28(0x10)
	struct UDataTable* DataTable; // 0x38(0x8)
	struct UBCDataTable* BlockTable; // 0x40(0x8)
	uint8_t Pad_0x48[0x140]; // 0x48(0x140)
	struct UDataTableRowDesc* Desc; // 0x188(0x8)
};

// Object: Class Basic.TableManagerSubsystem
// Size: 0x80 (Inherited: 0x30)
struct UTableManagerSubsystem : UGameInstanceSubsystem
{
	struct FString BaseTableRelativeDir; // 0x30(0x10)
	struct FString ModTableRelativeDir; // 0x40(0x10)
	struct FString TableRelativeDir; // 0x50(0x10)
	struct FString ManualTableDirectory; // 0x60(0x10)
	struct FString CurrentModName; // 0x70(0x10)


	// Object: Function Basic.TableManagerSubsystem.SetTableStringDataField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104291b8c
	// Params: [ Num(5) Size(0x39) ]
	bool SetTableStringDataField(struct FName& tableName, struct FString Key, struct FString Field, struct FString NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10422EB68
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function Basic.TableManagerSubsystem.SetModName
	// Flags: [Final|Native|Public]
	// Offset: 0x104291af4
	// Params: [ Num(1) Size(0x10) ]
	void SetModName(struct FString ModName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10422E4C8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10422EB68
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Basic.TableManagerSubsystem.GetTableProxy
	// Flags: [Final|Native|Public]
	// Offset: 0x10429196c
	// Params: [ Num(6) Size(0x30) ]
	struct UDataTableProxy* GetTableProxy(struct FName tableName, bool bTempory, struct FName SystemName, struct FName SubModName, bool bPreLoadPathCompression);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10422CC40
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10422E4C8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Basic.TableManagerSubsystem.GetTableDataField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10422e6ec
	// Params: [ Num(5) Size(0x31) ]
	bool GetTableDataField(struct FString tableName, struct FTableRowBase& Key, struct FString Field, struct FTableRowBase& Out);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104FD0740
	// [Call #10] RVA: 0x10422CC40
	// [Call #11] RVA: 0x101FC0158
	// [Call #12] RVA: 0x101FBF638
	// [Call #13] RVA: 0x106C8DCEC
	// [Call #14] RVA: 0x10421A5F0
	// [Call #15] RVA: 0x106C8DCEC
	// [Call #16] RVA: 0x10422CA44
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x10422EB10
	// [Call #19] RVA: 0x10422EB34

	// Object: Function Basic.TableManagerSubsystem.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10422e548
	// Params: [ Num(4) Size(0x29) ]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FBF868
	// [Call #8] RVA: 0x104FD0740
	// [Call #9] RVA: 0x10422CC40
	// [Call #10] RVA: 0x10422CA44
	// [Call #11] RVA: 0x103562FEC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
};

// Object: Class Basic.TickOptimizationAnimComponent
// Size: 0x1B0 (Inherited: 0x178)
struct UTickOptimizationAnimComponent : UActorComponent
{
	bool EnableTickOptimization; // 0x178(0x1)
	uint8_t AnimUpdateRateOptimizationsMode; // 0x179(0x1)
	uint8_t Pad_0x17A[0x6]; // 0x17A(0x6)
	struct TArray<float> FramesSkippedScreenSizeThresholds; // 0x180(0x10)
	struct TArray<int> LODToFramesSkipped; // 0x190(0x10)
	int NonRenderedFramesSkipped; // 0x1A0(0x4)
	int MaxFramesSkippedForInterpolation; // 0x1A4(0x4)
	bool bForceEnableAnimUpdateRateOptimizations; // 0x1A8(0x1)
	uint8_t Pad_0x1A9[0x7]; // 0x1A9(0x7)


	// Object: Function Basic.TickOptimizationAnimComponent.ShouldForceEnableAnimUpdateRateOptimizations
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042924ac
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldForceEnableAnimUpdateRateOptimizations();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationAnimComponent.SetNonRenderedFramesSkipped
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104292430
	// Params: [ Num(1) Size(0x4) ]
	void SetNonRenderedFramesSkipped(int InNonRenderedFramesSkipped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256E24
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationAnimComponent.SetMaxFramesSkippedForInterpolation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042923b4
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxFramesSkippedForInterpolation(int InMaxFramesSkippedForInterpolation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256E98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256E24
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationAnimComponent.SetLODToFramesSkipped
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10429230c
	// Params: [ Num(1) Size(0x10) ]
	void SetLODToFramesSkipped(struct TArray<int>& InLODToFramesSkipped);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256F80
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256E98
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256E24
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function Basic.TickOptimizationAnimComponent.SetFramesSkippedScreenSizeThresholds
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104292264
	// Params: [ Num(1) Size(0x10) ]
	void SetFramesSkippedScreenSizeThresholds(struct TArray<float>& InFramesSkippedScreenSizeThresholds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256F0C
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256F80
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104256E98
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104256E24

	// Object: Function Basic.TickOptimizationAnimComponent.SetForceEnableAnimUpdateRateOptimizations
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042921e0
	// Params: [ Num(1) Size(0x1) ]
	void SetForceEnableAnimUpdateRateOptimizations(bool bInForceEnableAnimUpdateRateOptimizations);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256FF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256F0C
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x101F8C2E4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256F80
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104256E98

	// Object: Function Basic.TickOptimizationAnimComponent.SetAnimUpdateRateOptimizationsMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104292164
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimUpdateRateOptimizationsMode(uint8_t InAnimUpdateRateOptimizationsMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256DB0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256FF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256F0C
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104256F80
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.TickOptimizationAnimComponent.RegisterDynamicSkinnedMeshComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042920e8
	// Params: [ Num(1) Size(0x8) ]
	void RegisterDynamicSkinnedMeshComponent(struct USkinnedMeshComponent* SkinnedMeshComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256F0C
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Basic.TickOptimizationAnimComponent.GetNonRenderedFramesSkipped
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042920cc
	// Params: [ Num(1) Size(0x4) ]
	int GetNonRenderedFramesSkipped();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256F0C
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Basic.TickOptimizationAnimComponent.GetMaxFramesSkippedForInterpolation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042920b0
	// Params: [ Num(1) Size(0x4) ]
	int GetMaxFramesSkippedForInterpolation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256F0C
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8C2E4

	// Object: Function Basic.TickOptimizationAnimComponent.GetLODToFramesSkipped
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104292094
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GetLODToFramesSkipped();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104256F0C
	// [Call #13] RVA: 0x101F8C2E4

	// Object: Function Basic.TickOptimizationAnimComponent.GetFramesSkippedScreenSizeThresholds
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104292078
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<float> GetFramesSkippedScreenSizeThresholds();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationAnimComponent.GetAnimUpdateRateOptimizationsMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10429205c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetAnimUpdateRateOptimizationsMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104256AF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104256DB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104256FF4
	// [Call #10] RVA: 0x10516D168
};

// Object: Class Basic.TickOptimizationFocusComponent
// Size: 0x3B0 (Inherited: 0x3A0)
struct UTickOptimizationFocusComponent : USceneComponent
{
	struct UTickOptimizationSubsystem* Subsystem; // 0x3A0(0x8)
	uint8_t Pad_0x3A8[0x8]; // 0x3A8(0x8)


	// Object: Function Basic.TickOptimizationFocusComponent.ShouldTrack
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1042929d8
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldTrack();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
};

// Object: Class Basic.TickOptimizationSubsystem
// Size: 0xA8 (Inherited: 0x30)
struct UTickOptimizationSubsystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
	struct TArray<struct UTickOptimizationFocusComponent*> Focuses; // 0x38(0x10)
	struct TArray<struct UTickOptimizationTargetComponent*> SphereRangeTargets; // 0x48(0x10)
	uint8_t Pad_0x58[0x20]; // 0x58(0x20)
	struct TArray<struct UTickOptimizationTargetComponent*> SphereZoneTargets; // 0x78(0x10)
	uint8_t Pad_0x88[0x10]; // 0x88(0x10)
	struct TArray<struct UTickOptimizationTargetComponent*> UpdatedTargets; // 0x98(0x10)
};

// Object: Class Basic.TickOptimizationTargetComponent
// Size: 0x430 (Inherited: 0x3A0)
struct UTickOptimizationTargetComponent : USceneComponent
{
	struct UTickOptimizationSubsystem* Subsystem; // 0x3A0(0x8)
	uint8_t Pad_0x3A8[0x8]; // 0x3A8(0x8)
	struct TArray<struct UActorComponent*> TickControlledComponents; // 0x3B0(0x10)
	bool EnableTickOptimization; // 0x3C0(0x1)
	uint8_t DistanceMode; // 0x3C1(0x1)
	uint8_t Pad_0x3C2[0x2]; // 0x3C2(0x2)
	float SphereRadius; // 0x3C4(0x4)
	float BufferSize; // 0x3C8(0x4)
	uint8_t Pad_0x3CC[0x4]; // 0x3CC(0x4)
	struct TArray<float> MidZoneSizes; // 0x3D0(0x10)
	bool bActorTickControl; // 0x3E0(0x1)
	bool bActorTickChange; // 0x3E1(0x1)
	bool bComponentsTickControl; // 0x3E2(0x1)
	bool bComponentsTickChange; // 0x3E3(0x1)
	bool bForceExecuteFirstTick; // 0x3E4(0x1)
	uint8_t Pad_0x3E5[0x3]; // 0x3E5(0x3)
	struct TArray<struct FTickOptimizationTickSettings> TickSettings; // 0x3E8(0x10)
	bool bForced; // 0x3F8(0x1)
	uint8_t Pad_0x3F9[0x3]; // 0x3F9(0x3)
	int TickZone; // 0x3FC(0x4)
	struct FScriptMulticastDelegate OnTickChanged; // 0x400(0x10)
	struct FScriptMulticastDelegate OnTickZoneChanged; // 0x410(0x10)
	struct FScriptMulticastDelegate OnTickEnabledChanged; // 0x420(0x10)


	// Object: Function Basic.TickOptimizationTargetComponent.ShouldForceExecuteFirstTick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042935ec
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldForceExecuteFirstTick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationTargetComponent.SetTickSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104293544
	// Params: [ Num(1) Size(0x10) ]
	void SetTickSettings(struct TArray<struct FTickOptimizationTickSettings>& InTickSettings);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042593C0
	// [Call #4] RVA: 0x10425CEB0
	// [Call #5] RVA: 0x10425CEB0
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationTargetComponent.SetSphereRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042934c8
	// Params: [ Num(1) Size(0x4) ]
	void SetSphereRadius(float InRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104258E7C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1042593C0
	// [Call #7] RVA: 0x10425CEB0
	// [Call #8] RVA: 0x10425CEB0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationTargetComponent.SetMidZoneSizes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104293420
	// Params: [ Num(1) Size(0x10) ]
	void SetMidZoneSizes(struct TArray<float>& InMidZoneSizes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104258F64
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258E7C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1042593C0
	// [Call #13] RVA: 0x10425CEB0
	// [Call #14] RVA: 0x10425CEB0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Basic.TickOptimizationTargetComponent.SetForceExecuteFirstTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429339c
	// Params: [ Num(1) Size(0x1) ]
	void SetForceExecuteFirstTick(bool bInForceExecuteFirstTick);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425934C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104258F64
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x101F8C2E4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104258E7C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1042593C0
	// [Call #16] RVA: 0x10425CEB0
	// [Call #17] RVA: 0x10425CEB0
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Basic.TickOptimizationTargetComponent.SetDistanceMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104293320
	// Params: [ Num(1) Size(0x1) ]
	void SetDistanceMode(uint8_t InDistanceMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104258E08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10425934C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258F64
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104258E7C

	// Object: Function Basic.TickOptimizationTargetComponent.SetComponentsTickControl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429329c
	// Params: [ Num(1) Size(0x1) ]
	void SetComponentsTickControl(bool bInComponentsTickControl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259140
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104258E08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10425934C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104258F64
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Basic.TickOptimizationTargetComponent.SetBufferSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104293220
	// Params: [ Num(1) Size(0x4) ]
	void SetBufferSize(float InBufferSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104258EF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259140
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258E08
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10425934C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.SetActorTickControl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429319c
	// Params: [ Num(1) Size(0x1) ]
	void SetActorTickControl(bool bInActorTickControl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259010
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104258EF0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104259140
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104258E08
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.RemoveComponentTickControl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104293120
	// Params: [ Num(1) Size(0x8) ]
	void RemoveComponentTickControl(struct UActorComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104259140
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.Release
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429310c
	// Params: [ Num(0) Size(0x0) ]
	void Release();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104259140
	// [Call #13] RVA: 0x10516D168

	// Object: Function Basic.TickOptimizationTargetComponent.IsForced
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042930f0
	// Params: [ Num(1) Size(0x1) ]
	bool IsForced();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104259140

	// Object: Function Basic.TickOptimizationTargetComponent.IsComponentsTickControl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042930d4
	// Params: [ Num(1) Size(0x1) ]
	bool IsComponentsTickControl();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104259140

	// Object: Function Basic.TickOptimizationTargetComponent.IsActorTickControl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1042930b8
	// Params: [ Num(1) Size(0x1) ]
	bool IsActorTickControl();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104259140

	// Object: Function Basic.TickOptimizationTargetComponent.GetTickZone
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10429309c
	// Params: [ Num(1) Size(0x4) ]
	int GetTickZone();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.GetTickSettings
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104293080
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FTickOptimizationTickSettings> GetTickSettings();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0
	// [Call #10] RVA: 0x10516D168

	// Object: Function Basic.TickOptimizationTargetComponent.GetSphereRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104293064
	// Params: [ Num(1) Size(0x4) ]
	float GetSphereRadius();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0

	// Object: Function Basic.TickOptimizationTargetComponent.GetMidZoneSizes
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104293048
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<float> GetMidZoneSizes();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104258EF0

	// Object: Function Basic.TickOptimizationTargetComponent.GetDistanceMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10429302c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetDistanceMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.GetBufferSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104293010
	// Params: [ Num(1) Size(0x4) ]
	float GetBufferSize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259010
	// [Call #7] RVA: 0x10516D168

	// Object: Function Basic.TickOptimizationTargetComponent.Force
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104292f94
	// Params: [ Num(1) Size(0x4) ]
	void Force(int InZone);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259478
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259690
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Basic.TickOptimizationTargetComponent.AddComponentTickControl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104292f18
	// Params: [ Num(1) Size(0x8) ]
	void AddComponentTickControl(struct UActorComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104258B28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104259478
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
};

// Object: Class Basic.UAEBuffPoolSubsystem
// Size: 0x80 (Inherited: 0x30)
struct UUAEBuffPoolSubsystem : UWorldSubsystem
{
	struct TMap<struct FString, struct USTBuff*> BuffInstancedTemplateMap; // 0x30(0x50)
};

// Object: Class Basic.UAEGameEngine
// Size: 0xEC0 (Inherited: 0xE70)
struct UUAEGameEngine : UGameEngine
{
	uint8_t Pad_0xE70[0x10]; // 0xE70(0x10)
	struct UBackendHUD* AssociatedBackendHUD; // 0xE80(0x8)
	uint8_t Pad_0xE88[0xC]; // 0xE88(0xC)
	bool bEnableAutoStat; // 0xE94(0x1)
	bool bEnableAutoTickDeltaThreshold; // 0xE95(0x1)
	uint8_t Pad_0xE96[0x2]; // 0xE96(0x2)
	float AutoTickDeltaThresholdFactor; // 0xE98(0x4)
	float StatCollection_AvgTickDeltaThreshold; // 0xE9C(0x4)
	float AutoStat_AvgTickDeltaThreshold; // 0xEA0(0x4)
	float AutoStat_StartTime; // 0xEA4(0x4)
	uint8_t Pad_0xEA8[0x4]; // 0xEA8(0x4)
	float AutoStat_Duration_Engine; // 0xEAC(0x4)
	float AutoStat_Duration_PhysX; // 0xEB0(0x4)
	uint8_t Pad_0xEB4[0xC]; // 0xEB4(0xC)
};

// Object: Class Basic.BPTable
// Size: 0xD8 (Inherited: 0x28)
struct UBPTable : UObject
{
	struct FString BPTableName; // 0x28(0x10)
	struct TMap<int, struct FBPTableItem> BPTableItemMap; // 0x38(0x50)
	struct TMap<int, struct FBPTableItem> BPTableItemMap_Mod; // 0x88(0x50)


	// Object: Function Basic.BPTable.GetWrapperPath
	// Flags: [Final|Native|Public]
	// Offset: 0x1042963dc
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetWrapperPath(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042195BC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.BPTable.GetWrapperClass
	// Flags: [Final|Native|Public]
	// Offset: 0x104296350
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetWrapperClass(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042193AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1042195BC
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Basic.BPTable.GetPath
	// Flags: [Final|Native|Public]
	// Offset: 0x104296214
	// Params: [ Num(4) Size(0x18) ]
	struct FString GetPath(int ID, bool IsLobby, bool bForceLobby);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1042191B0
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1042193AC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1042195BC
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Basic.BPTable.GetObject
	// Flags: [Final|Native|Public]
	// Offset: 0x1042960c4
	// Params: [ Num(5) Size(0x20) ]
	struct UObject* GetObject(int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1042196C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1042191B0

	// Object: Function Basic.BPTable.GetModObject
	// Flags: [Final|Native|Public]
	// Offset: 0x104295fb8
	// Params: [ Num(4) Size(0x20) ]
	struct UObject* GetModObject(int ID, struct UObject* Outer, bool IsLobby);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104219770
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1042196C0

	// Object: Function Basic.BPTable.GetModClass
	// Flags: [Final|Native|Public]
	// Offset: 0x104295eec
	// Params: [ Num(3) Size(0x10) ]
	struct UObject* GetModClass(int ID, bool IsLobby);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10421914C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104219770
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.BPTable.GetCustom1Class
	// Flags: [Final|Native|Public]
	// Offset: 0x104295e60
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetCustom1Class(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042194B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10421914C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104219770

	// Object: Function Basic.BPTable.GetClass
	// Flags: [Final|Native|Public]
	// Offset: 0x104295d4c
	// Params: [ Num(4) Size(0x10) ]
	struct UObject* GetClass(int ID, bool IsLobby, bool IsLowDevice);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1042185F8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1042194B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10421914C

	// Object: Function Basic.BPTable.ConvertPath
	// Flags: [Final|Native|Public]
	// Offset: 0x104295cd0
	// Params: [ Num(1) Size(0x4) ]
	void ConvertPath(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104217E98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1042185F8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1042194B4
	// [Call #14] RVA: 0x10516D168
};

// Object: Class Basic.UAELoadedClassManager
// Size: 0x3A8 (Inherited: 0x28)
struct UUAELoadedClassManager : UObject
{
	struct TMap<struct FString, struct UBPTable*> BPTableMap; // 0x28(0x50)
	struct TMap<struct FString, struct UBPTable*> BPTableMap_Mod; // 0x78(0x50)
	struct TMap<int, struct FString> BPTableNameMap; // 0xC8(0x50)
	struct TMap<struct FName, struct FTableNameToName> BPTableNameToNameMap; // 0x118(0x50)
	struct FString LoadedClassManagerClassName; // 0x168(0x10)
	uint8_t Pad_0x178[0x1C8]; // 0x178(0x1C8)
	struct TMap<struct UObject*, struct FSoftClassPath> AsyncLoadClassDict; // 0x340(0x50)
	uint8_t Pad_0x390[0x18]; // 0x390(0x18)


	// Object: Function Basic.UAELoadedClassManager.InitTableData
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104297914
	// Params: [ Num(0) Size(0x0) ]
	void InitTableData();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.UAELoadedClassManager.InitialModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1042978f8
	// Params: [ Num(0) Size(0x0) ]
	void InitialModTableItemMap();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Basic.UAELoadedClassManager.InitBPTableMap_Mod
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitBPTableMap_Mod();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.UAELoadedClassManager.InitBPTableMap
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitBPTableMap();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Basic.UAELoadedClassManager.HandleTableModNameChanged
	// Flags: [Final|Native|Public]
	// Offset: 0x104297860
	// Params: [ Num(1) Size(0x10) ]
	void HandleTableModNameChanged(struct FString InModName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104217ADC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UAELoadedClassManager.GetWrapperPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104297750
	// Params: [ Num(3) Size(0x28) ]
	struct FString GetWrapperPath(struct FString BPTableName, int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10421B770
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104217ADC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function Basic.UAELoadedClassManager.GetWrapperClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104297668
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* GetWrapperClass(struct FString BPTableName, int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10421B0D8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10421B770
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.GetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042974c8
	// Params: [ Num(5) Size(0x28) ]
	struct FString GetPath(struct FString BPTableName, int ID, bool IsLobby, bool bForceLobby);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10421A8F8
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10421B0D8

	// Object: Function Basic.UAELoadedClassManager.GetObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104297310
	// Params: [ Num(6) Size(0x30) ]
	struct UObject* GetObject(struct FString BPTableName, int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10421BA40
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.GetExactDeviceLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1042972dc
	// Params: [ Num(1) Size(0x4) ]
	int GetExactDeviceLevel();
	// [Call #1] RVA: 0x10421AF08
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10421BA40
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.GetDeviceLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1042972a8
	// Params: [ Num(1) Size(0x4) ]
	int GetDeviceLevel();
	// [Call #1] RVA: 0x10421B0AC
	// [Call #2] RVA: 0x10421AF08
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10421BA40
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Basic.UAELoadedClassManager.GetCustom1Class
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042971c0
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* GetCustom1Class(struct FString BPTableName, int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10421B424
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10421B0AC
	// [Call #10] RVA: 0x10421AF08
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.GetClassLoadingPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429706c
	// Params: [ Num(4) Size(0x28) ]
	struct FString GetClassLoadingPath(struct FString BPTableName, int ID, bool IsLobby);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10421A884
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10421B424
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Basic.UAELoadedClassManager.GetClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104296ef4
	// Params: [ Num(5) Size(0x20) ]
	struct UObject* GetClass(struct FString BPTableName, int ID, bool IsLobby, bool IsLowDevice);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104219FC4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.GetBPTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104296e40
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetBPTableName(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BC6C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104219FC4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Basic.UAELoadedClassManager.GetAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104296d20
	// Params: [ Num(2) Size(0x28) ]
	void GetAssetByAssetReferenceAsync(struct FSoftObjectPath AssetReference, DelegateProperty AssetLoadSuccessDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020FDC08
	// [Call #7] RVA: 0x10421C490
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10421BC6C
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Basic.UAELoadedClassManager.GetAssetAsyncWithStringForManage
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104296b64
	// Params: [ Num(3) Size(0x38) ]
	void GetAssetAsyncWithStringForManage(struct FSoftObjectPath AssetReference, struct FString InputString, DelegateProperty AssetLoadSuccessDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020FDC08
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x10421C93C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x101FD9E48
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104296b30
	// Params: [ Num(1) Size(0x8) ]
	struct UUAELoadedClassManager* Get();
	// [Call #1] RVA: 0x10421981C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD9E48
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020FDC08
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x10421C93C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101FD9E48

	// Object: Function Basic.UAELoadedClassManager.CreateAndAddBPTable_Mod
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104296a88
	// Params: [ Num(2) Size(0x18) ]
	struct UBPTable* CreateAndAddBPTable_Mod(struct FString BPTableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BF24
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10421981C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020FDC08
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x10421C93C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504

	// Object: Function Basic.UAELoadedClassManager.CreateAndAddBPTable
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1042969e0
	// Params: [ Num(2) Size(0x18) ]
	struct UBPTable* CreateAndAddBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BE0C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10421BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10421981C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.ClearModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1042969c4
	// Params: [ Num(0) Size(0x0) ]
	void ClearModTableItemMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BE0C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10421BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10421981C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48
	// [Call #19] RVA: 0x10516D168

	// Object: Function Basic.UAELoadedClassManager.ClearBPTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042969b0
	// Params: [ Num(0) Size(0x0) ]
	void ClearBPTable_Mod();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BE0C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10421BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10421981C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48

	// Object: Function Basic.UAELoadedClassManager.ClearBPTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429699c
	// Params: [ Num(0) Size(0x0) ]
	void ClearBPTable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421BE0C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10421BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10421981C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Basic.UAELoadedClassManager.ClearAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public]
	// Offset: 0x10429690c
	// Params: [ Num(1) Size(0x10) ]
	void ClearAssetByAssetReferenceAsync(DelegateProperty AssetLoadSuccessDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10421C8EC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10421BE0C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10421BF24
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10421981C

	// Object: Function Basic.UAELoadedClassManager.ClearAllHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042968f8
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllHandle();
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10421C8EC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10421BE0C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10421BF24
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Basic.UAELoadedClassManager.ClearAllData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1042968e4
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllData();
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10421C8EC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10421BE0C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10421BF24
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
};

// Object: Class Basic.UAEMeshComponent
// Size: 0x13A0 (Inherited: 0x1350)
struct UUAEMeshComponent : USkeletalMeshComponent
{
	bool bUseBoneRetargetLODFeature; // 0x1344(0x1)
	bool bVisibleWithLOD; // 0x1349(0x1)
	uint8_t Pad_0x1352[0x4E]; // 0x1352(0x4E)


	// Object: Function Basic.UAEMeshComponent.TriggerCacheMaterialParameterNameIndices
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429c068
	// Params: [ Num(0) Size(0x0) ]
	void TriggerCacheMaterialParameterNameIndices();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Basic.UAEMeshComponent.RemoveDisableClothRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429bfd0
	// Params: [ Num(1) Size(0x10) ]
	void RemoveDisableClothRequest(struct FString InSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421F414
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UAEMeshComponent.GetPredictedLODLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429bf94
	// Params: [ Num(1) Size(0x4) ]
	int GetPredictedLODLevel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421F414
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.UAEMeshComponent.GetAnimUpdateParamsInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429bf30
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAnimUpdateParamsInfo();
	// [Call #1] RVA: 0x10421F198
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10421F414
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.UAEMeshComponent.AddDisableClothRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429be98
	// Params: [ Num(1) Size(0x10) ]
	void AddDisableClothRequest(struct FString InSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421F2D0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10421F198
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10421F414
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
};

// Object: Class Basic.UAENetConnection
// Size: 0x35A68 (Inherited: 0x35708)
struct UUAENetConnection : UIpConnection
{
	uint8_t Pad_0x35708[0xF4]; // 0x35708(0xF4)
	int InitialHandshakeTimeoutNumThreshold; // 0x357FC(0x4)
	uint8_t Pad_0x35800[0x4]; // 0x35800(0x4)
	int ActorChannelProcessBunchErrorNumThreshold_Server_Global; // 0x35804(0x4)
	int ActorChannelProcessBunchErrorNumThreshold_Client_Global; // 0x35808(0x4)
	int ActorChannelProcessBunchErrorNumThreshold_Client_PerActor; // 0x3580C(0x4)
	uint8_t Pad_0x35810[0x50]; // 0x35810(0x50)
	bool bEnableHTTPDNS; // 0x35860(0x1)
	uint8_t Pad_0x35861[0x7]; // 0x35861(0x7)
	struct FString HTTPDNSServerAddr; // 0x35868(0x10)
	float HTTPDNSResponseTimeout; // 0x35878(0x4)
	uint8_t Pad_0x3587C[0xC]; // 0x3587C(0xC)
	float CheckLevelInitializedTime; // 0x35888(0x4)
	float CheckLevelActorsOvertime; // 0x3588C(0x4)
	float TempCheckLevelInitializedTime; // 0x35890(0x4)
	uint8_t Pad_0x35894[0x4]; // 0x35894(0x4)
	struct TMap<struct FName, struct FUnLoadLevelActorCollection> UnLevelInitActors; // 0x35898(0x50)
	struct UNetRelevancyGroup* RelevancyGroup; // 0x358E8(0x8)
	uint8_t Pad_0x358F0[0x100]; // 0x358F0(0x100)
	struct TArray<struct FPendingRegionNetworkObject> PendingRegionNetworkObjects; // 0x359F0(0x10)
	float MinRegionActorTickDelta; // 0x35A00(0x4)
	float MaxRegionActorTickDelta; // 0x35A04(0x4)
	uint8_t Pad_0x35A08[0xC]; // 0x35A08(0xC)
	bool EnableWeakNetUpdate; // 0x35A14(0x1)
	uint8_t Pad_0x35A15[0x3]; // 0x35A15(0x3)
	float MinWeakNetUpdateDelay; // 0x35A18(0x4)
	float MaxWeakNetUpdateDelay; // 0x35A1C(0x4)
	float SquareSegmentSize; // 0x35A20(0x4)
	float MaxSegmentDistance; // 0x35A24(0x4)
	int MaxObjectNumInSegments; // 0x35A28(0x4)
	uint8_t Pad_0x35A2C[0x15]; // 0x35A2C(0x15)
	bool bRecreateSocketOnLost; // 0x35A41(0x1)
	uint8_t Pad_0x35A42[0x12]; // 0x35A42(0x12)
	float UpdateClientPingTimeThreshold; // 0x35A54(0x4)
	uint8_t Pad_0x35A58[0x10]; // 0x35A58(0x10)


	// Object: Function Basic.UAENetConnection.IsClosed
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10429ca90
	// Params: [ Num(1) Size(0x1) ]
	bool IsClosed();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190648

	// Object: Function Basic.UAENetConnection.HasSameRegion
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x10429c9c8
	// Params: [ Num(3) Size(0x19) ]
	bool HasSameRegion(struct FVector OldLoc, struct FVector NewLoc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104223300
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Basic.UAENetConnection.ForceRefreshRegionWeakNetUpdateObjects
	// Flags: [Final|Native|Public]
	// Offset: 0x10429c94c
	// Params: [ Num(1) Size(0x4) ]
	void ForceRefreshRegionWeakNetUpdateObjects(float WeakNetConsiderFrequency);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042231C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104223300
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class Basic.UAENetDriver
// Size: 0xB68 (Inherited: 0xA00)
struct UUAENetDriver : UIpNetDriver
{
	float NetCullChangeTime; // 0xA00(0x4)
	bool bEnableCollectNetStats; // 0xA04(0x1)
	bool bEnableResetNetStats; // 0xA05(0x1)
	uint8_t Pad_0xA06[0x2]; // 0xA06(0x2)
	struct TArray<struct FRPCShareSerializationFunctionPresetConfig> RPCShareSerializationFunctionPresetConfigs; // 0xA08(0x10)
	uint8_t Pad_0xA18[0x150]; // 0xA18(0x150)
};

// Object: Class Basic.UAETableManager
// Size: 0x748 (Inherited: 0x28)
struct UUAETableManager : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FString TableRelativeDir; // 0x30(0x10)
	struct TArray<struct FName> TablesNeedReleasedInBattle; // 0x40(0x10)
	struct FString ManualTableDirectory; // 0x50(0x10)
	uint8_t Pad_0x60[0x160]; // 0x60(0x160)
	struct TArray<struct UUAEDataTable*> TableObjList; // 0x1C0(0x10)
	struct UWorld* CurWorld; // 0x1D0(0x8)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap; // 0x1D8(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap_Mod; // 0x228(0x50)
	struct FScriptMulticastDelegate OnTableCreateInFighting; // 0x278(0x10)
	uint8_t Pad_0x288[0x168]; // 0x288(0x168)
	struct FString PathCompressionConfigsPath; // 0x3F0(0x10)
	bool bIsPathCompression; // 0x400(0x1)
	bool bIsPathCompressionCache; // 0x401(0x1)
	uint8_t Pad_0x402[0x2]; // 0x402(0x2)
	int PathCompressionCacheMaxSize; // 0x404(0x4)
	bool bTranslationFallBackUnloadDuplicate; // 0x408(0x1)
	bool bShrinkTranslationMap; // 0x409(0x1)
	bool bSpeedUpLoadLocalizationText; // 0x40A(0x1)
	bool bAsyncLoadLocalizationTable; // 0x40B(0x1)
	bool bLoadPathCompressionCfgWhenReadTable; // 0x40C(0x1)
	bool bGenerateTrieTreeFromDict; // 0x40D(0x1)
	uint8_t Pad_0x40E[0x2]; // 0x40E(0x2)
	struct TArray<struct FString> TableToPreLoadPathCompression; // 0x410(0x10)
	uint8_t Pad_0x420[0x8]; // 0x420(0x8)
	struct FString BaseTableRelativeDir; // 0x428(0x10)
	struct FString ModTableRelativeDir; // 0x438(0x10)
	struct FString SplitModTableRelativeDir; // 0x448(0x10)
	struct TArray<struct FString> BaseModTableConfig; // 0x458(0x10)
	struct TArray<struct FName> LobbyTableToLoadInMainCity; // 0x468(0x10)
	struct TArray<struct FString> ModListToLoadTranslation; // 0x478(0x10)
	struct TMap<struct FName, struct UModTable*> ModTableMap; // 0x488(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> ModTableObjMap; // 0x4D8(0x50)
	struct TArray<struct UUAEDataTable*> InGameTableObjList; // 0x528(0x10)
	struct TMap<struct FName, bool> CheckNeedModMap; // 0x538(0x50)
	struct FString CurrentModName; // 0x588(0x10)
	struct FString EmptyModName; // 0x598(0x10)
	struct TMap<struct FString, struct UBaseTableResMap*> LoadedTableMap; // 0x5A8(0x50)
	struct TMap<struct FString, bool> CheckMapTable; // 0x5F8(0x50)
	uint8_t Pad_0x648[0x100]; // 0x648(0x100)


	// Object: Function Basic.UAETableManager.ReleaseTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429db1c
	// Params: [ Num(1) Size(0x8) ]
	void ReleaseTable(struct FName TableFName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104233760
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Basic.UAETableManager.GetTablePtr_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429da90
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEDataTable* GetTablePtr_Mod(struct FName tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104216408
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104233760
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Basic.UAETableManager.GetTablePtr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10429d9c0
	// Params: [ Num(3) Size(0x18) ]
	struct UUAEDataTable* GetTablePtr(struct FName tableName, bool bCheckModTable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104214ED0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104216408
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104233760
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UAETableManager.GetTableMap
	// Flags: [Final|Native|Public]
	// Offset: 0x10429d918
	// Params: [ Num(2) Size(0x18) ]
	struct UBaseTableResMap* GetTableMap(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042389B4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104214ED0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104216408
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.UAETableManager.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10429d50c
	// Params: [ Num(4) Size(0x29) ]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FBF868
	// [Call #8] RVA: 0x104214C3C
	// [Call #9] RVA: 0x1042389B4
	// [Call #10] RVA: 0x101F88CE4
	// [Call #11] RVA: 0x10509A0A4
	// [Call #12] RVA: 0x104FD0740
	// [Call #13] RVA: 0x104238948
	// [Call #14] RVA: 0x10421470C
	// [Call #15] RVA: 0x104FD0740
	// [Call #16] RVA: 0x101F88CE4
	// [Call #17] RVA: 0x10509A0A4
	// [Call #18] RVA: 0x106202884
	// [Call #19] RVA: 0x104EFDFCC
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x10516CE1C

	// Object: Function Basic.UAETableManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429d4d8
	// Params: [ Num(1) Size(0x8) ]
	struct UUAETableManager* GetInstance();
	// [Call #1] RVA: 0x104214C3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FBF868
	// [Call #9] RVA: 0x104214C3C
	// [Call #10] RVA: 0x1042389B4
	// [Call #11] RVA: 0x101F88CE4
	// [Call #12] RVA: 0x10509A0A4
	// [Call #13] RVA: 0x104FD0740
	// [Call #14] RVA: 0x104238948
	// [Call #15] RVA: 0x10421470C
	// [Call #16] RVA: 0x104FD0740
	// [Call #17] RVA: 0x101F88CE4
	// [Call #18] RVA: 0x10509A0A4
	// [Call #19] RVA: 0x106202884

	// Object: Function Basic.UAETableManager.GetDomainByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429d434
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetDomainByID(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104233A40
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x104214C3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FBF868
	// [Call #16] RVA: 0x104214C3C
	// [Call #17] RVA: 0x1042389B4
	// [Call #18] RVA: 0x101F88CE4
	// [Call #19] RVA: 0x10509A0A4
	// [Call #20] RVA: 0x104FD0740
	// [Call #21] RVA: 0x104238948

	// Object: Function Basic.UAETableManager.GetDataTableStatic_Mod
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429d39c
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEDataTable* GetDataTableStatic_Mod(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1042339E0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104233A40
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104214C3C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101FBF868

	// Object: Function Basic.UAETableManager.GetDataTableStatic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429d304
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEDataTable* GetDataTableStatic(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10421470C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1042339E0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104233A40
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x104214C3C
	// [Call #21] RVA: 0x10516D168

	// Object: Function Basic.UAETableManager.GetDataTableProxy
	// Flags: [Final|Native|Public]
	// Offset: 0x10429d1c0
	// Params: [ Num(5) Size(0x28) ]
	struct UDataTableProxy* GetDataTableProxy(struct FName tableName, bool bTempory, struct FName SystemName, struct FName SubModName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10422CD90
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10421470C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1042339E0
	// [Call #19] RVA: 0x101F8130C
};

// Object: Class Basic.UELanguageUtilityMethods
// Size: 0x28 (Inherited: 0x28)
struct UUELanguageUtilityMethods : UBlueprintFunctionLibrary
{

	// Object: Function Basic.UELanguageUtilityMethods.SetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e344
	// Params: [ Num(1) Size(0x10) ]
	void SetDownLoadLanguageName(struct FString Language);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259DC0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UELanguageUtilityMethods.IsJaguar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e310
	// Params: [ Num(1) Size(0x1) ]
	bool IsJaguar();
	// [Call #1] RVA: 0x1042598B4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104259DC0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Basic.UELanguageUtilityMethods.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e2ac
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetPublishRegion();
	// [Call #1] RVA: 0x1042598B8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1042598B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104259DC0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Basic.UELanguageUtilityMethods.GetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e248
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDownLoadLanguageName();
	// [Call #1] RVA: 0x104259D64
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1042598B8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1042598B4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104259DC0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function Basic.UELanguageUtilityMethods.GetCurrentLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e1e4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCurrentLanguageName();
	// [Call #1] RVA: 0x1042598BC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104259D64
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1042598B8
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1042598B4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104259DC0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C

	// Object: Function Basic.UELanguageUtilityMethods.ConvertLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e124
	// Params: [ Num(2) Size(0x20) ]
	struct FString ConvertLanguageName(struct FString prelanguage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104259E00
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1042598BC
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104259D64
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x1042598B8
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x1042598B4
	// [Call #26] RVA: 0x10516D168

	// Object: Function Basic.UELanguageUtilityMethods.CheckLocalizationExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e0f0
	// Params: [ Num(1) Size(0x1) ]
	bool CheckLocalizationExist();
	// [Call #1] RVA: 0x104259A34
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104259E00
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1042598BC
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104259D64
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1042598B8
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x1042598B4
};

// Object: Class Basic.UEMathUtilityMethods
// Size: 0x28 (Inherited: 0x28)
struct UUEMathUtilityMethods : UBlueprintFunctionLibrary
{

	// Object: Function Basic.UEMathUtilityMethods.VectorNormalizeMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x10429ef0c
	// Params: [ Num(3) Size(0x1C) ]
	void VectorNormalizeMultiple(struct FVector& Out, struct FVector& v1, float Multiple);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10425B26C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UEMathUtilityMethods.VectorMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x10429ee00
	// Params: [ Num(3) Size(0x1C) ]
	void VectorMultiple(struct FVector& Out, struct FVector& v1, float Multiple);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10425B250
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10425B26C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Basic.UEMathUtilityMethods.VectorMinus
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x10429ece8
	// Params: [ Num(3) Size(0x24) ]
	void VectorMinus(struct FVector& Out, struct FVector& v1, struct FVector& v2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10425B22C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10425B250
	// [Call #15] RVA: 0x10516D168

	// Object: Function Basic.UEMathUtilityMethods.VectorAdditive
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x10429ebd0
	// Params: [ Num(3) Size(0x24) ]
	void VectorAdditive(struct FVector& Out, struct FVector& v1, struct FVector& v2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10425B208
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10425B22C

	// Object: Function Basic.UEMathUtilityMethods.FilterOKForCurrentMode
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x10429ea64
	// Params: [ Num(4) Size(0x19) ]
	bool FilterOKForCurrentMode(uint8_t ModeType, int ModeOpenFlag, struct FString ModeTypes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x10425ADD0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Basic.UEMathUtilityMethods.Conv_VectorToRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x10429e99c
	// Params: [ Num(2) Size(0x18) ]
	void Conv_VectorToRotator(struct FRotator& Out, struct FVector& Vec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10425B2DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x10425ADD0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Basic.UEMathUtilityMethods.CalculateAngleToTargetAngle
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e870
	// Params: [ Num(5) Size(0x14) ]
	float CalculateAngleToTargetAngle(float StartAngle, float targetAngle, float StepAngle, uint8_t Dir);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10425AB1C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10425B2DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Basic.UEMathUtilityMethods.BKDRHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e798
	// Params: [ Num(3) Size(0x18) ]
	int BKDRHash(struct FString StrToHash, int Mod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10425AD14
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10425AB1C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Basic.UEMathUtilityMethods.AngleDis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429e6e4
	// Params: [ Num(3) Size(0xC) ]
	float AngleDis(float angleA, float angleB);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10425AA74
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10425AD14
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class Basic.UEPathUtilityMethods
// Size: 0x28 (Inherited: 0x28)
struct UUEPathUtilityMethods : UBlueprintFunctionLibrary
{

	// Object: Function Basic.UEPathUtilityMethods.IsPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429fb50
	// Params: [ Num(2) Size(0x11) ]
	bool IsPathExist(struct FString HandlePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425B8E0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Basic.UEPathUtilityMethods.IsAvatarResPathExistRetODPakName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10429fa54
	// Params: [ Num(3) Size(0x21) ]
	bool IsAvatarResPathExistRetODPakName(struct FString HandlePath, struct FString& OutODPakName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10425B564
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10425B8E0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C

	// Object: Function Basic.UEPathUtilityMethods.IsAvatarResPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f9bc
	// Params: [ Num(2) Size(0x11) ]
	bool IsAvatarResPathExist(struct FString HandlePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425B308
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10425B564
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10425B8E0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Basic.UEPathUtilityMethods.GetPassiveDownloadResourcePaths
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f958
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetPassiveDownloadResourcePaths();
	// [Call #1] RVA: 0x10425C5B4
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10425B308
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10425B564
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Basic.UEPathUtilityMethods.GetPassiveDownloadResourceIDList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f8f4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GetPassiveDownloadResourceIDList();
	// [Call #1] RVA: 0x10425C64C
	// [Call #2] RVA: 0x101FA6168
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10425C5B4
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10425B308
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10425B564
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function Basic.UEPathUtilityMethods.GetODPakFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f834
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetODPakFileName(struct FString InODPakPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425B764
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10425C64C
	// [Call #11] RVA: 0x101FA6168
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10425C5B4
	// [Call #16] RVA: 0x101FA5F38
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10425B308
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x10516D168

	// Object: Function Basic.UEPathUtilityMethods.GetModName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f790
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetModName(struct UObject* WorldContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425BB28
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10425B764
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10425C64C
	// [Call #18] RVA: 0x101FA6168
	// [Call #19] RVA: 0x101F8BA44
	// [Call #20] RVA: 0x101F8BA44
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10425C5B4
	// [Call #23] RVA: 0x101FA5F38
	// [Call #24] RVA: 0x101F8B9F8
	// [Call #25] RVA: 0x101F8B9F8
	// [Call #26] RVA: 0x106C8459C

	// Object: Function Basic.UEPathUtilityMethods.GetFullModName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10429f64c
	// Params: [ Num(3) Size(0x28) ]
	void GetFullModName(struct UObject* WorldContext, struct FString& MainMod, struct FString& SubMod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10425BE64
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10425BB28
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10425B764

	// Object: Function Basic.UEPathUtilityMethods.FilterOKForCurrentModeString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f440
	// Params: [ Num(6) Size(0x39) ]
	bool FilterOKForCurrentModeString(struct FString CurrentModeString, struct FString CurrentExtraModeString, struct FString ModStringInfo, uint8_t ModeType, int ModeOpenFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x10425C1B0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function Basic.UEPathUtilityMethods.ClearPassiveDownloadResourcePaths
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f42c
	// Params: [ Num(0) Size(0x0) ]
	void ClearPassiveDownloadResourcePaths();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x10425C1B0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function Basic.UEPathUtilityMethods.ClearPassiveDownloadResourceIDList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f418
	// Params: [ Num(0) Size(0x0) ]
	void ClearPassiveDownloadResourceIDList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x10425C1B0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Basic.UEPathUtilityMethods.AddPassiveResourceDownloadFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10429f3a4
	// Params: [ Num(1) Size(0x4) ]
	void AddPassiveResourceDownloadFlag(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10425C620
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10425C1B0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
};

