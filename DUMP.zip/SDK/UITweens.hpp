#pragma once

#include <cstdint>

// Object: Enum UITweens.EUITweenEaseType
enum class EUITweenEaseType : uint8_t
{
	Linear = 0,
	EaseInQuad = 1,
	EaseOutQuad = 2,
	EaseInOutQuad = 3,
	EaseOutInQuad = 4,
	EaseInCubic = 5,
	EaseOutCubic = 6,
	EaseInOutCubic = 7,
	EaseOutInCubic = 8,
	EaseInQuart = 9,
	EaseOutQuart = 10,
	EaseInOutQuart = 11,
	EaseOutInQuart = 12,
	EaseInQuint = 13,
	EaseOutQuint = 14,
	EaseInOutQuint = 15,
	EaseOutInQuint = 16,
	EaseInSine = 17,
	EaseOutSine = 18,
	EaseInOutSine = 19,
	EaseOutInSine = 20,
	EaseInExpo = 21,
	EaseOutExpo = 22,
	EaseInOutExpo = 23,
	EaseOutInExpo = 24,
	EaseInCirc = 25,
	EaseOutCirc = 26,
	EaseInOutCirc = 27,
	EaseOutInCirc = 28,
	EaseInElastic = 29,
	EaseOutElastic = 30,
	EaseInOutElastic = 31,
	EaseOutInElastic = 32,
	EaseInBack = 33,
	EaseOutBack = 34,
	EaseInOutBack = 35,
	EaseOutInBack = 36,
	EaseInBounce = 37,
	EaseOutBounce = 38,
	EaseInOutBounce = 39,
	EaseOutInBounce = 40,
	EUITweenEaseType_MAX = 41
};

// Object: Class UITweens.TweenManager
// Size: 0x50 (Inherited: 0x28)
struct UTweenManager : UObject
{
	uint8_t Pad_0x28[0x28]; // 0x28(0x28)


	// Object: Function UITweens.TweenManager.TweenScale
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x102beecdc
	// Params: [ Num(5) Size(0x20) ]
	void TweenScale(struct UWidget* Widget, struct FVector2D From, struct FVector2D To, float Timespan, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BEE068
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function UITweens.TweenManager.TweenPosition
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x102beeb78
	// Params: [ Num(5) Size(0x20) ]
	void TweenPosition(struct UWidget* Widget, struct FVector2D From, struct FVector2D To, float Timespan, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BEDF98
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UITweens.TweenManager.TweenAlpha
	// Flags: [Final|Native|Public]
	// Offset: 0x102beea10
	// Params: [ Num(5) Size(0x18) ]
	void TweenAlpha(struct UWidget* Widget, float From, float To, float Timespan, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BEE138
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UITweens.TweenManager.Tick
	// Flags: [Final|Native|Public]
	// Offset: 0x102bee98c
	// Params: [ Num(1) Size(0x4) ]
	void Tick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102BEE138
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
};

