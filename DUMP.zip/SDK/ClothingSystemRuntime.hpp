#pragma once

#include <cstdint>

// Object: Enum ClothingSystemRuntime.EClothingWindMethod
enum class EClothingWindMethod : uint8_t
{
	Legacy = 0,
	Accurate = 1,
	EClothingWindMethod_MAX = 2
};

// Object: Enum ClothingSystemRuntime.EClothTetherMode
enum class EClothTetherMode : uint8_t
{
	Geodesic = 0,
	Simple = 1,
	EClothTetherMode_MAX = 2
};

// Object: Enum ClothingSystemRuntime.EClothSolverMode
enum class EClothSolverMode : uint8_t
{
	GaussSeidel = 0,
	Jacobi = 1,
	EClothSolverMode_MAX = 2
};

// Object: Enum ClothingSystemRuntime.MaskTarget_PhysMesh
enum class EMaskTarget_PhysMesh : uint8_t
{
	None = 0,
	MaxDistance = 1,
	BackstopDistance = 2,
	BackstopRadius = 3,
	AnimDriveMultiplier = 4,
	SelfCollisionMask = 5,
	PhysicsStiffness = 6,
	ShapeMatchingMask = 7,
	ClothLayerMask = 8,
	AnimDriveStiffnessWeightMap = 9,
	AnimDriveDampingWeightMap = 10,
	MaskTarget_MAX = 11
};

// Object: ScriptStruct ClothingSystemRuntime.ClothConfig
// Size: 0x160 (Inherited: 0x0)
struct FClothConfig
{
	struct FClothConstraintSetup VerticalConstraintConfig; // 0x0(0x10)
	struct FClothConstraintSetup HorizontalConstraintConfig; // 0x10(0x10)
	struct FClothConstraintSetup BendConstraintConfig; // 0x20(0x10)
	struct FClothConstraintSetup ShearConstraintConfig; // 0x30(0x10)
	struct FClothWindConfig WindConfig; // 0x40(0xC)
	struct FClothSelfCollisionConfig SelfCollisionConfig; // 0x4C(0xC)
	struct FClothDampingConfig DampingConfig; // 0x58(0x2C)
	struct FClothInertiaConfig InertiaConfig; // 0x84(0x24)
	struct FClothSolverConfig SolverConfig; // 0xA8(0x34)
	struct FClothTeleportConfig TeleportConfig; // 0xDC(0x10)
	struct FClothTetherConfig TetherConfig; // 0xEC(0xC)
	struct FClothCollisionConfig CollisionConfig; // 0xF8(0x8)
	struct FClothVolumeConfig VolumeConfig; // 0x100(0x10)
	struct FClothBendingElementConfig BendingElementConfig; // 0x110(0x18)
	struct FClothAnimDriveConfig AnimDriveConfig; // 0x128(0x1C)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
	struct FSoftObjectPath ImportedConfigAssetPath; // 0x148(0x18)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothAnimDriveConfig
// Size: 0x1C (Inherited: 0x0)
struct FClothAnimDriveConfig
{
	bool bAnimDriveEnabled; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float AnimDriveStiffnessLow; // 0x4(0x4)
	float AnimDriveStiffnessHigh; // 0x8(0x4)
	float AnimDriveDampingLow; // 0xC(0x4)
	float AnimDriveDampingHigh; // 0x10(0x4)
	float AnimDriveMaxRelativeVelocity; // 0x14(0x4)
	float AnimDriveMultiplier; // 0x18(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothBendingElementConfig
// Size: 0x18 (Inherited: 0x0)
struct FClothBendingElementConfig
{
	bool bEnableBendingElement; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float BendingElementStiffness; // 0x4(0x4)
	float BendingElementDamping; // 0x8(0x4)
	float BendingElementBucklingRatio; // 0xC(0x4)
	float BendingElementBucklingStiffness; // 0x10(0x4)
	float FlatnessRatio; // 0x14(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothVolumeConfig
// Size: 0x10 (Inherited: 0x0)
struct FClothVolumeConfig
{
	bool bEnableVolumeConstraints; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float VolumeConstraintStiffness; // 0x4(0x4)
	float VolumeConstraintScaleMultiplier; // 0x8(0x4)
	int VolumeConstraintSampleStride; // 0xC(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothCollisionConfig
// Size: 0x8 (Inherited: 0x0)
struct FClothCollisionConfig
{
	float CollisionThickness; // 0x0(0x4)
	bool bEnableContinuousCollision; // 0x4(0x1)
	bool bEnableEnvironmentalCollision; // 0x5(0x1)
	bool bEnableGroundCollision; // 0x6(0x1)
	uint8_t Pad_0x7[0x1]; // 0x7(0x1)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothTetherConfig
// Size: 0xC (Inherited: 0x0)
struct FClothTetherConfig
{
	bool bEnableTether; // 0x0(0x1)
	uint8_t TetherMode; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	float TetherStiffness; // 0x4(0x4)
	float TetherLimit; // 0x8(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothTeleportConfig
// Size: 0x10 (Inherited: 0x0)
struct FClothTeleportConfig
{
	bool bEnableAutoTeleportDetection; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float TeleportThreshold; // 0x4(0x4)
	float ResetThreshold; // 0x8(0x4)
	float RotationThreshold; // 0xC(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothSolverConfig
// Size: 0x34 (Inherited: 0x0)
struct FClothSolverConfig
{
	uint8_t SolverMode; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float JacobiSOR; // 0x4(0x4)
	bool bUseGPU; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float SolverFrequency; // 0xC(0x4)
	float StiffnessFrequency; // 0x10(0x4)
	float GravityScale; // 0x14(0x4)
	bool bUseXPBD; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int XpbdIterations; // 0x1C(0x4)
	float MaxStiffness; // 0x20(0x4)
	float MaxParticleDisplacement; // 0x24(0x4)
	bool bEnableAdaptiveFrequency; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float AdaptiveFrequencyMin; // 0x2C(0x4)
	float AdaptiveFrequencyMax; // 0x30(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothInertiaConfig
// Size: 0x24 (Inherited: 0x0)
struct FClothInertiaConfig
{
	struct FVector LinearInertiaScale; // 0x0(0xC)
	struct FVector AngularInertiaScale; // 0xC(0xC)
	struct FVector CentrifugalInertiaScale; // 0x18(0xC)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothDampingConfig
// Size: 0x2C (Inherited: 0x0)
struct FClothDampingConfig
{
	struct FVector Damping; // 0x0(0xC)
	struct FVector LinearDrag; // 0xC(0xC)
	struct FVector AngularDrag; // 0x18(0xC)
	float Friction; // 0x24(0x4)
	float AnimDriveDamping; // 0x28(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothSelfCollisionConfig
// Size: 0xC (Inherited: 0x0)
struct FClothSelfCollisionConfig
{
	float SelfCollisionRadius; // 0x0(0x4)
	float SelfCollisionStiffness; // 0x4(0x4)
	float SelfCollisionCullScale; // 0x8(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothWindConfig
// Size: 0xC (Inherited: 0x0)
struct FClothWindConfig
{
	uint8_t WindMethod; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float WindDragCoefficient; // 0x4(0x4)
	float WindLiftCoefficient; // 0x8(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothConstraintSetup
// Size: 0x10 (Inherited: 0x0)
struct FClothConstraintSetup
{
	float Stiffness; // 0x0(0x4)
	float StiffnessMultiplier; // 0x4(0x4)
	float StretchLimit; // 0x8(0x4)
	float CompressionLimit; // 0xC(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothLODData
// Size: 0x268 (Inherited: 0x0)
struct FClothLODData
{
	struct FClothPhysicalMeshData PhysicalMeshData; // 0x0(0x218)
	struct FClothCollisionData CollisionData; // 0x218(0x30)
	uint8_t Pad_0x248[0x20]; // 0x248(0x20)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothPhysicalMeshData
// Size: 0x218 (Inherited: 0x0)
struct FClothPhysicalMeshData
{
	struct TArray<struct FVector> Vertices; // 0x0(0x10)
	struct TArray<struct FVector> Normals; // 0x10(0x10)
	struct TArray<uint32_t> Indices; // 0x20(0x10)
	struct TArray<float> MaxDistances; // 0x30(0x10)
	struct TArray<float> BackstopDistances; // 0x40(0x10)
	struct TArray<float> BackstopRadiuses; // 0x50(0x10)
	struct TArray<float> AnimDriveMultipliers; // 0x60(0x10)
	struct TArray<float> SelfCollisionMask; // 0x70(0x10)
	struct TArray<float> PhysicsStiffness; // 0x80(0x10)
	struct TArray<float> ShapeMatchingMask; // 0x90(0x10)
	struct TArray<struct FVector2D> UVs; // 0xA0(0x10)
	struct TArray<float> InverseMasses; // 0xB0(0x10)
	struct TArray<struct FClothVertBoneData> BoneData; // 0xC0(0x10)
	int MaxBoneWeights; // 0xD0(0x4)
	int NumFixedVerts; // 0xD4(0x4)
	int OriginalSectionVertexCount; // 0xD8(0x4)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
	struct TArray<uint32_t> SelfCollisionIndices; // 0xE0(0x10)
	struct TArray<uint32_t> ShapeMatchingIndices; // 0xF0(0x10)
	int NumShapeMatchingRigidBodies; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
	struct TArray<uint32_t> ShapeMatchingRigidBodyOffsets; // 0x108(0x10)
	struct TArray<uint32_t> ShapeMatchingRigidBodyIds; // 0x118(0x10)
	struct TArray<float> ShapeMatchingRestPositions; // 0x128(0x10)
	struct TArray<float> ShapeMatchingInitialCenters; // 0x138(0x10)
	struct TArray<struct FIntPoint> VirtualEdges; // 0x148(0x10)
	struct TArray<float> ClothLayerMask; // 0x158(0x10)
	struct TArray<float> AnimDriveStiffnessWeightMap; // 0x168(0x10)
	struct TArray<float> AnimDriveDampingWeightMap; // 0x178(0x10)
	struct TArray<struct FVolumeConstraint> VolumeConstraints; // 0x188(0x10)
	struct TArray<int> ParticleToTetrahedronMap; // 0x198(0x10)
	int NumVolumeConstraints; // 0x1A8(0x4)
	float VolumeConstraintScale; // 0x1AC(0x4)
	int VolumeConstraintSampleStride; // 0x1B0(0x4)
	uint8_t Pad_0x1B4[0x4]; // 0x1B4(0x4)
	struct TArray<uint32_t> ClothLayerOffsets; // 0x1B8(0x10)
	int NumClothLayers; // 0x1C8(0x4)
	uint8_t Pad_0x1CC[0x4]; // 0x1CC(0x4)
	struct TArray<uint32_t> ParticleVolumeConstraintOffsets; // 0x1D0(0x10)
	struct TArray<uint32_t> ParticleVolumeConstraintData; // 0x1E0(0x10)
	int NumBendingElements; // 0x1F0(0x4)
	uint8_t Pad_0x1F4[0x4]; // 0x1F4(0x4)
	struct TArray<int> BendingElementIndices; // 0x1F8(0x10)
	struct TArray<float> BendingElementRestAngles; // 0x208(0x10)
};

// Object: ScriptStruct ClothingSystemRuntime.VolumeConstraint
// Size: 0x18 (Inherited: 0x0)
struct FVolumeConstraint
{
	uint32_t Particle; // 0x0(0x4)
	uint32_t Triangle[0x3]; // 0x4(0xC)
	float RestVolume; // 0x10(0x4)
	float Scale; // 0x14(0x4)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothVertBoneData
// Size: 0x34 (Inherited: 0x0)
struct FClothVertBoneData
{
	int NumInfluences; // 0x0(0x4)
	uint16_t BoneIndices[0x8]; // 0x4(0x10)
	float BoneWeights[0x8]; // 0x14(0x20)
};

// Object: ScriptStruct ClothingSystemRuntime.ClothParameterMask_PhysMesh
// Size: 0x30 (Inherited: 0x0)
struct FClothParameterMask_PhysMesh
{
	struct FName MaskName; // 0x0(0x8)
	uint8_t CurrentTarget; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float MaxValue; // 0xC(0x4)
	float MinValue; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<float> Values; // 0x18(0x10)
	bool bEnabled; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: Class ClothingSystemRuntime.ClothBoneDataAsset
// Size: 0x80 (Inherited: 0x28)
struct UClothBoneDataAsset : UObject
{
	struct TArray<struct FClothVertBoneData> BoneData; // 0x28(0x10)
	struct TArray<struct FName> UsedBoneNames; // 0x38(0x10)
	int MaxBoneWeights; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct FName ReferenceBoneName; // 0x50(0x8)
	int NumVertices; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct FSoftObjectPath SourceMeshPath; // 0x60(0x18)
	int SourceLod; // 0x78(0x4)
	int SourceSection; // 0x7C(0x4)
};

// Object: Class ClothingSystemRuntime.ClothConfigAsset
// Size: 0x190 (Inherited: 0x30)
struct UClothConfigAsset : UDataAsset
{
	struct FClothConfig ConfigData; // 0x30(0x160)
};

// Object: Class ClothingSystemRuntime.ClothingAssetCustomData
// Size: 0x28 (Inherited: 0x28)
struct UClothingAssetCustomData : UObject
{
};

// Object: Class ClothingSystemRuntime.ClothingAsset
// Size: 0x270 (Inherited: 0x48)
struct UClothingAsset : UClothingAssetBase
{
	struct UPhysicsAsset* PhysicsAsset; // 0x48(0x8)
	uint8_t DefaultSkinningMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	struct UClothBoneDataAsset* AlternateBoneDataAsset; // 0x58(0x28)
	struct FClothConfig ClothConfig; // 0x80(0x160)
	struct TArray<struct FClothLODData> LODData; // 0x1E0(0x10)
	struct TArray<int> LodMap; // 0x1F0(0x10)
	struct TArray<struct FName> UsedBoneNames; // 0x200(0x10)
	struct TArray<int> UsedBoneIndices; // 0x210(0x10)
	int ReferenceBoneIndex; // 0x220(0x4)
	uint8_t Pad_0x224[0x4]; // 0x224(0x4)
	struct TArray<struct FClothVertBoneData> AlternateBoneData; // 0x228(0x10)
	int AlternateMaxBoneWeights; // 0x238(0x4)
	uint8_t Pad_0x23C[0x4]; // 0x23C(0x4)
	struct TArray<struct FName> AlternateUsedBoneNames; // 0x240(0x10)
	struct TArray<int> AlternateUsedBoneIndices; // 0x250(0x10)
	int AlternateReferenceBoneIndex; // 0x260(0x4)
	uint8_t Pad_0x264[0x4]; // 0x264(0x4)
	struct UClothingAssetCustomData* customData; // 0x268(0x8)
};

// Object: Class ClothingSystemRuntime.ClothingSimulationFactoryNv
// Size: 0x28 (Inherited: 0x28)
struct UClothingSimulationFactoryNv : UClothingSimulationFactory
{
};

// Object: Class ClothingSystemRuntime.ClothMaskAsset
// Size: 0x70 (Inherited: 0x30)
struct UClothMaskAsset : UDataAsset
{
	struct FClothParameterMask_PhysMesh MaskData; // 0x30(0x30)
	struct FName SourceAssetName; // 0x60(0x8)
	int SourceLodIndex; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

