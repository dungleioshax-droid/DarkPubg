#pragma once

#include <cstdint>

// Object: Class CreativeLua.CreativeBridgeLuaVM
// Size: 0x470 (Inherited: 0x440)
struct UCreativeBridgeLuaVM : UCreativeLuaVM
{
	uint8_t Pad_0x440[0x8]; // 0x440(0x8)
	struct UObject* LuaVMManager; // 0x448(0x8)
	struct FString RegisterUGCVMFunctionHandlerName; // 0x450(0x10)
	struct FString UGCVMPostInitFunctionHandlerName; // 0x460(0x10)


	// Object: Function CreativeLua.CreativeBridgeLuaVM.UGCLuaError
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10252907c
	// Params: [ Num(1) Size(0x4) ]
	void UGCLuaError(int errCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102522680
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function CreativeLua.CreativeBridgeLuaVM.SetUGCSuspendStateFix
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102528ff8
	// Params: [ Num(1) Size(0x1) ]
	void SetUGCSuspendStateFix(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102523900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102522680
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function CreativeLua.CreativeBridgeLuaVM.RegisterSluaCallUgcluaEventHandler
	// Flags: [Final|Native|Public]
	// Offset: 0x102528fe4
	// Params: [ Num(0) Size(0x0) ]
	void RegisterSluaCallUgcluaEventHandler();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102523900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102522680
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function CreativeLua.CreativeBridgeLuaVM.PostInit
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102528fc8
	// Params: [ Num(0) Size(0x0) ]
	void PostInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102523900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102522680
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function CreativeLua.CreativeBridgeLuaVM.GetUGCSuspendStateFix
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102528f94
	// Params: [ Num(1) Size(0x1) ]
	bool GetUGCSuspendStateFix();
	// [Call #1] RVA: 0x10252391C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102523900
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102522680
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class CreativeLua.CreativeEnvLuaVM
// Size: 0x80 (Inherited: 0x28)
struct UCreativeEnvLuaVM : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
};

// Object: Class CreativeLua.CreativeEnvLuaVMFactory
// Size: 0x28 (Inherited: 0x28)
struct UCreativeEnvLuaVMFactory : UBlueprintFunctionLibrary
{

	// Object: Function CreativeLua.CreativeEnvLuaVMFactory.CreateCreativeEnvLuaVM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025294c8
	// Params: [ Num(3) Size(0x20) ]
	struct UCreativeEnvLuaVM* CreateCreativeEnvLuaVM(struct FString InLuaFilePath, struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025239B4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x10518366C
	// [Call #13] RVA: 0x10518559C
};

