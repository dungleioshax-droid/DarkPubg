#pragma once

#include <cstdint>

// Object: Enum BlockyLua.EBlockyEditorShortcutKey
enum class EBlockyEditorShortcutKey : uint8_t
{
	None = 0,
	Clone = 1,
	Copy = 2,
	Cut = 3,
	Paste = 4,
	Undo = 5,
	Redo = 6,
	Delete = 7,
	Search = 8,
	Save = 9,
	Log = 10,
	Escape = 11,
	EBlockyEditorShortcutKey_MAX = 12
};

// Object: Enum BlockyLua.ESearchResultVisibleType
enum class ESearchResultVisibleType : uint8_t
{
	SRVT_ShowAll = 0,
	SRVT_OnlyBlocks = 1,
	SRVT_OnlyGraphs = 2,
	SRVT_OnlyPresets = 3,
	SRVT_MAX = 4
};

// Object: Enum BlockyLua.BLOCKYLUA_AUTO_SCROLL_TYPE
enum class EBLOCKYLUA_AUTO_SCROLL_TYPE : uint8_t
{
	LEFT_RIGHT = 0,
	PING_PONG = 1,
	BLOCKYLUA_AUTO_SCROLL_MAX = 2
};

// Object: ScriptStruct BlockyLua.IntArrayWrapper
// Size: 0x10 (Inherited: 0x0)
struct FIntArrayWrapper
{
	struct TArray<int> Values; // 0x0(0x10)
};

// Object: ScriptStruct BlockyLua.SlotData
// Size: 0x20 (Inherited: 0x0)
struct FSlotData
{
	struct UBlockBase* LinkedSlotHost; // 0x0(0x8)
	uint8_t Pad_0x8[0x18]; // 0x8(0x18)
};

// Object: Class BlockyLua.Blocky3DVarWidget
// Size: 0x2C8 (Inherited: 0x260)
struct UBlocky3DVarWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)
	bool IsBPInit; // 0x288(0x1)
	uint8_t Pad_0x289[0x7]; // 0x289(0x7)
	struct FString X; // 0x290(0x10)
	struct FString Y; // 0x2A0(0x10)
	struct FString Z; // 0x2B0(0x10)
	int StartSlotIdx; // 0x2C0(0x4)
	uint8_t Pad_0x2C4[0x4]; // 0x2C4(0x4)


	// Object: Function BlockyLua.Blocky3DVarWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbcb78
	// Params: [ Num(0) Size(0x0) ]
	void SetResult();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function BlockyLua.Blocky3DVarWidget.InitText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	void InitText(float X, float Y, float Z);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.Blocky3DVarWidget.CleanNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbcaa8
	// Params: [ Num(2) Size(0x20) ]
	struct FString CleanNumber(struct FString Input);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B8D89C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyBlockDisplayWidget
// Size: 0x288 (Inherited: 0x260)
struct UBlockyBlockDisplayWidget : UUserWidget
{
	uint8_t Pad_0x260[0x10]; // 0x260(0x10)
	struct UBlockyGraphData* BlockyGraphData; // 0x270(0x8)
	struct FVector2D BlockSize; // 0x278(0x8)
	bool Movable; // 0x280(0x1)
	uint8_t Pad_0x281[0x7]; // 0x281(0x7)
};

// Object: Class BlockyLua.BlockyBlockDisplayWidget_Custom
// Size: 0x2B0 (Inherited: 0x288)
struct UBlockyBlockDisplayWidget_Custom : UBlockyBlockDisplayWidget
{
	struct UCustomConfig* Config; // 0x288(0x8)
	struct FString BlockName; // 0x290(0x10)
	struct TArray<struct FString> ParamName; // 0x2A0(0x10)


	// Object: Function BlockyLua.BlockyBlockDisplayWidget_Custom.UpdateName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbcf0c
	// Params: [ Num(1) Size(0x10) ]
	void UpdateName(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B8E738
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyBlockDisplayWidget_Custom.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbce90
	// Params: [ Num(1) Size(0x1) ]
	void Init(enum class ECustomBlockType Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B8E5C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B8E738
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyBlockDisplayWidget_Preset
// Size: 0x288 (Inherited: 0x288)
struct UBlockyBlockDisplayWidget_Preset : UBlockyBlockDisplayWidget
{

	// Object: Function BlockyLua.BlockyBlockDisplayWidget_Preset.InitPreset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbd194
	// Params: [ Num(1) Size(0x8) ]
	void InitPreset(struct UBlockyGraphWidget* HostGraphWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B8E9A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x106BBD4AC
	// [Call #8] RVA: 0x106B8F560
};

// Object: Class BlockyLua.BlockyBlockDisplayWidget_Variable
// Size: 0x298 (Inherited: 0x288)
struct UBlockyBlockDisplayWidget_Variable : UBlockyBlockDisplayWidget
{
	struct UNamedVar* NamedVar; // 0x288(0x8)
	bool HasSettingIcon; // 0x290(0x1)
	bool HasCopyIcon; // 0x291(0x1)
	bool IsEditingDisplay; // 0x292(0x1)
	uint8_t Pad_0x293[0x5]; // 0x293(0x5)


	// Object: Function BlockyLua.BlockyBlockDisplayWidget_Variable.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbd3a8
	// Params: [ Num(0) Size(0x0) ]
	void Init();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function BlockyLua.BlockyBlockDisplayWidget_Variable.CalculateDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106bbd374
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D CalculateDrawSize();
	// [Call #1] RVA: 0x106B8F560
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class BlockyLua.BlockyBlockListWidget
// Size: 0x2A8 (Inherited: 0x260)
struct UBlockyBlockListWidget : UUserWidget
{
	uint8_t Pad_0x260[0x28]; // 0x260(0x28)
	struct UBlockyBlockWindowWidget* HostWindow; // 0x288(0x8)
	float HorizontalMoveCheckDelta; // 0x290(0x4)
	float VerticalMoveCheckDelta; // 0x294(0x4)
	bool IsOpenComment; // 0x298(0x1)
	uint8_t Pad_0x299[0x7]; // 0x299(0x7)
	struct UBlockyBlockListItemObject* PointAtListItem; // 0x2A0(0x8)
};

// Object: Class BlockyLua.BlockyBlockWindowWidget
// Size: 0x278 (Inherited: 0x260)
struct UBlockyBlockWindowWidget : UUserWidget
{
	struct UBlockyGraphData* GraphWidget; // 0x260(0x8)
	struct UBlockyBlockListWidget* WidgetToPaint; // 0x268(0x8)
	uint8_t Pad_0x270[0x8]; // 0x270(0x8)


	// Object: Function BlockyLua.BlockyBlockWindowWidget.SetWidgetVariableToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetWidgetVariableToShow(struct UBlockyMenuItemObject_Variable* item_Variable);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyBlockWindowWidget.SetWidgetCustomToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetWidgetCustomToShow(struct UBlockyMenuItemObject_Custom* item_Custom);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyBlockWindowWidget.SetWidgetCommonToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetWidgetCommonToShow(struct UBlockyMenuItemObject* MenuItem);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyBlockWindowWidget.SetWidgetBPToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetWidgetBPToShow(struct UUserWidget* Widget);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyBooleanWidget
// Size: 0x288 (Inherited: 0x260)
struct UBlockyBooleanWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)


	// Object: Function BlockyLua.BlockyBooleanWidget.SetText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyBooleanWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbda4c
	// Params: [ Num(2) Size(0x20) ]
	void SetResult(struct FString displayValue, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B90884
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10508F76C
};

// Object: Class BlockyLua.BlockyCategoryItemWidget
// Size: 0x2A8 (Inherited: 0x260)
struct UBlockyCategoryItemWidget : UUserWidget
{
	int Index; // 0x260(0x4)
	uint8_t Pad_0x264[0x4]; // 0x264(0x4)
	struct FText Name; // 0x268(0x18)
	bool IsScrolling; // 0x280(0x1)
	uint8_t Pad_0x281[0xF]; // 0x281(0xF)
	struct UBlockyCategoryWidget* HostWidget; // 0x290(0x8)
	struct UScrollBox* SubScrollBox; // 0x298(0x8)
	uint8_t Pad_0x2A0[0x8]; // 0x2A0(0x8)


	// Object: Function BlockyLua.BlockyCategoryItemWidget.SetSelected
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool IsSelected);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyCategoryItemWidget.OnScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbddc8
	// Params: [ Num(0) Size(0x0) ]
	void OnScroll();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyCategoryItemWidget.OnClick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbddb4
	// Params: [ Num(0) Size(0x0) ]
	void OnClick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyCategoryItemWidget.InitWithItemObject
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitWithItemObject(struct UBlockyCategoryItemObject* Item);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyCategoryItemWidget.InitTextToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitTextToShow();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyCategoryWidget
// Size: 0x2A0 (Inherited: 0x260)
struct UBlockyCategoryWidget : UUserWidget
{
	struct UBlockyGraphData* GraphWidget; // 0x260(0x8)
	struct UObject* CategoryItemWidgetType; // 0x268(0x8)
	struct FText CategoryName; // 0x270(0x18)
	uint8_t Pad_0x288[0x8]; // 0x288(0x8)
	struct UScrollBox* SubScrollBox; // 0x290(0x8)
	float CurrentScrollOffset; // 0x298(0x4)
	uint8_t Pad_0x29C[0x4]; // 0x29C(0x4)


	// Object: Function BlockyLua.BlockyCategoryWidget.GetCurrentCategoryNameWithVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbe0bc
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetCurrentCategoryNameWithVariable();
	// [Call #1] RVA: 0x106B914C4
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x106BBE474
	// [Call #11] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyCategoryWidget.GetCategoryContainer
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetCategoryContainer();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyColorPickerWidget
// Size: 0x2A8 (Inherited: 0x260)
struct UBlockyColorPickerWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)
	struct TArray<struct FLinearColor> RecommendedColors; // 0x288(0x10)
	struct TArray<struct FLinearColor> StoredColors; // 0x298(0x10)


	// Object: Function BlockyLua.BlockyColorPickerWidget.SetResult
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x106bbe2d8
	// Params: [ Num(1) Size(0x10) ]
	void SetResult(struct FLinearColor& Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B91698
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyColorPickerWidget.SetColor
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetColor(struct FLinearColor& Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyColorPickerWidget.LoadColors
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbe2c4
	// Params: [ Num(0) Size(0x0) ]
	void LoadColors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B91698
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
};

// Object: Class BlockyLua.BlockyEditor
// Size: 0x470 (Inherited: 0x260)
struct UBlockyEditor : UUserWidget
{
	uint8_t Pad_0x260[0x8]; // 0x260(0x8)
	struct UBlockyGraphData* GraphData; // 0x268(0x8)
	bool IsSlotPreset; // 0x270(0x1)
	bool IsLastPresetCategory; // 0x271(0x1)
	uint8_t Pad_0x272[0x6]; // 0x272(0x6)
	struct FString LastPresetCategory; // 0x278(0x10)
	struct UWidget* MainPanel; // 0x288(0x8)
	bool IsCustomVarVisable; // 0x290(0x1)
	uint8_t Pad_0x291[0x7]; // 0x291(0x7)
	struct UBlockyEnumWidget* EnumWidget; // 0x298(0x8)
	struct UBlockyStringWidget* StringWidget; // 0x2A0(0x8)
	struct UBlockyBooleanWidget* BooleanWidget; // 0x2A8(0x8)
	struct UBlockyFloatWidget* FloatWidget; // 0x2B0(0x8)
	struct UBlocky3DVarWidget* Var3DWidget; // 0x2B8(0x8)
	struct UBlockyIntegerWidget* IntegerWidget; // 0x2C0(0x8)
	struct UBlockyColorPickerWidget* ColorWidget; // 0x2C8(0x8)
	struct UBlockyPresetWidget* PresetWidget; // 0x2D0(0x8)
	struct UBlockySelectFromSceneWidget* SelectFromSceneWidget; // 0x2D8(0x8)
	struct TArray<struct UBlockyMenuItemObject*> CurrentMenuItems; // 0x2E0(0x10)
	struct UBlockyMenuItemObject* CurrentSerchMenuItem; // 0x2F0(0x8)
	struct UBlockyBlockListItemObject* ListItemSerchAtPoint; // 0x2F8(0x8)
	struct UMaterial* AnimateMaterial; // 0x300(0x8)
	struct UMaterialInstance* DeleteUIDockingMaterial; // 0x308(0x8)
	struct UMaterialInstance* DeleteRangeUIDockingMaterial; // 0x310(0x8)
	struct UMaterialInstance* DeleteUIBgDockingMaterial; // 0x318(0x8)
	struct UBlockyMenuWidget* MenuWidget; // 0x320(0x8)
	struct UBlockyCategoryWidget* CategoryWidget; // 0x328(0x8)
	struct UBlockyBlockWindowWidget* BlockWindowWidget; // 0x330(0x8)
	struct UBlockyLogWidget* BlockyLogWidget; // 0x338(0x8)
	struct TArray<struct UWidget*> ShortcutBlockingWidgets; // 0x340(0x10)
	float PresetTagTitleY; // 0x350(0x4)
	uint8_t Pad_0x354[0x4]; // 0x354(0x4)
	struct UBlockyMenuItemWidget* CurrentMenuItemWidget; // 0x358(0x8)
	struct TMap<struct FString, struct UBlockyBlockListItemObject*> TypeFilterItems; // 0x360(0x50)
	struct TMap<struct FString, struct UBlockyBlockListItemObject*> TypeFilterArrayItems; // 0x3B0(0x50)
	struct TArray<struct UBlockyMenuItemObject_TypeFilter*> TypeFilterMenus; // 0x400(0x10)
	struct TArray<struct UBlockyCategoryItemObject*> CurrentSlotPresetCategorys; // 0x410(0x10)
	uint8_t Pad_0x420[0x50]; // 0x420(0x50)


	// Object: Function BlockyLua.BlockyEditor.UpdateTriggerGroups
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void UpdateTriggerGroups();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.UpdateSearchPanel
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void UpdateSearchPanel();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.UpdateSearchButtonVisible
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void UpdateSearchButtonVisible(bool IsShowSearchButton);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.TryBackToVariableOrCustomPanel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x106bbf1b0
	// Params: [ Num(1) Size(0x1) ]
	bool TryBackToVariableOrCustomPanel();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyEditor.ShowPresetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbf134
	// Params: [ Num(1) Size(0x8) ]
	void ShowPresetAnimation(struct UPresetDesc* PresetDesc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BAFB58
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyEditor.SetWidgetBPToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	void SetWidgetBPToShow(struct UUserWidget* Widget, bool HideCategory);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.SetMenuWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbf0b8
	// Params: [ Num(1) Size(0x8) ]
	void SetMenuWidget(struct UBlockyMenuWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97DA0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BAFB58
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyEditor.SetCategoryWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbf03c
	// Params: [ Num(1) Size(0x8) ]
	void SetCategoryWidget(struct UBlockyCategoryWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97E44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97DA0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BAFB58
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function BlockyLua.BlockyEditor.SetBlockLogWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbefc0
	// Params: [ Num(1) Size(0x8) ]
	void SetBlockLogWidget(struct UBlockyLogWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97EF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97E44
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97DA0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BAFB58

	// Object: Function BlockyLua.BlockyEditor.SetBlockListWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbef44
	// Params: [ Num(1) Size(0x8) ]
	void SetBlockListWidget(struct UBlockyBlockWindowWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97E9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97EF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97E44
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B97DA0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyEditor.ResetAsyncWidgetHandleMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbef30
	// Params: [ Num(0) Size(0x0) ]
	void ResetAsyncWidgetHandleMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97E9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97EF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97E44
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B97DA0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyEditor.OnUpdateUndoRedoState
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x2) ]
	void OnUpdateUndoRedoState(bool HasUndoCommands, bool HasRedoCommands);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.OnShowTips
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnShowTips(struct FText& Tips);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.OnShowPresetPanelHandler
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbeeac
	// Params: [ Num(1) Size(0x1) ]
	void OnShowPresetPanelHandler(bool IsShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BAB008
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97E9C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97EF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B97E44
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyEditor.LoadWidgetAsync
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bbecb0
	// Params: [ Num(3) Size(0x30) ]
	void LoadWidgetAsync(struct FString WidgetName, struct FString WidgetPath, DelegateProperty& Delegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106BAFD84
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyEditor.LoadMaterialInterface
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbebbc
	// Params: [ Num(2) Size(0x18) ]
	struct UMaterialInterface* LoadMaterialInterface(struct FString AnimationPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106BB0118
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101FD9E48
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x106BAFD84
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyEditor.IsShowExplain
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void IsShowExplain(bool bFlag);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.IsCloseComment
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void IsCloseComment(bool bFlag);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.GetSaveCooldownDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bbeb88
	// Params: [ Num(1) Size(0x4) ]
	float GetSaveCooldownDuration();
	// [Call #1] RVA: 0x106BAFD68
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x106BB0118
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FD9E48
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F8122C

	// Object: Function BlockyLua.BlockyEditor.GetLocaleString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bbeab8
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetLocaleString(struct FString KeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BAFD34
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BAFD68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106BB0118
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyEditor.GetCurrentMenuItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bbea7c
	// Params: [ Num(1) Size(0x8) ]
	struct UBlockyMenuItemObject* GetCurrentMenuItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BAFD34
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BAFD68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106BB0118
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyEditor.CollectListItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbe9f8
	// Params: [ Num(1) Size(0x1) ]
	void CollectListItem(bool bCollect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BAFD34
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106BAFD68
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106BB0118

	// Object: Function BlockyLua.BlockyEditor.BP_OnShowTools
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void BP_OnShowTools(struct TArray<uint8_t>& ButtonTypes);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.BP_OnBlockyEditorShortcut
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void BP_OnBlockyEditorShortcut(uint8_t ShortCutKey);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEditor.AddChildBluckyWidget
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void AddChildBluckyWidget(struct UUserWidget* Widget);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyEnumWidget
// Size: 0x288 (Inherited: 0x260)
struct UBlockyEnumWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)


	// Object: Function BlockyLua.BlockyEnumWidget.SetShowDisplayItems
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x50) ]
	void SetShowDisplayItems(struct TMap<struct FName, struct FText>& Names);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyEnumWidget.SetResultWithName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbfacc
	// Params: [ Num(1) Size(0x8) ]
	void SetResultWithName(struct FName Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B918A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x101F82D88
	// [Call #9] RVA: 0x10516EACC
	// [Call #10] RVA: 0x101F8130C
};

// Object: Class BlockyLua.BlockyFloatWidget
// Size: 0x288 (Inherited: 0x260)
struct UBlockyFloatWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)


	// Object: Function BlockyLua.BlockyFloatWidget.SetText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyFloatWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbfe30
	// Params: [ Num(1) Size(0x10) ]
	void SetResult(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B919E8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyFloatWidget.CleanNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bbfd60
	// Params: [ Num(2) Size(0x20) ]
	struct FString CleanNumber(struct FString Input);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B91B78
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B919E8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyGraphWidget
// Size: 0x300 (Inherited: 0x260)
struct UBlockyGraphWidget : UUserWidget
{
	uint8_t Pad_0x260[0x8]; // 0x260(0x8)
	struct UBlockyGraphData* BlockyGraphData; // 0x268(0x8)
	struct UBlockyEditor* HostEditor; // 0x270(0x8)
	struct FGraphSettingMap GraphSettingsMap; // 0x278(0x50)
	struct TArray<int> defaultTags; // 0x2C8(0x10)
	bool IsOnTouch; // 0x2D8(0x1)
	bool IsMoveGraphOnly; // 0x2D9(0x1)
	uint8_t Pad_0x2DA[0x6]; // 0x2DA(0x6)
	DelegateProperty OnAsyncLoadBinCompletedHandle; // 0x2E0(0x10)
	struct UDeleteBlockUI* DeleteBlockUI; // 0x2F0(0x8)
	bool IsShowSaveTemplate; // 0x2F8(0x1)
	uint8_t Pad_0x2F9[0x7]; // 0x2F9(0x7)


	// Object: Function BlockyLua.BlockyGraphWidget.ViewPosToCanvasPos
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bc2668
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D ViewPosToCanvasPos(struct FVector2D Postion);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98230
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.UpdateVariableItemNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc2604
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FText> UpdateVariableItemNames();
	// [Call #1] RVA: 0x106B9718C
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B98230
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.UpdateTriggerGroups
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc25f0
	// Params: [ Num(0) Size(0x0) ]
	void UpdateTriggerGroups();
	// [Call #1] RVA: 0x106B9718C
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B98230
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.UpdateCustomItemNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc258c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FText> UpdateCustomItemNames();
	// [Call #1] RVA: 0x106B97194
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B9718C
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B98230
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.UpdateBlockByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc2578
	// Params: [ Num(0) Size(0x0) ]
	void UpdateBlockByTag();
	// [Call #1] RVA: 0x106B97194
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B9718C
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B98230
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.Undo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc2564
	// Params: [ Num(0) Size(0x0) ]
	void Undo();
	// [Call #1] RVA: 0x106B97194
	// [Call #2] RVA: 0x106B541B4
	// [Call #3] RVA: 0x1037BBE68
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B9718C
	// [Call #7] RVA: 0x106B541B4
	// [Call #8] RVA: 0x1037BBE68
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B98230
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyGraphWidget.TryBackToVariableOrCustomPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc2530
	// Params: [ Num(1) Size(0x1) ]
	bool TryBackToVariableOrCustomPanel();
	// [Call #1] RVA: 0x106B97180
	// [Call #2] RVA: 0x106B97194
	// [Call #3] RVA: 0x106B541B4
	// [Call #4] RVA: 0x1037BBE68
	// [Call #5] RVA: 0x1037BBE68
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x106B9718C
	// [Call #8] RVA: 0x106B541B4
	// [Call #9] RVA: 0x1037BBE68
	// [Call #10] RVA: 0x1037BBE68
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B98230
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function BlockyLua.BlockyGraphWidget.ShowTips
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc2484
	// Params: [ Num(1) Size(0x18) ]
	void ShowTips(struct FText& Tips);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B970A4
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B97180
	// [Call #9] RVA: 0x106B97194
	// [Call #10] RVA: 0x106B541B4
	// [Call #11] RVA: 0x1037BBE68
	// [Call #12] RVA: 0x1037BBE68
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106B9718C
	// [Call #15] RVA: 0x106B541B4
	// [Call #16] RVA: 0x1037BBE68
	// [Call #17] RVA: 0x1037BBE68
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B98230

	// Object: Function BlockyLua.BlockyGraphWidget.ShowPresetParamPop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc2470
	// Params: [ Num(0) Size(0x0) ]
	void ShowPresetParamPop();
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B970A4
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B97180
	// [Call #9] RVA: 0x106B97194
	// [Call #10] RVA: 0x106B541B4
	// [Call #11] RVA: 0x1037BBE68
	// [Call #12] RVA: 0x1037BBE68
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106B9718C
	// [Call #15] RVA: 0x106B541B4
	// [Call #16] RVA: 0x1037BBE68
	// [Call #17] RVA: 0x1037BBE68
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.SetViewScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc23f4
	// Params: [ Num(1) Size(0x4) ]
	void SetViewScale(float InScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B981E4
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B970A4
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B97180
	// [Call #12] RVA: 0x106B97194
	// [Call #13] RVA: 0x106B541B4
	// [Call #14] RVA: 0x1037BBE68
	// [Call #15] RVA: 0x1037BBE68
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106B9718C
	// [Call #18] RVA: 0x106B541B4
	// [Call #19] RVA: 0x1037BBE68

	// Object: Function BlockyLua.BlockyGraphWidget.SetViewPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106bc237c
	// Params: [ Num(1) Size(0x8) ]
	void SetViewPosition(struct FVector2D ViewPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B981CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B981E4
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B970A4
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106B97180
	// [Call #15] RVA: 0x106B97194
	// [Call #16] RVA: 0x106B541B4
	// [Call #17] RVA: 0x1037BBE68

	// Object: Function BlockyLua.BlockyGraphWidget.SetTagsSetting
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc225c
	// Params: [ Num(2) Size(0x60) ]
	void SetTagsSetting(struct TArray<int>& newDefaultTags, struct FGraphSettingMap& newGraphSettingsMap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B5AC64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B983CC
	// [Call #7] RVA: 0x106B5AE18
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106B5AE18
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B981CC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B981E4
	// [Call #18] RVA: 0x104F0F380

	// Object: Function BlockyLua.BlockyGraphWidget.SetShowSaveTemplateVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc21d8
	// Params: [ Num(1) Size(0x1) ]
	void SetShowSaveTemplateVar(bool IsShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B93288
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B5AC64
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B983CC
	// [Call #10] RVA: 0x106B5AE18
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106B5AE18
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B981CC
	// [Call #18] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.SetMenuWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc215c
	// Params: [ Num(1) Size(0x8) ]
	void SetMenuWidget(struct UBlockyMenuWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97D98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B93288
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B5AC64
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B983CC
	// [Call #13] RVA: 0x106B5AE18
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106B5AE18
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.SetGraphCanMove
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc20d8
	// Params: [ Num(1) Size(0x1) ]
	void SetGraphCanMove(bool isCanMove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B93290
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97D98
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B93288
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B5AC64
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B983CC

	// Object: Function BlockyLua.BlockyGraphWidget.SetCurrentSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1ff4
	// Params: [ Num(1) Size(0x10) ]
	void SetCurrentSubGraph(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B980C0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B93290
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B97D98
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B93288

	// Object: Function BlockyLua.BlockyGraphWidget.SetCategoryWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1f78
	// Params: [ Num(1) Size(0x8) ]
	void SetCategoryWidget(struct UBlockyCategoryWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97E3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B980C0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B93290
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B97D98

	// Object: Function BlockyLua.BlockyGraphWidget.SetCaptureScreenShot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106bc1ef0
	// Params: [ Num(2) Size(0x10) ]
	struct UTexture2D* SetCaptureScreenShot(struct FVector2D screenRect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B93298
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97E3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106B980C0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.SetBlockLogWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1e74
	// Params: [ Num(1) Size(0x8) ]
	void SetBlockLogWidget(struct UBlockyLogWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97EEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B93298
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97E3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106B980C0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0

	// Object: Function BlockyLua.BlockyGraphWidget.SetBlockListWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1df8
	// Params: [ Num(1) Size(0x8) ]
	void SetBlockListWidget(struct UBlockyBlockWindowWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97E94
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97EEC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B93298
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B97E3C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.SaveGraphToJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1d94
	// Params: [ Num(1) Size(0x10) ]
	struct FString SaveGraphToJsonText();
	// [Call #1] RVA: 0x106B971A8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B97E94
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97EEC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B93298
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B97E3C

	// Object: Function BlockyLua.BlockyGraphWidget.SaveGraphToBin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1d30
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> SaveGraphToBin();
	// [Call #1] RVA: 0x106B972D0
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B971A8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B97E94
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B97EEC
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B93298

	// Object: Function BlockyLua.BlockyGraphWidget.SaveGlobalVarToJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1ccc
	// Params: [ Num(1) Size(0x10) ]
	struct FString SaveGlobalVarToJsonText();
	// [Call #1] RVA: 0x106B97234
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B972D0
	// [Call #7] RVA: 0x1021B8BBC
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B971A8
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B97E94
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B97EEC

	// Object: Function BlockyLua.BlockyGraphWidget.SaveGlobalVarToBin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1c68
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> SaveGlobalVarToBin();
	// [Call #1] RVA: 0x106B9732C
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B97234
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B972D0
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106B971A8
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x106B97E94
	// [Call #24] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.SaveCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1c54
	// Params: [ Num(0) Size(0x0) ]
	void SaveCustom();
	// [Call #1] RVA: 0x106B9732C
	// [Call #2] RVA: 0x1021B8BBC
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106B97234
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106B972D0
	// [Call #12] RVA: 0x1021B8BBC
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106B971A8
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x106B97E94
	// [Call #24] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.SaveBlockyGraphToTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1ba0
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<uint8_t> SaveBlockyGraphToTemplate(struct UBlockyGraph* BlockyGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106B971A8
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.Save
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b8c
	// Params: [ Num(0) Size(0x0) ]
	void Save();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106B971A8
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyGraphWidget.ReturnToPreviewGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b78
	// Params: [ Num(0) Size(0x0) ]
	void ReturnToPreviewGraph();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106B971A8
	// [Call #24] RVA: 0x101F8156C

	// Object: Function BlockyLua.BlockyGraphWidget.ReturnToMainGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b64
	// Params: [ Num(0) Size(0x0) ]
	void ReturnToMainGraph();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.ResetMenuItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b50
	// Params: [ Num(0) Size(0x0) ]
	void ResetMenuItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.ResetJsonChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b3c
	// Params: [ Num(0) Size(0x0) ]
	void ResetJsonChangedFlag();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.ResetGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1b28
	// Params: [ Num(0) Size(0x0) ]
	void ResetGraph();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9755C
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106B9732C
	// [Call #9] RVA: 0x1021B8BBC
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106B97234
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106B972D0
	// [Call #19] RVA: 0x1021B8BBC
	// [Call #20] RVA: 0x101F8BA74

	// Object: Function BlockyLua.BlockyGraphWidget.RemoveSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1a44
	// Params: [ Num(1) Size(0x10) ]
	void RemoveSubGraph(struct FString InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B9803C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B9755C
	// [Call #15] RVA: 0x1021B8BBC
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x106B9732C

	// Object: Function BlockyLua.BlockyGraphWidget.RefreshFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1a30
	// Params: [ Num(0) Size(0x0) ]
	void RefreshFont();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B9803C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B9755C
	// [Call #15] RVA: 0x1021B8BBC
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.ReEditVariable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc19b4
	// Params: [ Num(1) Size(0x4) ]
	void ReEditVariable(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.Redo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc19a0
	// Params: [ Num(0) Size(0x0) ]
	void Redo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.QuoteCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc198c
	// Params: [ Num(0) Size(0x0) ]
	void QuoteCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.Quote
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1978
	// Params: [ Num(0) Size(0x0) ]
	void Quote();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.Paste
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1964
	// Params: [ Num(0) Size(0x0) ]
	void Paste();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.OnCloseItemList
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnCloseItemList();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyGraphWidget.OnAsyncLoadGraphBinCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x106bc1950
	// Params: [ Num(0) Size(0x0) ]
	void OnAsyncLoadGraphBinCompleted();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B9803C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.LoadTemplateToBlockyGraph_Test
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc17d4
	// Params: [ Num(3) Size(0x12) ]
	void LoadTemplateToBlockyGraph_Test(struct TArray<uint8_t> TemplateAst, bool IsCreateNewGraph, bool IsLoadPresetsInGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FFC894
	// [Call #8] RVA: 0x106B97B30
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B98294

	// Object: Function BlockyLua.BlockyGraphWidget.LoadTemplateToBlockyGraph
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc1690
	// Params: [ Num(3) Size(0x12) ]
	void LoadTemplateToBlockyGraph(struct TArray<uint8_t>& TemplateAst, bool IsCreateNewGraph, bool IsLoadPresetsInGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B976D0
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FFC894
	// [Call #18] RVA: 0x106B97B30

	// Object: Function BlockyLua.BlockyGraphWidget.LoadGraphFromJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc15ac
	// Params: [ Num(1) Size(0x10) ]
	void LoadGraphFromJsonText(struct FString JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B971B0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B976D0
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x101F8BA74
	// [Call #21] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.LoadGraphFromBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc1504
	// Params: [ Num(1) Size(0x10) ]
	void LoadGraphFromBin(struct TArray<uint8_t>& JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B972D8
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106B971B0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.LoadGlobalVarFromJsonText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1420
	// Params: [ Num(1) Size(0x10) ]
	void LoadGlobalVarFromJsonText(struct FString JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106B97248
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B972D8
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x106B971B0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x104EEF504

	// Object: Function BlockyLua.BlockyGraphWidget.LoadGlobalVarFromBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc1378
	// Params: [ Num(1) Size(0x10) ]
	void LoadGlobalVarFromBin(struct TArray<uint8_t>& JsonStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97334
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106B97248
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B972D8
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x101F8BA74
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.Load
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1364
	// Params: [ Num(0) Size(0x0) ]
	void Load();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97334
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106B97248
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B972D8
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x101F8BA74
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyGraphWidget.IsViewOverlap
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bc12a4
	// Params: [ Num(3) Size(0x11) ]
	bool IsViewOverlap(struct FVector2D Position, struct FVector2D Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B98258
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B97334
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106B97248
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyGraphWidget.IsFirstGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1270
	// Params: [ Num(1) Size(0x1) ]
	bool IsFirstGraph();
	// [Call #1] RVA: 0x106B9818C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B98258
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97334
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106B97248
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyGraphWidget.GM_GenerateAllBlocks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc1178
	// Params: [ Num(3) Size(0x9) ]
	void GM_GenerateAllBlocks(int CombinedBlocksNum, int GraphBlocksNum, bool bNeedResetGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B97BE4
	// [Call #8] RVA: 0x106B9818C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B98258
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.GM_AddBlocks
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc1048
	// Params: [ Num(3) Size(0x18) ]
	void GM_AddBlocks(struct TArray<struct FString>& typeNames, int X, int Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B97BD4
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106B97BE4
	// [Call #18] RVA: 0x106B9818C

	// Object: Function BlockyLua.BlockyGraphWidget.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bc1014
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetViewSize();
	// [Call #1] RVA: 0x106B981FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B97BD4
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106B97BE4

	// Object: Function BlockyLua.BlockyGraphWidget.GetViewScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bc0fe0
	// Params: [ Num(1) Size(0x4) ]
	float GetViewScale();
	// [Call #1] RVA: 0x106B981F0
	// [Call #2] RVA: 0x106B981FC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BD4
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.GetViewPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bc0fac
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetViewPosition();
	// [Call #1] RVA: 0x106B981D8
	// [Call #2] RVA: 0x106B981F0
	// [Call #3] RVA: 0x106B981FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B97BD4
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.GetJsonChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0f78
	// Params: [ Num(1) Size(0x1) ]
	bool GetJsonChangedFlag();
	// [Call #1] RVA: 0x106B97B94
	// [Call #2] RVA: 0x106B981D8
	// [Call #3] RVA: 0x106B981F0
	// [Call #4] RVA: 0x106B981FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BD4
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.GetGraphSettingByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc0cc8
	// Params: [ Num(6) Size(0x28) ]
	void GetGraphSettingByName(struct FString GraphName, bool& CanCopy, bool& CanReName, bool& CanDel, bool& CanSave, struct TArray<int>& Tags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106B98404
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyGraphWidget.GetDeleteBlockUIRect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0c4c
	// Params: [ Num(1) Size(0x4) ]
	void GetDeleteBlockUIRect(float InRectWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9719C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.GetCurrentGraph
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bc0c18
	// Params: [ Num(1) Size(0x8) ]
	struct UBlockyGraph* GetCurrentGraph();
	// [Call #1] RVA: 0x106B9278C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B9719C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.FocusTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0b9c
	// Params: [ Num(1) Size(0x8) ]
	void FocusTo(struct UBlockBase* TargetBlock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98570
	// [Call #4] RVA: 0x106B9278C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9719C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.FinishVariableEdit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0acc
	// Params: [ Num(2) Size(0x2) ]
	void FinishVariableEdit(bool bSaveVar, bool bReEdit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B97BA4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B98570
	// [Call #9] RVA: 0x106B9278C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9719C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.FinishCustomEdit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0a48
	// Params: [ Num(1) Size(0x1) ]
	void FinishCustomEdit(bool bSave);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B97BA4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B98570
	// [Call #12] RVA: 0x106B9278C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.FinishBlockSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc09c4
	// Params: [ Num(1) Size(0x1) ]
	void FinishBlockSetting(bool bSave);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BA4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B98570

	// Object: Function BlockyLua.BlockyGraphWidget.Eject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc09b0
	// Params: [ Num(0) Size(0x0) ]
	void Eject();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BA4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B98570

	// Object: Function BlockyLua.BlockyGraphWidget.EditCustumBlockGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc099c
	// Params: [ Num(0) Size(0x0) ]
	void EditCustumBlockGraph();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BA4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.EditCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0988
	// Params: [ Num(0) Size(0x0) ]
	void EditCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BA4
	// [Call #12] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.Disable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0974
	// Params: [ Num(0) Size(0x0) ]
	void Disable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B97BA4

	// Object: Function BlockyLua.BlockyGraphWidget.DeleteVariableListItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc08f8
	// Params: [ Num(1) Size(0x4) ]
	void DeleteVariableListItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.DeleteSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc08e4
	// Params: [ Num(0) Size(0x0) ]
	void DeleteSelected();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.DeleteCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc08d0
	// Params: [ Num(0) Size(0x0) ]
	void DeleteCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.DefineCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc08bc
	// Params: [ Num(0) Size(0x0) ]
	void DefineCustom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4
	// [Call #10] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.Define
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc08a8
	// Params: [ Num(0) Size(0x0) ]
	void Define();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4

	// Object: Function BlockyLua.BlockyGraphWidget.Copy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0894
	// Params: [ Num(0) Size(0x0) ]
	void Copy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4

	// Object: Function BlockyLua.BlockyGraphWidget.Comment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0880
	// Params: [ Num(0) Size(0x0) ]
	void Comment();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9828C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BB4

	// Object: Function BlockyLua.BlockyGraphWidget.CollectListItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc07fc
	// Params: [ Num(1) Size(0x1) ]
	void CollectListItem(bool bCollect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9828C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BAC

	// Object: Function BlockyLua.BlockyGraphWidget.Clone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc07e8
	// Params: [ Num(0) Size(0x0) ]
	void Clone();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9828C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B97BAC

	// Object: Function BlockyLua.BlockyGraphWidget.ClearUndoRedoDatas
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc07d4
	// Params: [ Num(0) Size(0x0) ]
	void ClearUndoRedoDatas();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9828C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.ClearTextSizeCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc07c0
	// Params: [ Num(0) Size(0x0) ]
	void ClearTextSizeCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9828C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.ClearLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc07ac
	// Params: [ Num(0) Size(0x0) ]
	void ClearLog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B97BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9828C
	// [Call #7] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyGraphWidget.CanvasPosToViewPos
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bc0724
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D CanvasPosToViewPos(struct FVector2D Postion);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98208
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B97BBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9828C

	// Object: Function BlockyLua.BlockyGraphWidget.BlockyLog_Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0520
	// Params: [ Num(4) Size(0x30) ]
	void BlockyLog_Show(uint8_t Mode, struct UBlockBase* BlockSource, struct FString SlotID, struct FString Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106B98580
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyGraphWidget.AsyncLoadGraphFromBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc0408
	// Params: [ Num(2) Size(0x20) ]
	void AsyncLoadGraphFromBin(struct TArray<uint8_t>& GraphBinContent, struct TArray<uint8_t>& GlobalVarBinContent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B9733C
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C

	// Object: Function BlockyLua.BlockyGraphWidget.AddSubGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc028c
	// Params: [ Num(2) Size(0x20) ]
	void AddSubGraph(struct FString InName, struct FString InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B97F44
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106B9733C
	// [Call #26] RVA: 0x101F8BA74

	// Object: Function BlockyLua.BlockyGraphWidget.AddGraph
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc0100
	// Params: [ Num(3) Size(0x28) ]
	struct UBlockyGraph* AddGraph(struct FString InName, struct FString InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B97A44
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C

	// Object: Function BlockyLua.BlockyGraphWidget.AddGlobalComment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc00ec
	// Params: [ Num(0) Size(0x0) ]
	void AddGlobalComment();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106B97A44
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
};

// Object: Class BlockyLua.BlockyGroupItemWidget
// Size: 0x260 (Inherited: 0x260)
struct UBlockyGroupItemWidget : UUserWidget
{
};

// Object: Class BlockyLua.BlockyGroupWidget
// Size: 0x278 (Inherited: 0x260)
struct UBlockyGroupWidget : UUserWidget
{
	struct UButton* BT_AddGroupItem; // 0x260(0x8)
	uint8_t Pad_0x268[0x10]; // 0x268(0x10)


	// Object: Function BlockyLua.BlockyGroupWidget.GetGroupContainer
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetGroupContainer();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyGroupWidget.AddGroupItem
	// Flags: [Final|Native|Public]
	// Offset: 0x106bc40b4
	// Params: [ Num(0) Size(0x0) ]
	void AddGroupItem();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10516EACC
	// [Call #6] RVA: 0x101F82D88
	// [Call #7] RVA: 0x10516EACC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
};

// Object: Class BlockyLua.BlockyIntegerWidget
// Size: 0x290 (Inherited: 0x260)
struct UBlockyIntegerWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)
	bool NegativeEnable; // 0x288(0x1)
	uint8_t Pad_0x289[0x7]; // 0x289(0x7)


	// Object: Function BlockyLua.BlockyIntegerWidget.SetText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyIntegerWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc432c
	// Params: [ Num(1) Size(0x10) ]
	void SetResult(struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B98A10
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyIntegerWidget.SetNegativeEnable
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void SetNegativeEnable(bool Enable);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyLogItemWidget
// Size: 0x2A8 (Inherited: 0x260)
struct UBlockyLogItemWidget : UUserWidget
{
	struct UBlockyGraphData* GraphWidget; // 0x260(0x8)
	struct UBlockyLogWidget* LogWidget; // 0x268(0x8)
	struct UBlockBase* BlockBase; // 0x270(0x8)
	struct FString BlockSlotId; // 0x278(0x10)
	uint8_t Pad_0x288[0x20]; // 0x288(0x20)


	// Object: Function BlockyLua.BlockyLogItemWidget.SetShowWarn
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetShowWarn(struct FString Warn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.SetShowInfo
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetShowInfo(struct FString Info);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.SetShowError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetShowError(struct FString Error);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.SetActiveWidgetIndex
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveWidgetIndex(int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.OnClickBtnToBlock
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7728
	// Params: [ Num(0) Size(0x0) ]
	void OnClickBtnToBlock();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogItemWidget.GetTextBlockWarn
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UTextBlock* GetTextBlockWarn();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.GetTextBlockInfo
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UTextBlock* GetTextBlockInfo();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.GetTextBlockError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UTextBlock* GetTextBlockError();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogItemWidget.GetActiveWidgetIndex
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	int GetActiveWidgetIndex();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyLogWidget
// Size: 0x290 (Inherited: 0x260)
struct UBlockyLogWidget : UUserWidget
{
	struct UBlockyGraphData* GraphWidget; // 0x260(0x8)
	struct UObject* LogItemWidgetType; // 0x268(0x8)
	uint8_t Pad_0x270[0x20]; // 0x270(0x20)


	// Object: Function BlockyLua.BlockyLogWidget.ShowLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7f30
	// Params: [ Num(0) Size(0x0) ]
	void ShowLog();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogWidget.SetBtnWarnText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetBtnWarnText(struct FString Warn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.SetBtnInfoText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetBtnInfoText(struct FString Info);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.SetBtnErrorText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetBtnErrorText(struct FString Error);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.OnClickWarnShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7f1c
	// Params: [ Num(0) Size(0x0) ]
	void OnClickWarnShow();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogWidget.OnClickInfoShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7f08
	// Params: [ Num(0) Size(0x0) ]
	void OnClickInfoShow();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogWidget.OnClickErrorShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7ef4
	// Params: [ Num(0) Size(0x0) ]
	void OnClickErrorShow();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogWidget.OnClickAllShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc7ee0
	// Params: [ Num(0) Size(0x0) ]
	void OnClickAllShow();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLogWidget.GetLogContainer
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetLogContainer();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.GetItemTextWidth
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	float GetItemTextWidth();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.GetBtnWarnText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetBtnWarnText();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.GetBtnInfoText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetBtnInfoText();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLogWidget.GetBtnErrorText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetBtnErrorText();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyLuaLoopScrollBase
// Size: 0xC50 (Inherited: 0xB28)
struct UBlockyLuaLoopScrollBase : UScrollBox
{
	bool bDelayLoad; // 0xB28(0x1)
	uint8_t Pad_0xB29[0x3]; // 0xB29(0x3)
	float BlockyLuaEdgePadding; // 0xB2C(0x4)
	struct FScriptMulticastDelegate OnRefreshItem; // 0xB30(0x10)
	struct FScriptMulticastDelegate OnItemCreated; // 0xB40(0x10)
	struct FScriptMulticastDelegate OnChangeData; // 0xB50(0x10)
	uint8_t Pad_0xB60[0xD0]; // 0xB60(0xD0)
	struct UWidget* itemType; // 0xC30(0x8)
	uint8_t Pad_0xC38[0x10]; // 0xC38(0x10)
	struct UCanvasPanel* CanvasPanel; // 0xC48(0x8)


	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.UserScrolled
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc8bf8
	// Params: [ Num(1) Size(0x4) ]
	void UserScrolled(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9BD54
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.SetItemType
	// Flags: [Final|Native|Public]
	// Offset: 0x106bc8b7c
	// Params: [ Num(1) Size(0x8) ]
	void SetItemType(struct UWidget* _ItemType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9AEE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9BD54
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.SetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc8af0
	// Params: [ Num(2) Size(0x5) ]
	bool SetItemCount(int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B064
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9AEE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9BD54
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc8a74
	// Params: [ Num(1) Size(0x4) ]
	void RemoveItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B6B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B064
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9AEE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9BD54
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.RefreshItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc89e8
	// Params: [ Num(2) Size(0x5) ]
	bool RefreshItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B4B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B6B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B064
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9AEE0
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.RefreshAllItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc89d4
	// Params: [ Num(0) Size(0x0) ]
	void RefreshAllItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B4B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B6B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B064
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9AEE0
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.Push
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc89c0
	// Params: [ Num(0) Size(0x0) ]
	void Push();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B4B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B6B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B064
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9AEE0

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.Pop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc89ac
	// Params: [ Num(0) Size(0x0) ]
	void Pop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B4B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B6B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B064
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9AEE0

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase.OnRefreshItem__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnRefreshItem__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase.OnItemCreated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnItemCreated__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase.OnChangeData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnChangeData__DelegateSignature(struct UWidget* Item, int Index, struct FString Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.InsertItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc8930
	// Params: [ Num(1) Size(0x4) ]
	void InsertItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9B538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B4B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B6B0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9B064

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.GetWidgetIndex
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc88a4
	// Params: [ Num(2) Size(0xC) ]
	int GetWidgetIndex(struct UWidget* Item);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9BFC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9B538
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9B4B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9B6B0

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.GetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc8870
	// Params: [ Num(1) Size(0x4) ]
	int GetItemCount();
	// [Call #1] RVA: 0x106B9B528
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B9BFC0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9B538
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B9B4B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.GetIndexOfWidget
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc87e4
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetIndexOfWidget(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9C098
	// [Call #4] RVA: 0x106B9B528
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9BFC0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B9B538
	// [Call #11] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.ChangeData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc86b0
	// Params: [ Num(3) Size(0x19) ]
	bool ChangeData(int Index, struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B9B8D8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B9C098
	// [Call #17] RVA: 0x106B9B528
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.CallTick
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bc8634
	// Params: [ Num(1) Size(0x4) ]
	void CallTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9BFB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B9B8D8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B9C098

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase.AutoSize
	// Flags: [Final|Native|Public]
	// Offset: 0x106bc85b0
	// Params: [ Num(1) Size(0x1) ]
	void AutoSize(bool bAutoSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9BA64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9BFB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106B9B8D8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
};

// Object: Class BlockyLua.BlockyLuaLoopScrollBase_MultiItem
// Size: 0xC98 (Inherited: 0xB28)
struct UBlockyLuaLoopScrollBase_MultiItem : UScrollBox
{
	bool bDelayLoad; // 0xB28(0x1)
	uint8_t Pad_0xB29[0x3]; // 0xB29(0x3)
	float BlockyLuaEdgePadding; // 0xB2C(0x4)
	struct FScriptMulticastDelegate OnRefreshItem; // 0xB30(0x10)
	struct FScriptMulticastDelegate OnItemCreated; // 0xB40(0x10)
	struct FScriptMulticastDelegate OnChangeData; // 0xB50(0x10)
	uint8_t Pad_0xB60[0x130]; // 0xB60(0x130)
	struct UCanvasPanel* CanvasPanel; // 0xC90(0x8)


	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.UserScrolled
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc98f4
	// Params: [ Num(1) Size(0x4) ]
	void UserScrolled(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D3DC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.SetItemType
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bc984c
	// Params: [ Num(1) Size(0x10) ]
	void SetItemType(struct TArray<struct UWidget*>& TypeArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9C50C
	// [Call #4] RVA: 0x106BB685C
	// [Call #5] RVA: 0x106BB685C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9D3DC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.SetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc97c0
	// Params: [ Num(2) Size(0x5) ]
	bool SetItemCount(int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9C588
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9C50C
	// [Call #7] RVA: 0x106BB685C
	// [Call #8] RVA: 0x106BB685C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9D3DC
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc9744
	// Params: [ Num(1) Size(0x4) ]
	void RemoveItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9CC54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9C588
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9C50C
	// [Call #10] RVA: 0x106BB685C
	// [Call #11] RVA: 0x106BB685C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B9D3DC

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.RefreshItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc96b8
	// Params: [ Num(2) Size(0x5) ]
	bool RefreshItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9CA38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9CC54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9C588
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9C50C
	// [Call #13] RVA: 0x106BB685C
	// [Call #14] RVA: 0x106BB685C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.RefreshAllItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc96a4
	// Params: [ Num(0) Size(0x0) ]
	void RefreshAllItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9CA38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9CC54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9C588
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9C50C
	// [Call #13] RVA: 0x106BB685C
	// [Call #14] RVA: 0x106BB685C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.Push
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc9628
	// Params: [ Num(1) Size(0x8) ]
	void Push(struct UWidget* Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9CAB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9CA38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9CC54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9C588

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.Pop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc9614
	// Params: [ Num(0) Size(0x0) ]
	void Pop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9CAB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9CA38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9CC54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9C588

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase_MultiItem.OnRefreshItem__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnRefreshItem__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase_MultiItem.OnItemCreated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnItemCreated__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLuaLoopScrollBase_MultiItem.OnChangeData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnChangeData__DelegateSignature(struct UWidget* Item, int Index, struct FString Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.InsertItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc955c
	// Params: [ Num(2) Size(0x10) ]
	void InsertItem(int Index, struct UWidget* Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106B9CAC0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B9CAB4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B9CA38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B9CC54

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.GetWidgetIndex
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc94d0
	// Params: [ Num(2) Size(0xC) ]
	int GetWidgetIndex(struct UWidget* Item);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D644
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B9CAC0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106B9CAB4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.GetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc949c
	// Params: [ Num(1) Size(0x4) ]
	int GetItemCount();
	// [Call #1] RVA: 0x106B9CAAC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B9D644
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106B9CAC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9CAB4
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.GetIndexOfWidget
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bc9410
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetIndexOfWidget(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D71C
	// [Call #4] RVA: 0x106B9CAAC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9D644
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9CAC0
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.ClearItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc93fc
	// Params: [ Num(0) Size(0x0) ]
	void ClearItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D71C
	// [Call #4] RVA: 0x106B9CAAC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9D644
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106B9CAC0

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.ChangeData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bc92c8
	// Params: [ Num(3) Size(0x19) ]
	bool ChangeData(int Index, struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106B9CF00
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B9D71C
	// [Call #17] RVA: 0x106B9CAAC
	// [Call #18] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.CallTick
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bc924c
	// Params: [ Num(1) Size(0x4) ]
	void CallTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D638
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106B9CF00
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B9D71C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBase_MultiItem.AutoSize
	// Flags: [Final|Native|Public]
	// Offset: 0x106bc91c8
	// Params: [ Num(1) Size(0x1) ]
	void AutoSize(bool bAutoSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9D08C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9D638
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106B9CF00
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
};

// Object: Class BlockyLua.BlockyLuaLoopScrollBox
// Size: 0xC60 (Inherited: 0xC50)
struct UBlockyLuaLoopScrollBox : UBlockyLuaLoopScrollBase
{
	float ItemSize; // 0xC50(0x4)
	float Padding; // 0xC54(0x4)
	bool bAlignMagnetic; // 0xC58(0x1)
	uint8_t Pad_0xC59[0x7]; // 0xC59(0x7)


	// Object: Function BlockyLua.BlockyLuaLoopScrollBox.ScrollToItem
	// Flags: [Native|Public]
	// Offset: 0x106bc9ec4
	// Params: [ Num(1) Size(0x4) ]
	void ScrollToItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x106BCA3F8
	// [Call #7] RVA: 0x106B9DDE4
};

// Object: Class BlockyLua.BlockyLuaLoopScrollBox_MultiItem
// Size: 0xD40 (Inherited: 0xC98)
struct UBlockyLuaLoopScrollBox_MultiItem : UBlockyLuaLoopScrollBase_MultiItem
{
	struct TMap<struct UWidget*, float> WidgetSizeMap; // 0xC98(0x50)
	struct TMap<struct UWidget*, float> WidgetPaddingMap; // 0xCE8(0x50)
	bool bAlignMagnetic; // 0xD38(0x1)
	uint8_t Pad_0xD39[0x7]; // 0xD39(0x7)


	// Object: Function BlockyLua.BlockyLuaLoopScrollBox_MultiItem.ScrollToItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bca1f8
	// Params: [ Num(1) Size(0x4) ]
	void ScrollToItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBox_MultiItem.BP_UserScrolled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bca17c
	// Params: [ Num(1) Size(0x4) ]
	void BP_UserScrolled(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9DDF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBox_MultiItem.BP_PreventScrollOutOfSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bca0e8
	// Params: [ Num(2) Size(0x2) ]
	bool BP_PreventScrollOutOfSize(bool bScroll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9DDF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106B9DDF0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLuaLoopScrollBox_MultiItem.BP_GetContentSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bca0b4
	// Params: [ Num(1) Size(0x4) ]
	float BP_GetContentSize();
	// [Call #1] RVA: 0x106B9DDE4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B9DDF4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9DDF0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class BlockyLua.BlockyLuaLoopScrollGrid
// Size: 0xC78 (Inherited: 0xC50)
struct UBlockyLuaLoopScrollGrid : UBlockyLuaLoopScrollBase
{
	struct FVector2D ItemSize; // 0xC50(0x8)
	struct FVector2D Padding; // 0xC58(0x8)
	bool bAlignGrid; // 0xC60(0x1)
	bool bAlignAnimation; // 0xC61(0x1)
	uint8_t Pad_0xC62[0x16]; // 0xC62(0x16)


	// Object: Function BlockyLua.BlockyLuaLoopScrollGrid.ScrollToItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bca4d0
	// Params: [ Num(1) Size(0x4) ]
	void ScrollToItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10516EACC
	// [Call #7] RVA: 0x10516EACC
};

// Object: Class BlockyLua.BlockyMenuItemWidget
// Size: 0x290 (Inherited: 0x260)
struct UBlockyMenuItemWidget : UUserWidget
{
	int Index; // 0x260(0x4)
	uint8_t Pad_0x264[0x4]; // 0x264(0x4)
	struct FText Name; // 0x268(0x18)
	struct UBlockyMenuWidget* HostWidget; // 0x280(0x8)
	struct UBlockyCategoryItemWidget* CurrentCategoryItemWidget; // 0x288(0x8)


	// Object: Function BlockyLua.BlockyMenuItemWidget.SetSelected
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool IsSelected);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyMenuItemWidget.OnClick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bca7a0
	// Params: [ Num(0) Size(0x0) ]
	void OnClick();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10516EACC

	// Object: Function BlockyLua.BlockyMenuItemWidget.InitWithItemObject
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void InitWithItemObject(struct UBlockyMenuItemObject* Item);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyMenuItemWidget.InitTextToShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitTextToShow();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyMenuWidget
// Size: 0x280 (Inherited: 0x260)
struct UBlockyMenuWidget : UUserWidget
{
	struct UObject* MenuItemWidgetType; // 0x260(0x8)
	uint8_t Pad_0x268[0x10]; // 0x268(0x10)
	struct UBlockyGraphData* GraphWidget; // 0x278(0x8)


	// Object: Function BlockyLua.BlockyMenuWidget.SelectMenu
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcaa90
	// Params: [ Num(2) Size(0x9) ]
	bool SelectMenu(struct UBlockyMenuItemWidget* MenuItemWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9EBB8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyMenuWidget.OnAddMenuItemWidget
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnAddMenuItemWidget(struct UBlockyMenuItemWidget* MenuItemWidget);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyMenuWidget.GetMenuContainer
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetMenuContainer();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyPresetItemWidget
// Size: 0x280 (Inherited: 0x260)
struct UBlockyPresetItemWidget : UUserWidget
{
	struct UPresetDesc* Desc; // 0x260(0x8)
	struct UBlockyPresetWidget* Host; // 0x268(0x8)
	struct UBlockySearchWidget* SearchHost; // 0x270(0x8)
	struct UScrollBox* SubScrollBox; // 0x278(0x8)


	// Object: Function BlockyLua.BlockyPresetItemWidget.SetPresetDesc_BP
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetPresetDesc_BP(struct UPresetDesc* PresetDesc);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyPresetItemWidget.SetImageShowIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcadc0
	// Params: [ Num(1) Size(0x8) ]
	void SetImageShowIcon(struct UImage* Image);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9F744
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function BlockyLua.BlockyPresetItemWidget.GetPresetDescCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcad5c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetPresetDescCode();
	// [Call #1] RVA: 0x106B9F864
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B9F744
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyPresetWidget
// Size: 0x300 (Inherited: 0x260)
struct UBlockyPresetWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyEditor* HostWidget; // 0x280(0x8)
	struct UButton* Button_FilterAction; // 0x288(0x8)
	struct FString SlotTypeName; // 0x290(0x10)
	struct TMap<int, struct FIntArrayWrapper> CurrentTages; // 0x2A0(0x50)
	struct TArray<struct FString> CurrentTagesStr; // 0x2F0(0x10)


	// Object: Function BlockyLua.BlockyPresetWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb39c
	// Params: [ Num(1) Size(0x8) ]
	void SetResult(struct UPresetDesc* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9FA70
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyPresetWidget.SetPresets
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetPresets(struct TArray<struct UPresetDesc*>& Presets);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyPresetWidget.ResetMenuItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb388
	// Params: [ Num(0) Size(0x0) ]
	void ResetMenuItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9FA70
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyPresetWidget.OnFilterBtnClick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb324
	// Params: [ Num(1) Size(0x10) ]
	struct FString OnFilterBtnClick();
	// [Call #1] RVA: 0x106B9FFB0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106B9FA70
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyPresetWidget.LoopScrollBoxFilterStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb28c
	// Params: [ Num(1) Size(0x10) ]
	void LoopScrollBoxFilterStr(struct FString filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9FBB0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x106B9FFB0
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106B9FA70
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyPresetWidget.LoopScrollBoxFilterByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bcb134
	// Params: [ Num(2) Size(0x60) ]
	void LoopScrollBoxFilterByTag(struct TMap<int, struct FIntArrayWrapper>& Tags, struct TArray<struct FString> curTagsStr);
	// [Call #1] RVA: 0x106BCE120
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F86A94
	// [Call #7] RVA: 0x106B9FD34
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106BB1CC0
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106BB1CC0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B9FBB0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106B9FFB0
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyPresetWidget.InitPresets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb120
	// Params: [ Num(0) Size(0x0) ]
	void InitPresets();
	// [Call #1] RVA: 0x106BCE120
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F86A94
	// [Call #7] RVA: 0x106B9FD34
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106BB1CC0
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106BB1CC0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106B9FBB0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x106B9FFB0
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyPresetWidget.GetPresetDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb0ec
	// Params: [ Num(1) Size(0x8) ]
	struct UPresetDesc* GetPresetDesc();
	// [Call #1] RVA: 0x106BA0124
	// [Call #2] RVA: 0x106BCE120
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F86A94
	// [Call #8] RVA: 0x106B9FD34
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106BB1CC0
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x106BB1CC0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106B9FBB0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyPresetWidget.GetLoopScrollBox
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UScrollBox* GetLoopScrollBox();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyPresetWidget.GetIsIconWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcb0b8
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsIconWidget();
	// [Call #1] RVA: 0x106BA00CC
	// [Call #2] RVA: 0x106BA0124
	// [Call #3] RVA: 0x106BCE120
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F86A94
	// [Call #9] RVA: 0x106B9FD34
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106BB1CC0
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106BB1CC0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106B9FBB0
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BlockyLua.BlockyPresetWidget.ClearSearchText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ClearSearchText();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockyRichTextBlock
// Size: 0x428 (Inherited: 0x128)
struct UBlockyRichTextBlock : UTextLayoutWidget
{
	struct FText Text; // 0x128(0x18)
	DelegateProperty TextDelegate; // 0x140(0x10)
	struct FSlateFontInfo Font; // 0x150(0x58)
	struct FLinearColor Color; // 0x1A8(0x10)
	struct TArray<struct URichTextBlockDecorator*> Decorators; // 0x1B8(0x10)
	uint8_t Pad_0x1C8[0x260]; // 0x1C8(0x260)


	// Object: Function BlockyLua.BlockyRichTextBlock.SetText
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bcb890
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText& InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x106BC79E4

	// Object: Function BlockyLua.BlockyRichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcb82c
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x106BA685C
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104F0F380
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockySearchResultPanel
// Size: 0x328 (Inherited: 0x260)
struct UBlockySearchResultPanel : UUserWidget
{
	float DrawBottomDelta; // 0x260(0x4)
	float HorizontalMoveCheckDelta; // 0x264(0x4)
	float VerticalMoveCheckDelta; // 0x268(0x4)
	float WhileRefreshBlockSizeY; // 0x26C(0x4)
	bool IsDragging; // 0x270(0x1)
	bool IsHorizontalMove; // 0x271(0x1)
	uint8_t Pad_0x272[0x2]; // 0x272(0x2)
	struct FVector2D TouchStartPosition; // 0x274(0x8)
	struct FVector2D PointAtOffset; // 0x27C(0x8)
	int CurrentCategoryIndex; // 0x284(0x4)
	int YOffset; // 0x288(0x4)
	int TotalHeight_Blocks; // 0x28C(0x4)
	int TotalHeight_Graphs; // 0x290(0x4)
	int TotalHeight_GraphsTitle; // 0x294(0x4)
	int ViewHeight; // 0x298(0x4)
	int totalHeight; // 0x29C(0x4)
	bool bNeedUpdateTotalHeight_Graphs; // 0x2A0(0x1)
	uint8_t Pad_0x2A1[0x7]; // 0x2A1(0x7)
	struct UBlockyBlockListItemObject* ListItemAtPoint; // 0x2A8(0x8)
	struct TWeakObjectPtr<struct UBlockyMenuItemObject_Search> FoundResults; // 0x2B0(0x8)
	struct USpacer* BlocksContainer; // 0x2B8(0x8)
	struct UBlockyLuaLoopScrollBox_MultiItem* GraphBlocksContainer; // 0x2C0(0x8)
	struct UObject* GraphBlocksWidgetType; // 0x2C8(0x8)
	struct UObject* GraphItemBlockWidgetType; // 0x2D0(0x8)
	struct UBlockyGraphData* GraphData; // 0x2D8(0x8)
	struct UScrollBox* TabContainer; // 0x2E0(0x8)
	bool bShowComment; // 0x2E8(0x1)
	uint8_t Pad_0x2E9[0x3]; // 0x2E9(0x3)
	struct TWeakObjectPtr<struct UBlockyGraph> LastSelectedGraph; // 0x2EC(0x8)
	struct TWeakObjectPtr<struct UBlockBase> LastSelectedBlock; // 0x2F4(0x8)
	uint8_t Pad_0x2FC[0x4]; // 0x2FC(0x4)
	struct TArray<struct UBlockyGraph*> CollapsedGraphs; // 0x300(0x10)
	struct TArray<struct UObject*> ItemObjectList; // 0x310(0x10)
	uint8_t SearchResultVisibleType; // 0x320(0x1)
	uint8_t Pad_0x321[0x7]; // 0x321(0x7)


	// Object: Function BlockyLua.BlockySearchResultPanel.UpdateGraphContentSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbefc
	// Params: [ Num(0) Size(0x0) ]
	void UpdateGraphContentSize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResultPanel.ToggleGraphResults
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbe80
	// Params: [ Num(1) Size(0x8) ]
	void ToggleGraphResults(struct UBlockyGraph* InGraph);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA8704
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResultPanel.ScrollToCategory
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbdc4
	// Params: [ Num(2) Size(0x5) ]
	void ScrollToCategory(int CategoryIndex, bool GraphCategory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA7AF4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA8704
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResultPanel.RefreshGraphBlocksWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbdb0
	// Params: [ Num(0) Size(0x0) ]
	void RefreshGraphBlocksWidgets();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA7AF4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA8704
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResultPanel.OnGraphBlocksCreated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbcf8
	// Params: [ Num(2) Size(0xC) ]
	void OnGraphBlocksCreated(struct UWidget* Widget, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA802C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BA7AF4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BA8704
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResultPanel.FocusToBlock
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbc44
	// Params: [ Num(2) Size(0x10) ]
	void FocusToBlock(struct UBlockyGraph* InGraph, struct UBlockBase* InBlock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA85B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BA802C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA7AF4

	// Object: Function BlockyLua.BlockySearchResultPanel.FilterOutSearchResultToShow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcbbc8
	// Params: [ Num(1) Size(0x1) ]
	void FilterOutSearchResultToShow(uint8_t VisibleType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA7C3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA85B8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BA802C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchResultPanel.BP_ScrollYOffset
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x5) ]
	bool BP_ScrollYOffset(int DeltaY);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockySearchResults_GraphItemWidget
// Size: 0x2B8 (Inherited: 0x260)
struct UBlockySearchResults_GraphItemWidget : UUserWidget
{
	struct FVector2D IconSize; // 0x260(0x8)
	struct FString SearchingStr; // 0x268(0x10)
	struct FString BlockDisplayString; // 0x278(0x10)
	struct TWeakObjectPtr<struct UBlockyGraph> BlockGraph; // 0x288(0x8)
	struct TWeakObjectPtr<struct UBlockBase> bLock; // 0x290(0x8)
	struct UBlockySearchResultPanel* HostResultPanel; // 0x298(0x8)
	bool bIsDragging; // 0x2A0(0x1)
	uint8_t Pad_0x2A1[0x7]; // 0x2A1(0x7)
	struct UImage* BlockIcon; // 0x2A8(0x8)
	struct UBlockyRichTextBlock* TextBlock_BlockDisplay; // 0x2B0(0x8)


	// Object: Function BlockyLua.BlockySearchResults_GraphItemWidget.OnClickedBlock
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcc4f4
	// Params: [ Num(0) Size(0x0) ]
	void OnClickedBlock();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResults_GraphItemWidget.OnBlockWidgetSelected
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnBlockWidgetSelected(bool bSelected);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockySearchResults_GraphItemWidget.MarkSearchingStringWithColor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcc37c
	// Params: [ Num(4) Size(0x40) ]
	struct FString MarkSearchingStringWithColor(struct FString InputString, struct FString Target, struct FString ColorString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA88C4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchResults_GraphItemWidget.IsSearchUseCase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcc348
	// Params: [ Num(1) Size(0x1) ]
	bool IsSearchUseCase();
	// [Call #1] RVA: 0x106BA8898
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA88C4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function BlockyLua.BlockySearchResults_GraphItemWidget.GetKeyWordColor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcc2e4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetKeyWordColor();
	// [Call #1] RVA: 0x106BA8E04
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106BA8898
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BA88C4
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockySearchResults_GraphWidget
// Size: 0x290 (Inherited: 0x260)
struct UBlockySearchResults_GraphWidget : UUserWidget
{
	struct UObject* GraphBlockItemWidgetType; // 0x260(0x8)
	struct FString GraphDisplayName; // 0x268(0x10)
	struct UBlockySearchResultPanel* HostResultPanel; // 0x278(0x8)
	struct TWeakObjectPtr<struct UBlockyGraph> BlockGraph; // 0x280(0x8)
	bool bIsDragging; // 0x288(0x1)
	uint8_t Pad_0x289[0x7]; // 0x289(0x7)


	// Object: Function BlockyLua.BlockySearchResults_GraphWidget.ToggleGraphResultsCollapse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcc85c
	// Params: [ Num(0) Size(0x0) ]
	void ToggleGraphResultsCollapse();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10516EACC

	// Object: Function BlockyLua.BlockySearchResults_GraphWidget.OnSetGraphResultsCollapse
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnSetGraphResultsCollapse(bool InCollapse);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockySearchResults_GraphWidget.OnRefreshDisplayNameView
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void OnRefreshDisplayNameView(struct FString InGraphDisplayName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockySearchResultsTab
// Size: 0x290 (Inherited: 0x260)
struct UBlockySearchResultsTab : UUserWidget
{
	bool IsGraphCategory; // 0x260(0x1)
	uint8_t Pad_0x261[0x3]; // 0x261(0x3)
	int TabIndex; // 0x264(0x4)
	struct FText TabDisplayName; // 0x268(0x18)
	bool IsPresetTab; // 0x280(0x1)
	uint8_t Pad_0x281[0x7]; // 0x281(0x7)
	struct UBlockySearchWidget* SearchWidget; // 0x288(0x8)


	// Object: Function BlockyLua.BlockySearchResultsTab.OnSetSelected
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnSetSelected(bool bSelected);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BlockyLua.BlockySearchWidget
// Size: 0x3E8 (Inherited: 0x260)
struct UBlockySearchWidget : UUserWidget
{
	struct TMap<struct UBlockyMenuItemObject*, bool> MenuItemVisibility; // 0x260(0x50)
	struct TMap<struct UBlockyCategoryItemObject*, bool> CategoriesVisibility; // 0x2B0(0x50)
	struct TMap<struct UBlockyBlockListItemObject*, bool> BlockItemsVisibility; // 0x300(0x50)
	uint8_t Pad_0x350[0x8]; // 0x350(0x8)
	struct TArray<struct UBlockyCategoryItemObject*> PresetCategorysResults; // 0x358(0x10)
	struct TArray<struct UPresetDesc*> ResultPresets; // 0x368(0x10)
	struct TArray<struct FString> PresetsCategorys; // 0x378(0x10)
	bool IsPresetsSearch; // 0x388(0x1)
	uint8_t Pad_0x389[0x7]; // 0x389(0x7)
	struct UScrollBox* TabContainer; // 0x390(0x8)
	struct UBlockySearchResultPanel* SearchResultPanel; // 0x398(0x8)
	struct FText ContentTabText; // 0x3A0(0x18)
	struct UObject* SearchResultsTabType; // 0x3B8(0x8)
	struct UBlockyMenuItemObject_Search* SearchResults; // 0x3C0(0x8)
	struct UBlockyGraphWidget* HostGraphWidget; // 0x3C8(0x8)
	uint8_t SearchResultVisibleType; // 0x3D0(0x1)
	uint8_t Pad_0x3D1[0x7]; // 0x3D1(0x7)
	struct TArray<struct FString> SearchHistories; // 0x3D8(0x10)


	// Object: Function BlockyLua.BlockySearchWidget.StoreLastSelectedMenuItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd5bc
	// Params: [ Num(1) Size(0x1) ]
	void StoreLastSelectedMenuItems(bool OverrideLastData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA8F68
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchWidget.ShouldCommitString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x106bcd500
	// Params: [ Num(2) Size(0x19) ]
	bool ShouldCommitString(struct FText& Value);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BA8ED0
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BA8F68
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchWidget.SetSearchHistories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd41c
	// Params: [ Num(1) Size(0x10) ]
	void SetSearchHistories(struct TArray<struct FString> searchArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F86A94
	// [Call #4] RVA: 0x106BA9ED4
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA8ED0
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106BA8F68
	// [Call #22] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySearchWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd3a0
	// Params: [ Num(1) Size(0x8) ]
	void SetResult(struct UPresetDesc* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA92F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F86A94
	// [Call #7] RVA: 0x106BA9ED4
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104F0F380
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106BA8ED0
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockySearchWidget.SetGraphWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd324
	// Params: [ Num(1) Size(0x8) ]
	void SetGraphWidget(struct UBlockyGraphWidget* InGraphWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9C38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA92F8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F86A94
	// [Call #10] RVA: 0x106BA9ED4
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104F0F380
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.SearchMatchingResults
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd27c
	// Params: [ Num(2) Size(0x11) ]
	bool SearchMatchingResults(struct FString SearchStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9378
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA9C38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA92F8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F86A94
	// [Call #16] RVA: 0x106BA9ED4
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8B9F8

	// Object: Function BlockyLua.BlockySearchWidget.ScrollToTabContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd200
	// Params: [ Num(1) Size(0x8) ]
	void ScrollToTabContent(struct UBlockySearchResultsTab* NewSelectedTab);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA92F8
	// [Call #16] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockySearchWidget.SaveSearchHistories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd1ec
	// Params: [ Num(0) Size(0x0) ]
	void SaveSearchHistories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA92F8

	// Object: Function BlockyLua.BlockySearchWidget.RevertLastSelectedMenuItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd1d8
	// Params: [ Num(0) Size(0x0) ]
	void RevertLastSelectedMenuItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA92F8

	// Object: Function BlockyLua.BlockySearchWidget.RefreshTabContainerView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd1c4
	// Params: [ Num(0) Size(0x0) ]
	void RefreshTabContainerView();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA92F8

	// Object: Function BlockyLua.BlockySearchWidget.RefreshSearchResultsView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd1b0
	// Params: [ Num(0) Size(0x0) ]
	void RefreshSearchResultsView();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.LoadSearchHistories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd19c
	// Params: [ Num(0) Size(0x0) ]
	void LoadSearchHistories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA9378
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA9C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.IsSearchUseCase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcd168
	// Params: [ Num(1) Size(0x1) ]
	bool IsSearchUseCase();
	// [Call #1] RVA: 0x106BA95A8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BA9A9C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA9378
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BA9C38

	// Object: Function BlockyLua.BlockySearchWidget.InitLoopScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bcd044
	// Params: [ Num(2) Size(0x18) ]
	void InitLoopScroll(struct UBlockyLoopScrollBox* ScrollBox, struct TArray<struct UPresetDesc*> arrayPresets);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10230949C
	// [Call #6] RVA: 0x106BA9BE8
	// [Call #7] RVA: 0x1023089F4
	// [Call #8] RVA: 0x1023089F4
	// [Call #9] RVA: 0x1023089F4
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x1023089F4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106BA95A8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106BA9A9C

	// Object: Function BlockyLua.BlockySearchWidget.HasMenuSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcd010
	// Params: [ Num(1) Size(0x1) ]
	bool HasMenuSelected();
	// [Call #1] RVA: 0x106BA92F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10230949C
	// [Call #7] RVA: 0x106BA9BE8
	// [Call #8] RVA: 0x1023089F4
	// [Call #9] RVA: 0x1023089F4
	// [Call #10] RVA: 0x1023089F4
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x1023089F4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BA95A8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.HasAnySearchResults
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccfdc
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnySearchResults();
	// [Call #1] RVA: 0x106BA9A80
	// [Call #2] RVA: 0x106BA92F0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10230949C
	// [Call #8] RVA: 0x106BA9BE8
	// [Call #9] RVA: 0x1023089F4
	// [Call #10] RVA: 0x1023089F4
	// [Call #11] RVA: 0x1023089F4
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x1023089F4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x106BA95A8
	// [Call #17] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockySearchWidget.HasAnyHistory
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccfa8
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnyHistory();
	// [Call #1] RVA: 0x106BA9EE4
	// [Call #2] RVA: 0x106BA9A80
	// [Call #3] RVA: 0x106BA92F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10230949C
	// [Call #9] RVA: 0x106BA9BE8
	// [Call #10] RVA: 0x1023089F4
	// [Call #11] RVA: 0x1023089F4
	// [Call #12] RVA: 0x1023089F4
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x1023089F4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106BA95A8

	// Object: Function BlockyLua.BlockySearchWidget.GetTotalSearchedNums
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccf74
	// Params: [ Num(1) Size(0x4) ]
	int GetTotalSearchedNums();
	// [Call #1] RVA: 0x106BA9A40
	// [Call #2] RVA: 0x106BA9EE4
	// [Call #3] RVA: 0x106BA9A80
	// [Call #4] RVA: 0x106BA92F0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10230949C
	// [Call #10] RVA: 0x106BA9BE8
	// [Call #11] RVA: 0x1023089F4
	// [Call #12] RVA: 0x1023089F4
	// [Call #13] RVA: 0x1023089F4
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x1023089F4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x106BA95A8

	// Object: Function BlockyLua.BlockySearchWidget.GetSearchHistories
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccf10
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSearchHistories();
	// [Call #1] RVA: 0x106BA9E80
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x106BA9A40
	// [Call #7] RVA: 0x106BA9EE4
	// [Call #8] RVA: 0x106BA9A80
	// [Call #9] RVA: 0x106BA92F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10230949C
	// [Call #15] RVA: 0x106BA9BE8
	// [Call #16] RVA: 0x1023089F4
	// [Call #17] RVA: 0x1023089F4
	// [Call #18] RVA: 0x1023089F4
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x1023089F4
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockySearchWidget.GetPresetsSearchedNums
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccedc
	// Params: [ Num(1) Size(0x4) ]
	int GetPresetsSearchedNums();
	// [Call #1] RVA: 0x106BA9A78
	// [Call #2] RVA: 0x106BA9E80
	// [Call #3] RVA: 0x101FA5F38
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x106BA9A40
	// [Call #8] RVA: 0x106BA9EE4
	// [Call #9] RVA: 0x106BA9A80
	// [Call #10] RVA: 0x106BA92F0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10230949C
	// [Call #16] RVA: 0x106BA9BE8
	// [Call #17] RVA: 0x1023089F4
	// [Call #18] RVA: 0x1023089F4

	// Object: Function BlockyLua.BlockySearchWidget.GetPresetDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccea8
	// Params: [ Num(1) Size(0x8) ]
	struct UPresetDesc* GetPresetDesc();
	// [Call #1] RVA: 0x106BA9C04
	// [Call #2] RVA: 0x106BA9A78
	// [Call #3] RVA: 0x106BA9E80
	// [Call #4] RVA: 0x101FA5F38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x106BA9A40
	// [Call #9] RVA: 0x106BA9EE4
	// [Call #10] RVA: 0x106BA9A80
	// [Call #11] RVA: 0x106BA92F0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10230949C

	// Object: Function BlockyLua.BlockySearchWidget.GetHistoryStoreNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcce74
	// Params: [ Num(1) Size(0x4) ]
	int GetHistoryStoreNum();
	// [Call #1] RVA: 0x106BA9E54
	// [Call #2] RVA: 0x106BA9C04
	// [Call #3] RVA: 0x106BA9A78
	// [Call #4] RVA: 0x106BA9E80
	// [Call #5] RVA: 0x101FA5F38
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x106BA9A40
	// [Call #10] RVA: 0x106BA9EE4
	// [Call #11] RVA: 0x106BA9A80
	// [Call #12] RVA: 0x106BA92F0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.GetHistoryNums
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcce40
	// Params: [ Num(1) Size(0x4) ]
	int GetHistoryNums();
	// [Call #1] RVA: 0x106BA9EDC
	// [Call #2] RVA: 0x106BA9E54
	// [Call #3] RVA: 0x106BA9C04
	// [Call #4] RVA: 0x106BA9A78
	// [Call #5] RVA: 0x106BA9E80
	// [Call #6] RVA: 0x101FA5F38
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BA9A40
	// [Call #11] RVA: 0x106BA9EE4
	// [Call #12] RVA: 0x106BA9A80
	// [Call #13] RVA: 0x106BA92F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockySearchWidget.GetGraphSearchedNums
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bcce0c
	// Params: [ Num(1) Size(0x4) ]
	int GetGraphSearchedNums();
	// [Call #1] RVA: 0x106BA9A30
	// [Call #2] RVA: 0x106BA9EDC
	// [Call #3] RVA: 0x106BA9E54
	// [Call #4] RVA: 0x106BA9C04
	// [Call #5] RVA: 0x106BA9A78
	// [Call #6] RVA: 0x106BA9E80
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x106BA9A40
	// [Call #12] RVA: 0x106BA9EE4
	// [Call #13] RVA: 0x106BA9A80
	// [Call #14] RVA: 0x106BA92F0

	// Object: Function BlockyLua.BlockySearchWidget.GetBlockSearchedNums
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bccdd8
	// Params: [ Num(1) Size(0x4) ]
	int GetBlockSearchedNums();
	// [Call #1] RVA: 0x106BA9A20
	// [Call #2] RVA: 0x106BA9A30
	// [Call #3] RVA: 0x106BA9EDC
	// [Call #4] RVA: 0x106BA9E54
	// [Call #5] RVA: 0x106BA9C04
	// [Call #6] RVA: 0x106BA9A78
	// [Call #7] RVA: 0x106BA9E80
	// [Call #8] RVA: 0x101FA5F38
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106BA9A40
	// [Call #13] RVA: 0x106BA9EE4
	// [Call #14] RVA: 0x106BA9A80

	// Object: Function BlockyLua.BlockySearchWidget.FilterSearchResultVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccd5c
	// Params: [ Num(1) Size(0x1) ]
	void FilterSearchResultVisible(uint8_t InSearchResultVisibleType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9CA0
	// [Call #4] RVA: 0x106BA9A20
	// [Call #5] RVA: 0x106BA9A30
	// [Call #6] RVA: 0x106BA9EDC
	// [Call #7] RVA: 0x106BA9E54
	// [Call #8] RVA: 0x106BA9C04
	// [Call #9] RVA: 0x106BA9A78
	// [Call #10] RVA: 0x106BA9E80
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BA9A40

	// Object: Function BlockyLua.BlockySearchWidget.EmptyListItemSeleceted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccd48
	// Params: [ Num(0) Size(0x0) ]
	void EmptyListItemSeleceted();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9CA0
	// [Call #4] RVA: 0x106BA9A20
	// [Call #5] RVA: 0x106BA9A30
	// [Call #6] RVA: 0x106BA9EDC
	// [Call #7] RVA: 0x106BA9E54
	// [Call #8] RVA: 0x106BA9C04
	// [Call #9] RVA: 0x106BA9A78
	// [Call #10] RVA: 0x106BA9E80
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BA9A40

	// Object: Function BlockyLua.BlockySearchWidget.DoSearching
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void DoSearching(struct FString SearchStr);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockySearchWidget.ClearTabSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccd34
	// Params: [ Num(0) Size(0x0) ]
	void ClearTabSelected();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9CA0
	// [Call #4] RVA: 0x106BA9A20
	// [Call #5] RVA: 0x106BA9A30
	// [Call #6] RVA: 0x106BA9EDC
	// [Call #7] RVA: 0x106BA9E54
	// [Call #8] RVA: 0x106BA9C04
	// [Call #9] RVA: 0x106BA9A78
	// [Call #10] RVA: 0x106BA9E80
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockySearchWidget.ClearSearchHistories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccd20
	// Params: [ Num(0) Size(0x0) ]
	void ClearSearchHistories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9CA0
	// [Call #4] RVA: 0x106BA9A20
	// [Call #5] RVA: 0x106BA9A30
	// [Call #6] RVA: 0x106BA9EDC
	// [Call #7] RVA: 0x106BA9E54
	// [Call #8] RVA: 0x106BA9C04
	// [Call #9] RVA: 0x106BA9A78
	// [Call #10] RVA: 0x106BA9E80
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockySearchWidget.ClearMenuSelectionStore
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccd0c
	// Params: [ Num(0) Size(0x0) ]
	void ClearMenuSelectionStore();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA9CA0
	// [Call #4] RVA: 0x106BA9A20
	// [Call #5] RVA: 0x106BA9A30
	// [Call #6] RVA: 0x106BA9EDC
	// [Call #7] RVA: 0x106BA9E54
	// [Call #8] RVA: 0x106BA9C04
	// [Call #9] RVA: 0x106BA9A78
	// [Call #10] RVA: 0x106BA9E80
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8

	// Object: Function BlockyLua.BlockySearchWidget.AddSearchHistory
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bccc28
	// Params: [ Num(1) Size(0x10) ]
	void AddSearchHistory(struct FString NewHistory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106BA9CE8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BA9CA0
	// [Call #15] RVA: 0x106BA9A20
	// [Call #16] RVA: 0x106BA9A30
	// [Call #17] RVA: 0x106BA9EDC
};

// Object: Class BlockyLua.BlockySelectFromSceneWidget
// Size: 0x2C0 (Inherited: 0x260)
struct UBlockySelectFromSceneWidget : UUserWidget
{
	struct UBlockBase* LinkedSlotHost; // 0x260(0x8)
	uint8_t Pad_0x268[0x18]; // 0x268(0x18)
	struct UBlockyGraphData* HostWidget; // 0x280(0x8)
	struct UPresetDesc* PresetDesc; // 0x288(0x8)
	struct TArray<struct UObjectDesc*> OtherPresetDescs; // 0x290(0x10)
	struct FText DefaultShowName; // 0x2A0(0x18)
	struct UObjectDesc* ObjectDesc; // 0x2B8(0x8)


	// Object: Function BlockyLua.BlockySelectFromSceneWidget.SetPreset
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetPreset(struct UPresetDesc* Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockySelectFromSceneWidget.SetObjectDesc
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetObjectDesc(struct UObjectDesc* Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockySelectFromSceneWidget.SetImageShowIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd0f0c
	// Params: [ Num(2) Size(0x9) ]
	bool SetImageShowIcon(struct UImage* Image);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA03F8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySelectFromSceneWidget.OnReceiveCustomSelectionResult
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd0e90
	// Params: [ Num(1) Size(0x8) ]
	void OnReceiveCustomSelectionResult(struct UObjectDesc* Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA0598
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA03F8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockySelectFromSceneWidget.CallSelectScenePreset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd0e7c
	// Params: [ Num(0) Size(0x0) ]
	void CallSelectScenePreset();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA0598
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA03F8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyStringWidget
// Size: 0x2E8 (Inherited: 0x260)
struct UBlockyStringWidget : UUserWidget
{
	struct TMap<int, struct FSlotData> ResultSlotsMap; // 0x260(0x50)
	struct UBlockBase* LinkedSlotHost; // 0x2B0(0x8)
	uint8_t Pad_0x2B8[0x18]; // 0x2B8(0x18)
	struct UBlockyGraphData* HostWidget; // 0x2D0(0x8)
	struct FVector2D TextBoxSize; // 0x2D8(0x8)
	bool IsFinishedInput; // 0x2E0(0x1)
	uint8_t Pad_0x2E1[0x7]; // 0x2E1(0x7)


	// Object: Function BlockyLua.BlockyStringWidget.StrDelEnt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bd14a4
	// Params: [ Num(2) Size(0x30) ]
	struct FText StrDelEnt(struct FText& Value);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BA0A84
	// [Call #5] RVA: 0x104F0F4CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyStringWidget.StoreSlotDataWithSerialId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd1428
	// Params: [ Num(1) Size(0x4) ]
	void StoreSlotDataWithSerialId(int SerialId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA0B44
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA0A84
	// [Call #8] RVA: 0x104F0F4CC
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyStringWidget.SetText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyStringWidget.SetResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd1350
	// Params: [ Num(2) Size(0x14) ]
	void SetResult(struct FString Value, int SerialId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA063C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BA0B44
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA0A84
	// [Call #16] RVA: 0x104F0F4CC
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C
};

// Object: Class BlockyLua.CustomizeEditableText
// Size: 0x5C0 (Inherited: 0x500)
struct UCustomizeEditableText : UEditableText
{
	uint8_t Pad_0x500[0x90]; // 0x500(0x90)
	struct FScriptMulticastDelegate OnTextPreCommitted; // 0x590(0x10)
	struct FScriptMulticastDelegate OnTextReceiveCommitted; // 0x5A0(0x10)
	int TextCountLimit; // 0x5B0(0x4)
	int SerialId; // 0x5B4(0x4)
	bool LimitEmojiInput; // 0x5B8(0x1)
	bool IsReceiveCheckStringResult; // 0x5B9(0x1)
	uint8_t Pad_0x5BA[0x6]; // 0x5BA(0x6)


	// Object: Function BlockyLua.CustomizeEditableText.SetNewText
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bd1a00
	// Params: [ Num(1) Size(0x18) ]
	void SetNewText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x106BA19C4
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLua.CustomizeEditableText.ReceiveCheckStringResultProcess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106bd18c4
	// Params: [ Num(3) Size(0x30) ]
	void ReceiveCheckStringResultProcess(bool Result, struct FString ValidString, struct FCheckStringHandleData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA15F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x106BA19C4
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function BlockyLua.CustomizeEditableText.OpenKeyBoard
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bd18b0
	// Params: [ Num(0) Size(0x0) ]
	void OpenKeyBoard();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA15F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x106BA19C4
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: DelegateFunction BlockyLua.CustomizeEditableText.OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature(struct FText& CommittedText, enum class ETextCommit CommitMethod, int SerialId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.CustomizeEditableText.GetValidText
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bd184c
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetValidText();
	// [Call #1] RVA: 0x106BA19B8
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA15F0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104F0F380
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104F0F458
	// [Call #20] RVA: 0x106BA19C4
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
};

// Object: Class BlockyLua.CustomizeEditableTextBox
// Size: 0xD70 (Inherited: 0xCB0)
struct UCustomizeEditableTextBox : UEditableTextBox
{
	uint8_t Pad_0xCB0[0x90]; // 0xCB0(0x90)
	struct FScriptMulticastDelegate OnTextPreCommitted; // 0xD40(0x10)
	struct FScriptMulticastDelegate OnTextReceiveCommitted; // 0xD50(0x10)
	int TextCountLimit; // 0xD60(0x4)
	int SerialId; // 0xD64(0x4)
	bool LimitEmojiInput; // 0xD68(0x1)
	bool IsReceiveCheckStringResult; // 0xD69(0x1)
	uint8_t Pad_0xD6A[0x6]; // 0xD6A(0x6)


	// Object: Function BlockyLua.CustomizeEditableTextBox.SetNewText
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bd1ef4
	// Params: [ Num(1) Size(0x18) ]
	void SetNewText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x106BA2930
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10508F76C

	// Object: Function BlockyLua.CustomizeEditableTextBox.ReceiveCheckStringResultProcess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106bd1db8
	// Params: [ Num(3) Size(0x30) ]
	void ReceiveCheckStringResultProcess(bool Result, struct FString ValidString, struct FCheckStringHandleData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA255C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x106BA2930
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: DelegateFunction BlockyLua.CustomizeEditableTextBox.OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature(struct FText& CommittedText, enum class ETextCommit CommitMethod, int SerialId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.CustomizeEditableTextBox.GetValidText
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bd1d54
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetValidText();
	// [Call #1] RVA: 0x106BA2924
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA255C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104F0F380
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104F0F458
	// [Call #20] RVA: 0x106BA2930
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
};

// Object: Class BlockyLua.CustomizeMultiLineEditableTextBox
// Size: 0xFA8 (Inherited: 0xEE8)
struct UCustomizeMultiLineEditableTextBox : UMultiLineEditableTextBox
{
	uint8_t Pad_0xEE8[0x90]; // 0xEE8(0x90)
	struct FScriptMulticastDelegate OnTextPreCommitted; // 0xF78(0x10)
	struct FScriptMulticastDelegate OnTextReceiveCommitted; // 0xF88(0x10)
	int TextCountLimit; // 0xF98(0x4)
	int SerialId; // 0xF9C(0x4)
	bool LimitEmojiInput; // 0xFA0(0x1)
	bool IsReceiveCheckStringResult; // 0xFA1(0x1)
	uint8_t Pad_0xFA2[0x6]; // 0xFA2(0x6)


	// Object: Function BlockyLua.CustomizeMultiLineEditableTextBox.SetNewText
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x106bd249c
	// Params: [ Num(1) Size(0x18) ]
	void SetNewText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x106BA36CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function BlockyLua.CustomizeMultiLineEditableTextBox.ReceiveCheckStringResultProcess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106bd2360
	// Params: [ Num(3) Size(0x30) ]
	void ReceiveCheckStringResultProcess(bool Result, struct FString ValidString, struct FCheckStringHandleData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA32F8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x106BA36CC
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: DelegateFunction BlockyLua.CustomizeMultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnMultiLineEditableTextBoxCommittedWithSerialIdEvent__DelegateSignature(struct FText& CommittedText, enum class ETextCommit CommitMethod, int SerialId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.CustomizeMultiLineEditableTextBox.GetValidText
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bd22fc
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetValidText();
	// [Call #1] RVA: 0x106BA36C0
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA32F8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104F0F380
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104F0F458
	// [Call #20] RVA: 0x106BA36CC
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8

	// Object: Function BlockyLua.CustomizeMultiLineEditableTextBox.CheckStringValidProcess
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x106bd2204
	// Params: [ Num(2) Size(0x19) ]
	void CheckStringValidProcess(struct FText& InText, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA2FAC
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BA36C0
	// [Call #11] RVA: 0x104F0F4CC
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class BlockyLua.DeleteBlockUI
// Size: 0x68 (Inherited: 0x28)
struct UDeleteBlockUI : UObject
{
	struct FBlockRect rect; // 0x28(0x10)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
	struct UBrushData* BrushBG; // 0x48(0x8)
	uint8_t Pad_0x50[0xC]; // 0x50(0xC)
	bool IsInArrange; // 0x5C(0x1)
	uint8_t Pad_0x5D[0xB]; // 0x5D(0xB)
};

// Object: Class BlockyLua.BlockyAutoScrollBox
// Size: 0xB48 (Inherited: 0xB28)
struct UBlockyAutoScrollBox : UScrollBox
{
	uint8_t AutoScrollType; // 0xB28(0x1)
	uint8_t Pad_0xB29[0x3]; // 0xB29(0x3)
	float RollSpeed; // 0xB2C(0x4)
	float StayTimeWhenStart; // 0xB30(0x4)
	float StayTimeWhenEnd; // 0xB34(0x4)
	uint8_t Pad_0xB38[0x10]; // 0xB38(0x10)


	// Object: Function BlockyLua.BlockyAutoScrollBox.Tick
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bd29e8
	// Params: [ Num(1) Size(0x4) ]
	void Tick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyAutoScrollBox.SetTextPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd28f8
	// Params: [ Num(3) Size(0x14) ]
	void SetTextPadding(struct UTextBlock* Text, struct UScrollBoxSlot* boxSlot, float totalLength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BA3B44
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyLoopScrollBase
// Size: 0xCB0 (Inherited: 0xB28)
struct UBlockyLoopScrollBase : UScrollBox
{
	bool bDelayLoad; // 0xB28(0x1)
	uint8_t Pad_0xB29[0x3]; // 0xB29(0x3)
	float BlockyLuaEdgePadding; // 0xB2C(0x4)
	struct FScriptMulticastDelegate OnRefreshItem; // 0xB30(0x10)
	struct FScriptMulticastDelegate OnItemCreated; // 0xB40(0x10)
	struct FScriptMulticastDelegate OnChangeData; // 0xB50(0x10)
	uint8_t Pad_0xB60[0xE8]; // 0xB60(0xE8)
	bool bViewSizeInit; // 0xC48(0x1)
	uint8_t Pad_0xC49[0x3]; // 0xC49(0x3)
	float LastPresetTitleOffset; // 0xC4C(0x4)
	uint8_t Pad_0xC50[0x20]; // 0xC50(0x20)
	struct UBlockyPresetWidget* Host; // 0xC70(0x8)
	struct UBlockySearchWidget* SearchHost; // 0xC78(0x8)
	uint8_t Pad_0xC80[0x8]; // 0xC80(0x8)
	struct UWidget* ItemString; // 0xC88(0x8)
	struct UWidget* ItemIcon; // 0xC90(0x8)
	uint8_t Pad_0xC98[0x10]; // 0xC98(0x10)
	struct UCanvasPanel* CanvasPanel; // 0xCA8(0x8)


	// Object: Function BlockyLua.BlockyLoopScrollBase.UserScrolled
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bd35b4
	// Params: [ Num(1) Size(0x4) ]
	void UserScrolled(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA4FE0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLoopScrollBase.Tick
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bd3530
	// Params: [ Num(1) Size(0x4) ]
	void Tick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BA4FE0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLoopScrollBase.SetItemType
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd34b4
	// Params: [ Num(1) Size(0x8) ]
	void SetItemType(struct UWidget* _ItemType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA4050
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA4FE0
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLoopScrollBase.SetItemCount
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd3428
	// Params: [ Num(2) Size(0x5) ]
	bool SetItemCount(int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA411C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA4050
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BA4FE0
	// [Call #12] RVA: 0x10519022C

	// Object: Function BlockyLua.BlockyLoopScrollBase.RemoveItem
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd33ac
	// Params: [ Num(1) Size(0x4) ]
	void RemoveItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA48A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA411C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA4050
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BlockyLua.BlockyLoopScrollBase.RefreshItem
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd3320
	// Params: [ Num(2) Size(0x5) ]
	bool RefreshItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA45A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA48A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA411C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA4050
	// [Call #13] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLoopScrollBase.RefreshAllItems
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd330c
	// Params: [ Num(0) Size(0x0) ]
	void RefreshAllItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA45A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA48A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA411C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA4050
	// [Call #13] RVA: 0x10516D168

	// Object: DelegateFunction BlockyLua.BlockyLoopScrollBase.OnRefreshItem__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnRefreshItem__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLoopScrollBase.OnItemCreated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void OnItemCreated__DelegateSignature(struct UWidget* Item, int Index);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction BlockyLua.BlockyLoopScrollBase.OnChangeData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	void OnChangeData__DelegateSignature(struct UWidget* Item, int Index, struct FString Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BlockyLua.BlockyLoopScrollBase.LoopScrollBoxFilterStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd3274
	// Params: [ Num(1) Size(0x10) ]
	void LoopScrollBoxFilterStr(struct FString filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106B9FC3C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA45A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA48A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA411C

	// Object: Function BlockyLua.BlockyLoopScrollBase.LoopScrollBoxFilterByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bd31c8
	// Params: [ Num(1) Size(0x50) ]
	void LoopScrollBoxFilterByTag(struct TMap<int, struct FIntArrayWrapper>& Tags);
	// [Call #1] RVA: 0x106BCE120
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106B9FDEC
	// [Call #5] RVA: 0x106BB1CC0
	// [Call #6] RVA: 0x106BB1CC0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B9FC3C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BA45A0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106BA48A4

	// Object: Function BlockyLua.BlockyLoopScrollBase.InsertItem
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd314c
	// Params: [ Num(1) Size(0x4) ]
	void InsertItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA4738
	// [Call #4] RVA: 0x106BCE120
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106B9FDEC
	// [Call #8] RVA: 0x106BB1CC0
	// [Call #9] RVA: 0x106BB1CC0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106B9FC3C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106BA45A0

	// Object: Function BlockyLua.BlockyLoopScrollBase.GetWidgetIndex
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bd30c0
	// Params: [ Num(2) Size(0xC) ]
	int GetWidgetIndex(struct UWidget* Item);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA526C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BA4738
	// [Call #7] RVA: 0x106BCE120
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106B9FDEC
	// [Call #11] RVA: 0x106BB1CC0
	// [Call #12] RVA: 0x106BB1CC0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B9FC3C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyLoopScrollBase.GetItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd305c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UWidget*> GetItems();
	// [Call #1] RVA: 0x106BA461C
	// [Call #2] RVA: 0x103D8C73C
	// [Call #3] RVA: 0x1025A291C
	// [Call #4] RVA: 0x1025A291C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BA526C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BA4738
	// [Call #12] RVA: 0x106BCE120
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106B9FDEC
	// [Call #16] RVA: 0x106BB1CC0
	// [Call #17] RVA: 0x106BB1CC0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function BlockyLua.BlockyLoopScrollBase.GetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bd3028
	// Params: [ Num(1) Size(0x4) ]
	int GetItemCount();
	// [Call #1] RVA: 0x106BA4614
	// [Call #2] RVA: 0x106BA461C
	// [Call #3] RVA: 0x103D8C73C
	// [Call #4] RVA: 0x1025A291C
	// [Call #5] RVA: 0x1025A291C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BA526C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA4738
	// [Call #13] RVA: 0x106BCE120
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106B9FDEC
	// [Call #17] RVA: 0x106BB1CC0
	// [Call #18] RVA: 0x106BB1CC0
	// [Call #19] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyLoopScrollBase.GetIndexOfWidget
	// Flags: [Final|Native|Protected]
	// Offset: 0x106bd2f9c
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetIndexOfWidget(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA5344
	// [Call #4] RVA: 0x106BA4614
	// [Call #5] RVA: 0x106BA461C
	// [Call #6] RVA: 0x103D8C73C
	// [Call #7] RVA: 0x1025A291C
	// [Call #8] RVA: 0x1025A291C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BA526C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BA4738
	// [Call #16] RVA: 0x106BCE120

	// Object: Function BlockyLua.BlockyLoopScrollBase.ChangeData
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd2e68
	// Params: [ Num(3) Size(0x19) ]
	bool ChangeData(int Index, struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106BA4ACC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BA5344
	// [Call #17] RVA: 0x106BA4614
	// [Call #18] RVA: 0x106BA461C
	// [Call #19] RVA: 0x103D8C73C
	// [Call #20] RVA: 0x1025A291C
	// [Call #21] RVA: 0x1025A291C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function BlockyLua.BlockyLoopScrollBase.AutoSize
	// Flags: [Final|Native|Public]
	// Offset: 0x106bd2de4
	// Params: [ Num(1) Size(0x1) ]
	void AutoSize(bool bAutoSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BA4C58
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106BA4ACC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106BA5344
};

// Object: Class BlockyLua.BlockyLoopScrollBox
// Size: 0xCE8 (Inherited: 0xCB0)
struct UBlockyLoopScrollBox : UBlockyLoopScrollBase
{
	struct FVector2D StringItemSize; // 0xCB0(0x8)
	struct FVector2D IconItemSize; // 0xCB8(0x8)
	struct FVector2D StringItemPadding; // 0xCC0(0x8)
	struct FVector2D IconItemPadding; // 0xCC8(0x8)
	bool bAlignMagnetic; // 0xCD0(0x1)
	uint8_t Pad_0xCD1[0x17]; // 0xCD1(0x17)


	// Object: Function BlockyLua.BlockyLoopScrollBox.Tick
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bd3c14
	// Params: [ Num(1) Size(0x4) ]
	void Tick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x106BD3F70

	// Object: Function BlockyLua.BlockyLoopScrollBox.ScrollToItem
	// Flags: [Native|Public]
	// Offset: 0x106bd3b90
	// Params: [ Num(1) Size(0x4) ]
	void ScrollToItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
};

// Object: Class BlockyLua.BlockyLoopScrollGrid
// Size: 0xCD8 (Inherited: 0xCB0)
struct UBlockyLoopScrollGrid : UBlockyLoopScrollBase
{
	struct FVector2D ItemSize; // 0xCB0(0x8)
	struct FVector2D Padding; // 0xCB8(0x8)
	bool bAlignGrid; // 0xCC0(0x1)
	bool bAlignAnimation; // 0xCC1(0x1)
	uint8_t Pad_0xCC2[0x16]; // 0xCC2(0x16)


	// Object: Function BlockyLua.BlockyLoopScrollGrid.ScrollToItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106bd3e4c
	// Params: [ Num(1) Size(0x4) ]
	void ScrollToItem(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10518366C
	// [Call #7] RVA: 0x104FD0740
	// [Call #8] RVA: 0x1036A6C08
	// [Call #9] RVA: 0x105093FD0
};

