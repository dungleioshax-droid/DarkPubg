#pragma once

#include <cstdint>

// Object: Class CommonUIWidget.CommonInputBox
// Size: 0x2C8 (Inherited: 0x2C8)
struct UCommonInputBox : ULuaUserWidget
{
};

// Object: Class CommonUIWidget.CommonPopupBox
// Size: 0x2C8 (Inherited: 0x2C8)
struct UCommonPopupBox : ULuaUserWidget
{
};

// Object: Class CommonUIWidget.CommonSearchBox
// Size: 0x2C8 (Inherited: 0x2C8)
struct UCommonSearchBox : ULuaUserWidget
{
};

