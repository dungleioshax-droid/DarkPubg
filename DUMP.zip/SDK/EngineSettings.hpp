#pragma once

#include <cstdint>

// Object: Enum EngineSettings.EThreePlayerSplitScreenType
enum class EThreePlayerSplitScreenType : uint8_t
{
	FavorTop = 0,
	FavorBottom = 1,
	EThreePlayerSplitScreenType_MAX = 2
};

// Object: Enum EngineSettings.ETwoPlayerSplitScreenType
enum class ETwoPlayerSplitScreenType : uint8_t
{
	Horizontal = 0,
	Vertical = 1,
	ETwoPlayerSplitScreenType_MAX = 2
};

// Object: ScriptStruct EngineSettings.AutoCompleteCommand
// Size: 0x28 (Inherited: 0x0)
struct FAutoCompleteCommand
{
	struct FString Command; // 0x0(0x10)
	struct FString Desc; // 0x10(0x10)
	uint8_t Pad_0x20[0x8]; // 0x20(0x8)
};

// Object: ScriptStruct EngineSettings.GameModeName
// Size: 0x28 (Inherited: 0x0)
struct FGameModeName
{
	struct FString Name; // 0x0(0x10)
	struct FSoftClassPath GameMode; // 0x10(0x18)
};

// Object: Class EngineSettings.ConsoleSettings
// Size: 0x70 (Inherited: 0x28)
struct UConsoleSettings : UObject
{
	int MaxScrollbackSize; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FAutoCompleteCommand> ManualAutoCompleteList; // 0x30(0x10)
	struct TArray<struct FString> AutoCompleteMapPaths; // 0x40(0x10)
	float BackgroundOpacityPercentage; // 0x50(0x4)
	bool bOrderTopToBottom; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
	struct FColor InputColor; // 0x58(0x4)
	struct FColor HistoryColor; // 0x5C(0x4)
	struct FColor AutoCompleteCommandColor; // 0x60(0x4)
	struct FColor AutoCompleteCVarColor; // 0x64(0x4)
	struct FColor AutoCompleteFadedColor; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

// Object: Class EngineSettings.GameMapsSettings
// Size: 0x108 (Inherited: 0x28)
struct UGameMapsSettings : UObject
{
	struct FSoftObjectPath EditorStartupMap; // 0x28(0x18)
	struct FString LocalMapOptions; // 0x40(0x10)
	struct FSoftObjectPath TransitionMap; // 0x50(0x18)
	bool bUseSplitscreen; // 0x68(0x1)
	enum class ETwoPlayerSplitScreenType TwoPlayerSplitscreenLayout; // 0x69(0x1)
	enum class EThreePlayerSplitScreenType ThreePlayerSplitscreenLayout; // 0x6A(0x1)
	bool bOffsetPlayerGamepadIds; // 0x6B(0x1)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct FSoftClassPath GameInstanceClass; // 0x70(0x18)
	struct FSoftObjectPath GameDefaultMap; // 0x88(0x18)
	struct FSoftObjectPath ServerDefaultMap; // 0xA0(0x18)
	struct FSoftClassPath GlobalDefaultGameMode; // 0xB8(0x18)
	struct FSoftClassPath GlobalDefaultServerGameMode; // 0xD0(0x18)
	struct TArray<struct FGameModeName> GameModeMapPrefixes; // 0xE8(0x10)
	struct TArray<struct FGameModeName> GameModeClassAliases; // 0xF8(0x10)
};

// Object: Class EngineSettings.GameNetworkManagerSettings
// Size: 0x58 (Inherited: 0x28)
struct UGameNetworkManagerSettings : UObject
{
	int MinDynamicBandwidth; // 0x28(0x4)
	int MaxDynamicBandwidth; // 0x2C(0x4)
	int TotalNetBandwidth; // 0x30(0x4)
	int BadPingThreshold; // 0x34(0x4)
	uint8_t bIsStandbyCheckingEnabled : 1; // 0x38(0x1), Mask(0x1)
	uint8_t BitPad_0x38_1 : 7; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	float StandbyRxCheatTime; // 0x3C(0x4)
	float StandbyTxCheatTime; // 0x40(0x4)
	float PercentMissingForRxStandby; // 0x44(0x4)
	float PercentMissingForTxStandby; // 0x48(0x4)
	float PercentForBadPing; // 0x4C(0x4)
	float JoinInProgressStandbyWaitTime; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: Class EngineSettings.GameSessionSettings
// Size: 0x38 (Inherited: 0x28)
struct UGameSessionSettings : UObject
{
	int MaxSpectators; // 0x28(0x4)
	int MaxPlayers; // 0x2C(0x4)
	uint8_t bRequiresPushToTalk : 1; // 0x30(0x1), Mask(0x1)
	uint8_t BitPad_0x30_1 : 7; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: Class EngineSettings.GeneralEngineSettings
// Size: 0x28 (Inherited: 0x28)
struct UGeneralEngineSettings : UObject
{
};

// Object: Class EngineSettings.GeneralProjectSettings
// Size: 0x120 (Inherited: 0x28)
struct UGeneralProjectSettings : UObject
{
	struct FString CompanyName; // 0x28(0x10)
	struct FString CompanyDistinguishedName; // 0x38(0x10)
	struct FString CopyrightNotice; // 0x48(0x10)
	struct FString Description; // 0x58(0x10)
	struct FString Homepage; // 0x68(0x10)
	struct FString LicensingTerms; // 0x78(0x10)
	struct FString PrivacyPolicy; // 0x88(0x10)
	struct FGuid ProjectID; // 0x98(0x10)
	struct FString ProjectName; // 0xA8(0x10)
	struct FString ProjectVersion; // 0xB8(0x10)
	struct FString ProjectBranch; // 0xC8(0x10)
	struct FString SupportContact; // 0xD8(0x10)
	struct FText ProjectDisplayedTitle; // 0xE8(0x18)
	struct FText ProjectDebugTitleInfo; // 0x100(0x18)
	bool bShouldWindowPreserveAspectRatio; // 0x118(0x1)
	bool bUseBorderlessWindow; // 0x119(0x1)
	bool bStartInVR; // 0x11A(0x1)
	bool bStartInAR; // 0x11B(0x1)
	bool bAllowWindowResize; // 0x11C(0x1)
	bool bAllowClose; // 0x11D(0x1)
	bool bAllowMaximize; // 0x11E(0x1)
	bool bAllowMinimize; // 0x11F(0x1)
};

// Object: Class EngineSettings.HudSettings
// Size: 0x40 (Inherited: 0x28)
struct UHudSettings : UObject
{
	uint8_t bShowHUD : 1; // 0x28(0x1), Mask(0x1)
	uint8_t BitPad_0x28_1 : 7; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct TArray<struct FName> DebugDisplay; // 0x30(0x10)
};

