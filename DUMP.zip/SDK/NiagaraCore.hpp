#pragma once

#include <cstdint>

// Object: ScriptStruct NiagaraCore.NiagaraCompileHash
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraCompileHash
{
	struct TArray<uint8_t> DataHash; // 0x0(0x10)
};

// Object: Class NiagaraCore.NiagaraMergeable
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraMergeable : UObject
{
};

// Object: Class NiagaraCore.NiagaraDataInterfaceBase
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraDataInterfaceBase : UNiagaraMergeable
{
};

