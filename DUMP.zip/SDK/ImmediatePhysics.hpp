#pragma once

#include <cstdint>

// Object: Enum ImmediatePhysics.ESimulationSpace
enum class ESimulationSpace : uint8_t
{
	ComponentSpace = 0,
	WorldSpace = 1,
	RootBoneSpace = 2,
	ESimulationSpace_MAX = 3
};

// Object: ScriptStruct ImmediatePhysics.AnimNode_RigidBody
// Size: 0x2D8 (Inherited: 0x78)
struct FAnimNode_RigidBody : FAnimNode_SkeletalControlBase
{
	struct UPhysicsAsset* OverridePhysicsAsset; // 0x78(0x8)
	struct FVector OverrideWorldGravity; // 0x80(0xC)
	struct FVector ExternalForce; // 0x8C(0xC)
	enum class ECollisionChannel OverlapChannel; // 0x98(0x1)
	bool bEnableWorldGeometry; // 0x99(0x1)
	uint8_t Pad_0x9A[0x2]; // 0x9A(0x2)
	int SimulationSpace; // 0x9C(0x4)
	bool bOverrideWorldGravity; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float CachedBoundsScale; // 0xA4(0x4)
	bool bComponentSpaceSimulation; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x22F]; // 0xA9(0x22F)
};

