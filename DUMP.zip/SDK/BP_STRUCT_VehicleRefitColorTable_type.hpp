#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehicleRefitColorTable_type.BP_STRUCT_VehicleRefitColorTable_type
// Size: 0x48 (Inherited: 0x0)
struct FBP_STRUCT_VehicleRefitColorTable_type
{
	int ID_0_7607F1003C307130785E051708091744; // 0x0(0x4)
	int Gray_1_23C2528073E753A86CAE45C709177089; // 0x4(0x4)
	struct FString Color3_2_133F1A40217781872E65F412071E3F43; // 0x8(0x10)
	struct FString Color2_3_133E1A00217781862E65F413071E3F42; // 0x18(0x10)
	struct FString Color1_4_133D19C0217781852E65F410071E3F41; // 0x28(0x10)
	struct FString ColorBPPath_5_507BD54027F0DEF913818BAA07048B58; // 0x38(0x10)
};

