#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_StatEvent_VNG_type.BP_STRUCT_StatEvent_VNG_type
// Size: 0x25 (Inherited: 0x0)
struct FBP_STRUCT_StatEvent_VNG_type
{
	struct FString adjustAndroidToken_0_2B69D2C02D82C7E15A7A63F5075AEDFE; // 0x0(0x10)
	struct FString adjustIOSToken_1_34A49D40116F00617E8F2AED03BA599E; // 0x10(0x10)
	int id_2_66F452C07E8AB669370C7CC20C2FB044; // 0x20(0x4)
	bool unique_3_2662854074A21CCF2EDA1DF601192705; // 0x24(0x1)
};

