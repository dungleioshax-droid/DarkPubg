#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LobbyQueueControl_UIConfig_type.BP_STRUCT_LobbyQueueControl_UIConfig_type
// Size: 0x41 (Inherited: 0x0)
struct FBP_STRUCT_LobbyQueueControl_UIConfig_type
{
	int BigType_0_40DE1EC0180FAF994DDBA0C40ED48D05; // 0x0(0x4)
	bool IsUnlimited_1_22E86B802FA92E4A7725A5590F96AE24; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct FString KeyName_2_22737C401026D429084E417407E68B45; // 0x8(0x10)
	struct FString LobbyType_3_5318D8400C468EBB754620C40053D515; // 0x18(0x10)
	struct FString Param_4_2BB60E004F65CFE82D1A0EC80D70A0BD; // 0x28(0x10)
	int SmallType_5_27AD988016F05D5A404F5ED900FC4045; // 0x38(0x4)
	int UIKey_6_6693C38003A294E42D499D760D800909; // 0x3C(0x4)
	bool UIStackCheck_7_1724EE40618D04232488F13A0E05CD3B; // 0x40(0x1)
};

