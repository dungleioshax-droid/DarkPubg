#pragma once

#include <cstdint>

// Object: Enum UMG.ESlateVisibility
enum class ESlateVisibility : uint8_t
{
	Visible = 0,
	Collapsed = 1,
	Hidden = 2,
	HitTestInvisible = 3,
	SelfHitTestInvisible = 4,
	ESlateVisibility_MAX = 5
};

// Object: Enum UMG.EButtonOnClickSound
enum class EButtonOnClickSound : uint8_t
{
	None = 0,
	Click = 1,
	Confirm = 2,
	Switch = 3,
	Object_Click = 4,
	Start = 5,
	Close = 6,
	Hall_click = 7,
	Menu_open = 8,
	Menu_close = 9,
	Item_get = 10,
	Page = 11,
	Set = 12,
	EButtonOnClickSound_MAX = 13
};

// Object: Enum UMG.EButtonClickGroupEnum
enum class EButtonClickGroupEnum : uint8_t
{
	None = 0,
	GlobalGroupOne = 1,
	GlobalGroupTwo = 2,
	GlobalGroupThere = 3,
	GlobalGroupFour = 4,
	GlobalGroupFive = 5,
	ModuleGroupOne = 6,
	ModuleGroupTwo = 7,
	ModuleGroupThere = 8,
	ModuleGroupFour = 9,
	ModuleGroupFive = 10,
	EButtonClickGroupEnum_MAX = 11
};

// Object: Enum UMG.EVirtualKeyboardType
enum class EVirtualKeyboardType : uint8_t
{
	Default = 0,
	Number = 1,
	Web = 2,
	Email = 3,
	Password = 4,
	AlphaNumeric = 5,
	EVirtualKeyboardType_MAX = 6
};

// Object: Enum UMG.EAutoScrollType
enum class EAutoScrollType : uint8_t
{
	LeftRight = 0,
	PingPong = 1,
	EAutoScrollType_MAX = 2
};

// Object: Enum UMG.EUMGSequencePlayMode
enum class EUMGSequencePlayMode : uint8_t
{
	Forward = 0,
	Reverse = 1,
	PingPong = 2,
	EUMGSequencePlayMode_MAX = 3
};

// Object: Enum UMG.EWidgetTickFrequency
enum class EWidgetTickFrequency : uint8_t
{
	Never = 0,
	Auto = 1,
	EWidgetTickFrequency_MAX = 2
};

// Object: Enum UMG.EDragPivot
enum class EDragPivot : uint8_t
{
	MouseDown = 0,
	TopLeft = 1,
	TopCenter = 2,
	TopRight = 3,
	CenterLeft = 4,
	CenterCenter = 5,
	CenterRight = 6,
	BottomLeft = 7,
	BottomCenter = 8,
	BottomRight = 9,
	EDragPivot_MAX = 10
};

// Object: Enum UMG.ESlateSizeRule
enum class ESlateSizeRule : uint8_t
{
	Automatic = 0,
	Fill = 1,
	ESlateSizeRule_MAX = 2
};

// Object: Enum UMG.EWidgetDesignFlags
enum class EWidgetDesignFlags : uint8_t
{
	None = 0,
	Designing = 1,
	ShowOutline = 2,
	ExecutePreConstruct = 4,
	SimluateIphoneXNotch = 8,
	EWidgetDesignFlags_MAX = 9
};

// Object: Enum UMG.EBindingKind
enum class EBindingKind : uint8_t
{
	Function = 0,
	Property = 1,
	EBindingKind_MAX = 2
};

// Object: Enum UMG.EWidgetGeometryMode
enum class EWidgetGeometryMode : uint8_t
{
	Plane = 0,
	Cylinder = 1,
	EWidgetGeometryMode_MAX = 2
};

// Object: Enum UMG.EWidgetBlendMode
enum class EWidgetBlendMode : uint8_t
{
	Opaque = 0,
	Masked = 1,
	Transparent = 2,
	EWidgetBlendMode_MAX = 3
};

// Object: Enum UMG.EWidgetTimingPolicy
enum class EWidgetTimingPolicy : uint8_t
{
	RealTime = 0,
	GameTime = 1,
	EWidgetTimingPolicy_MAX = 2
};

// Object: Enum UMG.EWidgetSpace
enum class EWidgetSpace : uint8_t
{
	World = 0,
	Screen = 1,
	EWidgetSpace_MAX = 2
};

// Object: Enum UMG.EWidgetInteractionSource
enum class EWidgetInteractionSource : uint8_t
{
	World = 0,
	Mouse = 1,
	CenterScreen = 2,
	Custom = 3,
	EWidgetInteractionSource_MAX = 4
};

// Object: ScriptStruct UMG.EventReply
// Size: 0xB8 (Inherited: 0x0)
struct FEventReply
{
	uint8_t Pad_0x0[0xB8]; // 0x0(0xB8)
};

// Object: ScriptStruct UMG.WidgetTransform
// Size: 0x1C (Inherited: 0x0)
struct FWidgetTransform
{
	struct FVector2D Translation; // 0x0(0x8)
	struct FVector2D Scale; // 0x8(0x8)
	struct FVector2D Shear; // 0x10(0x8)
	float Angle; // 0x18(0x4)
};

// Object: ScriptStruct UMG.ShapedTextOptions
// Size: 0x4 (Inherited: 0x0)
struct FShapedTextOptions
{
	uint8_t bOverride_TextShapingMethod : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bOverride_TextFlowDirection : 1; // 0x0(0x1), Mask(0x2)
	uint8_t BitPad_0x0_2 : 6; // 0x0(0x1)
	uint8_t TextShapingMethod; // 0x1(0x1)
	uint8_t TextFlowDirection; // 0x2(0x1)
	uint8_t Pad_0x3[0x1]; // 0x3(0x1)
};

// Object: ScriptStruct UMG.AnchorData
// Size: 0x28 (Inherited: 0x0)
struct FAnchorData
{
	struct FMargin Offsets; // 0x0(0x10)
	struct FAnchors Anchors; // 0x10(0x10)
	struct FVector2D Alignment; // 0x20(0x8)
};

// Object: ScriptStruct UMG.PaintContext
// Size: 0x30 (Inherited: 0x0)
struct FPaintContext
{
	uint8_t Pad_0x0[0x30]; // 0x0(0x30)
};

// Object: ScriptStruct UMG.NamedSlotBinding
// Size: 0x10 (Inherited: 0x0)
struct FNamedSlotBinding
{
	struct FName Name; // 0x0(0x8)
	struct UWidget* Content; // 0x8(0x8)
};

// Object: ScriptStruct UMG.DynamicPropertyPath
// Size: 0x10 (Inherited: 0x0)
struct FDynamicPropertyPath
{
	struct TArray<struct FPropertyPathSegment> Segments; // 0x0(0x10)
};

// Object: ScriptStruct UMG.PropertyPathSegment
// Size: 0x20 (Inherited: 0x0)
struct FPropertyPathSegment
{
	struct FName Name; // 0x0(0x8)
	int ArrayIndex; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct UStruct* Struct; // 0x10(0x8)
	struct UField* Field; // 0x18(0x8)
};

// Object: ScriptStruct UMG.MovieScene2DTransformSectionTemplate
// Size: 0x358 (Inherited: 0x40)
struct FMovieScene2DTransformSectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve Translation[0x2]; // 0x40(0xE0)
	struct FRichCurve Rotation; // 0x120(0x70)
	struct FRichCurve Scale[0x2]; // 0x190(0xE0)
	struct FRichCurve Shear[0x2]; // 0x270(0xE0)
	uint8_t BlendType; // 0x350(0x1)
	uint8_t Pad_0x351[0x7]; // 0x351(0x7)
};

// Object: ScriptStruct UMG.MovieSceneMarginSectionTemplate
// Size: 0x208 (Inherited: 0x40)
struct FMovieSceneMarginSectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve TopCurve; // 0x40(0x70)
	struct FRichCurve LeftCurve; // 0xB0(0x70)
	struct FRichCurve RightCurve; // 0x120(0x70)
	struct FRichCurve BottomCurve; // 0x190(0x70)
	uint8_t BlendType; // 0x200(0x1)
	uint8_t Pad_0x201[0x7]; // 0x201(0x7)
};

// Object: ScriptStruct UMG.MovieSceneWAnimTimeSectionTemplate
// Size: 0x208 (Inherited: 0x40)
struct FMovieSceneWAnimTimeSectionTemplate : FMovieScenePropertySectionTemplate
{
	struct FRichCurve PlayTimeCurve_1; // 0x40(0x70)
	struct FRichCurve PlayTimeCurve_2; // 0xB0(0x70)
	struct FRichCurve PlayTimeCurve_3; // 0x120(0x70)
	struct FRichCurve PlayTimeCurve_4; // 0x190(0x70)
	uint8_t BlendType; // 0x200(0x1)
	uint8_t Pad_0x201[0x7]; // 0x201(0x7)
};

// Object: ScriptStruct UMG.MovieSceneWidgetMaterialSectionTemplate
// Size: 0x58 (Inherited: 0x48)
struct FMovieSceneWidgetMaterialSectionTemplate : FMovieSceneParameterSectionTemplate
{
	struct TArray<struct FName> BrushPropertyNamePath; // 0x48(0x10)
};

// Object: ScriptStruct UMG.SlateMeshVertex
// Size: 0x3C (Inherited: 0x0)
struct FSlateMeshVertex
{
	struct FVector2D Position; // 0x0(0x8)
	struct FColor Color; // 0x8(0x4)
	struct FVector2D UV0; // 0xC(0x8)
	struct FVector2D UV1; // 0x14(0x8)
	struct FVector2D UV2; // 0x1C(0x8)
	struct FVector2D UV3; // 0x24(0x8)
	struct FVector2D UV4; // 0x2C(0x8)
	struct FVector2D UV5; // 0x34(0x8)
};

// Object: ScriptStruct UMG.SlateChildSize
// Size: 0x8 (Inherited: 0x0)
struct FSlateChildSize
{
	float Value; // 0x0(0x4)
	enum class ESlateSizeRule SizeRule; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct UMG.LazyLoadBinding
// Size: 0x18 (Inherited: 0x0)
struct FLazyLoadBinding
{
	struct FString Name; // 0x0(0x10)
	struct TWeakObjectPtr<struct UPanelSlot> PanelSlot; // 0x10(0x8)
};

// Object: ScriptStruct UMG.WidgetAnimationBinding
// Size: 0x28 (Inherited: 0x0)
struct FWidgetAnimationBinding
{
	struct FName WidgetName; // 0x0(0x8)
	struct FName SlotWidgetName; // 0x8(0x8)
	struct FGuid AnimationGuid; // 0x10(0x10)
	bool bIsRootWidget; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: ScriptStruct UMG.DelegateRuntimeBinding
// Size: 0x38 (Inherited: 0x0)
struct FDelegateRuntimeBinding
{
	struct FString ObjectName; // 0x0(0x10)
	struct FName PropertyName; // 0x10(0x8)
	struct FName FunctionName; // 0x18(0x8)
	struct FDynamicPropertyPath SourcePath; // 0x20(0x10)
	uint8_t Kind; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: ScriptStruct UMG.WidgetNavigationData
// Size: 0x18 (Inherited: 0x0)
struct FWidgetNavigationData
{
	uint8_t Rule; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FName WidgetToFocus; // 0x8(0x8)
	struct TWeakObjectPtr<struct UWidget> Widget; // 0x10(0x8)
};

// Object: Class UMG.Visual
// Size: 0x28 (Inherited: 0x28)
struct UVisual : UObject
{
};

// Object: Class UMG.Widget
// Size: 0x100 (Inherited: 0x28)
struct UWidget : UVisual
{
	struct UPanelSlot* Slot; // 0x28(0x8)
	DelegateProperty bIsEnabledDelegate; // 0x30(0x10)
	struct FText ToolTipText; // 0x40(0x18)
	DelegateProperty ToolTipTextDelegate; // 0x58(0x10)
	struct UWidget* ToolTipWidget; // 0x68(0x8)
	DelegateProperty ToolTipWidgetDelegate; // 0x70(0x10)
	DelegateProperty VisibilityDelegate; // 0x80(0x10)
	struct FWidgetTransform RenderTransform; // 0x90(0x1C)
	struct FVector2D RenderTransformPivot; // 0xAC(0x8)
	uint8_t bIsVariable : 1; // 0xB4(0x1), Mask(0x1)
	uint8_t bCreatedByConstructionScript : 1; // 0xB4(0x1), Mask(0x2)
	uint8_t bIsEnabled : 1; // 0xB4(0x1), Mask(0x4)
	uint8_t bOverride_Cursor : 1; // 0xB4(0x1), Mask(0x8)
	uint8_t bIsVolatile : 1; // 0xB4(0x1), Mask(0x10)
	uint8_t bIsVolatileThrottle : 1; // 0xB4(0x1), Mask(0x20)
	uint8_t bDisableVolatileInSlateGI : 1; // 0xB4(0x1), Mask(0x40)
	uint8_t bWriteSceneZBuffer : 1; // 0xB4(0x1), Mask(0x80)
	uint8_t bWriteSceneZBufferNew : 1; // 0xB5(0x1), Mask(0x1)
	uint8_t BitPad_0xB5_1 : 7; // 0xB5(0x1)
	uint8_t UsedLayerPolicy; // 0xB6(0x1)
	uint8_t PreservedLayerNum; // 0xB7(0x1)
	enum class EMouseCursor Cursor; // 0xB8(0x1)
	uint8_t Clipping; // 0xB9(0x1)
	uint8_t Visibility; // 0xBA(0x1)
	bool bVisiblePass; // 0xBB(0x1)
	uint8_t WidgetVisible; // 0xBC(0x1)
	bool bOpenReciveClick; // 0xBD(0x1)
	bool bReciveClick; // 0xBE(0x1)
	uint8_t Pad_0xBF[0x1]; // 0xBF(0x1)
	struct UWidgetNavigation* Navigation; // 0xC0(0x8)
	uint8_t Pad_0xC8[0x28]; // 0xC8(0x28)
	struct TArray<struct UPropertyBinding*> NativeBindings; // 0xF0(0x10)


	// Object: Function UMG.Widget.SetWidgetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dba37c
	// Params: [ Num(1) Size(0x1) ]
	void SetWidgetVisibility(uint8_t InVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.Widget.SetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dba300
	// Params: [ Num(1) Size(0x1) ]
	void SetWidgetRender(uint8_t InWidgetVisible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4958C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.Widget.SetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dba27c
	// Params: [ Num(1) Size(0x1) ]
	void SetVisibility(uint8_t InVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D4958C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.Widget.SetUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dba200
	// Params: [ Num(1) Size(0x8) ]
	void SetUserFocus(struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4A05C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D4958C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.Widget.SetToolTipText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dba154
	// Params: [ Num(1) Size(0x18) ]
	void SetToolTipText(struct FText& InToolTipText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D49968
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4A05C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D4958C

	// Object: Function UMG.Widget.SetToolTip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dba0d8
	// Params: [ Num(1) Size(0x8) ]
	void SetToolTip(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D499D0
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D49968
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4A05C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.SetRenderTranslation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dba060
	// Params: [ Num(1) Size(0x8) ]
	void SetRenderTranslation(struct FVector2D Translation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48EF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D499D0
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49968
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D4A05C
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetRenderTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db9fe8
	// Params: [ Num(1) Size(0x8) ]
	void SetRenderTransformPivot(struct FVector2D Pivot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4901C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D48EF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D499D0
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D49968
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetRenderTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9f3c
	// Params: [ Num(1) Size(0x1C) ]
	void SetRenderTransform(struct FWidgetTransform InTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48D68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4901C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D48EF8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D499D0
	// [Call #13] RVA: 0x104F0F380
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetRenderShear
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db9ec4
	// Params: [ Num(1) Size(0x8) ]
	void SetRenderShear(struct FVector2D Shear);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48EE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D48D68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4901C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D48EF8
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetRenderScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db9e4c
	// Params: [ Num(1) Size(0x8) ]
	void SetRenderScale(struct FVector2D Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48EE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D48EE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D48D68
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4901C
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetRenderAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9dd0
	// Params: [ Num(1) Size(0x4) ]
	void SetRenderAngle(float Angle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48EF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D48EE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D48EE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D48D68
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetNavigationRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9cdc
	// Params: [ Num(3) Size(0x10) ]
	void SetNavigationRule(uint8_t Direction, uint8_t Rule, struct FName WidgetToFocus);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4A378
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D48EF0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D48EE0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D48EE8

	// Object: Function UMG.Widget.SetKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9cc8
	// Params: [ Num(0) Size(0x0) ]
	void SetKeyboardFocus();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4A378
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D48EF0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D48EE0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.SetIsEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105db9c3c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsEnabled(bool bInIsEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4A378
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D48EF0
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9bc0
	// Params: [ Num(1) Size(0x1) ]
	void SetCursor(enum class EMouseCursor InCursor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D491FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4A378
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.SetClipping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9b44
	// Params: [ Num(1) Size(0x1) ]
	void SetClipping(uint8_t InClipping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D49754
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D491FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.SetAllNavigationRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9a8c
	// Params: [ Num(2) Size(0x10) ]
	void SetAllNavigationRules(uint8_t Rule, struct FName WidgetToFocus);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D4A510
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D49754
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D491FC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.ResetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9a78
	// Params: [ Num(0) Size(0x0) ]
	void ResetCursor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D4A510
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D49754
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D491FC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.RemoveFromParent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105db9a5c
	// Params: [ Num(0) Size(0x0) ]
	void RemoveFromParent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D4A510
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D49754
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D491FC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: DelegateFunction UMG.Widget.OnReply__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0xB8) ]
	struct FEventReply OnReply__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9a28
	// Params: [ Num(1) Size(0x1) ]
	bool IsVisible();
	// [Call #1] RVA: 0x105D49314
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4A510
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D49754
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D491FC
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.Widget.IsHovered
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db99f4
	// Params: [ Num(1) Size(0x1) ]
	bool IsHovered();
	// [Call #1] RVA: 0x105D49C10
	// [Call #2] RVA: 0x105D49314
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4A510
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49754
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D491FC

	// Object: Function UMG.Widget.InvalidateLayoutCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db99e0
	// Params: [ Num(0) Size(0x0) ]
	void InvalidateLayoutCache();
	// [Call #1] RVA: 0x105D49C10
	// [Call #2] RVA: 0x105D49314
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4A510
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49754
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D491FC

	// Object: Function UMG.Widget.InvalidateLayoutAndVolatility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db99cc
	// Params: [ Num(0) Size(0x0) ]
	void InvalidateLayoutAndVolatility();
	// [Call #1] RVA: 0x105D49C10
	// [Call #2] RVA: 0x105D49314
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4A510
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49754
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.HasUserFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9940
	// Params: [ Num(2) Size(0x9) ]
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D49FA0
	// [Call #4] RVA: 0x105D49C10
	// [Call #5] RVA: 0x105D49314
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4A510
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.HasUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db98b4
	// Params: [ Num(2) Size(0x9) ]
	bool HasUserFocus(struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D49E1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D49FA0
	// [Call #7] RVA: 0x105D49C10
	// [Call #8] RVA: 0x105D49314
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function UMG.Widget.HasMouseCapture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9880
	// Params: [ Num(1) Size(0x1) ]
	bool HasMouseCapture();
	// [Call #1] RVA: 0x105D49CE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D49E1C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D49FA0
	// [Call #8] RVA: 0x105D49C10
	// [Call #9] RVA: 0x105D49314
	// [Call #10] RVA: 0x10516D168

	// Object: Function UMG.Widget.HasKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db984c
	// Params: [ Num(1) Size(0x1) ]
	bool HasKeyboardFocus();
	// [Call #1] RVA: 0x105D49C78
	// [Call #2] RVA: 0x105D49CE0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D49E1C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D49FA0
	// [Call #9] RVA: 0x105D49C10
	// [Call #10] RVA: 0x105D49314

	// Object: Function UMG.Widget.HasFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9818
	// Params: [ Num(1) Size(0x1) ]
	bool HasFocusedDescendants();
	// [Call #1] RVA: 0x105D49F40
	// [Call #2] RVA: 0x105D49C78
	// [Call #3] RVA: 0x105D49CE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D49E1C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D49FA0
	// [Call #10] RVA: 0x105D49C10
	// [Call #11] RVA: 0x105D49314

	// Object: Function UMG.Widget.HasAnyUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db97e4
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnyUserFocus();
	// [Call #1] RVA: 0x105D49EDC
	// [Call #2] RVA: 0x105D49F40
	// [Call #3] RVA: 0x105D49C78
	// [Call #4] RVA: 0x105D49CE0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D49E1C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49FA0
	// [Call #11] RVA: 0x105D49C10

	// Object: Function UMG.Widget.GetWidgetRender
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db97b0
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetWidgetRender();
	// [Call #1] RVA: 0x105D49698
	// [Call #2] RVA: 0x105D49EDC
	// [Call #3] RVA: 0x105D49F40
	// [Call #4] RVA: 0x105D49C78
	// [Call #5] RVA: 0x105D49CE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D49E1C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D49FA0

	// Object: DelegateFunction UMG.Widget.GetWidget__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetWidget__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db977c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetVisibility();
	// [Call #1] RVA: 0x105D493BC
	// [Call #2] RVA: 0x105D49698
	// [Call #3] RVA: 0x105D49EDC
	// [Call #4] RVA: 0x105D49F40
	// [Call #5] RVA: 0x105D49C78
	// [Call #6] RVA: 0x105D49CE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D49E1C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D49FA0

	// Object: Function UMG.Widget.GetTickSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9744
	// Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetTickSpaceGeometry();
	// [Call #1] RVA: 0x105D4A5D4
	// [Call #2] RVA: 0x105D493BC
	// [Call #3] RVA: 0x105D49698
	// [Call #4] RVA: 0x105D49EDC
	// [Call #5] RVA: 0x105D49F40
	// [Call #6] RVA: 0x105D49C78
	// [Call #7] RVA: 0x105D49CE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D49E1C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.Widget.GetTheTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9710
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetTheTemplate();
	// [Call #1] RVA: 0x105D4B278
	// [Call #2] RVA: 0x105D4A5D4
	// [Call #3] RVA: 0x105D493BC
	// [Call #4] RVA: 0x105D49698
	// [Call #5] RVA: 0x105D49EDC
	// [Call #6] RVA: 0x105D49F40
	// [Call #7] RVA: 0x105D49C78
	// [Call #8] RVA: 0x105D49CE0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D49E1C

	// Object: DelegateFunction UMG.Widget.GetText__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetSlateVisibility__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x28) ]
	struct FSlateColor GetSlateColor__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0xB8) ]
	struct FSlateBrush GetSlateBrush__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db96dc
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetParent();
	// [Call #1] RVA: 0x105D3B9D8
	// [Call #2] RVA: 0x105D4B278
	// [Call #3] RVA: 0x105D4A5D4
	// [Call #4] RVA: 0x105D493BC
	// [Call #5] RVA: 0x105D49698
	// [Call #6] RVA: 0x105D49EDC
	// [Call #7] RVA: 0x105D49F40
	// [Call #8] RVA: 0x105D49C78
	// [Call #9] RVA: 0x105D49CE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D49E1C

	// Object: Function UMG.Widget.GetPaintSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db96a4
	// Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetPaintSpaceGeometry();
	// [Call #1] RVA: 0x105D4A640
	// [Call #2] RVA: 0x105D3B9D8
	// [Call #3] RVA: 0x105D4B278
	// [Call #4] RVA: 0x105D4A5D4
	// [Call #5] RVA: 0x105D493BC
	// [Call #6] RVA: 0x105D49698
	// [Call #7] RVA: 0x105D49EDC
	// [Call #8] RVA: 0x105D49F40
	// [Call #9] RVA: 0x105D49C78
	// [Call #10] RVA: 0x105D49CE0
	// [Call #11] RVA: 0x10516D168

	// Object: Function UMG.Widget.GetOwningPlayer
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9668
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetOwningPlayer();
	// [Call #1] RVA: 0x105D4A640
	// [Call #2] RVA: 0x105D3B9D8
	// [Call #3] RVA: 0x105D4B278
	// [Call #4] RVA: 0x105D4A5D4
	// [Call #5] RVA: 0x105D493BC
	// [Call #6] RVA: 0x105D49698
	// [Call #7] RVA: 0x105D49EDC
	// [Call #8] RVA: 0x105D49F40
	// [Call #9] RVA: 0x105D49C78
	// [Call #10] RVA: 0x105D49CE0

	// Object: DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	enum class EMouseCursor GetMouseCursor__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetLinearColor__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.GetIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9634
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsEnabled();
	// [Call #1] RVA: 0x105D490B8
	// [Call #2] RVA: 0x105D4A640
	// [Call #3] RVA: 0x105D3B9D8
	// [Call #4] RVA: 0x105D4B278
	// [Call #5] RVA: 0x105D4A5D4
	// [Call #6] RVA: 0x105D493BC
	// [Call #7] RVA: 0x105D49698
	// [Call #8] RVA: 0x105D49EDC
	// [Call #9] RVA: 0x105D49F40
	// [Call #10] RVA: 0x105D49C78

	// Object: DelegateFunction UMG.Widget.GetInt32__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	int GetInt32__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GetFloat__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	float GetFloat__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.GetDesiredSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9600
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetDesiredSize();
	// [Call #1] RVA: 0x105D4A218
	// [Call #2] RVA: 0x105D490B8
	// [Call #3] RVA: 0x105D4A640
	// [Call #4] RVA: 0x105D3B9D8
	// [Call #5] RVA: 0x105D4B278
	// [Call #6] RVA: 0x105D4A5D4
	// [Call #7] RVA: 0x105D493BC
	// [Call #8] RVA: 0x105D49698
	// [Call #9] RVA: 0x105D49EDC
	// [Call #10] RVA: 0x105D49F40

	// Object: Function UMG.Widget.GetClipping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db95cc
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetClipping();
	// [Call #1] RVA: 0x105D49704
	// [Call #2] RVA: 0x105D4A218
	// [Call #3] RVA: 0x105D490B8
	// [Call #4] RVA: 0x105D4A640
	// [Call #5] RVA: 0x105D3B9D8
	// [Call #6] RVA: 0x105D4B278
	// [Call #7] RVA: 0x105D4A5D4
	// [Call #8] RVA: 0x105D493BC
	// [Call #9] RVA: 0x105D49698
	// [Call #10] RVA: 0x105D49EDC

	// Object: DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetCheckBoxState__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.GetCachedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db9594
	// Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetCachedGeometry();
	// [Call #1] RVA: 0x105D4A5D0
	// [Call #2] RVA: 0x105D49704
	// [Call #3] RVA: 0x105D4A218
	// [Call #4] RVA: 0x105D490B8
	// [Call #5] RVA: 0x105D4A640
	// [Call #6] RVA: 0x105D3B9D8
	// [Call #7] RVA: 0x105D4B278
	// [Call #8] RVA: 0x105D4A5D4
	// [Call #9] RVA: 0x105D493BC
	// [Call #10] RVA: 0x105D49698

	// Object: Function UMG.Widget.GetCachedAllottedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db955c
	// Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetCachedAllottedGeometry();
	// [Call #1] RVA: 0x105D4A6AC
	// [Call #2] RVA: 0x105D4A5D0
	// [Call #3] RVA: 0x105D49704
	// [Call #4] RVA: 0x105D4A218
	// [Call #5] RVA: 0x105D490B8
	// [Call #6] RVA: 0x105D4A640
	// [Call #7] RVA: 0x105D3B9D8
	// [Call #8] RVA: 0x105D4B278
	// [Call #9] RVA: 0x105D4A5D4
	// [Call #10] RVA: 0x105D493BC

	// Object: DelegateFunction UMG.Widget.GetBool__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	bool GetBool__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x18) ]
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Widget.ForceVolatileThrottle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db94d8
	// Params: [ Num(1) Size(0x1) ]
	void ForceVolatileThrottle(bool bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D49864
	// [Call #4] RVA: 0x105D4A6AC
	// [Call #5] RVA: 0x105D4A5D0
	// [Call #6] RVA: 0x105D49704
	// [Call #7] RVA: 0x105D4A218
	// [Call #8] RVA: 0x105D490B8
	// [Call #9] RVA: 0x105D4A640
	// [Call #10] RVA: 0x105D3B9D8

	// Object: Function UMG.Widget.ForceVolatile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9454
	// Params: [ Num(1) Size(0x1) ]
	void ForceVolatile(bool bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D497D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D49864
	// [Call #7] RVA: 0x105D4A6AC
	// [Call #8] RVA: 0x105D4A5D0
	// [Call #9] RVA: 0x105D49704
	// [Call #10] RVA: 0x105D4A218
	// [Call #11] RVA: 0x105D490B8

	// Object: Function UMG.Widget.ForceLayoutPrepass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db9440
	// Params: [ Num(0) Size(0x0) ]
	void ForceLayoutPrepass();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D497D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D49864
	// [Call #7] RVA: 0x105D4A6AC
	// [Call #8] RVA: 0x105D4A5D0
	// [Call #9] RVA: 0x105D49704
	// [Call #10] RVA: 0x105D4A218
	// [Call #11] RVA: 0x105D490B8

	// Object: Function UMG.Widget.DisableVolatileInSlateGI
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db93bc
	// Params: [ Num(1) Size(0x1) ]
	void DisableVolatileInSlateGI(bool bDisabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D498D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D497D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D49864
	// [Call #10] RVA: 0x105D4A6AC
	// [Call #11] RVA: 0x105D4A5D0
	// [Call #12] RVA: 0x105D49704

	// Object: Function UMG.Widget.AdaptationWidgetSlot
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105db9330
	// Params: [ Num(1) Size(0x10) ]
	void AdaptationWidgetSlot(struct FMargin& InOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4B2F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D498D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D497D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D49864
	// [Call #13] RVA: 0x105D4A6AC
};

// Object: Class UMG.Image
// Size: 0x288 (Inherited: 0x100)
struct UImage : UWidget
{
	struct FSlateBrush Brush; // 0x100(0xB8)
	DelegateProperty BrushDelegate; // 0x1B8(0x10)
	bool MatchSize; // 0x1C8(0x1)
	uint8_t Pad_0x1C9[0x7]; // 0x1C9(0x7)
	DelegateProperty OnSetBrushAsyncComplete; // 0x1D0(0x10)
	struct TArray<struct FSlateColor> ColorSwitchList; // 0x1E0(0x10)
	int ActiveColorIndex; // 0x1F0(0x4)
	struct FLinearColor ColorAndOpacity; // 0x1F4(0x10)
	uint8_t Pad_0x204[0x4]; // 0x204(0x4)
	DelegateProperty ColorAndOpacityDelegate; // 0x208(0x10)
	struct FString imageSrcPath; // 0x218(0x10)
	struct FVector2D ScalePivot; // 0x228(0x8)
	DelegateProperty OnMouseButtonDownEvent; // 0x230(0x10)
	struct FSoftObjectPath AsyncLoadResourcePath; // 0x240(0x18)
	uint8_t Pad_0x258[0x20]; // 0x258(0x20)
	float HitTestAreaRadius; // 0x278(0x4)
	bool bIsEnhancedImage; // 0x27C(0x1)
	bool bIsUseEnhancedHitTest; // 0x27D(0x1)
	bool bFixOverScale; // 0x27E(0x1)
	bool bVersionImg; // 0x27F(0x1)
	bool bDontPaintWhenAlphaZero; // 0x280(0x1)
	bool bDontPaintWhenColorZero; // 0x281(0x1)
	bool bAsyncLoadImageAsset; // 0x282(0x1)
	bool bDisablePixelSnapping; // 0x283(0x1)
	uint8_t Pad_0x284[0x4]; // 0x284(0x4)


	// Object: Function UMG.Image.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da07dc
	// Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D35BF0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.Image.SetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da0758
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenColorZero(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36654
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D35BF0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.Image.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da06d4
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenAlphaZero(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36628
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D36654
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D35BF0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Image.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105da0658
	// Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D35AC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D36628
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D36654
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D35BF0
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.Image.SetBrushResourceFromPathSync
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da0578
	// Params: [ Num(2) Size(0x11) ]
	void SetBrushResourceFromPathSync(struct FString ResourcePath, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D352E4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D35AC8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D36628
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D36654

	// Object: Function UMG.Image.SetBrushFromTextureDynamic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da04b8
	// Params: [ Num(2) Size(0x9) ]
	void SetBrushFromTextureDynamic(struct UTexture2DDynamic* Texture, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D35EC0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D352E4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D35AC8
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.Image.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da03f8
	// Params: [ Num(2) Size(0x9) ]
	void SetBrushFromTexture(struct UTexture2D* Texture, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D35DEC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D35EC0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D352E4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function UMG.Image.SetBrushFromSoftObjectPathAsync
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105da02f0
	// Params: [ Num(2) Size(0x19) ]
	void SetBrushFromSoftObjectPathAsync(struct FSoftObjectPath& SoftObjectPath, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D36014
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D35DEC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.Image.SetBrushFromPathAsync
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da0210
	// Params: [ Num(2) Size(0x11) ]
	void SetBrushFromPathAsync(struct FString ResourcePath, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D350E0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D36014
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function UMG.Image.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da0194
	// Params: [ Num(1) Size(0x8) ]
	void SetBrushFromMaterial(struct UMaterialInterface* Material);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D35F78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D350E0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D36014
	// [Call #17] RVA: 0x101F8130C

	// Object: Function UMG.Image.SetBrushFromAtlasInterface
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105da00bc
	// Params: [ Num(2) Size(0x11) ]
	void SetBrushFromAtlasInterface(struct TScriptInterface<Class> AtlasRegion, bool bMatchSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D35F78
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D350E0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function UMG.Image.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da0040
	// Params: [ Num(1) Size(0x8) ]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D35D20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D35F78
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Image.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d9ff94
	// Params: [ Num(1) Size(0xB8) ]
	void SetBrush(struct FSlateBrush& InBrush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D35C18
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D35D20
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.Image.SetActiveColorIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ff18
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveColorIndex(int InIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D35AE8
	// [Call #4] RVA: 0x101FE9E54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D35C18
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D35D20
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.Image.SeFixOverScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fe94
	// Params: [ Num(1) Size(0x1) ]
	void SeFixOverScale(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36614
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D35AE8
	// [Call #7] RVA: 0x101FE9E54
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D35C18
	// [Call #11] RVA: 0x101FEA144
	// [Call #12] RVA: 0x101FEA144
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D35D20

	// Object: Function UMG.Image.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fe60
	// Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial();
	// [Call #1] RVA: 0x105D36460
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D36614
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D35AE8
	// [Call #8] RVA: 0x101FE9E54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D35C18
	// [Call #12] RVA: 0x101FEA144
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D35D20

	// Object: Function UMG.Image.GetDontPaintWhenColorZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fe2c
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenColorZero();
	// [Call #1] RVA: 0x105D36668
	// [Call #2] RVA: 0x105D36460
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D36614
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D35AE8
	// [Call #9] RVA: 0x101FE9E54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D35C18
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function UMG.Image.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fdf8
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenAlphaZero();
	// [Call #1] RVA: 0x105D3663C
	// [Call #2] RVA: 0x105D36668
	// [Call #3] RVA: 0x105D36460
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D36614
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D35AE8
	// [Call #10] RVA: 0x101FE9E54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D35C18
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x101FEA144
	// [Call #16] RVA: 0x106C8459C
};

// Object: Class UMG.UserWidget
// Size: 0x260 (Inherited: 0x100)
struct UUserWidget : UWidget
{
	uint8_t Pad_0x100[0x8]; // 0x100(0x8)
	struct FLinearColor ColorAndOpacity; // 0x108(0x10)
	DelegateProperty ColorAndOpacityDelegate; // 0x118(0x10)
	struct FSlateColor ForegroundColor; // 0x128(0x28)
	DelegateProperty ForegroundColorDelegate; // 0x150(0x10)
	struct FMargin Padding; // 0x160(0x10)
	struct FWAnimTime WAnimTime; // 0x170(0x10)
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // 0x180(0x10)
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // 0x190(0x10)
	DelegateProperty OnTouchStart; // 0x1A0(0x10)
	DelegateProperty OnTouchMove; // 0x1B0(0x10)
	DelegateProperty OnTouchEnd; // 0x1C0(0x10)
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // 0x1D0(0x10)
	struct UWidgetTree* WidgetTree; // 0x1E0(0x8)
	int Priority; // 0x1E8(0x4)
	uint8_t bSupportsKeyboardFocus : 1; // 0x1EC(0x1), Mask(0x1)
	uint8_t bIsFocusable : 1; // 0x1EC(0x1), Mask(0x2)
	uint8_t bStopAction : 1; // 0x1EC(0x1), Mask(0x4)
	uint8_t bCanEverTick : 1; // 0x1EC(0x1), Mask(0x8)
	uint8_t bCanEverPaint : 1; // 0x1EC(0x1), Mask(0x10)
	uint8_t bDontPaintWhenChildEmpty : 1; // 0x1EC(0x1), Mask(0x20)
	uint8_t bEnableLazyLoad : 1; // 0x1EC(0x1), Mask(0x40)
	uint8_t BitPad_0x1EC_7 : 1; // 0x1EC(0x1)
	uint8_t bCookedWidgetTree : 1; // 0x1ED(0x1), Mask(0x1)
	uint8_t BitPad_0x1ED_1 : 7; // 0x1ED(0x1)
	bool needAutoPlay; // 0x1EE(0x1)
	bool isAutoLoop; // 0x1EF(0x1)
	struct TArray<struct FName> autoPlayNameList; // 0x1F0(0x10)
	uint8_t TickFrequency; // 0x200(0x1)
	uint8_t Pad_0x201[0x7]; // 0x201(0x7)
	struct UInputComponent* InputComponent; // 0x208(0x8)
	uint8_t Pad_0x210[0x50]; // 0x210(0x50)


	// Object: Function UMG.UserWidget.UnregisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db4608
	// Params: [ Num(0) Size(0x0) ]
	void UnregisterInputComponent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.UserWidget.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x3C) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.StopListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db4548
	// Params: [ Num(2) Size(0x9) ]
	void StopListeningForInputAction(struct FName ActionName, enum class EInputEvent EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D89AE8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.UserWidget.StopListeningForAllInputActions
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db4534
	// Params: [ Num(0) Size(0x0) ]
	void StopListeningForAllInputActions();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D89AE8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.UserWidget.StopAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db44b8
	// Params: [ Num(1) Size(0x8) ]
	void StopAnimation(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87B70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D89AE8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.UserWidget.SetWAnimTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db4438
	// Params: [ Num(1) Size(0x10) ]
	void SetWAnimTime(struct FWAnimTime InWAnimTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8729C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D87B70
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D89AE8
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.UserWidget.SetPositionInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db437c
	// Params: [ Num(2) Size(0x9) ]
	void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D895A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8729C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87B70
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetPlaybackSpeed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db42c4
	// Params: [ Num(2) Size(0xC) ]
	void SetPlaybackSpeed(struct UWidgetAnimation* InAnimation, float PlaybackSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D87D00
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D895A8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8729C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetPadding
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db4244
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D87D00
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D895A8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db41c8
	// Params: [ Num(1) Size(0x8) ]
	void SetOwningPlayer(struct APlayerController* LocalPlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D894EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D87104
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87D00
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db414c
	// Params: [ Num(1) Size(0x8) ]
	void SetOwningLocalPlayer(struct ULocalPlayer* LocalPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8945C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D894EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D87104
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D87D00

	// Object: Function UMG.UserWidget.SetNumLoopsToPlay
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db4094
	// Params: [ Num(2) Size(0xC) ]
	void SetNumLoopsToPlay(struct UWidgetAnimation* InAnimation, int NumLoopsToPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D87CCC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8945C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D894EC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D87104

	// Object: Function UMG.UserWidget.SetInputActionPriority
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db4018
	// Params: [ Num(1) Size(0x4) ]
	void SetInputActionPriority(int NewPriority);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D89C4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D87CCC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8945C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D894EC

	// Object: Function UMG.UserWidget.SetInputActionBlocking
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db3f94
	// Params: [ Num(1) Size(0x1) ]
	void SetInputActionBlocking(bool bShouldBlock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D89C60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D89C4C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87CCC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8945C

	// Object: Function UMG.UserWidget.SetForegroundColor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3e94
	// Params: [ Num(1) Size(0x28) ]
	void SetForegroundColor(struct FSlateColor InForegroundColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87058
	// [Call #4] RVA: 0x101FE9F60
	// [Call #5] RVA: 0x101FE9F60
	// [Call #6] RVA: 0x101FE9F60
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D89C60
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D89C4C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db3e10
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D88314
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D87058
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D89C60
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetDesiredSizeInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db3d98
	// Params: [ Num(1) Size(0x8) ]
	void SetDesiredSizeInViewport(struct FVector2D Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D895F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D88314
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D87058
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x101FE9F60
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.SetColorAndOpacity
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db3d1c
	// Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D86F98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D895F8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D88314
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D87058
	// [Call #13] RVA: 0x101FE9F60
	// [Call #14] RVA: 0x101FE9F60

	// Object: Function UMG.UserWidget.SetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3c9c
	// Params: [ Num(1) Size(0x10) ]
	void SetAnchorsInViewport(struct FAnchors Anchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8960C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D86F98
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D895F8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D88314
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.SetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db3c24
	// Params: [ Num(1) Size(0x8) ]
	void SetAlignmentInViewport(struct FVector2D Alignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D89620
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8960C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D86F98
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D895F8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.ReverseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3ba8
	// Params: [ Num(1) Size(0x8) ]
	void ReverseAnimation(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87D30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D89620
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8960C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D86F98
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D895F8

	// Object: Function UMG.UserWidget.RemoveFromViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3b94
	// Params: [ Num(0) Size(0x0) ]
	void RemoveFromViewport();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87D30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D89620
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8960C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D86F98
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.RegisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db3b80
	// Params: [ Num(0) Size(0x0) ]
	void RegisterInputComponent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87D30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D89620
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8960C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D86F98
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.PlayUserWidgetAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3a14
	// Params: [ Num(5) Size(0x18) ]
	void PlayUserWidgetAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87AF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D87D30
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3998
	// Params: [ Num(1) Size(0x8) ]
	void PlaySound(struct USoundBase* SoundToPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87D9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D87AF0
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.PlayAnimationTo
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db37f4
	// Params: [ Num(6) Size(0x1C) ]
	void PlayAnimationTo(struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8758C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D87D9C
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.PlayAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db3688
	// Params: [ Num(5) Size(0x18) ]
	void PlayAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87AF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.PauseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db35fc
	// Params: [ Num(2) Size(0xC) ]
	float PauseAnimation(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87BC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D87AF0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnTouchGesture
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent& GestureEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnRemovedFromFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnPreviewMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnPreviewKeyDown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x130) ]
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnPaint
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x30) ]
	void OnPaint(struct FPaintContext& Context);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseWheel
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x78) ]
	void OnMouseLeave(struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xB0) ]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseCaptureLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnMouseCaptureLost();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMouseButtonDoubleClick
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x168) ]
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnMotionDetected
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x140) ]
	struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnKeyUp
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x130) ]
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnKeyDown
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x130) ]
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnKeyChar
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x118) ]
	struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnFocusReceived
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xF8) ]
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnFocusLost(struct FFocusEvent InFocusEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0xB9) ]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDragOver
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0xB9) ]
	bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDragLeave
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x80) ]
	void OnDragLeave(struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDragEnter
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xB8) ]
	void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xB8) ]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x80) ]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	// Offset: 0x105db3578
	// Params: [ Num(1) Size(0x8) ]
	void OnAnimationStarted(struct UWidgetAnimation* Animation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D87BC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Public|BlueprintEvent]
	// Offset: 0x105db34f4
	// Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D87BC8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.OnAnalogValueChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x138) ]
	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.OnAddedToFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.ListenForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db3398
	// Params: [ Num(4) Size(0x20) ]
	void ListenForInputAction(struct FName ActionName, enum class EInputEvent EventType, bool bConsume, DelegateProperty Callback);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FD9E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8995C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.IsPlayingAnimation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db3374
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlayingAnimation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FD9E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8995C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.IsListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db32e8
	// Params: [ Num(2) Size(0x9) ]
	bool IsListeningForInputAction(struct FName ActionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D89BB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD9E48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8995C
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.IsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db32b4
	// Params: [ Num(1) Size(0x1) ]
	bool IsInViewport();
	// [Call #1] RVA: 0x105D89420
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D89BB8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD9E48
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8995C

	// Object: Function UMG.UserWidget.IsInteractable
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	bool IsInteractable();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.IsAnyAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db3280
	// Params: [ Num(1) Size(0x1) ]
	bool IsAnyAnimationPlaying();
	// [Call #1] RVA: 0x105D87CBC
	// [Call #2] RVA: 0x105D89420
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D89BB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.UserWidget.IsAnimationPlayingForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db31f4
	// Params: [ Num(2) Size(0x9) ]
	bool IsAnimationPlayingForward(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87D60
	// [Call #4] RVA: 0x105D87CBC
	// [Call #5] RVA: 0x105D89420
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D89BB8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.IsAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db3168
	// Params: [ Num(2) Size(0x9) ]
	bool IsAnimationPlaying(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87C60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D87D60
	// [Call #7] RVA: 0x105D87CBC
	// [Call #8] RVA: 0x105D89420
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D89BB8

	// Object: Function UMG.UserWidget.GetWidgetFromName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x105db30cc
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetWidgetFromName(struct FName& Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87FC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D87C60
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D87D60
	// [Call #10] RVA: 0x105D87CBC
	// [Call #11] RVA: 0x105D89420
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.GetOwningPlayerPawn
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db3098
	// Params: [ Num(1) Size(0x8) ]
	struct APawn* GetOwningPlayerPawn();
	// [Call #1] RVA: 0x105D89544
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D87FC8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D87C60
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D87D60
	// [Call #11] RVA: 0x105D87CBC
	// [Call #12] RVA: 0x105D89420

	// Object: Function UMG.UserWidget.GetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db305c
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetOwningPlayer();
	// [Call #1] RVA: 0x105D89544
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D87FC8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D87C60
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D87D60
	// [Call #11] RVA: 0x105D87CBC

	// Object: Function UMG.UserWidget.GetOwningLocalPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db3028
	// Params: [ Num(1) Size(0x8) ]
	struct ULocalPlayer* GetOwningLocalPlayer();
	// [Call #1] RVA: 0x105D882D8
	// [Call #2] RVA: 0x105D89544
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D87FC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D87C60
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87D60

	// Object: Function UMG.UserWidget.GetOrCreateLazyChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db2f34
	// Params: [ Num(2) Size(0x18) ]
	struct UWidget* GetOrCreateLazyChild(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x105D8842C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x105D882D8
	// [Call #13] RVA: 0x105D89544
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D87FC8

	// Object: Function UMG.UserWidget.GetIsVisible
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db2f00
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsVisible();
	// [Call #1] RVA: 0x105D893F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x105D8842C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x105D882D8
	// [Call #14] RVA: 0x105D89544
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D87FC8

	// Object: Function UMG.UserWidget.GetEnableLazyLoad
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db2ecc
	// Params: [ Num(1) Size(0x1) ]
	bool GetEnableLazyLoad();
	// [Call #1] RVA: 0x105D88420
	// [Call #2] RVA: 0x105D893F8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x105D8842C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D882D8
	// [Call #15] RVA: 0x105D89544
	// [Call #16] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db2e98
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D883B0
	// [Call #2] RVA: 0x105D88420
	// [Call #3] RVA: 0x105D893F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x105D8842C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x105D882D8
	// [Call #16] RVA: 0x105D89544

	// Object: Function UMG.UserWidget.GetAnimationCurrentTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db2e0c
	// Params: [ Num(2) Size(0xC) ]
	float GetAnimationCurrentTime(struct UWidgetAnimation* InAnimation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D87C28
	// [Call #4] RVA: 0x105D883B0
	// [Call #5] RVA: 0x105D88420
	// [Call #6] RVA: 0x105D893F8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x105D8842C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x105D882D8

	// Object: Function UMG.UserWidget.GetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db2dd4
	// Params: [ Num(1) Size(0x10) ]
	struct FAnchors GetAnchorsInViewport();
	// [Call #1] RVA: 0x105D88FF0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D87C28
	// [Call #5] RVA: 0x105D883B0
	// [Call #6] RVA: 0x105D88420
	// [Call #7] RVA: 0x105D893F8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x105D8842C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function UMG.UserWidget.GetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db2da0
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetAlignmentInViewport();
	// [Call #1] RVA: 0x105D8906C
	// [Call #2] RVA: 0x105D88FF0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D87C28
	// [Call #6] RVA: 0x105D883B0
	// [Call #7] RVA: 0x105D88420
	// [Call #8] RVA: 0x105D893F8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x105D8842C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function UMG.UserWidget.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Destruct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.UserWidget.AddToViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db2d24
	// Params: [ Num(1) Size(0x4) ]
	void AddToViewport(int ZOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D881D8
	// [Call #4] RVA: 0x105D8906C
	// [Call #5] RVA: 0x105D88FF0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D87C28
	// [Call #9] RVA: 0x105D883B0
	// [Call #10] RVA: 0x105D88420
	// [Call #11] RVA: 0x105D893F8
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.UserWidget.AddToPlayerScreen
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x105db2c98
	// Params: [ Num(2) Size(0x5) ]
	bool AddToPlayerScreen(int ZOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D881EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D881D8
	// [Call #7] RVA: 0x105D8906C
	// [Call #8] RVA: 0x105D88FF0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D87C28
	// [Call #12] RVA: 0x105D883B0
	// [Call #13] RVA: 0x105D88420
};

// Object: Class UMG.WidgetComponent
// Size: 0xB90 (Inherited: 0xA20)
struct UWidgetComponent : UMeshComponent
{
	bool bAntialiased; // 0xA1D(0x1)
	float RTScale; // 0xA20(0x4)
	uint8_t Space; // 0xA24(0x1)
	uint8_t TimingPolicy; // 0xA25(0x1)
	uint8_t Pad_0xA27[0x1]; // 0xA27(0x1)
	struct UUserWidget* WidgetClass; // 0xA28(0x8)
	struct FIntPoint DrawSize; // 0xA30(0x8)
	bool bManuallyRedraw; // 0xA38(0x1)
	bool bRedrawRequested; // 0xA39(0x1)
	uint8_t Pad_0xA3A[0x2]; // 0xA3A(0x2)
	float RedrawTime; // 0xA3C(0x4)
	uint8_t Pad_0xA40[0x8]; // 0xA40(0x8)
	struct FIntPoint CurrentDrawSize; // 0xA48(0x8)
	uint8_t Pad_0xA50[0x4]; // 0xA50(0x4)
	bool bDrawAtDesiredSize; // 0xA54(0x1)
	uint8_t Pad_0xA55[0x3]; // 0xA55(0x3)
	struct FVector2D Pivot; // 0xA58(0x8)
	bool bReceiveHardwareInput; // 0xA60(0x1)
	bool bWindowFocusable; // 0xA61(0x1)
	uint8_t Pad_0xA62[0x6]; // 0xA62(0x6)
	struct ULocalPlayer* OwnerPlayer; // 0xA68(0x8)
	struct FLinearColor BackgroundColor; // 0xA70(0x10)
	struct FLinearColor TintColorAndOpacity; // 0xA80(0x10)
	float OpacityFromTexture; // 0xA90(0x4)
	uint8_t BlendMode; // 0xA94(0x1)
	bool bIsTwoSided; // 0xA95(0x1)
	bool TickWhenOffscreen; // 0xA96(0x1)
	uint8_t Pad_0xA97[0x1]; // 0xA97(0x1)
	struct UUserWidget* Widget; // 0xA98(0x8)
	uint8_t Pad_0xAA0[0x20]; // 0xAA0(0x20)
	struct UBodySetup* BodySetup; // 0xAC0(0x8)
	struct UMaterialInterface* TranslucentMaterialAA; // 0xAC8(0x8)
	struct UMaterialInterface* TranslucentMaterialAA_OneSided; // 0xAD0(0x8)
	struct UMaterialInterface* TranslucentMaterial; // 0xAD8(0x8)
	struct UMaterialInterface* TranslucentMaterial_OneSided; // 0xAE0(0x8)
	struct UMaterialInterface* OpaqueMaterial; // 0xAE8(0x8)
	struct UMaterialInterface* OpaqueMaterial_OneSided; // 0xAF0(0x8)
	struct UMaterialInterface* MaskedMaterial; // 0xAF8(0x8)
	struct UMaterialInterface* MaskedMaterial_OneSided; // 0xB00(0x8)
	struct UTextureRenderTarget2D* RenderTarget; // 0xB08(0x8)
	struct UMaterialInstanceDynamic* MaterialInstance; // 0xB10(0x8)
	bool bAddedToScreen; // 0xB18(0x1)
	bool bEditTimeUsable; // 0xB19(0x1)
	uint8_t Pad_0xB1A[0x6]; // 0xB1A(0x6)
	struct FName SharedLayerName; // 0xB20(0x8)
	int LayerZOrder; // 0xB28(0x4)
	uint8_t GeometryMode; // 0xB2C(0x1)
	uint8_t Pad_0xB2D[0x3]; // 0xB2D(0x3)
	float CylinderArcAngle; // 0xB30(0x4)
	uint8_t Pad_0xB34[0x54]; // 0xB34(0x54)
	bool ForceDisableShareRT; // 0xB88(0x1)
	uint8_t Pad_0xB89[0x7]; // 0xB89(0x7)


	// Object: Function UMG.WidgetComponent.SetWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1030
	// Params: [ Num(1) Size(0x8) ]
	void SetWidget(struct UUserWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.WidgetComponent.SetTintColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc0fb4
	// Params: [ Num(1) Size(0x10) ]
	void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4E898
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetComponent.SetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc0f38
	// Params: [ Num(1) Size(0x8) ]
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4D360
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4E898
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.WidgetComponent.SetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc0ec0
	// Params: [ Num(1) Size(0x8) ]
	void SetDrawSize(struct FVector2D Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4E7B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4D360
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4E898
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.WidgetComponent.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc0e44
	// Params: [ Num(1) Size(0x10) ]
	void SetBackgroundColor(struct FLinearColor NewBackgroundColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4E850
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4E7B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4D360
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4E898
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetComponent.RequestRedraw
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc0e28
	// Params: [ Num(0) Size(0x0) ]
	void RequestRedraw();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4E850
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4E7B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4D360
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4E898
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetComponent.GetUserWidgetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0df4
	// Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetUserWidgetObject();
	// [Call #1] RVA: 0x105D40A40
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4E850
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4E7B4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4D360
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4E898

	// Object: Function UMG.WidgetComponent.GetRenderTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0dc0
	// Params: [ Num(1) Size(0x8) ]
	struct UTextureRenderTarget2D* GetRenderTarget();
	// [Call #1] RVA: 0x105D4E540
	// [Call #2] RVA: 0x105D40A40
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D4E850
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D4E7B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D4D360
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetComponent.GetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0d8c
	// Params: [ Num(1) Size(0x8) ]
	struct ULocalPlayer* GetOwnerPlayer();
	// [Call #1] RVA: 0x105D4CAD0
	// [Call #2] RVA: 0x105D4E540
	// [Call #3] RVA: 0x105D40A40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4E850
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4E7B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4D360
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.WidgetComponent.GetMaterialInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0d58
	// Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetMaterialInstance();
	// [Call #1] RVA: 0x105D4E548
	// [Call #2] RVA: 0x105D4CAD0
	// [Call #3] RVA: 0x105D4E540
	// [Call #4] RVA: 0x105D40A40
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4E850
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4E7B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4D360

	// Object: Function UMG.WidgetComponent.GetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0d24
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetDrawSize();
	// [Call #1] RVA: 0x105D4D0B8
	// [Call #2] RVA: 0x105D4E548
	// [Call #3] RVA: 0x105D4CAD0
	// [Call #4] RVA: 0x105D4E540
	// [Call #5] RVA: 0x105D40A40
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D4E850
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D4E7B4
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.WidgetComponent.GetCurrentDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc0cf0
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetCurrentDrawSize();
	// [Call #1] RVA: 0x105D4E8E0
	// [Call #2] RVA: 0x105D4D0B8
	// [Call #3] RVA: 0x105D4E548
	// [Call #4] RVA: 0x105D4CAD0
	// [Call #5] RVA: 0x105D4E540
	// [Call #6] RVA: 0x105D40A40
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4E850
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4E7B4
};

// Object: Class UMG.PanelWidget
// Size: 0x118 (Inherited: 0x100)
struct UPanelWidget : UWidget
{
	struct TArray<struct UPanelSlot*> Slots; // 0x100(0x10)
	uint8_t Pad_0x110[0x8]; // 0x110(0x8)


	// Object: Function UMG.PanelWidget.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6788
	// Params: [ Num(2) Size(0x5) ]
	bool RemoveChildAt(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B9F0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.PanelWidget.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da66fc
	// Params: [ Num(2) Size(0x9) ]
	bool RemoveChild(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3BEE4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3B9F0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.PanelWidget.HasChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da6670
	// Params: [ Num(2) Size(0x9) ]
	bool HasChild(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B9B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3BEE4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3B9F0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.PanelWidget.HasAnyChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da663c
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnyChildren();
	// [Call #1] RVA: 0x105D3BF24
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D3B9B4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D3BEE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D3B9F0
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.PanelWidget.GetChildrenCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da6608
	// Params: [ Num(1) Size(0x4) ]
	int GetChildrenCount();
	// [Call #1] RVA: 0x105D26CA4
	// [Call #2] RVA: 0x105D3BF24
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D3B9B4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D3BEE4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3B9F0
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.PanelWidget.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da657c
	// Params: [ Num(2) Size(0xC) ]
	int GetChildIndex(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B954
	// [Call #4] RVA: 0x105D26CA4
	// [Call #5] RVA: 0x105D3BF24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D3B9B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3BEE4
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.PanelWidget.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da64f0
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetChildAt(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B928
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3B954
	// [Call #7] RVA: 0x105D26CA4
	// [Call #8] RVA: 0x105D3BF24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3B9B4
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.PanelWidget.ClearChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da64dc
	// Params: [ Num(0) Size(0x0) ]
	void ClearChildren();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B928
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3B954
	// [Call #7] RVA: 0x105D26CA4
	// [Call #8] RVA: 0x105D3BF24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3B9B4

	// Object: Function UMG.PanelWidget.AddChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6414
	// Params: [ Num(3) Size(0x18) ]
	struct UPanelSlot* AddChildAt(int Index, struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D3BC68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D3B928
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3B954
	// [Call #12] RVA: 0x105D26CA4
	// [Call #13] RVA: 0x105D3BF24

	// Object: Function UMG.PanelWidget.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6388
	// Params: [ Num(2) Size(0x10) ]
	struct UPanelSlot* AddChild(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2B7F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D3BC68
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D3B928
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class UMG.CanvasPanel
// Size: 0x130 (Inherited: 0x118)
struct UCanvasPanel : UPanelWidget
{
	uint8_t Pad_0x118[0x10]; // 0x118(0x10)
	bool bDontPaintWhenChildEmpty; // 0x128(0x1)
	uint8_t Pad_0x129[0x7]; // 0x129(0x7)


	// Object: Function UMG.CanvasPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105d98c74
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2B4CC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.CanvasPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105d98c40
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D2B4E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2B4CC
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.CanvasPanel.AddChildToCanvas
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d98bb4
	// Params: [ Num(2) Size(0x10) ]
	struct UCanvasPanelSlot* AddChildToCanvas(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2B7C0
	// [Call #4] RVA: 0x105D2B4E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2B4CC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.ContentWidget
// Size: 0x118 (Inherited: 0x118)
struct UContentWidget : UPanelWidget
{

	// Object: Function UMG.ContentWidget.SetContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9b584
	// Params: [ Num(2) Size(0x10) ]
	struct UPanelSlot* SetContent(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2FEC8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.ContentWidget.GetContentSlot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9b550
	// Params: [ Num(1) Size(0x8) ]
	struct UPanelSlot* GetContentSlot();
	// [Call #1] RVA: 0x105D26CAC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2FEC8
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.ContentWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9b51c
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetContent();
	// [Call #1] RVA: 0x105D2FEA0
	// [Call #2] RVA: 0x105D26CAC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D2FEC8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class UMG.Slider
// Size: 0x498 (Inherited: 0x100)
struct USlider : UWidget
{
	float Value; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
	DelegateProperty ValueDelegate; // 0x108(0x10)
	struct FSliderStyle WidgetStyle; // 0x118(0x2F0)
	enum class EOrientation Orientation; // 0x408(0x1)
	uint8_t Pad_0x409[0x3]; // 0x409(0x3)
	struct FLinearColor SliderBarColor; // 0x40C(0x10)
	struct FLinearColor SliderHandleColor; // 0x41C(0x10)
	bool IndentHandle; // 0x42C(0x1)
	bool Locked; // 0x42D(0x1)
	uint8_t Pad_0x42E[0x2]; // 0x42E(0x2)
	float StepSize; // 0x430(0x4)
	bool IsFocusable; // 0x434(0x1)
	uint8_t Pad_0x435[0x3]; // 0x435(0x3)
	struct FScriptMulticastDelegate OnMouseCaptureBegin; // 0x438(0x10)
	struct FScriptMulticastDelegate OnMouseCaptureEnd; // 0x448(0x10)
	struct FScriptMulticastDelegate OnControllerCaptureBegin; // 0x458(0x10)
	struct FScriptMulticastDelegate OnControllerCaptureEnd; // 0x468(0x10)
	struct FScriptMulticastDelegate OnValueChanged; // 0x478(0x10)
	uint8_t Pad_0x488[0x10]; // 0x488(0x10)


	// Object: Function UMG.Slider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dabf64
	// Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D42228
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.Slider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dabee8
	// Params: [ Num(1) Size(0x4) ]
	void SetStepSize(float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4236C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D42228
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.Slider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dabe6c
	// Params: [ Num(1) Size(0x10) ]
	void SetSliderHandleColor(struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D423D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4236C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D42228
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Slider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dabdf0
	// Params: [ Num(1) Size(0x10) ]
	void SetSliderBarColor(struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4244C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D423D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4236C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D42228
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.Slider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dabd6c
	// Params: [ Num(1) Size(0x1) ]
	void SetLocked(bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D42300
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4244C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D423D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4236C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Slider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dabce8
	// Params: [ Num(1) Size(0x1) ]
	void SetIndentHandle(bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D42294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D42300
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4244C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D423D8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Slider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dabcb4
	// Params: [ Num(1) Size(0x4) ]
	float GetValue();
	// [Call #1] RVA: 0x105D42210
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D42294
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D42300
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4244C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D423D8
};

// Object: Class UMG.PanelSlot
// Size: 0x40 (Inherited: 0x28)
struct UPanelSlot : UVisual
{
	struct UPanelWidget* Parent; // 0x28(0x8)
	struct UWidget* Content; // 0x30(0x8)
	struct UObject* ContentClass; // 0x38(0x8)
};

// Object: Class UMG.HorizontalBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct UHorizontalBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	struct FSlateChildSize Size; // 0x50(0x8)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x58(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x59(0x1)
	uint8_t Pad_0x5A[0xE]; // 0x5A(0xE)


	// Object: Function UMG.HorizontalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fb10
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D34A24
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.HorizontalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9fa78
	// Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FSlateChildSize InSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D34914
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D34A24
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.HorizontalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f9f8
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3489C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D34914
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D34A24
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.HorizontalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f97c
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D34A10
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3489C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D34914
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D34A24
	// [Call #13] RVA: 0x10519022C
};

// Object: Class UMG.HorizontalBox
// Size: 0x128 (Inherited: 0x118)
struct UHorizontalBox : UPanelWidget
{
	bool bDontPaintWhenChildEmpty; // 0x111(0x1)
	uint8_t Pad_0x119[0xF]; // 0x119(0xF)


	// Object: Function UMG.HorizontalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105d9f6e8
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3452C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.HorizontalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105d9f6b4
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D34540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D3452C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.HorizontalBox.AddChildToHorizontalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f628
	// Params: [ Num(2) Size(0x10) ]
	struct UHorizontalBoxSlot* AddChildToHorizontalBox(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D344FC
	// [Call #4] RVA: 0x105D34540
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D3452C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.VerticalBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct UVerticalBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	struct FSlateChildSize Size; // 0x50(0x8)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x58(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x59(0x1)
	uint8_t Pad_0x5A[0xE]; // 0x5A(0xE)


	// Object: Function UMG.VerticalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db820c
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D47900
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.VerticalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db8174
	// Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FSlateChildSize InSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D477F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D47900
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.VerticalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db80f4
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D47778
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D477F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D47900
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.VerticalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db8078
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D478EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D47778
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D477F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D47900
	// [Call #13] RVA: 0x10519022C
};

// Object: Class UMG.VerticalBox
// Size: 0x128 (Inherited: 0x118)
struct UVerticalBox : UPanelWidget
{
	bool bDontPaintWhenChildEmpty; // 0x111(0x1)
	uint8_t Pad_0x119[0xF]; // 0x119(0xF)


	// Object: Function UMG.VerticalBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db7de0
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4743C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.VerticalBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105db7dac
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D47450
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4743C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.VerticalBox.AddChildToVerticalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db7d20
	// Params: [ Num(2) Size(0x10) ]
	struct UVerticalBoxSlot* AddChildToVerticalBox(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4740C
	// [Call #4] RVA: 0x105D47450
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D4743C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.WidgetBlueprintGeneratedClass
// Size: 0x508 (Inherited: 0x498)
struct UWidgetBlueprintGeneratedClass : UBlueprintGeneratedClass
{
	struct UWidgetTree* WidgetTree; // 0x498(0x8)
	uint8_t bAllowTemplate : 1; // 0x4A0(0x1), Mask(0x1)
	uint8_t bValidTemplate : 1; // 0x4A0(0x1), Mask(0x2)
	uint8_t bTemplateInitialized : 1; // 0x4A0(0x1), Mask(0x4)
	uint8_t bCookedTemplate : 1; // 0x4A0(0x1), Mask(0x8)
	uint8_t bClassRequiresNativeTick : 1; // 0x4A0(0x1), Mask(0x10)
	uint8_t BitPad_0x4A0_5 : 3; // 0x4A0(0x1)
	uint8_t Pad_0x4A1[0x7]; // 0x4A1(0x7)
	struct TArray<struct FDelegateRuntimeBinding> Bindings; // 0x4A8(0x10)
	struct TArray<struct UWidgetAnimation*> Animations; // 0x4B8(0x10)
	struct TArray<struct FName> NamedSlots; // 0x4C8(0x10)
	struct UUserWidget* TemplateAsset; // 0x4D8(0x28)
	struct UUserWidget* Template; // 0x500(0x8)
};

// Object: Class UMG.ScrollBox
// Size: 0xB28 (Inherited: 0x118)
struct UScrollBox : UPanelWidget
{
	struct FScrollBoxStyle WidgetStyle; // 0x118(0x2E8)
	struct FScrollBarStyle WidgetBarStyle; // 0x400(0x680)
	struct USlateWidgetStyleAsset* Style; // 0xA80(0x8)
	struct USlateWidgetStyleAsset* BarStyle; // 0xA88(0x8)
	enum class EOrientation Orientation; // 0xA90(0x1)
	uint8_t ScrollBarVisibility; // 0xA91(0x1)
	uint8_t ConsumeMouseWheel; // 0xA92(0x1)
	uint8_t Pad_0xA93[0x1]; // 0xA93(0x1)
	struct FVector2D ScrollbarThickness; // 0xA94(0x8)
	bool AlwaysShowScrollbar; // 0xA9C(0x1)
	bool AllowOverscroll; // 0xA9D(0x1)
	uint8_t NavigationDestination; // 0xA9E(0x1)
	uint8_t Pad_0xA9F[0x1]; // 0xA9F(0x1)
	float NavigationScrollPadding; // 0xAA0(0x4)
	float EdgePadding; // 0xAA4(0x4)
	bool bAllowRightClickDragScrolling; // 0xAA8(0x1)
	bool bDisableHorOrVertMove; // 0xAA9(0x1)
	bool bDisableScroll; // 0xAAA(0x1)
	bool bDontPaintWhenChildEmpty; // 0xAAB(0x1)
	uint8_t Pad_0xAAC[0x4]; // 0xAAC(0x4)
	struct FScriptMulticastDelegate OnUserScrolled; // 0xAB0(0x10)
	struct FScriptMulticastDelegate OnUserScrolledUnused; // 0xAC0(0x10)
	struct FScriptMulticastDelegate OnBeginScroll; // 0xAD0(0x10)
	struct FScriptMulticastDelegate OnEndScroll; // 0xAE0(0x10)
	struct FScriptMulticastDelegate OnTouchStartEvent; // 0xAF0(0x10)
	struct FScriptMulticastDelegate OnTouchEndEvent; // 0xB00(0x10)
	uint8_t Pad_0xB10[0x18]; // 0xB10(0x18)


	// Object: Function UMG.ScrollBox.StopScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8cf4
	// Params: [ Num(0) Size(0x0) ]
	void StopScroll();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.ScrollBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8c78
	// Params: [ Num(1) Size(0x4) ]
	void SetScrollOffset(float NewScrollOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D402F0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.ScrollBox.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8bfc
	// Params: [ Num(1) Size(0x1) ]
	void SetScrollBarVisibility(uint8_t NewScrollBarVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40478
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D402F0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.ScrollBox.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105da8b74
	// Params: [ Num(1) Size(0x8) ]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40478
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D402F0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.ScrollBox.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8af8
	// Params: [ Num(1) Size(0x1) ]
	void SetOrientation(enum class EOrientation NewOrientation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40460
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40538
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40478
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D402F0
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.ScrollBox.SetMaxScrollSpd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8a7c
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxScrollSpd(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4058C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40460
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40538
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40478
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.ScrollBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da89f8
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D405B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4058C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40460
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40538
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.ScrollBox.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8974
	// Params: [ Num(1) Size(0x1) ]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40560
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D405B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4058C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40460
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.ScrollBox.SetAllowOverscroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da88f0
	// Params: [ Num(1) Size(0x1) ]
	void SetAllowOverscroll(bool NewAllowOverscroll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40574
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40560
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D405B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4058C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.ScrollBox.ScrollWidgetIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da87ec
	// Params: [ Num(3) Size(0xA) ]
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, uint8_t ScrollDestination);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40334
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D40574
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D40560
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.ScrollBox.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da87d8
	// Params: [ Num(0) Size(0x0) ]
	void ScrollToStart();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40334
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D40574
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D40560
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.ScrollBox.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da87c4
	// Params: [ Num(0) Size(0x0) ]
	void ScrollToEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40334
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D40574
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D40560

	// Object: Function UMG.ScrollBox.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da8790
	// Params: [ Num(1) Size(0x4) ]
	float GetScrollOffset();
	// [Call #1] RVA: 0x105D402C8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D40334
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D40574
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D40560

	// Object: Function UMG.ScrollBox.GetScrollEndOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da875c
	// Params: [ Num(1) Size(0x4) ]
	float GetScrollEndOffset();
	// [Call #1] RVA: 0x105D402DC
	// [Call #2] RVA: 0x105D402C8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40334
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40574
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.ScrollBox.GetIsScrolling
	// Flags: [Final|Native|Public]
	// Offset: 0x105da8734
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsScrolling();
	// [Call #1] RVA: 0x105D402DC
	// [Call #2] RVA: 0x105D402C8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40334
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40574

	// Object: Function UMG.ScrollBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8700
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D405C8
	// [Call #2] RVA: 0x105D402DC
	// [Call #3] RVA: 0x105D402C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D40334
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.ScrollBox.GetCacheOverscrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da86cc
	// Params: [ Num(1) Size(0x4) ]
	float GetCacheOverscrollOffset();
	// [Call #1] RVA: 0x105D4059C
	// [Call #2] RVA: 0x105D405C8
	// [Call #3] RVA: 0x105D402DC
	// [Call #4] RVA: 0x105D402C8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D40334
	// [Call #12] RVA: 0x10516D168
};

// Object: Class UMG.TextLayoutWidget
// Size: 0x128 (Inherited: 0x100)
struct UTextLayoutWidget : UWidget
{
	struct FShapedTextOptions ShapedTextOptions; // 0x100(0x4)
	enum class ETextJustify Justification; // 0x104(0x1)
	enum class ETextVerticalJustify VerticalJustification; // 0x105(0x1)
	bool AutoWrapText; // 0x106(0x1)
	uint8_t Pad_0x107[0x1]; // 0x107(0x1)
	float WrapTextAt; // 0x108(0x4)
	uint8_t WrappingPolicy; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	struct FMargin Margin; // 0x110(0x10)
	float LineHeightPercentage; // 0x120(0x4)
	uint8_t Pad_0x124[0x4]; // 0x124(0x4)
};

// Object: Class UMG.TextBlock
// Size: 0x298 (Inherited: 0x128)
struct UTextBlock : UTextLayoutWidget
{
	struct FText Text; // 0x128(0x18)
	bool AutoCapitalizeText; // 0x140(0x1)
	uint8_t Pad_0x141[0x7]; // 0x141(0x7)
	DelegateProperty TextDelegate; // 0x148(0x10)
	struct TArray<struct FSlateColor> ColorSwitchList; // 0x158(0x10)
	int ActiveColorIndex; // 0x168(0x4)
	uint8_t Pad_0x16C[0x4]; // 0x16C(0x4)
	struct FSlateColor ColorAndOpacity; // 0x170(0x28)
	DelegateProperty ColorAndOpacityDelegate; // 0x198(0x10)
	struct FSlateColor SelectColorAndOpacity; // 0x1A8(0x28)
	struct FSlateColor NoSelectColorAndOpacity; // 0x1D0(0x28)
	bool bHaveSelectColorAndOpacity; // 0x1F8(0x1)
	bool bIsSelected; // 0x1F9(0x1)
	uint8_t Pad_0x1FA[0x6]; // 0x1FA(0x6)
	struct FSlateFontInfo Font; // 0x200(0x58)
	struct FVector2D ShadowOffset; // 0x258(0x8)
	struct FLinearColor ShadowColorAndOpacity; // 0x260(0x10)
	DelegateProperty ShadowColorAndOpacityDelegate; // 0x270(0x10)
	float MinDesiredWidth; // 0x280(0x4)
	bool AutoEllipsisText; // 0x284(0x1)
	bool bWrapWithInvalidationPanel; // 0x285(0x1)
	uint8_t Pad_0x286[0x12]; // 0x286(0x12)


	// Object: Function UMG.TextBlock.SetVerticalJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf6cc
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalJustification(enum class ETextVerticalJustify InJustification);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D44AF8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.TextBlock.SetText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105daf604
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D44AF8
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function UMG.TextBlock.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105daf58c
	// Params: [ Num(1) Size(0x8) ]
	void SetShadowOffset(struct FVector2D InShadowOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D449A8
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D44AF8
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function UMG.TextBlock.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105daf510
	// Params: [ Num(1) Size(0x10) ]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4492C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D449A8
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D44AF8

	// Object: Function UMG.TextBlock.SetSelectColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf48c
	// Params: [ Num(1) Size(0x1) ]
	void SetSelectColor(bool bIsSelect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D447DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4492C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D449A8
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104F0F458
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C

	// Object: Function UMG.TextBlock.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf410
	// Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D448B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D447DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4492C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D449A8
	// [Call #13] RVA: 0x104F0F380
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.TextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf394
	// Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D44B68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D448B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D447DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4492C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.TextBlock.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf318
	// Params: [ Num(1) Size(0x1) ]
	void SetJustification(enum class ETextJustify InJustification);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D44A88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D44B68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D448B8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D447DC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.TextBlock.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf20c
	// Params: [ Num(1) Size(0x58) ]
	void SetFont(struct FSlateFontInfo InFontInfo);
	// [Call #1] RVA: 0x1051E3694
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D44A20
	// [Call #5] RVA: 0x10206BEBC
	// [Call #6] RVA: 0x10206BEBC
	// [Call #7] RVA: 0x10206BEBC
	// [Call #8] RVA: 0x10206BEBC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D44A88
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D44B68
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.TextBlock.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf10c
	// Params: [ Num(1) Size(0x28) ]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4463C
	// [Call #4] RVA: 0x101FE9F60
	// [Call #5] RVA: 0x101FE9F60
	// [Call #6] RVA: 0x101FE9F60
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1051E3694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D44A20
	// [Call #13] RVA: 0x10206BEBC
	// [Call #14] RVA: 0x10206BEBC
	// [Call #15] RVA: 0x10206BEBC
	// [Call #16] RVA: 0x10206BEBC
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function UMG.TextBlock.SetAutoEllipsisText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf088
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoEllipsisText(bool InAutoEllipsisText);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D44BD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4463C
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1051E3694
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D44A20
	// [Call #16] RVA: 0x10206BEBC
	// [Call #17] RVA: 0x10206BEBC

	// Object: Function UMG.TextBlock.SetActiveColorIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daf00c
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveColorIndex(int InIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D446A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D44BD4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4463C
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x101FE9F60
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1051E3694
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.TextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105daefa8
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x105D45734
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D446A8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D44BD4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D4463C
	// [Call #15] RVA: 0x101FE9F60
	// [Call #16] RVA: 0x101FE9F60
	// [Call #17] RVA: 0x101FE9F60
};

// Object: Class UMG.ComboBoxString
// Size: 0x1070 (Inherited: 0x100)
struct UComboBoxString : UWidget
{
	struct TArray<struct FString> DefaultOptions; // 0x100(0x10)
	struct FString SelectedOption; // 0x110(0x10)
	struct FComboBoxStyle WidgetStyle; // 0x120(0x508)
	struct FTableRowStyle ItemStyle; // 0x628(0x8F8)
	struct FMargin ContentPadding; // 0xF20(0x10)
	float MaxListHeight; // 0xF30(0x4)
	bool HasDownArrow; // 0xF34(0x1)
	bool EnableGamepadNavigationMode; // 0xF35(0x1)
	uint8_t Pad_0xF36[0x2]; // 0xF36(0x2)
	struct FSlateFontInfo Font; // 0xF38(0x58)
	struct FSlateColor ForegroundColor; // 0xF90(0x28)
	bool bIsFocusable; // 0xFB8(0x1)
	bool bAbove; // 0xFB9(0x1)
	uint8_t Pad_0xFBA[0x6]; // 0xFBA(0x6)
	DelegateProperty OnGenerateWidgetEvent; // 0xFC0(0x10)
	uint8_t Pad_0xFD0[0x20]; // 0xFD0(0x20)
	struct FScriptMulticastDelegate OnSelectionChanged; // 0xFF0(0x10)
	struct FScriptMulticastDelegate OnOpening; // 0x1000(0x10)
	struct FScriptMulticastDelegate OnOpenChanged; // 0x1010(0x10)
	uint8_t Pad_0x1020[0x50]; // 0x1020(0x50)


	// Object: Function UMG.ComboBoxString.SetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9aff4
	// Params: [ Num(1) Size(0x10) ]
	void SetSelectedOption(struct FString Option);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x105D2F37C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function UMG.ComboBoxString.SetComboListViewOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9af68
	// Params: [ Num(2) Size(0x8) ]
	int SetComboListViewOffset(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2F4F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x105D2F37C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.ComboBoxString.RemoveOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9aec0
	// Params: [ Num(2) Size(0x11) ]
	bool RemoveOption(struct FString Option);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2F1B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F4F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x105D2F37C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function UMG.ComboBoxString.RefreshOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9aeac
	// Params: [ Num(0) Size(0x0) ]
	void RefreshOptions();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2F1B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F4F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x105D2F37C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: DelegateFunction UMG.ComboBoxString.OnSelectionChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x11) ]
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.ComboBoxString.OnOpeningEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnOpeningEvent__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.ComboBoxString.OnOpenChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x2) ]
	void OnOpenChangedEvent__DelegateSignature(bool bIsOpen, bool bAbove);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.ComboBoxString.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9ae48
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedOption();
	// [Call #1] RVA: 0x105D2F484
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D2F1B0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D2F4F0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x105D2F37C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function UMG.ComboBoxString.GetOptionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9ae14
	// Params: [ Num(1) Size(0x4) ]
	int GetOptionCount();
	// [Call #1] RVA: 0x105D2F4E8
	// [Call #2] RVA: 0x105D2F484
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F1B0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D2F4F0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.ComboBoxString.GetOptionAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9ad60
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetOptionAtIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2F2C0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x105D2F4E8
	// [Call #9] RVA: 0x105D2F484
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D2F1B0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function UMG.ComboBoxString.FindOptionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9acb8
	// Params: [ Num(2) Size(0x14) ]
	int FindOptionIndex(struct FString Option);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2EEE0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F2C0
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D2F4E8
	// [Call #15] RVA: 0x105D2F484
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function UMG.ComboBoxString.CloseComboBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9aca4
	// Params: [ Num(0) Size(0x0) ]
	void CloseComboBox();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2EEE0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F2C0
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D2F4E8
	// [Call #15] RVA: 0x105D2F484
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function UMG.ComboBoxString.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ac90
	// Params: [ Num(0) Size(0x0) ]
	void ClearSelection();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2EEE0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F2C0
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D2F4E8
	// [Call #15] RVA: 0x105D2F484
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function UMG.ComboBoxString.ClearOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ac7c
	// Params: [ Num(0) Size(0x0) ]
	void ClearOptions();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2EEE0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2F2C0
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D2F4E8
	// [Call #15] RVA: 0x105D2F484
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function UMG.ComboBoxString.AddOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9abe4
	// Params: [ Num(1) Size(0x10) ]
	void AddOption(struct FString Option);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2E6FC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2EEE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D2F2C0
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x105D2F4E8
};

// Object: Class UMG.Button
// Size: 0x520 (Inherited: 0x118)
struct UButton : UContentWidget
{
	struct USlateWidgetStyleAsset* Style; // 0x118(0x8)
	struct FButtonStyle WidgetStyle; // 0x120(0x338)
	struct FLinearColor ColorAndOpacity; // 0x458(0x10)
	struct FLinearColor BackgroundColor; // 0x468(0x10)
	enum class EButtonClickMethod ClickMethod; // 0x478(0x1)
	enum class EButtonTouchMethod TouchMethod; // 0x479(0x1)
	bool IsFocusable; // 0x47A(0x1)
	bool IsPassMouseEvent; // 0x47B(0x1)
	float nClickCd; // 0x47C(0x4)
	bool bTouchPass; // 0x480(0x1)
	bool bPressEventWithParamPass; // 0x481(0x1)
	uint8_t Pad_0x482[0x6]; // 0x482(0x6)
	struct FScriptMulticastDelegate OnClicked; // 0x488(0x10)
	struct FScriptMulticastDelegate OnPressed; // 0x498(0x10)
	struct FScriptMulticastDelegate OnReleased; // 0x4A8(0x10)
	struct FScriptMulticastDelegate OnHovered; // 0x4B8(0x10)
	struct FScriptMulticastDelegate OnUnhovered; // 0x4C8(0x10)
	struct FScriptMulticastDelegate OnPressedParam; // 0x4D8(0x10)
	DelegateProperty OnMouseButtonDownEvent; // 0x4E8(0x10)
	uint8_t OnClickSoundType; // 0x4F8(0x1)
	uint8_t Pad_0x4F9[0x1F]; // 0x4F9(0x1F)
	uint8_t ButtonClickGroupName; // 0x518(0x1)
	uint8_t Pad_0x519[0x7]; // 0x519(0x7)


	// Object: Function UMG.Button.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d98410
	// Params: [ Num(1) Size(0x1) ]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A768
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.Button.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d9835c
	// Params: [ Num(1) Size(0x338) ]
	void SetStyle(struct FButtonStyle& InStyle);
	// [Call #1] RVA: 0x10522DC68
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2A5EC
	// [Call #5] RVA: 0x1037408D8
	// [Call #6] RVA: 0x1037408D8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2A768
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function UMG.Button.SetPressEventWithParamPassEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d982d8
	// Params: [ Num(1) Size(0x1) ]
	void SetPressEventWithParamPassEnabled(bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2AD0C
	// [Call #4] RVA: 0x10522DC68
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2A5EC
	// [Call #8] RVA: 0x1037408D8
	// [Call #9] RVA: 0x1037408D8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2A768
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function UMG.Button.SetOnClickSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d98250
	// Params: [ Num(1) Size(0x10) ]
	void SetOnClickSound(DelegateProperty onSound);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2A824
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2AD0C
	// [Call #8] RVA: 0x10522DC68
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D2A5EC
	// [Call #12] RVA: 0x1037408D8
	// [Call #13] RVA: 0x1037408D8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D2A768

	// Object: Function UMG.Button.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d981d4
	// Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A628
	// [Call #4] RVA: 0x101FD9E48
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2A824
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2AD0C
	// [Call #11] RVA: 0x10522DC68
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D2A5EC
	// [Call #15] RVA: 0x1037408D8
	// [Call #16] RVA: 0x1037408D8
	// [Call #17] RVA: 0x106C8459C

	// Object: Function UMG.Button.SetClickSoundType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d98158
	// Params: [ Num(1) Size(0x1) ]
	void SetClickSoundType(uint8_t onSoundType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A81C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2A628
	// [Call #7] RVA: 0x101FD9E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2A824
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2AD0C
	// [Call #14] RVA: 0x10522DC68
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.Button.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d980dc
	// Params: [ Num(1) Size(0x1) ]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A750
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2A81C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2A628
	// [Call #10] RVA: 0x101FD9E48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2A824
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.Button.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d98060
	// Params: [ Num(1) Size(0x10) ]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A6A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2A750
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2A81C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2A628
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.Button.Release
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9804c
	// Params: [ Num(0) Size(0x0) ]
	void Release();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2A6A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2A750
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2A81C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2A628
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: DelegateFunction UMG.Button.OnButtonSoundEvent__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnButtonSoundEvent__DelegateSignature(uint8_t Sound);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.Button.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d98018
	// Params: [ Num(1) Size(0x1) ]
	bool IsPressed();
	// [Call #1] RVA: 0x105D2A720
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2A6A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2A750
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2A81C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2A628
	// [Call #14] RVA: 0x101FD9E48
};

// Object: Class UMG.EditableTextBox
// Size: 0xCB0 (Inherited: 0x100)
struct UEditableTextBox : UWidget
{
	struct FText Text; // 0x100(0x18)
	DelegateProperty TextDelegate; // 0x118(0x10)
	bool bAutoScrollText; // 0x128(0x1)
	uint8_t Pad_0x129[0x3]; // 0x129(0x3)
	float ScrollSpeed; // 0x12C(0x4)
	uint8_t AutoScrollType; // 0x130(0x1)
	uint8_t Pad_0x131[0x7]; // 0x131(0x7)
	struct FEditableTextBoxStyle WidgetStyle; // 0x138(0xA68)
	struct USlateWidgetStyleAsset* Style; // 0xBA0(0x8)
	struct FText hintText; // 0xBA8(0x18)
	DelegateProperty HintTextDelegate; // 0xBC0(0x10)
	struct FSlateFontInfo Font; // 0xBD0(0x58)
	struct FLinearColor ForegroundColor; // 0xC28(0x10)
	struct FLinearColor BackgroundColor; // 0xC38(0x10)
	struct FLinearColor ReadOnlyForegroundColor; // 0xC48(0x10)
	bool IsReadOnly; // 0xC58(0x1)
	bool IsPassword; // 0xC59(0x1)
	uint8_t Pad_0xC5A[0x2]; // 0xC5A(0x2)
	float MinimumDesiredWidth; // 0xC5C(0x4)
	struct FMargin Padding; // 0xC60(0x10)
	bool IsCaretMovedWhenGainFocus; // 0xC70(0x1)
	bool SelectAllTextWhenFocused; // 0xC71(0x1)
	bool RevertTextOnEscape; // 0xC72(0x1)
	bool ClearKeyboardFocusOnCommit; // 0xC73(0x1)
	bool SelectAllTextOnCommit; // 0xC74(0x1)
	bool AllowContextMenu; // 0xC75(0x1)
	enum class EVirtualKeyboardType keyboardType; // 0xC76(0x1)
	uint8_t Pad_0xC77[0x1]; // 0xC77(0x1)
	struct FShapedTextOptions ShapedTextOptions; // 0xC78(0x4)
	bool bVirtualKeyboardTriggerDirect; // 0xC7C(0x1)
	uint8_t Pad_0xC7D[0x3]; // 0xC7D(0x3)
	struct FScriptMulticastDelegate OnTextChanged; // 0xC80(0x10)
	struct FScriptMulticastDelegate OnTextCommitted; // 0xC90(0x10)
	uint8_t Pad_0xCA0[0x10]; // 0xCA0(0x10)


	// Object: Function UMG.EditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e1d4
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D3249C
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function UMG.EditableTextBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e158
	// Params: [ Num(1) Size(0x4) ]
	void SetScrollOffset(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D32910
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D3249C
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.EditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e0d4
	// Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3257C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D32910
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x105D3249C
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x10519022C

	// Object: Function UMG.EditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e014
	// Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D32504
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D3257C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D32910
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x105D3249C
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8

	// Object: Function UMG.EditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9df54
	// Params: [ Num(1) Size(0x18) ]
	void SetError(struct FText InError);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D3256C
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x105D32504
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x105D3257C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x19) ]
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.EditableTextBox.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9df20
	// Params: [ Num(1) Size(0x1) ]
	bool HasError();
	// [Call #1] RVA: 0x105D32620
	// [Call #2] RVA: 0x104F0F380
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104F0F458
	// [Call #6] RVA: 0x105D3256C
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104F0F458
	// [Call #16] RVA: 0x105D32504
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x105D3257C

	// Object: Function UMG.EditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9debc
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x105D32480
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105D32620
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x105D3256C
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x105D32504
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x101FBDBE8
	// [Call #26] RVA: 0x106C8459C
	// [Call #27] RVA: 0x10516D168

	// Object: Function UMG.EditableTextBox.ClearError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9dea8
	// Params: [ Num(0) Size(0x0) ]
	void ClearError();
	// [Call #1] RVA: 0x105D32480
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105D32620
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x105D3256C
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x105D32504
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x101FBDBE8
	// [Call #26] RVA: 0x106C8459C
};

// Object: Class UMG.InvalidationBox
// Size: 0x128 (Inherited: 0x118)
struct UInvalidationBox : UContentWidget
{
	bool bCanCache; // 0x111(0x1)
	bool CacheRelativeTransforms; // 0x112(0x1)
	bool bDontPaintWhenChildEmpty; // 0x113(0x1)
	uint8_t Pad_0x11B[0xD]; // 0x11B(0xD)


	// Object: Function UMG.InvalidationBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1970
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D37A08
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.InvalidationBox.SetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da18ec
	// Params: [ Num(1) Size(0x1) ]
	void SetCanCache(bool CanCache);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D379F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D37A08
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.InvalidationBox.InvalidateCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da18d8
	// Params: [ Num(0) Size(0x0) ]
	void InvalidateCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D379F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D37A08
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.InvalidationBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da18a4
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D37A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D379F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D37A08
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.InvalidationBox.GetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da1870
	// Params: [ Num(1) Size(0x1) ]
	bool GetCanCache();
	// [Call #1] RVA: 0x105D379DC
	// [Call #2] RVA: 0x105D37A1C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D379F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D37A08
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.RetainerBox
// Size: 0x140 (Inherited: 0x118)
struct URetainerBox : UContentWidget
{
	bool RenderOnInvalidation; // 0x111(0x1)
	bool RenderOnPhase; // 0x112(0x1)
	int Phase; // 0x114(0x4)
	int PhaseCount; // 0x118(0x4)
	struct UMaterialInterface* EffectMaterial; // 0x120(0x8)
	struct FName TextureParameter; // 0x128(0x8)
	uint8_t Pad_0x132[0xE]; // 0x132(0xE)


	// Object: Function UMG.RetainerBox.SkipCurrentFrameRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7178
	// Params: [ Num(0) Size(0x0) ]
	void SkipCurrentFrameRender();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function UMG.RetainerBox.SetTextureParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da70fc
	// Params: [ Num(1) Size(0x8) ]
	void SetTextureParameter(struct FName TextureParameter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3CAA4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.RetainerBox.SetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7080
	// Params: [ Num(1) Size(0x8) ]
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3CA90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3CAA4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.RetainerBox.RequestRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da706c
	// Params: [ Num(0) Size(0x0) ]
	void RequestRender();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3CA90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3CAA4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.RetainerBox.GetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da7038
	// Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetEffectMaterial();
	// [Call #1] RVA: 0x105D3CA80
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D3CA90
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D3CAA4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.AsyncTaskDownloadImage
// Size: 0x48 (Inherited: 0x28)
struct UAsyncTaskDownloadImage : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFail; // 0x38(0x10)


	// Object: Function UMG.AsyncTaskDownloadImage.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d95b58
	// Params: [ Num(2) Size(0x18) ]
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x105D25F1C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
	// [Call #15] RVA: 0x105D9660C
};

// Object: Class UMG.BackgroundBlur
// Size: 0x2C8 (Inherited: 0x118)
struct UBackgroundBlur : UContentWidget
{
	struct FMargin Padding; // 0x114(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x124(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x125(0x1)
	bool bApplyAlphaToBlur; // 0x126(0x1)
	float BlurStrength; // 0x128(0x4)
	bool bOverrideAutoRadiusCalculation; // 0x12C(0x1)
	enum class EBlurType BlurType; // 0x12D(0x1)
	float BlurDirection; // 0x130(0x4)
	struct FVector2D BlurCenter; // 0x134(0x8)
	int BlurRadius; // 0x13C(0x4)
	struct UTexture* BlurMask; // 0x140(0x8)
	struct FSlateBrush LowQualityFallbackBrush; // 0x148(0xB8)
	struct FSlateBrush BlurMaskBrush; // 0x200(0xB8)
	uint8_t Pad_0x2B9[0xF]; // 0x2B9(0xF)


	// Object: Function UMG.BackgroundBlur.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9623c
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27744
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.BackgroundBlur.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d961bc
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D276B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D27744
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.BackgroundBlur.SetLowQualityFallbackBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d96110
	// Params: [ Num(1) Size(0xB8) ]
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D27924
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D276B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D27744
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function UMG.BackgroundBlur.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96094
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27730
	// [Call #4] RVA: 0x101FE9E54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D27924
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D276B4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D27744
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.BackgroundBlur.SetBlurStrength
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105d96010
	// Params: [ Num(1) Size(0x4) ]
	void SetBlurStrength(float InStrength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D27730
	// [Call #6] RVA: 0x101FE9E54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D27924
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x101FEA144
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D276B4

	// Object: Function UMG.BackgroundBlur.SetBlurRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d95f94
	// Params: [ Num(1) Size(0x4) ]
	void SetBlurRadius(int InBlurRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2776C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D27730
	// [Call #9] RVA: 0x101FE9E54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D27924
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x106C8459C

	// Object: Function UMG.BackgroundBlur.SetBlurMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d95f18
	// Params: [ Num(1) Size(0x8) ]
	void SetBlurMask(struct UTexture* InTexture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D278E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2776C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D27730
	// [Call #12] RVA: 0x101FE9E54
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.BackgroundBlur.SetBlurDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d95e9c
	// Params: [ Num(1) Size(0x4) ]
	void SetBlurDirection(float InDirection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27840
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D278E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2776C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.BackgroundBlur.SetBlurCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d95e24
	// Params: [ Num(1) Size(0x8) ]
	void SetBlurCenter(struct FVector2D InCenter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D278AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D27840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D278E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2776C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.BackgroundBlur.SetApplyAlphaToBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d95da0
	// Params: [ Num(1) Size(0x1) ]
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27758
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D278AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D27840
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D278E4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class UMG.BackgroundBlurSlot
// Size: 0x68 (Inherited: 0x40)
struct UBackgroundBlurSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.BackgroundBlurSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d967e0
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27C90
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105D96B0C

	// Object: Function UMG.BackgroundBlurSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96760
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27C80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D27C90
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.BackgroundBlurSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d966e4
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D27C88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D27C80
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D27C90
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.PropertyBinding
// Size: 0x48 (Inherited: 0x28)
struct UPropertyBinding : UObject
{
	struct TWeakObjectPtr<struct UObject> SourceObject; // 0x28(0x8)
	struct FDynamicPropertyPath SourcePath; // 0x30(0x10)
	struct FName DestinationProperty; // 0x40(0x8)
};

// Object: Class UMG.BoolBinding
// Size: 0x48 (Inherited: 0x48)
struct UBoolBinding : UPropertyBinding
{

	// Object: Function UMG.BoolBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105d96a44
	// Params: [ Num(1) Size(0x1) ]
	bool GetValue();
	// [Call #1] RVA: 0x105D24974
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105D97730
	// [Call #6] RVA: 0x105D29334
	// [Call #7] RVA: 0x105D29308
	// [Call #8] RVA: 0x105D2922C
};

// Object: Class UMG.Border
// Size: 0x290 (Inherited: 0x118)
struct UBorder : UContentWidget
{
	enum class EHorizontalAlignment HorizontalAlignment; // 0x111(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x112(0x1)
	uint8_t bShowEffectWhenDisabled : 1; // 0x113(0x1), Mask(0x1)
	struct FLinearColor ContentColorAndOpacity; // 0x114(0x10)
	DelegateProperty ContentColorAndOpacityDelegate; // 0x128(0x10)
	struct FMargin Padding; // 0x138(0x10)
	struct FSlateBrush Background; // 0x148(0xB8)
	DelegateProperty BackgroundDelegate; // 0x200(0x10)
	struct FLinearColor BrushColor; // 0x210(0x10)
	DelegateProperty BrushColorDelegate; // 0x220(0x10)
	struct FVector2D DesiredSizeScale; // 0x230(0x8)
	DelegateProperty OnMouseButtonDownEvent; // 0x238(0x10)
	DelegateProperty OnMouseButtonUpEvent; // 0x248(0x10)
	DelegateProperty OnMouseMoveEvent; // 0x258(0x10)
	DelegateProperty OnMouseDoubleClickEvent; // 0x268(0x10)
	bool bDontPaintWhenChildEmpty; // 0x278(0x1)
	bool bDontPaintWhenAlphaZero; // 0x279(0x1)
	uint8_t BitPad_0x27C_1 : 7; // 0x27C(0x1)
	uint8_t Pad_0x27D[0x13]; // 0x27D(0x13)


	// Object: Function UMG.Border.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97218
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D28F88
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.Border.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97198
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D28EF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D28F88
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.Border.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9711c
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D28F74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D28EF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D28F88
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Border.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97098
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D292F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D28F74
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D28EF8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D28F88
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.Border.SetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97014
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenAlphaZero(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D29320
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D292F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D28F74
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D28EF8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetDesiredSizeScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d96f9c
	// Params: [ Num(1) Size(0x8) ]
	void SetDesiredSizeScale(struct FVector2D InScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2934C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D29320
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D292F4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D28F74
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetContentColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d96f20
	// Params: [ Num(1) Size(0x10) ]
	void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D28E7C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2934C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D29320
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D292F4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96ea4
	// Params: [ Num(1) Size(0x8) ]
	void SetBrushFromTexture(struct UTexture2D* Texture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2913C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D28E7C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2934C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D29320
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96e28
	// Params: [ Num(1) Size(0x8) ]
	void SetBrushFromMaterial(struct UMaterialInterface* Material);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D291B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2913C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D28E7C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2934C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96dac
	// Params: [ Num(1) Size(0x8) ]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2908C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D291B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2913C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D28E7C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D2934C

	// Object: Function UMG.Border.SetBrushColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d96d30
	// Params: [ Num(1) Size(0x10) ]
	void SetBrushColor(struct FLinearColor InBrushColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D28F9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2908C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D291B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2913C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.Border.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d96c84
	// Params: [ Num(1) Size(0xB8) ]
	void SetBrush(struct FSlateBrush& InBrush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D29018
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D28F9C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2908C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D291B4
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.Border.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96c50
	// Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial();
	// [Call #1] RVA: 0x105D2922C
	// [Call #2] RVA: 0x101FE9E54
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D29018
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x101FEA144
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D28F9C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D2908C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D291B4

	// Object: Function UMG.Border.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96c1c
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D29308
	// [Call #2] RVA: 0x105D2922C
	// [Call #3] RVA: 0x101FE9E54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D29018
	// [Call #7] RVA: 0x101FEA144
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D28F9C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D2908C
	// [Call #16] RVA: 0x10516D168

	// Object: Function UMG.Border.GetDontPaintWhenAlphaZero
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d96be8
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenAlphaZero();
	// [Call #1] RVA: 0x105D29334
	// [Call #2] RVA: 0x105D29308
	// [Call #3] RVA: 0x105D2922C
	// [Call #4] RVA: 0x101FE9E54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D29018
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D28F9C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D2908C
};

// Object: Class UMG.BorderSlot
// Size: 0x68 (Inherited: 0x40)
struct UBorderSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.BorderSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97904
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D29534
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105D97C58

	// Object: Function UMG.BorderSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97884
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D29524
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D29534
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.BorderSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d97808
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2952C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D29524
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D29534
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.BrushBinding
// Size: 0x50 (Inherited: 0x48)
struct UBrushBinding : UPropertyBinding
{
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function UMG.BrushBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105d97b6c
	// Params: [ Num(1) Size(0xB8) ]
	struct FSlateBrush GetValue();
	// [Call #1] RVA: 0x105D24AE8
	// [Call #2] RVA: 0x101FE5E98
	// [Call #3] RVA: 0x101FEA144
	// [Call #4] RVA: 0x101FEA144
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
};

// Object: Class UMG.ButtonSlot
// Size: 0x68 (Inherited: 0x40)
struct UButtonSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.ButtonSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d98954
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2AF48
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105D98E34

	// Object: Function UMG.ButtonSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d988d4
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2ADC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2AF48
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.ButtonSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d98858
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2AEB0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2ADC8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2AF48
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.CanvasPanelSlot
// Size: 0x78 (Inherited: 0x40)
struct UCanvasPanelSlot : UPanelSlot
{
	struct FAnchorData LayoutData; // 0x40(0x28)
	bool bAutoSize; // 0x68(0x1)
	bool bSupportNotch; // 0x69(0x1)
	uint8_t Pad_0x6A[0x2]; // 0x6A(0x2)
	int ZOrder; // 0x6C(0x4)
	uint8_t Pad_0x70[0x8]; // 0x70(0x8)


	// Object: Function UMG.CanvasPanelSlot.SetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d996b8
	// Params: [ Num(1) Size(0x4) ]
	void SetZOrder(int InZOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C438
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.CanvasPanelSlot.SetSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d99634
	// Params: [ Num(1) Size(0x1) ]
	void SetSupportNotch(bool InSupportNotch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C410
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C438
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.CanvasPanelSlot.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d995bc
	// Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FVector2D InSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2BE74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C410
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C438
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.CanvasPanelSlot.SetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d99544
	// Params: [ Num(1) Size(0x8) ]
	void SetPosition(struct FVector2D InPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2BD80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2BE74
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C410
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C438
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.CanvasPanelSlot.SetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d994c4
	// Params: [ Num(1) Size(0x10) ]
	void SetOffsets(struct FMargin InOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2BFE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2BD80
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2BE74
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C410
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.SetMinimum
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x105d9944c
	// Params: [ Num(1) Size(0x8) ]
	void SetMinimum(struct FVector2D InMinimumAnchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C548
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2BFE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2BD80
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2BE74
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.SetMaximum
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x105d993d4
	// Params: [ Num(1) Size(0x8) ]
	void SetMaximum(struct FVector2D InMaximumAnchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C5BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C548
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2BFE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2BD80
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D2BE74

	// Object: Function UMG.CanvasPanelSlot.SetLayout
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d99344
	// Params: [ Num(1) Size(0x28) ]
	void SetLayout(struct FAnchorData& InLayoutData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2BBE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C5BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C548
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2BFE8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d992c0
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(bool InbAutoSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C2E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2BBE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C5BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C548
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.SetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d99240
	// Params: [ Num(1) Size(0x10) ]
	void SetAnchors(struct FAnchors InAnchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C0F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C2E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2BBE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C5BC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.SetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105d991c8
	// Params: [ Num(1) Size(0x8) ]
	void SetAlignment(struct FVector2D InAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2C200
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C0F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C2E8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2BBE0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.GetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99194
	// Params: [ Num(1) Size(0x4) ]
	int GetZOrder();
	// [Call #1] RVA: 0x105D2C4D8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2C200
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2C0F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2C2E8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2BBE0

	// Object: Function UMG.CanvasPanelSlot.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99160
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSize();
	// [Call #1] RVA: 0x105D2BF68
	// [Call #2] RVA: 0x105D2C4D8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D2C200
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D2C0F4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D2C2E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9912c
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPosition();
	// [Call #1] RVA: 0x105D2BDF4
	// [Call #2] RVA: 0x105D2BF68
	// [Call #3] RVA: 0x105D2C4D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2C200
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C0F4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C2E8
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.CanvasPanelSlot.GetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d990f4
	// Params: [ Num(1) Size(0x10) ]
	struct FMargin GetOffsets();
	// [Call #1] RVA: 0x105D2C05C
	// [Call #2] RVA: 0x105D2BDF4
	// [Call #3] RVA: 0x105D2BF68
	// [Call #4] RVA: 0x105D2C4D8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2C200
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2C0F4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D2C2E8

	// Object: Function UMG.CanvasPanelSlot.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d990a4
	// Params: [ Num(1) Size(0x28) ]
	struct FAnchorData GetLayout();
	// [Call #1] RVA: 0x105D2BD6C
	// [Call #2] RVA: 0x105D2C05C
	// [Call #3] RVA: 0x105D2BDF4
	// [Call #4] RVA: 0x105D2BF68
	// [Call #5] RVA: 0x105D2C4D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D2C200
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D2C0F4
	// [Call #12] RVA: 0x10516D168

	// Object: Function UMG.CanvasPanelSlot.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99070
	// Params: [ Num(1) Size(0x1) ]
	bool GetAutoSize();
	// [Call #1] RVA: 0x105D2C3A0
	// [Call #2] RVA: 0x105D2BD6C
	// [Call #3] RVA: 0x105D2C05C
	// [Call #4] RVA: 0x105D2BDF4
	// [Call #5] RVA: 0x105D2BF68
	// [Call #6] RVA: 0x105D2C4D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2C200
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D2C0F4

	// Object: Function UMG.CanvasPanelSlot.GetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99038
	// Params: [ Num(1) Size(0x10) ]
	struct FAnchors GetAnchors();
	// [Call #1] RVA: 0x105D2C168
	// [Call #2] RVA: 0x105D2C3A0
	// [Call #3] RVA: 0x105D2BD6C
	// [Call #4] RVA: 0x105D2C05C
	// [Call #5] RVA: 0x105D2BDF4
	// [Call #6] RVA: 0x105D2BF68
	// [Call #7] RVA: 0x105D2C4D8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D2C200
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.CanvasPanelSlot.GetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99004
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetAlignment();
	// [Call #1] RVA: 0x105D2C26C
	// [Call #2] RVA: 0x105D2C168
	// [Call #3] RVA: 0x105D2C3A0
	// [Call #4] RVA: 0x105D2BD6C
	// [Call #5] RVA: 0x105D2C05C
	// [Call #6] RVA: 0x105D2BDF4
	// [Call #7] RVA: 0x105D2BF68
	// [Call #8] RVA: 0x105D2C4D8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D2C200

	// Object: Function UMG.CanvasPanelSlot.GeSupportNotch
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d98fd0
	// Params: [ Num(1) Size(0x1) ]
	bool GeSupportNotch();
	// [Call #1] RVA: 0x105D2C430
	// [Call #2] RVA: 0x105D2C26C
	// [Call #3] RVA: 0x105D2C168
	// [Call #4] RVA: 0x105D2C3A0
	// [Call #5] RVA: 0x105D2BD6C
	// [Call #6] RVA: 0x105D2C05C
	// [Call #7] RVA: 0x105D2BDF4
	// [Call #8] RVA: 0x105D2BF68
	// [Call #9] RVA: 0x105D2C4D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class UMG.CheckBox
// Size: 0x910 (Inherited: 0x118)
struct UCheckBox : UContentWidget
{
	uint8_t CheckedState; // 0x111(0x1)
	DelegateProperty CheckedStateDelegate; // 0x118(0x10)
	struct FCheckBoxStyle WidgetStyle; // 0x128(0x730)
	struct USlateWidgetStyleAsset* Style; // 0x858(0x8)
	struct USlateBrushAsset* UncheckedImage; // 0x860(0x8)
	struct USlateBrushAsset* UncheckedHoveredImage; // 0x868(0x8)
	struct USlateBrushAsset* UncheckedPressedImage; // 0x870(0x8)
	struct USlateBrushAsset* CheckedImage; // 0x878(0x8)
	struct USlateBrushAsset* CheckedHoveredImage; // 0x880(0x8)
	struct USlateBrushAsset* CheckedPressedImage; // 0x888(0x8)
	struct USlateBrushAsset* UndeterminedImage; // 0x890(0x8)
	struct USlateBrushAsset* UndeterminedHoveredImage; // 0x898(0x8)
	struct USlateBrushAsset* UndeterminedPressedImage; // 0x8A0(0x8)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x8A8(0x1)
	uint8_t Pad_0x8AA[0x2]; // 0x8AA(0x2)
	struct FMargin Padding; // 0x8AC(0x10)
	uint8_t Pad_0x8BC[0x4]; // 0x8BC(0x4)
	struct FSlateColor BorderBackgroundColor; // 0x8C0(0x28)
	bool IsFocusable; // 0x8E8(0x1)
	uint8_t Pad_0x8E9[0x7]; // 0x8E9(0x7)
	struct FScriptMulticastDelegate OnCheckStateChanged; // 0x8F0(0x10)
	uint8_t Pad_0x900[0x10]; // 0x900(0x10)


	// Object: Function UMG.CheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d99f50
	// Params: [ Num(1) Size(0x1) ]
	void SetIsChecked(bool InIsChecked);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2CD90
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.CheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d99ed4
	// Params: [ Num(1) Size(0x1) ]
	void SetCheckedState(uint8_t InCheckedState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2CE30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2CD90
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.CheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99ea0
	// Params: [ Num(1) Size(0x1) ]
	bool IsPressed();
	// [Call #1] RVA: 0x105D2CD44
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D2CE30
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D2CD90
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.CheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99e6c
	// Params: [ Num(1) Size(0x1) ]
	bool IsChecked();
	// [Call #1] RVA: 0x105D2CD58
	// [Call #2] RVA: 0x105D2CD44
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D2CE30
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D2CD90
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.CheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d99e38
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetCheckedState();
	// [Call #1] RVA: 0x105D2CD78
	// [Call #2] RVA: 0x105D2CD58
	// [Call #3] RVA: 0x105D2CD44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2CE30
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2CD90
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.CheckedStateBinding
// Size: 0x50 (Inherited: 0x48)
struct UCheckedStateBinding : UPropertyBinding
{
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function UMG.CheckedStateBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105d9a274
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetValue();
	// [Call #1] RVA: 0x105D24DCC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105D9A698
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D2D66C
	// [Call #9] RVA: 0x10516D168
};

// Object: Class UMG.CircularThrobber
// Size: 0x1E8 (Inherited: 0x100)
struct UCircularThrobber : UWidget
{
	int NumberOfPieces; // 0x100(0x4)
	float Period; // 0x104(0x4)
	float Radius; // 0x108(0x4)
	uint8_t Pad_0x10C[0x4]; // 0x10C(0x4)
	struct USlateBrushAsset* PieceImage; // 0x110(0x8)
	struct FSlateBrush Image; // 0x118(0xB8)
	bool bEnableRadius; // 0x1D0(0x1)
	uint8_t Pad_0x1D1[0x17]; // 0x1D1(0x17)


	// Object: Function UMG.CircularThrobber.SetRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9a500
	// Params: [ Num(1) Size(0x4) ]
	void SetRadius(float InRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2D6BC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105D9A8DC

	// Object: Function UMG.CircularThrobber.SetPeriod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9a484
	// Params: [ Num(1) Size(0x4) ]
	void SetPeriod(float InPeriod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2D694
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2D6BC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.CircularThrobber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9a408
	// Params: [ Num(1) Size(0x4) ]
	void SetNumberOfPieces(int InNumberOfPieces);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D2D66C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D2D694
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D2D6BC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.ColorBinding
// Size: 0x50 (Inherited: 0x48)
struct UColorBinding : UPropertyBinding
{
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function UMG.ColorBinding.GetSlateValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105d9a7a8
	// Params: [ Num(1) Size(0x28) ]
	struct FSlateColor GetSlateValue();
	// [Call #1] RVA: 0x105D250EC
	// [Call #2] RVA: 0x101FE9FDC
	// [Call #3] RVA: 0x101FE9F60
	// [Call #4] RVA: 0x101FE9F60
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105190870

	// Object: Function UMG.ColorBinding.GetLinearValue
	// Flags: [Final|Native|Public|HasDefaults|Const]
	// Offset: 0x105d9a770
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetLinearValue();
	// [Call #1] RVA: 0x105D2524C
	// [Call #2] RVA: 0x105D250EC
	// [Call #3] RVA: 0x101FE9FDC
	// [Call #4] RVA: 0x101FE9F60
	// [Call #5] RVA: 0x101FE9F60
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class UMG.ComboBox
// Size: 0x138 (Inherited: 0x100)
struct UComboBox : UWidget
{
	struct TArray<struct UObject*> Items; // 0x100(0x10)
	DelegateProperty OnGenerateWidgetEvent; // 0x110(0x10)
	bool bIsFocusable; // 0x120(0x1)
	uint8_t Pad_0x121[0x17]; // 0x121(0x17)
};

// Object: Class UMG.DragDropOperation
// Size: 0x88 (Inherited: 0x28)
struct UDragDropOperation : UObject
{
	struct FString Tag; // 0x28(0x10)
	struct UObject* Payload; // 0x38(0x8)
	struct UWidget* DefaultDragVisual; // 0x40(0x8)
	uint8_t Pivot; // 0x48(0x1)
	uint8_t Pad_0x49[0x3]; // 0x49(0x3)
	struct FVector2D Offset; // 0x4C(0x8)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FScriptMulticastDelegate OnDrop; // 0x58(0x10)
	struct FScriptMulticastDelegate OnDragCancelled; // 0x68(0x10)
	struct FScriptMulticastDelegate OnDragged; // 0x78(0x10)


	// Object: Function UMG.DragDropOperation.Drop
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x105d9bcac
	// Params: [ Num(1) Size(0x78) ]
	void Drop(struct FPointerEvent& PointerEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10220D174
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.DragDropOperation.Dragged
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x105d9bbb4
	// Params: [ Num(1) Size(0x78) ]
	void Dragged(struct FPointerEvent& PointerEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10220D174
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10220D174
	// [Call #9] RVA: 0x10220D174
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.DragDropOperation.DragCancelled
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x105d9babc
	// Params: [ Num(1) Size(0x78) ]
	void DragCancelled(struct FPointerEvent& PointerEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10220D174
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10220D174
	// [Call #9] RVA: 0x10220D174
	// [Call #10] RVA: 0x106C8459C
};

// Object: Class UMG.EditableText
// Size: 0x500 (Inherited: 0x100)
struct UEditableText : UWidget
{
	struct FText Text; // 0x100(0x18)
	DelegateProperty TextDelegate; // 0x118(0x10)
	struct FText hintText; // 0x128(0x18)
	DelegateProperty HintTextDelegate; // 0x140(0x10)
	struct TArray<struct FSlateColor> ColorSwitchList; // 0x150(0x10)
	int ActiveColorIndex; // 0x160(0x4)
	uint8_t Pad_0x164[0x4]; // 0x164(0x4)
	struct FEditableTextStyle WidgetStyle; // 0x168(0x2B0)
	struct USlateWidgetStyleAsset* Style; // 0x418(0x8)
	struct USlateBrushAsset* BackgroundImageSelected; // 0x420(0x8)
	struct USlateBrushAsset* BackgroundImageComposing; // 0x428(0x8)
	struct USlateBrushAsset* CaretImage; // 0x430(0x8)
	struct FSlateFontInfo Font; // 0x438(0x58)
	struct FSlateColor ColorAndOpacity; // 0x490(0x28)
	bool IsReadOnly; // 0x4B8(0x1)
	bool IsPassword; // 0x4B9(0x1)
	uint8_t Pad_0x4BA[0x2]; // 0x4BA(0x2)
	float MinimumDesiredWidth; // 0x4BC(0x4)
	bool IsCaretMovedWhenGainFocus; // 0x4C0(0x1)
	bool SelectAllTextWhenFocused; // 0x4C1(0x1)
	bool RevertTextOnEscape; // 0x4C2(0x1)
	bool ClearKeyboardFocusOnCommit; // 0x4C3(0x1)
	bool SelectAllTextOnCommit; // 0x4C4(0x1)
	bool AllowContextMenu; // 0x4C5(0x1)
	enum class EVirtualKeyboardType keyboardType; // 0x4C6(0x1)
	uint8_t Pad_0x4C7[0x1]; // 0x4C7(0x1)
	struct FShapedTextOptions ShapedTextOptions; // 0x4C8(0x4)
	bool bVirtualKeyboardTriggerDirect; // 0x4CC(0x1)
	uint8_t Pad_0x4CD[0x3]; // 0x4CD(0x3)
	struct FScriptMulticastDelegate OnTextChanged; // 0x4D0(0x10)
	struct FScriptMulticastDelegate OnTextCommitted; // 0x4E0(0x10)
	uint8_t Pad_0x4F0[0x10]; // 0x4F0(0x10)


	// Object: Function UMG.EditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9c480
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D30F00
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function UMG.EditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9c3fc
	// Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool InbIsReadyOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3103C
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D30F00
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.EditableText.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9c378
	// Params: [ Num(1) Size(0x1) ]
	void SetIsPassword(bool InbIsPassword);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D30F68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3103C
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x105D30F00
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x10519022C

	// Object: Function UMG.EditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9c2b8
	// Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InHintText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D30FD4
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D30F68
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D3103C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x105D30F00
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8

	// Object: Function UMG.EditableText.SetActiveColorIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9c23c
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveColorIndex(int InIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D310A8
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D30FD4
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D30F68
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105D3103C

	// Object: DelegateFunction UMG.EditableText.OnEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x19) ]
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.EditableText.OnEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.EditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9c1d8
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x105D30EE4
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D310A8
	// [Call #9] RVA: 0x104F0F380
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104F0F458
	// [Call #13] RVA: 0x105D30FD4
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x105D30F68
	// [Call #22] RVA: 0x10516D168
};

// Object: Class UMG.ExpandableArea
// Size: 0x3C0 (Inherited: 0x100)
struct UExpandableArea : UWidget
{
	uint8_t Pad_0x100[0x8]; // 0x100(0x8)
	struct FExpandableAreaStyle Style; // 0x108(0x180)
	struct FSlateBrush BorderBrush; // 0x288(0xB8)
	struct FSlateColor BorderColor; // 0x340(0x28)
	bool bIsExpanded; // 0x368(0x1)
	uint8_t Pad_0x369[0x3]; // 0x369(0x3)
	float MaxHeight; // 0x36C(0x4)
	struct FMargin HeaderPadding; // 0x370(0x10)
	struct FMargin AreaPadding; // 0x380(0x10)
	struct FScriptMulticastDelegate OnExpansionChanged; // 0x390(0x10)
	struct UWidget* HeaderContent; // 0x3A0(0x8)
	struct UWidget* BodyContent; // 0x3A8(0x8)
	uint8_t Pad_0x3B0[0x10]; // 0x3B0(0x10)


	// Object: Function UMG.ExpandableArea.SetIsExpanded_Animated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e72c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsExpanded_Animated(bool IsExpanded);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D32C18
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.ExpandableArea.SetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9e6a8
	// Params: [ Num(1) Size(0x1) ]
	void SetIsExpanded(bool IsExpanded);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D32BFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D32C18
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.ExpandableArea.GetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d9e674
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsExpanded();
	// [Call #1] RVA: 0x105D32BDC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D32BFC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D32C18
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.FloatBinding
// Size: 0x48 (Inherited: 0x48)
struct UFloatBinding : UPropertyBinding
{

	// Object: Function UMG.FloatBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105d9e9c8
	// Params: [ Num(1) Size(0x4) ]
	float GetValue();
	// [Call #1] RVA: 0x105D25488
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105D9EE34
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D3391C
	// [Call #9] RVA: 0x105D33960
};

// Object: Class UMG.GridPanel
// Size: 0x150 (Inherited: 0x118)
struct UGridPanel : UPanelWidget
{
	struct TArray<float> ColumnFill; // 0x118(0x10)
	struct TArray<float> RowFill; // 0x128(0x10)
	bool bDontPaintWhenChildEmpty; // 0x138(0x1)
	uint8_t Pad_0x139[0x17]; // 0x139(0x17)


	// Object: Function UMG.GridPanel.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ec30
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3394C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.GridPanel.ReSortSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ec1c
	// Params: [ Num(0) Size(0x0) ]
	void ReSortSlot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3394C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.GridPanel.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ebe8
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D33960
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D3394C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.GridPanel.AddChildToGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9eb5c
	// Params: [ Num(2) Size(0x10) ]
	struct UGridSlot* AddChildToGrid(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3391C
	// [Call #4] RVA: 0x105D33960
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D3394C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class UMG.GridSlot
// Size: 0x78 (Inherited: 0x40)
struct UGridSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x2]; // 0x52(0x2)
	int Row; // 0x54(0x4)
	int RowSpan; // 0x58(0x4)
	int Column; // 0x5C(0x4)
	int ColumnSpan; // 0x60(0x4)
	int Layer; // 0x64(0x4)
	struct FVector2D Nudge; // 0x68(0x8)
	uint8_t Pad_0x70[0x8]; // 0x70(0x8)


	// Object: Function UMG.GridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f274
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33F18
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.GridSlot.SetRowSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f1f8
	// Params: [ Num(1) Size(0x4) ]
	void SetRowSpan(int InRowSpan);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33D68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33F18
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.GridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f17c
	// Params: [ Num(1) Size(0x4) ]
	void SetRow(int InRow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33CAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33D68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33F18
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.GridSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f0fc
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33C34
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33CAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33D68
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D33F18
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.GridSlot.SetLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f080
	// Params: [ Num(1) Size(0x4) ]
	void SetLayer(int InLayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33E4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33C34
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33CAC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D33D68
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.GridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9f004
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33F04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33E4C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33C34
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D33CAC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.GridSlot.SetColumnSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ef88
	// Params: [ Num(1) Size(0x4) ]
	void SetColumnSpan(int InColumnSpan);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33E38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33F04
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33E4C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D33C34
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.GridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d9ef0c
	// Params: [ Num(1) Size(0x4) ]
	void SetColumn(int InColumn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D33D7C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D33E38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D33F04
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D33E4C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class UMG.InputKeySelector
// Size: 0x798 (Inherited: 0x100)
struct UInputKeySelector : UWidget
{
	struct FButtonStyle WidgetStyle; // 0x100(0x338)
	struct FTextBlockStyle TextStyle; // 0x438(0x250)
	struct FInputChord SelectedKey; // 0x688(0x20)
	struct FSlateFontInfo Font; // 0x6A8(0x58)
	struct FMargin Margin; // 0x700(0x10)
	struct FLinearColor ColorAndOpacity; // 0x710(0x10)
	struct FText KeySelectionText; // 0x720(0x18)
	struct FText NoKeySpecifiedText; // 0x738(0x18)
	bool bAllowModifierKeys; // 0x750(0x1)
	bool bAllowGamepadKeys; // 0x751(0x1)
	uint8_t Pad_0x752[0x6]; // 0x752(0x6)
	struct TArray<struct FKey> EscapeKeys; // 0x758(0x10)
	struct FScriptMulticastDelegate OnKeySelected; // 0x768(0x10)
	struct FScriptMulticastDelegate OnIsSelectingKeyChanged; // 0x778(0x10)
	uint8_t Pad_0x788[0x10]; // 0x788(0x10)


	// Object: Function UMG.InputKeySelector.SetTextBlockVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1374
	// Params: [ Num(1) Size(0x1) ]
	void SetTextBlockVisibility(uint8_t InVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3753C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.InputKeySelector.SetSelectedKey
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105da12b8
	// Params: [ Num(1) Size(0x20) ]
	void SetSelectedKey(struct FInputChord& InSelectedKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36C58
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3753C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.InputKeySelector.SetNoKeySpecifiedText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da11f8
	// Params: [ Num(1) Size(0x18) ]
	void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D36D48
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D36C58
	// [Call #14] RVA: 0x1021C8F20
	// [Call #15] RVA: 0x1021C8F20
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105D3753C
	// [Call #20] RVA: 0x10519022C

	// Object: Function UMG.InputKeySelector.SetKeySelectionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1138
	// Params: [ Num(1) Size(0x18) ]
	void SetKeySelectionText(struct FText InKeySelectionText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D36CD0
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x105D36D48
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x105D36C58
	// [Call #24] RVA: 0x1021C8F20
	// [Call #25] RVA: 0x1021C8F20
	// [Call #26] RVA: 0x106C8459C

	// Object: Function UMG.InputKeySelector.SetAllowModifierKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da10b4
	// Params: [ Num(1) Size(0x1) ]
	void SetAllowModifierKeys(bool bInAllowModifierKeys);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36DC0
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D36CD0
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104F0F380
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104F0F458
	// [Call #18] RVA: 0x105D36D48
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function UMG.InputKeySelector.SetAllowGamepadKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1030
	// Params: [ Num(1) Size(0x1) ]
	void SetAllowGamepadKeys(bool bInAllowGamepadKeys);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D36DD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D36DC0
	// [Call #7] RVA: 0x104F0F380
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F458
	// [Call #11] RVA: 0x105D36CD0
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x105D36D48
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8

	// Object: DelegateFunction UMG.InputKeySelector.OnKeySelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x20) ]
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.InputKeySelector.OnIsSelectingKeyChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnIsSelectingKeyChanged__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.InputKeySelector.GetIsSelectingKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da0ffc
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsSelectingKey();
	// [Call #1] RVA: 0x105D36DE8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D36DD4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D36DC0
	// [Call #8] RVA: 0x104F0F380
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104F0F458
	// [Call #12] RVA: 0x105D36CD0
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104F0F380
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class UMG.Int32Binding
// Size: 0x48 (Inherited: 0x48)
struct UInt32Binding : UPropertyBinding
{

	// Object: Function UMG.Int32Binding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105da16e0
	// Params: [ Num(1) Size(0x4) ]
	int GetValue();
	// [Call #1] RVA: 0x105D2556C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105DA1BE4
	// [Call #6] RVA: 0x105D379DC
	// [Call #7] RVA: 0x105D37A1C
	// [Call #8] RVA: 0x10516D168
};

// Object: Class UMG.TableViewBase
// Size: 0x100 (Inherited: 0x100)
struct UTableViewBase : UWidget
{
};

// Object: Class UMG.ListView
// Size: 0x140 (Inherited: 0x100)
struct UListView : UTableViewBase
{
	float ItemHeight; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
	struct TArray<struct UObject*> Items; // 0x108(0x10)
	enum class ESelectionMode SelectionMode; // 0x118(0x1)
	uint8_t Pad_0x119[0x7]; // 0x119(0x7)
	DelegateProperty OnGenerateRowEvent; // 0x120(0x10)
	uint8_t Pad_0x130[0x10]; // 0x130(0x10)
};

// Object: Class UMG.MenuAnchor
// Size: 0x158 (Inherited: 0x118)
struct UMenuAnchor : UContentWidget
{
	struct UUserWidget* MenuClass; // 0x118(0x8)
	DelegateProperty OnGetMenuContentEvent; // 0x120(0x10)
	enum class EMenuPlacement Placement; // 0x130(0x1)
	bool ShouldDeferPaintingAfterWindowContent; // 0x131(0x1)
	bool UseApplicationMenuStack; // 0x132(0x1)
	uint8_t Pad_0x133[0x5]; // 0x133(0x5)
	struct FScriptMulticastDelegate OnMenuOpenChanged; // 0x138(0x10)
	uint8_t Pad_0x148[0x10]; // 0x148(0x10)


	// Object: Function UMG.MenuAnchor.ToggleOpen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1f78
	// Params: [ Num(1) Size(0x1) ]
	void ToggleOpen(bool bFocusOnOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D38AE0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.MenuAnchor.ShouldOpenDueToClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da1f44
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldOpenDueToClick();
	// [Call #1] RVA: 0x105D38BB8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D38AE0
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.MenuAnchor.Open
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1ec0
	// Params: [ Num(1) Size(0x1) ]
	void Open(bool bFocusMenu);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D38B30
	// [Call #4] RVA: 0x105D38BB8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D38AE0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.MenuAnchor.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da1e8c
	// Params: [ Num(1) Size(0x1) ]
	bool IsOpen();
	// [Call #1] RVA: 0x105D38BA8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D38B30
	// [Call #5] RVA: 0x105D38BB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D38AE0
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.MenuAnchor.HasOpenSubMenus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da1e58
	// Params: [ Num(1) Size(0x1) ]
	bool HasOpenSubMenus();
	// [Call #1] RVA: 0x105D38BF0
	// [Call #2] RVA: 0x105D38BA8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D38B30
	// [Call #6] RVA: 0x105D38BB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D38AE0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function UMG.MenuAnchor.GetMenuPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da1e24
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetMenuPosition();
	// [Call #1] RVA: 0x105D38BC8
	// [Call #2] RVA: 0x105D38BF0
	// [Call #3] RVA: 0x105D38BA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D38B30
	// [Call #7] RVA: 0x105D38BB8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D38AE0
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function UMG.MenuAnchor.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da1e10
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x105D38BC8
	// [Call #2] RVA: 0x105D38BF0
	// [Call #3] RVA: 0x105D38BA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D38B30
	// [Call #7] RVA: 0x105D38BB8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D38AE0
	// [Call #11] RVA: 0x10519022C
};

// Object: Class UMG.MouseCursorBinding
// Size: 0x48 (Inherited: 0x48)
struct UMouseCursorBinding : UPropertyBinding
{

	// Object: Function UMG.MouseCursorBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105da2348
	// Params: [ Num(1) Size(0x1) ]
	enum class EMouseCursor GetValue();
	// [Call #1] RVA: 0x105D256E8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class UMG.MovieScene2DTransformSection
// Size: 0x3C8 (Inherited: 0xB0)
struct UMovieScene2DTransformSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve Translation[0x2]; // 0xB8(0xE0)
	struct FRichCurve Rotation; // 0x198(0x70)
	struct FRichCurve Scale[0x2]; // 0x208(0xE0)
	struct FRichCurve Shear[0x2]; // 0x2E8(0xE0)
};

// Object: Class UMG.MovieScene2DTransformTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieScene2DTransformTrack : UMovieScenePropertyTrack
{
};

// Object: Class UMG.MovieSceneMarginSection
// Size: 0x278 (Inherited: 0xB0)
struct UMovieSceneMarginSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve TopCurve; // 0xB8(0x70)
	struct FRichCurve LeftCurve; // 0x128(0x70)
	struct FRichCurve RightCurve; // 0x198(0x70)
	struct FRichCurve BottomCurve; // 0x208(0x70)
};

// Object: Class UMG.MovieSceneMarginTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneMarginTrack : UMovieScenePropertyTrack
{
};

// Object: Class UMG.MovieSceneWAnimTimeSection
// Size: 0x278 (Inherited: 0xB0)
struct UMovieSceneWAnimTimeSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FRichCurve PlayTimeCurve_1; // 0xB8(0x70)
	struct FRichCurve PlayTimeCurve_2; // 0x128(0x70)
	struct FRichCurve PlayTimeCurve_3; // 0x198(0x70)
	struct FRichCurve PlayTimeCurve_4; // 0x208(0x70)
};

// Object: Class UMG.MovieSceneWAnimTimeTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneWAnimTimeTrack : UMovieScenePropertyTrack
{
};

// Object: Class UMG.MovieSceneWidgetMaterialTrack
// Size: 0x80 (Inherited: 0x68)
struct UMovieSceneWidgetMaterialTrack : UMovieSceneMaterialTrack
{
	struct TArray<struct FName> BrushPropertyNamePath; // 0x68(0x10)
	struct FName TrackName; // 0x78(0x8)
};

// Object: Class UMG.MultiLineEditableText
// Size: 0x468 (Inherited: 0x128)
struct UMultiLineEditableText : UTextLayoutWidget
{
	struct FText Text; // 0x128(0x18)
	struct FText hintText; // 0x140(0x18)
	DelegateProperty HintTextDelegate; // 0x158(0x10)
	struct TArray<struct FSlateColor> ColorSwitchList; // 0x168(0x10)
	int ActiveColorIndex; // 0x178(0x4)
	uint8_t Pad_0x17C[0x4]; // 0x17C(0x4)
	struct FTextBlockStyle WidgetStyle; // 0x180(0x250)
	bool bIsReadOnly; // 0x3D0(0x1)
	uint8_t Pad_0x3D1[0x7]; // 0x3D1(0x7)
	struct FSlateFontInfo Font; // 0x3D8(0x58)
	bool AllowContextMenu; // 0x430(0x1)
	uint8_t Pad_0x431[0x7]; // 0x431(0x7)
	struct FScriptMulticastDelegate OnTextChanged; // 0x438(0x10)
	struct FScriptMulticastDelegate OnTextCommitted; // 0x448(0x10)
	uint8_t Pad_0x458[0x10]; // 0x458(0x10)


	// Object: Function UMG.MultiLineEditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da32fc
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D398B8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da3278
	// Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D39A08
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D398B8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da31b8
	// Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D399A0
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D39A08
	// [Call #14] RVA: 0x104F0F380
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104F0F458
	// [Call #18] RVA: 0x105D398B8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableText.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da30ac
	// Params: [ Num(1) Size(0x58) ]
	void SetFont(struct FSlateFontInfo InNewFont);
	// [Call #1] RVA: 0x1051E3694
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D39934
	// [Call #5] RVA: 0x10206BEBC
	// [Call #6] RVA: 0x10206BEBC
	// [Call #7] RVA: 0x10206BEBC
	// [Call #8] RVA: 0x10206BEBC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104F0F458
	// [Call #14] RVA: 0x105D399A0
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x105D39A08

	// Object: Function UMG.MultiLineEditableText.SetActiveColorIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da3030
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveColorIndex(int InIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D39A74
	// [Call #4] RVA: 0x1051E3694
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D39934
	// [Call #8] RVA: 0x10206BEBC
	// [Call #9] RVA: 0x10206BEBC
	// [Call #10] RVA: 0x10206BEBC
	// [Call #11] RVA: 0x10206BEBC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x104F0F380
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104F0F458
	// [Call #17] RVA: 0x105D399A0
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x106C8459C

	// Object: Function UMG.MultiLineEditableText.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da301c
	// Params: [ Num(0) Size(0x0) ]
	void ScrollToEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D39A74
	// [Call #4] RVA: 0x1051E3694
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D39934
	// [Call #8] RVA: 0x10206BEBC
	// [Call #9] RVA: 0x10206BEBC
	// [Call #10] RVA: 0x10206BEBC
	// [Call #11] RVA: 0x10206BEBC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x104F0F380
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104F0F458
	// [Call #17] RVA: 0x105D399A0
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8

	// Object: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x19) ]
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.MultiLineEditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da2fb8
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x105D3989C
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D39A74
	// [Call #9] RVA: 0x1051E3694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D39934
	// [Call #13] RVA: 0x10206BEBC
	// [Call #14] RVA: 0x10206BEBC
	// [Call #15] RVA: 0x10206BEBC
	// [Call #16] RVA: 0x10206BEBC
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104F0F380
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class UMG.MultiLineEditableTextBox
// Size: 0xEE8 (Inherited: 0x128)
struct UMultiLineEditableTextBox : UTextLayoutWidget
{
	struct FText Text; // 0x128(0x18)
	struct FText hintText; // 0x140(0x18)
	DelegateProperty HintTextDelegate; // 0x158(0x10)
	struct FEditableTextBoxStyle WidgetStyle; // 0x168(0xA68)
	struct FTextBlockStyle TextStyle; // 0xBD0(0x250)
	bool bIsReadOnly; // 0xE20(0x1)
	bool AllowContextMenu; // 0xE21(0x1)
	uint8_t Pad_0xE22[0x6]; // 0xE22(0x6)
	struct USlateWidgetStyleAsset* Style; // 0xE28(0x8)
	struct FSlateFontInfo Font; // 0xE30(0x58)
	struct FLinearColor ForegroundColor; // 0xE88(0x10)
	struct FLinearColor BackgroundColor; // 0xE98(0x10)
	struct FLinearColor ReadOnlyForegroundColor; // 0xEA8(0x10)
	struct FScriptMulticastDelegate OnTextChanged; // 0xEB8(0x10)
	struct FScriptMulticastDelegate OnTextCommitted; // 0xEC8(0x10)
	uint8_t Pad_0xED8[0x10]; // 0xED8(0x10)


	// Object: Function UMG.MultiLineEditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da39cc
	// Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D3A974
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da3948
	// Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3A9EC
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104F0F458
	// [Call #8] RVA: 0x105D3A974
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da3888
	// Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InText);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D3A8E8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D3A9EC
	// [Call #14] RVA: 0x104F0F380
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104F0F458
	// [Call #18] RVA: 0x105D3A974
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10519022C

	// Object: Function UMG.MultiLineEditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da37c8
	// Params: [ Num(1) Size(0x18) ]
	void SetError(struct FText InError);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F458
	// [Call #5] RVA: 0x105D3A9DC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104F0F380
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x105D3A8E8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x105D3A9EC
	// [Call #24] RVA: 0x104F0F380
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x19) ]
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.MultiLineEditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105da3764
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetText();
	// [Call #1] RVA: 0x105D3A950
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104F0F380
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104F0F458
	// [Call #10] RVA: 0x105D3A9DC
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104F0F380
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104F0F458
	// [Call #20] RVA: 0x105D3A8E8
	// [Call #21] RVA: 0x101FBDBE8
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4
	// [Call #28] RVA: 0x105D3A9EC
};

// Object: Class UMG.NamedSlot
// Size: 0x128 (Inherited: 0x118)
struct UNamedSlot : UContentWidget
{
	uint8_t Pad_0x118[0x10]; // 0x118(0x10)
};

// Object: Class UMG.NamedSlotInterface
// Size: 0x28 (Inherited: 0x28)
struct INamedSlotInterface : IInterface
{
};

// Object: Class UMG.NativeWidgetHost
// Size: 0x110 (Inherited: 0x100)
struct UNativeWidgetHost : UWidget
{
	uint8_t Pad_0x100[0x10]; // 0x100(0x10)
};

// Object: Class UMG.Overlay
// Size: 0x128 (Inherited: 0x118)
struct UOverlay : UPanelWidget
{
	uint8_t Pad_0x118[0x10]; // 0x118(0x10)


	// Object: Function UMG.Overlay.AddChildToOverlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da5cf0
	// Params: [ Num(2) Size(0x10) ]
	struct UOverlaySlot* AddChildToOverlay(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B32C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105DA61F0
};

// Object: Class UMG.OverlaySlot
// Size: 0x60 (Inherited: 0x40)
struct UOverlaySlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0xE]; // 0x52(0xE)


	// Object: Function UMG.OverlaySlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6020
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B85C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function UMG.OverlaySlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da5fa0
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B7D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3B85C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function UMG.OverlaySlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da5f24
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3B848
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3B7D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3B85C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.ProgressBar
// Size: 0x3A0 (Inherited: 0x100)
struct UProgressBar : UWidget
{
	struct FProgressBarStyle WidgetStyle; // 0x100(0x230)
	struct USlateWidgetStyleAsset* Style; // 0x330(0x8)
	struct USlateBrushAsset* BackgroundImage; // 0x338(0x8)
	struct USlateBrushAsset* FillImage; // 0x340(0x8)
	struct USlateBrushAsset* MarqueeImage; // 0x348(0x8)
	float percent; // 0x350(0x4)
	enum class EProgressBarFillType BarFillType; // 0x354(0x1)
	bool bIsMarquee; // 0x355(0x1)
	uint8_t Pad_0x356[0x2]; // 0x356(0x2)
	struct FVector2D BorderPadding; // 0x358(0x8)
	DelegateProperty PercentDelegate; // 0x360(0x10)
	struct FLinearColor FillColorAndOpacity; // 0x370(0x10)
	DelegateProperty FillColorAndOpacityDelegate; // 0x380(0x10)
	uint8_t Pad_0x390[0x10]; // 0x390(0x10)


	// Object: Function UMG.ProgressBar.SetPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6cc8
	// Params: [ Num(1) Size(0x4) ]
	void SetPercent(float InPercent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3C910
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.ProgressBar.SetIsMarquee
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da6c44
	// Params: [ Num(1) Size(0x1) ]
	void SetIsMarquee(bool InbIsMarquee);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3C810
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3C910
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.ProgressBar.SetFillColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105da6bc8
	// Params: [ Num(1) Size(0x10) ]
	void SetFillColorAndOpacity(struct FLinearColor InColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3C890
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3C810
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3C910
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.RichTextBlock
// Size: 0x428 (Inherited: 0x128)
struct URichTextBlock : UTextLayoutWidget
{
	struct FText Text; // 0x128(0x18)
	DelegateProperty TextDelegate; // 0x140(0x10)
	struct FSlateFontInfo Font; // 0x150(0x58)
	struct FLinearColor Color; // 0x1A8(0x10)
	struct TArray<struct URichTextBlockDecorator*> Decorators; // 0x1B8(0x10)
	uint8_t Pad_0x1C8[0x260]; // 0x1C8(0x260)
};

// Object: Class UMG.RichTextBlockDecorator
// Size: 0x30 (Inherited: 0x28)
struct URichTextBlockDecorator : UObject
{
	bool bReveal; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	int RevealedIndex; // 0x2C(0x4)
};

// Object: Class UMG.SafeZone
// Size: 0x128 (Inherited: 0x118)
struct USafeZone : UContentWidget
{
	bool PadLeft; // 0x111(0x1)
	bool PadRight; // 0x112(0x1)
	bool PadTop; // 0x113(0x1)
	bool PadBottom; // 0x114(0x1)
	uint8_t Pad_0x11C[0xC]; // 0x11C(0xC)


	// Object: Function UMG.SafeZone.SetSidesToPad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da761c
	// Params: [ Num(4) Size(0x4) ]
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3E64C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class UMG.SafeZoneSlot
// Size: 0x68 (Inherited: 0x40)
struct USafeZoneSlot : UPanelSlot
{
	bool bIsTitleSafe; // 0x40(0x1)
	uint8_t Pad_0x41[0x3]; // 0x41(0x3)
	struct FMargin SafeAreaScale; // 0x44(0x10)
	enum class EHorizontalAlignment HAlign; // 0x54(0x1)
	enum class EVerticalAlignment VAlign; // 0x55(0x1)
	uint8_t Pad_0x56[0x2]; // 0x56(0x2)
	struct FMargin Padding; // 0x58(0x10)
};

// Object: Class UMG.ScaleBox
// Size: 0x130 (Inherited: 0x118)
struct UScaleBox : UContentWidget
{
	enum class EStretch Stretch; // 0x111(0x1)
	enum class EStretchDirection StretchDirection; // 0x112(0x1)
	float UserSpecifiedScale; // 0x114(0x4)
	float UserSpecifiedScaleBias; // 0x118(0x4)
	bool IgnoreInheritedScale; // 0x11C(0x1)
	bool bFixQuivering; // 0x11D(0x1)
	bool bSingleLayoutPass; // 0x11E(0x1)
	uint8_t Pad_0x125[0xB]; // 0x125(0xB)


	// Object: Function UMG.ScaleBox.SetUserSpecifiedScaleBias
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7cc4
	// Params: [ Num(1) Size(0x4) ]
	void SetUserSpecifiedScaleBias(float InUserSpecifiedScaleBias);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EFAC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.ScaleBox.SetUserSpecifiedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7c48
	// Params: [ Num(1) Size(0x4) ]
	void SetUserSpecifiedScale(float InUserSpecifiedScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EF98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3EFAC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.ScaleBox.SetStretchDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7bcc
	// Params: [ Num(1) Size(0x1) ]
	void SetStretchDirection(enum class EStretchDirection InStretchDirection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EF84
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3EF98
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3EFAC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.ScaleBox.SetStretch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7b50
	// Params: [ Num(1) Size(0x1) ]
	void SetStretch(enum class EStretch InStretch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EF70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3EF84
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3EF98
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D3EFAC
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.ScaleBox.SetIgnoreInheritedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7acc
	// Params: [ Num(1) Size(0x1) ]
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EFD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3EF70
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3EF84
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D3EF98
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.ScaleBox.SetFixQuiver
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da7a48
	// Params: [ Num(1) Size(0x1) ]
	void SetFixQuiver(bool InFixQuiver);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3EFC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3EFD4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3EF70
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D3EF84
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class UMG.ScaleBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct UScaleBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.ScaleBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8130
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3F2C4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105DA84DC

	// Object: Function UMG.ScaleBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da80b0
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3F20C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3F2C4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.ScaleBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8034
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D3F22C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D3F20C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D3F2C4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.ScrollBar
// Size: 0x7A8 (Inherited: 0x100)
struct UScrollBar : UWidget
{
	struct FScrollBarStyle WidgetStyle; // 0x100(0x680)
	struct USlateWidgetStyleAsset* Style; // 0x780(0x8)
	bool bAlwaysShowScrollbar; // 0x788(0x1)
	enum class EOrientation Orientation; // 0x789(0x1)
	uint8_t Pad_0x78A[0x2]; // 0x78A(0x2)
	struct FVector2D Thickness; // 0x78C(0x8)
	uint8_t Pad_0x794[0x14]; // 0x794(0x14)


	// Object: Function UMG.ScrollBar.SetState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da8394
	// Params: [ Num(2) Size(0x8) ]
	void SetState(float InOffsetFraction, float InThumbSizeFraction);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D3F6F8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class UMG.ScrollBoxSlot
// Size: 0x60 (Inherited: 0x40)
struct UScrollBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	uint8_t Pad_0x51[0xF]; // 0x51(0xF)


	// Object: Function UMG.ScrollBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da93fc
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40664
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870

	// Object: Function UMG.ScrollBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9380
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D406DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40664
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class UMG.ShareWidgetRT
// Size: 0x90 (Inherited: 0x28)
struct UShareWidgetRT : UObject
{
	struct UTextureRenderTarget2D* RenderTarget; // 0x28(0x8)
	struct TSet<struct UObject*> AllSharedWidget; // 0x30(0x50)
	uint8_t Pad_0x80[0x10]; // 0x80(0x10)
};

// Object: Class UMG.ShareWidgetRTManager
// Size: 0x500 (Inherited: 0x4B0)
struct AShareWidgetRTManager : AActor
{
	struct TMap<struct UObject*, struct UShareWidgetRT*> SharedWidgetRTMap; // 0x4B0(0x50)
};

// Object: Class UMG.SizeBox
// Size: 0x140 (Inherited: 0x118)
struct USizeBox : UContentWidget
{
	uint8_t bOverride_WidthOverride : 1; // 0x111(0x1), Mask(0x1)
	uint8_t bOverride_HeightOverride : 1; // 0x111(0x1), Mask(0x2)
	uint8_t bOverride_MinDesiredWidth : 1; // 0x111(0x1), Mask(0x4)
	uint8_t bOverride_MinDesiredHeight : 1; // 0x111(0x1), Mask(0x8)
	uint8_t bOverride_MaxDesiredWidth : 1; // 0x111(0x1), Mask(0x10)
	uint8_t bOverride_MaxDesiredHeight : 1; // 0x111(0x1), Mask(0x20)
	uint8_t bOverride_MaxAspectRatio : 1; // 0x111(0x1), Mask(0x40)
	uint8_t bDontPaintWhenChildEmpty : 1; // 0x111(0x1), Mask(0x80)
	float WidthOverride; // 0x114(0x4)
	float HeightOverride; // 0x118(0x4)
	float MinDesiredWidth; // 0x11C(0x4)
	float MinDesiredHeight; // 0x120(0x4)
	float MaxDesiredWidth; // 0x124(0x4)
	float MaxDesiredHeight; // 0x128(0x4)
	float MaxAspectRatio; // 0x12C(0x4)
	uint8_t Pad_0x135[0xB]; // 0x135(0xB)


	// Object: Function UMG.SizeBox.SetWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9c4c
	// Params: [ Num(1) Size(0x4) ]
	void SetWidthOverride(float InWidthOverride);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40E44
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.SizeBox.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9bd0
	// Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D41034
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40E44
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.SizeBox.SetMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9b54
	// Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredHeight(float InMinDesiredHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4112C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D41034
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D40E44
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.SizeBox.SetMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9ad8
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxDesiredWidth(float InMaxDesiredWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D41224
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4112C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D41034
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D40E44
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.SizeBox.SetMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9a5c
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxDesiredHeight(float InMaxDesiredHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4131C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D41224
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4112C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D41034
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.SizeBox.SetMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da99e0
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxAspectRatio(float InMaxAspectRatio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D41414
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4131C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D41224
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4112C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.SizeBox.SetHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9964
	// Params: [ Num(1) Size(0x4) ]
	void SetHeightOverride(float InHeightOverride);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D40F3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D41414
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4131C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D41224
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.SizeBox.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da98e0
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4150C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D40F3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D41414
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4131C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.SizeBox.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da98ac
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4131C

	// Object: Function UMG.SizeBox.ClearWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9898
	// Params: [ Num(0) Size(0x0) ]
	void ClearWidthOverride();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4131C

	// Object: Function UMG.SizeBox.ClearMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9884
	// Params: [ Num(0) Size(0x0) ]
	void ClearMinDesiredWidth();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4131C

	// Object: Function UMG.SizeBox.ClearMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9870
	// Params: [ Num(0) Size(0x0) ]
	void ClearMinDesiredHeight();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D4131C

	// Object: Function UMG.SizeBox.ClearMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da985c
	// Params: [ Num(0) Size(0x0) ]
	void ClearMaxDesiredWidth();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function UMG.SizeBox.ClearMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9848
	// Params: [ Num(0) Size(0x0) ]
	void ClearMaxDesiredHeight();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
	// [Call #11] RVA: 0x10516D168

	// Object: Function UMG.SizeBox.ClearMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9834
	// Params: [ Num(0) Size(0x0) ]
	void ClearMaxAspectRatio();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414

	// Object: Function UMG.SizeBox.ClearHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105da9820
	// Params: [ Num(0) Size(0x0) ]
	void ClearHeightOverride();
	// [Call #1] RVA: 0x105D41534
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D4150C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D40F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D41414
};

// Object: Class UMG.SizeBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct USizeBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.SizeBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daa3b8
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D41990
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105DAB4F8

	// Object: Function UMG.SizeBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daa338
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D41810
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D41990
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.SizeBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daa2bc
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D418F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D41810
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D41990
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.SlateBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct USlateBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x105dab028
	// Params: [ Num(4) Size(0x50) ]
	void ScreenToWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1051EB7DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D860A0
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToWidgetAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x105daaf34
	// Params: [ Num(3) Size(0x18) ]
	void ScreenToWidgetAbsolute(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D860F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1051EB7DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D860A0

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x105daae40
	// Params: [ Num(3) Size(0x18) ]
	void ScreenToViewport(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D861A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D860F4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1051EB7DC
	// [Call #18] RVA: 0x10516D168

	// Object: Function UMG.SlateBlueprintLibrary.LocalToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daacac
	// Params: [ Num(5) Size(0x58) ]
	void LocalToViewport(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D LocalCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1051EB7DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D85F2C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function UMG.SlateBlueprintLibrary.LocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daabdc
	// Params: [ Num(3) Size(0x48) ]
	struct FVector2D LocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalCoordinate);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D85EB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1051EB7DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D85F2C

	// Object: Function UMG.SlateBlueprintLibrary.IsUnderLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daaafc
	// Params: [ Num(3) Size(0x41) ]
	bool IsUnderLocation(struct FGeometry& Geometry, struct FVector2D& AbsoluteCoordinate);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D85E1C
	// [Call #7] RVA: 0x1051EB7DC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D85EB4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1051EB7DC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.SlateBlueprintLibrary.GetLocalSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daaa6c
	// Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetLocalSize(struct FGeometry& Geometry);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D85EDC
	// [Call #5] RVA: 0x1051EB7DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D85E1C
	// [Call #11] RVA: 0x1051EB7DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D85EB4

	// Object: Function UMG.SlateBlueprintLibrary.GetAbsoluteSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daa9dc
	// Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D85EE4
	// [Call #5] RVA: 0x1051EB7DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D85EDC
	// [Call #9] RVA: 0x1051EB7DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D85E1C
	// [Call #15] RVA: 0x1051EB7DC
	// [Call #16] RVA: 0x10516D168

	// Object: Function UMG.SlateBlueprintLibrary.GetAbsolutePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daa94c
	// Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetAbsolutePosition(struct FGeometry& Geometry);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D85EF0
	// [Call #5] RVA: 0x1051EB7DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D85EE4
	// [Call #9] RVA: 0x1051EB7DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D85EDC
	// [Call #13] RVA: 0x1051EB7DC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.SlateBlueprintLibrary.EqualEqual_SlateBrush
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daa828
	// Params: [ Num(3) Size(0x171) ]
	bool EqualEqual_SlateBrush(struct FSlateBrush& A, struct FSlateBrush& B);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FE9E54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D85F28
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x101FEA144
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1051EB7DC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D85EF0
	// [Call #17] RVA: 0x1051EB7DC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x105D85EE4

	// Object: Function UMG.SlateBlueprintLibrary.AbsoluteToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daa6ec
	// Params: [ Num(4) Size(0x20) ]
	void AbsoluteToViewport(struct UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D85F80
	// [Call #10] RVA: 0x101FE9E54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FE9E54
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D85F28
	// [Call #17] RVA: 0x101FEA144
	// [Call #18] RVA: 0x101FEA144
	// [Call #19] RVA: 0x101FEA144
	// [Call #20] RVA: 0x101FEA144

	// Object: Function UMG.SlateBlueprintLibrary.AbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105daa61c
	// Params: [ Num(3) Size(0x48) ]
	struct FVector2D AbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteCoordinate);
	// [Call #1] RVA: 0x1051EB7DC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D85E80
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D85F80
	// [Call #16] RVA: 0x101FE9E54
	// [Call #17] RVA: 0x10516D168
};

// Object: Class UMG.SlateDataSheet
// Size: 0x430 (Inherited: 0x28)
struct USlateDataSheet : UObject
{
	struct UTexture2D* DataTexture; // 0x28(0x8)
	uint8_t Pad_0x30[0x400]; // 0x30(0x400)
};

// Object: Class UMG.SlateVectorArtData
// Size: 0x60 (Inherited: 0x28)
struct USlateVectorArtData : UObject
{
	struct TArray<struct FSlateMeshVertex> VertexData; // 0x28(0x10)
	struct TArray<uint32_t> IndexData; // 0x38(0x10)
	struct UMaterialInterface* Material; // 0x48(0x8)
	struct FVector2D ExtentMin; // 0x50(0x8)
	struct FVector2D ExtentMax; // 0x58(0x8)
};

// Object: Class UMG.Spacer
// Size: 0x118 (Inherited: 0x100)
struct USpacer : UWidget
{
	struct FVector2D Size; // 0x100(0x8)
	uint8_t Pad_0x108[0x10]; // 0x108(0x10)


	// Object: Function UMG.Spacer.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dadde0
	// Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FVector2D InSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D42564
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519077C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class UMG.SpinBox
// Size: 0x5F8 (Inherited: 0x100)
struct USpinBox : UWidget
{
	float Value; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
	DelegateProperty ValueDelegate; // 0x108(0x10)
	struct FSpinBoxStyle WidgetStyle; // 0x118(0x3D8)
	struct USlateWidgetStyleAsset* Style; // 0x4F0(0x8)
	float Delta; // 0x4F8(0x4)
	float SliderExponent; // 0x4FC(0x4)
	struct FSlateFontInfo Font; // 0x500(0x58)
	enum class ETextJustify Justification; // 0x558(0x1)
	uint8_t Pad_0x559[0x3]; // 0x559(0x3)
	float MinDesiredWidth; // 0x55C(0x4)
	bool ClearKeyboardFocusOnCommit; // 0x560(0x1)
	bool SelectAllTextOnCommit; // 0x561(0x1)
	uint8_t Pad_0x562[0x6]; // 0x562(0x6)
	struct FSlateColor ForegroundColor; // 0x568(0x28)
	struct FScriptMulticastDelegate OnValueChanged; // 0x590(0x10)
	struct FScriptMulticastDelegate OnValueCommitted; // 0x5A0(0x10)
	struct FScriptMulticastDelegate OnBeginSliderMovement; // 0x5B0(0x10)
	struct FScriptMulticastDelegate OnEndSliderMovement; // 0x5C0(0x10)
	uint8_t bOverride_MinValue : 1; // 0x5D0(0x1), Mask(0x1)
	uint8_t bOverride_MaxValue : 1; // 0x5D0(0x1), Mask(0x2)
	uint8_t bOverride_MinSliderValue : 1; // 0x5D0(0x1), Mask(0x4)
	uint8_t bOverride_MaxSliderValue : 1; // 0x5D0(0x1), Mask(0x8)
	uint8_t BitPad_0x5D0_4 : 4; // 0x5D0(0x1)
	uint8_t Pad_0x5D1[0x3]; // 0x5D1(0x3)
	float MinValue; // 0x5D4(0x4)
	float MaxValue; // 0x5D8(0x4)
	float MinSliderValue; // 0x5DC(0x4)
	float MaxSliderValue; // 0x5E0(0x4)
	uint8_t Pad_0x5E4[0x14]; // 0x5E4(0x14)


	// Object: Function UMG.SpinBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae554
	// Params: [ Num(1) Size(0x4) ]
	void SetValue(float NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D43BB4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.SpinBox.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae4d8
	// Params: [ Num(1) Size(0x4) ]
	void SetMinValue(float NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D43740
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D43BB4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.SpinBox.SetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae45c
	// Params: [ Num(1) Size(0x4) ]
	void SetMinSliderValue(float NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D43900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D43740
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D43BB4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.SpinBox.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae3e0
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxValue(float NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D43820
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D43900
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D43740
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D43BB4
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.SpinBox.SetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae364
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxSliderValue(float NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D439E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D43820
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D43900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D43740
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.SpinBox.SetForegroundColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae264
	// Params: [ Num(1) Size(0x28) ]
	void SetForegroundColor(struct FSlateColor InForegroundColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D43D20
	// [Call #4] RVA: 0x101FE9F60
	// [Call #5] RVA: 0x101FE9F60
	// [Call #6] RVA: 0x101FE9F60
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D439E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D43820
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxValueCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x5) ]
	void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxValueChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxBeginSliderMovement__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnSpinBoxBeginSliderMovement__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UMG.SpinBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dae230
	// Params: [ Num(1) Size(0x4) ]
	float GetValue();
	// [Call #1] RVA: 0x105D43B3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D43D20
	// [Call #5] RVA: 0x101FE9F60
	// [Call #6] RVA: 0x101FE9F60
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D439E0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D43820

	// Object: Function UMG.SpinBox.GetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dae1fc
	// Params: [ Num(1) Size(0x4) ]
	float GetMinValue();
	// [Call #1] RVA: 0x105D43C20
	// [Call #2] RVA: 0x105D43B3C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D43D20
	// [Call #6] RVA: 0x101FE9F60
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D439E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D43820

	// Object: Function UMG.SpinBox.GetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dae1c8
	// Params: [ Num(1) Size(0x4) ]
	float GetMinSliderValue();
	// [Call #1] RVA: 0x105D43CC8
	// [Call #2] RVA: 0x105D43C20
	// [Call #3] RVA: 0x105D43B3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D43D20
	// [Call #7] RVA: 0x101FE9F60
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D439E0
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.SpinBox.GetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dae194
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxValue();
	// [Call #1] RVA: 0x105D43C74
	// [Call #2] RVA: 0x105D43CC8
	// [Call #3] RVA: 0x105D43C20
	// [Call #4] RVA: 0x105D43B3C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D43D20
	// [Call #8] RVA: 0x101FE9F60
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D439E0

	// Object: Function UMG.SpinBox.GetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dae160
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxSliderValue();
	// [Call #1] RVA: 0x105D43CF4
	// [Call #2] RVA: 0x105D43C74
	// [Call #3] RVA: 0x105D43CC8
	// [Call #4] RVA: 0x105D43C20
	// [Call #5] RVA: 0x105D43B3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D43D20
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function UMG.SpinBox.ClearMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae14c
	// Params: [ Num(0) Size(0x0) ]
	void ClearMinValue();
	// [Call #1] RVA: 0x105D43CF4
	// [Call #2] RVA: 0x105D43C74
	// [Call #3] RVA: 0x105D43CC8
	// [Call #4] RVA: 0x105D43C20
	// [Call #5] RVA: 0x105D43B3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D43D20
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.SpinBox.ClearMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae138
	// Params: [ Num(0) Size(0x0) ]
	void ClearMinSliderValue();
	// [Call #1] RVA: 0x105D43CF4
	// [Call #2] RVA: 0x105D43C74
	// [Call #3] RVA: 0x105D43CC8
	// [Call #4] RVA: 0x105D43C20
	// [Call #5] RVA: 0x105D43B3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D43D20
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x106C8459C

	// Object: Function UMG.SpinBox.ClearMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae124
	// Params: [ Num(0) Size(0x0) ]
	void ClearMaxValue();
	// [Call #1] RVA: 0x105D43CF4
	// [Call #2] RVA: 0x105D43C74
	// [Call #3] RVA: 0x105D43CC8
	// [Call #4] RVA: 0x105D43C20
	// [Call #5] RVA: 0x105D43B3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D43D20
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x106C8459C

	// Object: Function UMG.SpinBox.ClearMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dae110
	// Params: [ Num(0) Size(0x0) ]
	void ClearMaxSliderValue();
	// [Call #1] RVA: 0x105D43CF4
	// [Call #2] RVA: 0x105D43C74
	// [Call #3] RVA: 0x105D43CC8
	// [Call #4] RVA: 0x105D43C20
	// [Call #5] RVA: 0x105D43B3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D43D20
	// [Call #9] RVA: 0x101FE9F60
	// [Call #10] RVA: 0x101FE9F60
	// [Call #11] RVA: 0x101FE9F60
	// [Call #12] RVA: 0x101FE9F60
	// [Call #13] RVA: 0x106C8459C
};

// Object: Class UMG.StaticMeshWidget
// Size: 0x120 (Inherited: 0x100)
struct UStaticMeshWidget : UWidget
{
	struct USlateVectorArtData* StaticMeshAsset; // 0x100(0x8)
	struct FVector2D MeshScale; // 0x108(0x8)
	uint8_t Pad_0x110[0x10]; // 0x110(0x10)
};

// Object: Class UMG.TextBinding
// Size: 0x50 (Inherited: 0x48)
struct UTextBinding : UPropertyBinding
{
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function UMG.TextBinding.GetTextValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105daeda4
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetTextValue();
	// [Call #1] RVA: 0x105D259AC
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105DAFB9C
	// [Call #11] RVA: 0x105D45734
	// [Call #12] RVA: 0x104F0F4CC
	// [Call #13] RVA: 0x101FBDBE8

	// Object: Function UMG.TextBinding.GetStringValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105daed40
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetStringValue();
	// [Call #1] RVA: 0x105D25B20
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105D259AC
	// [Call #7] RVA: 0x104F0F4CC
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10508F76C
	// [Call #15] RVA: 0x105DAFB9C
};

// Object: Class UMG.Throbber
// Size: 0x1D8 (Inherited: 0x100)
struct UThrobber : UWidget
{
	int NumberOfPieces; // 0x100(0x4)
	bool bAnimateHorizontally; // 0x104(0x1)
	bool bAnimateVertically; // 0x105(0x1)
	bool bAnimateOpacity; // 0x106(0x1)
	uint8_t Pad_0x107[0x1]; // 0x107(0x1)
	struct USlateBrushAsset* PieceImage; // 0x108(0x8)
	struct FSlateBrush Image; // 0x110(0xB8)
	uint8_t Pad_0x1C8[0x10]; // 0x1C8(0x10)


	// Object: Function UMG.Throbber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daffa8
	// Params: [ Num(1) Size(0x4) ]
	void SetNumberOfPieces(int InNumberOfPieces);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D45C24
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.Throbber.SetAnimateVertically
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105daff24
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimateVertically(bool bInAnimateVertically);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D45C8C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D45C24
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.Throbber.SetAnimateOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dafea0
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimateOpacity(bool bInAnimateOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D45CCC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D45C8C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D45C24
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Throbber.SetAnimateHorizontally
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dafe1c
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimateHorizontally(bool bInAnimateHorizontally);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D45C4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D45CCC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D45C8C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D45C24
	// [Call #13] RVA: 0x10519022C
};

// Object: Class UMG.TileView
// Size: 0x140 (Inherited: 0x100)
struct UTileView : UTableViewBase
{
	float ItemWidth; // 0x100(0x4)
	float ItemHeight; // 0x104(0x4)
	struct TArray<struct UObject*> Items; // 0x108(0x10)
	enum class ESelectionMode SelectionMode; // 0x118(0x1)
	uint8_t Pad_0x119[0x7]; // 0x119(0x7)
	DelegateProperty OnGenerateTileEvent; // 0x120(0x10)
	uint8_t Pad_0x130[0x10]; // 0x130(0x10)


	// Object: Function UMG.TileView.SetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0328
	// Params: [ Num(1) Size(0x4) ]
	void SetItemWidth(float Width);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46508
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.TileView.SetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db02ac
	// Params: [ Num(1) Size(0x4) ]
	void SetItemHeight(float Height);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4656C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46508
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.TileView.RequestListRefresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0298
	// Params: [ Num(0) Size(0x0) ]
	void RequestListRefresh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4656C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46508
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

// Object: Class UMG.UMGSequencePlayer
// Size: 0x720 (Inherited: 0x28)
struct UUMGSequencePlayer : UObject
{
	uint8_t Pad_0x28[0x348]; // 0x28(0x348)
	struct UWidgetAnimation* Animation; // 0x370(0x8)
	uint8_t Pad_0x378[0x3A8]; // 0x378(0x3A8)
};

// Object: Class UMG.UniformGridPanel
// Size: 0x140 (Inherited: 0x118)
struct UUniformGridPanel : UPanelWidget
{
	struct FMargin SlotPadding; // 0x114(0x10)
	float MinDesiredSlotWidth; // 0x124(0x4)
	float MinDesiredSlotHeight; // 0x128(0x4)
	uint8_t Pad_0x130[0x10]; // 0x130(0x10)


	// Object: Function UMG.UniformGridPanel.SetSlotPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db08dc
	// Params: [ Num(1) Size(0x10) ]
	void SetSlotPadding(struct FMargin InSlotPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46BC0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.UniformGridPanel.SetMinDesiredSlotWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0860
	// Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46C3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46BC0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.UniformGridPanel.SetMinDesiredSlotHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db07e4
	// Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46CA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46C3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D46BC0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.UniformGridPanel.AddChildToUniformGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0758
	// Params: [ Num(2) Size(0x10) ]
	struct UUniformGridSlot* AddChildToUniformGrid(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46B90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46CA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D46C3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D46BC0
	// [Call #13] RVA: 0x10519022C
};

// Object: Class UMG.UniformGridSlot
// Size: 0x58 (Inherited: 0x40)
struct UUniformGridSlot : UPanelSlot
{
	enum class EHorizontalAlignment HorizontalAlignment; // 0x40(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x41(0x1)
	uint8_t Pad_0x42[0x2]; // 0x42(0x2)
	int Row; // 0x44(0x4)
	int Column; // 0x48(0x4)
	uint8_t Pad_0x4C[0xC]; // 0x4C(0xC)


	// Object: Function UMG.UniformGridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0d00
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46E8C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UMG.UniformGridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0c84
	// Params: [ Num(1) Size(0x4) ]
	void SetRow(int InRow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46E50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46E8C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.UniformGridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0c08
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46E78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46E50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D46E8C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.UniformGridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db0b8c
	// Params: [ Num(1) Size(0x4) ]
	void SetColumn(int InColumn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D46E64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D46E78
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D46E50
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D46E8C
	// [Call #13] RVA: 0x10519022C
};

// Object: Class UMG.Viewport
// Size: 0x140 (Inherited: 0x118)
struct UViewport : UContentWidget
{
	struct FLinearColor BackgroundColor; // 0x114(0x10)
	uint8_t Pad_0x128[0x18]; // 0x128(0x18)


	// Object: Function UMG.Viewport.Spawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db8650
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* Spawn(struct AActor* ActorClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D4881C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.Viewport.SetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db85d4
	// Params: [ Num(1) Size(0xC) ]
	void SetViewRotation(struct FRotator Rotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48800
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D4881C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.Viewport.SetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105db8558
	// Params: [ Num(1) Size(0xC) ]
	void SetViewLocation(struct FVector Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D487B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D48800
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D4881C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Viewport.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db8520
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetViewRotation();
	// [Call #1] RVA: 0x105D487E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D487B8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D48800
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D4881C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function UMG.Viewport.GetViewportWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db84ec
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetViewportWorld();
	// [Call #1] RVA: 0x105D48780
	// [Call #2] RVA: 0x105D487E0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D487B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D48800
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D4881C
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.Viewport.GetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105db84b4
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetViewLocation();
	// [Call #1] RVA: 0x105D48798
	// [Call #2] RVA: 0x105D48780
	// [Call #3] RVA: 0x105D487E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D487B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D48800
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D4881C
};

// Object: Class UMG.VisibilityBinding
// Size: 0x48 (Inherited: 0x48)
struct UVisibilityBinding : UPropertyBinding
{

	// Object: Function UMG.VisibilityBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105db8990
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetValue();
	// [Call #1] RVA: 0x105D25D80
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class UMG.WeakRefImage
// Size: 0x2A8 (Inherited: 0x288)
struct UWeakRefImage : UImage
{
	uint8_t Pad_0x288[0x20]; // 0x288(0x20)


	// Object: Function UMG.WeakRefImage.UnloadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db8c9c
	// Params: [ Num(0) Size(0x0) ]
	void UnloadTextureResource();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870

	// Object: Function UMG.WeakRefImage.LoadTextureResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105db8c18
	// Params: [ Num(1) Size(0x1) ]
	void LoadTextureResource(bool bAsync);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D48AB4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class UMG.WidgetAnimation
// Size: 0x320 (Inherited: 0x2E8)
struct UWidgetAnimation : UMovieSceneSequence
{
	struct FScriptMulticastDelegate OnAnimationStarted; // 0x2E8(0x10)
	struct FScriptMulticastDelegate OnAnimationFinished; // 0x2F8(0x10)
	struct UMovieScene* MovieScene; // 0x308(0x8)
	struct TArray<struct FWidgetAnimationBinding> AnimationBindings; // 0x310(0x10)


	// Object: Function UMG.WidgetAnimation.GetStartTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dbb320
	// Params: [ Num(1) Size(0x4) ]
	float GetStartTime();
	// [Call #1] RVA: 0x105D23FB4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190648
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105DADEE4
	// [Call #8] RVA: 0x105184F34

	// Object: Function UMG.WidgetAnimation.GetEndTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dbb2ec
	// Params: [ Num(1) Size(0x4) ]
	float GetEndTime();
	// [Call #1] RVA: 0x105D23FC0
	// [Call #2] RVA: 0x105D23FB4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190648
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105DADEE4
};

// Object: Class UMG.WidgetBinding
// Size: 0x48 (Inherited: 0x48)
struct UWidgetBinding : UPropertyBinding
{

	// Object: Function UMG.WidgetBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105dbb5cc
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetValue();
	// [Call #1] RVA: 0x105D25E5C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105DADEE4
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0
	// [Call #8] RVA: 0x105DADEE4
	// [Call #9] RVA: 0x105184F34
};

// Object: Class UMG.WidgetBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWidgetBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function UMG.WidgetBlueprintLibrary.UnlockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbebcc
	// Params: [ Num(2) Size(0x170) ]
	struct FEventReply UnlockMouse(struct FEventReply& Reply);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8DA88
	// [Call #5] RVA: 0x10246D470
	// [Call #6] RVA: 0x10246D648
	// [Call #7] RVA: 0x10246D648
	// [Call #8] RVA: 0x106C8CAC8
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function UMG.WidgetBlueprintLibrary.Unhandled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbeb34
	// Params: [ Num(1) Size(0xB8) ]
	struct FEventReply Unhandled();
	// [Call #1] RVA: 0x105D8D7C0
	// [Call #2] RVA: 0x10246D470
	// [Call #3] RVA: 0x10246D648
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x10246D648
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10240B540
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8DA88
	// [Call #11] RVA: 0x10246D470
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x106C8CAC8
	// [Call #15] RVA: 0x10246D648
	// [Call #16] RVA: 0x10246D648
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function UMG.WidgetBlueprintLibrary.SetUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbe998
	// Params: [ Num(4) Size(0x180) ]
	struct FEventReply SetUserFocus(struct FEventReply& Reply, struct UWidget* FocusWidget, bool bInAllUsers);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8DAC0
	// [Call #9] RVA: 0x10246D470
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x106C8CAC8
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x105D8D7C0
	// [Call #17] RVA: 0x10246D470
	// [Call #18] RVA: 0x10246D648
	// [Call #19] RVA: 0x106C8CAC8
	// [Call #20] RVA: 0x10246D648
	// [Call #21] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.SetMousePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbe848
	// Params: [ Num(3) Size(0x178) ]
	struct FEventReply SetMousePosition(struct FEventReply& Reply, struct FVector2D NewMousePosition);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8DBC4
	// [Call #7] RVA: 0x10246D470
	// [Call #8] RVA: 0x10246D648
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10240B540
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnlyEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe760
	// Params: [ Num(3) Size(0x11) ]
	void SetInputMode_UIOnlyEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, uint8_t InMouseLockMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8CEDC
	// [Call #8] RVA: 0x10240B540
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8DBC4
	// [Call #14] RVA: 0x10246D470
	// [Call #15] RVA: 0x10246D648
	// [Call #16] RVA: 0x10246D648
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x10246D648
	// [Call #19] RVA: 0x10246D648
	// [Call #20] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe670
	// Params: [ Num(3) Size(0x11) ]
	void SetInputMode_UIOnly(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8CED8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8CEDC
	// [Call #15] RVA: 0x10240B540
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe5fc
	// Params: [ Num(1) Size(0x8) ]
	void SetInputMode_GameOnly(struct APlayerController* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8D104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8CED8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D8CEDC

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUIEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe4d0
	// Params: [ Num(4) Size(0x12) ]
	void SetInputMode_GameAndUIEx(struct APlayerController* Target, struct UWidget* InWidgetToFocus, uint8_t InMouseLockMode, bool bHideCursorDuringCapture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8CFF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8D104
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe39c
	// Params: [ Num(4) Size(0x12) ]
	void SetInputMode_GameAndUI(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8CFEC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8CFF0

	// Object: Function UMG.WidgetBlueprintLibrary.SetHardwareCursor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbe270
	// Params: [ Num(5) Size(0x21) ]
	bool SetHardwareCursor(struct UObject* WorldContextObject, enum class EMouseCursor CursorShape, struct FName CursorName, struct FVector2D HotSpot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E938
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8CFEC

	// Object: Function UMG.WidgetBlueprintLibrary.SetFocusToGameViewport
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbe25c
	// Params: [ Num(0) Size(0x0) ]
	void SetFocusToGameViewport();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E938
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dbe174
	// Params: [ Num(2) Size(0xC0) ]
	void SetBrushResourceToTexture(struct FSlateBrush& Brush, struct UTexture2D* Texture);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8E250
	// [Call #7] RVA: 0x101FEA144
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8E938
	// [Call #19] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dbe08c
	// Params: [ Num(2) Size(0xC0) ]
	void SetBrushResourceToMaterial(struct FSlateBrush& Brush, struct UMaterialInterface* Material);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8E258
	// [Call #7] RVA: 0x101FEA144
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x101FE9E54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D8E250
	// [Call #16] RVA: 0x101FEA144
	// [Call #17] RVA: 0x101FEA144
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.ReleaseMouseCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbdf7c
	// Params: [ Num(2) Size(0x170) ]
	struct FEventReply ReleaseMouseCapture(struct FEventReply& Reply);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8D908
	// [Call #5] RVA: 0x10246D470
	// [Call #6] RVA: 0x10246D648
	// [Call #7] RVA: 0x10246D648
	// [Call #8] RVA: 0x106C8CAC8
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101FE9E54
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D8E258
	// [Call #18] RVA: 0x101FEA144
	// [Call #19] RVA: 0x101FEA144
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x101FE9E54
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.ReleaseJoystickCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbde20
	// Params: [ Num(3) Size(0x178) ]
	struct FEventReply ReleaseJoystickCapture(struct FEventReply& Reply, bool bInAllJoysticks);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8DBC0
	// [Call #7] RVA: 0x10246D470
	// [Call #8] RVA: 0x10246D648
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10240B540
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D8D908
	// [Call #18] RVA: 0x10246D470
	// [Call #19] RVA: 0x10246D648
	// [Call #20] RVA: 0x10246D648
	// [Call #21] RVA: 0x106C8CAC8
	// [Call #22] RVA: 0x10246D648

	// Object: Function UMG.WidgetBlueprintLibrary.NoResourceBrush
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbddbc
	// Params: [ Num(1) Size(0xB8) ]
	struct FSlateBrush NoResourceBrush();
	// [Call #1] RVA: 0x105D8E260
	// [Call #2] RVA: 0x101FE5E98
	// [Call #3] RVA: 0x101FEA144
	// [Call #4] RVA: 0x101FEA144
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10240B540
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8DBC0
	// [Call #12] RVA: 0x10246D470
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x106C8CAC8
	// [Call #16] RVA: 0x10246D648
	// [Call #17] RVA: 0x10246D648
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10240B540
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x105D8D908

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbdca4
	// Params: [ Num(4) Size(0xC8) ]
	struct FSlateBrush MakeBrushFromTexture(struct UTexture2D* Texture, int Width, int Height);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8E06C
	// [Call #8] RVA: 0x101FE5E98
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x105D8E260
	// [Call #13] RVA: 0x101FE5E98
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x101FEA144
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10240B540
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x105D8DBC0

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromMaterial
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbdb8c
	// Params: [ Num(4) Size(0xC8) ]
	struct FSlateBrush MakeBrushFromMaterial(struct UMaterialInterface* Material, int Width, int Height);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8E148
	// [Call #8] RVA: 0x101FE5E98
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8E06C
	// [Call #19] RVA: 0x101FE5E98
	// [Call #20] RVA: 0x101FEA144
	// [Call #21] RVA: 0x101FEA144
	// [Call #22] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromAsset
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbdae8
	// Params: [ Num(2) Size(0xC0) ]
	struct FSlateBrush MakeBrushFromAsset(struct USlateBrushAsset* BrushAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8DFF4
	// [Call #4] RVA: 0x101FE5E98
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8E148
	// [Call #15] RVA: 0x101FE5E98
	// [Call #16] RVA: 0x101FEA144
	// [Call #17] RVA: 0x101FEA144
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.LockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd994
	// Params: [ Num(3) Size(0x178) ]
	struct FEventReply LockMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8D940
	// [Call #7] RVA: 0x10246D470
	// [Call #8] RVA: 0x10246D648
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D8DFF4
	// [Call #17] RVA: 0x101FE5E98
	// [Call #18] RVA: 0x101FEA144
	// [Call #19] RVA: 0x101FEA144
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.IsDragDropping
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd960
	// Params: [ Num(1) Size(0x1) ]
	bool IsDragDropping();
	// [Call #1] RVA: 0x105D8DE98
	// [Call #2] RVA: 0x10240B540
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8D940
	// [Call #8] RVA: 0x10246D470
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x106C8CAC8
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D8DFF4
	// [Call #18] RVA: 0x101FE5E98
	// [Call #19] RVA: 0x101FEA144
	// [Call #20] RVA: 0x101FEA144
	// [Call #21] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.Handled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd8c8
	// Params: [ Num(1) Size(0xB8) ]
	struct FEventReply Handled();
	// [Call #1] RVA: 0x105D8D728
	// [Call #2] RVA: 0x10246D470
	// [Call #3] RVA: 0x10246D648
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x10246D648
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x105D8DE98
	// [Call #8] RVA: 0x10240B540
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8D940
	// [Call #14] RVA: 0x10246D470
	// [Call #15] RVA: 0x10246D648
	// [Call #16] RVA: 0x10246D648
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x10246D648
	// [Call #19] RVA: 0x10246D648
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.GetSafeZonePadding
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbd774
	// Params: [ Num(4) Size(0x20) ]
	void GetSafeZonePadding(struct UObject* WorldContextObject, struct FVector2D& SafePadding, struct FVector2D& SafePaddingScale, struct FVector2D& SpillOverPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E774
	// [Call #10] RVA: 0x105D8D728
	// [Call #11] RVA: 0x10246D470
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8CAC8
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x105D8DE98
	// [Call #17] RVA: 0x10240B540

	// Object: Function UMG.WidgetBlueprintLibrary.GetKeyEventFromAnalogInputEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd6a0
	// Params: [ Num(2) Size(0x88) ]
	struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent& Event);
	// [Call #1] RVA: 0x1028E7F94
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8E6FC
	// [Call #5] RVA: 0x105DC0038
	// [Call #6] RVA: 0x102593DD4
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x102593DD4
	// [Call #9] RVA: 0x102593DD4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105D8E774

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromPointerEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd59c
	// Params: [ Num(2) Size(0x98) ]
	struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent& Event);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E72C
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x10220D174
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1028E7F94
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8E6FC
	// [Call #11] RVA: 0x105DC0038
	// [Call #12] RVA: 0x102593DD4
	// [Call #13] RVA: 0x102593DD4
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromNavigationEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd4e0
	// Params: [ Num(2) Size(0x48) ]
	struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent& Event);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E750
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8E72C
	// [Call #7] RVA: 0x10220D174
	// [Call #8] RVA: 0x10220D174
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1028E7F94
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8E6FC
	// [Call #14] RVA: 0x105DC0038
	// [Call #15] RVA: 0x102593DD4

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromKeyEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd400
	// Params: [ Num(2) Size(0x60) ]
	struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent& Event);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E6D8
	// [Call #4] RVA: 0x102593DD4
	// [Call #5] RVA: 0x102593DD4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E750
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromCharacterEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd344
	// Params: [ Num(2) Size(0x48) ]
	struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent& Event);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E708
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8E6D8
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x102593DD4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8E750

	// Object: Function UMG.WidgetBlueprintLibrary.GetDynamicMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd298
	// Params: [ Num(2) Size(0xC0) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush& Brush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8E2BC
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8E708
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8E6D8
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.GetDragDroppingContent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd264
	// Params: [ Num(1) Size(0x8) ]
	struct UDragDropOperation* GetDragDroppingContent();
	// [Call #1] RVA: 0x105D8DF48
	// [Call #2] RVA: 0x101FE9E54
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D8E2BC
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x101FEA144
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8E708
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8E6D8
	// [Call #15] RVA: 0x102593DD4

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd1b8
	// Params: [ Num(2) Size(0xC0) ]
	struct UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush& Brush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8E1F0
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x105D8DF48
	// [Call #9] RVA: 0x101FE9E54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8E2BC
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8E708

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd10c
	// Params: [ Num(2) Size(0xC0) ]
	struct UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush& Brush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8E220
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101FE9E54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8E1F0
	// [Call #12] RVA: 0x101FEA144
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x105D8DF48
	// [Call #16] RVA: 0x101FE9E54
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105D8E2BC
	// [Call #20] RVA: 0x101FEA144
	// [Call #21] RVA: 0x101FEA144
	// [Call #22] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResource
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbd060
	// Params: [ Num(2) Size(0xC0) ]
	struct UObject* GetBrushResource(struct FSlateBrush& Brush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8E1EC
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101FE9E54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8E220
	// [Call #12] RVA: 0x101FEA144
	// [Call #13] RVA: 0x101FEA144
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101FE9E54
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D8E1F0
	// [Call #19] RVA: 0x101FEA144
	// [Call #20] RVA: 0x101FEA144
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x105D8DF48
	// [Call #23] RVA: 0x101FE9E54

	// Object: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsWithInterface
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dbcefc
	// Params: [ Num(4) Size(0x21) ]
	void GetAllWidgetsWithInterface(struct UObject* WorldContextObject, struct IInterface* Interface, struct TArray<struct UUserWidget*>& FoundWidgets, bool TopLevelOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E4F0
	// [Call #10] RVA: 0x102ED1258
	// [Call #11] RVA: 0x102ED1258
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101FE9E54
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D8E1EC
	// [Call #17] RVA: 0x101FEA144
	// [Call #18] RVA: 0x101FEA144
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x101FE9E54
	// [Call #21] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsOfClass
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dbcd94
	// Params: [ Num(4) Size(0x21) ]
	void GetAllWidgetsOfClass(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UUserWidget* WidgetClass, bool TopLevelOnly);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8E338
	// [Call #10] RVA: 0x102ED1258
	// [Call #11] RVA: 0x102ED1258
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.EndDragDrop
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbcc84
	// Params: [ Num(2) Size(0x170) ]
	struct FEventReply EndDragDrop(struct FEventReply& Reply);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8DE5C
	// [Call #5] RVA: 0x10246D470
	// [Call #6] RVA: 0x10246D648
	// [Call #7] RVA: 0x10246D648
	// [Call #8] RVA: 0x106C8CAC8
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x105D8E338
	// [Call #21] RVA: 0x102ED1258

	// Object: Function UMG.WidgetBlueprintLibrary.DrawTextFormatted
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbca44
	// Params: [ Num(7) Size(0x78) ]
	void DrawTextFormatted(struct FPaintContext& Context, struct FText& Text, struct FVector2D Position, struct UFont* Font, int FontSize, struct FName FontTypeFace, struct FLinearColor Tint);
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105D8D5BC
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.DrawText
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbc8e4
	// Params: [ Num(4) Size(0x58) ]
	void DrawText(struct FPaintContext& Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint);
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8D414
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D862E8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.DrawLines
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbc75c
	// Params: [ Num(4) Size(0x51) ]
	void DrawLines(struct FPaintContext& Context, struct TArray<struct FVector2D>& Points, struct FLinearColor Tint, bool bAntiAlias);
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8D388
	// [Call #11] RVA: 0x10206E57C
	// [Call #12] RVA: 0x10206E57C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x105D862E8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbc5e4
	// Params: [ Num(5) Size(0x51) ]
	void DrawLine(struct FPaintContext& Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias);
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8D254
	// [Call #13] RVA: 0x105D862E8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.DrawBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dbc474
	// Params: [ Num(5) Size(0x58) ]
	void DrawBox(struct FPaintContext& Context, struct FVector2D Position, struct FVector2D Size, struct USlateBrushAsset* Brush, struct FLinearColor Tint);
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8D15C
	// [Call #13] RVA: 0x105D862E8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.DismissAllMenus
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbc460
	// Params: [ Num(0) Size(0x0) ]
	void DismissAllMenus();
	// [Call #1] RVA: 0x105D862E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8D15C
	// [Call #13] RVA: 0x105D862E8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.DetectDragIfPressed
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dbc230
	// Params: [ Num(4) Size(0x150) ]
	struct FEventReply DetectDragIfPressed(struct FPointerEvent& PointerEvent, struct UWidget* WidgetDetectingDrag, struct FKey DragKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8DD14
	// [Call #8] RVA: 0x10246D470
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x10220D174
	// [Call #13] RVA: 0x106C8CAC8
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x1021C8F20
	// [Call #16] RVA: 0x1021C8F20
	// [Call #17] RVA: 0x10220D174
	// [Call #18] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.DetectDrag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbc040
	// Params: [ Num(4) Size(0x190) ]
	struct FEventReply DetectDrag(struct FEventReply& Reply, struct UWidget* WidgetDetectingDrag, struct FKey DragKey);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8DC18
	// [Call #9] RVA: 0x10246D470
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x106C8CAC8
	// [Call #15] RVA: 0x10246D648
	// [Call #16] RVA: 0x1021C8F20
	// [Call #17] RVA: 0x1021C8F20
	// [Call #18] RVA: 0x10246D648
	// [Call #19] RVA: 0x106C8459C

	// Object: Function UMG.WidgetBlueprintLibrary.CreateDragDropOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbbfc4
	// Params: [ Num(2) Size(0x10) ]
	struct UDragDropOperation* CreateDragDropOperation(struct UDragDropOperation* OperationClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8CD50
	// [Call #4] RVA: 0x10240B540
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8DC18
	// [Call #12] RVA: 0x10246D470
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x1021C8F20
	// [Call #15] RVA: 0x1021C8F20
	// [Call #16] RVA: 0x10246D648
	// [Call #17] RVA: 0x106C8CAC8
	// [Call #18] RVA: 0x10246D648
	// [Call #19] RVA: 0x1021C8F20
	// [Call #20] RVA: 0x1021C8F20

	// Object: Function UMG.WidgetBlueprintLibrary.Create
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbbed4
	// Params: [ Num(4) Size(0x20) ]
	struct UUserWidget* Create(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8CC6C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8CD50
	// [Call #11] RVA: 0x10240B540
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.ClearUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbbd78
	// Params: [ Num(3) Size(0x178) ]
	struct FEventReply ClearUserFocus(struct FEventReply& Reply, bool bInAllUsers);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8DB88
	// [Call #7] RVA: 0x10246D470
	// [Call #8] RVA: 0x10246D648
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x105D8CC6C

	// Object: Function UMG.WidgetBlueprintLibrary.CheckWidgetIsActive
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbbcfc
	// Params: [ Num(2) Size(0x9) ]
	bool CheckWidgetIsActive(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E9CC
	// [Call #4] RVA: 0x10240B540
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8DB88
	// [Call #10] RVA: 0x10246D470
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8CAC8
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x10246D648
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function UMG.WidgetBlueprintLibrary.CaptureMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbbba8
	// Params: [ Num(3) Size(0x178) ]
	struct FEventReply CaptureMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8D858
	// [Call #7] RVA: 0x10246D470
	// [Call #8] RVA: 0x10246D648
	// [Call #9] RVA: 0x10246D648
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x10246D648
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D8E9CC
	// [Call #17] RVA: 0x10240B540
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.CaptureJoystick
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dbba0c
	// Params: [ Num(4) Size(0x180) ]
	struct FEventReply CaptureJoystick(struct FEventReply& Reply, struct UWidget* CapturingWidget, bool bInAllJoysticks);
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8DB84
	// [Call #9] RVA: 0x10246D470
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x106C8CAC8
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10240B540
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetBlueprintLibrary.CancelDragDrop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dbb9f8
	// Params: [ Num(0) Size(0x0) ]
	void CancelDragDrop();
	// [Call #1] RVA: 0x10240B540
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8DB84
	// [Call #9] RVA: 0x10246D470
	// [Call #10] RVA: 0x10246D648
	// [Call #11] RVA: 0x10246D648
	// [Call #12] RVA: 0x106C8CAC8
	// [Call #13] RVA: 0x10246D648
	// [Call #14] RVA: 0x10246D648
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10240B540
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class UMG.WidgetInteractionComponent
// Size: 0x590 (Inherited: 0x3A0)
struct UWidgetInteractionComponent : USceneComponent
{
	struct FScriptMulticastDelegate OnHoveredWidgetChanged; // 0x3A0(0x10)
	uint8_t Pad_0x3B0[0x10]; // 0x3B0(0x10)
	int VirtualUserIndex; // 0x3C0(0x4)
	float PointerIndex; // 0x3C4(0x4)
	enum class ECollisionChannel TraceChannel; // 0x3C8(0x1)
	uint8_t Pad_0x3C9[0x3]; // 0x3C9(0x3)
	float InteractionDistance; // 0x3CC(0x4)
	uint8_t InteractionSource; // 0x3D0(0x1)
	bool bEnableHitTesting; // 0x3D1(0x1)
	bool bShowDebug; // 0x3D2(0x1)
	uint8_t Pad_0x3D3[0x1]; // 0x3D3(0x1)
	struct FLinearColor DebugColor; // 0x3D4(0x10)
	uint8_t Pad_0x3E4[0x7C]; // 0x3E4(0x7C)
	struct FHitResult CustomHitResult; // 0x460(0x88)
	struct FVector2D LocalHitLocation; // 0x4E8(0x8)
	struct FVector2D LastLocalHitLocation; // 0x4F0(0x8)
	struct UWidgetComponent* HoveredWidgetComponent; // 0x4F8(0x8)
	struct FHitResult LastHitResult; // 0x500(0x88)
	bool bIsHoveredWidgetInteractable; // 0x588(0x1)
	bool bIsHoveredWidgetFocusable; // 0x589(0x1)
	bool bIsHoveredWidgetHitTestVisible; // 0x58A(0x1)
	uint8_t Pad_0x58B[0x5]; // 0x58B(0x5)


	// Object: Function UMG.WidgetInteractionComponent.SetCustomHitResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105dc1e80
	// Params: [ Num(1) Size(0x88) ]
	void SetCustomHitResult(struct FHitResult& HitResult);
	// [Call #1] RVA: 0x106C8CD38
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D7BDCC
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetInteractionComponent.SendKeyChar
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1d3c
	// Params: [ Num(3) Size(0x12) ]
	bool SendKeyChar(struct FString Characters, bool bRepeat);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106C8CD38
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D7BDCC
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function UMG.WidgetInteractionComponent.ScrollWheel
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1cb8
	// Params: [ Num(1) Size(0x4) ]
	void ScrollWheel(float ScrollDelta);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106C8CD38
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105D7BDCC

	// Object: Function UMG.WidgetInteractionComponent.ReleasePointerKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1bc8
	// Params: [ Num(1) Size(0x18) ]
	void ReleasePointerKey(struct FKey Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C8F20
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C

	// Object: Function UMG.WidgetInteractionComponent.ReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1ac8
	// Params: [ Num(2) Size(0x19) ]
	bool ReleaseKey(struct FKey Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C8F20
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x1021C8F20
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetInteractionComponent.PressPointerKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc19d8
	// Params: [ Num(1) Size(0x18) ]
	void PressPointerKey(struct FKey Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C8F20
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x1021C8F20
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetInteractionComponent.PressKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1890
	// Params: [ Num(3) Size(0x1A) ]
	bool PressKey(struct FKey Key, bool bRepeat);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x1021C8F20
	// [Call #8] RVA: 0x1021C8F20
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x1021C8F20
	// [Call #14] RVA: 0x1021C8F20
	// [Call #15] RVA: 0x1021C8F20
	// [Call #16] RVA: 0x106C8459C

	// Object: Function UMG.WidgetInteractionComponent.PressAndReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc1790
	// Params: [ Num(2) Size(0x19) ]
	bool PressAndReleaseKey(struct FKey Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C8F20
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x1021C8F20
	// [Call #14] RVA: 0x1021C8F20
	// [Call #15] RVA: 0x1021C8F20
	// [Call #16] RVA: 0x106C8459C

	// Object: Function UMG.WidgetInteractionComponent.IsOverInteractableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc175c
	// Params: [ Num(1) Size(0x1) ]
	bool IsOverInteractableWidget();
	// [Call #1] RVA: 0x105D7D230
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1021C8F20
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x1021C8F20
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1021C8F20
	// [Call #14] RVA: 0x1021C8F20

	// Object: Function UMG.WidgetInteractionComponent.IsOverHitTestVisibleWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc1728
	// Params: [ Num(1) Size(0x1) ]
	bool IsOverHitTestVisibleWidget();
	// [Call #1] RVA: 0x105D7D240
	// [Call #2] RVA: 0x105D7D230
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021C8F20
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x1021C8F20
	// [Call #8] RVA: 0x1021C8F20
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetInteractionComponent.IsOverFocusableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc16f4
	// Params: [ Num(1) Size(0x1) ]
	bool IsOverFocusableWidget();
	// [Call #1] RVA: 0x105D7D238
	// [Call #2] RVA: 0x105D7D240
	// [Call #3] RVA: 0x105D7D230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1021C8F20
	// [Call #7] RVA: 0x1021C8F20
	// [Call #8] RVA: 0x1021C8F20
	// [Call #9] RVA: 0x1021C8F20
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetInteractionComponent.GetLastHitResult
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc16bc
	// Params: [ Num(1) Size(0x88) ]
	struct FHitResult GetLastHitResult();
	// [Call #1] RVA: 0x105D7D248
	// [Call #2] RVA: 0x105D7D238
	// [Call #3] RVA: 0x105D7D240
	// [Call #4] RVA: 0x105D7D230
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1021C8F20
	// [Call #8] RVA: 0x1021C8F20
	// [Call #9] RVA: 0x1021C8F20
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function UMG.WidgetInteractionComponent.GetHoveredWidgetComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc1688
	// Params: [ Num(1) Size(0x8) ]
	struct UWidgetComponent* GetHoveredWidgetComponent();
	// [Call #1] RVA: 0x105D7D228
	// [Call #2] RVA: 0x105D7D248
	// [Call #3] RVA: 0x105D7D238
	// [Call #4] RVA: 0x105D7D240
	// [Call #5] RVA: 0x105D7D230
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1021C8F20
	// [Call #9] RVA: 0x1021C8F20
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function UMG.WidgetInteractionComponent.Get2DHitLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc1654
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D Get2DHitLocation();
	// [Call #1] RVA: 0x105D7D250
	// [Call #2] RVA: 0x105D7D228
	// [Call #3] RVA: 0x105D7D248
	// [Call #4] RVA: 0x105D7D238
	// [Call #5] RVA: 0x105D7D240
	// [Call #6] RVA: 0x105D7D230
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1021C8F20
	// [Call #10] RVA: 0x1021C8F20
	// [Call #11] RVA: 0x1021C8F20
	// [Call #12] RVA: 0x1021C8F20
	// [Call #13] RVA: 0x106C8459C
};

// Object: Class UMG.WidgetLayoutLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWidgetLayoutLibrary : UBlueprintFunctionLibrary
{

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsVerticalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2eac
	// Params: [ Num(2) Size(0x10) ]
	struct UVerticalBoxSlot* SlotAsVerticalBoxSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8F08C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsUniformGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2e30
	// Params: [ Num(2) Size(0x10) ]
	struct UUniformGridSlot* SlotAsUniformGridSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8F050
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8F08C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsOverlaySlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2db4
	// Params: [ Num(2) Size(0x10) ]
	struct UOverlaySlot* SlotAsOverlaySlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8F014
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8F050
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8F08C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsHorizontalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2d38
	// Params: [ Num(2) Size(0x10) ]
	struct UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EFD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8F014
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8F050
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8F08C
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2cbc
	// Params: [ Num(2) Size(0x10) ]
	struct UGridSlot* SlotAsGridSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EF9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8EFD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8F014
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8F050
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D8F08C

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsCanvasSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2c40
	// Params: [ Num(2) Size(0x10) ]
	struct UCanvasPanelSlot* SlotAsCanvasSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EF60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8EF9C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8EFD8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8F014
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D8F050

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsBorderSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2bc4
	// Params: [ Num(2) Size(0x10) ]
	struct UBorderSlot* SlotAsBorderSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EF24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8EF60
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8EF9C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8EFD8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D8F014

	// Object: Function UMG.WidgetLayoutLibrary.SetOriginalViewPortSizeXY
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dc2b18
	// Params: [ Num(2) Size(0x8) ]
	void SetOriginalViewPortSizeXY(int X, int Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D8EE28
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8EF24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8EF60
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8EF9C
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.WidgetLayoutLibrary.SetOriginalViewPortSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc2a98
	// Params: [ Num(1) Size(0x8) ]
	void SetOriginalViewPortSize(struct FIntPoint& Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EE04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8EE28
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8EF24
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8EF60
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.WidgetLayoutLibrary.RemoveAllWidgets
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dc2a24
	// Params: [ Num(1) Size(0x8) ]
	void RemoveAllWidgets(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8F0C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8EE04
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8EE28
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8EF24
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPositionReturnValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc296c
	// Params: [ Num(3) Size(0x1C) ]
	struct FVector2D ProjectWorldLocationToWidgetPositionReturnValue(struct APlayerController* PlayerController, struct FVector WorldLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D8EBB0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105D8F0C8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8EE04
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D8EE28

	// Object: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPosition
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc286c
	// Params: [ Num(4) Size(0x1D) ]
	bool ProjectWorldLocationToWidgetPosition(struct APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D& ScreenPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8EB78
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D8EBB0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105D8F0C8

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dc27e4
	// Params: [ Num(2) Size(0x40) ]
	struct FGeometry GetViewportWidgetGeometry(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8ECAC
	// [Call #4] RVA: 0x1051EC464
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8EB78
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105D8EBB0

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportSize
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2768
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetViewportSize(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8E81C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8ECAC
	// [Call #7] RVA: 0x1051EC464
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8EB78
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportScale
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc26ec
	// Params: [ Num(2) Size(0xC) ]
	float GetViewportScale(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D81814
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D8E81C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D8ECAC
	// [Call #10] RVA: 0x1051EC464
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetLayoutLibrary.GetPlayerScreenWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105dc2664
	// Params: [ Num(2) Size(0x40) ]
	struct FGeometry GetPlayerScreenWidgetGeometry(struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EE60
	// [Call #4] RVA: 0x1051EC464
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D81814
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8E81C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8ECAC
	// [Call #14] RVA: 0x1051EC464
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionScaledByDPI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105dc2548
	// Params: [ Num(4) Size(0x11) ]
	bool GetMousePositionScaledByDPI(struct APlayerController* Player, float& LocationX, float& LocationY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D8ED54
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8EE60
	// [Call #11] RVA: 0x1051EC464
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D81814
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionOnViewport
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc24cc
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetMousePositionOnViewport(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D8EC24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D8ED54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105D8EE60
	// [Call #14] RVA: 0x1051EC464
	// [Call #15] RVA: 0x10516D168

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionOnPlatform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc2498
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetMousePositionOnPlatform();
	// [Call #1] RVA: 0x105D8EBEC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D8EC24
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D8ED54
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105D8EE60
	// [Call #15] RVA: 0x1051EC464
};

// Object: Class UMG.WidgetNavigation
// Size: 0xB8 (Inherited: 0x28)
struct UWidgetNavigation : UObject
{
	struct FWidgetNavigationData Up; // 0x28(0x18)
	struct FWidgetNavigationData Down; // 0x40(0x18)
	struct FWidgetNavigationData Left; // 0x58(0x18)
	struct FWidgetNavigationData Right; // 0x70(0x18)
	struct FWidgetNavigationData Next; // 0x88(0x18)
	struct FWidgetNavigationData Previous; // 0xA0(0x18)
};

// Object: Class UMG.WidgetSwitcher
// Size: 0x130 (Inherited: 0x118)
struct UWidgetSwitcher : UPanelWidget
{
	int ActiveWidgetIndex; // 0x114(0x4)
	bool bDontPaintWhenChildEmpty; // 0x118(0x1)
	uint8_t Pad_0x11D[0x13]; // 0x11D(0x13)


	// Object: Function UMG.WidgetSwitcher.SetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc398c
	// Params: [ Num(1) Size(0x1) ]
	void SetDontPaintWhenChildEmpty(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7D970
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.WidgetSwitcher.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc3908
	// Params: [ Num(1) Size(0x4) ]
	void SetActiveWidgetIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D7D970
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetSwitcher.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105dc3884
	// Params: [ Num(1) Size(0x8) ]
	void SetActiveWidget(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D7D970
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetSwitcher.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc37f8
	// Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetWidgetAtIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7D4A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105D7D970
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.WidgetSwitcher.GetNumWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc37c4
	// Params: [ Num(1) Size(0x4) ]
	int GetNumWidgets();
	// [Call #1] RVA: 0x105D7D3E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105D7D4A8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105D7D970

	// Object: Function UMG.WidgetSwitcher.GetDontPaintWhenChildEmpty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc3790
	// Params: [ Num(1) Size(0x1) ]
	bool GetDontPaintWhenChildEmpty();
	// [Call #1] RVA: 0x105D7D984
	// [Call #2] RVA: 0x105D7D3E0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105D7D4A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetSwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc375c
	// Params: [ Num(1) Size(0x4) ]
	int GetActiveWidgetIndex();
	// [Call #1] RVA: 0x105D7D3FC
	// [Call #2] RVA: 0x105D7D984
	// [Call #3] RVA: 0x105D7D3E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7D4A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function UMG.WidgetSwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc3728
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetActiveWidget();
	// [Call #1] RVA: 0x105D7D4D0
	// [Call #2] RVA: 0x105D7D3FC
	// [Call #3] RVA: 0x105D7D984
	// [Call #4] RVA: 0x105D7D3E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105D7D4A8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class UMG.WidgetSwitcherSlot
// Size: 0x60 (Inherited: 0x40)
struct UWidgetSwitcherSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0xE]; // 0x52(0xE)


	// Object: Function UMG.WidgetSwitcherSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc3e6c
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7DA7C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function UMG.WidgetSwitcherSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc3dec
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7D9F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7DA7C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WidgetSwitcherSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc3d70
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7DA68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7D9F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7DA7C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.WidgetTree
// Size: 0x50 (Inherited: 0x28)
struct UWidgetTree : UObject
{
	struct UWidget* RootWidget; // 0x28(0x8)
	struct TArray<struct UWidget*> AllWidgets; // 0x30(0x10)
	struct TArray<struct FLazyLoadBinding> LazyLoadBindings; // 0x40(0x10)
};

// Object: Class UMG.WindowTitleBarArea
// Size: 0x130 (Inherited: 0x118)
struct UWindowTitleBarArea : UContentWidget
{
	bool bDoubleClickTogglesFullscreen; // 0x111(0x1)
	uint8_t Pad_0x119[0x17]; // 0x119(0x17)


	// Object: Function UMG.WindowTitleBarArea.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc438c
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E5B8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105DC4884

	// Object: Function UMG.WindowTitleBarArea.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc430c
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E53C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7E5B8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WindowTitleBarArea.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4290
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E5A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7E53C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7E5B8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.WindowTitleBarAreaSlot
// Size: 0x68 (Inherited: 0x40)
struct UWindowTitleBarAreaSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x1)
	uint8_t Pad_0x52[0x16]; // 0x52(0x16)


	// Object: Function UMG.WindowTitleBarAreaSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc46f8
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E6D0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105DC4B40

	// Object: Function UMG.WindowTitleBarAreaSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4678
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E6C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7E6D0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function UMG.WindowTitleBarAreaSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc45fc
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7E6C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7E6C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7E6D0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UMG.WrapBox
// Size: 0x138 (Inherited: 0x118)
struct UWrapBox : UPanelWidget
{
	struct FVector2D InnerSlotPadding; // 0x114(0x8)
	float WrapWidth; // 0x11C(0x4)
	bool bExplicitWrapWidth; // 0x120(0x1)
	uint8_t Pad_0x125[0x13]; // 0x125(0x13)


	// Object: Function UMG.WrapBox.SetInnerSlotPadding
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105dc49e8
	// Params: [ Num(1) Size(0x8) ]
	void SetInnerSlotPadding(struct FVector2D InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7EF3C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105DC5040

	// Object: Function UMG.WrapBox.AddChildWrapBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc495c
	// Params: [ Num(2) Size(0x10) ]
	struct UWrapBoxSlot* AddChildWrapBox(struct UWidget* Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7EB74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7EF3C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class UMG.WrapBoxSlot
// Size: 0x68 (Inherited: 0x40)
struct UWrapBoxSlot : UPanelSlot
{
	struct FMargin Padding; // 0x40(0x10)
	bool bFillEmptySpace; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	float FillSpanWhenLessThan; // 0x54(0x4)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x58(0x1)
	enum class EVerticalAlignment VerticalAlignment; // 0x59(0x1)
	uint8_t Pad_0x5A[0xE]; // 0x5A(0xE)


	// Object: Function UMG.WrapBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4e14
	// Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7F138
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function UMG.WrapBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4d94
	// Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7F04C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7F138
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UMG.WrapBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4d18
	// Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7F124
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7F04C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7F138
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UMG.WrapBoxSlot.SetFillSpanWhenLessThan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4c9c
	// Params: [ Num(1) Size(0x4) ]
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7F0D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7F124
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7F04C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D7F138
	// [Call #13] RVA: 0x10519022C

	// Object: Function UMG.WrapBoxSlot.SetFillEmptySpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc4c18
	// Params: [ Num(1) Size(0x1) ]
	void SetFillEmptySpace(bool InbFillEmptySpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105D7F0C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105D7F0D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105D7F124
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105D7F04C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: WidgetBlueprintGeneratedClass UMG.Default__WidgetBlueprintGeneratedClass
// Size: 0x0 (Inherited: 0x0)
struct Default__WidgetBlueprintGeneratedClass
{
};

