#pragma once

#include <cstdint>

// Object: Enum AutoRobot.EAutoRunTestFlag
enum class EAutoRunTestFlag : uint8_t
{
	Game4Win = 1,
	PVEBattleTest = 2,
	EAutoRunTestFlag_MAX = 3
};

// Object: ScriptStruct AutoRobot.BulletImpactAutoTestData
// Size: 0x1C (Inherited: 0x0)
struct FBulletImpactAutoTestData
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
};

// Object: Class AutoRobot.AutoRobotModule
// Size: 0x60 (Inherited: 0x28)
struct UAutoRobotModule : UObject
{
	uint8_t Pad_0x28[0x38]; // 0x28(0x38)
};

// Object: Class AutoRobot.AutoRobotSceneTool
// Size: 0x28 (Inherited: 0x28)
struct UAutoRobotSceneTool : UObject
{
};

// Object: Class AutoRobot.AutoRunPlayerTestActor
// Size: 0x4D0 (Inherited: 0x4B0)
struct AAutoRunPlayerTestActor : AActor
{
	float Interval; // 0x4AC(0x4)
	struct TArray<struct FVector> PortalLoctions; // 0x4B0(0x10)
	uint8_t Pad_0x4C4[0xC]; // 0x4C4(0xC)
};

// Object: Class AutoRobot.AutoTestInterface
// Size: 0x1E0 (Inherited: 0x178)
struct UAutoTestInterface : UActorComponent
{
	uint8_t Pad_0x178[0x68]; // 0x178(0x68)


	// Object: Function AutoRobot.AutoTestInterface.StarJumpPlane
	// Flags: [Final|Native|Public]
	// Offset: 0x1025a4210
	// Params: [ Num(0) Size(0x0) ]
	void StarJumpPlane();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x1025A3E70
	// [Call #5] RVA: 0x105185230
	// [Call #6] RVA: 0x1051903D0
	// [Call #7] RVA: 0x1025AA8B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class AutoRobot.AutoTestSubsystem
// Size: 0x68 (Inherited: 0x30)
struct UAutoTestSubsystem : UGameInstanceSubsystem
{
	struct URemoteControlManager* RemoteControlManager; // 0x30(0x8)
	struct UAutoRobotModule* AutoModule; // 0x38(0x8)
	struct FString AutoTestMissionType; // 0x40(0x10)
	struct FString CustomLineStr; // 0x50(0x10)
	int GamePlayMode; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)


	// Object: Function AutoRobot.AutoTestSubsystem.Swipe
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8464
	// Params: [ Num(10) Size(0x34) ]
	void Swipe(struct FString InPath, float Duringtime, int StartX, int StartY, int EndX, int EndY, int TouchIndex, int ControllerId, int ScreensizeX, int ScreensizeY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.StopRecordInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8450
	// Params: [ Num(0) Size(0x0) ]
	void StopRecordInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.StopPlayInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a843c
	// Params: [ Num(0) Size(0x0) ]
	void StopPlayInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.StartRemoteControl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8310
	// Params: [ Num(3) Size(0x24) ]
	void StartRemoteControl(struct FString Name, struct FString Host, int Port);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258D5D4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.StartRecordInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8278
	// Params: [ Num(1) Size(0x10) ]
	void StartRecordInput(struct FString Command);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258DBFC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258D5D4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.StartPlayInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a81e0
	// Params: [ Num(1) Size(0x10) ]
	void StartPlayInput(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258DD74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258DBFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10258D5D4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.SetCustomRouteLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a81cc
	// Params: [ Num(0) Size(0x0) ]
	void SetCustomRouteLine();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258DD74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258DBFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10258D5D4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.RegisterInputProcessor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a81b8
	// Params: [ Num(0) Size(0x0) ]
	void RegisterInputProcessor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258DD74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258DBFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10258D5D4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.PVEAutoTestGetEnemyLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a8180
	// Params: [ Num(1) Size(0xC) ]
	struct FVector PVEAutoTestGetEnemyLocation();
	// [Call #1] RVA: 0x10258E078
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258DD74
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258DBFC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.PubgmSimulateActionClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8104
	// Params: [ Num(1) Size(0x4) ]
	void PubgmSimulateActionClientEx(int SimulateType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E8A8
	// [Call #4] RVA: 0x10258E078
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258DD74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DBFC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.ParsePoint
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a8054
	// Params: [ Num(2) Size(0x1C) ]
	struct FVector ParsePoint(struct FString SrcStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DD74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.OpenDebugg
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8040
	// Params: [ Num(0) Size(0x0) ]
	void OpenDebugg();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DD74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.OnStopAutoTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a802c
	// Params: [ Num(0) Size(0x0) ]
	void OnStopAutoTest();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DD74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.OnStartAutoTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a8018
	// Params: [ Num(0) Size(0x0) ]
	void OnStartAutoTest();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DD74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.OnGameStart
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1025a8004
	// Params: [ Num(0) Size(0x0) ]
	void OnGameStart();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258DD74
	// [Call #14] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.OnGameEnd
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1025a7ff0
	// Params: [ Num(0) Size(0x0) ]
	void OnGameEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258D690
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E8A8
	// [Call #10] RVA: 0x10258E078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.IsUIAutoTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7fbc
	// Params: [ Num(1) Size(0x1) ]
	bool IsUIAutoTest();
	// [Call #1] RVA: 0x10258DA3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258D690
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E8A8
	// [Call #11] RVA: 0x10258E078
	// [Call #12] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.IsSecAutoRunTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7f88
	// Params: [ Num(1) Size(0x1) ]
	bool IsSecAutoRunTest();
	// [Call #1] RVA: 0x10258D8F0
	// [Call #2] RVA: 0x10258DA3C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258D690
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258E8A8
	// [Call #12] RVA: 0x10258E078

	// Object: Function AutoRobot.AutoTestSubsystem.IsGAutomatorTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7f54
	// Params: [ Num(1) Size(0x1) ]
	bool IsGAutomatorTest();
	// [Call #1] RVA: 0x10258D8E8
	// [Call #2] RVA: 0x10258D8F0
	// [Call #3] RVA: 0x10258DA3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258D690
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258E8A8
	// [Call #13] RVA: 0x10258E078

	// Object: Function AutoRobot.AutoTestSubsystem.IsAutoRunTestGamePVEProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7f20
	// Params: [ Num(1) Size(0x1) ]
	bool IsAutoRunTestGamePVEProfile();
	// [Call #1] RVA: 0x10258D90C
	// [Call #2] RVA: 0x10258D8E8
	// [Call #3] RVA: 0x10258D8F0
	// [Call #4] RVA: 0x10258DA3C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258D690
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E8A8

	// Object: Function AutoRobot.AutoTestSubsystem.IsAutoRunTestGamePVE
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7eec
	// Params: [ Num(1) Size(0x1) ]
	bool IsAutoRunTestGamePVE();
	// [Call #1] RVA: 0x10258D8F8
	// [Call #2] RVA: 0x10258D90C
	// [Call #3] RVA: 0x10258D8E8
	// [Call #4] RVA: 0x10258D8F0
	// [Call #5] RVA: 0x10258DA3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258D690
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.IsAutoRunTestGameBindComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7eb8
	// Params: [ Num(1) Size(0x1) ]
	bool IsAutoRunTestGameBindComponent();
	// [Call #1] RVA: 0x10258D55C
	// [Call #2] RVA: 0x10258D8F8
	// [Call #3] RVA: 0x10258D90C
	// [Call #4] RVA: 0x10258D8E8
	// [Call #5] RVA: 0x10258D8F0
	// [Call #6] RVA: 0x10258DA3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258D690
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.IsAutoRunTestGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7e84
	// Params: [ Num(1) Size(0x1) ]
	bool IsAutoRunTestGame();
	// [Call #1] RVA: 0x10258D8DC
	// [Call #2] RVA: 0x10258D55C
	// [Call #3] RVA: 0x10258D8F8
	// [Call #4] RVA: 0x10258D90C
	// [Call #5] RVA: 0x10258D8E8
	// [Call #6] RVA: 0x10258D8F0
	// [Call #7] RVA: 0x10258DA3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258D690
	// [Call #11] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.GetWidgetPathByPos
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7d5c
	// Params: [ Num(4) Size(0x10) ]
	void GetWidgetPathByPos(int StartX, int StartY, int ScreensizeX, int ScreensizeY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258DFDC
	// [Call #10] RVA: 0x10258D8DC
	// [Call #11] RVA: 0x10258D55C
	// [Call #12] RVA: 0x10258D8F8
	// [Call #13] RVA: 0x10258D90C
	// [Call #14] RVA: 0x10258D8E8
	// [Call #15] RVA: 0x10258D8F0

	// Object: Function AutoRobot.AutoTestSubsystem.GetRuntimeProfileData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7cf8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetRuntimeProfileData();
	// [Call #1] RVA: 0x10258DA28
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258DFDC
	// [Call #15] RVA: 0x10258D8DC
	// [Call #16] RVA: 0x10258D55C
	// [Call #17] RVA: 0x10258D8F8
	// [Call #18] RVA: 0x10258D90C

	// Object: Function AutoRobot.AutoTestSubsystem.GetAutoTestInterface
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025a7cc4
	// Params: [ Num(1) Size(0x8) ]
	struct UAutoTestInterface* GetAutoTestInterface();
	// [Call #1] RVA: 0x10258DFF4
	// [Call #2] RVA: 0x10258DA28
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258DFDC
	// [Call #16] RVA: 0x10258D8DC
	// [Call #17] RVA: 0x10258D55C
	// [Call #18] RVA: 0x10258D8F8

	// Object: Function AutoRobot.AutoTestSubsystem.GetAutoRunTestServerIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7c90
	// Params: [ Num(1) Size(0x4) ]
	int GetAutoRunTestServerIdx();
	// [Call #1] RVA: 0x10258D920
	// [Call #2] RVA: 0x10258DFF4
	// [Call #3] RVA: 0x10258DA28
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10258DFDC
	// [Call #17] RVA: 0x10258D8DC
	// [Call #18] RVA: 0x10258D55C

	// Object: Function AutoRobot.AutoTestSubsystem.GetAutoRunPassWD
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7c2c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAutoRunPassWD();
	// [Call #1] RVA: 0x10258D92C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258D920
	// [Call #7] RVA: 0x10258DFF4
	// [Call #8] RVA: 0x10258DA28
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10258DFDC

	// Object: Function AutoRobot.AutoTestSubsystem.GetAutoRunLuaTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7bc8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAutoRunLuaTest();
	// [Call #1] RVA: 0x10258D578
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258D92C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10258D920
	// [Call #12] RVA: 0x10258DFF4
	// [Call #13] RVA: 0x10258DA28
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.GetAutoRunAccount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7b64
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAutoRunAccount();
	// [Call #1] RVA: 0x10258A4FC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258D578
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10258D92C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10258D920
	// [Call #17] RVA: 0x10258DFF4
	// [Call #18] RVA: 0x10258DA28
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.CloseDebugg
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7b50
	// Params: [ Num(0) Size(0x0) ]
	void CloseDebugg();
	// [Call #1] RVA: 0x10258A4FC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258D578
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10258D92C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10258D920
	// [Call #17] RVA: 0x10258DFF4
	// [Call #18] RVA: 0x10258DA28
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.ClickButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7758
	// Params: [ Num(11) Size(0x48) ]
	void ClickButton(struct FString InPath, float Duringtime, int StartX, int StartY, int EndX, int EndY, int TouchIndex, int ControllerId, int ScreensizeX, int ScreensizeY, struct FString UsePos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.CheckStaticMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a75a4
	// Params: [ Num(4) Size(0x20) ]
	void CheckStaticMesh(float Radius, float DeformationDistance, bool CheckComplexCollisionQuery, struct FString MapName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x10258DFF0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestWaitForUIWithName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a750c
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestWaitForUIWithName(struct FString UIName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102590050
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10258DFF0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestWaitForSecond
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7490
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestWaitForSecond(int sec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FE14
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102590050
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestWaitForJumpPlane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a745c
	// Params: [ Num(1) Size(0x1) ]
	bool AutoTestWaitForJumpPlane();
	// [Call #1] RVA: 0x10258FF10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FE14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102590050
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestVehicleDriverShoot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7448
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestVehicleDriverShoot();
	// [Call #1] RVA: 0x10258FF10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FE14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102590050
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestVaultWall
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7434
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestVaultWall();
	// [Call #1] RVA: 0x10258FF10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FE14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102590050
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestUsePropSkillClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7420
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestUsePropSkillClientEx();
	// [Call #1] RVA: 0x10258FF10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FE14
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102590050
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestUseItemClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a73a4
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestUseItemClientEx(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F400
	// [Call #4] RVA: 0x10258FF10
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258FE14
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102590050
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestUseItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7328
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestUseItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258F400
	// [Call #7] RVA: 0x10258FF10
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258FE14
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102590050
	// [Call #14] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestUpgradePropSkillClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a72ac
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestUpgradePropSkillClientEx(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F4BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FD20
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258F400
	// [Call #10] RVA: 0x10258FF10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258FE14

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestToggleVehicleSync
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7228
	// Params: [ Num(1) Size(0x1) ]
	void AutoTestToggleVehicleSync(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FC04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258F4BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FD20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258F400
	// [Call #13] RVA: 0x10258FF10

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestThrowBoomOnlyClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a71ac
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestThrowBoomOnlyClientEx(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FC04
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258F4BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FD20
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestThrowBoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7130
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestThrowBoom(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FD54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FC04
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258F4BC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSwitchWeapon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a70b4
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestSwitchWeapon(int WeaponType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FDA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FD50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FD54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FC04
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSwitchMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a701c
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestSwitchMode(struct FString FunName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FF2C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FDA8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FD50
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258FD54
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestStopRecordStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a7008
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestStopRecordStats();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FF2C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FDA8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FD50
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258FD54
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestStatsCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6f70
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestStatsCommand(struct FString Command);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FE10
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FF2C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258FDA8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258FD50

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestStartRecordStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6ed8
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestStartRecordStats(struct FString FileStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FF1C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FE10
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258FF2C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10258FDA8

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestStartFireOnlyClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6db0
	// Params: [ Num(4) Size(0x10) ]
	void AutoTestStartFireOnlyClientEx(int InX, int InY, int InZ, int sec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E7D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FF1C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258FE10
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestStartFire
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6c88
	// Params: [ Num(4) Size(0x10) ]
	void AutoTestStartFire(int InX, int InY, int InZ, int sec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258E7D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258E7D8

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSpecating
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6c0c
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestSpecating(int LeftTeamCnt);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102590010
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258E7D4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSpawnVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6b74
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestSpawnVehicle(struct FString ResPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD28
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102590010
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258E7D4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSpawnAI
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6a48
	// Params: [ Num(4) Size(0x10) ]
	void AutoTestSpawnAI(int ID, float PosiX, float PosiY, float PosiZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FD2C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FD28
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102590010

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetVehicleRotation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6958
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestSetVehicleRotation(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E6EC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10258FD2C
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetRecordFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a68dc
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestSetRecordFrequency(int Frequency);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FF24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E6EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetGamePaused
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6858
	// Params: [ Num(1) Size(0x1) ]
	void AutoTestSetGamePaused(bool IsPause);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102590104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FF24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E6EC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetActorYaw
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a67dc
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestSetActorYaw(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E708
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102590104
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FF24
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetActorRotation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6728
	// Params: [ Num(2) Size(0x8) ]
	void AutoTestSetActorRotation(float InRate, float InSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258E6E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258E708
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102590104
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258FF24

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetActorPitch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a66ac
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestSetActorPitch(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E704
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258E6E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258E708
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102590104

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetActorFacePointWithZ
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a65bc
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestSetActorFacePointWithZ(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E6DC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E704
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E6E8
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSetActorFacePoint
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a64cc
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestSetActorFacePoint(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E6D8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E6DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10258E704

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestSendBuffertoSvr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025a6440
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestSendBuffertoSvr(struct TScriptInterface<Class>& ClientNetInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258DA4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E6D8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestReplaceMatByActorName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6208
	// Params: [ Num(5) Size(0x2C) ]
	void AutoTestReplaceMatByActorName(struct FString actorName, struct FString NewMatName, int RComp, int GComp, int BComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x10258EF58
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestReloadOnlyClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a61f4
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestReloadOnlyClientEx();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x10258EF58
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestPickupItemOnlyClientEx
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a61c0
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D AutoTestPickupItemOnlyClientEx();
	// [Call #1] RVA: 0x10258FE28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x10258EF58
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestPickupItem
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a6134
	// Params: [ Num(2) Size(0xC) ]
	struct FVector2D AutoTestPickupItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FE18
	// [Call #4] RVA: 0x10258FE28
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101F8122C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestOpenTraceRPC
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6120
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestOpenTraceRPC();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FE18
	// [Call #4] RVA: 0x10258FE28
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestOpenScope
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a609c
	// Params: [ Num(1) Size(0x1) ]
	void AutoTestOpenScope(bool bOpenScope);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FE18
	// [Call #7] RVA: 0x10258FE28
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestOpenDoorOnlyClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a6020
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestOpenDoorOnlyClientEx(int bOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E858
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FD24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FE18
	// [Call #10] RVA: 0x10258FE28
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestMustDie
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5fa4
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestMustDie(int LeftTeamCnt);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FF98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258E858
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FD24
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258FE18
	// [Call #13] RVA: 0x10258FE28

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestMoveVehicleForward
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5eb4
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestMoveVehicleForward(float Speed, float Rate, float sec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258FD4C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258FF98
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E858
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestMoveToPoint
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5dc4
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestMoveToPoint(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E718
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258FD4C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10258FF98

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestJumpPlane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5d48
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestJumpPlane(int sec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FDA4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E718
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10258FD4C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestJump
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5d34
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestJump();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FDA4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E718
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestIsOnVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5d00
	// Params: [ Num(1) Size(0x1) ]
	bool AutoTestIsOnVehicle();
	// [Call #1] RVA: 0x10258FC28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FDA4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258E718
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestIsDriver
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5ccc
	// Params: [ Num(1) Size(0x1) ]
	bool AutoTestIsDriver();
	// [Call #1] RVA: 0x10258F9C8
	// [Call #2] RVA: 0x10258FC28
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258FDA4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10258E718
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestIsCurrentCommandFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5c98
	// Params: [ Num(1) Size(0x1) ]
	bool AutoTestIsCurrentCommandFinished();
	// [Call #1] RVA: 0x10258D988
	// [Call #2] RVA: 0x10258F9C8
	// [Call #3] RVA: 0x10258FC28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FDA4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E718
	// [Call #14] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestInputMovement
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5c1c
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestInputMovement(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E71C
	// [Call #4] RVA: 0x10258D988
	// [Call #5] RVA: 0x10258F9C8
	// [Call #6] RVA: 0x10258FC28
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FDA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestInputKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5abc
	// Params: [ Num(4) Size(0x19) ]
	void AutoTestInputKey(struct FString Key, enum class EInputEvent EventType, float AmountDepressed, bool bGamepad);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258EEA0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E71C
	// [Call #16] RVA: 0x10258D988
	// [Call #17] RVA: 0x10258F9C8

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGMVehicleMoveAndTowardClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a591c
	// Params: [ Num(6) Size(0x18) ]
	void AutoTestGMVehicleMoveAndTowardClientEx(float InX, float InY, float InZ, float InX1, float InY1, float InZ1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258F770
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGMGotoClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a582c
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestGMGotoClientEx(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258F318
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGMGoto
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a573c
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestGMGoto(int InX, int InY, int InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E714
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258F318
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGMCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a56a4
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestGMCommand(struct FString Command);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FE0C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E714
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetVehicleLocationClientEx
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a566c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector AutoTestGetVehicleLocationClientEx();
	// [Call #1] RVA: 0x10258F8E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FE0C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E714
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetVehicleLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a5634
	// Params: [ Num(1) Size(0xC) ]
	struct FVector AutoTestGetVehicleLocation();
	// [Call #1] RVA: 0x10258E6F0
	// [Call #2] RVA: 0x10258F8E4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258FE0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E714
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetRuntimeStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5620
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetRuntimeStats();
	// [Call #1] RVA: 0x10258E6F0
	// [Call #2] RVA: 0x10258F8E4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258FE0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E714
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetRenderTimeDetail
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a560c
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetRenderTimeDetail();
	// [Call #1] RVA: 0x10258E6F0
	// [Call #2] RVA: 0x10258F8E4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258FE0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E714
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetPrimitivesDetail
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a55f8
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetPrimitivesDetail();
	// [Call #1] RVA: 0x10258E6F0
	// [Call #2] RVA: 0x10258F8E4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258FE0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10258E714

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetOnVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a557c
	// Params: [ Num(1) Size(0x4) ]
	void AutoTestGetOnVehicle(int SeatType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD44
	// [Call #4] RVA: 0x10258E6F0
	// [Call #5] RVA: 0x10258F8E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258FE0C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetOffVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5568
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetOffVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FD44
	// [Call #4] RVA: 0x10258E6F0
	// [Call #5] RVA: 0x10258F8E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258FE0C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetNearVehiclePos
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a5530
	// Params: [ Num(1) Size(0xC) ]
	struct FVector AutoTestGetNearVehiclePos();
	// [Call #1] RVA: 0x10258FD30
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FD44
	// [Call #5] RVA: 0x10258E6F0
	// [Call #6] RVA: 0x10258F8E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FE0C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetMemoryDetail
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a551c
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetMemoryDetail();
	// [Call #1] RVA: 0x10258FD30
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10258FD44
	// [Call #5] RVA: 0x10258E6F0
	// [Call #6] RVA: 0x10258F8E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FE0C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetMapName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a54b8
	// Params: [ Num(1) Size(0x10) ]
	struct FString AutoTestGetMapName();
	// [Call #1] RVA: 0x10258E6E0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258FD30
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10258FD44
	// [Call #10] RVA: 0x10258E6F0
	// [Call #11] RVA: 0x10258F8E4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258FE0C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetLuaReturnValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a53d4
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestGetLuaReturnValue(struct FString retval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102590074
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10258E6E0
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10258FD30
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10258FD44

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetGameModeState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5370
	// Params: [ Num(1) Size(0x10) ]
	struct FString AutoTestGetGameModeState();
	// [Call #1] RVA: 0x10258DFFC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102590074
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10258E6E0
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10258FD30
	// [Call #23] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetFrameInfo
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a5338
	// Params: [ Num(1) Size(0xC) ]
	struct FVector AutoTestGetFrameInfo();
	// [Call #1] RVA: 0x10258FEFC
	// [Call #2] RVA: 0x10258DFFC
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102590074
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10258E6E0
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10258FD30

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetDrawCallDetail
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5324
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestGetDrawCallDetail();
	// [Call #1] RVA: 0x10258FEFC
	// [Call #2] RVA: 0x10258DFFC
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102590074
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10258E6E0
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10258FD30

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetDis2D
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5178
	// Params: [ Num(7) Size(0x1C) ]
	int AutoTestGetDis2D(int InX1, int InY1, int InZ1, int InX2, int InY2, int InZ2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258E70C
	// [Call #14] RVA: 0x10258FEFC
	// [Call #15] RVA: 0x10258DFFC
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetCircleLocationClientEx
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a5140
	// Params: [ Num(1) Size(0xC) ]
	struct FVector AutoTestGetCircleLocationClientEx();
	// [Call #1] RVA: 0x10258E08C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E70C
	// [Call #15] RVA: 0x10258FEFC

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetAvailableDeadBoxItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a50dc
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> AutoTestGetAvailableDeadBoxItem();
	// [Call #1] RVA: 0x10258E02C
	// [Call #2] RVA: 0x101FA6168
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258E08C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10258E70C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetAllActorNames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5078
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> AutoTestGetAllActorNames();
	// [Call #1] RVA: 0x102590068
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10258E02C
	// [Call #7] RVA: 0x101FA6168
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10258E08C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetActorName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a5014
	// Params: [ Num(1) Size(0x10) ]
	struct FString AutoTestGetActorName();
	// [Call #1] RVA: 0x10258E034
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102590068
	// [Call #7] RVA: 0x101FA5F38
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10258E02C
	// [Call #12] RVA: 0x101FA6168
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10258E08C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetActorLocationListClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4f24
	// Params: [ Num(3) Size(0x18) ]
	struct TArray<struct FVector> AutoTestGetActorLocationListClientEx(int ActorType, float RangeRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258E118
	// [Call #6] RVA: 0x10246DCBC
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10258E034
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x102590068
	// [Call #16] RVA: 0x101FA5F38
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10258E02C
	// [Call #21] RVA: 0x101FA6168
	// [Call #22] RVA: 0x101F8BA44
	// [Call #23] RVA: 0x101F8BA44
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10258E08C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestGetActorLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a4e74
	// Params: [ Num(2) Size(0x1C) ]
	struct FVector AutoTestGetActorLocation(struct FString PlayerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E064
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258E118
	// [Call #12] RVA: 0x10246DCBC
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10258E034
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x102590068
	// [Call #22] RVA: 0x101FA5F38
	// [Call #23] RVA: 0x101F8B9F8

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestForceVehiclePosPullClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4de0
	// Params: [ Num(2) Size(0x8) ]
	float AutoTestForceVehiclePosPullClientEx(bool bNext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258E064
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E118
	// [Call #15] RVA: 0x10246DCBC
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x101F8C3A4
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestForceDeleteCmdAnim
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4dcc
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestForceDeleteCmdAnim();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258E064
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E118
	// [Call #15] RVA: 0x10246DCBC
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x101F8C3A4
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestEnableUITest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4db8
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestEnableUITest();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258E064
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258E118
	// [Call #15] RVA: 0x10246DCBC
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x101F8C3A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestEnableTickOrVisibilityByActorName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4c3c
	// Params: [ Num(3) Size(0x12) ]
	void AutoTestEnableTickOrVisibilityByActorName(struct FString actorName, bool bEnableTick, bool bShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x102590070
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258F504

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestEnableActorPrimitiveHighlight
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a4a30
	// Params: [ Num(5) Size(0x24) ]
	void AutoTestEnableActorPrimitiveHighlight(struct FString actorName, bool bEnable, bool bInCanBeOccluded, bool bOverrideColor, struct FLinearColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x102590100
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestDropItemClientEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a497c
	// Params: [ Num(2) Size(0x8) ]
	void AutoTestDropItemClientEx(int ItemId, int nCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258F448
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x102590100
	// [Call #18] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestDrawBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a47dc
	// Params: [ Num(6) Size(0x18) ]
	void AutoTestDrawBox(float LocationX, float LocationY, float LocationZ, float ExtentX, float ExtentY, float ExtentZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102590108
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258F448

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestContinuousMoveTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a46ec
	// Params: [ Num(3) Size(0xC) ]
	void AutoTestContinuousMoveTo(float InX, float InY, float InZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258FF18
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestConsoleCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4654
	// Params: [ Num(1) Size(0x10) ]
	void AutoTestConsoleCommand(struct FString Command);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FDAC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258FF18
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestCloseTraceRPC
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4640
	// Params: [ Num(0) Size(0x0) ]
	void AutoTestCloseTraceRPC();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258FDAC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258FF18
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestAutoMoveForward
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a45bc
	// Params: [ Num(1) Size(0x1) ]
	void AutoTestAutoMoveForward(bool StartAutoMoveForward);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10259010C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258FDAC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10258FF18
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoTestAddItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025a4508
	// Params: [ Num(2) Size(0x8) ]
	void AutoTestAddItem(int ItemId, int nCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10258F3FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10259010C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258FDAC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.AutoTestSubsystem.AutoMoveToTargetPosClientEx
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a448c
	// Params: [ Num(1) Size(0xC) ]
	void AutoMoveToTargetPosClientEx(struct FVector targetPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258EBEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258F3FC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10259010C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258FDAC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function AutoRobot.AutoTestSubsystem.AutoMovePawnToTargetPosClientEx
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025a4410
	// Params: [ Num(1) Size(0xC) ]
	void AutoMovePawnToTargetPosClientEx(struct FVector targetPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F074
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10258EBEC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10258F3FC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10259010C
};

// Object: Class AutoRobot.PubgmAutoRun
// Size: 0x1A0 (Inherited: 0x178)
struct UPubgmAutoRun : UActorComponent
{
	struct FScriptMulticastDelegate PubgmAutoRunSimulateAction; // 0x178(0x10)
	bool bRoutePointInited; // 0x188(0x1)
	uint8_t Pad_0x189[0x7]; // 0x189(0x7)
	struct TArray<struct AXTPoint*> RoutePoints; // 0x190(0x10)


	// Object: Function AutoRobot.PubgmAutoRun.VehicleTowardTo
	// Flags: [Final|Native|Public]
	// Offset: 0x1025ab1f4
	// Params: [ Num(3) Size(0xC) ]
	void VehicleTowardTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102591EBC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AutoRobot.PubgmAutoRun.VehicleMoveTo
	// Flags: [Final|Native|Public]
	// Offset: 0x1025ab104
	// Params: [ Num(3) Size(0xC) ]
	void VehicleMoveTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102591E08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102591EBC
	// [Call #15] RVA: 0x10519022C

	// Object: Function AutoRobot.PubgmAutoRun.VehicleMoveAndTowardTo
	// Flags: [Final|Native|Public]
	// Offset: 0x1025aaf64
	// Params: [ Num(6) Size(0x18) ]
	void VehicleMoveAndTowardTo(float X, float Y, float Z, float X1, float Y1, float Z1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10258F80C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: DelegateFunction AutoRobot.PubgmAutoRun.OnPubgmAutoRunSimulateAction__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void OnPubgmAutoRunSimulateAction__DelegateSignature(int SimActionType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AutoRobot.PubgmAutoRun.NeedCmdAutoRun
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025aaf30
	// Params: [ Num(1) Size(0x1) ]
	bool NeedCmdAutoRun();
	// [Call #1] RVA: 0x102592054
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10258F80C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.PubgmAutoRun.NativeSimulateAction
	// Flags: [Final|Native|Public]
	// Offset: 0x1025aaeb4
	// Params: [ Num(1) Size(0x4) ]
	void NativeSimulateAction(int SimActionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E8F8
	// [Call #4] RVA: 0x102592054
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10258F80C

	// Object: Function AutoRobot.PubgmAutoRun.InitRoutePoint
	// Flags: [Final|Native|Public]
	// Offset: 0x1025aaea0
	// Params: [ Num(0) Size(0x0) ]
	void InitRoutePoint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E8F8
	// [Call #4] RVA: 0x102592054
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10258F80C

	// Object: Function AutoRobot.PubgmAutoRun.GMGotoPosition
	// Flags: [Final|Native|Public]
	// Offset: 0x1025aadb0
	// Params: [ Num(3) Size(0xC) ]
	void GMGotoPosition(int X, int Y, int Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258F384
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E8F8
	// [Call #11] RVA: 0x102592054
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AutoRobot.PubgmAutoRun.GetRangeActorsPostions
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1025aac84
	// Params: [ Num(4) Size(0x28) ]
	struct TArray<struct FVector> GetRangeActorsPostions(int ActorType, struct FVector OriginPos, float RangeRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10258E29C
	// [Call #8] RVA: 0x10246DCBC
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10258F384

	// Object: Function AutoRobot.PubgmAutoRun.GetPoisonCircleLocation
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1025aac4c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetPoisonCircleLocation();
	// [Call #1] RVA: 0x10258E104
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10258E29C
	// [Call #9] RVA: 0x10246DCBC
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10258F384

	// Object: Function AutoRobot.PubgmAutoRun.GetPlayerSpeed
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025aabc8
	// Params: [ Num(2) Size(0x8) ]
	float GetPlayerSpeed(int SpeedIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258E104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E29C
	// [Call #11] RVA: 0x10246DCBC
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AutoRobot.PubgmAutoRun.GetNearestXTPointToVehicle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1025aaa68
	// Params: [ Num(4) Size(0x62) ]
	bool GetNearestXTPointToVehicle(struct FTransform& FirstPoint, struct FTransform& SecendPoint, bool bNext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102591B74
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10258E104
	// [Call #11] RVA: 0x10516D168

	// Object: Function AutoRobot.PubgmAutoRun.ForceVehiclePosPull
	// Flags: [Final|Native|Public]
	// Offset: 0x1025aa9d4
	// Params: [ Num(2) Size(0x8) ]
	float ForceVehiclePosPull(bool bNext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10258F558
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102591B74
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class AutoRobot.PVEAutoRunTest
// Size: 0x1C0 (Inherited: 0x178)
struct UPVEAutoRunTest : UActorComponent
{
	struct TArray<struct FVector> DstPointArray; // 0x178(0x10)
	int MaxMoveTime; // 0x188(0x4)
	int MaxDstStayTime; // 0x18C(0x4)
	int KillAllTime; // 0x190(0x4)
	int StatRecordTime; // 0x194(0x4)
	uint8_t Pad_0x198[0x28]; // 0x198(0x28)
};

// Object: Class AutoRobot.RemoteControlHelper
// Size: 0x28 (Inherited: 0x28)
struct URemoteControlHelper : UBlueprintFunctionLibrary
{

	// Object: Function AutoRobot.RemoteControlHelper.GetRuntimeStats
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025ab900
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetRuntimeStats();
	// [Call #1] RVA: 0x1025A0544
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x1025ABF64

	// Object: Function AutoRobot.RemoteControlHelper.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025ab89c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceName();
	// [Call #1] RVA: 0x1025A0418
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1025A0544
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AutoRobot.RemoteControlHelper.AutoPickup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025ab828
	// Params: [ Num(1) Size(0x8) ]
	void AutoPickup(struct ASTExtraBaseCharacter* Player);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025A01C4
	// [Call #4] RVA: 0x1025A0418
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1025A0544
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C
};

// Object: Class AutoRobot.RemoteControlManager
// Size: 0x28 (Inherited: 0x28)
struct URemoteControlManager : UObject
{

	// Object: Function AutoRobot.RemoteControlManager.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025abd60
	// Params: [ Num(2) Size(0x5) ]
	bool Tick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025A0BA4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AutoRobot.RemoteControlManager.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025abd4c
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025A0BA4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AutoRobot.RemoteControlManager.BeginWithFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025abd18
	// Params: [ Num(1) Size(0x1) ]
	bool BeginWithFile();
	// [Call #1] RVA: 0x1025A0B9C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1025A0BA4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AutoRobot.RemoteControlManager.Begin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025abb4c
	// Params: [ Num(4) Size(0x25) ]
	bool Begin(struct FString Name, struct FString Host, int Port);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x1025A0B94
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x1025A0B9C
	// [Call #24] RVA: 0x10516D168
};

// Object: Class AutoRobot.ShootWeaponAutoTestHandle
// Size: 0x38 (Inherited: 0x28)
struct UShootWeaponAutoTestHandle : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)


	// Object: Function AutoRobot.ShootWeaponAutoTestHandle.OnWeaponShootBullet
	// Flags: [Final|Native|Public]
	// Offset: 0x1025ac324
	// Params: [ Num(2) Size(0x10) ]
	void OnWeaponShootBullet(struct ASTExtraShootWeapon* ShootWeapon, struct ASTExtraShootWeaponBulletBase* Bullet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025A0BD8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AutoRobot.ShootWeaponAutoTestHandle.OnBulletImpact
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1025ac214
	// Params: [ Num(3) Size(0x98) ]
	void OnBulletImpact(struct ASTExtraShootWeapon* ShootWeapon, struct ASTExtraShootWeaponBulletBase* Bullet, struct FHitResult& HitRet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025A0CEC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025A0BD8
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function AutoRobot.ShootWeaponAutoTestHandle.OnBulletDamage
	// Flags: [Final|Native|Public]
	// Offset: 0x1025ac15c
	// Params: [ Num(2) Size(0x8) ]
	void OnBulletDamage(int ShootID, float Damage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025A0E8C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C8CD38
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025A0CEC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AutoRobot.ShootWeaponAutoTestHandle.GenerateBulletsImpactJsonStringAndClearData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025ac0f8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GenerateBulletsImpactJsonStringAndClearData();
	// [Call #1] RVA: 0x1025A0F98
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025A0E8C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C8CD38
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1025A0CEC
};

// Object: Class AutoRobot.TestAIController
// Size: 0x1130 (Inherited: 0x1120)
struct ATestAIController : ABaseAIController
{
	struct APickUpWrapperActor* EquipedWeaponClass; // 0x1120(0x8)
	struct ASTExtraBaseCharacter* CharacterClass; // 0x1128(0x8)
};

