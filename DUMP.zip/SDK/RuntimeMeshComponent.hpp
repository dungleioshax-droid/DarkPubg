#pragma once

#include <cstdint>

// Object: Enum RuntimeMeshComponent.EUpdateFrequency
enum class EUpdateFrequency : uint8_t
{
	Average = 0,
	Frequent = 1,
	Infrequent = 2,
	VertexBufferFrequent = 3,
	IndexBufferFrequent = 4,
	EUpdateFrequency_MAX = 5
};

// Object: Enum RuntimeMeshComponent.ERuntimeMeshCollisionCookingMode
enum class ERuntimeMeshCollisionCookingMode : uint8_t
{
	CollisionPerformance = 0,
	CookingPerformance = 1,
	ERuntimeMeshCollisionCookingMode_MAX = 2
};

// Object: ScriptStruct RuntimeMeshComponent.RuntimeMeshTangent
// Size: 0x10 (Inherited: 0x0)
struct FRuntimeMeshTangent
{
	struct FVector TangentX; // 0x0(0xC)
	bool bFlipTangentY; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct RuntimeMeshComponent.RuntimeMeshComponentPrePhysicsTickFunction
// Size: 0xB8 (Inherited: 0xB0)
struct FRuntimeMeshComponentPrePhysicsTickFunction : FTickFunction
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
};

// Object: ScriptStruct RuntimeMeshComponent.RuntimeConvexCollisionSection
// Size: 0x30 (Inherited: 0x0)
struct FRuntimeConvexCollisionSection
{
	struct TArray<struct FVector> VertexBuffer; // 0x0(0x10)
	struct FBox BoundingBox; // 0x10(0x1C)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct RuntimeMeshComponent.RuntimeMeshCollisionSection
// Size: 0x20 (Inherited: 0x0)
struct FRuntimeMeshCollisionSection
{
	struct TArray<struct FVector> VertexBuffer; // 0x0(0x10)
	struct TArray<int> IndexBuffer; // 0x10(0x10)
};

// Object: ScriptStruct RuntimeMeshComponent.RunTimeMeshFrustumCullNode
// Size: 0x38 (Inherited: 0x0)
struct FRunTimeMeshFrustumCullNode
{
	struct FBox Bounds; // 0x0(0x1C)
	uint16_t InfoIndex; // 0x1C(0x2)
	uint8_t Pad_0x1E[0x2]; // 0x1E(0x2)
	struct FString LandScapeName; // 0x20(0x10)
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
};

// Object: Class RuntimeMeshComponent.RuntimeMeshComponent
// Size: 0xBA0 (Inherited: 0xA20)
struct URuntimeMeshComponent : UMeshComponent
{
	uint8_t Pad_0xA20[0x8]; // 0xA20(0x8)
	struct FScriptMulticastDelegate CollisionUpdated; // 0xA28(0x10)
	bool bUseComplexAsSimpleCollision; // 0xA38(0x1)
	bool bUseAsyncCooking; // 0xA39(0x1)
	bool bCanbeOccluded; // 0xA3A(0x1)
	bool bShouldSerializeMeshData; // 0xA3B(0x1)
	uint8_t CollisionMode; // 0xA3C(0x1)
	uint8_t Pad_0xA3D[0x3]; // 0xA3D(0x3)
	struct UBodySetup* BodySetup; // 0xA40(0x8)
	uint8_t Pad_0xA48[0x30]; // 0xA48(0x30)
	struct TArray<struct FRuntimeMeshCollisionSection> MeshCollisionSections; // 0xA78(0x10)
	struct TArray<struct FRuntimeConvexCollisionSection> ConvexCollisionSections; // 0xA88(0x10)
	struct FBoxSphereBounds LocalBounds; // 0xA98(0x1C)
	uint8_t Pad_0xAB4[0x4]; // 0xAB4(0x4)
	struct FRuntimeMeshComponentPrePhysicsTickFunction PrePhysicsTick; // 0xAB8(0xB8)
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // 0xB70(0x10)
	uint8_t Pad_0xB80[0x20]; // 0xB80(0x20)


	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.UpdateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b72e84
	// Params: [ Num(10) Size(0x7A) ]
	void UpdateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.SetSectionTessellationTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b72d4c
	// Params: [ Num(3) Size(0x19) ]
	void SetSectionTessellationTriangles(int SectionIndex, struct TArray<int>& TessellationTriangles, bool bShouldMoveArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B38BC4
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72c90
	// Params: [ Num(2) Size(0x5) ]
	void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B38C28
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B38BC4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72bd4
	// Params: [ Num(2) Size(0x5) ]
	void SetMeshSectionCollisionEnabled(int SectionIndex, bool bNewCollisionEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B38CE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B38C28
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCastsShadow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72b18
	// Params: [ Num(2) Size(0x5) ]
	void SetMeshSectionCastsShadow(int SectionIndex, bool bNewCastsShadow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B38C84
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B38CE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B38C28

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshCollisionSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b729c4
	// Params: [ Num(3) Size(0x28) ]
	void SetMeshCollisionSection(int CollisionSectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B38E30
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B38C84
	// [Call #18] RVA: 0x10516D168

	// Object: DelegateFunction RuntimeMeshComponent.RuntimeMeshComponent.RuntimeMeshCollisionUpdatedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void RuntimeMeshCollisionUpdatedDelegate__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b72938
	// Params: [ Num(2) Size(0x5) ]
	bool IsMeshSectionVisible(int SectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38C54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B38E30
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b728ac
	// Params: [ Num(2) Size(0x5) ]
	bool IsMeshSectionCollisionEnabled(int SectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38D24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B38C54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B38E30
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x101F8C3A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCastingShadows
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b72820
	// Params: [ Num(2) Size(0x5) ]
	bool IsMeshSectionCastingShadows(int SectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38CB0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B38D24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B38C54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b727ec
	// Params: [ Num(1) Size(0x4) ]
	int GetNumSections();
	// [Call #1] RVA: 0x102B38D54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B38CB0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B38D24
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B38C54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.GetLastSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b727b8
	// Params: [ Num(1) Size(0x4) ]
	int GetLastSectionIndex();
	// [Call #1] RVA: 0x102B38DF8
	// [Call #2] RVA: 0x102B38D54
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B38CB0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B38D24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B38C54
	// [Call #12] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.FirstAvailableMeshSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b72784
	// Params: [ Num(1) Size(0x4) ]
	int FirstAvailableMeshSectionIndex();
	// [Call #1] RVA: 0x102B38DBC
	// [Call #2] RVA: 0x102B38DF8
	// [Call #3] RVA: 0x102B38D54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B38CB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B38D24
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B38C54

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.EndBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72770
	// Params: [ Num(0) Size(0x0) ]
	void EndBatchUpdates();
	// [Call #1] RVA: 0x102B38DBC
	// [Call #2] RVA: 0x102B38DF8
	// [Call #3] RVA: 0x102B38D54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B38CB0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B38D24
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B38C54

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.DoesSectionExist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b726e4
	// Params: [ Num(2) Size(0x5) ]
	bool DoesSectionExist(int SectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38D90
	// [Call #4] RVA: 0x102B38DBC
	// [Call #5] RVA: 0x102B38DF8
	// [Call #6] RVA: 0x102B38D54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B38CB0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B38D24

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.CreateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b72234
	// Params: [ Num(12) Size(0x7C) ]
	void CreateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCreateCollision, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles, uint8_t UpdateFrequency);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.CookCollisionNow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72220
	// Params: [ Num(0) Size(0x0) ]
	void CookCollisionNow();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b721a4
	// Params: [ Num(1) Size(0x4) ]
	void ClearMeshSection(int SectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B387D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshCollisionSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72128
	// Params: [ Num(1) Size(0x4) ]
	void ClearMeshCollisionSection(int CollisionSectionIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38F60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B387D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72114
	// Params: [ Num(0) Size(0x0) ]
	void ClearCollisionConvexMeshes();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38F60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B387D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b72100
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllMeshSections();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38F60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B387D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshCollisionSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b720ec
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllMeshCollisionSections();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B38F60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B387D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.ChangeRuntimeMeshSectionUVs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b71fa0
	// Params: [ Num(4) Size(0x59) ]
	bool ChangeRuntimeMeshSectionUVs(int SectionIndex, int Index, struct TMap<int, struct FVector2D> UVs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B754B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B75588
	// [Call #9] RVA: 0x102B3B438
	// [Call #10] RVA: 0x102B75CE0
	// [Call #11] RVA: 0x102B75CE0
	// [Call #12] RVA: 0x102B75CE0
	// [Call #13] RVA: 0x102B75CE0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B38F60
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.BeginBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b71f84
	// Params: [ Num(0) Size(0x0) ]
	void BeginBatchUpdates();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B754B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B75588
	// [Call #9] RVA: 0x102B3B438
	// [Call #10] RVA: 0x102B75CE0
	// [Call #11] RVA: 0x102B75CE0
	// [Call #12] RVA: 0x102B75CE0
	// [Call #13] RVA: 0x102B75CE0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B38F60
	// [Call #18] RVA: 0x10516D168

	// Object: Function RuntimeMeshComponent.RuntimeMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b71ea0
	// Params: [ Num(1) Size(0x10) ]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD7408
	// [Call #4] RVA: 0x102B39098
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102B754B8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B75588
	// [Call #20] RVA: 0x102B3B438
	// [Call #21] RVA: 0x102B75CE0
	// [Call #22] RVA: 0x102B75CE0
	// [Call #23] RVA: 0x102B75CE0
	// [Call #24] RVA: 0x102B75CE0
	// [Call #25] RVA: 0x106C8459C
};

// Object: Class RuntimeMeshComponent.RuntimeMeshLodComponent
// Size: 0xBC0 (Inherited: 0xA20)
struct URuntimeMeshLodComponent : UMeshComponent
{
	uint8_t Pad_0xA20[0x38]; // 0xA20(0x38)
	struct TArray<struct FRuntimeMeshCollisionSection> MeshCollisionSections; // 0xA58(0x10)
	struct TArray<struct FRuntimeConvexCollisionSection> ConvexCollisionSections; // 0xA68(0x10)
	struct FBoxSphereBounds LocalBounds; // 0xA78(0x1C)
	uint8_t Pad_0xA94[0x4]; // 0xA94(0x4)
	struct FRuntimeMeshComponentPrePhysicsTickFunction PrePhysicsTick; // 0xA98(0xB8)
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // 0xB50(0x10)
	struct TMap<struct FIntPoint, int> LodSectionIndexs; // 0xB60(0x50)
	uint8_t Pad_0xBB0[0x10]; // 0xBB0(0x10)
};

// Object: Class RuntimeMeshComponent.RuntimeMeshLibrary
// Size: 0x28 (Inherited: 0x28)
struct URuntimeMeshLibrary : UBlueprintFunctionLibrary
{

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b74cc0
	// Params: [ Num(8) Size(0x60) ]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int LODIndex, int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.GenerateTessellationIndexBuffer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b74a08
	// Params: [ Num(6) Size(0x60) ]
	void GenerateTessellationIndexBuffer(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<int>& OutTessTriangles);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B3E890
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x102B44598
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x10206E57C
	// [Call #18] RVA: 0x101F8BA44
	// [Call #19] RVA: 0x101F8C3A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b748ac
	// Params: [ Num(4) Size(0x20) ]
	void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, struct TArray<int>& Triangles);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B3D1D4
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102b74620
	// Params: [ Num(6) Size(0x60) ]
	void CreateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B3D2A8
	// [Call #14] RVA: 0x102B44598
	// [Call #15] RVA: 0x10206E57C
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x101F8C3A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.CopyRuntimeMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b744f0
	// Params: [ Num(4) Size(0x19) ]
	void CopyRuntimeMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComp, int LODIndex, struct URuntimeMeshComponent* RuntimeMeshComp, bool bShouldCreateCollision);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B3F458
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.CopyRuntimeMeshFromStaticMesh
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b743c0
	// Params: [ Num(4) Size(0x19) ]
	void CopyRuntimeMeshFromStaticMesh(struct UStaticMesh* StaticMesh, int LODIndex, struct URuntimeMeshComponent* RuntimeMeshComp, bool bShouldCreateCollision);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B3F460
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102B3F458

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b74224
	// Params: [ Num(5) Size(0x20) ]
	void ConvertQuadToTriangles(struct TArray<int>& Triangles, int Vert0, int Vert1, int Vert2, int Vert3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B3D090
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function RuntimeMeshComponent.RuntimeMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b73fd4
	// Params: [ Num(5) Size(0x50) ]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B3E6E0
	// [Call #12] RVA: 0x102B44598
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x10206E57C
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x102B44598
	// [Call #18] RVA: 0x101F8C3A4
	// [Call #19] RVA: 0x10206E57C
	// [Call #20] RVA: 0x101F8BA44
	// [Call #21] RVA: 0x101F8C3A4
	// [Call #22] RVA: 0x106C8459C
};

