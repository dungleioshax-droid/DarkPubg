#pragma once

#include <cstdint>

// Object: Class LuaHotReload.LuaHotReloadHelper
// Size: 0x38 (Inherited: 0x28)
struct ULuaHotReloadHelper : UObject
{
	struct FScriptMulticastDelegate OnScriptChangedDelegate; // 0x28(0x10)


	// Object: Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
	// Flags: [Final|Native|Public]
	// Offset: 0x102a5fbb8
	// Params: [ Num(1) Size(0x10) ]
	void OnLuaFileHotUpdate(struct FString NotifyMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A5F510
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10518559C
};

