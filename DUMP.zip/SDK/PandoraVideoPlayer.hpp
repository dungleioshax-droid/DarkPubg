#pragma once

#include <cstdint>

// Object: Class PandoraVideoPlayer.BP_PixVideoLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBP_PixVideoLibrary : UBlueprintFunctionLibrary
{

	// Object: Function PandoraVideoPlayer.BP_PixVideoLibrary.SetPixVideoLibraryPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff6abc
	// Params: [ Num(2) Size(0x11) ]
	bool SetPixVideoLibraryPath(struct FString LibPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101FF1324
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519077C

	// Object: Function PandoraVideoPlayer.BP_PixVideoLibrary.CreatePlayerWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff69d8
	// Params: [ Num(2) Size(0x18) ]
	struct UUserWidget* CreatePlayerWidget(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101FF11CC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101FF1324
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
	// [Call #24] RVA: 0x105190870
};

// Object: Class PandoraVideoPlayer.PVideoImage
// Size: 0x2B8 (Inherited: 0x288)
struct UPVideoImage : UImage
{
	struct FScriptMulticastDelegate PlayerEventDelegate; // 0x288(0x10)
	uint8_t Pad_0x298[0x18]; // 0x298(0x18)
	struct UPVideoPlayer* m_pPlayer; // 0x2B0(0x8)


	// Object: DelegateFunction PandoraVideoPlayer.PVideoImage.VideoPlayerEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0x20) ]
	void VideoPlayerEvent__DelegateSignature(int EventCode, int nParam1, int nParam2, struct FString strMsg);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PandoraVideoPlayer.PVideoImage.UseFileDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7f88
	// Params: [ Num(1) Size(0x1) ]
	void UseFileDelegate(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2928
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoImage.Update
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7f74
	// Params: [ Num(0) Size(0x0) ]
	void Update();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2928
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoImage.SetVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7ef8
	// Params: [ Num(1) Size(0x4) ]
	void SetVolume(int nVolume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF246C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2928
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoImage.SetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7e7c
	// Params: [ Num(1) Size(0x4) ]
	void SetVideoAlpha(float fAlpha);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF29EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF246C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2928
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoImage.SetStopAsyn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7e00
	// Params: [ Num(1) Size(0x4) ]
	void SetStopAsyn(int stopAsyn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2B88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF29EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF246C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2928
	// [Call #13] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoImage.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7d84
	// Params: [ Num(1) Size(0x4) ]
	void SetRate(float nRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2858
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2B88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF29EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF246C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.SetOnlyPlayType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7d08
	// Params: [ Num(1) Size(0x4) ]
	void SetOnlyPlayType(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2064
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2858
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2B88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF29EC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.SetNextVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7c28
	// Params: [ Num(2) Size(0x11) ]
	void SetNextVideo(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF2940
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2064
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2858
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2B88

	// Object: Function PandoraVideoPlayer.PVideoImage.SetNeedVideoTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7ba4
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedVideoTexture(bool needVideoTexture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF27C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF2940
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2064
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2858

	// Object: Function PandoraVideoPlayer.PVideoImage.SetNeedPlayAudio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7b20
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedPlayAudio(bool needPlayAudio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF27DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF27C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2940
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2064

	// Object: Function PandoraVideoPlayer.PVideoImage.SetMediaCodecMaxBufferGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7a94
	// Params: [ Num(2) Size(0x5) ]
	bool SetMediaCodecMaxBufferGap(int maxBufferGap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2BAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF27DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF27C4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2940
	// [Call #15] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.PVideoImage.SetDecryptionKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff79ec
	// Params: [ Num(2) Size(0x14) ]
	int SetDecryptionKey(struct FString decryptionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF201C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2BAC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF27DC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF27C4

	// Object: Function PandoraVideoPlayer.PVideoImage.SetDataUpdateCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7960
	// Params: [ Num(1) Size(0x10) ]
	void SetDataUpdateCallback(struct TScriptInterface<Class> dataUpdateInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2164
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF201C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2BAC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF27DC

	// Object: Function PandoraVideoPlayer.PVideoImage.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff78dc
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool doAutoPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF214C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2164
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF201C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF2BAC

	// Object: Function PandoraVideoPlayer.PVideoImage.SeekMs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7860
	// Params: [ Num(1) Size(0x4) ]
	void SeekMs(int millisec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2320
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF214C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2164
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF201C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.PVideoImage.SeekAndPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff77e4
	// Params: [ Num(1) Size(0x4) ]
	void SeekAndPause(int nMilliSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2360
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2320
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF214C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2164
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.Seek
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7768
	// Params: [ Num(1) Size(0x4) ]
	void Seek(int nSecond);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF22E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2360
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2320
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF214C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.Resume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7754
	// Params: [ Num(0) Size(0x0) ]
	void Resume();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF22E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2360
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2320
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF214C
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.PlayWithFd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7688
	// Params: [ Num(3) Size(0xC) ]
	int PlayWithFd(int nFd, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF1EF8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF22E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2360
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2320

	// Object: Function PandoraVideoPlayer.PVideoImage.PlayOnceAndLoopBetween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7564
	// Params: [ Num(4) Size(0x1C) ]
	int PlayOnceAndLoopBetween(struct FString strUrl, int nStartMs, int nEndMs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF207C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF1EF8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7474
	// Params: [ Num(3) Size(0x18) ]
	int Play(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF1A64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF207C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7460
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF1A64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF207C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.PVideoImage.IsTextureUpdated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff742c
	// Params: [ Num(1) Size(0x1) ]
	bool IsTextureUpdated();
	// [Call #1] RVA: 0x101FF191C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF1A64
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101FF207C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.PVideoImage.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff73f8
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x101FF26E0
	// [Call #2] RVA: 0x101FF191C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF1A64
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF207C

	// Object: Function PandoraVideoPlayer.PVideoImage.IsPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff73c4
	// Params: [ Num(1) Size(0x1) ]
	bool IsPause();
	// [Call #1] RVA: 0x101FF225C
	// [Call #2] RVA: 0x101FF26E0
	// [Call #3] RVA: 0x101FF191C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF1A64
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.IsAlphaVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7390
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlphaVideo();
	// [Call #1] RVA: 0x101FF195C
	// [Call #2] RVA: 0x101FF225C
	// [Call #3] RVA: 0x101FF26E0
	// [Call #4] RVA: 0x101FF191C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF1A64
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.GetYUVFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff735c
	// Params: [ Num(1) Size(0x4) ]
	int GetYUVFormat();
	// [Call #1] RVA: 0x101FF26FC
	// [Call #2] RVA: 0x101FF195C
	// [Call #3] RVA: 0x101FF225C
	// [Call #4] RVA: 0x101FF26E0
	// [Call #5] RVA: 0x101FF191C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF1A64
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.GetVideoTime
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101ff727c
	// Params: [ Num(2) Size(0x8) ]
	void GetVideoTime(float& fCurTime, float& fTotalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF218C
	// [Call #6] RVA: 0x101FF26FC
	// [Call #7] RVA: 0x101FF195C
	// [Call #8] RVA: 0x101FF225C
	// [Call #9] RVA: 0x101FF26E0
	// [Call #10] RVA: 0x101FF191C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.GetVideoTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff71f0
	// Params: [ Num(2) Size(0x10) ]
	struct UTexture2D* GetVideoTexture(int nIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF18DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF218C
	// [Call #9] RVA: 0x101FF26FC
	// [Call #10] RVA: 0x101FF195C
	// [Call #11] RVA: 0x101FF225C
	// [Call #12] RVA: 0x101FF26E0

	// Object: Function PandoraVideoPlayer.PVideoImage.GetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff71bc
	// Params: [ Num(1) Size(0x4) ]
	float GetVideoAlpha();
	// [Call #1] RVA: 0x101FF29FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FF18DC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF218C
	// [Call #10] RVA: 0x101FF26FC
	// [Call #11] RVA: 0x101FF195C
	// [Call #12] RVA: 0x101FF225C

	// Object: Function PandoraVideoPlayer.PVideoImage.GetRgbParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101ff7184
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetRgbParameter();
	// [Call #1] RVA: 0x101FF1A24
	// [Call #2] RVA: 0x101FF29FC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF18DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF218C
	// [Call #11] RVA: 0x101FF26FC
	// [Call #12] RVA: 0x101FF195C

	// Object: Function PandoraVideoPlayer.PVideoImage.GetResolution
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101ff70a4
	// Params: [ Num(2) Size(0x8) ]
	void GetResolution(int& nWidth, int& nHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF222C
	// [Call #6] RVA: 0x101FF1A24
	// [Call #7] RVA: 0x101FF29FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF18DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.GetPlayStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7070
	// Params: [ Num(1) Size(0x4) ]
	int GetPlayStatus();
	// [Call #1] RVA: 0x101FF2910
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF222C
	// [Call #7] RVA: 0x101FF1A24
	// [Call #8] RVA: 0x101FF29FC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF18DC
	// [Call #12] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.GetMediaType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff703c
	// Params: [ Num(1) Size(0x4) ]
	int GetMediaType();
	// [Call #1] RVA: 0x101FF27F4
	// [Call #2] RVA: 0x101FF2910
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF222C
	// [Call #8] RVA: 0x101FF1A24
	// [Call #9] RVA: 0x101FF29FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF18DC

	// Object: Function PandoraVideoPlayer.PVideoImage.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff7008
	// Params: [ Num(1) Size(0x4) ]
	int GetDuration();
	// [Call #1] RVA: 0x101FF271C
	// [Call #2] RVA: 0x101FF27F4
	// [Call #3] RVA: 0x101FF2910
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF222C
	// [Call #9] RVA: 0x101FF1A24
	// [Call #10] RVA: 0x101FF29FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.GetCurrentPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff6fd4
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentPosition();
	// [Call #1] RVA: 0x101FF2758
	// [Call #2] RVA: 0x101FF271C
	// [Call #3] RVA: 0x101FF27F4
	// [Call #4] RVA: 0x101FF2910
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF222C
	// [Call #10] RVA: 0x101FF1A24
	// [Call #11] RVA: 0x101FF29FC
	// [Call #12] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoImage.GetAlphaParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101ff6f9c
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetAlphaParameter();
	// [Call #1] RVA: 0x101FF1A44
	// [Call #2] RVA: 0x101FF2758
	// [Call #3] RVA: 0x101FF271C
	// [Call #4] RVA: 0x101FF27F4
	// [Call #5] RVA: 0x101FF2910
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF222C
	// [Call #11] RVA: 0x101FF1A24
	// [Call #12] RVA: 0x101FF29FC

	// Object: Function PandoraVideoPlayer.PVideoImage.EnableCacheResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff6eb8
	// Params: [ Num(2) Size(0x18) ]
	void EnableCacheResource(bool bEnable, struct FString cachePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF27A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF1A44
	// [Call #10] RVA: 0x101FF2758
	// [Call #11] RVA: 0x101FF271C
	// [Call #12] RVA: 0x101FF27F4
	// [Call #13] RVA: 0x101FF2910
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoImage.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff6ea4
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF27A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF1A44
	// [Call #10] RVA: 0x101FF2758
	// [Call #11] RVA: 0x101FF271C
	// [Call #12] RVA: 0x101FF27F4
	// [Call #13] RVA: 0x101FF2910
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

// Object: Class PandoraVideoPlayer.PVideoPlayerInterface
// Size: 0x28 (Inherited: 0x28)
struct IPVideoPlayerInterface : IInterface
{

	// Object: Function PandoraVideoPlayer.PVideoPlayerInterface.OnAudioDataUpdateCallback
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(7) Size(0x25) ]
	bool OnAudioDataUpdateCallback(struct TArray<uint8_t>& AudioData, int Size, int Samples, int Channels, int sample_rate, float clock);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class PandoraVideoPlayer.PVideoPlayer
// Size: 0x150 (Inherited: 0x28)
struct UPVideoPlayer : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FScriptMulticastDelegate MediaPlayerEventDelegate; // 0x30(0x10)
	uint8_t Pad_0x40[0xD8]; // 0x40(0xD8)
	struct TArray<struct UTexture2D*> m_pTextures; // 0x118(0x10)
	uint8_t Pad_0x128[0x28]; // 0x128(0x28)


	// Object: Function PandoraVideoPlayer.PVideoPlayer.UseFileDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9fdc
	// Params: [ Num(1) Size(0x1) ]
	void UseFileDelegate(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2938
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Update
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9fc8
	// Params: [ Num(0) Size(0x0) ]
	void Update();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2938
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9f4c
	// Params: [ Num(1) Size(0x4) ]
	void SetVolume(int nVolume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF247C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2938
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9ed4
	// Params: [ Num(1) Size(0x4) ]
	void SetVideoAlpha(float fAlpha);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF247C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF2938
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetStopAsyn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff9e60
	// Params: [ Num(1) Size(0x4) ]
	void SetStopAsyn(int stopAsyn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2B9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF247C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2938
	// [Call #12] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9de4
	// Params: [ Num(1) Size(0x4) ]
	void SetRate(float nRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2868
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2B9C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF247C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetOnlyPlayType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9d68
	// Params: [ Num(1) Size(0x4) ]
	void SetOnlyPlayType(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2074
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2868
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2B9C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF247C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetNextVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9c88
	// Params: [ Num(2) Size(0x11) ]
	void SetNextVideo(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF2950
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2074
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2868
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2B9C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetNeedVideoTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9c04
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedVideoTexture(bool bNeedVideoTexture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF27D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF2950
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2074
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2868

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetNeedPlayAudio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9b80
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedPlayAudio(bool bNeedPlayAudio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF27EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF27D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF2950
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2074

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetMediaCodecMaxBufferGap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff9b04
	// Params: [ Num(2) Size(0x5) ]
	bool SetMediaCodecMaxBufferGap(int maxBufferGap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF27EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF27D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF2950
	// [Call #15] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetHardwareDecodec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff9a88
	// Params: [ Num(1) Size(0x1) ]
	void SetHardwareDecodec(bool bHareware);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF3EF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2BBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF27EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF27D4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetDecryptionKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff99e0
	// Params: [ Num(2) Size(0x14) ]
	int SetDecryptionKey(struct FString decryptionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2048
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF3EF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2BBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF27EC
	// [Call #16] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetDataUpdateCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9954
	// Params: [ Num(1) Size(0x10) ]
	void SetDataUpdateCallback(struct TScriptInterface<Class> dataUpdateInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2180
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2048
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF3EF0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF2BBC

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetCachePacketSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff98e0
	// Params: [ Num(1) Size(0x4) ]
	void SetCachePacketSize(int nSizeMb);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF465C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2180
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2048
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF3EF0
	// [Call #16] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff985c
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool bAutoPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF215C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF465C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2180
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2048
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SeekMs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff97e0
	// Params: [ Num(1) Size(0x4) ]
	void SeekMs(int millisec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2330
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF215C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF465C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF2180
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.SeekAndPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9764
	// Params: [ Num(1) Size(0x4) ]
	void SeekAndPause(int nMilliSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF2370
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2330
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF215C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF465C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Seek
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff96e8
	// Params: [ Num(1) Size(0x4) ]
	void Seek(int nSecond);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF22F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2370
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2330
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF215C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Resume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff96d4
	// Params: [ Num(0) Size(0x0) ]
	void Resume();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF22F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2370
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2330
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF215C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.PlayOnceAndLoopBetween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff95b0
	// Params: [ Num(4) Size(0x1C) ]
	int PlayOnceAndLoopBetween(struct FString strUrl, int nStartMs, int nEndMs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF2090
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FF22F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101FF2370

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff94c0
	// Params: [ Num(3) Size(0x18) ]
	int Play(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF1A78
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF2090
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff94ac
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF1A78
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF2090
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: DelegateFunction PandoraVideoPlayer.PVideoPlayer.MediaPlayerEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0x20) ]
	void MediaPlayerEvent__DelegateSignature(int EventCode, int nParam1, int nParam2, struct FString strMsg);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PandoraVideoPlayer.PVideoPlayer.IsTextureUpdated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9478
	// Params: [ Num(1) Size(0x1) ]
	bool IsTextureUpdated();
	// [Call #1] RVA: 0x101FF1944
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF1A78
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101FF2090
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9444
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x101FF26F4
	// [Call #2] RVA: 0x101FF1944
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF1A78
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF2090

	// Object: Function PandoraVideoPlayer.PVideoPlayer.IsPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9410
	// Params: [ Num(1) Size(0x1) ]
	bool IsPause();
	// [Call #1] RVA: 0x101FF2278
	// [Call #2] RVA: 0x101FF26F4
	// [Call #3] RVA: 0x101FF1944
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF1A78
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.IsAlphaVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff93dc
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlphaVideo();
	// [Call #1] RVA: 0x101FF196C
	// [Call #2] RVA: 0x101FF2278
	// [Call #3] RVA: 0x101FF26F4
	// [Call #4] RVA: 0x101FF1944
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF1A78
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.InitPVideo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff93a8
	// Params: [ Num(1) Size(0x1) ]
	bool InitPVideo();
	// [Call #1] RVA: 0x101FF381C
	// [Call #2] RVA: 0x101FF196C
	// [Call #3] RVA: 0x101FF2278
	// [Call #4] RVA: 0x101FF26F4
	// [Call #5] RVA: 0x101FF1944
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF1A78
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetYUVFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9374
	// Params: [ Num(1) Size(0x4) ]
	int GetYUVFormat();
	// [Call #1] RVA: 0x101FF2714
	// [Call #2] RVA: 0x101FF381C
	// [Call #3] RVA: 0x101FF196C
	// [Call #4] RVA: 0x101FF2278
	// [Call #5] RVA: 0x101FF26F4
	// [Call #6] RVA: 0x101FF1944
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF1A78
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetVideoTime
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101ff9294
	// Params: [ Num(2) Size(0x8) ]
	void GetVideoTime(float& fCurTime, float& fTotalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF219C
	// [Call #6] RVA: 0x101FF2714
	// [Call #7] RVA: 0x101FF381C
	// [Call #8] RVA: 0x101FF196C
	// [Call #9] RVA: 0x101FF2278
	// [Call #10] RVA: 0x101FF26F4
	// [Call #11] RVA: 0x101FF1944

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetVideoTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9208
	// Params: [ Num(2) Size(0x10) ]
	struct UTexture2D* GetVideoTexture(int nIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF1900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF219C
	// [Call #9] RVA: 0x101FF2714
	// [Call #10] RVA: 0x101FF381C
	// [Call #11] RVA: 0x101FF196C
	// [Call #12] RVA: 0x101FF2278

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff91ec
	// Params: [ Num(1) Size(0x4) ]
	float GetVideoAlpha();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF1900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF219C
	// [Call #9] RVA: 0x101FF2714
	// [Call #10] RVA: 0x101FF381C
	// [Call #11] RVA: 0x101FF196C
	// [Call #12] RVA: 0x101FF2278

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetRgbParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101ff91b4
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetRgbParameter();
	// [Call #1] RVA: 0x101FF1A3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FF1900
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF219C
	// [Call #10] RVA: 0x101FF2714
	// [Call #11] RVA: 0x101FF381C
	// [Call #12] RVA: 0x101FF196C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetResolution
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101ff90d4
	// Params: [ Num(2) Size(0x8) ]
	void GetResolution(int& nWidth, int& nHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF2248
	// [Call #6] RVA: 0x101FF1A3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF1900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff90b8
	// Params: [ Num(1) Size(0x4) ]
	float GetRate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF2248
	// [Call #6] RVA: 0x101FF1A3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF1900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetPlayStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff909c
	// Params: [ Num(1) Size(0x4) ]
	int GetPlayStatus();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF2248
	// [Call #6] RVA: 0x101FF1A3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF1900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetMediaType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9068
	// Params: [ Num(1) Size(0x4) ]
	int GetMediaType();
	// [Call #1] RVA: 0x101FF2808
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF2248
	// [Call #7] RVA: 0x101FF1A3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FF1900

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9034
	// Params: [ Num(1) Size(0x4) ]
	int GetDuration();
	// [Call #1] RVA: 0x101FF272C
	// [Call #2] RVA: 0x101FF2808
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF2248
	// [Call #8] RVA: 0x101FF1A3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF1900

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetCurrentPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff9000
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentPosition();
	// [Call #1] RVA: 0x101FF2768
	// [Call #2] RVA: 0x101FF272C
	// [Call #3] RVA: 0x101FF2808
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF2248
	// [Call #9] RVA: 0x101FF1A3C
	// [Call #10] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.GetAlphaParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101ff8fc8
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetAlphaParameter();
	// [Call #1] RVA: 0x101FF1A5C
	// [Call #2] RVA: 0x101FF2768
	// [Call #3] RVA: 0x101FF272C
	// [Call #4] RVA: 0x101FF2808
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF2248
	// [Call #10] RVA: 0x101FF1A3C

	// Object: Function PandoraVideoPlayer.PVideoPlayer.EnableCacheResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff8ee4
	// Params: [ Num(2) Size(0x18) ]
	void EnableCacheResource(bool bEnable, struct FString cachePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF27B4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF1A5C
	// [Call #10] RVA: 0x101FF2768
	// [Call #11] RVA: 0x101FF272C
	// [Call #12] RVA: 0x101FF2808
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.PVideoPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ff8ed0
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF27B4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF1A5C
	// [Call #10] RVA: 0x101FF2768
	// [Call #11] RVA: 0x101FF272C
	// [Call #12] RVA: 0x101FF2808
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.PVideoPlayer.ClearCacheResource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101ff8e40
	// Params: [ Num(1) Size(0x10) ]
	void ClearCacheResource(struct FString cachePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF3E14
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF27B4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101FF1A5C
	// [Call #16] RVA: 0x101FF2768
	// [Call #17] RVA: 0x101FF272C
	// [Call #18] RVA: 0x101FF2808

	// Object: Function PandoraVideoPlayer.PVideoPlayer.BlueTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void BlueTick();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PandoraVideoPlayer.PVideoPlayer.BeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void BeginPlay();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class PandoraVideoPlayer.VideoPlayerWidget
// Size: 0x278 (Inherited: 0x260)
struct UVideoPlayerWidget : UUserWidget
{
	struct UPVideoImage* PVideoImage_Instance; // 0x260(0x8)
	struct FScriptMulticastDelegate OnPlayerEventDelegate; // 0x268(0x10)


	// Object: DelegateFunction PandoraVideoPlayer.VideoPlayerWidget.VideoPlayerEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0x20) ]
	void VideoPlayerEvent__DelegateSignature(int nEvent, int nArg1, int nArg2, struct FString sMsg);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.UseFileDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbdb0
	// Params: [ Num(1) Size(0x1) ]
	void UseFileDelegate(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4770
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbd34
	// Params: [ Num(1) Size(0x4) ]
	void SetVolume(int nVolume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4770
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbcb8
	// Params: [ Num(1) Size(0x4) ]
	void SetVideoAlpha(float fAlpha);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4944
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF46E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4770
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetStopAsyn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbc3c
	// Params: [ Num(1) Size(0x4) ]
	void SetStopAsyn(int stopAsyn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4974
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4944
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF46E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF4770
	// [Call #13] RVA: 0x10519022C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbbc0
	// Params: [ Num(1) Size(0x4) ]
	void SetRate(float nRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF474C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4974
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4944
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF46E4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetOnlyPlayType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffbb44
	// Params: [ Num(1) Size(0x4) ]
	void SetOnlyPlayType(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4684
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF474C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4974
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF4944
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetNextVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffba64
	// Params: [ Num(2) Size(0x11) ]
	void SetNextVideo(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF493C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF4684
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF474C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF4974

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetNeedVideoTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb9e0
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedVideoTexture(bool needVideoTexture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4724
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF493C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF4684
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF474C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetNeedPlayAudio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb95c
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedPlayAudio(bool needPlayAudio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4738
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4724
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF493C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FF4684

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetMediaCodecMaxBufferGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb8d0
	// Params: [ Num(2) Size(0x5) ]
	bool SetMediaCodecMaxBufferGap(int maxBufferGap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF497C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4738
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4724
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF493C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetHardwareDecodec
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb84c
	// Params: [ Num(1) Size(0x1) ]
	void SetHardwareDecodec(bool bHardWare);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4934
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF497C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4738
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF4724
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetDecryptionKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb7a4
	// Params: [ Num(2) Size(0x14) ]
	int SetDecryptionKey(struct FString decryptionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF467C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4934
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF497C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF4738

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetDataUpdateCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb718
	// Params: [ Num(1) Size(0x10) ]
	void SetDataUpdateCallback(struct TScriptInterface<Class> dataUpdateInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF4704
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF467C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF4934
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF497C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb694
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool doAutoPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF4704
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF467C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF4934

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SeekMs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb618
	// Params: [ Num(1) Size(0x4) ]
	void SeekMs(int nMilliSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF46A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF4704
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF467C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.SeekAndPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb59c
	// Params: [ Num(1) Size(0x4) ]
	void SeekAndPause(int nMilliSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF46D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF46A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF4704
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.Seek
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb520
	// Params: [ Num(1) Size(0x4) ]
	void Seek(int nSecond);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF46DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF46D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF46A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.Resume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb50c
	// Params: [ Num(0) Size(0x0) ]
	void Resume();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF46CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FF46DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FF46D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FF46A0
	// [Call #13] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.PlayWithFd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb440
	// Params: [ Num(3) Size(0xC) ]
	int PlayWithFd(int nFd, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF4674
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FF46CC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF46DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FF46D4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.PlayOnceAndLoopBetween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb31c
	// Params: [ Num(4) Size(0x1C) ]
	int PlayOnceAndLoopBetween(struct FString strUrl, int nStartMs, int nEndMs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FF4698
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF4674
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.Play1
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb22c
	// Params: [ Num(3) Size(0x18) ]
	int Play1(struct FString strUrl, bool bLoop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF466C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF4698
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb218
	// Params: [ Num(0) Size(0x0) ]
	void Pause();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF466C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FF4698
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.OnPlayerEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb070
	// Params: [ Num(4) Size(0x20) ]
	void OnPlayerEvent(int EventCode, int nParam1, int nParam2, struct FString strMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101FF4784
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.GetVideoAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb03c
	// Params: [ Num(1) Size(0x4) ]
	float GetVideoAlpha();
	// [Call #1] RVA: 0x101FF4958
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101FF4784
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.GetPlayStatus1
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffb008
	// Params: [ Num(1) Size(0x4) ]
	int GetPlayStatus1();
	// [Call #1] RVA: 0x101FF4754
	// [Call #2] RVA: 0x101FF4958
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101FF4784
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.GetDuration1
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffafd4
	// Params: [ Num(1) Size(0x4) ]
	int GetDuration1();
	// [Call #1] RVA: 0x101FF46EC
	// [Call #2] RVA: 0x101FF4754
	// [Call #3] RVA: 0x101FF4958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101FF4784
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.GetCurrentPosition1
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffafa0
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentPosition1();
	// [Call #1] RVA: 0x101FF46F4
	// [Call #2] RVA: 0x101FF46EC
	// [Call #3] RVA: 0x101FF4754
	// [Call #4] RVA: 0x101FF4958
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101FF4784
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.EnableCacheResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffaebc
	// Params: [ Num(2) Size(0x18) ]
	void EnableCacheResource(bool bEnable, struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF46FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF46F4
	// [Call #10] RVA: 0x101FF46EC
	// [Call #11] RVA: 0x101FF4754
	// [Call #12] RVA: 0x101FF4958
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffaea8
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FF46FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FF46F4
	// [Call #10] RVA: 0x101FF46EC
	// [Call #11] RVA: 0x101FF4754
	// [Call #12] RVA: 0x101FF4958
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PandoraVideoPlayer.VideoPlayerWidget.ClearCacheResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101ffae10
	// Params: [ Num(1) Size(0x10) ]
	void ClearCacheResource(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FF492C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FF46FC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101FF46F4
	// [Call #16] RVA: 0x101FF46EC
	// [Call #17] RVA: 0x101FF4754
	// [Call #18] RVA: 0x101FF4958
};

