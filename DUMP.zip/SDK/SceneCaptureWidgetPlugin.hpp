#pragma once

#include <cstdint>

// Object: Class SceneCaptureWidgetPlugin.WidgetCaptureComponent2D
// Size: 0xA30 (Inherited: 0xA10)
struct UWidgetCaptureComponent2D : USceneCaptureComponent2D
{
	struct ASceneCaptureCameraActor* OwnerCameraActor; // 0xA10(0x8)
	uint8_t Pad_0xA18[0x18]; // 0xA18(0x18)
};

// Object: Class SceneCaptureWidgetPlugin.SceneCaptureCameraActor
// Size: 0xA50 (Inherited: 0xA40)
struct ASceneCaptureCameraActor : ACameraActor
{
	struct UWidgetCaptureComponent2D* SceneCaptureComponent; // 0xA40(0x8)
	uint8_t Pad_0xA48[0x8]; // 0xA48(0x8)
};

// Object: Class SceneCaptureWidgetPlugin.SceneCaptureWidget
// Size: 0x1E0 (Inherited: 0x100)
struct USceneCaptureWidget : UWidget
{
	struct FSlateBrush Brush; // 0x100(0xB8)
	struct ASceneCaptureCameraActor* SceneCaptureCameraActor; // 0x1B8(0x8)
	uint8_t Pad_0x1C0[0x20]; // 0x1C0(0x20)


	// Object: Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fffa98
	// Params: [ Num(1) Size(0x8) ]
	void SetSceneCaptureCameraActor(struct ASceneCaptureCameraActor* InSceneCaptureCameraActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FFD994
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10518559C
	// [Call #8] RVA: 0x10518559C
};

