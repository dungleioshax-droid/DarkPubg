#pragma once

#include <cstdint>

// Object: Enum CustomLayout.EAnchorsType
enum class EAnchorsType : uint8_t
{
	TopLeft = 0,
	TopCenter = 1,
	TopRight = 2,
	MidLeft = 3,
	MidCenter = 4,
	MidRight = 5,
	BottomLeft = 6,
	BottomCenter = 7,
	BottomRight = 8,
	Other = 9,
	EAnchorsType_MAX = 10
};

// Object: Enum CustomLayout.ESCPDisplayState
enum class ESCPDisplayState : uint8_t
{
	Foreground = 1,
	Background = 2,
	Hidden = 3,
	ESCPDisplayState_MAX = 4
};

// Object: ScriptStruct CustomLayout.CustomLayoutBlueprintCode
// Size: 0x8 (Inherited: 0x0)
struct FCustomLayoutBlueprintCode
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct CustomLayout.DynamicCustomConfig
// Size: 0x2 (Inherited: 0x0)
struct FDynamicCustomConfig
{
	bool bIsShowInLobby; // 0x0(0x1)
	bool bIgnoreDPIScale; // 0x1(0x1)
};

// Object: ScriptStruct CustomLayout.DynamicCustomInfo
// Size: 0x18 (Inherited: 0x0)
struct FDynamicCustomInfo
{
	struct UUserWidget* DynamicCustomAsset; // 0x0(0x8)
	struct TArray<int> CustomTypes; // 0x8(0x10)
};

// Object: ScriptStruct CustomLayout.UIElemLayoutDetail
// Size: 0x28 (Inherited: 0x0)
struct FUIElemLayoutDetail
{
	int Type; // 0x0(0x4)
	float Opacity; // 0x4(0x4)
	float Scale; // 0x8(0x4)
	struct FAnchors AnchorType; // 0xC(0x10)
	struct FVector2D RelativePos; // 0x1C(0x8)
	bool Invalid; // 0x24(0x1)
	uint8_t Pad_0x25[0x3]; // 0x25(0x3)
};

// Object: ScriptStruct CustomLayout.TouchStatInfo
// Size: 0x8 (Inherited: 0x0)
struct FTouchStatInfo
{
	int CustomType; // 0x0(0x4)
	uint16_t ScreenSpaceX; // 0x4(0x2)
	uint16_t ScreenSpaceY; // 0x6(0x2)
};

// Object: Class CustomLayout.CustomizePanel
// Size: 0x168 (Inherited: 0x130)
struct UCustomizePanel : UCanvasPanel
{
	struct FScriptMulticastDelegate OnCustomLayoutChangeEvent; // 0x130(0x10)
	struct FMargin DetectMargin; // 0x140(0x10)
	struct FCustomLayoutBlueprintCode DefaultLayoutCode; // 0x150(0x8)
	int CustomType; // 0x158(0x4)
	float Opacity; // 0x15C(0x4)
	bool bInvalid; // 0x160(0x1)
	bool bInterceptChildInput; // 0x161(0x1)
	bool bMovable; // 0x162(0x1)
	uint8_t Pad_0x163[0x5]; // 0x163(0x5)


	// Object: Function CustomLayout.CustomizePanel.SetScale
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102724760
	// Params: [ Num(1) Size(0x4) ]
	void SetScale(float Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190648
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648
	// [Call #9] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomizePanel.SetPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1027246d8
	// Params: [ Num(1) Size(0x8) ]
	void SetPosition(struct FVector2D& Position);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D0CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190648
	// [Call #10] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomizePanel.SetOpacityWithClamp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027245e8
	// Params: [ Num(3) Size(0xC) ]
	void SetOpacityWithClamp(float InOpacity, float MinOpacity, float MaxOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271CCF0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D0CC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomizePanel.SetOpacity
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102724564
	// Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271CCF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271D0CC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.SetMovable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027244e0
	// Params: [ Num(1) Size(0x1) ]
	void SetMovable(bool bInMovable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271C444
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271CCF0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.SetMaxScale
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x102724464
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxScale(float Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D684
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271C444
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.SetInvalid
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1027243d8
	// Params: [ Num(1) Size(0x1) ]
	void SetInvalid(bool Invalid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271D684
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271C444
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetInterceptChildInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102724354
	// Params: [ Num(1) Size(0x1) ]
	void SetInterceptChildInput(bool bInIntercept);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271C3DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271D684
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271C444
	// [Call #12] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDrawMargin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027242d0
	// Params: [ Num(1) Size(0x1) ]
	void SetDrawMargin(bool bDraw);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D914
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271C3DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271D684
	// [Call #12] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDetectMargin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102724244
	// Params: [ Num(1) Size(0x10) ]
	void SetDetectMargin(struct FMargin& InMargin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271C35C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271D914
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271C3DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDesireScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027241c8
	// Params: [ Num(1) Size(0x4) ]
	void SetDesireScale(float Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271CF44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271C35C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271D914
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271C3DC
	// [Call #13] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDesirePosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102724140
	// Params: [ Num(1) Size(0x8) ]
	void SetDesirePosition(struct FVector2D& Position);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271CA74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271CF44
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271C35C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271D914
	// [Call #13] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDefaultLayoutCode
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027240b0
	// Params: [ Num(1) Size(0x8) ]
	void SetDefaultLayoutCode(struct FCustomLayoutBlueprintCode& InCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D444
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271CA74
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271CF44
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271C35C
	// [Call #13] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.SetDefaultLayoutByPositionAndAnchors
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102723fd4
	// Params: [ Num(2) Size(0x18) ]
	void SetDefaultLayoutByPositionAndAnchors(struct FVector2D& InPosition, struct FAnchors& InAnchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271D454
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271D444
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271CA74
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.SetCustomType
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102723f50
	// Params: [ Num(1) Size(0x4) ]
	void SetCustomType(int NewType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271D454
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D444
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.RestoreInBound
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x102723f3c
	// Params: [ Num(0) Size(0x0) ]
	void RestoreInBound();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271D454
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D444
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.ResetMaxScale
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x102723f28
	// Params: [ Num(0) Size(0x0) ]
	void ResetMaxScale();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271D454
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D444
	// [Call #11] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.IsOutOfBound
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723e9c
	// Params: [ Num(2) Size(0x5) ]
	bool IsOutOfBound(float InvisibleCheckOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D698
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D454
	// [Call #11] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.InitDefaultLayoutData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102723e88
	// Params: [ Num(0) Size(0x0) ]
	void InitDefaultLayoutData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D698
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271D454

	// Object: Function CustomLayout.CustomizePanel.GetScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723e54
	// Params: [ Num(1) Size(0x4) ]
	float GetScale();
	// [Call #1] RVA: 0x10271D0C4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10271D698
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271D454

	// Object: Function CustomLayout.CustomizePanel.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723e20
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPosition();
	// [Call #1] RVA: 0x10271CAD0
	// [Call #2] RVA: 0x10271D0C4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271D698
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.GetOpacity
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723de4
	// Params: [ Num(1) Size(0x4) ]
	float GetOpacity();
	// [Call #1] RVA: 0x10271CAD0
	// [Call #2] RVA: 0x10271D0C4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271D698
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.GetMovable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723db0
	// Params: [ Num(1) Size(0x1) ]
	bool GetMovable();
	// [Call #1] RVA: 0x10271CB14
	// [Call #2] RVA: 0x10271CAD0
	// [Call #3] RVA: 0x10271D0C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271D698
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.GetMaxScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723d7c
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxScale();
	// [Call #1] RVA: 0x10271CF94
	// [Call #2] RVA: 0x10271CB14
	// [Call #3] RVA: 0x10271CAD0
	// [Call #4] RVA: 0x10271D0C4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271D698
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomizePanel.GetLayoutData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723d2c
	// Params: [ Num(1) Size(0x28) ]
	struct FUIElemLayoutDetail GetLayoutData();
	// [Call #1] RVA: 0x10271D2C8
	// [Call #2] RVA: 0x10271CF94
	// [Call #3] RVA: 0x10271CB14
	// [Call #4] RVA: 0x10271CAD0
	// [Call #5] RVA: 0x10271D0C4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271D698
	// [Call #9] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomizePanel.GetLayoutCode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723cf8
	// Params: [ Num(1) Size(0x8) ]
	struct FCustomLayoutBlueprintCode GetLayoutCode();
	// [Call #1] RVA: 0x10271D4C8
	// [Call #2] RVA: 0x10271D2C8
	// [Call #3] RVA: 0x10271CF94
	// [Call #4] RVA: 0x10271CB14
	// [Call #5] RVA: 0x10271CAD0
	// [Call #6] RVA: 0x10271D0C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271D698

	// Object: Function CustomLayout.CustomizePanel.GetInvalid
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723cbc
	// Params: [ Num(1) Size(0x1) ]
	bool GetInvalid();
	// [Call #1] RVA: 0x10271D4C8
	// [Call #2] RVA: 0x10271D2C8
	// [Call #3] RVA: 0x10271CF94
	// [Call #4] RVA: 0x10271CB14
	// [Call #5] RVA: 0x10271CAD0
	// [Call #6] RVA: 0x10271D0C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271D698

	// Object: Function CustomLayout.CustomizePanel.GetDefaultLayoutData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723c6c
	// Params: [ Num(1) Size(0x28) ]
	struct FUIElemLayoutDetail GetDefaultLayoutData();
	// [Call #1] RVA: 0x10271D3D8
	// [Call #2] RVA: 0x10271D4C8
	// [Call #3] RVA: 0x10271D2C8
	// [Call #4] RVA: 0x10271CF94
	// [Call #5] RVA: 0x10271CB14
	// [Call #6] RVA: 0x10271CAD0
	// [Call #7] RVA: 0x10271D0C4

	// Object: Function CustomLayout.CustomizePanel.GetCustomType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723c38
	// Params: [ Num(1) Size(0x4) ]
	int GetCustomType();
	// [Call #1] RVA: 0x1027197CC
	// [Call #2] RVA: 0x10271D3D8
	// [Call #3] RVA: 0x10271D4C8
	// [Call #4] RVA: 0x10271D2C8
	// [Call #5] RVA: 0x10271CF94
	// [Call #6] RVA: 0x10271CB14
	// [Call #7] RVA: 0x10271CAD0
	// [Call #8] RVA: 0x10271D0C4

	// Object: Function CustomLayout.CustomizePanel.ClampPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102723ba0
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D ClampPosition(struct FVector2D& DesiredPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D110
	// [Call #4] RVA: 0x1027197CC
	// [Call #5] RVA: 0x10271D3D8
	// [Call #6] RVA: 0x10271D4C8
	// [Call #7] RVA: 0x10271D2C8
	// [Call #8] RVA: 0x10271CF94
	// [Call #9] RVA: 0x10271CB14

	// Object: Function CustomLayout.CustomizePanel.ApplyLayoutData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102723afc
	// Params: [ Num(1) Size(0x28) ]
	void ApplyLayoutData(struct FUIElemLayoutDetail& LayoutDetail);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719850
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271D110
	// [Call #7] RVA: 0x1027197CC
	// [Call #8] RVA: 0x10271D3D8
	// [Call #9] RVA: 0x10271D4C8

	// Object: Function CustomLayout.CustomizePanel.ApplyLayoutCode
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102723a6c
	// Params: [ Num(1) Size(0x8) ]
	void ApplyLayoutCode(struct FCustomLayoutBlueprintCode& InCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D5E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102719850
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271D110
	// [Call #10] RVA: 0x1027197CC
	// [Call #11] RVA: 0x10271D3D8

	// Object: Function CustomLayout.CustomizePanel.ApplyDefaultLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102723a58
	// Params: [ Num(0) Size(0x0) ]
	void ApplyDefaultLayout();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271D5E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102719850
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271D110
	// [Call #10] RVA: 0x1027197CC
	// [Call #11] RVA: 0x10271D3D8
};

// Object: Class CustomLayout.CustomLayoutBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCustomLayoutBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.MakeLayoutDetail
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10272578c
	// Params: [ Num(4) Size(0x38) ]
	struct FUIElemLayoutDetail MakeLayoutDetail(int Type, uint8_t AnchorType, struct FVector2D Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271AA88
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x1051903D0
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TypeToAnchors
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10272570c
	// Params: [ Num(2) Size(0x14) ]
	struct FAnchors Conv_TypeToAnchors(uint8_t InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271AD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271AA88
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x1051903D0
	// [Call #13] RVA: 0x105190870

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TouchStatInfoToLong
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x102725680
	// Params: [ Num(2) Size(0x10) ]
	uint64_t Conv_TouchStatInfoToLong(struct FTouchStatInfo& Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271AECC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271AD38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10271AA88
	// [Call #14] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LongToTouchStatInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x1027255f4
	// Params: [ Num(2) Size(0x10) ]
	struct FTouchStatInfo Conv_LongToTouchStatInfo(uint64_t& Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271AEE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271AECC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271AD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LayoutDetailToCode
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102725550
	// Params: [ Num(2) Size(0x30) ]
	struct FCustomLayoutBlueprintCode Conv_LayoutDetailToCode(struct FUIElemLayoutDetail& InDetail);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271ADD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271AEE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271AECC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271AD38

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_CodeToLayoutDetail
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102725468
	// Params: [ Num(3) Size(0x34) ]
	struct FUIElemLayoutDetail Conv_CodeToLayoutDetail(struct FCustomLayoutBlueprintCode& InCode, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271AD3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271ADD8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271AEE8
	// [Call #12] RVA: 0x10516D168

	// Object: Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_AnchorsToType
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027253dc
	// Params: [ Num(2) Size(0x11) ]
	uint8_t Conv_AnchorsToType(struct FAnchors& InAnchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271AB1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271AD3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271ADD8
	// [Call #12] RVA: 0x10516D168
};

// Object: Class CustomLayout.CustomLayoutSubsystem
// Size: 0xA8 (Inherited: 0x30)
struct UCustomLayoutSubsystem : UGameInstanceSubsystem
{
	struct TArray<struct UCustomLayoutUserSetting*> UserSettingSlots; // 0x30(0x10)
	struct FScriptMulticastDelegate OnPanelTouchPreview; // 0x40(0x10)
	uint8_t Pad_0x50[0x58]; // 0x50(0x58)


	// Object: Function CustomLayout.CustomLayoutSubsystem.UnregisterCustomPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027262c8
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterCustomPanel(struct UCustomPanel* InCustomizePanel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719A28
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutSubsystem.SetScreenPadding
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102726244
	// Params: [ Num(1) Size(0x10) ]
	void SetScreenPadding(struct FMargin& InOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271A1E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102719A28
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutSubsystem.SetEditMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027261c0
	// Params: [ Num(1) Size(0x1) ]
	void SetEditMode(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719F88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271A1E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102719A28
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutSubsystem.RemoveUserSettingSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102726144
	// Params: [ Num(1) Size(0x8) ]
	void RemoveUserSettingSlot(struct UCustomLayoutUserSetting* InUserSetting);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027192D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102719F88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271A1E8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102719A28
	// [Call #13] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutSubsystem.RegisterCustomPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027260c8
	// Params: [ Num(1) Size(0x8) ]
	void RegisterCustomPanel(struct UCustomPanel* InCustomizePanel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719598
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1027192D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102719F88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271A1E8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomLayoutSubsystem.InsertUserSettingSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102726010
	// Params: [ Num(2) Size(0xC) ]
	void InsertUserSettingSlot(struct UCustomLayoutUserSetting* InUserSetting, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102719158
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102719598
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027192D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719F88

	// Object: Function CustomLayout.CustomLayoutSubsystem.GetUserSettingInSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725f68
	// Params: [ Num(2) Size(0x18) ]
	struct UCustomLayoutUserSetting* GetUserSettingInSlot(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102718FA4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102719158
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719598
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1027192D4

	// Object: Function CustomLayout.CustomLayoutSubsystem.GetRegisteredPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725edc
	// Params: [ Num(2) Size(0x10) ]
	struct UCustomPanel* GetRegisteredPanel(int InCustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719E28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102718FA4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719158
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102719598

	// Object: Function CustomLayout.CustomLayoutSubsystem.FlushRegisteredPanelMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725ec8
	// Params: [ Num(0) Size(0x0) ]
	void FlushRegisteredPanelMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719E28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102718FA4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719158
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function CustomLayout.CustomLayoutSubsystem.FindLayoutDetail
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102725ddc
	// Params: [ Num(3) Size(0x2D) ]
	bool FindLayoutDetail(int InCustomType, struct FUIElemLayoutDetail& OutDetail);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102719308
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102719E28
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102718FA4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function CustomLayout.CustomLayoutSubsystem.ClearUserSettingSlots
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725dc8
	// Params: [ Num(0) Size(0x0) ]
	void ClearUserSettingSlots();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102719308
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102719E28
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102718FA4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function CustomLayout.CustomLayoutSubsystem.ClearRegisteredPanelMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725db4
	// Params: [ Num(0) Size(0x0) ]
	void ClearRegisteredPanelMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102719308
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102719E28
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102718FA4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C

	// Object: Function CustomLayout.CustomLayoutSubsystem.BroadcastCustomLayoutChange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102725d0c
	// Params: [ Num(1) Size(0x10) ]
	void BroadcastCustomLayoutChange(struct TArray<int>& InCustomTypeList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719AF0
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102719308
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719E28

	// Object: Function CustomLayout.CustomLayoutSubsystem.AddUserSettingSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102725c90
	// Params: [ Num(1) Size(0x8) ]
	void AddUserSettingSlot(struct UCustomLayoutUserSetting* InUserSetting);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102719074
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102719AF0
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102719308
};

// Object: Class CustomLayout.CustomLayoutUserSetting
// Size: 0xA0 (Inherited: 0x28)
struct UCustomLayoutUserSetting : USaveGame
{
	int CodecVersion; // 0x28(0x4)
	int ViewportWidth; // 0x2C(0x4)
	int ViewportHeight; // 0x30(0x4)
	float ViewportScale; // 0x34(0x4)
	struct FDateTime TimeTag; // 0x38(0x8)
	struct FString SaveSlotName; // 0x40(0x10)
	struct TMap<int, uint64_t> LayoutCodeMap; // 0x50(0x50)


	// Object: Function CustomLayout.CustomLayoutUserSetting.UpdateTimeTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102726c44
	// Params: [ Num(0) Size(0x0) ]
	void UpdateTimeTag();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutUserSetting.SetTimeTagFromUnixTimestamp
	// Flags: [Final|Native|Public]
	// Offset: 0x102726bc8
	// Params: [ Num(1) Size(0x8) ]
	void SetTimeTagFromUnixTimestamp(int64_t InUnixTimestamp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271B278
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutUserSetting.SetDataByLayoutDetail
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102726aec
	// Params: [ Num(2) Size(0x2C) ]
	void SetDataByLayoutDetail(int InCustomType, struct FUIElemLayoutDetail& InData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271B0F8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271B278
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutUserSetting.RemoveData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102726a70
	// Params: [ Num(1) Size(0x4) ]
	void RemoveData(int InCustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271B180
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271B0F8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271B278
	// [Call #12] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutUserSetting.GetTimeTagAsUnixTimestamp
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102726a3c
	// Params: [ Num(1) Size(0x8) ]
	int64_t GetTimeTagAsUnixTimestamp();
	// [Call #1] RVA: 0x10271B270
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10271B180
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271B0F8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271B278
	// [Call #13] RVA: 0x10519022C

	// Object: Function CustomLayout.CustomLayoutUserSetting.GetLayoutCodeCheckSum
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102726a08
	// Params: [ Num(1) Size(0x8) ]
	uint64_t GetLayoutCodeCheckSum();
	// [Call #1] RVA: 0x10271B2F8
	// [Call #2] RVA: 0x10271B270
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271B180
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271B0F8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10271B278

	// Object: Function CustomLayout.CustomLayoutUserSetting.GetDataAsLayoutDetail
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102726968
	// Params: [ Num(2) Size(0x2C) ]
	struct FUIElemLayoutDetail GetDataAsLayoutDetail(int InCustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271947C
	// [Call #4] RVA: 0x10271B2F8
	// [Call #5] RVA: 0x10271B270
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271B180
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10271B0F8

	// Object: Function CustomLayout.CustomLayoutUserSetting.GetCustomTypeList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027268c0
	// Params: [ Num(1) Size(0x10) ]
	void GetCustomTypeList(struct TArray<int>& OutKeys);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271B420
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271947C
	// [Call #10] RVA: 0x10271B2F8
	// [Call #11] RVA: 0x10271B270
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10271B180

	// Object: Function CustomLayout.CustomLayoutUserSetting.Contains
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102726834
	// Params: [ Num(2) Size(0x5) ]
	bool Contains(int InCustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271945C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271B420
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271947C
	// [Call #13] RVA: 0x10271B2F8
	// [Call #14] RVA: 0x10271B270
};

// Object: Class CustomLayout.CustomPanel
// Size: 0x170 (Inherited: 0x168)
struct UCustomPanel : UCustomizePanel
{
	uint8_t Pad_0x168[0x8]; // 0x168(0x8)


	// Object: Function CustomLayout.CustomPanel.UpdateCustomLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102727148
	// Params: [ Num(0) Size(0x0) ]
	void UpdateCustomLayout();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x1027239F0
	// [Call #6] RVA: 0x105184F34
	// [Call #7] RVA: 0x105190648
	// [Call #8] RVA: 0x1036A6C08

	// Object: Function CustomLayout.CustomPanel.SetEditable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027270c4
	// Params: [ Num(1) Size(0x1) ]
	void SetEditable(bool bEditable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027197D4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x1027239F0
};

// Object: Class CustomLayout.DynamicCustomIndexer
// Size: 0xD0 (Inherited: 0x30)
struct UDynamicCustomIndexer : UDataAsset
{
	struct TMap<struct FString, struct FDynamicCustomInfo> InfoMap; // 0x30(0x50)
	struct TMap<int, struct FAnchorData> DefaultLayoutData; // 0x80(0x50)


	// Object: Function CustomLayout.DynamicCustomIndexer.GetIndexer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102727640
	// Params: [ Num(2) Size(0x18) ]
	struct UDynamicCustomIndexer* GetIndexer(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271B590
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C

	// Object: Function CustomLayout.DynamicCustomIndexer.GetDefaultLayoutCode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027275b4
	// Params: [ Num(2) Size(0x10) ]
	struct FCustomLayoutBlueprintCode GetDefaultLayoutCode(int CustomType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271B6EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271B590
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function CustomLayout.DynamicCustomIndexer.CreateDynamicCustomWidgets
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1027273d0
	// Params: [ Num(5) Size(0xC0) ]
	struct TMap<int, struct UCustomizePanel*> CreateDynamicCustomWidgets(struct TArray<int>& InCustomTypeList, struct TMap<int, struct UCustomizePanel*>& CustomPanelMap, struct UCanvasPanel* Container, bool bIgnoreDPIScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102729258
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271B780
	// [Call #11] RVA: 0x102729274
	// [Call #12] RVA: 0x10272934C
	// [Call #13] RVA: 0x10272934C
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x10272934C
	// [Call #16] RVA: 0x10272934C
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10271B6EC
};

// Object: Class CustomLayout.PinchDragWidget
// Size: 0x2A8 (Inherited: 0x260)
struct UPinchDragWidget : UUserWidget
{
	DelegateProperty OnDrag; // 0x260(0x10)
	DelegateProperty OnPinch; // 0x270(0x10)
	DelegateProperty OnRelease; // 0x280(0x10)
	uint8_t Pad_0x290[0x18]; // 0x290(0x18)


	// Object: Function CustomLayout.PinchDragWidget.SetPinchEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102727c5c
	// Params: [ Num(1) Size(0x1) ]
	void SetPinchEnabled(bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function CustomLayout.PinchDragWidget.SetDragEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102727bf0
	// Params: [ Num(1) Size(0x1) ]
	void SetDragEnabled(bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function CustomLayout.PinchDragWidget.ScreenDeltaToParentLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102727b2c
	// Params: [ Num(3) Size(0x18) ]
	struct FVector2D ScreenDeltaToParentLocal(struct UWidget* Widget, struct FVector2D& ScreenDelta);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271DFFC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function CustomLayout.PinchDragWidget.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102727b18
	// Params: [ Num(0) Size(0x0) ]
	void Reset();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271DFFC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function CustomLayout.PinchDragWidget.IsPinchEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102727ae0
	// Params: [ Num(1) Size(0x1) ]
	bool IsPinchEnabled();
	// [Call #1] RVA: 0x101F83AC0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271DFFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function CustomLayout.PinchDragWidget.IsFirstPointIndex
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027279d8
	// Params: [ Num(2) Size(0x79) ]
	bool IsFirstPointIndex(struct FPointerEvent& InPointerEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10220D174
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x101F83AC0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271DFFC
	// [Call #12] RVA: 0x10516D168

	// Object: Function CustomLayout.PinchDragWidget.IsDragEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027279a0
	// Params: [ Num(1) Size(0x1) ]
	bool IsDragEnabled();
	// [Call #1] RVA: 0x101F83AC0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10220D174
	// [Call #5] RVA: 0x10220D174
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F83AC0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10271DFFC
};

// Object: Class CustomLayout.SettingCustomPanel
// Size: 0x1E0 (Inherited: 0x168)
struct USettingCustomPanel : UCustomizePanel
{
	uint8_t DisplayState; // 0x168(0x1)
	uint8_t Pad_0x169[0x7]; // 0x169(0x7)
	struct UMaterialInterface* SelectedImageCircularFlashEffectMaterial; // 0x170(0x8)
	struct UMaterialInterface* SelectedImageSquareFlashEffectMaterial; // 0x178(0x8)
	uint8_t Pad_0x180[0x10]; // 0x180(0x10)
	struct TMap<struct FString, struct TWeakObjectPtr<struct UWidget>> WidgetPtrMap; // 0x190(0x50)


	// Object: Function CustomLayout.SettingCustomPanel.SetSelectedImageOriginEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102728680
	// Params: [ Num(0) Size(0x0) ]
	void SetSelectedImageOriginEffect();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function CustomLayout.SettingCustomPanel.SetSelectedImageFlashEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10272866c
	// Params: [ Num(0) Size(0x0) ]
	void SetSelectedImageFlashEffect();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function CustomLayout.SettingCustomPanel.SetDisplayState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027285f0
	// Params: [ Num(1) Size(0x1) ]
	void SetDisplayState(uint8_t State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271EAFC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function CustomLayout.SettingCustomPanel.OnTouchPreview
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnTouchPreview();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CustomLayout.SettingCustomPanel.IsSquareFlashEffectAssetName
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x11) ]
	bool IsSquareFlashEffectAssetName(struct FString InAssetName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CustomLayout.SettingCustomPanel.IsCircleFlashEffectAssetName
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x11) ]
	bool IsCircleFlashEffectAssetName(struct FString InAssetName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function CustomLayout.SettingCustomPanel.GetWidgetByType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10272852c
	// Params: [ Num(3) Size(0x18) ]
	struct UWidget* GetWidgetByType(struct UWidget* RootWidget, struct UWidget* WidgetType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271ECB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271EAFC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function CustomLayout.SettingCustomPanel.GetSelectedImage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027284f8
	// Params: [ Num(1) Size(0x8) ]
	struct UImage* GetSelectedImage();
	// [Call #1] RVA: 0x10271EB68
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271ECB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10271EAFC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function CustomLayout.SettingCustomPanel.GetParentWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027284c4
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetParentWidget();
	// [Call #1] RVA: 0x10271EC34
	// [Call #2] RVA: 0x10271EB68
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10271ECB8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10271EAFC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function CustomLayout.SettingCustomPanel.GetNamedWidgetFromOwner
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027283d0
	// Params: [ Num(2) Size(0x18) ]
	struct UWidget* GetNamedWidgetFromOwner(struct FString Prefix);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10271EA58
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10271EC34
	// [Call #13] RVA: 0x10271EB68
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10271ECB8
	// [Call #19] RVA: 0x10516D168

	// Object: Function CustomLayout.SettingCustomPanel.GetInvalidImage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10272839c
	// Params: [ Num(1) Size(0x8) ]
	struct UImage* GetInvalidImage();
	// [Call #1] RVA: 0x10271E8A4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x10271EA58
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10271EC34
	// [Call #14] RVA: 0x10271EB68
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10271ECB8

	// Object: Function CustomLayout.SettingCustomPanel.GetCenterPositionInScreenSpace
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102728310
	// Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetCenterPositionInScreenSpace(struct UWidget* FullScreenWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271EFD4
	// [Call #4] RVA: 0x10271E8A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x10271EA58
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10271EC34
	// [Call #17] RVA: 0x10271EB68
	// [Call #18] RVA: 0x10516D168

	// Object: Function CustomLayout.SettingCustomPanel.FlashHighlight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102728294
	// Params: [ Num(1) Size(0x4) ]
	void FlashHighlight(float Seconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271F104
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10271EFD4
	// [Call #7] RVA: 0x10271E8A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x10271EA58
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10271EC34

	// Object: Function CustomLayout.SettingCustomPanel.ConvertCenterPositionFromScreenSpace
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1027281c0
	// Params: [ Num(3) Size(0x18) ]
	struct FVector2D ConvertCenterPositionFromScreenSpace(struct UWidget* FullScreenWidget, struct FVector2D& SSPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10271EE88
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10271F104
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10271EFD4
	// [Call #12] RVA: 0x10271E8A4
	// [Call #13] RVA: 0x10516D168
};

