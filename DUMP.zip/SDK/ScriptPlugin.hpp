#pragma once

#include <cstdint>

// Object: ScriptStruct ScriptPlugin.LuaStateGuard
// Size: 0x8 (Inherited: 0x0)
struct FLuaStateGuard
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct ScriptPlugin.LuaStateWrapperInitParams
// Size: 0xC0 (Inherited: 0x0)
struct FLuaStateWrapperInitParams
{
	uint8_t Pad_0x0[0xC0]; // 0x0(0xC0)
};

// Object: ScriptStruct ScriptPlugin.PlayerInfo
// Size: 0x38 (Inherited: 0x0)
struct FPlayerInfo
{
	int Level; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Name; // 0x8(0x10)
	int LocalPosition; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FSonInfo mySon; // 0x20(0x18)
};

// Object: ScriptStruct ScriptPlugin.SonInfo
// Size: 0x18 (Inherited: 0x0)
struct FSonInfo
{
	int xlevel; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString xname; // 0x8(0x10)
};

// Object: Class ScriptPlugin.LuaContext
// Size: 0x4C8 (Inherited: 0x4B0)
struct ALuaContext : AActor
{
	struct ULuaStateWrapper* OwningLuaStateWrapper; // 0x4B0(0x8)
	struct UObject* OwningObject; // 0x4B8(0x8)
	struct UScriptContextComponent* ScriptContextComponent; // 0x4C0(0x8)
};

// Object: Class ScriptPlugin.ScriptProfiler
// Size: 0x48 (Inherited: 0x28)
struct UScriptProfiler : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
};

// Object: Class ScriptPlugin.LuaStateWrapper
// Size: 0xF8 (Inherited: 0x28)
struct ULuaStateWrapper : UObject
{
	uint8_t Pad_0x28[0xD0]; // 0x28(0xD0)
};

// Object: Class ScriptPlugin.NetInterface
// Size: 0x28 (Inherited: 0x28)
struct INetInterface : IInterface
{
};

// Object: Class ScriptPlugin.ScriptBlueprint
// Size: 0xF8 (Inherited: 0xD8)
struct UScriptBlueprint : UBlueprint
{
	struct TArray<uint8_t> ByteCode; // 0xD8(0x10)
	struct FString SourceCode; // 0xE8(0x10)
};

// Object: Class ScriptPlugin.ScriptBlueprintGeneratedClass
// Size: 0x4C8 (Inherited: 0x498)
struct UScriptBlueprintGeneratedClass : UBlueprintGeneratedClass
{
	struct TArray<uint8_t> ByteCode; // 0x498(0x10)
	struct FString SourceCode; // 0x4A8(0x10)
	struct TArray<struct UProperty*> ScriptProperties; // 0x4B8(0x10)
};

// Object: Class ScriptPlugin.ScriptContext
// Size: 0x30 (Inherited: 0x28)
struct UScriptContext : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function ScriptPlugin.ScriptContext.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fc4228
	// Params: [ Num(1) Size(0x10) ]
	void CallScriptFunction(struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101FBC630
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
	// [Call #15] RVA: 0x101FC4CE8
};

// Object: Class ScriptPlugin.ScriptContextComponent
// Size: 0x188 (Inherited: 0x178)
struct UScriptContextComponent : UActorComponent
{
	uint8_t Pad_0x178[0x8]; // 0x178(0x8)
	struct ULuaStateWrapper* OwningLuaStateWrapper; // 0x180(0x8)


	// Object: Function ScriptPlugin.ScriptContextComponent.PushScriptArrayIndexData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fc4960
	// Params: [ Num(2) Size(0x14) ]
	void PushScriptArrayIndexData(struct FString ParamName, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101FBCFA8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function ScriptPlugin.ScriptContextComponent.PushOneScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc4874
	// Params: [ Num(1) Size(0x10) ]
	void PushOneScriptPropertyValues(struct FString ParamName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101FBCFA8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10519022C

	// Object: Function ScriptPlugin.ScriptContextComponent.PushAllScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc4858
	// Params: [ Num(0) Size(0x0) ]
	void PushAllScriptPropertyValues();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101FBCFA8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function ScriptPlugin.ScriptContextComponent.FetchScriptArrayIndexData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fc4734
	// Params: [ Num(2) Size(0x14) ]
	void FetchScriptArrayIndexData(struct FString ParamName, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101FBCEC8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function ScriptPlugin.ScriptContextComponent.FetchOneScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc4648
	// Params: [ Num(1) Size(0x10) ]
	void FetchOneScriptPropertyValues(struct FString ParamName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101FBCEC8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function ScriptPlugin.ScriptContextComponent.FetchAllScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc462c
	// Params: [ Num(0) Size(0x0) ]
	void FetchAllScriptPropertyValues();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101FBCEC8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function ScriptPlugin.ScriptContextComponent.CallScriptFunctionWithoutFetch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fc4548
	// Params: [ Num(1) Size(0x10) ]
	void CallScriptFunctionWithoutFetch(struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101FBCB90
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168

	// Object: Function ScriptPlugin.ScriptContextComponent.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fc4464
	// Params: [ Num(1) Size(0x10) ]
	void CallScriptFunction(struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101FBCA84
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101FBCB90
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
};

// Object: Class ScriptPlugin.ScriptHelperNetInterface
// Size: 0x28 (Inherited: 0x28)
struct UScriptHelperNetInterface : UObject
{

	// Object: Function ScriptPlugin.ScriptHelperNetInterface.SendPacket_LuaState
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101fc4f04
	// Params: [ Num(1) Size(0x4) ]
	int SendPacket_LuaState();
	// [Call #1] RVA: 0x101FBD320
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x101FC52A8
	// [Call #8] RVA: 0x10516D168

	// Object: Function ScriptPlugin.ScriptHelperNetInterface.Disconnect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101fc4e80
	// Params: [ Num(1) Size(0x10) ]
	void Disconnect(struct TScriptInterface<Class>& NetInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FBD398
	// [Call #4] RVA: 0x101FBD320
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function ScriptPlugin.ScriptHelperNetInterface.Connect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101fc4dc0
	// Params: [ Num(2) Size(0x14) ]
	void Connect(struct TScriptInterface<Class>& NetInterface, int Timeout);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FBD328
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FBD398
	// [Call #9] RVA: 0x101FBD320
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class ScriptPlugin.ScriptPluginComponent
// Size: 0x30 (Inherited: 0x28)
struct UScriptPluginComponent : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function ScriptPlugin.ScriptPluginComponent.CallScriptFunction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc5118
	// Params: [ Num(2) Size(0x11) ]
	bool CallScriptFunction(struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x100036FE0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10508F76C
	// [Call #14] RVA: 0x101FC3A54
};

// Object: Class ScriptPlugin.ScriptTestActor
// Size: 0x4C8 (Inherited: 0x4B0)
struct AScriptTestActor : AActor
{
	struct FString TestString; // 0x4B0(0x10)
	float TestValue; // 0x4C0(0x4)
	bool TestBool; // 0x4C4(0x1)
	uint8_t Pad_0x4C5[0x3]; // 0x4C5(0x3)


	// Object: Function ScriptPlugin.ScriptTestActor.TestFunction
	// Flags: [Final|Native|Public]
	// Offset: 0x101fc5500
	// Params: [ Num(4) Size(0x10) ]
	float TestFunction(float InValue, float InFactor, bool bMultiply);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FBD9D0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class ScriptPlugin.LuaClassBaseObj
// Size: 0x4B0 (Inherited: 0x4B0)
struct ALuaClassBaseObj : AActor
{

	// Object: Function ScriptPlugin.LuaClassBaseObj.ItsATest
	// Flags: [Native|Public]
	// Offset: 0x101fc588c
	// Params: [ Num(6) Size(0x80) ]
	struct FString ItsATest(struct FPlayerInfo Player1, struct TArray<int> nums, int X, struct FString Q, struct TArray<struct FPlayerInfo> Player2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FC70F4
	// [Call #12] RVA: 0x101FC71F0
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101FC72D0
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101FC73C0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8BA44
	// [Call #20] RVA: 0x101FC6E74
	// [Call #21] RVA: 0x101FC73C0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8BA44
	// [Call #24] RVA: 0x101FC6E74
	// [Call #25] RVA: 0x101F8130C

	// Object: Function ScriptPlugin.LuaClassBaseObj.HandleUIMessage
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc57ec
	// Params: [ Num(1) Size(0x10) ]
	void HandleUIMessage(struct FString UIMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101FC70F4
	// [Call #17] RVA: 0x101FC71F0
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x101FC72D0

	// Object: Function ScriptPlugin.LuaClassBaseObj.GetGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101fc5780
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetGameStatus();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: ScriptBlueprintGeneratedClass ScriptPlugin.Default__ScriptBlueprintGeneratedClass
// Size: 0x0 (Inherited: 0x0)
struct Default__ScriptBlueprintGeneratedClass
{
};

