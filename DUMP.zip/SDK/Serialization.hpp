#pragma once

#include <cstdint>

// Object: ScriptStruct Serialization.StructSerializerTestStruct
// Size: 0x1D8 (Inherited: 0x0)
struct FStructSerializerTestStruct
{
	struct FStructSerializerNumericTestStruct Numerics; // 0x0(0x30)
	struct FStructSerializerBooleanTestStruct Booleans; // 0x30(0x8)
	struct FStructSerializerObjectTestStruct Objects; // 0x38(0x10)
	struct FStructSerializerBuiltinTestStruct Builtins; // 0x48(0x60)
	struct FStructSerializerArrayTestStruct Arrays; // 0xA8(0x40)
	struct FStructSerializerMapTestStruct Maps; // 0xE8(0xF0)
};

// Object: ScriptStruct Serialization.StructSerializerMapTestStruct
// Size: 0xF0 (Inherited: 0x0)
struct FStructSerializerMapTestStruct
{
	struct TMap<int, struct FString> IntToStr; // 0x0(0x50)
	struct TMap<struct FString, struct FString> StrToStr; // 0x50(0x50)
	struct TMap<struct FString, struct FVector> StrToVec; // 0xA0(0x50)
};

// Object: ScriptStruct Serialization.StructSerializerArrayTestStruct
// Size: 0x40 (Inherited: 0x0)
struct FStructSerializerArrayTestStruct
{
	struct TArray<int> Int32Array; // 0x0(0x10)
	int StaticSingleElement; // 0x10(0x4)
	int StaticInt32Array[0x3]; // 0x14(0xC)
	float StaticFloatArray[0x3]; // 0x20(0xC)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FVector> VectorArray; // 0x30(0x10)
};

// Object: ScriptStruct Serialization.StructSerializerBuiltinTestStruct
// Size: 0x60 (Inherited: 0x0)
struct FStructSerializerBuiltinTestStruct
{
	struct FGuid Guid; // 0x0(0x10)
	struct FName Name; // 0x10(0x8)
	struct FString String; // 0x18(0x10)
	struct FRotator Rotator; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FText Text; // 0x38(0x18)
	struct FVector Vector; // 0x50(0xC)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
};

// Object: ScriptStruct Serialization.StructSerializerObjectTestStruct
// Size: 0x10 (Inherited: 0x0)
struct FStructSerializerObjectTestStruct
{
	struct UObject* Class; // 0x0(0x8)
	struct UObject* ObjectPtr; // 0x8(0x8)
};

// Object: ScriptStruct Serialization.StructSerializerBooleanTestStruct
// Size: 0x8 (Inherited: 0x0)
struct FStructSerializerBooleanTestStruct
{
	bool BoolFalse; // 0x0(0x1)
	bool BoolTrue; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	uint32_t Bitfield; // 0x4(0x4)
};

// Object: ScriptStruct Serialization.StructSerializerNumericTestStruct
// Size: 0x30 (Inherited: 0x0)
struct FStructSerializerNumericTestStruct
{
	uint8_t Int8; // 0x0(0x1)
	uint8_t Pad_0x1[0x1]; // 0x1(0x1)
	int16_t Int16; // 0x2(0x2)
	int Int32; // 0x4(0x4)
	int64_t Int64; // 0x8(0x8)
	uint8_t UInt8; // 0x10(0x1)
	uint8_t Pad_0x11[0x1]; // 0x11(0x1)
	uint16_t UInt16; // 0x12(0x2)
	uint32_t UInt32; // 0x14(0x4)
	uint64_t UInt64; // 0x18(0x8)
	float Float; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	double Double; // 0x28(0x8)
};

