#pragma once

#include <cstdint>

// Object: ScriptStruct MRMesh.MRMeshConfiguration
// Size: 0x1 (Inherited: 0x0)
struct FMRMeshConfiguration
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: Class MRMesh.MeshReconstructorBase
// Size: 0x28 (Inherited: 0x28)
struct UMeshReconstructorBase : UObject
{

	// Object: Function MRMesh.MeshReconstructorBase.StopReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105fc2ba0
	// Params: [ Num(0) Size(0x0) ]
	void StopReconstruction();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.StartReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105fc2b84
	// Params: [ Num(0) Size(0x0) ]
	void StartReconstruction();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.PauseReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105fc2b68
	// Params: [ Num(0) Size(0x0) ]
	void PauseReconstruction();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fc2b2c
	// Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionStarted();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fc2af0
	// Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionPaused();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x105fc2ad4
	// Params: [ Num(0) Size(0x0) ]
	void DisconnectMRMesh();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C

	// Object: Function MRMesh.MeshReconstructorBase.ConnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x105fc2a40
	// Params: [ Num(2) Size(0x9) ]
	struct FMRMeshConfiguration ConnectMRMesh(struct UMRMeshComponent* Mesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
};

// Object: Class MRMesh.MRMeshComponent
// Size: 0xA20 (Inherited: 0x9D0)
struct UMRMeshComponent : UPrimitiveComponent
{
	struct UMaterialInterface* Material; // 0x9D0(0x8)
	struct UMeshReconstructorBase* MeshReconstructor; // 0x9D8(0x8)
	bool bEnableCollision; // 0x9E0(0x1)
	uint8_t Pad_0x9E1[0x7]; // 0x9E1(0x7)
	struct TArray<struct UBodySetup*> BodySetups; // 0x9E8(0x10)
	uint8_t Pad_0x9F8[0x28]; // 0x9F8(0x28)


	// Object: Function MRMesh.MRMeshComponent.GetReconstructor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fc2f48
	// Params: [ Num(1) Size(0x8) ]
	struct UMeshReconstructorBase* GetReconstructor();
	// [Call #1] RVA: 0x105FBF318
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x104FD0740
	// [Call #7] RVA: 0x1036A6C08
	// [Call #8] RVA: 0x105093FD0

	// Object: Function MRMesh.MRMeshComponent.ConnectReconstructor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fc2ecc
	// Params: [ Num(1) Size(0x8) ]
	void ConnectReconstructor(struct UMeshReconstructorBase* Reconstructor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FBF2EC
	// [Call #4] RVA: 0x105FBF318
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
};

