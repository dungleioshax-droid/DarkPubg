#pragma once

#include <cstdint>

// Object: Enum GameplayAbilities.EGameplayEffectGrantedAbilityRemovePolicy
enum class EGameplayEffectGrantedAbilityRemovePolicy : uint8_t
{
	CancelAbilityImmediately = 0,
	RemoveAbilityOnEnd = 1,
	DoNothing = 2,
	EGameplayEffectGrantedAbilityRemovePolicy_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayEffectAttributeCaptureSource
enum class EGameplayEffectAttributeCaptureSource : uint8_t
{
	Source = 0,
	Target = 1,
	EGameplayEffectAttributeCaptureSource_MAX = 2
};

// Object: Enum GameplayAbilities.EGameplayAbilityActivationMode
enum class EGameplayAbilityActivationMode : uint8_t
{
	Authority = 0,
	NonAuthority = 1,
	Predicting = 2,
	Confirmed = 3,
	Rejected = 4,
	EGameplayAbilityActivationMode_MAX = 5
};

// Object: Enum GameplayAbilities.EAbilityGenericReplicatedEvent
enum class EAbilityGenericReplicatedEvent : uint8_t
{
	GenericConfirm = 0,
	GenericCancel = 1,
	InputPressed = 2,
	InputReleased = 3,
	GenericSignalFromClient = 4,
	GenericSignalFromServer = 5,
	GameCustom1 = 6,
	GameCustom2 = 7,
	GameCustom3 = 8,
	GameCustom4 = 9,
	GameCustom5 = 10,
	GameCustom6 = 11,
	MAX = 12
};

// Object: Enum GameplayAbilities.EReplicationMode
enum class EReplicationMode : uint8_t
{
	Minimal = 0,
	Mixed = 1,
	Full = 2,
	EReplicationMode_MAX = 3
};

// Object: Enum GameplayAbilities.EAbilityTaskWaitState
enum class EAbilityTaskWaitState : uint8_t
{
	WaitingOnGame = 1,
	WaitingOnUser = 2,
	WaitingOnAvatar = 4,
	EAbilityTaskWaitState_MAX = 5
};

// Object: Enum GameplayAbilities.ERootMotionMoveToActorTargetOffsetType
enum class ERootMotionMoveToActorTargetOffsetType : uint8_t
{
	AlignFromTargetToSource = 0,
	AlignToTargetForward = 1,
	AlignToWorldSpace = 2,
	ERootMotionMoveToActorTargetOffsetType_MAX = 3
};

// Object: Enum GameplayAbilities.EAbilityTaskNetSyncType
enum class EAbilityTaskNetSyncType : uint8_t
{
	BothWait = 0,
	OnlyServerWait = 1,
	OnlyClientWait = 2,
	EAbilityTaskNetSyncType_MAX = 3
};

// Object: Enum GameplayAbilities.EWaitAttributeChangeComparison
enum class EWaitAttributeChangeComparison : uint8_t
{
	None = 0,
	GreaterThan = 1,
	LessThan = 2,
	GreaterThanOrEqualTo = 3,
	LessThanOrEqualTo = 4,
	NotEqualTo = 5,
	ExactlyEqualTo = 6,
	MAX = 7
};

// Object: Enum GameplayAbilities.EGameplayAbilityInputBinds
enum class EGameplayAbilityInputBinds : uint8_t
{
	Ability1 = 0,
	Ability2 = 1,
	Ability3 = 2,
	Ability4 = 3,
	Ability5 = 4,
	Ability6 = 5,
	Ability7 = 6,
	Ability8 = 7,
	Ability9 = 8,
	EGameplayAbilityInputBinds_MAX = 9
};

// Object: Enum GameplayAbilities.ETargetAbilitySelfSelection
enum class ETargetAbilitySelfSelection : uint8_t
{
	TASS_Permit = 0,
	TASS_Forbid = 1,
	TASS_Require = 2,
	TASS_MAX = 3
};

// Object: Enum GameplayAbilities.ETargetDataFilterSelf
enum class ETargetDataFilterSelf : uint8_t
{
	TDFS_Any = 0,
	TDFS_NoSelf = 1,
	TDFS_NoOthers = 2,
	TDFS_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayAbilityTargetingLocationType
enum class EGameplayAbilityTargetingLocationType : uint8_t
{
	LiteralTransform = 0,
	ActorTransform = 1,
	SocketTransform = 2,
	EGameplayAbilityTargetingLocationType_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayTargetingConfirmation
enum class EGameplayTargetingConfirmation : uint8_t
{
	Instant = 0,
	UserConfirmed = 1,
	Custom = 2,
	CustomMulti = 3,
	EGameplayTargetingConfirmation_MAX = 4
};

// Object: Enum GameplayAbilities.EGameplayAbilityTriggerSource
enum class EGameplayAbilityTriggerSource : uint8_t
{
	GameplayEvent = 0,
	OwnedTagAdded = 1,
	OwnedTagPresent = 2,
	EGameplayAbilityTriggerSource_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayAbilityReplicationPolicy
enum class EGameplayAbilityReplicationPolicy : uint8_t
{
	ReplicateNo = 0,
	ReplicateYes = 1,
	EGameplayAbilityReplicationPolicy_MAX = 2
};

// Object: Enum GameplayAbilities.EGameplayAbilityNetExecutionPolicy
enum class EGameplayAbilityNetExecutionPolicy : uint8_t
{
	LocalPredicted = 0,
	LocalOnly = 1,
	ServerInitiated = 2,
	ServerOnly = 3,
	EGameplayAbilityNetExecutionPolicy_MAX = 4
};

// Object: Enum GameplayAbilities.EGameplayAbilityInstancingPolicy
enum class EGameplayAbilityInstancingPolicy : uint8_t
{
	NonInstanced = 0,
	InstancedPerActor = 1,
	InstancedPerExecution = 2,
	EGameplayAbilityInstancingPolicy_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayCuePayloadType
enum class EGameplayCuePayloadType : uint8_t
{
	EffectContext = 0,
	CueParameters = 1,
	FromSpec = 2,
	EGameplayCuePayloadType_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayEffectStackingExpirationPolicy
enum class EGameplayEffectStackingExpirationPolicy : uint8_t
{
	ClearEntireStack = 0,
	RemoveSingleStackAndRefreshDuration = 1,
	RefreshDuration = 2,
	EGameplayEffectStackingExpirationPolicy_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayEffectStackingPeriodPolicy
enum class EGameplayEffectStackingPeriodPolicy : uint8_t
{
	ResetOnSuccessfulApplication = 0,
	NeverReset = 1,
	EGameplayEffectStackingPeriodPolicy_MAX = 2
};

// Object: Enum GameplayAbilities.EGameplayEffectStackingDurationPolicy
enum class EGameplayEffectStackingDurationPolicy : uint8_t
{
	RefreshOnSuccessfulApplication = 0,
	NeverRefresh = 1,
	EGameplayEffectStackingDurationPolicy_MAX = 2
};

// Object: Enum GameplayAbilities.EGameplayEffectDurationType
enum class EGameplayEffectDurationType : uint8_t
{
	Instant = 0,
	Infinite = 1,
	HasDuration = 2,
	EGameplayEffectDurationType_MAX = 3
};

// Object: Enum GameplayAbilities.EAttributeBasedFloatCalculationType
enum class EAttributeBasedFloatCalculationType : uint8_t
{
	AttributeMagnitude = 0,
	AttributeBaseValue = 1,
	AttributeBonusMagnitude = 2,
	AttributeMagnitudeEvaluatedUpToChannel = 3,
	EAttributeBasedFloatCalculationType_MAX = 4
};

// Object: Enum GameplayAbilities.EGameplayEffectMagnitudeCalculation
enum class EGameplayEffectMagnitudeCalculation : uint8_t
{
	ScalableFloat = 0,
	AttributeBased = 1,
	CustomCalculationClass = 2,
	SetByCaller = 3,
	EGameplayEffectMagnitudeCalculation_MAX = 4
};

// Object: Enum GameplayAbilities.EGameplayTagEventType
enum class EGameplayTagEventType : uint8_t
{
	NewOrRemoved = 0,
	AnyCountChange = 1,
	EGameplayTagEventType_MAX = 2
};

// Object: Enum GameplayAbilities.EGameplayCueEvent
enum class EGameplayCueEvent : uint8_t
{
	OnActive = 0,
	WhileActive = 1,
	Executed = 2,
	Removed = 3,
	EGameplayCueEvent_MAX = 4
};

// Object: Enum GameplayAbilities.EGameplayEffectStackingType
enum class EGameplayEffectStackingType : uint8_t
{
	None = 0,
	AggregateBySource = 1,
	AggregateByTarget = 2,
	EGameplayEffectStackingType_MAX = 3
};

// Object: Enum GameplayAbilities.EGameplayModOp
enum class EGameplayModOp : uint8_t
{
	Additive = 0,
	Multiplicitive = 1,
	Division = 2,
	Override = 3,
	Max = 4
};

// Object: Enum GameplayAbilities.EGameplayModEvaluationChannel
enum class EGameplayModEvaluationChannel : uint8_t
{
	Channel0 = 0,
	Channel1 = 1,
	Channel2 = 2,
	Channel3 = 3,
	Channel4 = 4,
	Channel5 = 5,
	Channel6 = 6,
	Channel7 = 7,
	Channel8 = 8,
	Channel9 = 9,
	Channel_MAX = 10,
	EGameplayModEvaluationChannel_MAX = 11
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayEffect
// Size: 0x358 (Inherited: 0xC)
struct FActiveGameplayEffect : FFastArraySerializerItem
{
	uint8_t Pad_0xC[0xC]; // 0xC(0xC)
	struct FGameplayEffectSpec Spec; // 0x18(0x298)
	struct FPredictionKey PredictionKey; // 0x2B0(0x18)
	float StartServerWorldTime; // 0x2C8(0x4)
	float CachedStartServerWorldTime; // 0x2CC(0x4)
	float StartWorldTime; // 0x2D0(0x4)
	bool bIsInhibited; // 0x2D4(0x1)
	uint8_t Pad_0x2D5[0x83]; // 0x2D5(0x83)
};

// Object: ScriptStruct GameplayAbilities.PredictionKey
// Size: 0x18 (Inherited: 0x0)
struct FPredictionKey
{
	int16_t Current; // 0x0(0x2)
	int16_t Base; // 0x2(0x2)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UPackageMap* PredictiveConnection; // 0x8(0x8)
	bool bIsStale; // 0x10(0x1)
	bool bIsServerInitiated; // 0x11(0x1)
	uint8_t Pad_0x12[0x6]; // 0x12(0x6)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectSpec
// Size: 0x298 (Inherited: 0x0)
struct FGameplayEffectSpec
{
	struct UGameplayEffect* Def; // 0x0(0x8)
	struct TArray<struct FGameplayEffectModifiedAttribute> ModifiedAttributes; // 0x8(0x10)
	struct FGameplayEffectAttributeCaptureSpecContainer CapturedRelevantAttributes; // 0x18(0x28)
	uint8_t Pad_0x40[0x10]; // 0x40(0x10)
	float Duration; // 0x50(0x4)
	float Period; // 0x54(0x4)
	float ChanceToApplyToTarget; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct FTagContainerAggregator CapturedSourceTags; // 0x60(0x88)
	struct FTagContainerAggregator CapturedTargetTags; // 0xE8(0x88)
	struct FGameplayTagContainer DynamicGrantedTags; // 0x170(0x20)
	struct FGameplayTagContainer DynamicAssetTags; // 0x190(0x20)
	struct TArray<struct FModifierSpec> Modifiers; // 0x1B0(0x10)
	int StackCount; // 0x1C0(0x4)
	uint8_t bCompletedSourceAttributeCapture : 1; // 0x1C4(0x1), Mask(0x1)
	uint8_t bCompletedTargetAttributeCapture : 1; // 0x1C4(0x1), Mask(0x2)
	uint8_t bDurationLocked : 1; // 0x1C4(0x1), Mask(0x4)
	uint8_t BitPad_0x1C4_3 : 5; // 0x1C4(0x1)
	uint8_t Pad_0x1C5[0x3]; // 0x1C5(0x3)
	struct TArray<struct FGameplayAbilitySpecDef> GrantedAbilitySpecs; // 0x1C8(0x10)
	uint8_t Pad_0x1D8[0xA0]; // 0x1D8(0xA0)
	struct FGameplayEffectContextHandle EffectContext; // 0x278(0x18)
	float Level; // 0x290(0x4)
	uint8_t Pad_0x294[0x4]; // 0x294(0x4)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectContextHandle
// Size: 0x18 (Inherited: 0x0)
struct FGameplayEffectContextHandle
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilitySpecDef
// Size: 0x50 (Inherited: 0x0)
struct FGameplayAbilitySpecDef
{
	struct UGameplayAbility* Ability; // 0x0(0x8)
	int Level; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FScalableFloat LevelScalableFloat; // 0x10(0x28)
	int InputID; // 0x38(0x4)
	uint8_t RemovalPolicy; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
	struct UObject* SourceObject; // 0x40(0x8)
	struct FGameplayAbilitySpecHandle AssignedHandle; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilitySpecHandle
// Size: 0x4 (Inherited: 0x0)
struct FGameplayAbilitySpecHandle
{
	int Handle; // 0x0(0x4)
};

// Object: ScriptStruct GameplayAbilities.ScalableFloat
// Size: 0x28 (Inherited: 0x0)
struct FScalableFloat
{
	float Value; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FCurveTableRowHandle Curve; // 0x8(0x10)
	uint8_t Pad_0x18[0x10]; // 0x18(0x10)
};

// Object: ScriptStruct GameplayAbilities.ModifierSpec
// Size: 0x4 (Inherited: 0x0)
struct FModifierSpec
{
	float EvaluatedMagnitude; // 0x0(0x4)
};

// Object: ScriptStruct GameplayAbilities.TagContainerAggregator
// Size: 0x88 (Inherited: 0x0)
struct FTagContainerAggregator
{
	struct FGameplayTagContainer CapturedActorTags; // 0x0(0x20)
	struct FGameplayTagContainer CapturedSpecTags; // 0x20(0x20)
	struct FGameplayTagContainer ScopedTags; // 0x40(0x20)
	uint8_t Pad_0x60[0x28]; // 0x60(0x28)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectAttributeCaptureSpecContainer
// Size: 0x28 (Inherited: 0x0)
struct FGameplayEffectAttributeCaptureSpecContainer
{
	struct TArray<struct FGameplayEffectAttributeCaptureSpec> SourceAttributes; // 0x0(0x10)
	struct TArray<struct FGameplayEffectAttributeCaptureSpec> TargetAttributes; // 0x10(0x10)
	bool bHasNonSnapshottedAttributes; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectAttributeCaptureSpec
// Size: 0x38 (Inherited: 0x0)
struct FGameplayEffectAttributeCaptureSpec
{
	struct FGameplayEffectAttributeCaptureDefinition BackingDefinition; // 0x0(0x28)
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectAttributeCaptureDefinition
// Size: 0x28 (Inherited: 0x0)
struct FGameplayEffectAttributeCaptureDefinition
{
	struct FGameplayAttribute AttributeToCapture; // 0x0(0x20)
	uint8_t AttributeSource; // 0x20(0x1)
	bool bSnapshot; // 0x21(0x1)
	uint8_t Pad_0x22[0x6]; // 0x22(0x6)
};

// Object: ScriptStruct GameplayAbilities.GameplayAttribute
// Size: 0x20 (Inherited: 0x0)
struct FGameplayAttribute
{
	struct FString AttributeName; // 0x0(0x10)
	struct UProperty* Attribute; // 0x10(0x8)
	struct UStruct* AttributeOwner; // 0x18(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectModifiedAttribute
// Size: 0x28 (Inherited: 0x0)
struct FGameplayEffectModifiedAttribute
{
	struct FGameplayAttribute Attribute; // 0x0(0x20)
	float TotalMagnitude; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayEffectHandle
// Size: 0x8 (Inherited: 0x0)
struct FActiveGameplayEffectHandle
{
	int Handle; // 0x0(0x4)
	bool bPassedFiltersAndWasExecuted; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectSpecHandle
// Size: 0x18 (Inherited: 0x0)
struct FGameplayEffectSpecHandle
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectRemovalInfo
// Size: 0x20 (Inherited: 0x0)
struct FGameplayEffectRemovalInfo
{
	bool bPrematureRemoval; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int StackCount; // 0x4(0x4)
	struct FGameplayEffectContextHandle EffectContext; // 0x8(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayEventData
// Size: 0xA8 (Inherited: 0x0)
struct FGameplayEventData
{
	struct FGameplayTag EventTag; // 0x0(0x8)
	struct AActor* Instigator; // 0x8(0x8)
	struct AActor* Target; // 0x10(0x8)
	struct UObject* OptionalObject; // 0x18(0x8)
	struct UObject* OptionalObject2; // 0x20(0x8)
	struct FGameplayEffectContextHandle ContextHandle; // 0x28(0x18)
	struct FGameplayTagContainer InstigatorTags; // 0x40(0x20)
	struct FGameplayTagContainer TargetTags; // 0x60(0x20)
	float EventMagnitude; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct FGameplayAbilityTargetDataHandle TargetData; // 0x88(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetDataHandle
// Size: 0x20 (Inherited: 0x0)
struct FGameplayAbilityTargetDataHandle
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityActivationInfo
// Size: 0x20 (Inherited: 0x0)
struct FGameplayAbilityActivationInfo
{
	enum class EGameplayAbilityActivationMode ActivationMode; // 0x0(0x1)
	uint8_t bCanBeEndedByOtherInstance : 1; // 0x1(0x1), Mask(0x1)
	uint8_t BitPad_0x1_1 : 7; // 0x1(0x1)
	uint8_t Pad_0x2[0x6]; // 0x2(0x6)
	struct FPredictionKey PredictionKeyWhenActivated; // 0x8(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectQuery
// Size: 0x138 (Inherited: 0x0)
struct FGameplayEffectQuery
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
	DelegateProperty CustomMatchDelegate_BP; // 0x10(0x10)
	struct FGameplayTagQuery OwningTagQuery; // 0x20(0x48)
	struct FGameplayTagQuery EffectTagQuery; // 0x68(0x48)
	struct FGameplayTagQuery SourceTagQuery; // 0xB0(0x48)
	struct FGameplayAttribute ModifyingAttribute; // 0xF8(0x20)
	struct UObject* EffectSource; // 0x118(0x8)
	struct UGameplayEffect* EffectDefinition; // 0x120(0x8)
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueParameters
// Size: 0xB8 (Inherited: 0x0)
struct FGameplayCueParameters
{
	float NormalizedMagnitude; // 0x0(0x4)
	float RawMagnitude; // 0x4(0x4)
	struct FGameplayEffectContextHandle EffectContext; // 0x8(0x18)
	struct FGameplayTag MatchedTagName; // 0x20(0x8)
	struct FGameplayTag OriginalTag; // 0x28(0x8)
	struct FGameplayTagContainer AggregatedSourceTags; // 0x30(0x20)
	struct FGameplayTagContainer AggregatedTargetTags; // 0x50(0x20)
	struct FVector_NetQuantize10 Location; // 0x70(0xC)
	struct FVector_NetQuantizeNormal Normal; // 0x7C(0xC)
	struct TWeakObjectPtr<struct AActor> Instigator; // 0x88(0x8)
	struct TWeakObjectPtr<struct AActor> EffectCauser; // 0x90(0x8)
	struct TWeakObjectPtr<struct UObject> SourceObject; // 0x98(0x8)
	struct TWeakObjectPtr<struct UPhysicalMaterial> PhysicalMaterial; // 0xA0(0x8)
	int GameplayEffectLevel; // 0xA8(0x4)
	int AbilityLevel; // 0xAC(0x4)
	struct TWeakObjectPtr<struct USceneComponent> TargetAttachComponent; // 0xB0(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectSpecForRPC
// Size: 0x78 (Inherited: 0x0)
struct FGameplayEffectSpecForRPC
{
	struct UGameplayEffect* Def; // 0x0(0x8)
	struct TArray<struct FGameplayEffectModifiedAttribute> ModifiedAttributes; // 0x8(0x10)
	struct FGameplayEffectContextHandle EffectContext; // 0x18(0x18)
	struct FGameplayTagContainer AggregatedSourceTags; // 0x30(0x20)
	struct FGameplayTagContainer AggregatedTargetTags; // 0x50(0x20)
	float Level; // 0x70(0x4)
	float AbilityLevel; // 0x74(0x4)
};

// Object: ScriptStruct GameplayAbilities.ReplicatedPredictionKeyMap
// Size: 0xC0 (Inherited: 0xB0)
struct FReplicatedPredictionKeyMap : FFastArraySerializer
{
	struct TArray<struct FReplicatedPredictionKeyItem> PredictionKeys; // 0xB0(0x10)
};

// Object: ScriptStruct GameplayAbilities.ReplicatedPredictionKeyItem
// Size: 0x28 (Inherited: 0xC)
struct FReplicatedPredictionKeyItem : FFastArraySerializerItem
{
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FPredictionKey PredictionKey; // 0x10(0x18)
};

// Object: ScriptStruct GameplayAbilities.MinimalReplicationTagCountMap
// Size: 0x60 (Inherited: 0x0)
struct FMinimalReplicationTagCountMap
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
	struct UAbilitySystemComponent* Owner; // 0x50(0x8)
	uint8_t Pad_0x58[0x8]; // 0x58(0x8)
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayCueContainer
// Size: 0xD0 (Inherited: 0xB0)
struct FActiveGameplayCueContainer : FFastArraySerializer
{
	struct TArray<struct FActiveGameplayCue> GameplayCues; // 0xB0(0x10)
	struct UAbilitySystemComponent* Owner; // 0xC0(0x8)
	uint8_t Pad_0xC8[0x8]; // 0xC8(0x8)
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayCue
// Size: 0xF0 (Inherited: 0xC)
struct FActiveGameplayCue : FFastArraySerializerItem
{
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FGameplayTag GameplayCueTag; // 0x10(0x8)
	struct FPredictionKey PredictionKey; // 0x18(0x18)
	struct FGameplayCueParameters Parameters; // 0x30(0xB8)
	bool bPredictivelyRemoved; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayEffectsContainer
// Size: 0x428 (Inherited: 0xB0)
struct FActiveGameplayEffectsContainer : FFastArraySerializer
{
	uint8_t Pad_0xB0[0x30]; // 0xB0(0x30)
	struct TArray<struct FActiveGameplayEffect> GameplayEffects_Internal; // 0xE0(0x10)
	uint8_t Pad_0xF0[0x310]; // 0xF0(0x310)
	struct TArray<struct UGameplayEffect*> ApplicationImmunityQueryEffects; // 0x400(0x10)
	uint8_t Pad_0x410[0x18]; // 0x410(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityLocalAnimMontage
// Size: 0x30 (Inherited: 0x0)
struct FGameplayAbilityLocalAnimMontage
{
	struct UAnimMontage* AnimMontage; // 0x0(0x8)
	bool PlayBit; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FPredictionKey PredictionKey; // 0x10(0x18)
	struct UGameplayAbility* AnimatingAbility; // 0x28(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityRepAnimMontage
// Size: 0x30 (Inherited: 0x0)
struct FGameplayAbilityRepAnimMontage
{
	struct UAnimMontage* AnimMontage; // 0x0(0x8)
	float PlayRate; // 0x8(0x4)
	float Position; // 0xC(0x4)
	float BlendTime; // 0x10(0x4)
	uint8_t NextSectionID; // 0x14(0x1)
	uint8_t IsStopped : 1; // 0x15(0x1), Mask(0x1)
	uint8_t ForcePlayBit : 1; // 0x15(0x1), Mask(0x2)
	uint8_t BitPad_0x15_2 : 6; // 0x15(0x1)
	uint8_t Pad_0x16[0x2]; // 0x16(0x2)
	struct FPredictionKey PredictionKey; // 0x18(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilitySpecContainer
// Size: 0xC8 (Inherited: 0xB0)
struct FGameplayAbilitySpecContainer : FFastArraySerializer
{
	struct TArray<struct FGameplayAbilitySpec> Items; // 0xB0(0x10)
	uint8_t Pad_0xC0[0x8]; // 0xC0(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilitySpec
// Size: 0x78 (Inherited: 0xC)
struct FGameplayAbilitySpec : FFastArraySerializerItem
{
	struct FGameplayAbilitySpecHandle Handle; // 0xC(0x4)
	struct UGameplayAbility* Ability; // 0x10(0x8)
	int Level; // 0x18(0x4)
	int InputID; // 0x1C(0x4)
	struct UObject* SourceObject; // 0x20(0x8)
	uint8_t ActiveCount; // 0x28(0x1)
	uint8_t InputPressed : 1; // 0x29(0x1), Mask(0x1)
	uint8_t RemoveAfterActivation : 1; // 0x29(0x1), Mask(0x2)
	uint8_t PendingRemove : 1; // 0x29(0x1), Mask(0x4)
	uint8_t BitPad_0x29_3 : 5; // 0x29(0x1)
	uint8_t Pad_0x2A[0x6]; // 0x2A(0x6)
	struct FGameplayAbilityActivationInfo ActivationInfo; // 0x30(0x20)
	struct TArray<struct UGameplayAbility*> NonReplicatedInstances; // 0x50(0x10)
	struct TArray<struct UGameplayAbility*> ReplicatedInstances; // 0x60(0x10)
	struct FActiveGameplayEffectHandle GameplayEffectHandle; // 0x70(0x8)
};

// Object: ScriptStruct GameplayAbilities.AttributeDefaults
// Size: 0x10 (Inherited: 0x0)
struct FAttributeDefaults
{
	struct UAttributeSet* Attributes; // 0x0(0x8)
	struct UDataTable* DefaultStartingTable; // 0x8(0x8)
};

// Object: ScriptStruct GameplayAbilities.AttributeMetaData
// Size: 0x30 (Inherited: 0x8)
struct FAttributeMetaData : FTableRowBase
{
	float baseValue; // 0x8(0x4)
	float MinValue; // 0xC(0x4)
	float MaxValue; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString DerivedAttributeInfo; // 0x18(0x10)
	bool bCanStack; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: ScriptStruct GameplayAbilities.GlobalCurveDataOverride
// Size: 0x10 (Inherited: 0x0)
struct FGlobalCurveDataOverride
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct GameplayAbilities.GameplayAttributeData
// Size: 0x10 (Inherited: 0x0)
struct FGameplayAttributeData
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	float baseValue; // 0x8(0x4)
	float CurrentValue; // 0xC(0x4)
};

// Object: ScriptStruct GameplayAbilities.AbilityTriggerData
// Size: 0x10 (Inherited: 0x0)
struct FAbilityTriggerData
{
	struct FGameplayTag TriggerTag; // 0x0(0x8)
	enum class EGameplayAbilityTriggerSource TriggerSource; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityBindInfo
// Size: 0x10 (Inherited: 0x0)
struct FGameplayAbilityBindInfo
{
	enum class EGameplayAbilityInputBinds Command; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UGameplayAbility* GameplayAbilityClass; // 0x8(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayTargetDataFilterHandle
// Size: 0x10 (Inherited: 0x0)
struct FGameplayTargetDataFilterHandle
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct GameplayAbilities.GameplayTargetDataFilter
// Size: 0x28 (Inherited: 0x0)
struct FGameplayTargetDataFilter
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct AActor* SelfActor; // 0x8(0x8)
	enum class ETargetDataFilterSelf SelfFilter; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct AActor* RequiredActorClass; // 0x18(0x8)
	bool bReverseFilter; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetData
// Size: 0x8 (Inherited: 0x0)
struct FGameplayAbilityTargetData
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetData_SingleTargetHit
// Size: 0x90 (Inherited: 0x8)
struct FGameplayAbilityTargetData_SingleTargetHit : FGameplayAbilityTargetData
{
	struct FHitResult HitResult; // 0x8(0x88)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetData_ActorArray
// Size: 0x80 (Inherited: 0x8)
struct FGameplayAbilityTargetData_ActorArray : FGameplayAbilityTargetData
{
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FGameplayAbilityTargetingLocationInfo SourceLocation; // 0x10(0x60)
	struct TArray<struct TWeakObjectPtr<struct AActor>> TargetActorArray; // 0x70(0x10)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetingLocationInfo
// Size: 0x60 (Inherited: 0x0)
struct FGameplayAbilityTargetingLocationInfo
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	enum class EGameplayAbilityTargetingLocationType LocationType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FTransform LiteralTransform; // 0x10(0x30)
	struct AActor* SourceActor; // 0x40(0x8)
	struct UMeshComponent* SourceComponent; // 0x48(0x8)
	struct UGameplayAbility* SourceAbility; // 0x50(0x8)
	struct FName SourceSocketName; // 0x58(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityTargetData_LocationInfo
// Size: 0xD0 (Inherited: 0x8)
struct FGameplayAbilityTargetData_LocationInfo : FGameplayAbilityTargetData
{
	uint8_t Pad_0x8[0x8]; // 0x8(0x8)
	struct FGameplayAbilityTargetingLocationInfo SourceLocation; // 0x10(0x60)
	struct FGameplayAbilityTargetingLocationInfo TargetLocation; // 0x70(0x60)
};

// Object: ScriptStruct GameplayAbilities.AbilityTaskDebugMessage
// Size: 0x18 (Inherited: 0x0)
struct FAbilityTaskDebugMessage
{
	struct UGameplayTask* FromTask; // 0x0(0x8)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: ScriptStruct GameplayAbilities.AbilityEndedData
// Size: 0x10 (Inherited: 0x0)
struct FAbilityEndedData
{
	struct UGameplayAbility* AbilityThatEnded; // 0x0(0x8)
	struct FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x8(0x4)
	bool bReplicateEndAbility; // 0xC(0x1)
	bool bWasCancelled; // 0xD(0x1)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilitySpecHandleAndPredictionKey
// Size: 0x8 (Inherited: 0x0)
struct FGameplayAbilitySpecHandleAndPredictionKey
{
	struct FGameplayAbilitySpecHandle AbilityHandle; // 0x0(0x4)
	int PredictionKeyAtCreation; // 0x4(0x4)
};

// Object: ScriptStruct GameplayAbilities.GameplayAbilityActorInfo
// Size: 0x40 (Inherited: 0x0)
struct FGameplayAbilityActorInfo
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct TWeakObjectPtr<struct AActor> OwnerActor; // 0x8(0x8)
	struct TWeakObjectPtr<struct AActor> AvatarActor; // 0x10(0x8)
	struct TWeakObjectPtr<struct APlayerController> PlayerController; // 0x18(0x8)
	struct TWeakObjectPtr<struct UAbilitySystemComponent> AbilitySystemComponent; // 0x20(0x8)
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SkeletalMeshComponent; // 0x28(0x8)
	struct TWeakObjectPtr<struct UAnimInstance> AnimInstance; // 0x30(0x8)
	struct TWeakObjectPtr<struct UMovementComponent> MovementComponent; // 0x38(0x8)
};

// Object: ScriptStruct GameplayAbilities.WorldReticleParameters
// Size: 0xC (Inherited: 0x0)
struct FWorldReticleParameters
{
	struct FVector AOEScale; // 0x0(0xC)
};

// Object: ScriptStruct GameplayAbilities.PreallocationInfo
// Size: 0x68 (Inherited: 0x0)
struct FPreallocationInfo
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
	struct TArray<struct AGameplayCueNotify_Actor*> ClassesNeedingPreallocation; // 0x50(0x10)
	uint8_t Pad_0x60[0x8]; // 0x60(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayCuePendingExecute
// Size: 0x170 (Inherited: 0x0)
struct FGameplayCuePendingExecute
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
	struct FPredictionKey PredictionKey; // 0x18(0x18)
	uint8_t PayloadType; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct UAbilitySystemComponent* OwningComponent; // 0x38(0x8)
	struct FGameplayEffectSpecForRPC FromSpec; // 0x40(0x78)
	struct FGameplayCueParameters CueParameters; // 0xB8(0xB8)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueTag
// Size: 0x8 (Inherited: 0x0)
struct FGameplayCueTag
{
	struct FGameplayTag GameplayCueTag; // 0x0(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueObjectLibrary
// Size: 0x58 (Inherited: 0x0)
struct FGameplayCueObjectLibrary
{
	struct TArray<struct FString> Paths; // 0x0(0x10)
	uint8_t Pad_0x10[0x20]; // 0x10(0x20)
	struct UObjectLibrary* ActorObjectLibrary; // 0x30(0x8)
	struct UObjectLibrary* StaticObjectLibrary; // 0x38(0x8)
	uint8_t Pad_0x40[0x4]; // 0x40(0x4)
	bool bShouldSyncScan; // 0x44(0x1)
	bool bShouldAsyncLoad; // 0x45(0x1)
	bool bShouldSyncLoad; // 0x46(0x1)
	uint8_t Pad_0x47[0x1]; // 0x47(0x1)
	struct UGameplayCueSet* CueSet; // 0x48(0x8)
	bool bHasBeenInitialized; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueNotifyData
// Size: 0x30 (Inherited: 0x0)
struct FGameplayCueNotifyData
{
	struct FGameplayTag GameplayCueTag; // 0x0(0x8)
	struct FSoftObjectPath GameplayCueNotifyObj; // 0x8(0x18)
	struct UObject* LoadedGameplayCueClass; // 0x20(0x8)
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueTranslationManager
// Size: 0x80 (Inherited: 0x0)
struct FGameplayCueTranslationManager
{
	struct TArray<struct FGameplayCueTranslatorNode> TranslationLUT; // 0x0(0x10)
	struct TMap<struct FName, struct FGameplayCueTranslatorNodeIndex> TranslationNameToIndexMap; // 0x10(0x50)
	struct UGameplayTagsManager* TagManager; // 0x60(0x8)
	uint8_t Pad_0x68[0x18]; // 0x68(0x18)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueTranslatorNodeIndex
// Size: 0x4 (Inherited: 0x0)
struct FGameplayCueTranslatorNodeIndex
{
	int Index; // 0x0(0x4)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueTranslatorNode
// Size: 0x78 (Inherited: 0x0)
struct FGameplayCueTranslatorNode
{
	struct TArray<struct FGameplayCueTranslationLink> Links; // 0x0(0x10)
	struct FGameplayCueTranslatorNodeIndex CachedIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FGameplayTag CachedGameplayTag; // 0x18(0x8)
	struct FName CachedGameplayTagName; // 0x20(0x8)
	uint8_t Pad_0x28[0x50]; // 0x28(0x50)
};

// Object: ScriptStruct GameplayAbilities.GameplayCueTranslationLink
// Size: 0x18 (Inherited: 0x0)
struct FGameplayCueTranslationLink
{
	struct UGameplayCueTranslator* RulesCDO; // 0x0(0x8)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
};

// Object: ScriptStruct GameplayAbilities.ActiveGameplayEffectQuery
// Size: 0x70 (Inherited: 0x0)
struct FActiveGameplayEffectQuery
{
	uint8_t Pad_0x0[0x70]; // 0x0(0x70)
};

// Object: ScriptStruct GameplayAbilities.InheritedTagContainer
// Size: 0x60 (Inherited: 0x0)
struct FInheritedTagContainer
{
	struct FGameplayTagContainer CombinedTags; // 0x0(0x20)
	struct FGameplayTagContainer Added; // 0x20(0x20)
	struct FGameplayTagContainer Removed; // 0x40(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectCue
// Size: 0x48 (Inherited: 0x0)
struct FGameplayEffectCue
{
	struct FGameplayAttribute MagnitudeAttribute; // 0x0(0x20)
	float MinLevel; // 0x20(0x4)
	float MaxLevel; // 0x24(0x4)
	struct FGameplayTagContainer GameplayCueTags; // 0x28(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayModifierInfo
// Size: 0x2A0 (Inherited: 0x0)
struct FGameplayModifierInfo
{
	struct FGameplayAttribute Attribute; // 0x0(0x20)
	enum class EGameplayModOp ModifierOp; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
	struct FScalableFloat Magnitude; // 0x28(0x28)
	struct FGameplayEffectModifierMagnitude ModifierMagnitude; // 0x50(0x1C8)
	struct FGameplayModEvaluationChannelSettings EvaluationChannelSettings; // 0x218(0x1)
	uint8_t Pad_0x219[0x7]; // 0x219(0x7)
	struct FGameplayTagRequirements SourceTags; // 0x220(0x40)
	struct FGameplayTagRequirements TargetTags; // 0x260(0x40)
};

// Object: ScriptStruct GameplayAbilities.GameplayTagRequirements
// Size: 0x40 (Inherited: 0x0)
struct FGameplayTagRequirements
{
	struct FGameplayTagContainer RequireTags; // 0x0(0x20)
	struct FGameplayTagContainer IgnoreTags; // 0x20(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayModEvaluationChannelSettings
// Size: 0x1 (Inherited: 0x0)
struct FGameplayModEvaluationChannelSettings
{
	uint8_t Channel; // 0x0(0x1)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectModifierMagnitude
// Size: 0x1C8 (Inherited: 0x0)
struct FGameplayEffectModifierMagnitude
{
	uint8_t MagnitudeCalculationType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FScalableFloat ScalableFloatMagnitude; // 0x8(0x28)
	struct FAttributeBasedFloat AttributeBasedMagnitude; // 0x30(0xF8)
	struct FCustomCalculationBasedFloat CustomMagnitude; // 0x128(0x90)
	struct FSetByCallerFloat SetByCallerMagnitude; // 0x1B8(0x10)
};

// Object: ScriptStruct GameplayAbilities.SetByCallerFloat
// Size: 0x10 (Inherited: 0x0)
struct FSetByCallerFloat
{
	struct FName DataName; // 0x0(0x8)
	struct FGameplayTag DataTag; // 0x8(0x8)
};

// Object: ScriptStruct GameplayAbilities.CustomCalculationBasedFloat
// Size: 0x90 (Inherited: 0x0)
struct FCustomCalculationBasedFloat
{
	struct UGameplayModMagnitudeCalculation* CalculationClassMagnitude; // 0x0(0x8)
	struct FScalableFloat Coefficient; // 0x8(0x28)
	struct FScalableFloat PreMultiplyAdditiveValue; // 0x30(0x28)
	struct FScalableFloat PostMultiplyAdditiveValue; // 0x58(0x28)
	struct FCurveTableRowHandle FinalLookupCurve; // 0x80(0x10)
};

// Object: ScriptStruct GameplayAbilities.AttributeBasedFloat
// Size: 0xF8 (Inherited: 0x0)
struct FAttributeBasedFloat
{
	struct FScalableFloat Coefficient; // 0x0(0x28)
	struct FScalableFloat PreMultiplyAdditiveValue; // 0x28(0x28)
	struct FScalableFloat PostMultiplyAdditiveValue; // 0x50(0x28)
	struct FGameplayEffectAttributeCaptureDefinition BackingAttribute; // 0x78(0x28)
	struct FCurveTableRowHandle AttributeCurve; // 0xA0(0x10)
	uint8_t AttributeCalculationType; // 0xB0(0x1)
	uint8_t FinalChannel; // 0xB1(0x1)
	uint8_t Pad_0xB2[0x6]; // 0xB2(0x6)
	struct FGameplayTagContainer SourceTagFilter; // 0xB8(0x20)
	struct FGameplayTagContainer TargetTagFilter; // 0xD8(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectExecutionDefinition
// Size: 0x58 (Inherited: 0x0)
struct FGameplayEffectExecutionDefinition
{
	struct UGameplayEffectExecutionCalculation* CalculationClass; // 0x0(0x8)
	struct FGameplayTagContainer PassedInTags; // 0x8(0x20)
	struct TArray<struct FGameplayEffectExecutionScopedModifierInfo> CalculationModifiers; // 0x28(0x10)
	struct TArray<struct UGameplayEffect*> ConditionalGameplayEffectClasses; // 0x38(0x10)
	struct TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x48(0x10)
};

// Object: ScriptStruct GameplayAbilities.ConditionalGameplayEffect
// Size: 0x28 (Inherited: 0x0)
struct FConditionalGameplayEffect
{
	struct UGameplayEffect* EffectClass; // 0x0(0x8)
	struct FGameplayTagContainer RequiredSourceTags; // 0x8(0x20)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectExecutionScopedModifierInfo
// Size: 0x280 (Inherited: 0x0)
struct FGameplayEffectExecutionScopedModifierInfo
{
	struct FGameplayEffectAttributeCaptureDefinition CapturedAttribute; // 0x0(0x28)
	enum class EGameplayModOp ModifierOp; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FGameplayEffectModifierMagnitude ModifierMagnitude; // 0x30(0x1C8)
	struct FGameplayModEvaluationChannelSettings EvaluationChannelSettings; // 0x1F8(0x1)
	uint8_t Pad_0x1F9[0x7]; // 0x1F9(0x7)
	struct FGameplayTagRequirements SourceTags; // 0x200(0x40)
	struct FGameplayTagRequirements TargetTags; // 0x240(0x40)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectCustomExecutionOutput
// Size: 0x18 (Inherited: 0x0)
struct FGameplayEffectCustomExecutionOutput
{
	struct TArray<struct FGameplayModifierEvaluatedData> OutputModifiers; // 0x0(0x10)
	uint8_t bTriggerConditionalGameplayEffects : 1; // 0x10(0x1), Mask(0x1)
	uint8_t bHandledStackCountManually : 1; // 0x10(0x1), Mask(0x2)
	uint8_t bHandledGameplayCuesManually : 1; // 0x10(0x1), Mask(0x4)
	uint8_t BitPad_0x10_3 : 5; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayModifierEvaluatedData
// Size: 0x38 (Inherited: 0x0)
struct FGameplayModifierEvaluatedData
{
	struct FGameplayAttribute Attribute; // 0x0(0x20)
	enum class EGameplayModOp ModifierOp; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	float Magnitude; // 0x24(0x4)
	struct FActiveGameplayEffectHandle Handle; // 0x28(0x8)
	bool IsValid; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectCustomExecutionParameters
// Size: 0xA8 (Inherited: 0x0)
struct FGameplayEffectCustomExecutionParameters
{
	uint8_t Pad_0x0[0xA8]; // 0x0(0xA8)
};

// Object: ScriptStruct GameplayAbilities.GameplayEffectContext
// Size: 0x70 (Inherited: 0x0)
struct FGameplayEffectContext
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct TWeakObjectPtr<struct AActor> Instigator; // 0x8(0x8)
	struct TWeakObjectPtr<struct AActor> EffectCauser; // 0x10(0x8)
	struct TWeakObjectPtr<struct UGameplayAbility> AbilityCDO; // 0x18(0x8)
	struct TWeakObjectPtr<struct UGameplayAbility> AbilityInstanceNotReplicated; // 0x20(0x8)
	int AbilityLevel; // 0x28(0x4)
	struct TWeakObjectPtr<struct UObject> SourceObject; // 0x2C(0x8)
	struct TWeakObjectPtr<struct UAbilitySystemComponent> InstigatorAbilitySystemComponent; // 0x34(0x8)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct TArray<struct TWeakObjectPtr<struct AActor>> Actors; // 0x40(0x10)
	uint8_t Pad_0x50[0x10]; // 0x50(0x10)
	struct FVector WorldOrigin; // 0x60(0xC)
	bool bHasWorldOrigin; // 0x6C(0x1)
	uint8_t Pad_0x6D[0x3]; // 0x6D(0x3)
};

// Object: ScriptStruct GameplayAbilities.GameplayTagResponseTableEntry
// Size: 0x50 (Inherited: 0x0)
struct FGameplayTagResponseTableEntry
{
	struct FGameplayTagReponsePair Positive; // 0x0(0x28)
	struct FGameplayTagReponsePair Negative; // 0x28(0x28)
};

// Object: ScriptStruct GameplayAbilities.GameplayTagReponsePair
// Size: 0x28 (Inherited: 0x0)
struct FGameplayTagReponsePair
{
	struct FGameplayTag Tag; // 0x0(0x8)
	struct UGameplayEffect* ResponseGameplayEffect; // 0x8(0x8)
	struct TArray<struct UGameplayEffect*> ResponseGameplayEffects; // 0x10(0x10)
	int SoftCountCap; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: Class GameplayAbilities.AbilitySystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102127644
	// Params: [ Num(3) Size(0x25) ]
	bool TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B45B8
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102127550
	// Params: [ Num(3) Size(0x25) ]
	bool TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle& HitResult, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B44F8
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B45B8
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212745c
	// Params: [ Num(3) Size(0x25) ]
	bool TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B47B0
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B44F8
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102127368
	// Params: [ Num(3) Size(0x25) ]
	bool TargetDataHasActor(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B4478
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B47B0
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCountToMax
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102127268
	// Params: [ Num(2) Size(0x30) ]
	struct FGameplayEffectSpecHandle SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B5BB8
	// [Call #5] RVA: 0x1020B5AC8
	// [Call #6] RVA: 0x1020C8DFC
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020B4478
	// [Call #18] RVA: 0x1020C5658
	// [Call #19] RVA: 0x1020C5658
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102127128
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayEffectSpecHandle SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int StackCount);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5B14
	// [Call #7] RVA: 0x1020B5AC8
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10211990C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1020B5BB8
	// [Call #19] RVA: 0x1020B5AC8
	// [Call #20] RVA: 0x1020C8DFC
	// [Call #21] RVA: 0x1020C8DFC
	// [Call #22] RVA: 0x1020C8DFC
	// [Call #23] RVA: 0x1020C8DFC
	// [Call #24] RVA: 0x1020C8DFC
	// [Call #25] RVA: 0x1020C8DFC
	// [Call #26] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102126fe8
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayEffectSpecHandle SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B555C
	// [Call #7] RVA: 0x1020B5AC8
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10211990C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020B5B14
	// [Call #21] RVA: 0x1020B5AC8
	// [Call #22] RVA: 0x1020C8DFC
	// [Call #23] RVA: 0x1020C8DFC
	// [Call #24] RVA: 0x1020C8DFC
	// [Call #25] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SendGameplayEventToActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102126e88
	// Params: [ Num(3) Size(0xB8) ]
	void SendGameplayEventToActor(struct AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C506C
	// [Call #8] RVA: 0x1020B2FBC
	// [Call #9] RVA: 0x1020C4EF4
	// [Call #10] RVA: 0x1020C4EF4
	// [Call #11] RVA: 0x1020C4EF4
	// [Call #12] RVA: 0x1020C4EF4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10211990C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1020B555C
	// [Call #20] RVA: 0x1020B5AC8
	// [Call #21] RVA: 0x1020C8DFC
	// [Call #22] RVA: 0x1020C8DFC
	// [Call #23] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.NotEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126d4c
	// Params: [ Num(3) Size(0x41) ]
	bool NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C64FC
	// [Call #6] RVA: 0x1020C64FC
	// [Call #7] RVA: 0x1020B36D0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1020C506C
	// [Call #24] RVA: 0x1020B2FBC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126bf8
	// Params: [ Num(5) Size(0x38) ]
	struct FGameplayEffectSpecHandle MakeSpecHandle(struct UGameplayEffect* InGameplayEffect, struct AActor* InInstigator, struct AActor* InEffectCauser, float InLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B3F7C
	// [Call #10] RVA: 0x1020B5AC8
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1020C64FC
	// [Call #19] RVA: 0x1020C64FC
	// [Call #20] RVA: 0x1020B36D0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeFilterHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126ae0
	// Params: [ Num(3) Size(0x40) ]
	struct FGameplayTargetDataFilterHandle MakeFilterHandle(struct FGameplayTargetDataFilter filter, struct AActor* FilterActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B3EB8
	// [Call #6] RVA: 0x10212ED4C
	// [Call #7] RVA: 0x1020C747C
	// [Call #8] RVA: 0x1020C747C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1020B3F7C
	// [Call #19] RVA: 0x1020B5AC8
	// [Call #20] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126a20
	// Params: [ Num(2) Size(0x21) ]
	bool IsValid(struct FGameplayAttribute Attribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C64FC
	// [Call #4] RVA: 0x1020B3080
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B3EB8
	// [Call #15] RVA: 0x10212ED4C
	// [Call #16] RVA: 0x1020C747C
	// [Call #17] RVA: 0x1020C747C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlledPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126920
	// Params: [ Num(2) Size(0xB9) ]
	bool IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4B40
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C64FC
	// [Call #13] RVA: 0x1020B3080
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126820
	// Params: [ Num(2) Size(0xB9) ]
	bool IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4B3C
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C7600
	// [Call #13] RVA: 0x1020B4B40
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x1020C76E8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.HasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126720
	// Params: [ Num(2) Size(0xB9) ]
	bool HasHitResult(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4CEC
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C7600
	// [Call #13] RVA: 0x1020B4B3C
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x1020C76E8
	// [Call #18] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126618
	// Params: [ Num(3) Size(0x60) ]
	struct FTransform GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B463C
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C7600
	// [Call #12] RVA: 0x1020B4CEC
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPointTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126510
	// Params: [ Num(3) Size(0x60) ]
	struct FTransform GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B48D0
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B463C
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126414
	// Params: [ Num(3) Size(0x30) ]
	struct FVector GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B4834
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B48D0
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212630c
	// Params: [ Num(2) Size(0xC4) ]
	struct FVector GetOrigin(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4EAC
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B4834
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetModifiedAttributeMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021261b4
	// Params: [ Num(3) Size(0x3C) ]
	float GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C64FC
	// [Call #7] RVA: 0x1020B60F8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1020C7600
	// [Call #20] RVA: 0x1020B4EAC
	// [Call #21] RVA: 0x1020C76E8
	// [Call #22] RVA: 0x1020C76E8
	// [Call #23] RVA: 0x1020C76E8
	// [Call #24] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102126098
	// Params: [ Num(2) Size(0xF0) ]
	struct FTransform GetInstigatorTransform(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4DDC
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10211990C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C64FC
	// [Call #16] RVA: 0x1020B60F8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x1020C8DFC
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125f98
	// Params: [ Num(2) Size(0xC0) ]
	struct AActor* GetInstigatorActor(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4DD8
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C7600
	// [Call #13] RVA: 0x1020B4DDC
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x1020C76E8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10211990C
	// [Call #20] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResultFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125e70
	// Params: [ Num(3) Size(0xB0) ]
	struct FHitResult GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle& HitResult, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B4538
	// [Call #6] RVA: 0x106C8DCEC
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C7600
	// [Call #13] RVA: 0x1020B4DD8
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x1020C76E8
	// [Call #18] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125d2c
	// Params: [ Num(2) Size(0x140) ]
	struct FHitResult GetHitResult(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4C7C
	// [Call #5] RVA: 0x106C8DCEC
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B4538
	// [Call #16] RVA: 0x106C8DCEC
	// [Call #17] RVA: 0x1020C5658

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueEndLocationAndNormal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125b48
	// Params: [ Num(5) Size(0xD9) ]
	bool GetGameplayCueEndLocationAndNormal(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Location, struct FVector& Normal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C7600
	// [Call #10] RVA: 0x1020B4F24
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C76E8
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueDirection
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021259bc
	// Params: [ Num(4) Size(0xCD) ]
	bool GetGameplayCueDirection(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Direction);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020B50B4
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C76E8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125864
	// Params: [ Num(4) Size(0x30) ]
	float GetFloatAttributeFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C64FC
	// [Call #8] RVA: 0x1020B3114
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBaseFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212570c
	// Params: [ Num(4) Size(0x30) ]
	float GetFloatAttributeBaseFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C64FC
	// [Call #8] RVA: 0x1020B3284
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C64FC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021255b4
	// Params: [ Num(4) Size(0x30) ]
	float GetFloatAttributeBase(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C64FC
	// [Call #8] RVA: 0x1020B3200
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C64FC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttribute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212545c
	// Params: [ Num(4) Size(0x30) ]
	float GetFloatAttribute(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C64FC
	// [Call #8] RVA: 0x1020B3090
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C64FC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetEffectContext
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10212535c
	// Params: [ Num(2) Size(0x30) ]
	struct FGameplayEffectContextHandle GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B5C60
	// [Call #5] RVA: 0x10209E778
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1020C64FC
	// [Call #20] RVA: 0x1020B3090
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetDataCountFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021252b4
	// Params: [ Num(2) Size(0x24) ]
	int GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4228
	// [Call #4] RVA: 0x1020C5658
	// [Call #5] RVA: 0x1020C5658
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10211990C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1020B5C60
	// [Call #11] RVA: 0x10209E778
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C8DFC
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllLinkedGameplayEffectSpecHandles
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021251b4
	// Params: [ Num(2) Size(0x28) ]
	struct TArray<struct FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B5D1C
	// [Call #5] RVA: 0x1020EEB70
	// [Call #6] RVA: 0x1020CA7A4
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020CA7A4
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B4228
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10211990C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1020B5C60
	// [Call #23] RVA: 0x10209E778
	// [Call #24] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorsFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102125098
	// Params: [ Num(3) Size(0x38) ]
	struct TArray<struct AActor*> GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B4230
	// [Call #6] RVA: 0x10212ECFC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10211990C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B5D1C
	// [Call #16] RVA: 0x1020EEB70
	// [Call #17] RVA: 0x1020CA7A4
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x1020C8DFC
	// [Call #20] RVA: 0x1020CA7A4
	// [Call #21] RVA: 0x1020C8DFC
	// [Call #22] RVA: 0x1020C8DFC
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102124f98
	// Params: [ Num(2) Size(0xBC) ]
	int GetActorCount(struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C7600
	// [Call #4] RVA: 0x1020B4B48
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B4230
	// [Call #15] RVA: 0x10212ECFC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x101F811FC
	// [Call #19] RVA: 0x1020C5658
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10211990C
	// [Call #22] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102124e3c
	// Params: [ Num(3) Size(0xC8) ]
	struct AActor* GetActorByIndex(struct FGameplayCueParameters Parameters, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C7600
	// [Call #6] RVA: 0x1020B4BE8
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020C7600
	// [Call #15] RVA: 0x1020B4B48
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x1020C76E8
	// [Call #18] RVA: 0x1020C76E8
	// [Call #19] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectTotalDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124db8
	// Params: [ Num(2) Size(0xC) ]
	float GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B5F60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C7600
	// [Call #9] RVA: 0x1020B4BE8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C76E8
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStartTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124d34
	// Params: [ Num(2) Size(0xC) ]
	float GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B5E7C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5F60
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C7600
	// [Call #12] RVA: 0x1020B4BE8
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackLimitCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124cb0
	// Params: [ Num(2) Size(0xC) ]
	int GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B5E24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5E7C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B5F60
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124c2c
	// Params: [ Num(2) Size(0xC) ]
	int GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B5DD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5E24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B5E7C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B5F60

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectRemainingDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124b70
	// Params: [ Num(3) Size(0x14) ]
	float GetActiveGameplayEffectRemainingDuration(struct UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B5FB4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B5DD4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B5E24
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B5E7C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectExpectedEndTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124aec
	// Params: [ Num(2) Size(0xC) ]
	float GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B5EC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B5FB4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B5DD4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B5E24

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectDebugString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102124a40
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B6168
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1020B5EC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B5FB4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021249c4
	// Params: [ Num(2) Size(0x10) ]
	struct UAbilitySystemComponent* GetAbilitySystemComponent(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B2FB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B6168
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B5EC8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1020B5FB4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.ForwardGameplayCueToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102124840
	// Params: [ Num(3) Size(0xD0) ]
	void ForwardGameplayCueToTarget(struct TScriptInterface<Class> TargetCueInterface, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020B4D18
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C76E8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020B2FB4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.FilterTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021246dc
	// Params: [ Num(3) Size(0x50) ]
	struct FGameplayAbilityTargetDataHandle FilterTargetData(struct FGameplayAbilityTargetDataHandle& TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B3AE4
	// [Call #6] RVA: 0x1020C6444
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x1020C747C
	// [Call #9] RVA: 0x1020C747C
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C747C
	// [Call #13] RVA: 0x1020C747C
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTagsAndBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102124464
	// Params: [ Num(7) Size(0x74) ]
	float EvaluateAttributeValueWithTagsAndBase(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, float baseValue, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C64FC
	// [Call #14] RVA: 0x1020B3560
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212422c
	// Params: [ Num(6) Size(0x70) ]
	float EvaluateAttributeValueWithTags(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C64FC
	// [Call #12] RVA: 0x1020B339C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x1020C4E8C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EqualEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021240f0
	// Params: [ Num(3) Size(0x41) ]
	bool EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C64FC
	// [Call #6] RVA: 0x1020C64FC
	// [Call #7] RVA: 0x1020B36CC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextSetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102123fd8
	// Params: [ Num(2) Size(0x24) ]
	void EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B4B24
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C64FC
	// [Call #16] RVA: 0x1020C64FC
	// [Call #17] RVA: 0x1020B36CC
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123ef0
	// Params: [ Num(2) Size(0x19) ]
	bool EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4924
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B4B24
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180
	// [Call #17] RVA: 0x1020C5180
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123e08
	// Params: [ Num(2) Size(0x19) ]
	bool EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4934
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B4924
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextHasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123d20
	// Params: [ Num(2) Size(0x19) ]
	bool EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B49BC
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B4934
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetSourceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123c38
	// Params: [ Num(2) Size(0x20) ]
	struct UObject* EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4A78
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B49BC
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOriginalInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123b50
	// Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4A30
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B4A78
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123a64
	// Params: [ Num(2) Size(0x24) ]
	struct FVector EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4A90
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B4A30
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212397c
	// Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4A00
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B4A90
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123864
	// Params: [ Num(2) Size(0xA0) ]
	struct FHitResult EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B494C
	// [Call #4] RVA: 0x106C8DCEC
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B4A00
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetEffectCauser
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212377c
	// Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B4A48
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B494C
	// [Call #12] RVA: 0x106C8DCEC
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextAddHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021235cc
	// Params: [ Num(3) Size(0xA1) ]
	void EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C8DCEC
	// [Call #9] RVA: 0x1020B49E8
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020B4A48
	// [Call #18] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesTargetDataContainActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123498
	// Params: [ Num(4) Size(0x31) ]
	bool DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle& TargetData, int Index, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B4334
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C8CD38
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesGameplayCueMeetTagRequirements
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021232a4
	// Params: [ Num(4) Size(0x139) ]
	bool DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements& SourceTagReqs, struct FGameplayTagRequirements& TargetTagReqs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020B53E4
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C64D4
	// [Call #11] RVA: 0x1020C64D4
	// [Call #12] RVA: 0x1020C76E8
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C64D4
	// [Call #15] RVA: 0x1020C64D4
	// [Call #16] RVA: 0x1020C76E8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.CloneSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102123130
	// Params: [ Num(4) Size(0x40) ]
	struct FGameplayEffectSpecHandle CloneSpecHandle(struct AActor* InNewInstigator, struct AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10211990C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B405C
	// [Call #9] RVA: 0x1020B5AC8
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignTagSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122fb0
	// Params: [ Num(4) Size(0x40) ]
	struct FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B54C4
	// [Call #9] RVA: 0x1020B5AC8
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10211990C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122e30
	// Params: [ Num(4) Size(0x40) ]
	struct FGameplayEffectSpecHandle AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FName DataName, float Magnitude);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B542C
	// [Call #9] RVA: 0x1020B5AC8
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10211990C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AppendTargetDataHandle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102122ce0
	// Params: [ Num(3) Size(0x60) ]
	struct FGameplayAbilityTargetDataHandle AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle& HandleToAdd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C68C8
	// [Call #6] RVA: 0x1020B36D4
	// [Call #7] RVA: 0x1020C6444
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10211990C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffectSpec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122b4c
	// Params: [ Num(3) Size(0x48) ]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10211990C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B5878
	// [Call #8] RVA: 0x1020B5AC8
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C8DFC
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x1020C68C8

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122a0c
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, struct UGameplayEffect* LinkedGameplayEffect);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5958
	// [Call #7] RVA: 0x1020B5AC8
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10211990C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10211990C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1020B5878
	// [Call #22] RVA: 0x1020B5AC8
	// [Call #23] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122890
	// Params: [ Num(3) Size(0x50) ]
	struct FGameplayEffectSpecHandle AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C5138
	// [Call #7] RVA: 0x1020B569C
	// [Call #8] RVA: 0x1020B5AC8
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10211990C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x1020B5958

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122750
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayEffectSpecHandle AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B55F8
	// [Call #7] RVA: 0x1020B5AC8
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10211990C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C5138
	// [Call #21] RVA: 0x1020B569C
	// [Call #22] RVA: 0x1020B5AC8
	// [Call #23] RVA: 0x1020C8DFC
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x1020C8DFC
	// [Call #26] RVA: 0x1020C4E8C
	// [Call #27] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021225d4
	// Params: [ Num(3) Size(0x50) ]
	struct FGameplayEffectSpecHandle AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C5138
	// [Call #7] RVA: 0x1020B57DC
	// [Call #8] RVA: 0x1020B5AC8
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10211990C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x1020B55F8

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102122494
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayEffectSpecHandle AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B5738
	// [Call #7] RVA: 0x1020B5AC8
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10211990C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C5138
	// [Call #21] RVA: 0x1020B57DC
	// [Call #22] RVA: 0x1020B5AC8
	// [Call #23] RVA: 0x1020C8DFC
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x1020C8DFC
	// [Call #26] RVA: 0x1020C4E8C
	// [Call #27] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromLocations
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212232c
	// Params: [ Num(3) Size(0xE0) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo& SourceLocation, struct FGameplayAbilityTargetingLocationInfo& TargetLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B3700
	// [Call #6] RVA: 0x1020C6444
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10211990C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B5738
	// [Call #16] RVA: 0x1020B5AC8
	// [Call #17] RVA: 0x1020C8DFC
	// [Call #18] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102122268
	// Params: [ Num(2) Size(0xA8) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(struct FHitResult& HitResult);
	// [Call #1] RVA: 0x106C8CD38
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B4130
	// [Call #5] RVA: 0x1020C6444
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B3700
	// [Call #14] RVA: 0x1020C6444
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10211990C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActorArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102122144
	// Params: [ Num(3) Size(0x38) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(struct TArray<struct AActor*>& ActorArray, bool OneTargetPerHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B3928
	// [Call #6] RVA: 0x1020C6444
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B4130
	// [Call #16] RVA: 0x1020C6444
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x1020C5658
	// [Call #19] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021220a0
	// Params: [ Num(2) Size(0x28) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B386C
	// [Call #4] RVA: 0x1020C6444
	// [Call #5] RVA: 0x1020C5658
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B3928
	// [Call #13] RVA: 0x1020C6444
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x101F811FC
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x106C8CD38
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1020B4130
};

// Object: Class GameplayAbilities.AbilitySystemComponent
// Size: 0x1140 (Inherited: 0x1F0)
struct UAbilitySystemComponent : UGameplayTasksComponent
{
	uint8_t Pad_0x1F0[0x8]; // 0x1F0(0x8)
	struct TArray<struct FAttributeDefaults> DefaultStartingData; // 0x1F8(0x10)
	struct TArray<struct UAttributeSet*> SpawnedAttributes; // 0x208(0x10)
	uint8_t Pad_0x218[0xC8]; // 0x218(0xC8)
	float OutgoingDuration; // 0x2E0(0x4)
	float IncomingDuration; // 0x2E4(0x4)
	uint8_t Pad_0x2E8[0x28]; // 0x2E8(0x28)
	struct TArray<struct FString> ClientDebugStrings; // 0x310(0x10)
	struct TArray<struct FString> ServerDebugStrings; // 0x320(0x10)
	struct FGameplayAbilitySpecContainer ActivatableAbilities; // 0x330(0xC8)
	uint8_t Pad_0x3F8[0x50]; // 0x3F8(0x50)
	struct TArray<struct UGameplayAbility*> AllReplicatedInstancedAbilities; // 0x448(0x10)
	uint8_t Pad_0x458[0x238]; // 0x458(0x238)
	struct TArray<struct AGameplayAbilityTargetActor*> SpawnedTargetActors; // 0x690(0x10)
	struct FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // 0x6A0(0x30)
	uint8_t Pad_0x6D0[0x8]; // 0x6D0(0x8)
	struct FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // 0x6D8(0x30)
	uint8_t Pad_0x708[0xB8]; // 0x708(0xB8)
	struct AActor* OwnerActor; // 0x7C0(0x8)
	struct AActor* AvatarActor; // 0x7C8(0x8)
	uint8_t Pad_0x7D0[0x18]; // 0x7D0(0x18)
	struct FActiveGameplayEffectsContainer ActiveGameplayEffects; // 0x7E8(0x428)
	struct FActiveGameplayCueContainer ActiveGameplayCues; // 0xC10(0xD0)
	struct FActiveGameplayCueContainer MinimalReplicationGameplayCues; // 0xCE0(0xD0)
	uint8_t Pad_0xDB0[0x128]; // 0xDB0(0x128)
	struct TArray<uint8_t> BlockedAbilityBindings; // 0xED8(0x10)
	uint8_t Pad_0xEE8[0x128]; // 0xEE8(0x128)
	struct FMinimalReplicationTagCountMap MinimalReplicationTags; // 0x1010(0x60)
	uint8_t Pad_0x1070[0x10]; // 0x1070(0x10)
	struct FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // 0x1080(0xC0)


	// Object: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilityByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212da34
	// Params: [ Num(3) Size(0xA) ]
	bool TryActivateAbilityByClass(struct UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C0ED4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilitiesByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10212d92c
	// Params: [ Num(3) Size(0x22) ]
	bool TryActivateAbilitiesByTag(struct FGameplayTagContainer& GameplayTagContainer, bool bAllowRemoteActivation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C0A3C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C0ED4
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemComponent.TargetConfirm
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212d918
	// Params: [ Num(0) Size(0x0) ]
	void TargetConfirm();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C0A3C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C0ED4
	// [Call #14] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemComponent.TargetCancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212d904
	// Params: [ Num(0) Size(0x0) ]
	void TargetCancel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C0A3C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C0ED4
	// [Call #14] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetUserAbilityActivationInhibited
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212d880
	// Params: [ Num(1) Size(0x1) ]
	void SetUserAbilityActivationInhibited(bool NewInhibit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C2300
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C0A3C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevelUsingQuery
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x10212d778
	// Params: [ Num(2) Size(0x13C) ]
	void SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int NewLevel);
	// [Call #1] RVA: 0x1020EC904
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020FA7E8
	// [Call #7] RVA: 0x1020B7E94
	// [Call #8] RVA: 0x1020C5240
	// [Call #9] RVA: 0x1020C5240
	// [Call #10] RVA: 0x1020C5240
	// [Call #11] RVA: 0x1020C5240
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C2300
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevel
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x10212d6b8
	// Params: [ Num(2) Size(0xC) ]
	void SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int NewLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B7E8C
	// [Call #6] RVA: 0x1020EC904
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020FA7E8
	// [Call #12] RVA: 0x1020B7E94
	// [Call #13] RVA: 0x1020C5240
	// [Call #14] RVA: 0x1020C5240
	// [Call #15] RVA: 0x1020C5240
	// [Call #16] RVA: 0x1020C5240
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C2300

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbilityWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212d4e0
	// Params: [ Num(4) Size(0xC8) ]
	void ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C506C
	// [Call #10] RVA: 0x1020C4EF4
	// [Call #11] RVA: 0x1020C4EF4
	// [Call #12] RVA: 0x1020C4EF4
	// [Call #13] RVA: 0x1020C4EF4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212d3b8
	// Params: [ Num(3) Size(0x20) ]
	void ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetDataCancelled
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212d288
	// Params: [ Num(3) Size(0x38) ]
	void ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212d0c0
	// Params: [ Num(5) Size(0x60) ]
	void ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEventWithPayload
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cf18
	// Params: [ Num(5) Size(0x44) ]
	void ServerSetReplicatedEventWithPayload(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cdac
	// Params: [ Num(4) Size(0x38) ]
	void ServerSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputReleased
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cd24
	// Params: [ Num(1) Size(0x4) ]
	void ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputPressed
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cc9c
	// Params: [ Num(1) Size(0x4) ]
	void ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_RequestWithStrings
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cbfc
	// Params: [ Num(1) Size(0x10) ]
	void ServerPrintDebug_RequestWithStrings(struct TArray<struct FString> Strings);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_Request
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10212cbe0
	// Params: [ Num(0) Size(0x0) ]
	void ServerPrintDebug_Request();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212ca94
	// Params: [ Num(3) Size(0x40) ]
	void ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetPlayRate
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212c9d4
	// Params: [ Num(2) Size(0xC) ]
	void ServerCurrentMontageSetPlayRate(struct UAnimMontage* ClientAnimMontage, float InPlayRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetNextSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212c8a0
	// Params: [ Num(4) Size(0x20) ]
	void ServerCurrentMontageSetNextSectionName(struct UAnimMontage* ClientAnimMontage, float ClientPosition, struct FName SectionName, struct FName NextSectionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageJumpToSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212c7e4
	// Params: [ Num(2) Size(0x10) ]
	void ServerCurrentMontageJumpToSectionName(struct UAnimMontage* ClientAnimMontage, struct FName SectionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10212c6ec
	// Params: [ Num(2) Size(0x28) ]
	void ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffectBySourceEffect
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x10212c5fc
	// Params: [ Num(3) Size(0x14) ]
	void RemoveActiveGameplayEffectBySourceEffect(struct UGameplayEffect* GameplayEffect, struct UAbilitySystemComponent* InstigatorAbilitySystemComponent, int StacksToRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B7D38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffect
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x10212c52c
	// Params: [ Num(3) Size(0xD) ]
	bool RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int StacksToRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10209EBD8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B7D38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212c45c
	// Params: [ Num(2) Size(0x24) ]
	int RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B89DC
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10209EBD8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithSourceTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212c38c
	// Params: [ Num(2) Size(0x24) ]
	int RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8A50
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B89DC
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10209EBD8

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithGrantedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212c2bc
	// Params: [ Num(2) Size(0x24) ]
	int RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8B38
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8A50
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1020C5138
	// [Call #22] RVA: 0x1020B89DC
	// [Call #23] RVA: 0x1020C4E8C
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x1020C4E8C

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithAppliedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212c1ec
	// Params: [ Num(2) Size(0x24) ]
	int RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1020C5138
	// [Call #22] RVA: 0x1020B8A50
	// [Call #23] RVA: 0x1020C4E8C
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x1020C4E8C

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ServerDebugString
	// Flags: [Native|Public]
	// Offset: 0x10212c1d0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ServerDebugString();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1020C5138
	// [Call #22] RVA: 0x1020B8A50
	// [Call #23] RVA: 0x1020C4E8C
	// [Call #24] RVA: 0x1020C4E8C

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ReplicatedAnimMontage
	// Flags: [Final|Native|Protected]
	// Offset: 0x10212c1bc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ReplicatedAnimMontage();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1020C5138
	// [Call #22] RVA: 0x1020B8A50

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_OwningActor
	// Flags: [Final|Native|Public]
	// Offset: 0x10212c1a8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_OwningActor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ClientDebugString
	// Flags: [Native|Public]
	// Offset: 0x10212c18c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ClientDebugString();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ActivateAbilities
	// Flags: [Final|Native|Protected]
	// Offset: 0x10212c178
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ActivateAbilities();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x1020B8AC4
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C5138
	// [Call #13] RVA: 0x1020B8B38
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212bf9c
	// Params: [ Num(3) Size(0xF0) ]
	void NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5138
	// [Call #8] RVA: 0x1020C7600
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212bddc
	// Params: [ Num(3) Size(0x50) ]
	void NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5138
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212bc00
	// Params: [ Num(3) Size(0xF0) ]
	void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5138
	// [Call #8] RVA: 0x1020C7600
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C76E8
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C76E8
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212ba4c
	// Params: [ Num(3) Size(0xD8) ]
	void NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b924
	// Params: [ Num(2) Size(0x90) ]
	void NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey);
	// [Call #1] RVA: 0x1020EEEC0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020FE458
	// [Call #7] RVA: 0x1020C8E78
	// [Call #8] RVA: 0x1020C8E78
	// [Call #9] RVA: 0x1020C8E78
	// [Call #10] RVA: 0x1020C8E78
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b7a8
	// Params: [ Num(3) Size(0x38) ]
	void NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1020EEEC0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020FE458

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b5f4
	// Params: [ Num(3) Size(0xD8) ]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b4f8
	// Params: [ Num(2) Size(0x90) ]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey);
	// [Call #1] RVA: 0x1020EEEC0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C8E78
	// [Call #7] RVA: 0x1020C8E78
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C7600

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b344
	// Params: [ Num(3) Size(0xD8) ]
	void NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C7600
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x1020C76E8
	// [Call #10] RVA: 0x1020C76E8
	// [Call #11] RVA: 0x1020C76E8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1020EEEC0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10212b1c8
	// Params: [ Num(3) Size(0x38) ]
	void NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.MakeOutgoingSpec
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212b03c
	// Params: [ Num(4) Size(0x40) ]
	struct FGameplayEffectSpecHandle MakeOutgoingSpec(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10209D314
	// [Call #8] RVA: 0x1020B5AC8
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C8DFC
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.MakeEffectContext
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212afd8
	// Params: [ Num(1) Size(0x18) ]
	struct FGameplayEffectContextHandle MakeEffectContext();
	// [Call #1] RVA: 0x1020B6C7C
	// [Call #2] RVA: 0x10209E778
	// [Call #3] RVA: 0x1020C5180
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10209D314
	// [Call #13] RVA: 0x1020B5AC8
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180
	// [Call #17] RVA: 0x1020C8DFC
	// [Call #18] RVA: 0x1020C5180
	// [Call #19] RVA: 0x1020C5180
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.K2_InitStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212af24
	// Params: [ Num(2) Size(0x10) ]
	void K2_InitStats(struct UAttributeSet* Attributes, struct UDataTable* DataTable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B6890
	// [Call #6] RVA: 0x1020B6C7C
	// [Call #7] RVA: 0x10209E778
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10209D314
	// [Call #18] RVA: 0x1020B5AC8
	// [Call #19] RVA: 0x1020C8DFC
	// [Call #20] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.AbilitySystemComponent.IsGameplayCueActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212ae90
	// Params: [ Num(2) Size(0x9) ]
	bool IsGameplayCueActive(struct FGameplayTag GameplayCueTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B6890
	// [Call #8] RVA: 0x1020B6C7C
	// [Call #9] RVA: 0x10209E778
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetUserAbilityActivationInhibited
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212ae5c
	// Params: [ Num(1) Size(0x1) ]
	bool GetUserAbilityActivationInhibited();
	// [Call #1] RVA: 0x10209B26C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B6890
	// [Call #9] RVA: 0x1020B6C7C
	// [Call #10] RVA: 0x10209E778
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectMagnitude
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212ad44
	// Params: [ Num(3) Size(0x2C) ]
	float GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C64FC
	// [Call #6] RVA: 0x1020B7E1C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10209B26C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212ac3c
	// Params: [ Num(4) Size(0x18) ]
	int GetGameplayEffectCount(struct UGameplayEffect* SourceGameplayEffect, struct UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B6D0C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C64FC
	// [Call #13] RVA: 0x1020B7E1C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10209B26C

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetActiveEffects
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x10212ab58
	// Params: [ Num(2) Size(0x148) ]
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffects(struct FGameplayEffectQuery& Query);
	// [Call #1] RVA: 0x1020EC904
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B89D4
	// [Call #5] RVA: 0x1020FA7EC
	// [Call #6] RVA: 0x1020CA774
	// [Call #7] RVA: 0x1020C5240
	// [Call #8] RVA: 0x1020CA774
	// [Call #9] RVA: 0x1020C5240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020B6D0C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212aad0
	// Params: [ Num(1) Size(0x4) ]
	void ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020EC904
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B89D4
	// [Call #7] RVA: 0x1020FA7EC
	// [Call #8] RVA: 0x1020CA774
	// [Call #9] RVA: 0x1020C5240
	// [Call #10] RVA: 0x1020CA774
	// [Call #11] RVA: 0x1020C5240
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10212a9b8
	// Params: [ Num(3) Size(0x20) ]
	void ClientSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020EC904
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B89D4
	// [Call #13] RVA: 0x1020FA7EC
	// [Call #14] RVA: 0x1020CA774
	// [Call #15] RVA: 0x1020C5240

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientPrintDebug_Response
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10212a8d8
	// Params: [ Num(2) Size(0x14) ]
	void ClientPrintDebug_Response(struct TArray<struct FString> Strings, int GameFlags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212a7e0
	// Params: [ Num(2) Size(0x28) ]
	void ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212a6e8
	// Params: [ Num(2) Size(0x28) ]
	void ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceedWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212a55c
	// Params: [ Num(3) Size(0xC8) ]
	void ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C506C
	// [Call #8] RVA: 0x1020C4EF4
	// [Call #9] RVA: 0x1020C4EF4
	// [Call #10] RVA: 0x1020C4EF4
	// [Call #11] RVA: 0x1020C4EF4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212a480
	// Params: [ Num(2) Size(0x20) ]
	void ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C506C
	// [Call #12] RVA: 0x1020C4EF4
	// [Call #13] RVA: 0x1020C4EF4
	// [Call #14] RVA: 0x1020C4EF4

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilityFailed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10212a3bc
	// Params: [ Num(2) Size(0x6) ]
	void ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16_t PredictionKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212a214
	// Params: [ Num(5) Size(0x38) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(struct UGameplayEffect* GameplayEffectClass, struct UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B6E0C
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5180
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212a0a4
	// Params: [ Num(4) Size(0x30) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B72B0
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102129f98
	// Params: [ Num(3) Size(0x28) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle& SpecHandle, struct UAbilitySystemComponent* Target);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020B7CA8
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020B72B0
	// [Call #17] RVA: 0x1020C5180
	// [Call #18] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToSelf
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102129ed0
	// Params: [ Num(2) Size(0x20) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle& SpecHandle);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020B7CE8
	// [Call #5] RVA: 0x1020C8DFC
	// [Call #6] RVA: 0x1020C8DFC
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10211990C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020B7CA8
	// [Call #14] RVA: 0x1020C8DFC
	// [Call #15] RVA: 0x1020C8DFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityConfirmOrCancel__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void AbilityConfirmOrCancel__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityAbilityKey__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void AbilityAbilityKey__DelegateSignature(int InputID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class GameplayAbilities.AbilitySystemDebugHUD
// Size: 0x598 (Inherited: 0x598)
struct AAbilitySystemDebugHUD : AHUD
{
};

// Object: Class GameplayAbilities.AbilitySystemGlobals
// Size: 0x238 (Inherited: 0x28)
struct UAbilitySystemGlobals : UObject
{
	struct FSoftClassPath AbilitySystemGlobalsClassName; // 0x28(0x18)
	uint8_t Pad_0x40[0x28]; // 0x40(0x28)
	struct FGameplayTag ActivateFailCooldownTag; // 0x68(0x8)
	struct FName ActivateFailCooldownName; // 0x70(0x8)
	struct FGameplayTag ActivateFailCostTag; // 0x78(0x8)
	struct FName ActivateFailCostName; // 0x80(0x8)
	struct FGameplayTag ActivateFailTagsBlockedTag; // 0x88(0x8)
	struct FName ActivateFailTagsBlockedName; // 0x90(0x8)
	struct FGameplayTag ActivateFailTagsMissingTag; // 0x98(0x8)
	struct FName ActivateFailTagsMissingName; // 0xA0(0x8)
	struct FGameplayTag ActivateFailNetworkingTag; // 0xA8(0x8)
	struct FName ActivateFailNetworkingName; // 0xB0(0x8)
	int MinimalReplicationTagCountBits; // 0xB8(0x4)
	bool bAllowGameplayModEvaluationChannels; // 0xBC(0x1)
	uint8_t DefaultGameplayModEvaluationChannel; // 0xBD(0x1)
	uint8_t Pad_0xBE[0x2]; // 0xBE(0x2)
	struct FName GameplayModEvaluationChannelAliases[0xA]; // 0xC0(0x50)
	struct FSoftObjectPath GlobalCurveTableName; // 0x110(0x18)
	struct FSoftObjectPath GlobalAttributeMetaDataTableName; // 0x128(0x18)
	struct FSoftObjectPath GlobalAttributeSetDefaultsTableName; // 0x140(0x18)
	struct TArray<struct FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // 0x158(0x10)
	struct FSoftObjectPath GlobalGameplayCueManagerClass; // 0x168(0x18)
	struct FSoftObjectPath GlobalGameplayCueManagerName; // 0x180(0x18)
	struct TArray<struct FString> GameplayCueNotifyPaths; // 0x198(0x10)
	struct FSoftObjectPath GameplayTagResponseTableName; // 0x1A8(0x18)
	struct UGameplayTagReponseTable* GameplayTagResponseTable; // 0x1C0(0x8)
	bool PredictTargetGameplayEffects; // 0x1C8(0x1)
	uint8_t Pad_0x1C9[0x7]; // 0x1C9(0x7)
	struct UCurveTable* GlobalCurveTable; // 0x1D0(0x8)
	struct TArray<struct UCurveTable*> GlobalAttributeDefaultsTables; // 0x1D8(0x10)
	struct UDataTable* GlobalAttributeMetaDataTable; // 0x1E8(0x8)
	struct UGameplayCueManager* GlobalGameplayCueManager; // 0x1F0(0x8)
	uint8_t Pad_0x1F8[0x40]; // 0x1F8(0x40)


	// Object: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCosts
	// Flags: [Exec|Native|Public]
	// Offset: 0x10212f8d0
	// Params: [ Num(0) Size(0x0) ]
	void ToggleIgnoreAbilitySystemCosts();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCooldowns
	// Flags: [Exec|Native|Public]
	// Offset: 0x10212f8b4
	// Params: [ Num(0) Size(0x0) ]
	void ToggleIgnoreAbilitySystemCooldowns();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilitySystemInterface
// Size: 0x28 (Inherited: 0x28)
struct IAbilitySystemInterface : IInterface
{
};

// Object: Class GameplayAbilities.AttributeSet
// Size: 0x30 (Inherited: 0x28)
struct UAttributeSet : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: Class GameplayAbilities.AbilitySystemTestAttributeSet
// Size: 0x70 (Inherited: 0x30)
struct UAbilitySystemTestAttributeSet : UAttributeSet
{
	float MaxHealth; // 0x2C(0x4)
	float Health; // 0x30(0x4)
	float Mana; // 0x34(0x4)
	float MaxMana; // 0x38(0x4)
	float Damage; // 0x3C(0x4)
	float SpellDamage; // 0x40(0x4)
	float PhysicalDamage; // 0x44(0x4)
	float CritChance; // 0x48(0x4)
	float CritMultiplier; // 0x4C(0x4)
	float ArmorDamageReduction; // 0x50(0x4)
	float DodgeChance; // 0x54(0x4)
	float LifeSteal; // 0x58(0x4)
	float Strength; // 0x5C(0x4)
	float StackingAttribute1; // 0x60(0x4)
	float StackingAttribute2; // 0x64(0x4)
	float NoStackAttribute; // 0x68(0x4)
};

// Object: Class GameplayAbilities.AbilitySystemTestPawn
// Size: 0x558 (Inherited: 0x538)
struct AAbilitySystemTestPawn : ADefaultPawn
{
	uint8_t Pad_0x538[0x18]; // 0x538(0x18)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x550(0x8)
};

// Object: Class GameplayAbilities.AbilityTask
// Size: 0x78 (Inherited: 0x60)
struct UAbilityTask : UGameplayTask
{
	struct UGameplayAbility* Ability; // 0x60(0x8)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x68(0x8)
	uint8_t Pad_0x70[0x8]; // 0x70(0x8)
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotion_Base
// Size: 0xB0 (Inherited: 0x78)
struct UAbilityTask_ApplyRootMotion_Base : UAbilityTask
{
	struct FName ForceName; // 0x78(0x8)
	uint8_t FinishVelocityMode; // 0x80(0x1)
	uint8_t Pad_0x81[0x3]; // 0x81(0x3)
	struct FVector FinishSetVelocity; // 0x84(0xC)
	float FinishClampVelocity; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
	struct UCharacterMovementComponent* MovementComponent; // 0x98(0x8)
	uint8_t Pad_0xA0[0x10]; // 0xA0(0x10)
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce
// Size: 0xE0 (Inherited: 0xB0)
struct UAbilityTask_ApplyRootMotionConstantForce : UAbilityTask_ApplyRootMotion_Base
{
	struct FScriptMulticastDelegate OnFinish; // 0xB0(0x10)
	struct FVector WorldDirection; // 0xC0(0xC)
	float Strength; // 0xCC(0x4)
	float Duration; // 0xD0(0x4)
	bool bIsAdditive; // 0xD4(0x1)
	uint8_t Pad_0xD5[0x3]; // 0xD5(0x3)
	struct UCurveFloat* StrengthOverTime; // 0xD8(0x8)


	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce.ApplyRootMotionConstantForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10213008c
	// Params: [ Num(11) Size(0x50) ]
	struct UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, struct UCurveFloat* StrengthOverTime, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce
// Size: 0x108 (Inherited: 0xB0)
struct UAbilityTask_ApplyRootMotionJumpForce : UAbilityTask_ApplyRootMotion_Base
{
	struct FScriptMulticastDelegate OnFinish; // 0xB0(0x10)
	struct FScriptMulticastDelegate OnLanded; // 0xC0(0x10)
	struct FRotator Rotation; // 0xD0(0xC)
	float Distance; // 0xDC(0x4)
	float Height; // 0xE0(0x4)
	float Duration; // 0xE4(0x4)
	float MinimumLandedTriggerTime; // 0xE8(0x4)
	bool bFinishOnLanded; // 0xEC(0x1)
	uint8_t Pad_0xED[0x3]; // 0xED(0x3)
	struct UCurveVector* PathOffsetCurve; // 0xF0(0x8)
	struct UCurveFloat* TimeMappingCurve; // 0xF8(0x8)
	uint8_t Pad_0x100[0x8]; // 0x100(0x8)


	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.OnLandedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10213085c
	// Params: [ Num(1) Size(0x88) ]
	void OnLandedCallback(struct FHitResult& Hit);
	// [Call #1] RVA: 0x106C8CD38
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020A5DA4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.Finish
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102130848
	// Params: [ Num(0) Size(0x0) ]
	void Finish();
	// [Call #1] RVA: 0x106C8CD38
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020A5DA4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.ApplyRootMotionJumpForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1021304f4
	// Params: [ Num(14) Size(0x58) ]
	struct UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce
// Size: 0x128 (Inherited: 0xB0)
struct UAbilityTask_ApplyRootMotionMoveToActorForce : UAbilityTask_ApplyRootMotion_Base
{
	struct FScriptMulticastDelegate OnFinished; // 0xB0(0x10)
	uint8_t Pad_0xC0[0x8]; // 0xC0(0x8)
	struct FVector StartLocation; // 0xC8(0xC)
	struct FVector TargetLocation; // 0xD4(0xC)
	struct AActor* TargetActor; // 0xE0(0x8)
	struct FVector TargetLocationOffset; // 0xE8(0xC)
	uint8_t OffsetAlignment; // 0xF4(0x1)
	uint8_t Pad_0xF5[0x3]; // 0xF5(0x3)
	float Duration; // 0xF8(0x4)
	bool bDisableDestinationReachedInterrupt; // 0xFC(0x1)
	bool bSetNewMovementMode; // 0xFD(0x1)
	enum class EMovementMode NewMovementMode; // 0xFE(0x1)
	bool bRestrictSpeedToExpected; // 0xFF(0x1)
	struct UCurveVector* PathOffsetCurve; // 0x100(0x8)
	struct UCurveFloat* TimeMappingCurve; // 0x108(0x8)
	struct UCurveFloat* TargetLerpSpeedHorizontalCurve; // 0x110(0x8)
	struct UCurveFloat* TargetLerpSpeedVerticalCurve; // 0x118(0x8)
	uint8_t Pad_0x120[0x8]; // 0x120(0x8)


	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnTargetActorSwapped
	// Flags: [Final|Native|Public]
	// Offset: 0x1021315d0
	// Params: [ Num(2) Size(0x10) ]
	void OnTargetActorSwapped(struct AActor* OriginalTarget, struct AActor* NewTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020A68F0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnRep_TargetLocation
	// Flags: [Final|Native|Protected]
	// Offset: 0x1021315bc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_TargetLocation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020A68F0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToTargetDataActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102131048
	// Params: [ Num(20) Size(0x98) ]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int TargetDataIndex, int TargetActorIndex, struct FVector TargetLocationOffset, uint8_t OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102130be4
	// Params: [ Num(18) Size(0x78) ]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* TargetActor, struct FVector TargetLocationOffset, uint8_t OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce
// Size: 0x100 (Inherited: 0xB0)
struct UAbilityTask_ApplyRootMotionMoveToForce : UAbilityTask_ApplyRootMotion_Base
{
	struct FScriptMulticastDelegate OnTimedOut; // 0xB0(0x10)
	struct FScriptMulticastDelegate OnTimedOutAndDestinationReached; // 0xC0(0x10)
	struct FVector StartLocation; // 0xD0(0xC)
	struct FVector TargetLocation; // 0xDC(0xC)
	float Duration; // 0xE8(0x4)
	bool bSetNewMovementMode; // 0xEC(0x1)
	enum class EMovementMode NewMovementMode; // 0xED(0x1)
	bool bRestrictSpeedToExpected; // 0xEE(0x1)
	uint8_t Pad_0xEF[0x1]; // 0xEF(0x1)
	struct UCurveVector* PathOffsetCurve; // 0xF0(0x8)
	uint8_t Pad_0xF8[0x8]; // 0xF8(0x8)


	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce.ApplyRootMotionMoveToForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102131968
	// Params: [ Num(12) Size(0x50) ]
	struct UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce
// Size: 0x108 (Inherited: 0xB0)
struct UAbilityTask_ApplyRootMotionRadialForce : UAbilityTask_ApplyRootMotion_Base
{
	struct FScriptMulticastDelegate OnFinish; // 0xB0(0x10)
	struct FVector Location; // 0xC0(0xC)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct AActor* LocationActor; // 0xD0(0x8)
	float Strength; // 0xD8(0x4)
	float Duration; // 0xDC(0x4)
	float Radius; // 0xE0(0x4)
	bool bIsPush; // 0xE4(0x1)
	bool bIsAdditive; // 0xE5(0x1)
	bool bNoZForce; // 0xE6(0x1)
	uint8_t Pad_0xE7[0x1]; // 0xE7(0x1)
	struct UCurveFloat* StrengthDistanceFalloff; // 0xE8(0x8)
	struct UCurveFloat* StrengthOverTime; // 0xF0(0x8)
	bool bUseFixedWorldDirection; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x3]; // 0xF9(0x3)
	struct FRotator FixedWorldDirection; // 0xFC(0xC)


	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce.ApplyRootMotionRadialForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102131e2c
	// Params: [ Num(18) Size(0x78) ]
	struct UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, struct AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, struct UCurveFloat* StrengthDistanceFalloff, struct UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, uint8_t VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_MoveToLocation
// Size: 0xC0 (Inherited: 0x78)
struct UAbilityTask_MoveToLocation : UAbilityTask
{
	struct FScriptMulticastDelegate OnTargetLocationReached; // 0x78(0x10)
	uint8_t Pad_0x88[0x4]; // 0x88(0x4)
	struct FVector StartLocation; // 0x8C(0xC)
	struct FVector TargetLocation; // 0x98(0xC)
	float DurationOfMovement; // 0xA4(0x4)
	uint8_t Pad_0xA8[0x8]; // 0xA8(0x8)
	struct UCurveFloat* LerpCurve; // 0xB0(0x8)
	struct UCurveVector* LerpCurveVector; // 0xB8(0x8)


	// Object: Function GameplayAbilities.AbilityTask_MoveToLocation.MoveToLocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1021324b0
	// Params: [ Num(7) Size(0x38) ]
	struct UAbilityTask_MoveToLocation* MoveToLocation(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, float Duration, struct UCurveFloat* OptionalInterpolationCurve, struct UCurveVector* OptionalVectorInterpolationCurve);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020A9B10
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_NetworkSyncPoint
// Size: 0x90 (Inherited: 0x78)
struct UAbilityTask_NetworkSyncPoint : UAbilityTask
{
	struct FScriptMulticastDelegate OnSync; // 0x78(0x10)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)


	// Object: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.WaitNetSync
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213289c
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, uint8_t SyncType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AA49C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.OnSignalCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x102132888
	// Params: [ Num(0) Size(0x0) ]
	void OnSignalCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AA49C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_PlayMontageAndWait
// Size: 0x100 (Inherited: 0x78)
struct UAbilityTask_PlayMontageAndWait : UAbilityTask
{
	struct FScriptMulticastDelegate OnCompleted; // 0x78(0x10)
	struct FScriptMulticastDelegate OnBlendOut; // 0x88(0x10)
	struct FScriptMulticastDelegate OnInterrupted; // 0x98(0x10)
	struct FScriptMulticastDelegate OnCancelled; // 0xA8(0x10)
	uint8_t Pad_0xB8[0x48]; // 0xB8(0x48)


	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageInterrupted
	// Flags: [Final|Native|Public]
	// Offset: 0x102132eb4
	// Params: [ Num(0) Size(0x0) ]
	void OnMontageInterrupted();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageEnded
	// Flags: [Final|Native|Public]
	// Offset: 0x102132df4
	// Params: [ Num(2) Size(0x9) ]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AA9FC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageBlendingOut
	// Flags: [Final|Native|Public]
	// Offset: 0x102132d34
	// Params: [ Num(2) Size(0x9) ]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AA7B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1020AA9FC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.CreatePlayMontageAndWaitProxy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102132b44
	// Params: [ Num(8) Size(0x38) ]
	struct UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020AAA34
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_Repeat
// Size: 0xB0 (Inherited: 0x78)
struct UAbilityTask_Repeat : UAbilityTask
{
	struct FScriptMulticastDelegate OnPerformAction; // 0x78(0x10)
	struct FScriptMulticastDelegate OnFinished; // 0x88(0x10)
	uint8_t Pad_0x98[0x18]; // 0x98(0x18)


	// Object: Function GameplayAbilities.AbilityTask_Repeat.RepeatAction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102133164
	// Params: [ Num(4) Size(0x18) ]
	struct UAbilityTask_Repeat* RepeatAction(struct UGameplayAbility* OwningAbility, float TimeBetweenActions, int TotalActionCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020AB554
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_SpawnActor
// Size: 0xB8 (Inherited: 0x78)
struct UAbilityTask_SpawnActor : UAbilityTask
{
	struct FScriptMulticastDelegate Success; // 0x78(0x10)
	struct FScriptMulticastDelegate DidNotSpawn; // 0x88(0x10)
	uint8_t Pad_0x98[0x20]; // 0x98(0x20)


	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.SpawnActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021336dc
	// Params: [ Num(4) Size(0x38) ]
	struct UAbilityTask_SpawnActor* SpawnActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C68C8
	// [Call #8] RVA: 0x1020AB814
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1021335a0
	// Params: [ Num(3) Size(0x30) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C68C8
	// [Call #8] RVA: 0x1020ABA60
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1020C68C8
	// [Call #21] RVA: 0x1020AB814
	// [Call #22] RVA: 0x1020C5658
	// [Call #23] RVA: 0x1020C5658

	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102133404
	// Params: [ Num(5) Size(0x39) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class, struct AActor*& SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C68C8
	// [Call #10] RVA: 0x1020AB8A8
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
};

// Object: Class GameplayAbilities.AbilityTask_StartAbilityState
// Size: 0xB0 (Inherited: 0x78)
struct UAbilityTask_StartAbilityState : UAbilityTask
{
	struct FScriptMulticastDelegate OnStateEnded; // 0x78(0x10)
	struct FScriptMulticastDelegate OnStateInterrupted; // 0x88(0x10)
	uint8_t Pad_0x98[0x18]; // 0x98(0x18)


	// Object: Function GameplayAbilities.AbilityTask_StartAbilityState.StartAbilityState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102133a58
	// Params: [ Num(4) Size(0x20) ]
	struct UAbilityTask_StartAbilityState* StartAbilityState(struct UGameplayAbility* OwningAbility, struct FName StateName, bool bEndCurrentState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020ABC08
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_VisualizeTargeting
// Size: 0xA0 (Inherited: 0x78)
struct UAbilityTask_VisualizeTargeting : UAbilityTask
{
	struct FScriptMulticastDelegate TimeElapsed; // 0x78(0x10)
	uint8_t Pad_0x88[0x18]; // 0x88(0x18)


	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargetingUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102133ff8
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetActor, struct FName TaskInstanceName, float Duration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020AC15C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargeting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102133ecc
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargeting(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct FName TaskInstanceName, float Duration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020ABF98
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1020AC15C

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102133e18
	// Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AC514
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020ABF98
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102133d08
	// Params: [ Num(4) Size(0x19) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020AC39C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020AC514
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_WaitAbilityActivate
// Size: 0x130 (Inherited: 0x78)
struct UAbilityTask_WaitAbilityActivate : UAbilityTask
{
	struct FScriptMulticastDelegate OnActivate; // 0x78(0x10)
	uint8_t Pad_0x88[0xA8]; // 0x88(0xA8)


	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213473c
	// Params: [ Num(5) Size(0x58) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C8D44
	// [Call #10] RVA: 0x1020AC77C
	// [Call #11] RVA: 0x1020C64D4
	// [Call #12] RVA: 0x1020C64D4
	// [Call #13] RVA: 0x1020C64D4
	// [Call #14] RVA: 0x1020C64D4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021345a4
	// Params: [ Num(5) Size(0x60) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E41A18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E43F54
	// [Call #11] RVA: 0x1020AC800
	// [Call #12] RVA: 0x1020C4EB4
	// [Call #13] RVA: 0x1020C4EB4
	// [Call #14] RVA: 0x1020C4EB4
	// [Call #15] RVA: 0x1020C4EB4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102134424
	// Params: [ Num(6) Size(0x28) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020AC6DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105E41A18
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.OnAbilityActivate
	// Flags: [Final|Native|Public]
	// Offset: 0x1021343a8
	// Params: [ Num(1) Size(0x8) ]
	void OnAbilityActivate(struct UGameplayAbility* ActivatedAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AC8F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020AC6DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E41A18
};

// Object: Class GameplayAbilities.AbilityTask_WaitAbilityCommit
// Size: 0xF0 (Inherited: 0x78)
struct UAbilityTask_WaitAbilityCommit : UAbilityTask
{
	struct FScriptMulticastDelegate OnCommit; // 0x78(0x10)
	uint8_t Pad_0x88[0x68]; // 0x88(0x68)


	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102134d48
	// Params: [ Num(4) Size(0x60) ]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E41A18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E43F54
	// [Call #9] RVA: 0x1020ACB80
	// [Call #10] RVA: 0x1020C4EB4
	// [Call #11] RVA: 0x1020C4EB4
	// [Call #12] RVA: 0x1020C4EB4
	// [Call #13] RVA: 0x1020C4EB4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102134c14
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020ACAE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E41A18
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E43F54
	// [Call #18] RVA: 0x1020ACB80
	// [Call #19] RVA: 0x1020C4EB4
	// [Call #20] RVA: 0x1020C4EB4

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.OnAbilityCommit
	// Flags: [Final|Native|Public]
	// Offset: 0x102134b98
	// Params: [ Num(1) Size(0x8) ]
	void OnAbilityCommit(struct UGameplayAbility* ActivatedAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020ACC70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020ACAE8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E41A18
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChange
// Size: 0xD0 (Inherited: 0x78)
struct UAbilityTask_WaitAttributeChange : UAbilityTask
{
	struct FScriptMulticastDelegate OnChange; // 0x78(0x10)
	uint8_t Pad_0x88[0x48]; // 0x88(0x48)


	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChangeWithComparison
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102135338
	// Params: [ Num(8) Size(0x50) ]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, enum class EWaitAttributeChangeComparison InComparisonType, float InComparisonValue, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C64FC
	// [Call #16] RVA: 0x1020ACED8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213516c
	// Params: [ Num(6) Size(0x48) ]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChange(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C64FC
	// [Call #12] RVA: 0x1020ACDEC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold
// Size: 0x100 (Inherited: 0x78)
struct UAbilityTask_WaitAttributeChangeRatioThreshold : UAbilityTask
{
	struct FScriptMulticastDelegate OnChange; // 0x78(0x10)
	uint8_t Pad_0x88[0x78]; // 0x88(0x78)


	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold.WaitForAttributeChangeRatioThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021357a0
	// Params: [ Num(7) Size(0x60) ]
	struct UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C64FC
	// [Call #14] RVA: 0x1020C64FC
	// [Call #15] RVA: 0x1020AD2F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold
// Size: 0xC8 (Inherited: 0x78)
struct UAbilityTask_WaitAttributeChangeThreshold : UAbilityTask
{
	struct FScriptMulticastDelegate OnChange; // 0x78(0x10)
	uint8_t Pad_0x88[0x40]; // 0x88(0x40)


	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold.WaitForAttributeChangeThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102136e78
	// Params: [ Num(6) Size(0x40) ]
	struct UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C64FC
	// [Call #12] RVA: 0x1020AD934
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitCancel
// Size: 0x90 (Inherited: 0x78)
struct UAbilityTask_WaitCancel : UAbilityTask
{
	struct FScriptMulticastDelegate OnCancel; // 0x78(0x10)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)


	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.WaitCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102137278
	// Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitCancel* WaitCancel(struct UGameplayAbility* OwningAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020ADE84
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x1021376AC

	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x102137264
	// Params: [ Num(0) Size(0x0) ]
	void OnLocalCancelCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020ADE84
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x102137250
	// Params: [ Num(0) Size(0x0) ]
	void OnCancelCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020ADE84
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_WaitConfirm
// Size: 0x98 (Inherited: 0x78)
struct UAbilityTask_WaitConfirm : UAbilityTask
{
	struct FScriptMulticastDelegate OnConfirm; // 0x78(0x10)
	uint8_t Pad_0x88[0x10]; // 0x88(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitConfirm.WaitConfirm
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102137560
	// Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitConfirm* WaitConfirm(struct UGameplayAbility* OwningAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE1A0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x102137A34

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirm.OnConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1021374e4
	// Params: [ Num(1) Size(0x8) ]
	void OnConfirmCallback(struct UGameplayAbility* InAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE170
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020AE1A0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitConfirmCancel
// Size: 0xA0 (Inherited: 0x78)
struct UAbilityTask_WaitConfirmCancel : UAbilityTask
{
	struct FScriptMulticastDelegate OnConfirm; // 0x78(0x10)
	struct FScriptMulticastDelegate OnCancel; // 0x88(0x10)
	uint8_t Pad_0x98[0x8]; // 0x98(0x8)


	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.WaitConfirmCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213781c
	// Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(struct UGameplayAbility* OwningAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE654
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x102137808
	// Params: [ Num(0) Size(0x0) ]
	void OnLocalConfirmCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE654
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1021377f4
	// Params: [ Num(0) Size(0x0) ]
	void OnLocalCancelCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE654
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1021377e0
	// Params: [ Num(0) Size(0x0) ]
	void OnConfirmCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE654
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1021377cc
	// Params: [ Num(0) Size(0x0) ]
	void OnCancelCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020AE654
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitDelay
// Size: 0x90 (Inherited: 0x78)
struct UAbilityTask_WaitDelay : UAbilityTask
{
	struct FScriptMulticastDelegate OnFinish; // 0x78(0x10)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)


	// Object: Function GameplayAbilities.AbilityTask_WaitDelay.WaitDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102137b54
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AE9E4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x102137F38
	// [Call #10] RVA: 0x10516D168
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied
// Size: 0x1B0 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayEffectApplied : UAbilityTask
{
	uint8_t Pad_0x78[0x128]; // 0x78(0x128)
	struct UAbilitySystemComponent* ExternalOwner; // 0x1A0(0x8)
	uint8_t Pad_0x1A8[0x8]; // 0x1A8(0x8)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied.OnApplyGameplayEffectCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102137d74
	// Params: [ Num(3) Size(0x2A8) ]
	void OnApplyGameplayEffectCallback(struct UAbilitySystemComponent* Target, struct FGameplayEffectSpec& SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020EE05C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020AECF4
	// [Call #9] RVA: 0x1020C887C
	// [Call #10] RVA: 0x1020C887C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self
// Size: 0x1D0 (Inherited: 0x1B0)
struct UAbilityTask_WaitGameplayEffectApplied_Self : UAbilityTask_WaitGameplayEffectApplied
{
	struct FScriptMulticastDelegate OnApplied; // 0x1B0(0x10)
	uint8_t Pad_0x1C0[0x10]; // 0x1C0(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213834c
	// Params: [ Num(8) Size(0xC8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E41A18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E41A18
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E43F54
	// [Call #18] RVA: 0x105E43F54
	// [Call #19] RVA: 0x1020AF210
	// [Call #20] RVA: 0x1020C4EB4
	// [Call #21] RVA: 0x1020C4EB4
	// [Call #22] RVA: 0x1020C747C
	// [Call #23] RVA: 0x1020C4EB4
	// [Call #24] RVA: 0x1020C4EB4

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102138058
	// Params: [ Num(8) Size(0xB8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C8D44
	// [Call #16] RVA: 0x1020C8D44
	// [Call #17] RVA: 0x1020AF0EC
	// [Call #18] RVA: 0x1020C64D4
	// [Call #19] RVA: 0x1020C64D4
	// [Call #20] RVA: 0x1020C747C
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target
// Size: 0x1D0 (Inherited: 0x1B0)
struct UAbilityTask_WaitGameplayEffectApplied_Target : UAbilityTask_WaitGameplayEffectApplied
{
	struct FScriptMulticastDelegate OnApplied; // 0x1B0(0x10)
	uint8_t Pad_0x1C0[0x10]; // 0x1C0(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102138b50
	// Params: [ Num(8) Size(0xC8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E41A18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E41A18
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E43F54
	// [Call #18] RVA: 0x105E43F54
	// [Call #19] RVA: 0x1020AF690
	// [Call #20] RVA: 0x1020C4EB4
	// [Call #21] RVA: 0x1020C4EB4
	// [Call #22] RVA: 0x1020C747C
	// [Call #23] RVA: 0x1020C4EB4
	// [Call #24] RVA: 0x1020C4EB4

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213885c
	// Params: [ Num(8) Size(0xB8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffects);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C8D44
	// [Call #16] RVA: 0x1020C8D44
	// [Call #17] RVA: 0x1020AF5A4
	// [Call #18] RVA: 0x1020C64D4
	// [Call #19] RVA: 0x1020C64D4
	// [Call #20] RVA: 0x1020C747C
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity
// Size: 0x120 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayEffectBlockedImmunity : UAbilityTask
{
	struct FScriptMulticastDelegate bLocked; // 0x78(0x10)
	uint8_t Pad_0x88[0x88]; // 0x88(0x88)
	struct UAbilitySystemComponent* ExternalOwner; // 0x110(0x8)
	uint8_t Pad_0x118[0x8]; // 0x118(0x8)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity.WaitGameplayEffectBlockedByImmunity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102139060
	// Params: [ Num(6) Size(0xA0) ]
	struct UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C8D44
	// [Call #12] RVA: 0x1020C8D44
	// [Call #13] RVA: 0x1020AFA34
	// [Call #14] RVA: 0x1020C64D4
	// [Call #15] RVA: 0x1020C64D4
	// [Call #16] RVA: 0x1020C64D4
	// [Call #17] RVA: 0x1020C64D4
	// [Call #18] RVA: 0x1020C64D4
	// [Call #19] RVA: 0x1020C64D4
	// [Call #20] RVA: 0x1020C64D4
	// [Call #21] RVA: 0x1020C64D4
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved
// Size: 0xB8 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayEffectRemoved : UAbilityTask
{
	struct FScriptMulticastDelegate OnRemoved; // 0x78(0x10)
	struct FScriptMulticastDelegate InvalidHandle; // 0x88(0x10)
	uint8_t Pad_0x98[0x20]; // 0x98(0x20)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.WaitForGameplayEffectRemoved
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021394ec
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020AFEEC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.OnGameplayEffectRemoved
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10213942c
	// Params: [ Num(1) Size(0x20) ]
	void OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo& InGameplayEffectRemovalInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B0154
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020AFEEC
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange
// Size: 0xB0 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayEffectStackChange : UAbilityTask
{
	struct FScriptMulticastDelegate OnChange; // 0x78(0x10)
	struct FScriptMulticastDelegate InvalidHandle; // 0x88(0x10)
	uint8_t Pad_0x98[0x18]; // 0x98(0x18)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.WaitForGameplayEffectStackChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102139890
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.OnGameplayEffectStackChange
	// Flags: [Final|Native|Public]
	// Offset: 0x102139798
	// Params: [ Num(3) Size(0x10) ]
	void OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int NewCount, int OldCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B0408
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEvent
// Size: 0xA8 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayEvent : UAbilityTask
{
	struct FScriptMulticastDelegate EventReceived; // 0x78(0x10)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0x90(0x8)
	uint8_t Pad_0x98[0x10]; // 0x98(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEvent.WaitGameplayEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102139b3c
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B04E8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTag
// Size: 0xA0 (Inherited: 0x78)
struct UAbilityTask_WaitGameplayTag : UAbilityTask
{
	uint8_t Pad_0x78[0x10]; // 0x78(0x10)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0x88(0x8)
	uint8_t Pad_0x90[0x10]; // 0x90(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTag.GameplayTagCallback
	// Flags: [Native|Public]
	// Offset: 0x10213a3bc
	// Params: [ Num(2) Size(0xC) ]
	void GameplayTagCallback(struct FGameplayTag Tag, int NewCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10213A790
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTagAdded
// Size: 0xB0 (Inherited: 0xA0)
struct UAbilityTask_WaitGameplayTagAdded : UAbilityTask_WaitGameplayTag
{
	struct FScriptMulticastDelegate Added; // 0xA0(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTagAdded.WaitGameplayTagAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102139e28
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B08E4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTagRemoved
// Size: 0xB0 (Inherited: 0xA0)
struct UAbilityTask_WaitGameplayTagRemoved : UAbilityTask_WaitGameplayTag
{
	struct FScriptMulticastDelegate Removed; // 0xA0(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTagRemoved.WaitGameplayTagRemove
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213a118
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B0B2C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitInputPress
// Size: 0x98 (Inherited: 0x78)
struct UAbilityTask_WaitInputPress : UAbilityTask
{
	struct FScriptMulticastDelegate OnPress; // 0x78(0x10)
	uint8_t Pad_0x88[0x10]; // 0x88(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitInputPress.WaitInputPress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213a5f4
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitInputPress* WaitInputPress(struct UGameplayAbility* OwningAbility, bool bTestAlreadyPressed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B0FB0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_WaitInputPress.OnPressCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10213a5e0
	// Params: [ Num(0) Size(0x0) ]
	void OnPressCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B0FB0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_WaitInputRelease
// Size: 0x98 (Inherited: 0x78)
struct UAbilityTask_WaitInputRelease : UAbilityTask
{
	struct FScriptMulticastDelegate OnRelease; // 0x78(0x10)
	uint8_t Pad_0x88[0x10]; // 0x88(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitInputRelease.WaitInputRelease
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213a8c4
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitInputRelease* WaitInputRelease(struct UGameplayAbility* OwningAbility, bool bTestAlreadyReleased);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B1400
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GameplayAbilities.AbilityTask_WaitInputRelease.OnReleaseCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10213a8b0
	// Params: [ Num(0) Size(0x0) ]
	void OnReleaseCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B1400
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.AbilityTask_WaitMovementModeChange
// Size: 0x98 (Inherited: 0x78)
struct UAbilityTask_WaitMovementModeChange : UAbilityTask
{
	struct FScriptMulticastDelegate OnChange; // 0x78(0x10)
	uint8_t Pad_0x88[0x10]; // 0x88(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.OnMovementModeChange
	// Flags: [Final|Native|Public]
	// Offset: 0x10213ac38
	// Params: [ Num(3) Size(0xA) ]
	void OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, uint8_t PreviousCustomMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B17D8
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.CreateWaitMovementModeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213ab80
	// Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(struct UGameplayAbility* OwningAbility, enum class EMovementMode NewMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B1684
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B17D8
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class GameplayAbilities.AbilityTask_WaitOverlap
// Size: 0x88 (Inherited: 0x78)
struct UAbilityTask_WaitOverlap : UAbilityTask
{
	struct FScriptMulticastDelegate OnOverlap; // 0x78(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitOverlap.WaitForOverlap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213b0a4
	// Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitOverlap* WaitForOverlap(struct UGameplayAbility* OwningAbility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B1AF8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10213BC10

	// Object: Function GameplayAbilities.AbilityTask_WaitOverlap.OnHitCallback
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10213af1c
	// Params: [ Num(5) Size(0xB0) ]
	void OnHitCallback(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B1974
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B1AF8
	// [Call #16] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.AbilityTask_WaitTargetData
// Size: 0xB8 (Inherited: 0x78)
struct UAbilityTask_WaitTargetData : UAbilityTask
{
	struct FScriptMulticastDelegate ValidData; // 0x78(0x10)
	struct FScriptMulticastDelegate Cancelled; // 0x88(0x10)
	uint8_t Pad_0x98[0x8]; // 0x98(0x8)
	struct AGameplayAbilityTargetActor* TargetActor; // 0xA0(0x8)
	uint8_t Pad_0xA8[0x10]; // 0xA8(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetDataUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213b864
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B1E30
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10213b72c
	// Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitTargetData* WaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* Class);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B1DA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCancelledCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10213b718
	// Params: [ Num(0) Size(0x0) ]
	void OnTargetDataReplicatedCancelledCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B1DA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10213b624
	// Params: [ Num(2) Size(0x28) ]
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle& Data, struct FGameplayTag ActivationTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B2844
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020B1DA4

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReadyCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10213b57c
	// Params: [ Num(1) Size(0x20) ]
	void OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B2490
	// [Call #4] RVA: 0x1020C5658
	// [Call #5] RVA: 0x1020C5658
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020B2844
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataCancelledCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10213b4d4
	// Params: [ Num(1) Size(0x20) ]
	void OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020B2620
	// [Call #4] RVA: 0x1020C5658
	// [Call #5] RVA: 0x1020C5658
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020B2490
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020B2844
	// [Call #18] RVA: 0x1020C5658
	// [Call #19] RVA: 0x1020C5658
	// [Call #20] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10213b420
	// Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020B238C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020B2620
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020B2490
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10213b310
	// Params: [ Num(4) Size(0x19) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B22B4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020B238C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020B2620
	// [Call #16] RVA: 0x1020C5658
};

// Object: Class GameplayAbilities.AbilityTask_WaitVelocityChange
// Size: 0xA0 (Inherited: 0x78)
struct UAbilityTask_WaitVelocityChange : UAbilityTask
{
	struct FScriptMulticastDelegate OnVelocityChage; // 0x78(0x10)
	struct UMovementComponent* CachedMovementComponent; // 0x88(0x8)
	uint8_t Pad_0x90[0x10]; // 0x90(0x10)


	// Object: Function GameplayAbilities.AbilityTask_WaitVelocityChange.CreateWaitVelocityChange
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10213bd30
	// Params: [ Num(4) Size(0x20) ]
	struct UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(struct UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020B2E60
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x102136E10
};

// Object: Class GameplayAbilities.GameplayAbility
// Size: 0x440 (Inherited: 0x28)
struct UGameplayAbility : UObject
{
	uint8_t Pad_0x28[0x68]; // 0x28(0x68)
	struct FGameplayTagContainer AbilityTags; // 0x90(0x20)
	uint8_t Pad_0xB0[0x18]; // 0xB0(0x18)
	bool bReplicateInputDirectly; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x28]; // 0xC9(0x28)
	enum class EGameplayAbilityReplicationPolicy ReplicationPolicy; // 0xF1(0x1)
	enum class EGameplayAbilityInstancingPolicy InstancingPolicy; // 0xF2(0x1)
	bool bServerRespectsRemoteAbilityCancellation; // 0xF3(0x1)
	bool bRetriggerInstancedAbility; // 0xF4(0x1)
	uint8_t Pad_0xF5[0x3]; // 0xF5(0x3)
	struct FGameplayAbilityActivationInfo CurrentActivationInfo; // 0xF8(0x20)
	struct FGameplayEventData CurrentEventData; // 0x118(0xA8)
	enum class EGameplayAbilityNetExecutionPolicy NetExecutionPolicy; // 0x1C0(0x1)
	uint8_t Pad_0x1C1[0x7]; // 0x1C1(0x7)
	struct UGameplayEffect* CostGameplayEffectClass; // 0x1C8(0x8)
	struct TArray<struct FAbilityTriggerData> AbilityTriggers; // 0x1D0(0x10)
	struct UGameplayEffect* CooldownGameplayEffectClass; // 0x1E0(0x8)
	struct FGameplayTagQuery CancelAbilitiesMatchingTagQuery; // 0x1E8(0x48)
	struct FGameplayTagQuery ConstTagQuery; // 0x230(0x48)
	struct FGameplayTagContainer CancelAbilitiesWithTag; // 0x278(0x20)
	struct FGameplayTagContainer BlockAbilitiesWithTag; // 0x298(0x20)
	struct FGameplayTagContainer ActivationOwnedTags; // 0x2B8(0x20)
	struct FGameplayTagContainer ActivationRequiredTags; // 0x2D8(0x20)
	struct FGameplayTagContainer ActivationBlockedTags; // 0x2F8(0x20)
	struct FGameplayTagContainer SourceRequiredTags; // 0x318(0x20)
	struct FGameplayTagContainer SourceBlockedTags; // 0x338(0x20)
	struct FGameplayTagContainer TargetRequiredTags; // 0x358(0x20)
	struct FGameplayTagContainer TargetBlockedTags; // 0x378(0x20)
	struct TArray<struct UGameplayTask*> ActiveTasks; // 0x398(0x10)
	uint8_t Pad_0x3A8[0x70]; // 0x3A8(0x70)
	struct UAnimMontage* CurrentMontage; // 0x418(0x8)
	bool bIsActive; // 0x420(0x1)
	bool bIsCancelable; // 0x421(0x1)
	uint8_t Pad_0x422[0x16]; // 0x422(0x16)
	bool bIsBlockingOtherAbilities; // 0x438(0x1)
	uint8_t Pad_0x439[0x7]; // 0x439(0x7)


	// Object: Function GameplayAbilities.GameplayAbility.SetShouldBlockOtherAbilities
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213e084
	// Params: [ Num(1) Size(0x1) ]
	void SetShouldBlockOtherAbilities(bool bShouldBlockAbilities);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayAbilities.GameplayAbility.SetCanBeCanceled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213dff8
	// Params: [ Num(1) Size(0x1) ]
	void SetCanBeCanceled(bool bCanBeCanceled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GameplayAbilities.GameplayAbility.SendGameplayEvent
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10213dec4
	// Params: [ Num(2) Size(0xB0) ]
	void SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C506C
	// [Call #6] RVA: 0x1020C4EF4
	// [Call #7] RVA: 0x1020C4EF4
	// [Call #8] RVA: 0x1020C4EF4
	// [Call #9] RVA: 0x1020C4EF4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.RemoveGrantedByEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10213deb0
	// Params: [ Num(0) Size(0x0) ]
	void RemoveGrantedByEffect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C506C
	// [Call #6] RVA: 0x1020C4EF4
	// [Call #7] RVA: 0x1020C4EF4
	// [Call #8] RVA: 0x1020C4EF4
	// [Call #9] RVA: 0x1020C4EF4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.MontageStop
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213de34
	// Params: [ Num(1) Size(0x4) ]
	void MontageStop(float OverrideBlendOutTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209D8D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C506C
	// [Call #9] RVA: 0x1020C4EF4
	// [Call #10] RVA: 0x1020C4EF4
	// [Call #11] RVA: 0x1020C4EF4
	// [Call #12] RVA: 0x1020C4EF4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.MontageSetNextSectionName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213dd80
	// Params: [ Num(2) Size(0x10) ]
	void MontageSetNextSectionName(struct FName FromSectionName, struct FName ToSectionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10209D7C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10209D8D0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C506C
	// [Call #14] RVA: 0x1020C4EF4
	// [Call #15] RVA: 0x1020C4EF4

	// Object: Function GameplayAbilities.GameplayAbility.MontageJumpToSection
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213dd04
	// Params: [ Num(1) Size(0x8) ]
	void MontageJumpToSection(struct FName SectionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209D6F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10209D7C0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10209D8D0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerSkeletalMeshComponent
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	// Offset: 0x10213dc58
	// Params: [ Num(2) Size(0x70) ]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(struct FName SocketName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209DA34
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10209D6F8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10209D7C0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10209D8D0

	// Object: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerActor
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	// Offset: 0x10213dbfc
	// Params: [ Num(1) Size(0x60) ]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor();
	// [Call #1] RVA: 0x10209D9AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10209DA34
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10209D6F8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10209D7C0

	// Object: Function GameplayAbilities.GameplayAbility.MakeOutgoingGameplayEffectSpec
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213db0c
	// Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(struct UGameplayEffect* GameplayEffectClass, float Level);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10209D214
	// [Call #6] RVA: 0x1020B5AC8
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10209D9AC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10209DA34
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_ShouldAbilityRespondToEvent
	// Flags: [Event|Protected|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xE9) ]
	bool K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.K2_RemoveGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10213da88
	// Params: [ Num(1) Size(0x8) ]
	void K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10209D214
	// [Call #8] RVA: 0x1020B5AC8
	// [Call #9] RVA: 0x1020C8DFC
	// [Call #10] RVA: 0x1020C8DFC
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10209D9AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10209DA34

	// Object: Function GameplayAbilities.GameplayAbility.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void K2_OnEndAbility();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCueWithParams
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x10213d958
	// Params: [ Num(2) Size(0xC0) ]
	void K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10213d82c
	// Params: [ Num(2) Size(0x20) ]
	void K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020C76E8
	// [Call #15] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayAbility.K2_EndAbility
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10213d810
	// Params: [ Num(0) Size(0x0) ]
	void K2_EndAbility();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitExecute
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void K2_CommitExecute();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213d774
	// Params: [ Num(2) Size(0x2) ]
	bool K2_CommitAbilityCost(bool BroadcastCommitEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213d694
	// Params: [ Num(3) Size(0x3) ]
	bool K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbility
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213d658
	// Params: [ Num(1) Size(0x1) ]
	bool K2_CommitAbility();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213d61c
	// Params: [ Num(1) Size(0x1) ]
	bool K2_CheckAbilityCost();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168

	// Object: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10213d5e0
	// Params: [ Num(1) Size(0x1) ]
	bool K2_CheckAbilityCooldown();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_CancelAbility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10213d5cc
	// Params: [ Num(0) Size(0x0) ]
	void K2_CancelAbility();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.K2_CanActivateAbility
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x61) ]
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayTagContainer& RelevantTags);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213d444
	// Params: [ Num(3) Size(0x48) ]
	struct TArray<struct FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C68C8
	// [Call #7] RVA: 0x1020A00A4
	// [Call #8] RVA: 0x1020FA7EC
	// [Call #9] RVA: 0x1020CA774
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C8DFC
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x1020C8DFC
	// [Call #14] RVA: 0x1020CA774
	// [Call #15] RVA: 0x1020C5658
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x1020C8DFC
	// [Call #19] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213d350
	// Params: [ Num(2) Size(0x20) ]
	struct FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle);
	// [Call #1] RVA: 0x10211990C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10209F048
	// [Call #5] RVA: 0x1020C8DFC
	// [Call #6] RVA: 0x1020C8DFC
	// [Call #7] RVA: 0x1020C8DFC
	// [Call #8] RVA: 0x1020C8DFC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10211990C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C68C8
	// [Call #16] RVA: 0x1020A00A4
	// [Call #17] RVA: 0x1020FA7EC
	// [Call #18] RVA: 0x1020CA774
	// [Call #19] RVA: 0x1020C5658
	// [Call #20] RVA: 0x1020C8DFC
	// [Call #21] RVA: 0x1020C5658
	// [Call #22] RVA: 0x1020C8DFC
	// [Call #23] RVA: 0x1020CA774
	// [Call #24] RVA: 0x1020C5658
	// [Call #25] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.GameplayAbility.K2_AddGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10213d1dc
	// Params: [ Num(3) Size(0x21) ]
	void K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10211990C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10209F048
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C8DFC
	// [Call #18] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.GameplayAbility.K2_ActivateAbilityFromEvent
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0xA8) ]
	void K2_ActivateAbilityFromEvent(struct FGameplayEventData& EventData);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.K2_ActivateAbility
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void K2_ActivateAbility();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbility.InvalidateClientPredictionKey
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x10213d1c8
	// Params: [ Num(0) Size(0x0) ]
	void InvalidateClientPredictionKey();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10211990C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10209F048
	// [Call #16] RVA: 0x1020C8DFC
	// [Call #17] RVA: 0x1020C8DFC

	// Object: Function GameplayAbilities.GameplayAbility.GetOwningComponentFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d194
	// Params: [ Num(1) Size(0x8) ]
	struct USkeletalMeshComponent* GetOwningComponentFromActorInfo();
	// [Call #1] RVA: 0x10209D1FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10211990C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.GetOwningActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d160
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwningActorFromActorInfo();
	// [Call #1] RVA: 0x10209D104
	// [Call #2] RVA: 0x10209D1FC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5180
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10211990C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.GetGrantedByEffectContext
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d0fc
	// Params: [ Num(1) Size(0x18) ]
	struct FGameplayEffectContextHandle GetGrantedByEffectContext();
	// [Call #1] RVA: 0x10209E98C
	// [Call #2] RVA: 0x10209E778
	// [Call #3] RVA: 0x1020C5180
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10209D104
	// [Call #7] RVA: 0x10209D1FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020C5180
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180
	// [Call #17] RVA: 0x1020C5180
	// [Call #18] RVA: 0x106C8459C

	// Object: Function GameplayAbilities.GameplayAbility.GetCurrentSourceObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d0c8
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetCurrentSourceObject();
	// [Call #1] RVA: 0x10209EBE0
	// [Call #2] RVA: 0x10209E98C
	// [Call #3] RVA: 0x10209E778
	// [Call #4] RVA: 0x1020C5180
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10209D104
	// [Call #8] RVA: 0x10209D1FC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.GameplayAbility.GetCurrentMontage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d094
	// Params: [ Num(1) Size(0x8) ]
	struct UAnimMontage* GetCurrentMontage();
	// [Call #1] RVA: 0x10209D9A4
	// [Call #2] RVA: 0x10209EBE0
	// [Call #3] RVA: 0x10209E98C
	// [Call #4] RVA: 0x10209E778
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10209D104
	// [Call #9] RVA: 0x10209D1FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.GetCooldownTimeRemaining
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213d060
	// Params: [ Num(1) Size(0x4) ]
	float GetCooldownTimeRemaining();
	// [Call #1] RVA: 0x1020A0388
	// [Call #2] RVA: 0x10209D9A4
	// [Call #3] RVA: 0x10209EBE0
	// [Call #4] RVA: 0x10209E98C
	// [Call #5] RVA: 0x10209E778
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5180
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10209D104
	// [Call #10] RVA: 0x10209D1FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.GetContextFromOwner
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213cf64
	// Params: [ Num(2) Size(0x38) ]
	struct FGameplayEffectContextHandle GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C68C8
	// [Call #4] RVA: 0x10209E778
	// [Call #5] RVA: 0x1020C5180
	// [Call #6] RVA: 0x1020C5658
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1020A0388
	// [Call #13] RVA: 0x10209D9A4
	// [Call #14] RVA: 0x10209EBE0
	// [Call #15] RVA: 0x10209E98C
	// [Call #16] RVA: 0x10209E778
	// [Call #17] RVA: 0x1020C5180
	// [Call #18] RVA: 0x1020C5180
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10209D104
	// [Call #21] RVA: 0x10209D1FC

	// Object: Function GameplayAbilities.GameplayAbility.GetAvatarActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213cf30
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetAvatarActorFromActorInfo();
	// [Call #1] RVA: 0x10209D1E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020C68C8
	// [Call #5] RVA: 0x10209E778
	// [Call #6] RVA: 0x1020C5180
	// [Call #7] RVA: 0x1020C5658
	// [Call #8] RVA: 0x1020C5658
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1020A0388
	// [Call #14] RVA: 0x10209D9A4
	// [Call #15] RVA: 0x10209EBE0
	// [Call #16] RVA: 0x10209E98C
	// [Call #17] RVA: 0x10209E778
	// [Call #18] RVA: 0x1020C5180
	// [Call #19] RVA: 0x1020C5180
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10209D104

	// Object: Function GameplayAbilities.GameplayAbility.GetActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213cee8
	// Params: [ Num(1) Size(0x40) ]
	struct FGameplayAbilityActorInfo GetActorInfo();
	// [Call #1] RVA: 0x10209D0E0
	// [Call #2] RVA: 0x10213C644
	// [Call #3] RVA: 0x10209D1E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C68C8
	// [Call #7] RVA: 0x10209E778
	// [Call #8] RVA: 0x1020C5180
	// [Call #9] RVA: 0x1020C5658
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5180
	// [Call #12] RVA: 0x1020C5658
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1020A0388
	// [Call #16] RVA: 0x10209D9A4
	// [Call #17] RVA: 0x10209EBE0
	// [Call #18] RVA: 0x10209E98C
	// [Call #19] RVA: 0x10209E778
	// [Call #20] RVA: 0x1020C5180

	// Object: Function GameplayAbilities.GameplayAbility.GetAbilityLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213ceb4
	// Params: [ Num(1) Size(0x4) ]
	int GetAbilityLevel();
	// [Call #1] RVA: 0x10209E5A4
	// [Call #2] RVA: 0x10209D0E0
	// [Call #3] RVA: 0x10213C644
	// [Call #4] RVA: 0x10209D1E4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C68C8
	// [Call #8] RVA: 0x10209E778
	// [Call #9] RVA: 0x1020C5180
	// [Call #10] RVA: 0x1020C5658
	// [Call #11] RVA: 0x1020C5658
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1020A0388
	// [Call #17] RVA: 0x10209D9A4
	// [Call #18] RVA: 0x10209EBE0

	// Object: Function GameplayAbilities.GameplayAbility.EndTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213ce38
	// Params: [ Num(1) Size(0x8) ]
	void EndTaskByInstanceName(struct FName InstanceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209E120
	// [Call #4] RVA: 0x10209E5A4
	// [Call #5] RVA: 0x10209D0E0
	// [Call #6] RVA: 0x10213C644
	// [Call #7] RVA: 0x10209D1E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1020C68C8
	// [Call #11] RVA: 0x10209E778
	// [Call #12] RVA: 0x1020C5180
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1020A0388

	// Object: Function GameplayAbilities.GameplayAbility.EndAbilityState
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213cdbc
	// Params: [ Num(1) Size(0x8) ]
	void EndAbilityState(struct FName OptionalStateNameToEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209E308
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10209E120
	// [Call #7] RVA: 0x10209E5A4
	// [Call #8] RVA: 0x10209D0E0
	// [Call #9] RVA: 0x10213C644
	// [Call #10] RVA: 0x10209D1E4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C68C8
	// [Call #14] RVA: 0x10209E778
	// [Call #15] RVA: 0x1020C5180
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x1020C5658

	// Object: Function GameplayAbilities.GameplayAbility.ConfirmTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213ccfc
	// Params: [ Num(2) Size(0x9) ]
	void ConfirmTaskByInstanceName(struct FName InstanceName, bool bEndTask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10209DD54
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10209E308
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10209E120
	// [Call #12] RVA: 0x10209E5A4
	// [Call #13] RVA: 0x10209D0E0
	// [Call #14] RVA: 0x10213C644
	// [Call #15] RVA: 0x10209D1E4

	// Object: Function GameplayAbilities.GameplayAbility.CancelTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213cc80
	// Params: [ Num(1) Size(0x8) ]
	void CancelTaskByInstanceName(struct FName InstanceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10209E214
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10209DD54
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10209E308
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10209E120
	// [Call #15] RVA: 0x10209E5A4

	// Object: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithGrantedTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213cb80
	// Params: [ Num(2) Size(0x24) ]
	void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int StacksToRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C5138
	// [Call #6] RVA: 0x1020A0310
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10209E214
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10209DD54

	// Object: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithAssetTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213ca80
	// Params: [ Num(2) Size(0x24) ]
	void BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int StacksToRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C5138
	// [Call #6] RVA: 0x1020A0280
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020C5138
	// [Call #17] RVA: 0x1020A0310
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x1020C4E8C
	// [Call #20] RVA: 0x1020C4E8C
	// [Call #21] RVA: 0x1020C4E8C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213c8d0
	// Params: [ Num(5) Size(0x40) ]
	struct TArray<struct FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, struct UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020C68C8
	// [Call #10] RVA: 0x10209FC4C
	// [Call #11] RVA: 0x1020FA7EC
	// [Call #12] RVA: 0x1020CA774
	// [Call #13] RVA: 0x1020C5658
	// [Call #14] RVA: 0x1020C5658
	// [Call #15] RVA: 0x1020CA774
	// [Call #16] RVA: 0x1020C5658
	// [Call #17] RVA: 0x1020C5658
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1020C5138

	// Object: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10213c7c8
	// Params: [ Num(4) Size(0x18) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(struct UGameplayEffect* GameplayEffectClass, int GameplayEffectLevel, int Stacks);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10209EE48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020C68C8
	// [Call #17] RVA: 0x10209FC4C
	// [Call #18] RVA: 0x1020FA7EC
	// [Call #19] RVA: 0x1020CA774
	// [Call #20] RVA: 0x1020C5658
};

// Object: Class GameplayAbilities.GameplayAbility_CharacterJump
// Size: 0x440 (Inherited: 0x440)
struct UGameplayAbility_CharacterJump : UGameplayAbility
{
};

// Object: Class GameplayAbilities.GameplayAbility_Montage
// Size: 0x478 (Inherited: 0x440)
struct UGameplayAbility_Montage : UGameplayAbility
{
	struct UAnimMontage* MontageToPlay; // 0x440(0x8)
	float PlayRate; // 0x448(0x4)
	uint8_t Pad_0x44C[0x4]; // 0x44C(0x4)
	struct FName SectionName; // 0x450(0x8)
	struct TArray<struct UGameplayEffect*> GameplayEffectClassesWhileAnimating; // 0x458(0x10)
	struct TArray<struct UGameplayEffect*> GameplayEffectsWhileAnimating; // 0x468(0x10)
};

// Object: Class GameplayAbilities.GameplayAbilityBlueprint
// Size: 0xD8 (Inherited: 0xD8)
struct UGameplayAbilityBlueprint : UBlueprint
{
};

// Object: Class GameplayAbilities.GameplayAbilitySet
// Size: 0x40 (Inherited: 0x30)
struct UGameplayAbilitySet : UDataAsset
{
	struct TArray<struct FGameplayAbilityBindInfo> Abilities; // 0x30(0x10)
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor
// Size: 0x5B0 (Inherited: 0x4B0)
struct AGameplayAbilityTargetActor : AActor
{
	bool ShouldProduceTargetDataOnServer; // 0x4A9(0x1)
	struct FGameplayAbilityTargetingLocationInfo StartLocation; // 0x4B0(0x60)
	uint8_t Pad_0x511[0x2F]; // 0x511(0x2F)
	struct APlayerController* MasterPC; // 0x540(0x8)
	struct UGameplayAbility* OwningAbility; // 0x548(0x8)
	bool bDestroyOnConfirmation; // 0x550(0x1)
	uint8_t Pad_0x551[0x7]; // 0x551(0x7)
	struct AActor* SourceActor; // 0x558(0x8)
	struct FWorldReticleParameters ReticleParams; // 0x560(0xC)
	uint8_t Pad_0x56C[0x4]; // 0x56C(0x4)
	struct AGameplayAbilityWorldReticle* ReticleClass; // 0x570(0x8)
	struct FGameplayTargetDataFilterHandle filter; // 0x578(0x10)
	bool bDebug; // 0x588(0x1)
	uint8_t Pad_0x589[0x17]; // 0x589(0x17)
	struct UAbilitySystemComponent* GenericDelegateBoundASC; // 0x5A0(0x8)
	uint8_t Pad_0x5A8[0x8]; // 0x5A8(0x8)


	// Object: Function GameplayAbilities.GameplayAbilityTargetActor.ConfirmTargeting
	// Flags: [Native|Public]
	// Offset: 0x102141b04
	// Params: [ Num(0) Size(0x0) ]
	void ConfirmTargeting();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190648
	// [Call #5] RVA: 0x105190648
	// [Call #6] RVA: 0x105190648

	// Object: Function GameplayAbilities.GameplayAbilityTargetActor.CancelTargeting
	// Flags: [Native|Public]
	// Offset: 0x102141ae8
	// Params: [ Num(0) Size(0x0) ]
	void CancelTargeting();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190648
	// [Call #5] RVA: 0x105190648
	// [Call #6] RVA: 0x105190648
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_Trace
// Size: 0x5D0 (Inherited: 0x5B0)
struct AGameplayAbilityTargetActor_Trace : AGameplayAbilityTargetActor
{
	float MaxRange; // 0x5A8(0x4)
	struct FCollisionProfileName TraceProfile; // 0x5B0(0x8)
	bool bTraceAffectsAimPitch; // 0x5B8(0x1)
	uint8_t Pad_0x5BD[0x13]; // 0x5BD(0x13)
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_GroundTrace
// Size: 0x5F0 (Inherited: 0x5D0)
struct AGameplayAbilityTargetActor_GroundTrace : AGameplayAbilityTargetActor_Trace
{
	float CollisionRadius; // 0x5C4(0x4)
	float CollisionHeight; // 0x5C8(0x4)
	uint8_t Pad_0x5D8[0x18]; // 0x5D8(0x18)
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_ActorPlacement
// Size: 0x600 (Inherited: 0x5F0)
struct AGameplayAbilityTargetActor_ActorPlacement : AGameplayAbilityTargetActor_GroundTrace
{
	struct UObject* PlacedActorClass; // 0x5E8(0x8)
	struct UMaterialInterface* PlacedActorMaterial; // 0x5F0(0x8)
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_Radius
// Size: 0x5B0 (Inherited: 0x5B0)
struct AGameplayAbilityTargetActor_Radius : AGameplayAbilityTargetActor
{
	float Radius; // 0x5A8(0x4)
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_SingleLineTrace
// Size: 0x5D0 (Inherited: 0x5D0)
struct AGameplayAbilityTargetActor_SingleLineTrace : AGameplayAbilityTargetActor_Trace
{
};

// Object: Class GameplayAbilities.GameplayAbilityWorldReticle
// Size: 0x4D0 (Inherited: 0x4B0)
struct AGameplayAbilityWorldReticle : AActor
{
	struct FWorldReticleParameters Parameters; // 0x4AC(0xC)
	bool bFaceOwnerFlat; // 0x4B8(0x1)
	bool bSnapToTargetedActor; // 0x4B9(0x1)
	bool bIsTargetValid; // 0x4BA(0x1)
	bool bIsTargetAnActor; // 0x4BB(0x1)
	struct APlayerController* MasterPC; // 0x4C0(0x8)
	struct AActor* TargetingActor; // 0x4C8(0x8)


	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamVector
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x14) ]
	void SetReticleMaterialParamVector(struct FName ParamName, struct FVector Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamFloat
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void SetReticleMaterialParamFloat(struct FName ParamName, float Value);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnValidTargetChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnValidTargetChanged(bool bNewValue);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnTargetingAnActor
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnTargetingAnActor(bool bNewValue);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnParametersInitialized
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnParametersInitialized();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.FaceTowardSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102143474
	// Params: [ Num(1) Size(0x1) ]
	void FaceTowardSource(bool bFaceIn2D);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020A4208
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class GameplayAbilities.GameplayAbilityWorldReticle_ActorVisualization
// Size: 0x4E8 (Inherited: 0x4D0)
struct AGameplayAbilityWorldReticle_ActorVisualization : AGameplayAbilityWorldReticle
{
	struct UCapsuleComponent* CollisionComponent; // 0x4D0(0x8)
	struct TArray<struct UActorComponent*> VisualizationComponents; // 0x4D8(0x10)
};

// Object: Class GameplayAbilities.GameplayCueInterface
// Size: 0x28 (Inherited: 0x28)
struct IGameplayCueInterface : IInterface
{

	// Object: Function GameplayAbilities.GameplayCueInterface.ForwardGameplayCueToParent
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x102143d68
	// Params: [ Num(0) Size(0x0) ]
	void ForwardGameplayCueToParent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102136E10
	// [Call #6] RVA: 0x105184F34
	// [Call #7] RVA: 0x105190648

	// Object: Function GameplayAbilities.GameplayCueInterface.BlueprintCustomHandler
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC0) ]
	void BlueprintCustomHandler(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class GameplayAbilities.GameplayCueManager
// Size: 0x2F8 (Inherited: 0x30)
struct UGameplayCueManager : UDataAsset
{
	struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // 0x30(0x58)
	struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // 0x88(0x58)
	uint8_t Pad_0xE0[0x1B8]; // 0xE0(0x1B8)
	struct TArray<struct UObject*> LoadedGameplayCueNotifyClasses; // 0x298(0x10)
	struct TArray<struct AGameplayCueNotify_Actor*> GameplayCueClassesForPreallocation; // 0x2A8(0x10)
	struct TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // 0x2B8(0x10)
	int GameplayCueSendContextCount; // 0x2C8(0x4)
	uint8_t Pad_0x2CC[0x4]; // 0x2CC(0x4)
	struct TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // 0x2D0(0x10)
	uint8_t Pad_0x2E0[0x18]; // 0x2E0(0x18)
};

// Object: Class GameplayAbilities.GameplayCueNotify_Actor
// Size: 0x518 (Inherited: 0x4B0)
struct AGameplayCueNotify_Actor : AActor
{
	bool bAutoDestroyOnRemove; // 0x4A9(0x1)
	float AutoDestroyDelay; // 0x4AC(0x4)
	bool WarnIfTimelineIsStillRunning; // 0x4B0(0x1)
	bool WarnIfLatentActionIsStillRunning; // 0x4B1(0x1)
	uint8_t Pad_0x4B7[0x1]; // 0x4B7(0x1)
	struct FGameplayTag GameplayCueTag; // 0x4B8(0x8)
	struct FGameplayTagReferenceHelper ReferenceHelper; // 0x4C0(0x10)
	struct FName GameplayCueName; // 0x4D0(0x8)
	bool bAutoAttachToOwner; // 0x4D8(0x1)
	bool IsOverride; // 0x4D9(0x1)
	bool bUniqueInstancePerInstigator; // 0x4DA(0x1)
	bool bUniqueInstancePerSourceObject; // 0x4DB(0x1)
	bool bAllowMultipleOnActiveEvents; // 0x4DC(0x1)
	bool bAllowMultipleWhileActiveEvents; // 0x4DD(0x1)
	uint8_t Pad_0x4DE[0x2]; // 0x4DE(0x2)
	int NumPreallocatedInstances; // 0x4E0(0x4)
	uint8_t Pad_0x4E4[0x34]; // 0x4E4(0x34)


	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1021448c8
	// Params: [ Num(3) Size(0xC1) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x102144790
	// Params: [ Num(3) Size(0xC1) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnOwnerDestroyed
	// Flags: [Native|Public]
	// Offset: 0x10214470c
	// Params: [ Num(1) Size(0x8) ]
	void OnOwnerDestroyed(struct AActor* DestroyedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020C76E8
	// [Call #8] RVA: 0x1020C76E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1021445d4
	// Params: [ Num(3) Size(0xC1) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10214449c
	// Params: [ Num(3) Size(0xC1) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC8) ]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.K2_EndGameplayCue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102144480
	// Params: [ Num(0) Size(0x0) ]
	void K2_EndGameplayCue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class GameplayAbilities.GameplayCueNotify_Static
// Size: 0x50 (Inherited: 0x28)
struct UGameplayCueNotify_Static : UObject
{
	struct FGameplayTag GameplayCueTag; // 0x28(0x8)
	struct FGameplayTagReferenceHelper ReferenceHelper; // 0x30(0x10)
	struct FName GameplayCueName; // 0x40(0x8)
	bool IsOverride; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)


	// Object: Function GameplayAbilities.GameplayCueNotify_Static.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x1021455d8
	// Params: [ Num(3) Size(0xC1) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x1021454a0
	// Params: [ Num(3) Size(0xC1) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102145368
	// Params: [ Num(3) Size(0xC1) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102145230
	// Params: [ Num(3) Size(0xC1) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C76E8
	// [Call #6] RVA: 0x1020C76E8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020C76E8

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC8) ]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class GameplayAbilities.GameplayCueNotify_HitImpact
// Size: 0x60 (Inherited: 0x50)
struct UGameplayCueNotify_HitImpact : UGameplayCueNotify_Static
{
	struct USoundBase* Sound; // 0x50(0x8)
	struct UParticleSystem* ParticleSystem; // 0x58(0x8)
};

// Object: Class GameplayAbilities.GameplayCueSet
// Size: 0x90 (Inherited: 0x30)
struct UGameplayCueSet : UDataAsset
{
	struct TArray<struct FGameplayCueNotifyData> GameplayCueData; // 0x30(0x10)
	uint8_t Pad_0x40[0x50]; // 0x40(0x50)
};

// Object: Class GameplayAbilities.GameplayCueTranslator
// Size: 0x28 (Inherited: 0x28)
struct UGameplayCueTranslator : UObject
{
};

// Object: Class GameplayAbilities.GameplayCueTranslator_Test
// Size: 0x28 (Inherited: 0x28)
struct UGameplayCueTranslator_Test : UGameplayCueTranslator
{
};

// Object: Class GameplayAbilities.GameplayEffect
// Size: 0x638 (Inherited: 0x28)
struct UGameplayEffect : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	uint8_t DurationPolicy; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct FGameplayEffectModifierMagnitude DurationMagnitude; // 0x38(0x1C8)
	struct FScalableFloat Period; // 0x200(0x28)
	bool bExecutePeriodicEffectOnApplication; // 0x228(0x1)
	uint8_t Pad_0x229[0x7]; // 0x229(0x7)
	struct TArray<struct FGameplayModifierInfo> Modifiers; // 0x230(0x10)
	struct TArray<struct FGameplayEffectExecutionDefinition> Executions; // 0x240(0x10)
	struct FScalableFloat ChanceToApplyToTarget; // 0x250(0x28)
	struct TArray<struct UGameplayEffectCustomApplicationRequirement*> ApplicationRequirements; // 0x278(0x10)
	struct TArray<struct UGameplayEffect*> TargetEffectClasses; // 0x288(0x10)
	struct TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x298(0x10)
	struct TArray<struct UGameplayEffect*> OverflowEffects; // 0x2A8(0x10)
	bool bDenyOverflowApplication; // 0x2B8(0x1)
	bool bClearStackOnOverflow; // 0x2B9(0x1)
	uint8_t Pad_0x2BA[0x6]; // 0x2BA(0x6)
	struct TArray<struct UGameplayEffect*> PrematureExpirationEffectClasses; // 0x2C0(0x10)
	struct TArray<struct UGameplayEffect*> RoutineExpirationEffectClasses; // 0x2D0(0x10)
	bool bRequireModifierSuccessToTriggerCues; // 0x2E0(0x1)
	bool bSuppressStackingCues; // 0x2E1(0x1)
	uint8_t Pad_0x2E2[0x6]; // 0x2E2(0x6)
	struct TArray<struct FGameplayEffectCue> GameplayCues; // 0x2E8(0x10)
	struct UGameplayEffectUIData* UIData; // 0x2F8(0x8)
	struct FInheritedTagContainer InheritableGameplayEffectTags; // 0x300(0x60)
	struct FInheritedTagContainer InheritableOwnedTagsContainer; // 0x360(0x60)
	struct FGameplayTagRequirements OngoingTagRequirements; // 0x3C0(0x40)
	struct FGameplayTagRequirements ApplicationTagRequirements; // 0x400(0x40)
	struct FInheritedTagContainer RemoveGameplayEffectsWithTags; // 0x440(0x60)
	struct FGameplayTagRequirements GrantedApplicationImmunityTags; // 0x4A0(0x40)
	struct FGameplayEffectQuery GrantedApplicationImmunityQuery; // 0x4E0(0x138)
	uint8_t Pad_0x618[0x1]; // 0x618(0x1)
	uint8_t StackingType; // 0x619(0x1)
	uint8_t Pad_0x61A[0x2]; // 0x61A(0x2)
	int StackLimitCount; // 0x61C(0x4)
	uint8_t StackDurationRefreshPolicy; // 0x620(0x1)
	uint8_t StackPeriodResetPolicy; // 0x621(0x1)
	uint8_t StackExpirationPolicy; // 0x622(0x1)
	uint8_t Pad_0x623[0x5]; // 0x623(0x5)
	struct TArray<struct FGameplayAbilitySpecDef> GrantedAbilities; // 0x628(0x10)
};

// Object: Class GameplayAbilities.GameplayEffectCalculation
// Size: 0x38 (Inherited: 0x28)
struct UGameplayEffectCalculation : UObject
{
	struct TArray<struct FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // 0x28(0x10)
};

// Object: Class GameplayAbilities.GameplayEffectCustomApplicationRequirement
// Size: 0x28 (Inherited: 0x28)
struct UGameplayEffectCustomApplicationRequirement : UObject
{

	// Object: Function GameplayAbilities.GameplayEffectCustomApplicationRequirement.CanApplyGameplayEffect
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x10214fab8
	// Params: [ Num(4) Size(0x2A9) ]
	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* ASC);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020EE05C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C887C
	// [Call #9] RVA: 0x1020C887C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
};

// Object: Class GameplayAbilities.GameplayEffectExecutionCalculation
// Size: 0x40 (Inherited: 0x38)
struct UGameplayEffectExecutionCalculation : UGameplayEffectCalculation
{
	bool bRequiresPassedInTags; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)


	// Object: Function GameplayAbilities.GameplayEffectExecutionCalculation.Execute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x1021500a0
	// Params: [ Num(2) Size(0xC0) ]
	void Execute(struct FGameplayEffectCustomExecutionParameters& ExecutionParams, struct FGameplayEffectCustomExecutionOutput& OutExecutionOutput);
	// [Call #1] RVA: 0x1020FC08C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020F29F0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102100E94
	// [Call #8] RVA: 0x1020FC36C
	// [Call #9] RVA: 0x102100E94
	// [Call #10] RVA: 0x1020FC36C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.GameplayEffectTemplate
// Size: 0x638 (Inherited: 0x638)
struct UGameplayEffectTemplate : UGameplayEffect
{
};

// Object: Class GameplayAbilities.GameplayEffectUIData
// Size: 0x28 (Inherited: 0x28)
struct UGameplayEffectUIData : UObject
{
};

// Object: Class GameplayAbilities.GameplayEffectUIData_TextOnly
// Size: 0x40 (Inherited: 0x28)
struct UGameplayEffectUIData_TextOnly : UGameplayEffectUIData
{
	struct FText Description; // 0x28(0x18)
};

// Object: Class GameplayAbilities.GameplayModMagnitudeCalculation
// Size: 0x40 (Inherited: 0x38)
struct UGameplayModMagnitudeCalculation : UGameplayEffectCalculation
{
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)


	// Object: Function GameplayAbilities.GameplayModMagnitudeCalculation.CalculateBaseMagnitude
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x102151104
	// Params: [ Num(2) Size(0x29C) ]
	float CalculateBaseMagnitude(struct FGameplayEffectSpec& Spec);
	// [Call #1] RVA: 0x1020EE05C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020C887C
	// [Call #5] RVA: 0x1020C887C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10518366C
};

// Object: Class GameplayAbilities.GameplayTagReponseTable
// Size: 0x1D0 (Inherited: 0x30)
struct UGameplayTagReponseTable : UDataAsset
{
	struct TArray<struct FGameplayTagResponseTableEntry> Entries; // 0x30(0x10)
	uint8_t Pad_0x40[0x190]; // 0x40(0x190)


	// Object: Function GameplayAbilities.GameplayTagReponseTable.TagResponseEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x1021594d4
	// Params: [ Num(4) Size(0x1C) ]
	void TagResponseEvent(struct FGameplayTag Tag, int NewCount, struct UAbilitySystemComponent* ASC, int idx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10211E1C0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10508F76C
};

// Object: Class GameplayAbilities.TickableAttributeSetInterface
// Size: 0x28 (Inherited: 0x28)
struct ITickableAttributeSetInterface : IInterface
{
};

