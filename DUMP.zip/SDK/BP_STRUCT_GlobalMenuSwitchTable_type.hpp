#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_GlobalMenuSwitchTable_type.BP_STRUCT_GlobalMenuSwitchTable_type
// Size: 0x8 (Inherited: 0x0)
struct FBP_STRUCT_GlobalMenuSwitchTable_type
{
	int ID_0_14E478C009E418DF06E7F5440259BAA4; // 0x0(0x4)
	int Open_1_4FBB1A0034F5B7D2525FA9D509BB14EE; // 0x4(0x4)
};

