#pragma once

#include <cstdint>

// Object: Class OMobileFBPL.OMobileFBPL
// Size: 0x28 (Inherited: 0x28)
struct UOMobileFBPL : UBlueprintFunctionLibrary
{

	// Object: Function OMobileFBPL.OMobileFBPL.IsRunningOnBattery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad27c
	// Params: [ Num(1) Size(0x1) ]
	bool IsRunningOnBattery();
	// [Call #1] RVA: 0x101FACBB8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.IsBatteryStateCharging
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad248
	// Params: [ Num(1) Size(0x1) ]
	bool IsBatteryStateCharging();
	// [Call #1] RVA: 0x101FACBB4
	// [Call #2] RVA: 0x101FACBB8
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.GetVolumeState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad214
	// Params: [ Num(1) Size(0x4) ]
	int GetVolumeState();
	// [Call #1] RVA: 0x101FACB34
	// [Call #2] RVA: 0x101FACBB4
	// [Call #3] RVA: 0x101FACBB8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad1b0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceName();
	// [Call #1] RVA: 0x101FACB38
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x101FACB34
	// [Call #7] RVA: 0x101FACBB4
	// [Call #8] RVA: 0x101FACBB8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.GetBatteryTemperature
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad17c
	// Params: [ Num(1) Size(0x4) ]
	float GetBatteryTemperature();
	// [Call #1] RVA: 0x101FACBBC
	// [Call #2] RVA: 0x101FACB38
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101FACB34
	// [Call #8] RVA: 0x101FACBB4
	// [Call #9] RVA: 0x101FACBB8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.GetBatteryLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad148
	// Params: [ Num(1) Size(0x4) ]
	int GetBatteryLevel();
	// [Call #1] RVA: 0x101FACBB0
	// [Call #2] RVA: 0x101FACBBC
	// [Call #3] RVA: 0x101FACB38
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101FACB34
	// [Call #9] RVA: 0x101FACBB4
	// [Call #10] RVA: 0x101FACBB8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function OMobileFBPL.OMobileFBPL.AreHeadphonesPluggedIn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fad114
	// Params: [ Num(1) Size(0x1) ]
	bool AreHeadphonesPluggedIn();
	// [Call #1] RVA: 0x101FACBC4
	// [Call #2] RVA: 0x101FACBB0
	// [Call #3] RVA: 0x101FACBBC
	// [Call #4] RVA: 0x101FACB38
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FACB34
	// [Call #10] RVA: 0x101FACBB4
	// [Call #11] RVA: 0x101FACBB8
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

