#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_EffectItemBPTable_type.BP_STRUCT_EffectItemBPTable_type
// Size: 0x38 (Inherited: 0x0)
struct FBP_STRUCT_EffectItemBPTable_type
{
	struct FString CName_0_7A84EC0050230586473C7F7D0FE10665; // 0x0(0x10)
	int ID_1_77819E4026AAFDFB236ABAEE0425FEA4; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString LobbyPath_2_667FDC4028D32C79798D4B120AC19EB8; // 0x18(0x10)
	struct FString Path_3_084F3E402A58FF7D0D305BF205FF1C88; // 0x28(0x10)
};

