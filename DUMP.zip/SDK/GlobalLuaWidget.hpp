#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass GlobalLuaWidget.GlobalLuaWidget_C
// Size: 0x2C8 (Inherited: 0x2C8)
struct UGlobalLuaWidget_C : ULuaUserWidget
{

	// Object: Function GlobalLuaWidget.GlobalLuaWidget_C.GetNewLevelTaskData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xA0) ]
	void GetNewLevelTaskData(struct FString TaskID, bool& Has, struct FBP_STRUCT_NewLevelTask_type& BP_STRUCT_NewLevelTask_type);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

