#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Login_BtnItemUIBP.Login_BtnItemUIBP_C
// Size: 0x430 (Inherited: 0x418)
struct ULogin_BtnItemUIBP_C : UUAEUserWidget
{
	struct UButton* ButtonChannel; // 0x418(0x8)
	struct UGridPanel* GridPanel_0; // 0x420(0x8)
	struct UImage* Image_Btn; // 0x428(0x8)
};

