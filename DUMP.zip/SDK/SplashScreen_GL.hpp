#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass SplashScreen_GL.SplashScreen_GL_C
// Size: 0x278 (Inherited: 0x260)
struct USplashScreen_GL_C : UUserWidget
{
	struct UWidgetAnimation* Animation; // 0x260(0x8)
	struct UImage* Image_Pubg_Logobg; // 0x268(0x8)
	struct UImage* PUBG_Logo_01; // 0x270(0x8)
};

