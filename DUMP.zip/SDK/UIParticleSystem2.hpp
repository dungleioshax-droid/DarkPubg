#pragma once

#include <cstdint>

// Object: Enum UIParticleSystem2.UIMeshProjectionMethod
enum class EUIMeshProjectionMethod : uint8_t
{
	YOZOrtho = 0,
	XOYOrtho = 1,
	YOZPerspectiveFullScreen = 2,
	YOZPerspectiveLocal = 3,
	UIMeshProjectionMethod_MAX = 4
};

// Object: Class UIParticleSystem2.ParticleSystemWidget2
// Size: 0x138 (Inherited: 0x100)
struct UParticleSystemWidget2 : UWidget
{
	struct UObject* ParticleSystemTemplate; // 0x100(0x8)
	enum class EUIMeshProjectionMethod ProjectionMethod; // 0x108(0x1)
	uint8_t Pad_0x109[0x3]; // 0x109(0x3)
	float FieldOfView; // 0x10C(0x4)
	float DistanceToCamera; // 0x110(0x4)
	bool NoNeedsToSwitchVerticalAxis; // 0x114(0x1)
	bool bAutoActivate; // 0x115(0x1)
	bool bActivate; // 0x116(0x1)
	uint8_t Pad_0x117[0x1]; // 0x117(0x1)
	struct UFXSystemComponent* WorldParticleComponent; // 0x118(0x8)
	struct AActor* WorldParticleActor; // 0x120(0x8)
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)


	// Object: Function UIParticleSystem2.ParticleSystemWidget2.SetParticleSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025d2958
	// Params: [ Num(1) Size(0x8) ]
	void SetParticleSystem(struct UParticleSystem* ParticleSystem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025CB1E4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519077C

	// Object: Function UIParticleSystem2.ParticleSystemWidget2.SetNiagaraSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025d28dc
	// Params: [ Num(1) Size(0x8) ]
	void SetNiagaraSystem(struct UNiagaraSystem* ParticleSystem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025CB428
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025CB1E4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function UIParticleSystem2.ParticleSystemWidget2.SetActivate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025d2858
	// Params: [ Num(1) Size(0x1) ]
	void SetActivate(bool bIsActivate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025CC124
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025CB428
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025CB1E4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function UIParticleSystem2.ParticleSystemWidget2.GetParticleComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025d2824
	// Params: [ Num(1) Size(0x8) ]
	struct UParticleSystemComponent* GetParticleComponent();
	// [Call #1] RVA: 0x1025CC0AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1025CC124
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1025CB428
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025CB1E4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function UIParticleSystem2.ParticleSystemWidget2.GetNiagaraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025d27f0
	// Params: [ Num(1) Size(0x8) ]
	struct UNiagaraComponent* GetNiagaraComponent();
	// [Call #1] RVA: 0x1025CC0E8
	// [Call #2] RVA: 0x1025CC0AC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025CC124
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025CB428
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025CB1E4
	// [Call #12] RVA: 0x10519022C
};

// Object: Class UIParticleSystem2.UIParticleSystemComponent
// Size: 0xD10 (Inherited: 0xD00)
struct UUIParticleSystemComponent : UParticleSystemComponent
{
	uint8_t Pad_0xD00[0x10]; // 0xD00(0x10)
};

// Object: Class UIParticleSystem2.UINiagaraComponent
// Size: 0xBB0 (Inherited: 0xB90)
struct UUINiagaraComponent : UNiagaraComponent
{
	uint8_t Pad_0xB90[0x20]; // 0xB90(0x20)
};

