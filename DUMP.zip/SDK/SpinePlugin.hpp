#pragma once

#include <cstdint>

// Object: ScriptStruct SpinePlugin.SpineEvent
// Size: 0x30 (Inherited: 0x0)
struct FSpineEvent
{
	struct FString Name; // 0x0(0x10)
	struct FString StringValue; // 0x10(0x10)
	int IntValue; // 0x20(0x4)
	float FloatValue; // 0x24(0x4)
	float Time; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct SpinePlugin.SpineAnimationStateMixData
// Size: 0x28 (Inherited: 0x0)
struct FSpineAnimationStateMixData
{
	struct FString From; // 0x0(0x10)
	struct FString To; // 0x10(0x10)
	float Mix; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: Class SpinePlugin.SpineAtlasAsset
// Size: 0x58 (Inherited: 0x28)
struct USpineAtlasAsset : UObject
{
	struct TArray<struct UTexture2D*> atlasPages; // 0x28(0x10)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
	struct FString rawData; // 0x40(0x10)
	struct FName atlasFileName; // 0x50(0x8)
};

// Object: Class SpinePlugin.SpineBoneDriverComponent
// Size: 0x3D0 (Inherited: 0x3A0)
struct USpineBoneDriverComponent : USceneComponent
{
	struct AActor* Target; // 0x3A0(0x8)
	struct FString BoneName; // 0x3A8(0x10)
	bool UseComponentTransform; // 0x3B8(0x1)
	bool UsePosition; // 0x3B9(0x1)
	bool UseRotation; // 0x3BA(0x1)
	bool UseScale; // 0x3BB(0x1)
	uint8_t Pad_0x3BC[0x14]; // 0x3BC(0x14)


	// Object: Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform
	// Flags: [Final|Native|Protected]
	// Offset: 0x102bd5d50
	// Params: [ Num(1) Size(0x8) ]
	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9CE78
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870
};

// Object: Class SpinePlugin.SpineBoneFollowerComponent
// Size: 0x3C0 (Inherited: 0x3A0)
struct USpineBoneFollowerComponent : USceneComponent
{
	struct AActor* Target; // 0x3A0(0x8)
	struct FString BoneName; // 0x3A8(0x10)
	bool UseComponentTransform; // 0x3B8(0x1)
	bool UsePosition; // 0x3B9(0x1)
	bool UseRotation; // 0x3BA(0x1)
	bool UseScale; // 0x3BB(0x1)
	uint8_t Pad_0x3BC[0x4]; // 0x3BC(0x4)
};

// Object: Class SpinePlugin.TrackEntry
// Size: 0x90 (Inherited: 0x28)
struct UTrackEntry : UObject
{
	struct FScriptMulticastDelegate animationStart; // 0x28(0x10)
	struct FScriptMulticastDelegate AnimationInterrupt; // 0x38(0x10)
	struct FScriptMulticastDelegate AnimationEvent; // 0x48(0x10)
	struct FScriptMulticastDelegate AnimationComplete; // 0x58(0x10)
	struct FScriptMulticastDelegate animationEnd; // 0x68(0x10)
	struct FScriptMulticastDelegate AnimationDispose; // 0x78(0x10)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)


	// Object: Function SpinePlugin.TrackEntry.SetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6e1c
	// Params: [ Num(1) Size(0x4) ]
	void SetTrackTime(float trackTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC498
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpinePlugin.TrackEntry.SetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6da0
	// Params: [ Num(1) Size(0x4) ]
	void SetTrackEnd(float trackEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC488
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC498
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function SpinePlugin.TrackEntry.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6d24
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC478
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC488
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC498
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpinePlugin.TrackEntry.SetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6ca8
	// Params: [ Num(1) Size(0x4) ]
	void SetMixTime(float mixTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC468
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC478
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC488
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC498
	// [Call #13] RVA: 0x10519022C

	// Object: Function SpinePlugin.TrackEntry.SetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6c2c
	// Params: [ Num(1) Size(0x4) ]
	void SetMixDuration(float mixDuration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC458
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC468
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC478
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC488
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6ba8
	// Params: [ Num(1) Size(0x1) ]
	void SetLoop(bool Loop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC448
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC458
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC468
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC478
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6b2c
	// Params: [ Num(1) Size(0x4) ]
	void SetEventThreshold(float eventThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC438
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC448
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC458
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC468
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6ab0
	// Params: [ Num(1) Size(0x4) ]
	void SetDrawOrderThreshold(float drawOrderThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC428
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC438
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC448
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC458
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6a34
	// Params: [ Num(1) Size(0x4) ]
	void SetDelay(float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC418
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC428
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC438
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC448
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd69b8
	// Params: [ Num(1) Size(0x4) ]
	void SetAttachmentThreshold(float attachmentThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC408
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC418
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC428
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC438
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd693c
	// Params: [ Num(1) Size(0x4) ]
	void SetAnimationStart(float animationStart);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC3F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC408
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC418
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC428
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd68c0
	// Params: [ Num(1) Size(0x4) ]
	void SetAnimationLast(float animationLast);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC3E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC3F8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC408
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC418
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6844
	// Params: [ Num(1) Size(0x4) ]
	void SetAnimationEnd(float animationEnd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC3D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC3E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC3F8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC408
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd67c8
	// Params: [ Num(1) Size(0x4) ]
	void SetAlpha(float Alpha);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC3C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC3D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC3E8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC3F8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.isValidAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd67a4
	// Params: [ Num(1) Size(0x1) ]
	bool isValidAnimation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BDC3C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC3D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC3E8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC3F8
	// [Call #13] RVA: 0x10516D168

	// Object: Function SpinePlugin.TrackEntry.GetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6770
	// Params: [ Num(1) Size(0x4) ]
	float GetTrackTime();
	// [Call #1] RVA: 0x102BDC3B4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102BDC3C8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102BDC3D8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BDC3E8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102BDC3F8

	// Object: Function SpinePlugin.TrackEntry.GetTrackIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd673c
	// Params: [ Num(1) Size(0x4) ]
	int GetTrackIndex();
	// [Call #1] RVA: 0x102BDC3A4
	// [Call #2] RVA: 0x102BDC3B4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BDC3C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102BDC3D8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BDC3E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.GetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6708
	// Params: [ Num(1) Size(0x4) ]
	float GetTrackEnd();
	// [Call #1] RVA: 0x102BDC390
	// [Call #2] RVA: 0x102BDC3A4
	// [Call #3] RVA: 0x102BDC3B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BDC3C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC3D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC3E8

	// Object: Function SpinePlugin.TrackEntry.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd66d4
	// Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();
	// [Call #1] RVA: 0x102BDC37C
	// [Call #2] RVA: 0x102BDC390
	// [Call #3] RVA: 0x102BDC3A4
	// [Call #4] RVA: 0x102BDC3B4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102BDC3C8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BDC3D8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102BDC3E8

	// Object: Function SpinePlugin.TrackEntry.GetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd66a0
	// Params: [ Num(1) Size(0x4) ]
	float GetMixTime();
	// [Call #1] RVA: 0x102BDC368
	// [Call #2] RVA: 0x102BDC37C
	// [Call #3] RVA: 0x102BDC390
	// [Call #4] RVA: 0x102BDC3A4
	// [Call #5] RVA: 0x102BDC3B4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102BDC3C8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BDC3D8
	// [Call #12] RVA: 0x10516D168

	// Object: Function SpinePlugin.TrackEntry.GetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd666c
	// Params: [ Num(1) Size(0x4) ]
	float GetMixDuration();
	// [Call #1] RVA: 0x102BDC354
	// [Call #2] RVA: 0x102BDC368
	// [Call #3] RVA: 0x102BDC37C
	// [Call #4] RVA: 0x102BDC390
	// [Call #5] RVA: 0x102BDC3A4
	// [Call #6] RVA: 0x102BDC3B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BDC3C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BDC3D8

	// Object: Function SpinePlugin.TrackEntry.GetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6638
	// Params: [ Num(1) Size(0x1) ]
	bool GetLoop();
	// [Call #1] RVA: 0x102BDC344
	// [Call #2] RVA: 0x102BDC354
	// [Call #3] RVA: 0x102BDC368
	// [Call #4] RVA: 0x102BDC37C
	// [Call #5] RVA: 0x102BDC390
	// [Call #6] RVA: 0x102BDC3A4
	// [Call #7] RVA: 0x102BDC3B4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BDC3C8
	// [Call #11] RVA: 0x10516D168

	// Object: Function SpinePlugin.TrackEntry.GetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6604
	// Params: [ Num(1) Size(0x4) ]
	float GetEventThreshold();
	// [Call #1] RVA: 0x102BDC330
	// [Call #2] RVA: 0x102BDC344
	// [Call #3] RVA: 0x102BDC354
	// [Call #4] RVA: 0x102BDC368
	// [Call #5] RVA: 0x102BDC37C
	// [Call #6] RVA: 0x102BDC390
	// [Call #7] RVA: 0x102BDC3A4
	// [Call #8] RVA: 0x102BDC3B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BDC3C8

	// Object: Function SpinePlugin.TrackEntry.GetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd65d0
	// Params: [ Num(1) Size(0x4) ]
	float GetDrawOrderThreshold();
	// [Call #1] RVA: 0x102BDC31C
	// [Call #2] RVA: 0x102BDC330
	// [Call #3] RVA: 0x102BDC344
	// [Call #4] RVA: 0x102BDC354
	// [Call #5] RVA: 0x102BDC368
	// [Call #6] RVA: 0x102BDC37C
	// [Call #7] RVA: 0x102BDC390
	// [Call #8] RVA: 0x102BDC3A4
	// [Call #9] RVA: 0x102BDC3B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.TrackEntry.GetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd659c
	// Params: [ Num(1) Size(0x4) ]
	float GetDelay();
	// [Call #1] RVA: 0x102BDC308
	// [Call #2] RVA: 0x102BDC31C
	// [Call #3] RVA: 0x102BDC330
	// [Call #4] RVA: 0x102BDC344
	// [Call #5] RVA: 0x102BDC354
	// [Call #6] RVA: 0x102BDC368
	// [Call #7] RVA: 0x102BDC37C
	// [Call #8] RVA: 0x102BDC390
	// [Call #9] RVA: 0x102BDC3A4
	// [Call #10] RVA: 0x102BDC3B4

	// Object: Function SpinePlugin.TrackEntry.GetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6568
	// Params: [ Num(1) Size(0x4) ]
	float GetAttachmentThreshold();
	// [Call #1] RVA: 0x102BDC2F4
	// [Call #2] RVA: 0x102BDC308
	// [Call #3] RVA: 0x102BDC31C
	// [Call #4] RVA: 0x102BDC330
	// [Call #5] RVA: 0x102BDC344
	// [Call #6] RVA: 0x102BDC354
	// [Call #7] RVA: 0x102BDC368
	// [Call #8] RVA: 0x102BDC37C
	// [Call #9] RVA: 0x102BDC390
	// [Call #10] RVA: 0x102BDC3A4
	// [Call #11] RVA: 0x102BDC3B4

	// Object: Function SpinePlugin.TrackEntry.GetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6534
	// Params: [ Num(1) Size(0x4) ]
	float GetAnimationStart();
	// [Call #1] RVA: 0x102BDC2E0
	// [Call #2] RVA: 0x102BDC2F4
	// [Call #3] RVA: 0x102BDC308
	// [Call #4] RVA: 0x102BDC31C
	// [Call #5] RVA: 0x102BDC330
	// [Call #6] RVA: 0x102BDC344
	// [Call #7] RVA: 0x102BDC354
	// [Call #8] RVA: 0x102BDC368
	// [Call #9] RVA: 0x102BDC37C
	// [Call #10] RVA: 0x102BDC390
	// [Call #11] RVA: 0x102BDC3A4

	// Object: Function SpinePlugin.TrackEntry.getAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd64d0
	// Params: [ Num(1) Size(0x10) ]
	struct FString getAnimationName();
	// [Call #1] RVA: 0x102BDC21C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102BDC2E0
	// [Call #7] RVA: 0x102BDC2F4
	// [Call #8] RVA: 0x102BDC308
	// [Call #9] RVA: 0x102BDC31C
	// [Call #10] RVA: 0x102BDC330
	// [Call #11] RVA: 0x102BDC344
	// [Call #12] RVA: 0x102BDC354
	// [Call #13] RVA: 0x102BDC368
	// [Call #14] RVA: 0x102BDC37C

	// Object: Function SpinePlugin.TrackEntry.GetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd649c
	// Params: [ Num(1) Size(0x4) ]
	float GetAnimationLast();
	// [Call #1] RVA: 0x102BDC208
	// [Call #2] RVA: 0x102BDC21C
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102BDC2E0
	// [Call #8] RVA: 0x102BDC2F4
	// [Call #9] RVA: 0x102BDC308
	// [Call #10] RVA: 0x102BDC31C
	// [Call #11] RVA: 0x102BDC330
	// [Call #12] RVA: 0x102BDC344
	// [Call #13] RVA: 0x102BDC354
	// [Call #14] RVA: 0x102BDC368

	// Object: Function SpinePlugin.TrackEntry.GetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6468
	// Params: [ Num(1) Size(0x4) ]
	float GetAnimationEnd();
	// [Call #1] RVA: 0x102BDC1F4
	// [Call #2] RVA: 0x102BDC208
	// [Call #3] RVA: 0x102BDC21C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x102BDC2E0
	// [Call #9] RVA: 0x102BDC2F4
	// [Call #10] RVA: 0x102BDC308
	// [Call #11] RVA: 0x102BDC31C
	// [Call #12] RVA: 0x102BDC330
	// [Call #13] RVA: 0x102BDC344
	// [Call #14] RVA: 0x102BDC354

	// Object: Function SpinePlugin.TrackEntry.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6434
	// Params: [ Num(1) Size(0x4) ]
	float getAnimationDuration();
	// [Call #1] RVA: 0x102BDC1D0
	// [Call #2] RVA: 0x102BDC1F4
	// [Call #3] RVA: 0x102BDC208
	// [Call #4] RVA: 0x102BDC21C
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x102BDC2E0
	// [Call #10] RVA: 0x102BDC2F4
	// [Call #11] RVA: 0x102BDC308
	// [Call #12] RVA: 0x102BDC31C
	// [Call #13] RVA: 0x102BDC330
	// [Call #14] RVA: 0x102BDC344

	// Object: Function SpinePlugin.TrackEntry.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd6400
	// Params: [ Num(1) Size(0x4) ]
	float GetAlpha();
	// [Call #1] RVA: 0x102BDC1BC
	// [Call #2] RVA: 0x102BDC1D0
	// [Call #3] RVA: 0x102BDC1F4
	// [Call #4] RVA: 0x102BDC208
	// [Call #5] RVA: 0x102BDC21C
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x102BDC2E0
	// [Call #11] RVA: 0x102BDC2F4
	// [Call #12] RVA: 0x102BDC308
	// [Call #13] RVA: 0x102BDC31C
	// [Call #14] RVA: 0x102BDC330
};

// Object: Class SpinePlugin.SpineSkeletonComponent
// Size: 0x1D0 (Inherited: 0x178)
struct USpineSkeletonComponent : UActorComponent
{
	struct USpineAtlasAsset* Atlas; // 0x178(0x8)
	struct USpineSkeletonDataAsset* SkeletonData; // 0x180(0x8)
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // 0x188(0x10)
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // 0x198(0x10)
	uint8_t Pad_0x1A8[0x28]; // 0x1A8(0x28)


	// Object: Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd93e0
	// Params: [ Num(0) Size(0x0) ]
	void UpdateWorldTransform();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd93cc
	// Params: [ Num(0) Size(0x0) ]
	void SetToSetupPose();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd93b8
	// Params: [ Num(0) Size(0x0) ]
	void SetSlotsToSetupPose();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSlotColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102bd9298
	// Params: [ Num(2) Size(0x14) ]
	void SetSlotColor(struct FString SlotName, struct FColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102BA085C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102bd91e0
	// Params: [ Num(2) Size(0x11) ]
	bool SetSkins(struct TArray<struct FString>& SkinNames);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9FB48
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x102BA085C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd90ec
	// Params: [ Num(2) Size(0x11) ]
	bool SetSkin(struct FString SkinName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102B9E67C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B9FB48
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd9070
	// Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float ScaleY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA0370
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102B9E67C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B9FB48
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8ff4
	// Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float ScaleX);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA02E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BA0370
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102B9E67C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102bd8f10
	// Params: [ Num(2) Size(0x1C) ]
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9CF58
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BA02E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA0370
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8efc
	// Params: [ Num(0) Size(0x0) ]
	void SetBonesToSetupPose();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9CF58
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BA02E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA0370
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8d70
	// Params: [ Num(3) Size(0x21) ]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102B9FF14
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x102B9CF58

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8c7c
	// Params: [ Num(2) Size(0x11) ]
	bool HasSlot(struct FString SlotName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA078C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x102B9FF14
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x100036FE0
	// [Call #27] RVA: 0x104EEF504

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8b88
	// Params: [ Num(2) Size(0x11) ]
	bool HasSkin(struct FString SkinName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102B9FE44
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BA078C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd8a94
	// Params: [ Num(2) Size(0x11) ]
	bool HasBone(struct FString BoneName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA0564
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102B9FE44
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd89a0
	// Params: [ Num(2) Size(0x11) ]
	bool HasAnimation(struct FString AnimationName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA0ACC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BA0564
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bd88f8
	// Params: [ Num(1) Size(0x10) ]
	void GetSlots(struct TArray<struct FString>& Slots);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA0634
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102BA0ACC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x102BA0564
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bd8850
	// Params: [ Num(1) Size(0x10) ]
	void GetSkins(struct TArray<struct FString>& Skins);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9FCE8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA0634
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x102BA0ACC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd881c
	// Params: [ Num(1) Size(0x4) ]
	float GetScaleY();
	// [Call #1] RVA: 0x102BA03C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B9FCE8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA0634
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x102BA0ACC
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd87e8
	// Params: [ Num(1) Size(0x4) ]
	float GetScaleX();
	// [Call #1] RVA: 0x102BA0330
	// [Call #2] RVA: 0x102BA03C0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9FCE8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BA0634
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x102BA0ACC
	// [Call #19] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102bd872c
	// Params: [ Num(2) Size(0x40) ]
	struct FTransform GetBoneWorldTransform(struct FString BoneName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9D5F0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102BA0330
	// [Call #8] RVA: 0x102BA03C0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B9FCE8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102BA0634
	// [Call #18] RVA: 0x101F8B9F8

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bd8684
	// Params: [ Num(1) Size(0x10) ]
	void GetBones(struct TArray<struct FString>& Bones);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA0400
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B9D5F0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102BA0330
	// [Call #14] RVA: 0x102BA03C0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B9FCE8
	// [Call #18] RVA: 0x101F8B9F8

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bd85dc
	// Params: [ Num(1) Size(0x10) ]
	void GetAnimations(struct TArray<struct FString>& Animations);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA096C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA0400
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B9D5F0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x102BA0330

	// Object: Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd84e8
	// Params: [ Num(2) Size(0x14) ]
	float getAnimationDuration(struct FString AnimationName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA0B9C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA096C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102BA0400
	// [Call #21] RVA: 0x101F8B9F8
	// [Call #22] RVA: 0x101F8B9F8
	// [Call #23] RVA: 0x106C8459C
};

// Object: Class SpinePlugin.SpineSkeletonAnimationComponent
// Size: 0x2D0 (Inherited: 0x1D0)
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent
{
	struct FScriptMulticastDelegate animationStart; // 0x1D0(0x10)
	struct FScriptMulticastDelegate AnimationInterrupt; // 0x1E0(0x10)
	struct FScriptMulticastDelegate AnimationEvent; // 0x1F0(0x10)
	struct FScriptMulticastDelegate AnimationComplete; // 0x200(0x10)
	struct FScriptMulticastDelegate animationEnd; // 0x210(0x10)
	struct FScriptMulticastDelegate AnimationDispose; // 0x220(0x10)
	struct FString PreviewAnimation; // 0x230(0x10)
	struct FString PreviewSkin; // 0x240(0x10)
	uint8_t Pad_0x250[0x8]; // 0x250(0x8)
	struct TSet<struct UTrackEntry*> trackEntries; // 0x258(0x50)
	bool bAutoPlaying; // 0x2A8(0x1)
	uint8_t Pad_0x2A9[0x27]; // 0x2A9(0x27)


	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7fe4
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9F4A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7f24
	// Params: [ Num(2) Size(0x5) ]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9F3C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B9F4A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7e5c
	// Params: [ Num(3) Size(0x10) ]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9E5E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B9F3C0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B9F4A4
	// [Call #14] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7dd8
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool bInAutoPlays);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9F3B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B9E5E4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B9F3C0
	// [Call #14] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7c5c
	// Params: [ Num(4) Size(0x28) ]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x102B9E450
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102B9F3B8
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7c28
	// Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();
	// [Call #1] RVA: 0x102B9F4E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102B9E450
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B9F3B8

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7b9c
	// Params: [ Num(2) Size(0x10) ]
	struct UTrackEntry* GetCurrent(int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9F930
	// [Call #4] RVA: 0x102B9F4E4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x102B9E450
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7b88
	// Params: [ Num(0) Size(0x0) ]
	void ClearTracks();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9F930
	// [Call #4] RVA: 0x102B9F4E4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x102B9E450
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7b0c
	// Params: [ Num(1) Size(0x4) ]
	void ClearTrack(int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B9FA68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B9F930
	// [Call #7] RVA: 0x102B9F4E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7a0c
	// Params: [ Num(4) Size(0x18) ]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B9F81C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B9FA68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B9F930
	// [Call #14] RVA: 0x102B9F4E4

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd7850
	// Params: [ Num(5) Size(0x28) ]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102B9F5CC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
};

// Object: Class SpinePlugin.SpineSkeletonDataAsset
// Size: 0xF8 (Inherited: 0x28)
struct USpineSkeletonDataAsset : UObject
{
	float DefaultMix; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FSpineAnimationStateMixData> MixData; // 0x30(0x10)
	struct TArray<struct FString> Bones; // 0x40(0x10)
	struct TArray<struct FString> Slots; // 0x50(0x10)
	struct TArray<struct FString> Skins; // 0x60(0x10)
	struct TArray<struct FString> Animations; // 0x70(0x10)
	struct TArray<struct FString> Events; // 0x80(0x10)
	struct TArray<uint8_t> rawData; // 0x90(0x10)
	struct FName skeletonDataFileName; // 0xA0(0x8)
	uint8_t Pad_0xA8[0x50]; // 0xA8(0x50)
};

// Object: Class SpinePlugin.SpineSkeletonRendererComponent
// Size: 0xE40 (Inherited: 0xA90)
struct USpineSkeletonRendererComponent : UProceduralMeshComponent
{
	struct UMaterialInterface* NormalBlendMaterial; // 0xA88(0x8)
	struct UMaterialInterface* AdditiveBlendMaterial; // 0xA90(0x8)
	struct UMaterialInterface* MultiplyBlendMaterial; // 0xA98(0x8)
	struct UMaterialInterface* ScreenBlendMaterial; // 0xAA0(0x8)
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // 0xAA8(0x10)
	uint8_t Pad_0xAC0[0x48]; // 0xAC0(0x48)
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // 0xB08(0x10)
	uint8_t Pad_0xB18[0x50]; // 0xB18(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // 0xB68(0x10)
	uint8_t Pad_0xB78[0x50]; // 0xB78(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // 0xBC8(0x10)
	uint8_t Pad_0xBD8[0x50]; // 0xBD8(0x50)
	float DepthOffset; // 0xC28(0x4)
	uint8_t Pad_0xC2C[0x4]; // 0xC2C(0x4)
	struct FName TextureParameterName; // 0xC30(0x8)
	struct FLinearColor Color; // 0xC38(0x10)
	bool bCreateCollision; // 0xC48(0x1)
	uint8_t Pad_0xC49[0x1F7]; // 0xC49(0x1F7)
};

// Object: Class SpinePlugin.SpineWidget
// Size: 0x7E8 (Inherited: 0x100)
struct USpineWidget : UWidget
{
	float Scale; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
	struct FString InitialSkin; // 0x108(0x10)
	struct USpineAtlasAsset* Atlas; // 0x118(0x8)
	struct USpineSkeletonDataAsset* SkeletonData; // 0x120(0x8)
	struct UMaterialInterface* NormalBlendMaterial; // 0x128(0x8)
	struct UMaterialInterface* AdditiveBlendMaterial; // 0x130(0x8)
	struct UMaterialInterface* MultiplyBlendMaterial; // 0x138(0x8)
	struct UMaterialInterface* ScreenBlendMaterial; // 0x140(0x8)
	struct TMap<struct FName, struct UMaterialInterface*> CustomMaterials; // 0x148(0x50)
	struct TMap<struct FName, struct FName> Sockets; // 0x198(0x50)
	uint8_t Pad_0x1E8[0x50]; // 0x1E8(0x50)
	struct FName TextureParameterName; // 0x238(0x8)
	float DepthOffset; // 0x240(0x4)
	struct FLinearColor Color; // 0x244(0x10)
	uint8_t Pad_0x254[0x4]; // 0x254(0x4)
	struct FSlateBrush Brush; // 0x258(0xB8)
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // 0x310(0x10)
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // 0x320(0x10)
	struct FScriptMulticastDelegate animationStart; // 0x330(0x10)
	struct FScriptMulticastDelegate AnimationInterrupt; // 0x340(0x10)
	struct FScriptMulticastDelegate AnimationEvent; // 0x350(0x10)
	struct FScriptMulticastDelegate AnimationComplete; // 0x360(0x10)
	struct FScriptMulticastDelegate animationEnd; // 0x370(0x10)
	struct FScriptMulticastDelegate AnimationDispose; // 0x380(0x10)
	uint8_t Pad_0x390[0x40]; // 0x390(0x40)
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // 0x3D0(0x10)
	uint8_t Pad_0x3E0[0x50]; // 0x3E0(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // 0x430(0x10)
	uint8_t Pad_0x440[0x50]; // 0x440(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // 0x490(0x10)
	uint8_t Pad_0x4A0[0x50]; // 0x4A0(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // 0x4F0(0x10)
	uint8_t Pad_0x500[0x240]; // 0x500(0x240)
	struct TSet<struct UTrackEntry*> trackEntries; // 0x740(0x50)
	uint8_t Pad_0x790[0x50]; // 0x790(0x50)
	bool bAutoPlaying; // 0x7E0(0x1)
	uint8_t Pad_0x7E1[0x7]; // 0x7E1(0x7)


	// Object: Function SpinePlugin.SpineWidget.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb48c
	// Params: [ Num(0) Size(0x0) ]
	void UpdateWorldTransform();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineWidget.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb3cc
	// Params: [ Num(2) Size(0x5) ]
	void Tick(float DeltaTime, bool CallDelegates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA2F00
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineWidget.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb3b8
	// Params: [ Num(0) Size(0x0) ]
	void SetToSetupPose();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA2F00
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineWidget.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb33c
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA4640
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102BA2F00
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineWidget.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb328
	// Params: [ Num(0) Size(0x0) ]
	void SetSlotsToSetupPose();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA4640
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102BA2F00
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function SpinePlugin.SpineWidget.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102bdb270
	// Params: [ Num(2) Size(0x11) ]
	bool SetSkins(struct TArray<struct FString>& SkinNames);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA35C4
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA4640
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA2F00

	// Object: Function SpinePlugin.SpineWidget.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb17c
	// Params: [ Num(2) Size(0x11) ]
	bool SetSkin(struct FString SkinName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA2E18
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA35C4
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102BA4640

	// Object: Function SpinePlugin.SpineWidget.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb100
	// Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float ScaleY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA3D90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102BA2E18
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102BA35C4
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineWidget.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdb084
	// Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float ScaleX);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA3D00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BA3D90
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102BA2E18
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineWidget.SetScale
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102bdb000
	// Params: [ Num(1) Size(0x4) ]
	void SetScale(float InScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA3D00
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102BA3D90
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x102BA2E18
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504

	// Object: Function SpinePlugin.SpineWidget.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdaf40
	// Params: [ Num(2) Size(0x5) ]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA4574
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA3D00
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102BA3D90

	// Object: Function SpinePlugin.SpineWidget.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdae78
	// Params: [ Num(3) Size(0x10) ]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA49F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA4574
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.SetColor
	// Flags: [Native|Protected|HasDefaults|BlueprintCallable]
	// Offset: 0x102bdadf4
	// Params: [ Num(1) Size(0x10) ]
	void SetColor(struct FLinearColor InColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102BA49F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BA4574
	// [Call #13] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdade0
	// Params: [ Num(0) Size(0x0) ]
	void SetBonesToSetupPose();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102BA49F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BA4574
	// [Call #13] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdad5c
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool bInAutoPlays);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA456C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA49F4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdabd0
	// Params: [ Num(3) Size(0x21) ]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102BA3998
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x102BA456C
	// [Call #24] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bdaa54
	// Params: [ Num(4) Size(0x28) ]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x102BA46BC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F8122C

	// Object: Function SpinePlugin.SpineWidget.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda960
	// Params: [ Num(2) Size(0x11) ]
	bool HasSlot(struct FString SlotName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA419C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x102BA46BC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0

	// Object: Function SpinePlugin.SpineWidget.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda86c
	// Params: [ Num(2) Size(0x11) ]
	bool HasSkin(struct FString SkinName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA38C8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BA419C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineWidget.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda778
	// Params: [ Num(2) Size(0x11) ]
	bool HasBone(struct FString BoneName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA3F74
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BA38C8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineWidget.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda684
	// Params: [ Num(2) Size(0x11) ]
	bool HasAnimation(struct FString AnimationName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA43C4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BA3F74
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineWidget.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda650
	// Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();
	// [Call #1] RVA: 0x102BA4680
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x102BA43C4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x102BA3F74
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bda5a8
	// Params: [ Num(1) Size(0x10) ]
	void GetSlots(struct TArray<struct FString>& Slots);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA4044
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102BA4680
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x102BA43C4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F8122C

	// Object: Function SpinePlugin.SpineWidget.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bda500
	// Params: [ Num(1) Size(0x10) ]
	void GetSkins(struct TArray<struct FString>& Skins);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA376C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA4044
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102BA4680
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x102BA43C4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineWidget.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda4cc
	// Params: [ Num(1) Size(0x4) ]
	float GetScaleY();
	// [Call #1] RVA: 0x102BA3DE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102BA376C
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA4044
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x102BA4680
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x102BA43C4
	// [Call #19] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineWidget.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda498
	// Params: [ Num(1) Size(0x4) ]
	float GetScaleX();
	// [Call #1] RVA: 0x102BA3D50
	// [Call #2] RVA: 0x102BA3DE0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BA376C
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BA4044
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x102BA4680
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function SpinePlugin.SpineWidget.GetScale
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102bda464
	// Params: [ Num(1) Size(0x4) ]
	float GetScale();
	// [Call #1] RVA: 0x102BA3344
	// [Call #2] RVA: 0x102BA3D50
	// [Call #3] RVA: 0x102BA3DE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BA376C
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BA4044
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102BA4680

	// Object: Function SpinePlugin.SpineWidget.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda3d8
	// Params: [ Num(2) Size(0x10) ]
	struct UTrackEntry* GetCurrent(int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA4B2C
	// [Call #4] RVA: 0x102BA3344
	// [Call #5] RVA: 0x102BA3D50
	// [Call #6] RVA: 0x102BA3DE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA376C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102BA4044
	// [Call #16] RVA: 0x101F8B9F8

	// Object: Function SpinePlugin.SpineWidget.GetColor
	// Flags: [Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102bda3a0
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetColor();
	// [Call #1] RVA: 0x102BA3354
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102BA4B2C
	// [Call #5] RVA: 0x102BA3344
	// [Call #6] RVA: 0x102BA3D50
	// [Call #7] RVA: 0x102BA3DE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA376C
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bda2f8
	// Params: [ Num(1) Size(0x10) ]
	void GetBones(struct TArray<struct FString>& Bones);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA3E20
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102BA3354
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA4B2C
	// [Call #11] RVA: 0x102BA3344
	// [Call #12] RVA: 0x102BA3D50
	// [Call #13] RVA: 0x102BA3DE0
	// [Call #14] RVA: 0x10516D168

	// Object: Function SpinePlugin.SpineWidget.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102bda250
	// Params: [ Num(1) Size(0x10) ]
	void GetAnimations(struct TArray<struct FString>& Animations);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA426C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BA3E20
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102BA3354
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102BA4B2C
	// [Call #17] RVA: 0x102BA3344

	// Object: Function SpinePlugin.SpineWidget.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda15c
	// Params: [ Num(2) Size(0x14) ]
	float getAnimationDuration(struct FString AnimationName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA4494
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA426C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102BA3E20
	// [Call #21] RVA: 0x101F8B9F8
	// [Call #22] RVA: 0x101F8B9F8
	// [Call #23] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineWidget.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda148
	// Params: [ Num(0) Size(0x0) ]
	void ClearTracks();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BA4494
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BA426C
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102BA3E20
	// [Call #21] RVA: 0x101F8B9F8
	// [Call #22] RVA: 0x101F8B9F8
	// [Call #23] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineWidget.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bda0cc
	// Params: [ Num(1) Size(0x4) ]
	void ClearTrack(int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BA4C00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102BA4494
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102BA426C
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function SpinePlugin.SpineWidget.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd9fcc
	// Params: [ Num(4) Size(0x18) ]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102BA4A8C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BA4C00
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x102BA4494
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function SpinePlugin.SpineWidget.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bd9e10
	// Params: [ Num(5) Size(0x28) ]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x102BA4850
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
};

