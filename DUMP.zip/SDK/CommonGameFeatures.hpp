#pragma once

#include <cstdint>

// Object: ScriptStruct CommonGameFeatures.RepControlGroupData
// Size: 0x50 (Inherited: 0x0)
struct FRepControlGroupData
{
	struct TMap<int64_t, int> RepControlMap; // 0x0(0x50)
};

// Object: Class CommonGameFeatures.ActorRepControlComponent
// Size: 0x288 (Inherited: 0x238)
struct UActorRepControlComponent : ULuaActorComponent
{
	struct TMap<int, struct FRepControlGroupData> ItemRepBlockingUIDMap; // 0x238(0x50)


	// Object: Function CommonGameFeatures.ActorRepControlComponent.ToggleGroupedRepControlByUID
	// Flags: [Native|Public]
	// Offset: 0x102795e80
	// Params: [ Num(3) Size(0x10) ]
	void ToggleGroupedRepControlByUID(int64_t UID, int ControlMark, int RepControlGroup);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function CommonGameFeatures.ActorRepControlComponent.ShouldBlockRepByUID
	// Flags: [Native|Public|Const]
	// Offset: 0x102795db0
	// Params: [ Num(3) Size(0xD) ]
	bool ShouldBlockRepByUID(int64_t UID, int RepControlGroup);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function CommonGameFeatures.ActorRepControlComponent.GetControlGroupData
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x102795cb8
	// Params: [ Num(3) Size(0x59) ]
	bool GetControlGroupData(int RepControlGroup, struct FRepControlGroupData& OutData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279328C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102792E58
	// [Call #7] RVA: 0x10279335C
	// [Call #8] RVA: 0x10279335C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class CommonGameFeatures.RepControlActorBase
// Size: 0x578 (Inherited: 0x570)
struct ARepControlActorBase : ALuaActor
{
	bool bCanBlockNet; // 0x569(0x1)
	int RepControlGroup; // 0x56C(0x4)
	struct UActorRepControlComponent* CachedBlockingComp; // 0x570(0x8)


	// Object: Function CommonGameFeatures.RepControlActorBase.IsNetRelevantForCustomCheck
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x1027961e0
	// Params: [ Num(4) Size(0x1D) ]
	bool IsNetRelevantForCustomCheck(struct AActor* RealViewer, struct AActor* ViewTarget, struct FVector& SrcLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
};

