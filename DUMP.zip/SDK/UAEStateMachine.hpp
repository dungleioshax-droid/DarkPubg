#pragma once

#include <cstdint>

// Object: ScriptStruct UAEStateMachine.UAETransitionState
// Size: 0x10 (Inherited: 0x0)
struct FUAETransitionState
{
	struct FString StateName; // 0x0(0x10)
};

// Object: ScriptStruct UAEStateMachine.UAEStateMachineTransition
// Size: 0x28 (Inherited: 0x0)
struct FUAEStateMachineTransition
{
	struct TArray<struct FUAETransitionState> TransiteFromStates; // 0x0(0x10)
	struct FUAETransitionState TransitToState; // 0x10(0x10)
	float AutoFiredDelayTime; // 0x20(0x4)
	bool AutoFiredForcedTransit; // 0x24(0x1)
	uint8_t Pad_0x25[0x3]; // 0x25(0x3)
};

// Object: ScriptStruct UAEStateMachine.UAEStatesGather
// Size: 0x10 (Inherited: 0x0)
struct FUAEStatesGather
{
	struct TArray<struct UUAEState*> States; // 0x0(0x10)
};

// Object: Class UAEStateMachine.TestStatemachine
// Size: 0x4B8 (Inherited: 0x4B0)
struct ATestStatemachine : AActor
{
	struct UUAEStateMachineComponent* UAEStateMachineComponent; // 0x4B0(0x8)
};

// Object: Class UAEStateMachine.UAEStateMachineComponent
// Size: 0x230 (Inherited: 0x178)
struct UUAEStateMachineComponent : UActorComponent
{
	struct FScriptMulticastDelegate OnBeforeTransientEvent; // 0x178(0x10)
	struct FScriptMulticastDelegate OnAfterTransientEvent; // 0x188(0x10)
	struct FString Tag; // 0x198(0x10)
	struct TArray<struct UUAEState*> States; // 0x1A8(0x10)
	struct TMap<struct FString, struct FUAEStateMachineTransition> Transitions; // 0x1B8(0x50)
	struct FUAETransitionState StartState; // 0x208(0x10)
	struct FUAETransitionState EndState; // 0x218(0x10)
	struct UUAEState* CurrentState; // 0x228(0x8)


	// Object: Function UAEStateMachine.UAEStateMachineComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beba9c
	// Params: [ Num(0) Size(0x0) ]
	void Start();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UAEStateMachine.UAEStateMachineComponent.SetTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb9b8
	// Params: [ Num(1) Size(0x10) ]
	void SetTag(struct FString InTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE9A20
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: DelegateFunction UAEStateMachine.UAEStateMachineComponent.OnTransientEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x30) ]
	void OnTransientEvent__DelegateSignature(struct FString TransientEvent, struct FString CurrentState, struct FString TransientToState);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function UAEStateMachine.UAEStateMachineComponent.IsInState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb8c4
	// Params: [ Num(2) Size(0x11) ]
	bool IsInState(struct FString StateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE97C8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE9A20
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C

	// Object: Function UAEStateMachine.UAEStateMachineComponent.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb8a8
	// Params: [ Num(1) Size(0x8) ]
	struct UUAEState* GetCurrentState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE97C8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE9A20
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C

	// Object: Function UAEStateMachine.UAEStateMachineComponent.ForceDoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb7c4
	// Params: [ Num(1) Size(0x10) ]
	void ForceDoEvent(struct FString EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE92B8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE97C8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function UAEStateMachine.UAEStateMachineComponent.Finish
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb7b0
	// Params: [ Num(0) Size(0x0) ]
	void Finish();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE92B8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE97C8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function UAEStateMachine.UAEStateMachineComponent.DoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb6cc
	// Params: [ Num(1) Size(0x10) ]
	void DoEvent(struct FString EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE8DAC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE92B8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function UAEStateMachine.UAEStateMachineComponent.CanDoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102beb5d8
	// Params: [ Num(2) Size(0x11) ]
	bool CanDoEvent(struct FString EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BE99C8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BE8DAC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
};

// Object: Class UAEStateMachine.UAEState
// Size: 0x28 (Inherited: 0x28)
struct UUAEState : UObject
{

	// Object: Function UAEStateMachine.UAEState.Update
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102beb084
	// Params: [ Num(1) Size(0x4) ]
	void Update(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function UAEStateMachine.UAEState.OnLeave
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102beb000
	// Params: [ Num(1) Size(0x8) ]
	void OnLeave(struct UUAEState* TranitToState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function UAEStateMachine.UAEState.OnEnter
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102beaf7c
	// Params: [ Num(1) Size(0x8) ]
	void OnEnter(struct UUAEState* PrevState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

