#pragma once

#include <cstdint>

// Object: Class AWSHelper.AWSHelper
// Size: 0x178 (Inherited: 0x28)
struct UAWSHelper : UObject
{
	uint8_t Pad_0x28[0xA8]; // 0x28(0xA8)
	struct TMap<struct FString, struct FString> DownloadFilePaths; // 0xD0(0x50)
	float Timeout; // 0x120(0x4)
	uint8_t Pad_0x124[0x54]; // 0x124(0x54)
};

// Object: Class AWSHelper.AWSHelperBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAWSHelperBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.UploadFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102735900
	// Params: [ Num(6) Size(0x58) ]
	void UploadFile(struct UAWSHelper* CosHelper, struct FString FromFilePath, struct FString ToURL, struct FString NoneMatchHeader, DelegateProperty& OnComplete, DelegateProperty& OnProgress);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102731350
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.UploadBinary
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102735688
	// Params: [ Num(6) Size(0x58) ]
	void UploadBinary(struct UAWSHelper* CosHelper, struct TArray<uint8_t>& FromBinaries, struct FString ToURL, struct FString NoneMatchHeader, DelegateProperty& OnComplete, DelegateProperty& OnProgress);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10273148C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.DownloadFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102735478
	// Params: [ Num(5) Size(0x48) ]
	void DownloadFile(struct UAWSHelper* CosHelper, struct FString FromURL, struct FString ToFilePath, DelegateProperty& OnComplete, DelegateProperty& OnProgress);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FD9E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD9E48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1027315C8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.DownloadBinary
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027352bc
	// Params: [ Num(4) Size(0x38) ]
	void DownloadBinary(struct UAWSHelper* CosHelper, struct FString FromURL, DelegateProperty& OnComplete, DelegateProperty& OnProgress);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD9E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027316F4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.DestroyAWSHelper
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102735248
	// Params: [ Num(1) Size(0x8) ]
	void DestroyAWSHelper(struct UAWSHelper* AWSHelper);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027312F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD9E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD9E48
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1027316F4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function AWSHelper.AWSHelperBlueprintLibrary.ConstructAWSHelper
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102735214
	// Params: [ Num(1) Size(0x8) ]
	struct UAWSHelper* ConstructAWSHelper();
	// [Call #1] RVA: 0x102731258
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027312F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1027316F4
	// [Call #16] RVA: 0x101F8130C
};

// Object: Class AWSHelper.AWSResponse
// Size: 0x70 (Inherited: 0x28)
struct UAWSResponse : UObject
{
	uint8_t Pad_0x28[0x48]; // 0x28(0x48)


	// Object: Function AWSHelper.AWSResponse.IsOK
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102736014
	// Params: [ Num(1) Size(0x1) ]
	bool IsOK();
	// [Call #1] RVA: 0x1027318DC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetResponseCode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735fe0
	// Params: [ Num(1) Size(0x4) ]
	int GetResponseCode();
	// [Call #1] RVA: 0x102731948
	// [Call #2] RVA: 0x1027318DC
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetRequestURL
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735f7c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetRequestURL();
	// [Call #1] RVA: 0x102731964
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102731948
	// [Call #7] RVA: 0x1027318DC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetErrorMessage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735f18
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetErrorMessage();
	// [Call #1] RVA: 0x102731A3C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102731964
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102731948
	// [Call #12] RVA: 0x1027318DC
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetErrorCode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735eb4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetErrorCode();
	// [Call #1] RVA: 0x102731A90
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102731A3C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102731964
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102731948
	// [Call #17] RVA: 0x1027318DC
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetContentAsString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735e50
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetContentAsString();
	// [Call #1] RVA: 0x1027318C0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102731A90
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102731A3C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102731964
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x102731948
	// [Call #22] RVA: 0x1027318DC
	// [Call #23] RVA: 0x10519022C

	// Object: Function AWSHelper.AWSResponse.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102735e18
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> GetContent();
	// [Call #1] RVA: 0x1027319B8
	// [Call #2] RVA: 0x1027318C0
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102731A90
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x102731A3C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x102731964
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x102731948
	// [Call #23] RVA: 0x1027318DC
};

