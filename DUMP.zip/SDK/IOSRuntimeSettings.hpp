#pragma once

#include <cstdint>

// Object: Enum IOSRuntimeSettings.EIOSMetalShaderStandard
enum class EIOSMetalShaderStandard : uint8_t
{
	IOSMetalSLStandard_1_0 = 0,
	IOSMetalSLStandard_1_1 = 1,
	IOSMetalSLStandard_1_2 = 2,
	IOSMetalSLStandard_2_0 = 3,
	IOSMetalSLStandard_2_1 = 4,
	IOSMetalSLStandard_2_2 = 5,
	IOSMetalSLStandard_2_3 = 6,
	IOSMetalSLStandard_2_4 = 7,
	IOSMetalSLStandard_MAX = 8
};

// Object: Enum IOSRuntimeSettings.EIOSVersion
enum class EIOSVersion : uint8_t
{
	IOS_61 = 6,
	IOS_7 = 7,
	IOS_8 = 8,
	IOS_9 = 9,
	IOS_10 = 10,
	IOS_11 = 11,
	IOS_12 = 12,
	IOS_13 = 13,
	IOS_14 = 14,
	IOS_15 = 15,
	IOS_MAX = 16
};

// Object: Enum IOSRuntimeSettings.EPowerUsageFrameRateLock
enum class EPowerUsageFrameRateLock : uint8_t
{
	PUFRL_None = 0,
	PUFRL_20 = 20,
	PUFRL_30 = 30,
	PUFRL_60 = 60,
	PUFRL_MAX = 61
};

// Object: ScriptStruct IOSRuntimeSettings.IOSBuildResourceDirectory
// Size: 0x10 (Inherited: 0x0)
struct FIOSBuildResourceDirectory
{
	struct FString Path; // 0x0(0x10)
};

// Object: ScriptStruct IOSRuntimeSettings.IOSBuildResourceFilePath
// Size: 0x10 (Inherited: 0x0)
struct FIOSBuildResourceFilePath
{
	struct FString FilePath; // 0x0(0x10)
};

// Object: Class IOSRuntimeSettings.IOSRuntimeSettings
// Size: 0x1A0 (Inherited: 0x28)
struct UIOSRuntimeSettings : UObject
{
	uint8_t bEnableGameCenterSupport : 1; // 0x28(0x1), Mask(0x1)
	uint8_t bEnableCloudKitSupport : 1; // 0x28(0x1), Mask(0x2)
	uint8_t bEnableRemoteNotificationsSupport : 1; // 0x28(0x1), Mask(0x4)
	uint8_t BitPad_0x28_3 : 5; // 0x28(0x1)
	bool bSupportsMetal; // 0x29(0x1)
	bool bSupportsMetalMRT; // 0x2A(0x1)
	bool bCookPVRTCTextures; // 0x2B(0x1)
	bool bCookASTCTextures; // 0x2C(0x1)
	bool bSupportsOpenGLES2; // 0x2D(0x1)
	bool EnableRemoteShaderCompile; // 0x2E(0x1)
	bool bGeneratedSYMFile; // 0x2F(0x1)
	bool bGeneratedSYMBundle; // 0x30(0x1)
	bool bGenerateXCArchive; // 0x31(0x1)
	bool bDevForArmV7; // 0x32(0x1)
	bool bDevForArm64; // 0x33(0x1)
	bool bDevForArmV7S; // 0x34(0x1)
	bool bShipForArmV7; // 0x35(0x1)
	bool bShipForArm64; // 0x36(0x1)
	bool bShipForArmV7S; // 0x37(0x1)
	bool bShipForBitcode; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FString AdditionalLinkerFlags; // 0x40(0x10)
	struct FString AdditionalShippingLinkerFlags; // 0x50(0x10)
	struct FString RemoteServerName; // 0x60(0x10)
	bool bUseRSync; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
	struct FString RSyncUsername; // 0x78(0x10)
	struct FIOSBuildResourceDirectory DeltaCopyInstallPath; // 0x88(0x10)
	struct FString SSHPrivateKeyLocation; // 0x98(0x10)
	struct FIOSBuildResourceFilePath SSHPrivateKeyOverridePath; // 0xA8(0x10)
	bool bTreatRemoteAsSeparateController; // 0xB8(0x1)
	bool bAllowRemoteRotation; // 0xB9(0x1)
	bool bUseRemoteAsVirtualJoystick; // 0xBA(0x1)
	bool bUseRemoteAbsoluteDpadValues; // 0xBB(0x1)
	uint8_t bSupportsPortraitOrientation : 1; // 0xBC(0x1), Mask(0x1)
	uint8_t bSupportsUpsideDownOrientation : 1; // 0xBC(0x1), Mask(0x2)
	uint8_t bSupportsLandscapeLeftOrientation : 1; // 0xBC(0x1), Mask(0x4)
	uint8_t bSupportsLandscapeRightOrientation : 1; // 0xBC(0x1), Mask(0x8)
	uint8_t BitPad_0xBC_4 : 4; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
	struct FString BundleDisplayName; // 0xC0(0x10)
	struct FString BundleName; // 0xD0(0x10)
	struct FString BundleIdentifier; // 0xE0(0x10)
	struct FString VersionInfo; // 0xF0(0x10)
	uint8_t FrameRateLock; // 0x100(0x1)
	uint8_t MinimumiOSVersion; // 0x101(0x1)
	uint8_t bSupportsIPad : 1; // 0x102(0x1), Mask(0x1)
	uint8_t bSupportsIPhone : 1; // 0x102(0x1), Mask(0x2)
	uint8_t BitPad_0x102_2 : 6; // 0x102(0x1)
	uint8_t Pad_0x103[0x5]; // 0x103(0x5)
	struct FString AdditionalPlistData; // 0x108(0x10)
	bool bEnableFacebookSupport; // 0x118(0x1)
	uint8_t Pad_0x119[0x7]; // 0x119(0x7)
	struct FString FacebookAppID; // 0x120(0x10)
	struct FString MobileProvision; // 0x130(0x10)
	struct FString SigningCertificate; // 0x140(0x10)
	bool bAutomaticSigning; // 0x150(0x1)
	uint8_t MaxShaderLanguageVersion; // 0x151(0x1)
	bool UseFastIntrinsics; // 0x152(0x1)
	bool EnableMathOptimisations; // 0x153(0x1)
	bool bUseIntegratedKeyboard; // 0x154(0x1)
	uint8_t Pad_0x155[0x3]; // 0x155(0x3)
	int AudioSampleRate; // 0x158(0x4)
	int AudioCallbackBufferFrameSize; // 0x15C(0x4)
	int AudioNumBuffersToEnqueue; // 0x160(0x4)
	int AudioMaxChannels; // 0x164(0x4)
	int AudioNumSourceWorkers; // 0x168(0x4)
	uint8_t Pad_0x16C[0x4]; // 0x16C(0x4)
	struct FString SpatializationPlugin; // 0x170(0x10)
	struct FString ReverbPlugin; // 0x180(0x10)
	struct FString OcclusionPlugin; // 0x190(0x10)
};

