#pragma once

#include <cstdint>

// Object: Class ImgMedia.ImgMediaSource
// Size: 0x60 (Inherited: 0x38)
struct UImgMediaSource : UBaseMediaSource
{
	float FramesPerSecondOverride; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString ProxyOverride; // 0x40(0x10)
	struct FDirectoryPath SequencePath; // 0x50(0x10)


	// Object: Function ImgMedia.ImgMediaSource.SetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c2503c
	// Params: [ Num(1) Size(0x10) ]
	void SetSequencePath(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C1E5B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C

	// Object: Function ImgMedia.ImgMediaSource.GetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c24fd8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSequencePath();
	// [Call #1] RVA: 0x102C2529C
	// [Call #2] RVA: 0x101F82D88
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102C1E5B0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function ImgMedia.ImgMediaSource.GetProxies
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c24f30
	// Params: [ Num(1) Size(0x10) ]
	void GetProxies(struct TArray<struct FString>& OutProxies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C1E31C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102C2529C
	// [Call #8] RVA: 0x101F82D88
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102C1E5B0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
};

