#pragma once

#include <cstdint>

// Object: Enum PixUIProfiler.EPxProfilerCapability
enum class EPxProfilerCapability : uint8_t
{
	PrintSizeChange = 0,
	PrintCountChange = 1,
	AsyncInnerData = 2,
	Count = 3,
	EPxProfilerCapability_MAX = 4
};

// Object: Class PixUIProfiler.PxProfilerMgr
// Size: 0x28 (Inherited: 0x28)
struct UPxProfilerMgr : UObject
{

	// Object: Function PixUIProfiler.PxProfilerMgr.StartProfiler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940c34
	// Params: [ Num(0) Size(0x0) ]
	void StartProfiler();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PixUIProfiler.PxProfilerMgr.PxProfilerCapabilitySwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940b7c
	// Params: [ Num(2) Size(0x2) ]
	void PxProfilerCapabilitySwitch(uint8_t EPxProfilerCapability, bool bOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1029404F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PixUIProfiler.PxProfilerMgr.Print
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940b68
	// Params: [ Num(0) Size(0x0) ]
	void Print();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1029404F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PixUIProfiler.PxProfilerMgr.GetPxProfilerCapability
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940aec
	// Params: [ Num(2) Size(0x2) ]
	bool GetPxProfilerCapability(uint8_t EPxProfilerCapability);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102940504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1029404F4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function PixUIProfiler.PxProfilerMgr.EndProfiler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940ad8
	// Params: [ Num(0) Size(0x0) ]
	void EndProfiler();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102940504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1029404F4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function PixUIProfiler.PxProfilerMgr.Check
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102940ac4
	// Params: [ Num(0) Size(0x0) ]
	void Check();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102940504
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1029404F4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

