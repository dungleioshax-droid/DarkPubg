#pragma once

#include <cstdint>

// Object: ScriptStruct GameletJsEnv.GameletPropertyMetaRoot
// Size: 0x1 (Inherited: 0x0)
struct FGameletPropertyMetaRoot
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct GameletJsEnv.GameletArrayBuffer
// Size: 0x18 (Inherited: 0x0)
struct FGameletArrayBuffer
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct GameletJsEnv.GameletJsObject
// Size: 0x60 (Inherited: 0x0)
struct FGameletJsObject
{
	uint8_t Pad_0x0[0x60]; // 0x0(0x60)
};

// Object: Class GameletJsEnv.GameletDynamicDelegateProxy
// Size: 0x70 (Inherited: 0x28)
struct UGameletDynamicDelegateProxy : UObject
{
	uint8_t Pad_0x28[0x48]; // 0x28(0x48)


	// Object: Function GameletJsEnv.GameletDynamicDelegateProxy.Fire
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a1ce7c
	// Params: [ Num(0) Size(0x0) ]
	void Fire();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class GameletJsEnv.GameletExtensionMethods
// Size: 0x28 (Inherited: 0x28)
struct UGameletExtensionMethods : UBlueprintFunctionLibrary
{
};

// Object: Class GameletJsEnv.GameletJSGeneratedClass
// Size: 0x4F8 (Inherited: 0x498)
struct UGameletJSGeneratedClass : UBlueprintGeneratedClass
{
	uint8_t Pad_0x498[0x60]; // 0x498(0x60)
};

// Object: Class GameletJsEnv.GameletJSGeneratedFunction
// Size: 0x128 (Inherited: 0xC0)
struct UGameletJSGeneratedFunction : UFunction
{
	uint8_t Pad_0xC0[0x68]; // 0xC0(0x68)
};

// Object: Class GameletJsEnv.GameletJSWidgetGeneratedClass
// Size: 0x568 (Inherited: 0x508)
struct UGameletJSWidgetGeneratedClass : UWidgetBlueprintGeneratedClass
{
	uint8_t Pad_0x508[0x60]; // 0x508(0x60)
};

// Object: Class GameletJsEnv.GameletTypeScriptBlueprint
// Size: 0xD8 (Inherited: 0xD8)
struct UGameletTypeScriptBlueprint : UBlueprint
{
};

// Object: Class GameletJsEnv.GameletTypeScriptGeneratedClass
// Size: 0x550 (Inherited: 0x498)
struct UGameletTypeScriptGeneratedClass : UBlueprintGeneratedClass
{
	uint8_t Pad_0x498[0xB1]; // 0x498(0xB1)
	bool HasConstructor; // 0x549(0x1)
	uint8_t Pad_0x54A[0x6]; // 0x54A(0x6)
};

// Object: Class GameletJsEnv.GameletTypeScriptObject
// Size: 0x28 (Inherited: 0x28)
struct IGameletTypeScriptObject : IInterface
{
};

// Object: GameletJSGeneratedClass GameletJsEnv.Default__GameletJSGeneratedClass
// Size: 0x0 (Inherited: 0x0)
struct Default__GameletJSGeneratedClass
{
};

// Object: GameletJSWidgetGeneratedClass GameletJsEnv.Default__GameletJSWidgetGeneratedClass
// Size: 0x0 (Inherited: 0x0)
struct Default__GameletJSWidgetGeneratedClass
{
};

// Object: GameletTypeScriptGeneratedClass GameletJsEnv.Default__GameletTypeScriptGeneratedClass
// Size: 0x0 (Inherited: 0x0)
struct Default__GameletTypeScriptGeneratedClass
{
};

