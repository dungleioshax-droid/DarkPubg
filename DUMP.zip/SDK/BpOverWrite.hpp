#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass BpOverWrite.BpOverWrite_C
// Size: 0x1F8 (Inherited: 0x1F8)
struct UBpOverWrite_C : UBPClassManager
{
};

