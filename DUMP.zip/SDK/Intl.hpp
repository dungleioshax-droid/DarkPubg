#pragma once

#include <cstdint>

// Object: Class Intl.StatManager
// Size: 0x208 (Inherited: 0x28)
struct UStatManager : UObject
{
	uint8_t Pad_0x28[0x1E0]; // 0x28(0x1E0)


	// Object: Function Intl.StatManager.ReportUAStatsEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bdb6dc
	// Params: [ Num(4) Size(0x71) ]
	void ReportUAStatsEvent(struct TArray<struct FString>& InReportChannels, struct FString InEventName, struct TMap<struct FString, struct FString>& InParams, bool InIsRealTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8676C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BD8FAC
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function Intl.StatManager.ReportRevenue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bdb4e8
	// Params: [ Num(5) Size(0x88) ]
	void ReportRevenue(int InPurchaseEventType, struct FString InCurrencyCode, struct FString InExpense, struct TMap<struct FString, struct FString>& InParams, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8676C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BD87A0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Intl.StatManager.ReportPurchase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bdb378
	// Params: [ Num(4) Size(0x29) ]
	void ReportPurchase(int InPurchaseEventType, struct FString InCurrencyCode, struct FString InExpense, bool isRealTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BD82E0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F8676C
	// [Call #22] RVA: 0x10516D168

	// Object: Function Intl.StatManager.ReportEventWithString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bdb204
	// Params: [ Num(3) Size(0x19) ]
	void ReportEventWithString(int EventType, struct FString _eventBody, bool isRealTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x106BD7D30
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Intl.StatManager.ReportEventWithParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bdb0b4
	// Params: [ Num(3) Size(0x59) ]
	void ReportEventWithParam(int EventType, struct TMap<struct FString, struct FString> _params, bool isRealTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8676C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F87418
	// [Call #9] RVA: 0x106BD72B0
	// [Call #10] RVA: 0x101F87D64
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x101F87D64
	// [Call #13] RVA: 0x101F87D64
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F8122C

	// Object: Function Intl.StatManager.ReportEventWithNoParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bdaff8
	// Params: [ Num(2) Size(0x5) ]
	void ReportEventWithNoParam(int EventType, bool isRealTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BD81C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8676C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F87418
	// [Call #14] RVA: 0x106BD72B0
	// [Call #15] RVA: 0x101F87D64
	// [Call #16] RVA: 0x101F87D64
	// [Call #17] RVA: 0x101F87D64
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function Intl.StatManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106bdafc4
	// Params: [ Num(1) Size(0x8) ]
	struct UStatManager* GetInstance();
	// [Call #1] RVA: 0x106BD6F14
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BD81C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8676C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F87418
	// [Call #15] RVA: 0x106BD72B0
	// [Call #16] RVA: 0x101F87D64
	// [Call #17] RVA: 0x101F87D64
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x101F87D64
	// [Call #20] RVA: 0x106C8459C
};

