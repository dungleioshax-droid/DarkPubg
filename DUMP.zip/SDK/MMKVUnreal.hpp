#pragma once

#include <cstdint>

// Object: Class MMKVUnreal.MMKVObject
// Size: 0x30 (Inherited: 0x28)
struct UMMKVObject : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function MMKVUnreal.MMKVObject.TotalSize
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6cf9c
	// Params: [ Num(1) Size(0x4) ]
	uint32_t TotalSize();
	// [Call #1] RVA: 0x102A67AE8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MMKVUnreal.MMKVObject.SetString
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6cea0
	// Params: [ Num(3) Size(0x21) ]
	bool SetString(struct FString Key, struct FString Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A676A8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102A67AE8
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function MMKVUnreal.MMKVObject.SetInt32
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6cdb8
	// Params: [ Num(3) Size(0x15) ]
	bool SetInt32(struct FString Key, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A6731C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A676A8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x102A67AE8
	// [Call #20] RVA: 0x10519022C

	// Object: Function MMKVUnreal.MMKVObject.SetErrorLogDelegate
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x102a6cd30
	// Params: [ Num(1) Size(0x10) ]
	void SetErrorLogDelegate(DelegateProperty handler);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102A67BA0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A6731C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A676A8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function MMKVUnreal.MMKVObject.SetDouble
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6cc48
	// Params: [ Num(3) Size(0x19) ]
	bool SetDouble(struct FString Key, double Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A67470
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102A67BA0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A6731C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function MMKVUnreal.MMKVObject.SetBuffer
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102a6cb3c
	// Params: [ Num(3) Size(0x21) ]
	bool SetBuffer(struct FString Key, struct TArray<uint8_t>& Buffer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A67054
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102A67470
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x101FD9E48
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function MMKVUnreal.MMKVObject.SetBool
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6ca4c
	// Params: [ Num(3) Size(0x12) ]
	bool SetBool(struct FString Key, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A671D0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A67054
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function MMKVUnreal.MMKVObject.Remove
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6c9b4
	// Params: [ Num(1) Size(0x10) ]
	void Remove(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A6779C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102A671D0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102A67054
	// [Call #20] RVA: 0x101F8BA74

	// Object: DelegateFunction MMKVUnreal.MMKVObject.MMKVLogError__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x14) ]
	void MMKVLogError__DelegateSignature(struct FString MapID, int errorType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function MMKVUnreal.MMKVObject.Init
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6c8c8
	// Params: [ Num(2) Size(0x20) ]
	void Init(struct FString MMapID, struct FString RootPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A66710
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A6779C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x102A671D0
	// [Call #22] RVA: 0x101F8130C

	// Object: Function MMKVUnreal.MMKVObject.GetValueSize
	// Flags: [Final|Native|Public]
	// Offset: 0x102a6c820
	// Params: [ Num(2) Size(0x14) ]
	uint32_t GetValueSize(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A67834
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102A66710
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102A6779C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function MMKVUnreal.MMKVObject.GetString
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c750
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetString(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A67520
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102A67834
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102A66710
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function MMKVUnreal.MMKVObject.GetInt32
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c6a8
	// Params: [ Num(2) Size(0x14) ]
	int GetInt32(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A67278
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A67520
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102A67834
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168

	// Object: Function MMKVUnreal.MMKVObject.GetDouble
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c600
	// Params: [ Num(2) Size(0x18) ]
	double GetDouble(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A673C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A67278
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102A67520
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function MMKVUnreal.MMKVObject.GetBuffer
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c530
	// Params: [ Num(2) Size(0x20) ]
	struct TArray<uint8_t> GetBuffer(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A66F48
	// [Call #4] RVA: 0x1021B8BBC
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102A673C4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102A67278
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function MMKVUnreal.MMKVObject.GetBool
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c488
	// Params: [ Num(2) Size(0x11) ]
	bool GetBool(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A6712C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A66F48
	// [Call #10] RVA: 0x1021B8BBC
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102A673C4
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function MMKVUnreal.MMKVObject.GetAllKeys
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c424
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, bool> GetAllKeys();
	// [Call #1] RVA: 0x102A67978
	// [Call #2] RVA: 0x102A6D5A4
	// [Call #3] RVA: 0x102366FD4
	// [Call #4] RVA: 0x102366FD4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A6712C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102A66F48
	// [Call #15] RVA: 0x1021B8BBC
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x102A673C4

	// Object: Function MMKVUnreal.MMKVObject.ContainsKey
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102a6c37c
	// Params: [ Num(2) Size(0x11) ]
	bool ContainsKey(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A678D8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102A67978
	// [Call #8] RVA: 0x102A6D5A4
	// [Call #9] RVA: 0x102366FD4
	// [Call #10] RVA: 0x102366FD4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102A6712C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102A66F48
	// [Call #21] RVA: 0x1021B8BBC
	// [Call #22] RVA: 0x101F8BA74
	// [Call #23] RVA: 0x101F8130C
};

