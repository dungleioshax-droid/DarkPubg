#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_BigSegmentUpConfig_type.BP_STRUCT_BigSegmentUpConfig_type
// Size: 0x60 (Inherited: 0x0)
struct FBP_STRUCT_BigSegmentUpConfig_type
{
	struct FString HighLevelDeviceAnimPath_0_703E7C0074FB67A670B77DB604C5CFF8; // 0x0(0x10)
	int ID_1_068648C01D06091F1B6E47800634E474; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString VideoPath_4_7CE7A68040FD463430D035E10A0A3E38; // 0x18(0x10)
	struct FString SegmentUpAudioPath_6_3A6BAB4046E51B1B018362F70A65D778; // 0x28(0x10)
	struct FString SettledAudioPath_7_556EFA8033B134C021A93177054ADA98; // 0x38(0x10)
	struct FString SegStarIconPath_8_2A41994011E0ADD57F9C308707C7BD88; // 0x48(0x10)
	int SegmentVideoType_9_53A400806CE06550581E10410DE42165; // 0x58(0x4)
	int TypeID_10_6E417140530ABC6704CD632E05265D34; // 0x5C(0x4)
};

