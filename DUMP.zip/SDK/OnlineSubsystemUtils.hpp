#pragma once

#include <cstdint>

// Object: Enum OnlineSubsystemUtils.EBeaconConnectionState
enum class EBeaconConnectionState : uint8_t
{
	Invalid = 0,
	Closed = 1,
	Pending = 2,
	Open = 3,
	EBeaconConnectionState_MAX = 4
};

// Object: Enum OnlineSubsystemUtils.EClientRequestType
enum class EClientRequestType : uint8_t
{
	NonePending = 0,
	ExistingSessionReservation = 1,
	ReservationUpdate = 2,
	EmptyServerReservation = 3,
	Reconnect = 4,
	Abandon = 5,
	EClientRequestType_MAX = 6
};

// Object: Enum OnlineSubsystemUtils.EPartyReservationResult
enum class EPartyReservationResult : uint8_t
{
	NoResult = 0,
	RequestPending = 1,
	GeneralError = 2,
	PartyLimitReached = 3,
	IncorrectPlayerCount = 4,
	RequestTimedOut = 5,
	ReservationDuplicate = 6,
	ReservationNotFound = 7,
	ReservationAccepted = 8,
	ReservationDenied = 9,
	ReservationDenied_Banned = 10,
	ReservationRequestCanceled = 11,
	ReservationInvalid = 12,
	BadSessionId = 13,
	ReservationDenied_ContainsExistingPlayers = 14,
	EPartyReservationResult_MAX = 15
};

// Object: ScriptStruct OnlineSubsystemUtils.BlueprintSessionResult
// Size: 0xB8 (Inherited: 0x0)
struct FBlueprintSessionResult
{
	uint8_t Pad_0x0[0xB8]; // 0x0(0xB8)
};

// Object: ScriptStruct OnlineSubsystemUtils.PIELoginSettingsInternal
// Size: 0x40 (Inherited: 0x0)
struct FPIELoginSettingsInternal
{
	struct FString ID; // 0x0(0x10)
	struct FString Token; // 0x10(0x10)
	struct FString Type; // 0x20(0x10)
	struct TArray<uint8_t> TokenBytes; // 0x30(0x10)
};

// Object: ScriptStruct OnlineSubsystemUtils.PartyReservation
// Size: 0x30 (Inherited: 0x0)
struct FPartyReservation
{
	int TeamNum; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FUniqueNetIdRepl PartyLeader; // 0x8(0x18)
	struct TArray<struct FPlayerReservation> PartyMembers; // 0x20(0x10)
};

// Object: ScriptStruct OnlineSubsystemUtils.PlayerReservation
// Size: 0x30 (Inherited: 0x0)
struct FPlayerReservation
{
	struct FUniqueNetIdRepl UniqueId; // 0x0(0x18)
	struct FString ValidationStr; // 0x18(0x10)
	float ElapsedTime; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027eb96c
	// Params: [ Num(5) Size(0x20) ]
	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, float& Progress);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027B33B4
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027eb684
	// Params: [ Num(8) Size(0x69) ]
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, struct FText& Title, struct FText& LockedDescription, struct FText& UnlockedDescription, bool& bHidden);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104F0F380
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104F0F380
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104F0F380
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Size: 0x60 (Inherited: 0x28)
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x18]; // 0x48(0x18)


	// Object: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ebdac
	// Params: [ Num(3) Size(0x18) ]
	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B3844
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ebcf8
	// Params: [ Num(3) Size(0x18) ]
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B38EC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027B3844
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
};

// Object: Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Size: 0x78 (Inherited: 0x28)
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x30]; // 0x48(0x30)


	// Object: Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ec050
	// Params: [ Num(6) Size(0x28) ]
	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int UserTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027B3B44
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Size: 0x70 (Inherited: 0x28)
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x28]; // 0x48(0x28)


	// Object: Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ec360
	// Params: [ Num(3) Size(0x18) ]
	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B41C0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x1027EC740
	// [Call #10] RVA: 0x10516D168
};

// Object: Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Size: 0x90 (Inherited: 0x28)
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x48]; // 0x48(0x48)


	// Object: Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ec578
	// Params: [ Num(5) Size(0x20) ]
	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int PublicConnections, bool bUseLAN);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027B4708
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Size: 0x70 (Inherited: 0x28)
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x28]; // 0x48(0x28)


	// Object: Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ec818
	// Params: [ Num(3) Size(0x18) ]
	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B4AE8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x1027ECCF0
	// [Call #10] RVA: 0x10516D168
};

// Object: Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Size: 0x78 (Inherited: 0x28)
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x30]; // 0x48(0x30)


	// Object: Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027eca30
	// Params: [ Num(7) Size(0x40) ]
	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<Class> MatchActor, struct FString MatchID, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x1027B4D58
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
};

// Object: Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Size: 0x70 (Inherited: 0x28)
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x28]; // 0x48(0x28)


	// Object: Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ecdc8
	// Params: [ Num(5) Size(0x38) ]
	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, struct TScriptInterface<Class> TurnBasedMatchInterface);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1027B510C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
};

// Object: Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Size: 0x88 (Inherited: 0x28)
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x40]; // 0x48(0x40)


	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027ed520
	// Params: [ Num(2) Size(0xC8) ]
	struct FString GetServerName(struct FBlueprintSessionResult& Result);
	// [Call #1] RVA: 0x1027D4C4C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027B5B2C
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x1027D234C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x1027D234C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027ed474
	// Params: [ Num(2) Size(0xBC) ]
	int GetPingInMs(struct FBlueprintSessionResult& Result);
	// [Call #1] RVA: 0x1027D4C4C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027B5B24
	// [Call #5] RVA: 0x1027D234C
	// [Call #6] RVA: 0x1027D234C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1027D4C4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027B5B2C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x1027D234C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x1027D234C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027ed3c8
	// Params: [ Num(2) Size(0xBC) ]
	int GetMaxPlayers(struct FBlueprintSessionResult& Result);
	// [Call #1] RVA: 0x1027D4C4C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027B5B90
	// [Call #5] RVA: 0x1027D234C
	// [Call #6] RVA: 0x1027D234C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1027D4C4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027B5B24
	// [Call #12] RVA: 0x1027D234C
	// [Call #13] RVA: 0x1027D234C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1027D4C4C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1027B5B2C
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x1027D234C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x1027D234C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027ed31c
	// Params: [ Num(2) Size(0xBC) ]
	int GetCurrentPlayers(struct FBlueprintSessionResult& Result);
	// [Call #1] RVA: 0x1027D4C4C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027B5B80
	// [Call #5] RVA: 0x1027D234C
	// [Call #6] RVA: 0x1027D234C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1027D4C4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027B5B90
	// [Call #12] RVA: 0x1027D234C
	// [Call #13] RVA: 0x1027D234C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1027D4C4C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1027B5B24
	// [Call #19] RVA: 0x1027D234C
	// [Call #20] RVA: 0x1027D234C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x1027D4C4C
	// [Call #23] RVA: 0x10516D168

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ed1ec
	// Params: [ Num(5) Size(0x20) ]
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int MaxResults, bool bUseLAN);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027B57C8
	// [Call #10] RVA: 0x1027D4C4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1027B5B80
	// [Call #14] RVA: 0x1027D234C
	// [Call #15] RVA: 0x1027D234C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1027D4C4C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1027B5B90
};

// Object: Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Size: 0x80 (Inherited: 0x28)
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x38]; // 0x48(0x38)


	// Object: Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ed8b8
	// Params: [ Num(8) Size(0x38) ]
	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<Class> MatchActor, int MinPlayers, int MaxPlayers, int PlayerGroup, bool ShowExistingMatches);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1027B5D78
	// [Call #16] RVA: 0x10519022C
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy
// Size: 0x80 (Inherited: 0x28)
struct UInAppPurchaseCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x38]; // 0x48(0x38)


	// Object: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027edc5c
	// Params: [ Num(3) Size(0x28) ]
	struct UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest& ProductRequest);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B6C7C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x10519022C
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy
// Size: 0x90 (Inherited: 0x28)
struct UInAppPurchaseQueryCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x48]; // 0x48(0x48)


	// Object: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027edee0
	// Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B72FC
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x10519022C
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy
// Size: 0x90 (Inherited: 0x28)
struct UInAppPurchaseRestoreCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x48]; // 0x48(0x48)


	// Object: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027ee164
	// Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest>& ConsumableProductFlags, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027B79FC
	// [Call #6] RVA: 0x1027F1DCC
	// [Call #7] RVA: 0x1027F1DCC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
};

// Object: Class OnlineSubsystemUtils.IpConnection
// Size: 0x35708 (Inherited: 0x356A0)
struct UIpConnection : UNetConnection
{
	uint8_t Pad_0x356A0[0x68]; // 0x356A0(0x68)
};

// Object: Class OnlineSubsystemUtils.IpNetDriver
// Size: 0xA00 (Inherited: 0x8E8)
struct UIpNetDriver : UNetDriver
{
	uint8_t LogPortUnreach : 1; // 0x8E8(0x1), Mask(0x1)
	uint8_t AllowPlayerPortUnreach : 1; // 0x8E8(0x1), Mask(0x2)
	uint8_t BitPad_0x8E8_2 : 6; // 0x8E8(0x1)
	uint8_t Pad_0x8E9[0x3]; // 0x8E9(0x3)
	uint32_t MaxPortCountToTry; // 0x8EC(0x4)
	uint8_t Pad_0x8F0[0x18]; // 0x8F0(0x18)
	uint32_t ServerDesiredSocketReceiveBufferBytes; // 0x908(0x4)
	uint32_t ServerDesiredSocketSendBufferBytes; // 0x90C(0x4)
	uint32_t ClientDesiredSocketReceiveBufferBytes; // 0x910(0x4)
	uint32_t ClientDesiredSocketSendBufferBytes; // 0x914(0x4)
	uint8_t Pad_0x918[0x60]; // 0x918(0x60)
	float RecreateSocketCooldownTime; // 0x978(0x4)
	float RecreateSocketMaxTryCount; // 0x97C(0x4)
	bool bResolveRemoteHostOnRecreateSocket; // 0x980(0x1)
	bool bContinueProcessWhenReceiveEmptyPackets; // 0x981(0x1)
	bool bContinueProcessWhenConReceiveEmptyPackets; // 0x982(0x1)
	uint8_t Pad_0x983[0x7D]; // 0x983(0x7D)
};

// Object: Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Size: 0x128 (Inherited: 0x28)
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0xE0]; // 0x48(0xE0)


	// Object: Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027ee60c
	// Params: [ Num(4) Size(0xD0) ]
	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult& SearchResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027D4C4C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1027BDCE8
	// [Call #9] RVA: 0x1027D234C
	// [Call #10] RVA: 0x1027D234C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
};

// Object: Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027ee890
	// Params: [ Num(4) Size(0x15) ]
	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int StatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1027BE068
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Size: 0x68 (Inherited: 0x28)
struct ULeaderboardFlushCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x20]; // 0x48(0x20)


	// Object: Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027eeb30
	// Params: [ Num(3) Size(0x18) ]
	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027BE4C8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x1027EEEC4
};

// Object: Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Size: 0x98 (Inherited: 0x28)
struct ULeaderboardQueryCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x50]; // 0x48(0x50)


	// Object: Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027eed84
	// Params: [ Num(3) Size(0x18) ]
	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027BED14
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x1027EF118
};

// Object: Class OnlineSubsystemUtils.LogoutCallbackProxy
// Size: 0x60 (Inherited: 0x28)
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x18]; // 0x48(0x18)


	// Object: Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027eefd8
	// Params: [ Num(3) Size(0x18) ]
	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027BEE08
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105190870
};

// Object: Class OnlineSubsystemUtils.OnlineBeacon
// Size: 0x4D8 (Inherited: 0x4B0)
struct AOnlineBeacon : AActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	float BeaconConnectionInitialTimeout; // 0x4B8(0x4)
	float BeaconConnectionTimeout; // 0x4BC(0x4)
	struct UNetDriver* NetDriver; // 0x4C0(0x8)
	uint8_t Pad_0x4C8[0x10]; // 0x4C8(0x10)
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconClient
// Size: 0x518 (Inherited: 0x4D8)
struct AOnlineBeaconClient : AOnlineBeacon
{
	struct AOnlineBeaconHostObject* BeaconOwner; // 0x4D8(0x8)
	struct UNetConnection* BeaconConnection; // 0x4E0(0x8)
	uint8_t ConnectionState; // 0x4E8(0x1)
	uint8_t Pad_0x4E9[0x2F]; // 0x4E9(0x2F)


	// Object: Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient]
	// Offset: 0x1027ef3b8
	// Params: [ Num(0) Size(0x0) ]
	void ClientOnConnected();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconHost
// Size: 0x590 (Inherited: 0x4D8)
struct AOnlineBeaconHost : AOnlineBeacon
{
	int ListenPort; // 0x4D8(0x4)
	uint8_t Pad_0x4DC[0x4]; // 0x4DC(0x4)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x4E0(0x10)
	uint8_t Pad_0x4F0[0xA0]; // 0x4F0(0xA0)
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Size: 0x4D8 (Inherited: 0x4B0)
struct AOnlineBeaconHostObject : AActor
{
	struct FString BeaconTypeName; // 0x4B0(0x10)
	struct AOnlineBeaconClient* ClientBeaconActorClass; // 0x4C0(0x8)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x4C8(0x10)
};

// Object: Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Size: 0x130 (Inherited: 0x28)
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface
{
	struct FName VoiceSubsystemNameOverride; // 0x28(0x8)
	uint8_t Pad_0x30[0x100]; // 0x30(0x100)
};

// Object: Class OnlineSubsystemUtils.OnlinePIESettings
// Size: 0x50 (Inherited: 0x38)
struct UOnlinePIESettings : UDeveloperSettings
{
	bool bOnlinePIEEnabled; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct TArray<struct FPIELoginSettingsInternal> Logins; // 0x40(0x10)
};

// Object: Class OnlineSubsystemUtils.OnlineSessionClient
// Size: 0x190 (Inherited: 0x28)
struct UOnlineSessionClient : UOnlineSession
{
	uint8_t Pad_0x28[0x160]; // 0x28(0x160)
	bool bIsFromInvite; // 0x188(0x1)
	bool bHandlingDisconnect; // 0x189(0x1)
	uint8_t Pad_0x18A[0x6]; // 0x18A(0x6)
};

// Object: Class OnlineSubsystemUtils.PartyBeaconClient
// Size: 0x5B8 (Inherited: 0x518)
struct APartyBeaconClient : AOnlineBeaconClient
{
	uint8_t Pad_0x518[0x30]; // 0x518(0x30)
	struct FString DestSessionId; // 0x548(0x10)
	struct FPartyReservation PendingReservation; // 0x558(0x30)
	uint8_t RequestType; // 0x588(0x1)
	bool bPendingReservationSent; // 0x589(0x1)
	bool bCancelReservation; // 0x58A(0x1)
	uint8_t Pad_0x58B[0x2D]; // 0x58B(0x2D)


	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1027f0264
	// Params: [ Num(2) Size(0x40) ]
	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027D5A64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x1027D5A64
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x1051903D0
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1027f0158
	// Params: [ Num(2) Size(0x40) ]
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027D5A64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x1027D5A64
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1027D5A64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x1027D5A64
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1027f00ac
	// Params: [ Num(1) Size(0x18) ]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1021C3E14
	// [Call #4] RVA: 0x1021C3E14
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027D5A64
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x1027D5A64
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1027f0028
	// Params: [ Num(1) Size(0x4) ]
	void ClientSendReservationUpdates(int NumRemainingReservations);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021C3E14
	// [Call #6] RVA: 0x1021C3E14
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1027D5A64
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x1027D5A64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1027f000c
	// Params: [ Num(0) Size(0x0) ]
	void ClientSendReservationFull();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1021C3E14
	// [Call #6] RVA: 0x1021C3E14
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1027D5A64
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x1027D5A64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1027eff88
	// Params: [ Num(1) Size(0x1) ]
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1021C3E14
	// [Call #8] RVA: 0x1021C3E14
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1027eff04
	// Params: [ Num(1) Size(0x1) ]
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1021C3E14
	// [Call #10] RVA: 0x1021C3E14
	// [Call #11] RVA: 0x106C8459C
};

// Object: Class OnlineSubsystemUtils.PartyBeaconHost
// Size: 0x540 (Inherited: 0x4D8)
struct APartyBeaconHost : AOnlineBeaconHostObject
{
	struct UPartyBeaconState* State; // 0x4D8(0x8)
	uint8_t Pad_0x4E0[0x50]; // 0x4E0(0x50)
	bool bLogoutOnSessionTimeout; // 0x530(0x1)
	uint8_t Pad_0x531[0x3]; // 0x531(0x3)
	float SessionTimeoutSecs; // 0x534(0x4)
	float TravelSessionTimeoutSecs; // 0x538(0x4)
	uint8_t Pad_0x53C[0x4]; // 0x53C(0x4)
};

// Object: Class OnlineSubsystemUtils.PartyBeaconState
// Size: 0x70 (Inherited: 0x28)
struct UPartyBeaconState : UObject
{
	struct FName SessionName; // 0x28(0x8)
	int NumConsumedReservations; // 0x30(0x4)
	int MaxReservations; // 0x34(0x4)
	int NumTeams; // 0x38(0x4)
	int NumPlayersPerTeam; // 0x3C(0x4)
	struct FName TeamAssignmentMethod; // 0x40(0x8)
	int ReservedHostTeamNum; // 0x48(0x4)
	int ForceTeamNum; // 0x4C(0x4)
	struct TArray<struct FPartyReservation> Reservations; // 0x50(0x10)
	uint8_t Pad_0x60[0x10]; // 0x60(0x10)
};

// Object: Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Size: 0x70 (Inherited: 0x28)
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x28]; // 0x48(0x28)


	// Object: Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027f0aa4
	// Params: [ Num(6) Size(0x30) ]
	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, enum class EMPMatchOutcome Outcome, int TurnTimeoutInSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1027CF730
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C
};

// Object: Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Size: 0x58 (Inherited: 0x28)
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnSuccess; // 0x28(0x10)
	struct FScriptMulticastDelegate OnFailure; // 0x38(0x10)
	uint8_t Pad_0x48[0x10]; // 0x48(0x10)


	// Object: Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027f0df4
	// Params: [ Num(3) Size(0x18) ]
	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027CFB08
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10516EACC
	// [Call #10] RVA: 0x10516EACC
};

// Object: Class OnlineSubsystemUtils.TestBeaconClient
// Size: 0x518 (Inherited: 0x518)
struct ATestBeaconClient : AOnlineBeaconClient
{

	// Object: Function OnlineSubsystemUtils.TestBeaconClient.ServerPong
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1027f10a0
	// Params: [ Num(0) Size(0x0) ]
	void ServerPong();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function OnlineSubsystemUtils.TestBeaconClient.ClientPing
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1027f1084
	// Params: [ Num(0) Size(0x0) ]
	void ClientPing();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
};

// Object: Class OnlineSubsystemUtils.TestBeaconHost
// Size: 0x4D8 (Inherited: 0x4D8)
struct ATestBeaconHost : AOnlineBeaconHostObject
{
};

// Object: Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027f18d4
	// Params: [ Num(3) Size(0x18) ]
	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1027E2774
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027f16d0
	// Params: [ Num(5) Size(0x38) ]
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int playerIndex, struct FString& PlayerDisplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1027E2830
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027f151c
	// Params: [ Num(4) Size(0x24) ]
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int& playerIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1027E25A0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027f1368
	// Params: [ Num(4) Size(0x21) ]
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, bool& bIsMyTurn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1027E23B4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
};

