#pragma once

#include <cstdint>

// Object: Enum AI.EAISoundCollectType
enum class EAISoundCollectType : uint8_t
{
	AISoundCollectType_Step = 1,
	AISoundCollectType_Weapon = 2,
	AISoundCollectType_Vehicle = 3,
	AISoundCollectType_Horn = 4,
	AISoundCollectType_Grenade = 5,
	AISoundCollectType_MAX = 6
};

// Object: Enum AI.EObstacleDetectionSpace
enum class EObstacleDetectionSpace : uint8_t
{
	ObstacleDetection_Box = 0,
	ObstacleDetection_CapsuleSweep = 1,
	ObstacleDetection_MAX = 2
};

// Object: Enum AI.EAICheckFlyingStatusType
enum class EAICheckFlyingStatusType : uint8_t
{
	FlyingStatus_HasNavigationSystem = 0,
	FlyingStatus_NavigationVoxelDataDone = 1,
	FlyingStatus_MAX = 2
};

// Object: Enum AI.EAIOcclusionPointPoseType
enum class EAIOcclusionPointPoseType : uint8_t
{
	Occlusion_PoseProne = 1,
	Occlusion_PoseCrouch = 2,
	Occlusion_PoseStand = 4,
	Occlusion_PoseBush = 8,
	Occlusion_MAX = 9
};

// Object: Enum AI.EAICheckShootingPoseType
enum class EAICheckShootingPoseType : uint8_t
{
	ShootingPose_Normal = 0,
	ShootingPose_Stand = 1,
	ShootingPose_Peek = 2,
	ShootingPose_WaitVisibilityCheck = 254,
	ShootingPose_MAX = 255
};

// Object: Enum AI.EDistanceCheckType
enum class EDistanceCheckType : uint8_t
{
	FixedDistance = 0,
	BlackboardKey = 1,
	ApplySensedRadius = 2,
	EDistanceCheckType_MAX = 3
};

// Object: Enum AI.ECompareLengthType
enum class ECompareLengthType : uint8_t
{
	ELengthGreater = 0,
	ELengthLess = 1,
	ELengthEequal = 2,
	ECompareLengthType_MAX = 3
};

// Object: Enum AI.EAIDecoratorGeneralLineTraceType
enum class EAIDecoratorGeneralLineTraceType : uint8_t
{
	LineTraceType_Forward = 0,
	LineTraceType_MAX = 1
};

// Object: Enum AI.EInSafetyCircleType
enum class EInSafetyCircleType : uint8_t
{
	EInSafetyCircleType_None = 0,
	EInSafetyCircleType_BlueCircle = 1,
	EInSafetyCircleType_WhiteCircle = 2,
	EInSafetyCircleType_MAX = 3
};

// Object: Enum AI.EItemNumCheckType
enum class EItemNumCheckType : uint8_t
{
	ItemNumGreater = 0,
	ItemNumLess = 1,
	ItemNumEequal = 2,
	EItemNumCheckType_MAX = 3
};

// Object: Enum AI.EMobHasAIStateLogic
enum class EMobHasAIStateLogic : uint8_t
{
	Any = 0,
	All = 1,
	None = 2,
	EMobHasAIStateLogic_MAX = 3
};

// Object: Enum AI.EChooseEnemySearchMethod
enum class EChooseEnemySearchMethod : uint16_t
{
	SearchMethod_Nearest = 0,
	SearchMethod_MostHP = 1,
	SearchMethod_LeastHP = 2,
	SearchMethod_ByBlackboardValue = 255,
	SearchMethod_MAX = 256
};

// Object: Enum AI.EChooseEnemyType
enum class EChooseEnemyType : uint8_t
{
	EnemyType_Player = 0,
	EnemyType_Animal = 1,
	EnemyType_Zombie = 2,
	EnemyType_UAV = 3,
	EnemyType_MAX = 4
};

// Object: Enum AI.EAISearchTeammateType
enum class EAISearchTeammateType : uint8_t
{
	Nearest = 1,
	LeastHP = 2,
	EAISearchTeammateType_MAX = 3
};

// Object: Enum AI.EMobAddHPServiceType
enum class EMobAddHPServiceType : uint8_t
{
	LoseTarget = 0,
	EMobAddHPServiceType_MAX = 1
};

// Object: Enum AI.EAISearchEnemyType
enum class EAISearchEnemyType : uint8_t
{
	Nearest = 1,
	Random = 2,
	Farthest = 3,
	EAISearchEnemyType_MAX = 4
};

// Object: Enum AI.EAISearchEnemyRule
enum class EAISearchEnemyRule : uint16_t
{
	SingleRule_Hatred = 1,
	SingleRule_Random = 2,
	SingleRule_Nearest = 3,
	SingleRule_Farthest = 4,
	SingleRule_MostHP = 5,
	SingleRule_PoorHP = 6,
	SingleRule_BlackboardValue = 255,
	SingleRule_MAX = 256
};

// Object: Enum AI.EAISearchEnemyEntityType
enum class EAISearchEnemyEntityType : uint8_t
{
	PlayerOnly = 1,
	PlayerAndMob = 2,
	EAISearchEnemyEntityType_MAX = 3
};

// Object: Enum AI.EAISearchEnemySingleRule
enum class EAISearchEnemySingleRule : uint16_t
{
	SingleRule_Hatred = 1,
	SingleRule_Random = 2,
	SingleRule_Nearest = 3,
	SingleRule_Farthest = 4,
	SingleRule_MostHP = 5,
	SingleRule_PoorHP = 6,
	SingleRule_BlackboardValue = 255,
	SingleRule_MAX = 256
};

// Object: Enum AI.EAISenseGrenadeType
enum class EAISenseGrenadeType : uint8_t
{
	ExplosionGrenade = 0,
	BurningGrenade = 1,
	SmokingGrenade = 2,
	FlashBomb = 3,
	Grenade_MaxNum = 4,
	EAISenseGrenadeType_MAX = 5
};

// Object: Enum AI.ETargetAngleCheck
enum class ETargetAngleCheck : uint8_t
{
	TargetAngleCheckFocus = 0,
	TargetAngleCheckFocusFail = 1,
	TargetAngleCheckFocusSuccess = 2,
	ETargetAngleCheck_MAX = 3
};

// Object: Enum AI.EVHQueryEnemyRule
enum class EVHQueryEnemyRule : uint8_t
{
	Nearest = 1,
	Random = 2,
	EVHQueryEnemyRule_MAX = 3
};

// Object: Enum AI.EVHEnemyType
enum class EVHEnemyType : uint8_t
{
	EVHEnemyType_Player = 0,
	EVHEnemyType_Car = 1,
	EVHEnemyType_Mob = 2,
	EVHEnemyType_FakePlayer = 3,
	EVHEnemyType_MAX = 4
};

// Object: Enum AI.EAIAdvFindOcclusionPointSearchBestOcclusionMethod
enum class EAIAdvFindOcclusionPointSearchBestOcclusionMethod : uint8_t
{
	Method_Normal = 0,
	Method_NearToTarget = 2,
	Method_FarToTarget = 3,
	Method_NearToSelf = 4,
	Method_RandomOfSelf = 5,
	Method_MAX = 6
};

// Object: Enum AI.EAIAdvFindOcclusionPointPoseType
enum class EAIAdvFindOcclusionPointPoseType : uint8_t
{
	Occlusion_PoseProne = 1,
	Occlusion_PoseCrouch = 2,
	Occlusion_PoseStand = 4,
	Occlusion_PoseBush = 8,
	Occlusion_MAX = 9
};

// Object: Enum AI.EBioVHMoveType
enum class EBioVHMoveType : uint8_t
{
	EMoveType_Normal = 0,
	EMoveType_Backward = 1,
	EMoveType_Directly = 2,
	EMoveType_MAX = 3
};

// Object: Enum AI.EFindFlyingHoverPointOneSideShapeOType
enum class EFindFlyingHoverPointOneSideShapeOType : uint8_t
{
	OT_RandomSide = 0,
	OT_LeftSide = 1,
	OT_RightSide = 2,
	OT_MAX = 3
};

// Object: Enum AI.EFindFlyingHoverPointHoverType
enum class EFindFlyingHoverPointHoverType : uint8_t
{
	HT_OneSideShapeO = 0,
	HT_MAX = 1
};

// Object: Enum AI.EFlyToPathfindingThread
enum class EFlyToPathfindingThread : uint8_t
{
	Sync = 0,
	ASync = 1,
	EFlyToPathfindingThread_MAX = 2
};

// Object: Enum AI.EMobFindAttackablePositionLineTraceType
enum class EMobFindAttackablePositionLineTraceType : uint8_t
{
	Normal = 0,
	HalfHeightOffset = 1,
	CustomHeightOffset = 2,
	EMobFindAttackablePositionLineTraceType_MAX = 3
};

// Object: Enum AI.ESearchType
enum class ESearchType : uint8_t
{
	CenterInSelfLocation = 0,
	CenterInSpecificLocation = 1,
	ESearchType_MAX = 2
};

// Object: Enum AI.EAIMoveToOcclusionFinishMovePoseType
enum class EAIMoveToOcclusionFinishMovePoseType : uint8_t
{
	FinishMovePoseType_Normal = 0,
	FinishMovePoseType_CrouchIfACrouchOcclusion = 1,
	FinishMovePoseType_MAX = 2
};

// Object: Enum AI.EAIMoveToOcclusionMovingPoseType
enum class EAIMoveToOcclusionMovingPoseType : uint8_t
{
	MovingPoseType_Normal = 0,
	MovingPoseType_CrouchSprintIfAlreadyCrouched = 1,
	MovingPoseType_MAX = 2
};

// Object: Enum AI.EAIMoveToOcclusionSearchBestOcclusionMethod
enum class EAIMoveToOcclusionSearchBestOcclusionMethod : uint8_t
{
	Normal = 0,
	NearToTarget = 2,
	FarToTarget = 3,
	NearToSelf = 4,
	RandomOfSelf = 5,
	EAIMoveToOcclusionSearchBestOcclusionMethod_MAX = 6
};

// Object: Enum AI.EAIMoveToOcclusionPoseType
enum class EAIMoveToOcclusionPoseType : uint8_t
{
	PoseProne = 1,
	PoseCrouch = 2,
	PoseStand = 4,
	PoseBush = 8,
	EAIMoveToOcclusionPoseType_MAX = 9
};

// Object: Enum AI.ESeekFlyPointHorizontalAngleType
enum class ESeekFlyPointHorizontalAngleType : uint8_t
{
	TargetView = 0,
	TargetToSelf = 1,
	BornLocationView = 2,
	ESeekFlyPointHorizontalAngleType_MAX = 3
};

// Object: Enum AI.ESeekFlyPointCenterLocType
enum class ESeekFlyPointCenterLocType : uint8_t
{
	Target = 0,
	Self = 1,
	BornLocation = 2,
	ESeekFlyPointCenterLocType_MAX = 3
};

// Object: Enum AI.ELocateType
enum class ELocateType : uint8_t
{
	ELocateType_Random = 0,
	ELocateType_Strategy = 1,
	ELocateType_Escape = 2,
	ELocateType_MAX = 3
};

// Object: Enum AI.EAIVHMoveType
enum class EAIVHMoveType : uint8_t
{
	ELocateType_Normal = 0,
	ELocateType_Strategy = 1,
	ELocateType_Directly = 2,
	ELocateType_Toward = 3,
	ELocateType_MAX = 4
};

// Object: Enum AI.EAITaskNodeThrowGrenadeMethod
enum class EAITaskNodeThrowGrenadeMethod : uint8_t
{
	ThrowGrenadeMethod_Normal = 0,
	ThrowGrenadeMethod_Advanced = 1,
	ThrowGrenadeMethod_MAX = 2
};

// Object: Enum AI.ECustomDamageEventReactionType
enum class ECustomDamageEventReactionType : uint8_t
{
	SpawnActor = 0,
	ActiveParticles = 1,
	DetactiveParticles = 2,
	HideMesh = 3,
	HideMeshInstance = 4,
	HideBone = 5,
	ApplyPhysicalAnimationProfile = 6,
	SetCollisionEnabled = 7,
	ECustomDamageEventReactionType_MAX = 8
};

// Object: Enum AI.ECustomDamageEventTriggerType
enum class ECustomDamageEventTriggerType : uint8_t
{
	OnPassedDamageThreshold = 0,
	OnAnyDamage = 1,
	ECustomDamageEventTriggerType_MAX = 2
};

// Object: Enum AI.EAIProviderType
enum class EAIProviderType : uint8_t
{
	Type_None = 0,
	Type_TEG = 1,
	Type_CCS = 2,
	Type_MAX = 3
};

// Object: Enum AI.EMLBotType
enum class EMLBotType : uint8_t
{
	BT = 0,
	MLAI = 1,
	MLDelivery = 2,
	MLTeammate = 3,
	MLHumanoid = 5,
	EMLBotType_MAX = 6
};

// Object: Enum AI.EMLAIJumpingPhase
enum class EMLAIJumpingPhase : uint8_t
{
	Before = 0,
	FreeFalling = 1,
	OpenParachute = 2,
	Landing = 3,
	EMLAIJumpingPhase_MAX = 4
};

// Object: Enum AI.EDiffListIDTag
enum class EDiffListIDTag : uint8_t
{
	NoDiff = 0,
	General = 1,
	GeneralDiff = 2,
	EDiffListIDTag_MAX = 3
};

// Object: Enum AI.EStatePlayerType
enum class EStatePlayerType : uint8_t
{
	None = 0,
	MLAI_Normal = 1,
	MLAI_Deliver = 2,
	BTAI = 3,
	Player = 4,
	MLAI_Teammate = 5,
	CandidateBTAI = 6,
	CandidateMLAI = 7,
	Player_Teammate = 8,
	MLAI_Humanoid = 9,
	MLAI_Mercenary = 10,
	EStatePlayerType_MAX = 11
};

// Object: Enum AI.ENearItemType
enum class ENearItemType : uint8_t
{
	Box = 0,
	Item = 1,
	AirDropBox = 2,
	TreasureChest = 3,
	Weed = 4,
	ENearItemType_MAX = 5
};

// Object: Enum AI.ESpecialZoneType
enum class ESpecialZoneType : uint8_t
{
	Normal = 0,
	Character = 1,
	DamageableActor = 2,
	Vehicle = 3,
	ESpecialZoneType_MAX = 4
};

// Object: Enum AI.EVehicleSpecialState
enum class EVehicleSpecialState : uint8_t
{
	BeCatched = 0,
	HoverVHMagnetStatus = 1,
	HasNitroBoostAbility = 2,
	IsNitroBoosting = 3,
	CanNitroBoost = 4,
	EVehicleSpecialState_MAX = 5
};

// Object: ScriptStruct AI.ActionMoveData
// Size: 0x10 (Inherited: 0x0)
struct FActionMoveData
{
	bool IsStop; // 0x0(0x1)
	bool IsRun; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	float DirectionX; // 0x4(0x4)
	float DirectionY; // 0x8(0x4)
	float DirectionZ; // 0xC(0x4)
};

// Object: ScriptStruct AI.CacheNearbyItemState
// Size: 0x20 (Inherited: 0x0)
struct FCacheNearbyItemState
{
	struct TArray<struct FItemStateData> States; // 0x0(0x10)
	struct FVector Position; // 0x10(0xC)
	bool IsDirty; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
};

// Object: ScriptStruct AI.AIStateInfoBase
// Size: 0x18 (Inherited: 0x0)
struct FAIStateInfoBase
{
	uint64_t UnChanged; // 0x0(0x8)
	struct TArray<struct FString> IgnoreNames; // 0x8(0x10)
};

// Object: ScriptStruct AI.UniqueStateInfo
// Size: 0x20 (Inherited: 0x18)
struct FUniqueStateInfo : FAIStateInfoBase
{
	uint64_t diff_mark_id; // 0x18(0x8)
};

// Object: ScriptStruct AI.ItemStateData
// Size: 0x50 (Inherited: 0x20)
struct FItemStateData : FUniqueStateInfo
{
	int Type; // 0x20(0x4)
	int Category; // 0x24(0x4)
	int ID; // 0x28(0x4)
	int UID; // 0x2C(0x4)
	float Durability; // 0x30(0x4)
	struct FAIStateXYZ Position; // 0x34(0xC)
	uint32_t player_id; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	uint64_t unique_id; // 0x48(0x8)
};

// Object: ScriptStruct AI.AIStateXYZ
// Size: 0xC (Inherited: 0x0)
struct FAIStateXYZ
{
	float X; // 0x0(0x4)
	float Y; // 0x4(0x4)
	float Z; // 0x8(0x4)
};

// Object: ScriptStruct AI.ChildDynamicItem
// Size: 0x20 (Inherited: 0x0)
struct FChildDynamicItem
{
	int Category; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString ChildName; // 0x8(0x10)
	uint8_t Pad_0x18[0x8]; // 0x18(0x8)
};

// Object: ScriptStruct AI.CacheSoundState
// Size: 0x38 (Inherited: 0x0)
struct FCacheSoundState
{
	struct FSoundState SoundState; // 0x0(0x30)
	float Time; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct AI.SoundState
// Size: 0x30 (Inherited: 0x18)
struct FSoundState : FAIStateInfoBase
{
	int Type; // 0x18(0x4)
	struct FAIStateXYZ Location; // 0x1C(0xC)
	uint32_t ID; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.AIVehicleStateData
// Size: 0x80 (Inherited: 0x0)
struct FAIVehicleStateData
{
	uint8_t Pad_0x0[0x80]; // 0x0(0x80)
};

// Object: ScriptStruct AI.AIVehicleHatredInfo
// Size: 0xC (Inherited: 0x0)
struct FAIVehicleHatredInfo
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct AI.BTTaskMobOnceMemory
// Size: 0x4 (Inherited: 0x0)
struct FBTTaskMobOnceMemory
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
};

// Object: ScriptStruct AI.ShootingAimConfigContainer
// Size: 0x50 (Inherited: 0x0)
struct FShootingAimConfigContainer
{
	struct TMap<float, struct FShootingAimConfig> AimConfig; // 0x0(0x50)
};

// Object: ScriptStruct AI.ShootingAimConfig
// Size: 0x14 (Inherited: 0x0)
struct FShootingAimConfig
{
	uint8_t WeaponShotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float AimDeviationScale; // 0x4(0x4)
	float MinAimDeviationScale; // 0x8(0x4)
	struct FVector2D RandomShootFreqRange; // 0xC(0x8)
};

// Object: ScriptStruct AI.DifficultyShootingConfig
// Size: 0x10 (Inherited: 0x0)
struct FDifficultyShootingConfig
{
	uint8_t WeaponShotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float DeviationScale; // 0x4(0x4)
	struct FVector2D RandomShootFreqRange; // 0x8(0x8)
};

// Object: ScriptStruct AI.BTAICheckInAIBehaviorRegionMemory
// Size: 0x2C (Inherited: 0x0)
struct FBTAICheckInAIBehaviorRegionMemory
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	struct FVector SpawnLocation; // 0x4(0xC)
	struct FBox MaxMoveDistanceVolumeBox; // 0x10(0x1C)
};

// Object: ScriptStruct AI.BTAICheckMaxDistanceFromSpawnPointMemory
// Size: 0x2C (Inherited: 0x0)
struct FBTAICheckMaxDistanceFromSpawnPointMemory
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	struct FVector SpawnLocation; // 0x4(0xC)
	struct FBox MaxMoveDistanceVolumeBox; // 0x10(0x1C)
};

// Object: ScriptStruct AI.WeatherToRange
// Size: 0x10 (Inherited: 0x0)
struct FWeatherToRange
{
	struct TArray<struct FWeaponTypeToRange> Ranges; // 0x0(0x10)
};

// Object: ScriptStruct AI.WeaponTypeToRange
// Size: 0x8 (Inherited: 0x0)
struct FWeaponTypeToRange
{
	enum class EWeaponTypeNew WeaponType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float Range; // 0x4(0x4)
};

// Object: ScriptStruct AI.WeaponType2Range
// Size: 0xC (Inherited: 0x0)
struct FWeaponType2Range
{
	enum class EWeaponTypeNew WeaponType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float Range; // 0x4(0x4)
	float NightRange; // 0x8(0x4)
};

// Object: ScriptStruct AI.WeaponTypeToRangeWithPawnState
// Size: 0x58 (Inherited: 0x0)
struct FWeaponTypeToRangeWithPawnState
{
	enum class EWeaponTypeNew WeaponType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TMap<uint8_t, struct FShapeRangeParam> StateRange; // 0x8(0x50)
};

// Object: ScriptStruct AI.ShapeRangeParam
// Size: 0xC (Inherited: 0x0)
struct FShapeRangeParam
{
	float CircleR; // 0x0(0x4)
	float SectorR; // 0x4(0x4)
	float SectorDegree; // 0x8(0x4)
};

// Object: ScriptStruct AI.SightFanInfo
// Size: 0x8 (Inherited: 0x0)
struct FSightFanInfo
{
	float Radius; // 0x0(0x4)
	float Angle; // 0x4(0x4)
};

// Object: ScriptStruct AI.InTroubleTeleportConfig
// Size: 0x10 (Inherited: 0x0)
struct FInTroubleTeleportConfig
{
	float SrcCheckRadius; // 0x0(0x4)
	float DstCheckRadius; // 0x4(0x4)
	uint32_t TryFindDstLocNum; // 0x8(0x4)
	bool OnlyTeleportToLand; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct AI.AIDistantJudgeNoftify
// Size: 0x30 (Inherited: 0x0)
struct FAIDistantJudgeNoftify
{
	float RightValue; // 0x0(0x4)
	int SetBBValue; // 0x4(0x4)
	struct FBlackboardKeySelector NotifyBlackBoardKey; // 0x8(0x28)
};

// Object: ScriptStruct AI.BTFlyingChooseEnemyMemory
// Size: 0xC (Inherited: 0x0)
struct FBTFlyingChooseEnemyMemory
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct AI.BTMobAddHpMemory
// Size: 0x1 (Inherited: 0x0)
struct FBTMobAddHpMemory
{
	bool HPBuffAdded; // 0x0(0x1)
};

// Object: ScriptStruct AI.BTMobCheckLoseTargetMemory
// Size: 0x8 (Inherited: 0x0)
struct FBTMobCheckLoseTargetMemory
{
	bool LastLoseTarget; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float LoseTargetElapsedTime; // 0x4(0x4)
};

// Object: ScriptStruct AI.BTMobHearingMemory
// Size: 0x28 (Inherited: 0x0)
struct FBTMobHearingMemory
{
	struct FNoiseInfo LastChosenNoiseInfo; // 0x0(0x24)
	float LockNoiseElapsedTime; // 0x24(0x4)
};

// Object: ScriptStruct AI.BTMobMoveBlockTimerMemory
// Size: 0x4 (Inherited: 0x0)
struct FBTMobMoveBlockTimerMemory
{
	float BlockElapsedTime; // 0x0(0x4)
};

// Object: ScriptStruct AI.BTAISenseGrenadeMemory
// Size: 0x260 (Inherited: 0x0)
struct FBTAISenseGrenadeMemory
{
	struct TMap<uint8_t, float> GrenadeSensedDistance; // 0x0(0x50)
	struct TMap<uint8_t, float> GrenadeSensedDistanceSquared; // 0x50(0x50)
	float fMaxSenseDistance; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x11C]; // 0xA4(0x11C)
	struct TMap<uint8_t, struct FAISenseGrenadeBBKeyInfo> GrenadeBBKeyInfo; // 0x1C0(0x50)
	struct TMap<struct UObject*, uint8_t> GrenadeClassesMap; // 0x210(0x50)
};

// Object: ScriptStruct AI.AISenseGrenadeBBKeyInfo
// Size: 0x30 (Inherited: 0x0)
struct FAISenseGrenadeBBKeyInfo
{
	uint8_t GrenadeType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FBlackboardKeySelector BBKeyGrenadeActor; // 0x8(0x28)
};

// Object: ScriptStruct AI.BPAISenseGrenadeDistanceConfig
// Size: 0x8 (Inherited: 0x0)
struct FBPAISenseGrenadeDistanceConfig
{
	uint8_t GrenadeType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float GrenadeSenseDistance; // 0x4(0x4)
};

// Object: ScriptStruct AI.AISenseGrenadeClassConfig
// Size: 0x10 (Inherited: 0x0)
struct FAISenseGrenadeClassConfig
{
	struct TArray<struct UObject*> IncludeClassArray; // 0x0(0x10)
};

// Object: ScriptStruct AI.TaskAddItem
// Size: 0x8 (Inherited: 0x0)
struct FTaskAddItem
{
	int ItemId; // 0x0(0x4)
	int ItemCount; // 0x4(0x4)
};

// Object: ScriptStruct AI.DifficultyTimeConfig
// Size: 0x8 (Inherited: 0x0)
struct FDifficultyTimeConfig
{
	float WaitTime; // 0x0(0x4)
	float RandomDeviation; // 0x4(0x4)
};

// Object: ScriptStruct AI.BTTaskCrowdMoveMemory
// Size: 0x78 (Inherited: 0x0)
struct FBTTaskCrowdMoveMemory
{
	uint8_t Pad_0x0[0x78]; // 0x0(0x78)
};

// Object: ScriptStruct AI.BTTaskFlyAlongSplineMemory
// Size: 0x1C (Inherited: 0x0)
struct FBTTaskFlyAlongSplineMemory
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
};

// Object: ScriptStruct AI.BTTaskForceIdleMemory
// Size: 0xC (Inherited: 0x0)
struct FBTTaskForceIdleMemory
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct AI.GeneralRandLocationRetryRule
// Size: 0xC (Inherited: 0x0)
struct FGeneralRandLocationRetryRule
{
	float AngleRangeMin; // 0x0(0x4)
	float AngleRangeMax; // 0x4(0x4)
	float ScanStep; // 0x8(0x4)
};

// Object: ScriptStruct AI.BTLaunchMoveSpeedCurve
// Size: 0x4 (Inherited: 0x0)
struct FBTLaunchMoveSpeedCurve
{
	float DistanceThreshold; // 0x0(0x4)
};

// Object: ScriptStruct AI.BTTaskMobExplodeMemory
// Size: 0x1 (Inherited: 0x0)
struct FBTTaskMobExplodeMemory
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct AI.MobRandLocationRetryRule
// Size: 0xC (Inherited: 0x0)
struct FMobRandLocationRetryRule
{
	float AngleRangeMin; // 0x0(0x4)
	float AngleRangeMax; // 0x4(0x4)
	int RetryTimes; // 0x8(0x4)
};

// Object: ScriptStruct AI.BTTaskGetNearDeathCharNearbyMemory
// Size: 0xC (Inherited: 0x0)
struct FBTTaskGetNearDeathCharNearbyMemory
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct AI.BTTaskMobGetRandomAttackTargetInRadius
// Size: 0x8 (Inherited: 0x0)
struct FBTTaskMobGetRandomAttackTargetInRadius
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct AI.BTTaskGetVehicleNearbyMemory
// Size: 0xC (Inherited: 0x0)
struct FBTTaskGetVehicleNearbyMemory
{
	uint8_t Pad_0x0[0xC]; // 0x0(0xC)
};

// Object: ScriptStruct AI.BTTaskMoveAroundMemory
// Size: 0xA0 (Inherited: 0x0)
struct FBTTaskMoveAroundMemory
{
	uint8_t Pad_0x0[0x68]; // 0x0(0x68)
	struct AActor* FocusActor; // 0x68(0x8)
	uint8_t Pad_0x70[0x30]; // 0x70(0x30)
};

// Object: ScriptStruct AI.BTTaskRotateToTargetMemory
// Size: 0x8 (Inherited: 0x0)
struct FBTTaskRotateToTargetMemory
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct AI.BlackBoardSubTreeConfig
// Size: 0x30 (Inherited: 0x0)
struct FBlackBoardSubTreeConfig
{
	struct FBlackboardKeySelector BBKey; // 0x0(0x28)
	struct UBehaviorTree* SubBehaviorAsset; // 0x28(0x8)
};

// Object: ScriptStruct AI.LocationRetryRule
// Size: 0xC (Inherited: 0x0)
struct FLocationRetryRule
{
	float AngleRangeMin; // 0x0(0x4)
	float AngleRangeMax; // 0x4(0x4)
	float ScanStep; // 0x8(0x4)
};

// Object: ScriptStruct AI.AITaskNodeThrowGrenadeTargetLocRandomableConfig
// Size: 0x8 (Inherited: 0x0)
struct FAITaskNodeThrowGrenadeTargetLocRandomableConfig
{
	float RandomRange; // 0x0(0x4)
	int RandomTimes; // 0x4(0x4)
};

// Object: ScriptStruct AI.BTAICharacterCastSkillMemory
// Size: 0x34 (Inherited: 0x0)
struct FBTAICharacterCastSkillMemory
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	struct FVector FocusLocation; // 0x4(0xC)
	struct TWeakObjectPtr<struct AActor> FocusActor; // 0x10(0x8)
	struct FVector TossTargetLoc; // 0x18(0xC)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FVector GrenadeThrowStartLoc; // 0x28(0xC)
};

// Object: ScriptStruct AI.FindBuildingRatingConfig
// Size: 0x8 (Inherited: 0x0)
struct FFindBuildingRatingConfig
{
	int Rating; // 0x0(0x4)
	float SearchRadius; // 0x4(0x4)
};

// Object: ScriptStruct AI.BTTaskParachuteJumpBaseMemory
// Size: 0x20 (Inherited: 0x0)
struct FBTTaskParachuteJumpBaseMemory
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct AI.TriggeredCustomDamageEvent
// Size: 0xF0 (Inherited: 0x0)
struct FTriggeredCustomDamageEvent
{
	struct FCustomDamageEventRow Event; // 0x0(0xE8)
	float TimeTriggered; // 0xE8(0x4)
	uint8_t Pad_0xEC[0x4]; // 0xEC(0x4)
};

// Object: ScriptStruct AI.CustomDamageEventRow
// Size: 0xE8 (Inherited: 0x8)
struct FCustomDamageEventRow : FTableRowBase
{
	bool bProcessedLocally; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	struct FGuid EventID; // 0xC(0x10)
	bool bEnabled; // 0x1C(0x1)
	bool bClientOnly; // 0x1D(0x1)
	bool bReplicate; // 0x1E(0x1)
	bool bOnlyReplicateWhenRelevant; // 0x1F(0x1)
	uint8_t EventTriggerType; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	float TriggerCooldown; // 0x24(0x4)
	float HealthPercentageThreshold; // 0x28(0x4)
	bool bTriggerWhenDead; // 0x2C(0x1)
	uint8_t EventReactionType; // 0x2D(0x1)
	uint8_t Pad_0x2E[0x2]; // 0x2E(0x2)
	struct UClass* ActorClassToSpawn; // 0x30(0x28)
	bool bTriggersGlobalCooldown; // 0x58(0x1)
	bool bLockedByGlobalCooldown; // 0x59(0x1)
	uint8_t Pad_0x5A[0x6]; // 0x5A(0x6)
	struct UClass* OnCooldownActorClassToSpawn; // 0x60(0x28)
	bool bDestroySpawnedParticlesWithOwner; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
	struct FName AttachComponentTag; // 0x90(0x8)
	struct FName SpawnSocketName; // 0x98(0x8)
	struct FName CustomSpawnTransformTag; // 0xA0(0x8)
	bool bSpawnAtRandomPointInBoundingBox; // 0xA8(0x1)
	bool bUseCustomSpawnRotation; // 0xA9(0x1)
	uint8_t MinToSpawn; // 0xAA(0x1)
	uint8_t MaxToSpawn; // 0xAB(0x1)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
	struct FName ActorSpawnTag; // 0xB0(0x8)
	struct FName MeshComponentTag; // 0xB8(0x8)
	int MeshInstanceIndex; // 0xC0(0x4)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
	struct FName BoneName; // 0xC8(0x8)
	struct FName PhysicsAssetProfileName; // 0xD0(0x8)
	struct FName CollisionPrimitiveTag; // 0xD8(0x8)
	uint8_t Pad_0xE0[0x8]; // 0xE0(0x8)
};

// Object: ScriptStruct AI.DiffMercenaryJumpObstacleAllPlayerInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffMercenaryJumpObstacleAllPlayerInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.MercenaryJumpObstacleAIStateInfo
// Size: 0x78 (Inherited: 0x20)
struct FMercenaryJumpObstacleAIStateInfo : FUniqueStateInfo
{
	struct FJumpObstacleInfo jump_obstacle_info; // 0x20(0x58)
};

// Object: ScriptStruct AI.JumpObstacleInfo
// Size: 0x58 (Inherited: 0x18)
struct FJumpObstacleInfo : FAIStateInfoBase
{
	struct FAIStateXYZ ObstacleCenter; // 0x18(0xC)
	struct FAIStateXYZ ObstacleNearest; // 0x24(0xC)
	struct FAIStateXYZ ObstacleHighest; // 0x30(0xC)
	struct FAIStateXYZ JumpV; // 0x3C(0xC)
	struct FAIStateXYZ LandSpot; // 0x48(0xC)
	bool is_valid_jump; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
};

// Object: ScriptStruct AI.DiffLandScapeAllPlayerInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffLandScapeAllPlayerInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FLandScapeAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FDiffLandScapeAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FLandScapeAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.LandScapeAIStateInfo
// Size: 0x30 (Inherited: 0x20)
struct FLandScapeAIStateInfo : FUniqueStateInfo
{
	struct TArray<struct FLandScapeDestroyState> landscape_destroy_info; // 0x20(0x10)
};

// Object: ScriptStruct AI.LandScapeDestroyState
// Size: 0x38 (Inherited: 0x20)
struct FLandScapeDestroyState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	struct FAIStateXYZ Location; // 0x24(0xC)
	int Radius; // 0x30(0x4)
	int Depth; // 0x34(0x4)
};

// Object: ScriptStruct AI.DiffLandScapeAIStateInfo
// Size: 0x58 (Inherited: 0x20)
struct FDiffLandScapeAIStateInfo : FUniqueStateInfo
{
	struct FDiffLandScapeDestroyStateList landscape_destroy_info; // 0x20(0x38)
};

// Object: ScriptStruct AI.DiffLandScapeDestroyStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffLandScapeDestroyStateList : FAIStateInfoBase
{
	struct TArray<struct FLandScapeDestroyState> Values; // 0x18(0x10)
	struct TArray<uint32_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffLandScapeGlobalGameInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffLandScapeGlobalGameInfo : FAIStateInfoBase
{
	struct FDiffLandScapeChangeStateList landscape_change_info; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffLandScapeChangeStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffLandScapeChangeStateList : FAIStateInfoBase
{
	struct TArray<struct FLandScapeChangeState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.LandScapeChangeState
// Size: 0x38 (Inherited: 0x20)
struct FLandScapeChangeState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<struct FLandScapeChange> changes; // 0x28(0x10)
};

// Object: ScriptStruct AI.LandScapeChange
// Size: 0x48 (Inherited: 0x20)
struct FLandScapeChange : FUniqueStateInfo
{
	int component_index_x; // 0x20(0x4)
	int component_index_y; // 0x24(0x4)
	int component_x1; // 0x28(0x4)
	int component_y1; // 0x2C(0x4)
	int component_x2; // 0x30(0x4)
	int component_y2; // 0x34(0x4)
	struct TArray<uint16_t> heights_data; // 0x38(0x10)
};

// Object: ScriptStruct AI.DiffMPBaseAllPlayersInfo
// Size: 0x118 (Inherited: 0x18)
struct FDiffMPBaseAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
	struct TArray<uint64_t> del_item_id; // 0x108(0x10)
};

// Object: ScriptStruct AI.MPBaseAIStateInfo
// Size: 0x88 (Inherited: 0x20)
struct FMPBaseAIStateInfo : FUniqueStateInfo
{
	struct FMPBaseAIPlayerState State; // 0x20(0x38)
	struct FDeathMatchAIPlayerEquipment deathmatch_backpack; // 0x58(0x30)
};

// Object: ScriptStruct AI.DeathMatchAIPlayerEquipment
// Size: 0x30 (Inherited: 0x18)
struct FDeathMatchAIPlayerEquipment : FAIStateInfoBase
{
	struct TArray<struct FAIGameModePlayerWeaponSchemeInfo> weapon_scheme_info_list; // 0x18(0x10)
	int cur_weapon_scheme_index; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.AIGameModePlayerWeaponSchemeInfo
// Size: 0x30 (Inherited: 0x18)
struct FAIGameModePlayerWeaponSchemeInfo : FAIStateInfoBase
{
	int scheme_index; // 0x18(0x4)
	bool is_locked; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
	struct TArray<struct FAIGameModePlayerWeaponSchemeSlotInfo> slot_list; // 0x20(0x10)
};

// Object: ScriptStruct AI.AIGameModePlayerWeaponSchemeSlotInfo
// Size: 0x38 (Inherited: 0x18)
struct FAIGameModePlayerWeaponSchemeSlotInfo : FAIStateInfoBase
{
	int slot_index; // 0x18(0x4)
	int item_id; // 0x1C(0x4)
	int Count; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<int> attach_list; // 0x28(0x10)
};

// Object: ScriptStruct AI.MPBaseAIPlayerState
// Size: 0x38 (Inherited: 0x18)
struct FMPBaseAIPlayerState : FAIStateInfoBase
{
	uint32_t ID; // 0x18(0x4)
	bool is_invincible; // 0x1C(0x1)
	bool in_shoveling; // 0x1D(0x1)
	uint8_t Pad_0x1E[0x2]; // 0x1E(0x2)
	int death_count; // 0x20(0x4)
	float survive_time; // 0x24(0x4)
	float kd_ratio; // 0x28(0x4)
	int continue_kill; // 0x2C(0x4)
	int revenge; // 0x30(0x4)
	int top_spot_end; // 0x34(0x4)
};

// Object: ScriptStruct AI.DiffMPBaseGlobalGameState
// Size: 0x68 (Inherited: 0x18)
struct FDiffMPBaseGlobalGameState : FAIStateInfoBase
{
	struct FDiffMPBaseAIGameState Game; // 0x18(0x50)
};

// Object: ScriptStruct AI.DiffMPBaseAIGameState
// Size: 0x50 (Inherited: 0x18)
struct FDiffMPBaseAIGameState : FAIStateInfoBase
{
	struct FDiffTeamScoreDataList team_score_datas; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffTeamScoreDataList
// Size: 0x38 (Inherited: 0x18)
struct FDiffTeamScoreDataList : FAIStateInfoBase
{
	struct TArray<struct FTeamScoreData> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.TeamScoreData
// Size: 0x28 (Inherited: 0x20)
struct FTeamScoreData : FUniqueStateInfo
{
	int team_id; // 0x20(0x4)
	int team_score; // 0x24(0x4)
};

// Object: ScriptStruct AI.DiffBRBaseAllPlayersInfo
// Size: 0x118 (Inherited: 0x18)
struct FDiffBRBaseAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
	struct TArray<uint64_t> del_item_id; // 0x108(0x10)
};

// Object: ScriptStruct AI.BRBaseAIStateInfo
// Size: 0x98 (Inherited: 0x20)
struct FBRBaseAIStateInfo : FUniqueStateInfo
{
	struct FBRBaseAIPlayerState State; // 0x20(0x60)
	uint32_t deliver_target_id; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct TArray<struct FAIRecipients> recipients; // 0x88(0x10)
};

// Object: ScriptStruct AI.AIRecipients
// Size: 0x38 (Inherited: 0x18)
struct FAIRecipients : FAIStateInfoBase
{
	uint32_t ID; // 0x18(0x4)
	uint32_t team_id; // 0x1C(0x4)
	struct FAIStateXYZ Position; // 0x20(0xC)
	float Hp; // 0x2C(0x4)
	uint32_t Type; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct AI.BRBaseAIPlayerState
// Size: 0x60 (Inherited: 0x18)
struct FBRBaseAIPlayerState : FAIStateInfoBase
{
	int expect_delivery_num; // 0x18(0x4)
	int remain_delivery_num; // 0x1C(0x4)
	bool is_diving; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	int revival_count; // 0x24(0x4)
	uint32_t parachute_state; // 0x28(0x4)
	uint32_t plane_id; // 0x2C(0x4)
	int parallel_world_id; // 0x30(0x4)
	bool is_be_spectated; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	uint32_t related_id; // 0x38(0x4)
	bool can_parachute_jump; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
	uint32_t follow_state; // 0x40(0x4)
	uint32_t leader_id; // 0x44(0x4)
	uint32_t parachute_type; // 0x48(0x4)
	int revival_type; // 0x4C(0x4)
	struct FAIStateXYZ target_position; // 0x50(0xC)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
};

// Object: ScriptStruct AI.DiffBRBaseGlobalGameState
// Size: 0x168 (Inherited: 0x18)
struct FDiffBRBaseGlobalGameState : FAIStateInfoBase
{
	struct FDiffAirDropBoxStateList air_drop_box_states; // 0x18(0x38)
	struct FDiffSpecialMeshStateList special_meshes; // 0x50(0x38)
	struct FRedZoneState red_zone; // 0x88(0x30)
	struct FSafetyAreaState safety_area; // 0xB8(0x48)
	struct FDiffPlaneInfoList airplane_list; // 0x100(0x38)
	struct FGlobalControlInfo control_info; // 0x138(0x20)
	struct TArray<uint32_t> silent_list; // 0x158(0x10)
};

// Object: ScriptStruct AI.GlobalControlInfo
// Size: 0x20 (Inherited: 0x18)
struct FGlobalControlInfo : FAIStateInfoBase
{
	int airdrop_tag; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct AI.DiffPlaneInfoList
// Size: 0x38 (Inherited: 0x18)
struct FDiffPlaneInfoList : FAIStateInfoBase
{
	struct TArray<struct FPlaneInfo> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.PlaneInfo
// Size: 0x88 (Inherited: 0x20)
struct FPlaneInfo : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	uint32_t Type; // 0x24(0x4)
	struct FAIStateXYZ Position; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FFlightInfo flight_info; // 0x38(0x50)
};

// Object: ScriptStruct AI.FlightInfo
// Size: 0x50 (Inherited: 0x18)
struct FFlightInfo : FAIStateInfoBase
{
	struct FAIStateXYZ start_loc; // 0x18(0xC)
	struct FAIStateXYZ end_loc; // 0x24(0xC)
	struct FAIStateXYZ can_jump_loc; // 0x30(0xC)
	struct FAIStateXYZ force_jump_loc; // 0x3C(0xC)
	int player_num; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct AI.SafetyAreaState
// Size: 0x48 (Inherited: 0x18)
struct FSafetyAreaState : FAIStateInfoBase
{
	int State; // 0x18(0x4)
	struct FAIStateXYZ Center; // 0x1C(0xC)
	float Radius; // 0x28(0x4)
	struct FAIStateXYZ next_center; // 0x2C(0xC)
	float next_radius; // 0x38(0x4)
	int Time; // 0x3C(0x4)
	int total_time; // 0x40(0x4)
	int circle_index; // 0x44(0x4)
};

// Object: ScriptStruct AI.RedZoneState
// Size: 0x30 (Inherited: 0x18)
struct FRedZoneState : FAIStateInfoBase
{
	struct FAIStateXYZ Center; // 0x18(0xC)
	float Radius; // 0x24(0x4)
	float remain_time; // 0x28(0x4)
	float start_time; // 0x2C(0x4)
};

// Object: ScriptStruct AI.DiffSpecialMeshStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffSpecialMeshStateList : FAIStateInfoBase
{
	struct TArray<struct FSpecialMeshState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.SpecialMeshState
// Size: 0x40 (Inherited: 0x20)
struct FSpecialMeshState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	struct FAIStateXYZ Position; // 0x24(0xC)
	struct FAIStateXYZ Rotation; // 0x30(0xC)
	int custom_state; // 0x3C(0x4)
};

// Object: ScriptStruct AI.DiffAirDropBoxStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAirDropBoxStateList : FAIStateInfoBase
{
	struct TArray<struct FAirDropBoxState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.AirDropBoxState
// Size: 0x38 (Inherited: 0x20)
struct FAirDropBoxState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	int Type; // 0x24(0x4)
	struct FAIStateXYZ Position; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct AI.DiffNearbyMonsterAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffNearbyMonsterAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.NearbyMonsterAIStateInfo
// Size: 0x40 (Inherited: 0x20)
struct FNearbyMonsterAIStateInfo : FUniqueStateInfo
{
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
	struct TArray<uint64_t> monster_states_index; // 0x30(0x10)
};

// Object: ScriptStruct AI.DiffNearbyMonsterGlobalGameState
// Size: 0x68 (Inherited: 0x18)
struct FDiffNearbyMonsterGlobalGameState : FAIStateInfoBase
{
	struct FDiffMonsterGlobalNearbyInfo global_nearby_info; // 0x18(0x50)
};

// Object: ScriptStruct AI.DiffMonsterGlobalNearbyInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffMonsterGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffMonsterStates monster_states; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffMonsterStates
// Size: 0x38 (Inherited: 0x18)
struct FDiffMonsterStates : FAIStateInfoBase
{
	struct TArray<struct FMonsterState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.MonsterState
// Size: 0x80 (Inherited: 0x20)
struct FMonsterState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	int Category; // 0x24(0x4)
	struct FAIStateXYZ Position; // 0x28(0xC)
	struct FAIStateXYZ Rotation; // 0x34(0xC)
	struct FAIStateXYZ Speed; // 0x40(0xC)
	float Hp; // 0x4C(0x4)
	float hp_max; // 0x50(0x4)
	int using_skill_id; // 0x54(0x4)
	int skill_phase_index; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct TArray<struct FAIAttribute> Attributes; // 0x60(0x10)
	struct TArray<struct FIntAIAttribute> int_attributes; // 0x70(0x10)
};

// Object: ScriptStruct AI.IntAIAttribute
// Size: 0x30 (Inherited: 0x20)
struct FIntAIAttribute : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	uint64_t Value; // 0x28(0x8)
};

// Object: ScriptStruct AI.AIAttribute
// Size: 0x28 (Inherited: 0x20)
struct FAIAttribute : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	float Value; // 0x24(0x4)
};

// Object: ScriptStruct AI.DiffDestructibleItemAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffDestructibleItemAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.DestructibleItemAIStateInfo
// Size: 0x40 (Inherited: 0x20)
struct FDestructibleItemAIStateInfo : FUniqueStateInfo
{
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
	struct TArray<uint64_t> destructible_items_index; // 0x30(0x10)
};

// Object: ScriptStruct AI.DiffDestructibleItemGlobalGameState
// Size: 0x68 (Inherited: 0x18)
struct FDiffDestructibleItemGlobalGameState : FAIStateInfoBase
{
	struct FDiffDestructibleItemGlobalNearbyInfo global_nearby_info; // 0x18(0x50)
};

// Object: ScriptStruct AI.DiffDestructibleItemGlobalNearbyInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffDestructibleItemGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffDestructibleItemStateList destructible_items; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffDestructibleItemStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffDestructibleItemStateList : FAIStateInfoBase
{
	struct TArray<struct FDestructibleItem> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DestructibleItem
// Size: 0x60 (Inherited: 0x20)
struct FDestructibleItem : FUniqueStateInfo
{
	int Category; // 0x20(0x4)
	uint32_t ID; // 0x24(0x4)
	struct FAIStateXYZ Center; // 0x28(0xC)
	struct FAIStateXYZ Rotation; // 0x34(0xC)
	struct TArray<bool> fragment_states; // 0x40(0x10)
	struct FAIStateXYZ Scale; // 0x50(0xC)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
};

// Object: ScriptStruct AI.DiffDynamicItemAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffDynamicItemAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.DynamicItemAIStateInfo
// Size: 0x40 (Inherited: 0x20)
struct FDynamicItemAIStateInfo : FUniqueStateInfo
{
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
	struct TArray<uint64_t> dynamic_items_index; // 0x30(0x10)
};

// Object: ScriptStruct AI.DiffDynamicItemGlobalGameState
// Size: 0x68 (Inherited: 0x18)
struct FDiffDynamicItemGlobalGameState : FAIStateInfoBase
{
	struct FDiffDynamicItemGlobalNearbyInfo global_nearby_info; // 0x18(0x50)
};

// Object: ScriptStruct AI.DiffDynamicItemGlobalNearbyInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffDynamicItemGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffDynamicItemStateList dynamic_items; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffDynamicItemStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffDynamicItemStateList : FAIStateInfoBase
{
	struct TArray<struct FDynamicItem> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DynamicItem
// Size: 0x80 (Inherited: 0x20)
struct FDynamicItem : FUniqueStateInfo
{
	int Category; // 0x20(0x4)
	uint32_t ID; // 0x24(0x4)
	struct FAIStateXYZ Center; // 0x28(0xC)
	struct FAIStateXYZ Rotation; // 0x34(0xC)
	float Durability; // 0x40(0x4)
	uint32_t Custom; // 0x44(0x4)
	struct FAIStateXYZ Scale; // 0x48(0xC)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<struct FAIAttribute> custom_attribute_list; // 0x58(0x10)
	struct TArray<struct FIntAIAttribute> int_custom_attribute_list; // 0x68(0x10)
	int parallel_world_id; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: ScriptStruct AI.DiffDynamicItem
// Size: 0xD0 (Inherited: 0x20)
struct FDiffDynamicItem : FUniqueStateInfo
{
	int Category; // 0x20(0x4)
	uint32_t ID; // 0x24(0x4)
	struct FAIStateXYZ Center; // 0x28(0xC)
	struct FAIStateXYZ Rotation; // 0x34(0xC)
	float Durability; // 0x40(0x4)
	uint32_t Custom; // 0x44(0x4)
	struct FAIStateXYZ Scale; // 0x48(0xC)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FDiffAIAttributeList custom_attribute_list; // 0x58(0x38)
	struct FDiffIntAIAttributeList int_custom_attribute_list; // 0x90(0x38)
	int parallel_world_id; // 0xC8(0x4)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
};

// Object: ScriptStruct AI.DiffIntAIAttributeList
// Size: 0x38 (Inherited: 0x18)
struct FDiffIntAIAttributeList : FAIStateInfoBase
{
	struct TArray<struct FIntAIAttribute> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffAIAttributeList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAIAttributeList : FAIStateInfoBase
{
	struct TArray<struct FAIAttribute> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffNearbyPlayerAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffNearbyPlayerAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FNearbyPlayerAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FDiffNearbyPlayerAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FNearbyPlayerAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.NearbyPlayerAIStateInfo
// Size: 0x30 (Inherited: 0x20)
struct FNearbyPlayerAIStateInfo : FUniqueStateInfo
{
	struct TArray<struct FAINearbyPlayer> nearby_player; // 0x20(0x10)
};

// Object: ScriptStruct AI.AINearbyPlayer
// Size: 0x40 (Inherited: 0x20)
struct FAINearbyPlayer : FUniqueStateInfo
{
	struct FAISimplifyState State; // 0x20(0x20)
};

// Object: ScriptStruct AI.AISimplifyState
// Size: 0x20 (Inherited: 0x18)
struct FAISimplifyState : FAIStateInfoBase
{
	uint32_t ID; // 0x18(0x4)
	bool has_smoke; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
};

// Object: ScriptStruct AI.DiffNearbyPlayerAIStateInfo
// Size: 0x58 (Inherited: 0x20)
struct FDiffNearbyPlayerAIStateInfo : FUniqueStateInfo
{
	struct FDiffAINearbyPlayerList nearby_player; // 0x20(0x38)
};

// Object: ScriptStruct AI.DiffAINearbyPlayerList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAINearbyPlayerList : FAIStateInfoBase
{
	struct TArray<struct FAINearbyPlayer> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffNearbyDoorAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffNearbyDoorAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.NearbyDoorAIStateInfo
// Size: 0x40 (Inherited: 0x20)
struct FNearbyDoorAIStateInfo : FUniqueStateInfo
{
	uint8_t Pad_0x20[0x10]; // 0x20(0x10)
	struct TArray<uint64_t> nearby_door_index; // 0x30(0x10)
};

// Object: ScriptStruct AI.DiffNearbyDoorGlobalGameState
// Size: 0x68 (Inherited: 0x18)
struct FDiffNearbyDoorGlobalGameState : FAIStateInfoBase
{
	struct FDiffDoorGlobalNearbyInfo global_nearby_info; // 0x18(0x50)
};

// Object: ScriptStruct AI.DiffDoorGlobalNearbyInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffDoorGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffDoorStateList nearby_door; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffDoorStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffDoorStateList : FAIStateInfoBase
{
	struct TArray<struct FDoorState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DoorState
// Size: 0x48 (Inherited: 0x20)
struct FDoorState : FUniqueStateInfo
{
	struct FAIStateXYZ Position; // 0x20(0xC)
	int State; // 0x2C(0x4)
	uint32_t ID; // 0x30(0x4)
	struct FAIStateXYZ Rotation; // 0x34(0xC)
	int Type; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct AI.DiffVehicleAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffVehicleAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FVehicleAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FVehicleAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FVehicleAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.VehicleAIStateInfo
// Size: 0x148 (Inherited: 0x20)
struct FVehicleAIStateInfo : FUniqueStateInfo
{
	struct FVehicleAIPlayerState State; // 0x20(0x20)
	struct FVehicleState vehicle_state; // 0x40(0xE8)
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
	struct TArray<uint64_t> nearby_vehicles_index; // 0x138(0x10)
};

// Object: ScriptStruct AI.VehicleState
// Size: 0xE8 (Inherited: 0x20)
struct FVehicleState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	struct FAIStateXYZ Position; // 0x24(0xC)
	struct FAIStateXYZ Rotation; // 0x30(0xC)
	float Hp; // 0x3C(0x4)
	float gas; // 0x40(0x4)
	struct FAIStateXYZ Speed; // 0x44(0xC)
	uint32_t damaged_num; // 0x50(0x4)
	uint32_t Category; // 0x54(0x4)
	bool is_reverse; // 0x58(0x1)
	bool has_player; // 0x59(0x1)
	bool is_full; // 0x5A(0x1)
	uint8_t Pad_0x5B[0x5]; // 0x5B(0x5)
	struct FCameraState Camera; // 0x60(0x40)
	int location_state; // 0xA0(0x4)
	bool is_attached; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	uint32_t special_states; // 0xA8(0x4)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
	struct TArray<float> wheels_hp; // 0xB0(0x10)
	struct TArray<struct FVehicleDamageInfo> damage_info; // 0xC0(0x10)
	bool is_has_collision; // 0xD0(0x1)
	bool is_using_horn; // 0xD1(0x1)
	uint8_t Pad_0xD2[0x2]; // 0xD2(0x2)
	uint32_t born_island_owner_id; // 0xD4(0x4)
	uint32_t vehicle_avatar_id; // 0xD8(0x4)
	uint32_t custom_state; // 0xDC(0x4)
	float special_energy; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
};

// Object: ScriptStruct AI.VehicleDamageInfo
// Size: 0x30 (Inherited: 0x18)
struct FVehicleDamageInfo : FAIStateInfoBase
{
	uint32_t vehicle_id; // 0x18(0x4)
	uint32_t PlayerKey; // 0x1C(0x4)
	float Damage; // 0x20(0x4)
	int damage_type; // 0x24(0x4)
	bool is_kill; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
};

// Object: ScriptStruct AI.CameraState
// Size: 0x40 (Inherited: 0x18)
struct FCameraState : FAIStateInfoBase
{
	struct FAIStateXYZ Position; // 0x18(0xC)
	struct FAIStateXYZ Rotation; // 0x24(0xC)
	struct FAIStateXYZ view_position; // 0x30(0xC)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct AI.VehicleAIPlayerState
// Size: 0x20 (Inherited: 0x18)
struct FVehicleAIPlayerState : FAIStateInfoBase
{
	int vehicle_role; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct AI.DiffVehicleGlobalGameState
// Size: 0x78 (Inherited: 0x18)
struct FDiffVehicleGlobalGameState : FAIStateInfoBase
{
	struct FDiffVehicleGlobalNearbyInfo global_nearby_info; // 0x18(0x50)
	struct TArray<struct FAIStateXYZ> vehicle_spot_position; // 0x68(0x10)
};

// Object: ScriptStruct AI.DiffVehicleGlobalNearbyInfo
// Size: 0x50 (Inherited: 0x18)
struct FDiffVehicleGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffVehicleStateList nearby_vehicles; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffVehicleStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffVehicleStateList : FAIStateInfoBase
{
	struct TArray<struct FVehicleState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffBaseNearbyAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffBaseNearbyAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.BaseNearbyAIStateInfo
// Size: 0x88 (Inherited: 0x20)
struct FBaseNearbyAIStateInfo : FUniqueStateInfo
{
	struct TArray<uint64_t> nearby_item_index; // 0x20(0x10)
	struct TArray<uint64_t> nearby_thrown_index; // 0x30(0x10)
	uint8_t Pad_0x40[0x48]; // 0x40(0x48)
};

// Object: ScriptStruct AI.DiffBaseNearbyGlobalGameState
// Size: 0xA0 (Inherited: 0x18)
struct FDiffBaseNearbyGlobalGameState : FAIStateInfoBase
{
	struct FDiffBaseGlobalNearbyInfo global_nearby_info; // 0x18(0x88)
};

// Object: ScriptStruct AI.DiffBaseGlobalNearbyInfo
// Size: 0x88 (Inherited: 0x18)
struct FDiffBaseGlobalNearbyInfo : FAIStateInfoBase
{
	struct FDiffItemStateDataList nearby_item; // 0x18(0x38)
	struct FDiffAINearbyThrownList nearby_thrown; // 0x50(0x38)
};

// Object: ScriptStruct AI.DiffAINearbyThrownList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAINearbyThrownList : FAIStateInfoBase
{
	struct TArray<struct FAINearbyThrown> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.AINearbyThrown
// Size: 0x48 (Inherited: 0x20)
struct FAINearbyThrown : FUniqueStateInfo
{
	int Type; // 0x20(0x4)
	struct FAIStateXYZ Position; // 0x24(0xC)
	float remain_time; // 0x30(0x4)
	float explode_time; // 0x34(0x4)
	bool is_held; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	uint32_t ActorId; // 0x3C(0x4)
	uint32_t sourceid; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct AI.DiffItemStateDataList
// Size: 0x38 (Inherited: 0x18)
struct FDiffItemStateDataList : FAIStateInfoBase
{
	struct TArray<struct FItemStateData> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffMLBaseAllPlayersInfo
// Size: 0x108 (Inherited: 0x18)
struct FDiffMLBaseAllPlayersInfo : FAIStateInfoBase
{
	struct TMap<uint32_t, struct FMLBaseAIStateInfo> AllAIStateInfo; // 0x18(0x50)
	struct TMap<uint32_t, struct FDiffMLBaseAIStateInfo> AllDiffAIStateInfo; // 0x68(0x50)
	struct TMap<uint32_t, struct FMLBaseAIStateInfo> DebugAllAIStateInfo; // 0xB8(0x50)
};

// Object: ScriptStruct AI.MLBaseAIStateInfo
// Size: 0x130 (Inherited: 0x20)
struct FMLBaseAIStateInfo : FUniqueStateInfo
{
	struct FAIHeardSound Sound; // 0x20(0x28)
	struct FProgressBarState progress_bar; // 0x48(0x28)
	struct FAIPlayerHitInfo player_hit_info; // 0x70(0x30)
	struct FAIStateConfig Config; // 0xA0(0x20)
	struct FDamageRateInfo damage_rate_info; // 0xC0(0x40)
	struct TArray<struct FAIDestroyBulletProbInfo> destroy_bullet_prob_info; // 0x100(0x10)
	struct TArray<struct FDamageSource> all_damage_source; // 0x110(0x10)
	struct TArray<struct FAIBulletHole> all_bullet_hole; // 0x120(0x10)
};

// Object: ScriptStruct AI.AIBulletHole
// Size: 0x38 (Inherited: 0x18)
struct FAIBulletHole : FAIStateInfoBase
{
	struct FAIStateXYZ hole_pos; // 0x18(0xC)
	struct FAIStateXYZ hole_source_pos; // 0x24(0xC)
	uint32_t hole_source_id; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct AI.DamageSource
// Size: 0x30 (Inherited: 0x18)
struct FDamageSource : FAIStateInfoBase
{
	struct FAIStateXYZ damage_source; // 0x18(0xC)
	int damage_type; // 0x24(0x4)
	int damage_weapon_type; // 0x28(0x4)
	uint32_t damage_source_id; // 0x2C(0x4)
};

// Object: ScriptStruct AI.AIDestroyBulletProbInfo
// Size: 0xA0 (Inherited: 0x20)
struct FAIDestroyBulletProbInfo : FUniqueStateInfo
{
	int bullet_id; // 0x20(0x4)
	float low_hp_threshold; // 0x24(0x4)
	struct FSingleDestroyBulletProbInfo low_hp_destroy_bullet_info; // 0x28(0x28)
	struct FSingleDestroyBulletProbInfo high_hp_destroy_bullet_info; // 0x50(0x28)
	struct FSingleDestroyBulletProbInfo fatal_Damage_destroy_bullet_info; // 0x78(0x28)
};

// Object: ScriptStruct AI.SingleDestroyBulletProbInfo
// Size: 0x28 (Inherited: 0x18)
struct FSingleDestroyBulletProbInfo : FAIStateInfoBase
{
	float max_destroy_time_float; // 0x18(0x4)
	int max_destroy_num; // 0x1C(0x4)
	float destroy_cd_float; // 0x20(0x4)
	float destroy_bullet_prob; // 0x24(0x4)
};

// Object: ScriptStruct AI.DamageRateInfo
// Size: 0x40 (Inherited: 0x18)
struct FDamageRateInfo : FAIStateInfoBase
{
	struct TArray<struct FDamageRate> damage_rate_map; // 0x18(0x10)
	struct TArray<struct FDamageRate> revive_damage_rate_map; // 0x28(0x10)
	float near_death_damage_rate; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct AI.DamageRate
// Size: 0x20 (Inherited: 0x18)
struct FDamageRate : FAIStateInfoBase
{
	float Hp; // 0x18(0x4)
	float Rate; // 0x1C(0x4)
};

// Object: ScriptStruct AI.AIStateConfig
// Size: 0x20 (Inherited: 0x18)
struct FAIStateConfig : FAIStateInfoBase
{
	int Level; // 0x18(0x4)
	int Style; // 0x1C(0x4)
};

// Object: ScriptStruct AI.AIPlayerHitInfo
// Size: 0x30 (Inherited: 0x18)
struct FAIPlayerHitInfo : FAIStateInfoBase
{
	int fire_count; // 0x18(0x4)
	int hit_count; // 0x1C(0x4)
	int hit_head_count; // 0x20(0x4)
	int hit_count_filter; // 0x24(0x4)
	int hit_head_filter; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.ProgressBarState
// Size: 0x28 (Inherited: 0x18)
struct FProgressBarState : FAIStateInfoBase
{
	int Type; // 0x18(0x4)
	float remain_time; // 0x1C(0x4)
	uint32_t targetid; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct AI.AIHeardSound
// Size: 0x28 (Inherited: 0x18)
struct FAIHeardSound : FAIStateInfoBase
{
	struct TArray<struct FSoundState> heard_sound; // 0x18(0x10)
};

// Object: ScriptStruct AI.DiffMLBaseAIStateInfo
// Size: 0x158 (Inherited: 0x20)
struct FDiffMLBaseAIStateInfo : FUniqueStateInfo
{
	struct FAIHeardSound Sound; // 0x20(0x28)
	struct FProgressBarState progress_bar; // 0x48(0x28)
	struct FAIPlayerHitInfo player_hit_info; // 0x70(0x30)
	struct FAIStateConfig Config; // 0xA0(0x20)
	struct FDamageRateInfo damage_rate_info; // 0xC0(0x40)
	struct FDiffAIDestroyBulletProbInfoList destroy_bullet_prob_info; // 0x100(0x38)
	struct TArray<struct FAIBulletHole> all_bullet_hole; // 0x138(0x10)
	struct TArray<struct FDamageSource> all_damage_source; // 0x148(0x10)
};

// Object: ScriptStruct AI.DiffAIDestroyBulletProbInfoList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAIDestroyBulletProbInfoList : FAIStateInfoBase
{
	struct TArray<struct FAIDestroyBulletProbInfo> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffBaseModAllPlayersInfo
// Size: 0x120 (Inherited: 0x18)
struct FDiffBaseModAllPlayersInfo : FAIStateInfoBase
{
	uint32_t Key; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TMap<uint32_t, struct FBaseModAIStateInfo> AllAIStateInfo; // 0x20(0x50)
	struct TMap<uint32_t, struct FDiffBaseModAIStateInfo> AllDiffAIStateInfo; // 0x70(0x50)
	struct TMap<uint32_t, struct FBaseModAIStateInfo> DebugAllAIStateInfo; // 0xC0(0x50)
	struct TArray<uint64_t> del_item_id; // 0x110(0x10)
};

// Object: ScriptStruct AI.BaseModAIStateInfo
// Size: 0x2F0 (Inherited: 0x20)
struct FBaseModAIStateInfo : FUniqueStateInfo
{
	struct FBaseModAIPlayerState State; // 0x20(0x170)
	struct FAIPlayerInteractInfo player_interact_info; // 0x190(0x58)
	struct FCameraState Camera; // 0x1E8(0x40)
	struct FAIPlayerWeapon Weapon; // 0x228(0x28)
	struct FAIPlayerBackpack BackPack; // 0x250(0x28)
	struct FAIPlayerEquipment equipment; // 0x278(0x28)
	uint32_t Key; // 0x2A0(0x4)
	uint32_t ai_style; // 0x2A4(0x4)
	struct TArray<struct FChatMsgInfo> chatmsg_info_list; // 0x2A8(0x10)
	struct TArray<struct FSignMsgInfo> signmsg_info_list; // 0x2B8(0x10)
	struct TArray<struct FMapMarkInfo> mapmark_info_list; // 0x2C8(0x10)
	struct TArray<struct FAIAvatarInfo> avatar_info; // 0x2D8(0x10)
	uint32_t ai_provider; // 0x2E8(0x4)
	uint8_t Pad_0x2EC[0x4]; // 0x2EC(0x4)
};

// Object: ScriptStruct AI.AIAvatarInfo
// Size: 0x20 (Inherited: 0x18)
struct FAIAvatarInfo : FAIStateInfoBase
{
	int slot_id; // 0x18(0x4)
	int item_id; // 0x1C(0x4)
};

// Object: ScriptStruct AI.MapMarkInfo
// Size: 0x38 (Inherited: 0x18)
struct FMapMarkInfo : FAIStateInfoBase
{
	struct FAIStateXYZ mapmark_loc; // 0x18(0xC)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<struct FAIStateXYZ> mapmultimark_list; // 0x28(0x10)
};

// Object: ScriptStruct AI.SignMsgInfo
// Size: 0x30 (Inherited: 0x18)
struct FSignMsgInfo : FAIStateInfoBase
{
	struct FAIStateXYZ hit_pos; // 0x18(0xC)
	uint32_t item_id; // 0x24(0x4)
	uint32_t msg_type; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.ChatMsgInfo
// Size: 0x40 (Inherited: 0x18)
struct FChatMsgInfo : FAIStateInfoBase
{
	struct FString msg_content; // 0x18(0x10)
	uint32_t item_id; // 0x28(0x4)
	uint32_t msg_id; // 0x2C(0x4)
	struct FAIStateXYZ hit_position; // 0x30(0xC)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct AI.AIPlayerEquipment
// Size: 0x28 (Inherited: 0x18)
struct FAIPlayerEquipment : FAIStateInfoBase
{
	struct TArray<struct FAIEquipmentInfo> equipment_item; // 0x18(0x10)
};

// Object: ScriptStruct AI.AIEquipmentInfo
// Size: 0x30 (Inherited: 0x20)
struct FAIEquipmentInfo : FUniqueStateInfo
{
	int Category; // 0x20(0x4)
	uint32_t ID; // 0x24(0x4)
	float Durability; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.AIPlayerBackpack
// Size: 0x28 (Inherited: 0x18)
struct FAIPlayerBackpack : FAIStateInfoBase
{
	struct TArray<struct FAIBackpackItem> backpack_item; // 0x18(0x10)
};

// Object: ScriptStruct AI.AIBackpackItem
// Size: 0x30 (Inherited: 0x20)
struct FAIBackpackItem : FUniqueStateInfo
{
	int Category; // 0x20(0x4)
	uint32_t ID; // 0x24(0x4)
	uint32_t Count; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct AI.AIPlayerWeapon
// Size: 0x28 (Inherited: 0x18)
struct FAIPlayerWeapon : FAIStateInfoBase
{
	struct TArray<struct FAIWeaponStateInfo> player_weapon; // 0x18(0x10)
};

// Object: ScriptStruct AI.AIWeaponStateInfo
// Size: 0x50 (Inherited: 0x20)
struct FAIWeaponStateInfo : FUniqueStateInfo
{
	int slot_id; // 0x20(0x4)
	int Category; // 0x24(0x4)
	int Type; // 0x28(0x4)
	int Bullet; // 0x2C(0x4)
	float remain_reloading; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<int> attachments; // 0x38(0x10)
	int bullet_in_backpak; // 0x48(0x4)
	uint32_t weapon_avatar_id; // 0x4C(0x4)
};

// Object: ScriptStruct AI.AIPlayerInteractInfo
// Size: 0x58 (Inherited: 0x18)
struct FAIPlayerInteractInfo : FAIStateInfoBase
{
	struct TArray<struct FAIDamageInfo> active_damage; // 0x18(0x10)
	struct TArray<struct FAIDamageInfo> passive_damage; // 0x28(0x10)
	struct TArray<uint32_t> kill_list; // 0x38(0x10)
	struct TArray<uint32_t> knock_down_list; // 0x48(0x10)
};

// Object: ScriptStruct AI.AIDamageInfo
// Size: 0x30 (Inherited: 0x18)
struct FAIDamageInfo : FAIStateInfoBase
{
	uint32_t PlayerKey; // 0x18(0x4)
	float Damage; // 0x1C(0x4)
	int damage_type; // 0x20(0x4)
	int damage_weapon_type; // 0x24(0x4)
	uint32_t damage_part; // 0x28(0x4)
	float damage_before_cal_armor; // 0x2C(0x4)
};

// Object: ScriptStruct AI.BaseModAIPlayerState
// Size: 0x170 (Inherited: 0x18)
struct FBaseModAIPlayerState : FAIStateInfoBase
{
	uint32_t ID; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	uint64_t unique_id; // 0x20(0x8)
	struct FString player_name; // 0x28(0x10)
	int team_id; // 0x38(0x4)
	int team_index; // 0x3C(0x4)
	struct FAIStateXYZ Position; // 0x40(0xC)
	struct FAIStateXYZ Rotation; // 0x4C(0xC)
	struct FAIStateXYZ Speed; // 0x58(0xC)
	float Hp; // 0x64(0x4)
	float Energy; // 0x68(0x4)
	float dying_hp; // 0x6C(0x4)
	float oxygen; // 0x70(0x4)
	int active_weapon_slot; // 0x74(0x4)
	int weapon_status; // 0x78(0x4)
	bool is_switching; // 0x7C(0x1)
	uint8_t Pad_0x7D[0x3]; // 0x7D(0x3)
	int alive_state; // 0x80(0x4)
	int kill_count; // 0x84(0x4)
	int assist_count; // 0x88(0x4)
	int Damages; // 0x8C(0x4)
	bool is_left_probe; // 0x90(0x1)
	bool is_right_probe; // 0x91(0x1)
	bool is_floating; // 0x92(0x1)
	uint8_t Pad_0x93[0x1]; // 0x93(0x1)
	int using_skill_id; // 0x94(0x4)
	int skill_phase_index; // 0x98(0x4)
	bool is_pose_acting; // 0x9C(0x1)
	bool is_picking; // 0x9D(0x1)
	uint8_t Pad_0x9E[0x2]; // 0x9E(0x2)
	int body_state; // 0xA0(0x4)
	int location_state; // 0xA4(0x4)
	bool has_smoke; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x3]; // 0xA9(0x3)
	int player_type; // 0xAC(0x4)
	int ai_level; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct TArray<struct FAIAttribute> Attributes; // 0xB8(0x10)
	struct TArray<struct FIntAIAttribute> int_attributes; // 0xC8(0x10)
	struct TArray<struct FStrAIAttribute> str_attributes; // 0xD8(0x10)
	struct TArray<uint64_t> pawn_state_list; // 0xE8(0x10)
	bool is_lost_connection; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x3]; // 0xF9(0x3)
	int ai_kill_count; // 0xFC(0x4)
	bool in_delivery_pool; // 0x100(0x1)
	bool has_gone; // 0x101(0x1)
	bool in_afk; // 0x102(0x1)
	uint8_t Pad_0x103[0x1]; // 0x103(0x1)
	int emote_id; // 0x104(0x4)
	bool is_move_has_collision; // 0x108(0x1)
	uint8_t Pad_0x109[0x3]; // 0x109(0x3)
	float rating_score; // 0x10C(0x4)
	float real_hidden_score; // 0x110(0x4)
	float realscore_mu; // 0x114(0x4)
	float realscore_sigma; // 0x118(0x4)
	int zone_id; // 0x11C(0x4)
	int Gender; // 0x120(0x4)
	uint8_t Pad_0x124[0x4]; // 0x124(0x4)
	struct FString OpenID; // 0x128(0x10)
	int high_hp_destroy_bullet_num; // 0x138(0x4)
	int low_hp_destroy_bullet_num; // 0x13C(0x4)
	int fatal_damage_destroy_bullet_num; // 0x140(0x4)
	bool is_weapon_near_wall; // 0x144(0x1)
	uint8_t Pad_0x145[0x3]; // 0x145(0x3)
	struct FAIStateXYZ head_position; // 0x148(0xC)
	struct FAIStateXYZ muzzle_position; // 0x154(0xC)
	uint32_t ally_master_id; // 0x160(0x4)
	int first_lang_id; // 0x164(0x4)
	int received_fatal_destroy_bullet_num; // 0x168(0x4)
	int feature_id; // 0x16C(0x4)
};

// Object: ScriptStruct AI.StrAIAttribute
// Size: 0x38 (Inherited: 0x20)
struct FStrAIAttribute : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString Value; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffBaseModAIStateInfo
// Size: 0x3D8 (Inherited: 0x20)
struct FDiffBaseModAIStateInfo : FUniqueStateInfo
{
	struct FDiffBaseModAIPlayerState State; // 0x20(0x1E0)
	struct FAIPlayerInteractInfo player_interact_info; // 0x200(0x58)
	struct FCameraState Camera; // 0x258(0x40)
	struct FDiffAIPlayerWeapon Weapon; // 0x298(0x50)
	struct FDiffAIPlayerBackpack BackPack; // 0x2E8(0x50)
	struct FDiffAIPlayerEquipment equipment; // 0x338(0x50)
	uint32_t Key; // 0x388(0x4)
	uint32_t ai_style; // 0x38C(0x4)
	struct TArray<struct FChatMsgInfo> chatmsg_info_list; // 0x390(0x10)
	struct TArray<struct FSignMsgInfo> signmsg_info_list; // 0x3A0(0x10)
	struct TArray<struct FMapMarkInfo> mapmark_info_list; // 0x3B0(0x10)
	struct TArray<struct FAIAvatarInfo> avatar_info; // 0x3C0(0x10)
	uint32_t ai_provider; // 0x3D0(0x4)
	uint8_t Pad_0x3D4[0x4]; // 0x3D4(0x4)
};

// Object: ScriptStruct AI.DiffAIPlayerEquipment
// Size: 0x50 (Inherited: 0x18)
struct FDiffAIPlayerEquipment : FAIStateInfoBase
{
	struct FDiffAIEquipmentInfoList equipment_item; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffAIEquipmentInfoList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAIEquipmentInfoList : FAIStateInfoBase
{
	struct TArray<struct FAIEquipmentInfo> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffAIPlayerBackpack
// Size: 0x50 (Inherited: 0x18)
struct FDiffAIPlayerBackpack : FAIStateInfoBase
{
	struct FDiffAIBackpackItemList backpack_item; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffAIBackpackItemList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAIBackpackItemList : FAIStateInfoBase
{
	struct TArray<struct FAIBackpackItem> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffAIPlayerWeapon
// Size: 0x50 (Inherited: 0x18)
struct FDiffAIPlayerWeapon : FAIStateInfoBase
{
	struct FDiffAIWeaponStateInfoList player_weapon; // 0x18(0x38)
};

// Object: ScriptStruct AI.DiffAIWeaponStateInfoList
// Size: 0x38 (Inherited: 0x18)
struct FDiffAIWeaponStateInfoList : FAIStateInfoBase
{
	struct TArray<struct FAIWeaponStateInfo> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffBaseModAIPlayerState
// Size: 0x1E0 (Inherited: 0x18)
struct FDiffBaseModAIPlayerState : FAIStateInfoBase
{
	uint32_t ID; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	uint64_t unique_id; // 0x20(0x8)
	struct FString player_name; // 0x28(0x10)
	int team_id; // 0x38(0x4)
	int team_index; // 0x3C(0x4)
	struct FAIStateXYZ Position; // 0x40(0xC)
	struct FAIStateXYZ Rotation; // 0x4C(0xC)
	struct FAIStateXYZ Speed; // 0x58(0xC)
	float Hp; // 0x64(0x4)
	float Energy; // 0x68(0x4)
	float dying_hp; // 0x6C(0x4)
	float oxygen; // 0x70(0x4)
	int active_weapon_slot; // 0x74(0x4)
	int weapon_status; // 0x78(0x4)
	bool is_switching; // 0x7C(0x1)
	uint8_t Pad_0x7D[0x3]; // 0x7D(0x3)
	int alive_state; // 0x80(0x4)
	int kill_count; // 0x84(0x4)
	int assist_count; // 0x88(0x4)
	int Damages; // 0x8C(0x4)
	bool is_left_probe; // 0x90(0x1)
	bool is_right_probe; // 0x91(0x1)
	bool is_floating; // 0x92(0x1)
	uint8_t Pad_0x93[0x1]; // 0x93(0x1)
	int using_skill_id; // 0x94(0x4)
	int skill_phase_index; // 0x98(0x4)
	bool is_pose_acting; // 0x9C(0x1)
	bool is_picking; // 0x9D(0x1)
	bool is_weapon_near_wall; // 0x9E(0x1)
	uint8_t Pad_0x9F[0x1]; // 0x9F(0x1)
	int body_state; // 0xA0(0x4)
	int location_state; // 0xA4(0x4)
	bool has_smoke; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x3]; // 0xA9(0x3)
	int player_type; // 0xAC(0x4)
	int ai_level; // 0xB0(0x4)
	bool is_move_has_collision; // 0xB4(0x1)
	bool is_lost_connection; // 0xB5(0x1)
	uint8_t Pad_0xB6[0x2]; // 0xB6(0x2)
	float rating_score; // 0xB8(0x4)
	float real_hidden_score; // 0xBC(0x4)
	float realscore_mu; // 0xC0(0x4)
	float realscore_sigma; // 0xC4(0x4)
	int zone_id; // 0xC8(0x4)
	bool in_delivery_pool; // 0xCC(0x1)
	uint8_t Pad_0xCD[0x3]; // 0xCD(0x3)
	struct FDiffAIAttributeList Attributes; // 0xD0(0x38)
	struct FDiffIntAIAttributeList int_attributes; // 0x108(0x38)
	struct FDiffStrAIAttributeList str_attributes; // 0x140(0x38)
	struct TArray<uint64_t> pawn_state_list; // 0x178(0x10)
	int ai_kill_count; // 0x188(0x4)
	int Gender; // 0x18C(0x4)
	struct FString OpenID; // 0x190(0x10)
	bool has_gone; // 0x1A0(0x1)
	bool in_afk; // 0x1A1(0x1)
	uint8_t Pad_0x1A2[0x2]; // 0x1A2(0x2)
	int emote_id; // 0x1A4(0x4)
	int high_hp_destroy_bullet_num; // 0x1A8(0x4)
	int low_hp_destroy_bullet_num; // 0x1AC(0x4)
	int fatal_damage_destroy_bullet_num; // 0x1B0(0x4)
	struct FAIStateXYZ head_position; // 0x1B4(0xC)
	struct FAIStateXYZ muzzle_position; // 0x1C0(0xC)
	uint32_t ally_master_id; // 0x1CC(0x4)
	int first_lang_id; // 0x1D0(0x4)
	int received_fatal_destroy_bullet_num; // 0x1D4(0x4)
	int feature_id; // 0x1D8(0x4)
	uint8_t Pad_0x1DC[0x4]; // 0x1DC(0x4)
};

// Object: ScriptStruct AI.DiffStrAIAttributeList
// Size: 0x38 (Inherited: 0x18)
struct FDiffStrAIAttributeList : FAIStateInfoBase
{
	struct TArray<struct FStrAIAttribute> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.DiffBaseModGlobalGameState
// Size: 0xF0 (Inherited: 0x18)
struct FDiffBaseModGlobalGameState : FAIStateInfoBase
{
	struct FBaseModAIGameState Game; // 0x18(0x68)
	struct FDiffSpecialZoneStateList special_zones; // 0x80(0x38)
	struct FDiffBattleVoiceRoomInfoList voice_room_list; // 0xB8(0x38)
};

// Object: ScriptStruct AI.DiffBattleVoiceRoomInfoList
// Size: 0x38 (Inherited: 0x18)
struct FDiffBattleVoiceRoomInfoList : FAIStateInfoBase
{
	struct TArray<struct FBattleVoiceRoomInfo> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.BattleVoiceRoomInfo
// Size: 0x48 (Inherited: 0x20)
struct FBattleVoiceRoomInfo : FUniqueStateInfo
{
	uint32_t team_id; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString battle_voice_room_id; // 0x28(0x10)
	struct FString battle_voice_server_url; // 0x38(0x10)
};

// Object: ScriptStruct AI.DiffSpecialZoneStateList
// Size: 0x38 (Inherited: 0x18)
struct FDiffSpecialZoneStateList : FAIStateInfoBase
{
	struct TArray<struct FSpecialZoneState> Values; // 0x18(0x10)
	struct TArray<uint64_t> del_item_id; // 0x28(0x10)
};

// Object: ScriptStruct AI.SpecialZoneState
// Size: 0x88 (Inherited: 0x20)
struct FSpecialZoneState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	struct FAIStateXYZ Center; // 0x24(0xC)
	float Radius; // 0x30(0x4)
	uint32_t Type; // 0x34(0x4)
	struct FAIStateXYZ Position; // 0x38(0xC)
	struct FAIStateXYZ Rotation; // 0x44(0xC)
	int custom_state; // 0x50(0x4)
	struct FAIStateXYZ Scale; // 0x54(0xC)
	uint32_t extra_state; // 0x60(0x4)
	float Health; // 0x64(0x4)
	struct TArray<struct FAIAttribute> custom_attribute_list; // 0x68(0x10)
	struct TArray<struct FIntAIAttribute> int_custom_attribute_list; // 0x78(0x10)
};

// Object: ScriptStruct AI.BaseModAIGameState
// Size: 0x68 (Inherited: 0x18)
struct FBaseModAIGameState : FAIStateInfoBase
{
	bool is_over; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int alive_player_count; // 0x1C(0x4)
	int Stage; // 0x20(0x4)
	uint32_t mode_map; // 0x24(0x4)
	uint32_t mode_type; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString game_ds_version; // 0x30(0x10)
	int zone_id; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	uint64_t left_time; // 0x48(0x8)
	uint64_t stage_time; // 0x50(0x8)
	int can_jump_sky; // 0x58(0x4)
	int newbie_score; // 0x5C(0x4)
	int newbie_match_count; // 0x60(0x4)
	int mod_game_type; // 0x64(0x4)
};

// Object: ScriptStruct AI.DiffSpecialZoneState
// Size: 0xD8 (Inherited: 0x20)
struct FDiffSpecialZoneState : FUniqueStateInfo
{
	uint32_t ID; // 0x20(0x4)
	struct FAIStateXYZ Center; // 0x24(0xC)
	float Radius; // 0x30(0x4)
	uint32_t Type; // 0x34(0x4)
	struct FAIStateXYZ Position; // 0x38(0xC)
	struct FAIStateXYZ Rotation; // 0x44(0xC)
	int custom_state; // 0x50(0x4)
	struct FAIStateXYZ Scale; // 0x54(0xC)
	uint32_t extra_state; // 0x60(0x4)
	float Health; // 0x64(0x4)
	struct FDiffAIAttributeList custom_attribute_list; // 0x68(0x38)
	struct FDiffIntAIAttributeList int_custom_attribute_list; // 0xA0(0x38)
};

// Object: ScriptStruct AI.LandScapeGlobalGameInfo
// Size: 0x28 (Inherited: 0x18)
struct FLandScapeGlobalGameInfo : FAIStateInfoBase
{
	struct TArray<struct FLandScapeChangeState> landscape_change_info; // 0x18(0x10)
};

// Object: ScriptStruct AI.MPBaseGlobalGameState
// Size: 0x40 (Inherited: 0x18)
struct FMPBaseGlobalGameState : FAIStateInfoBase
{
	struct FMPBaseAIGameState Game; // 0x18(0x28)
};

// Object: ScriptStruct AI.MPBaseAIGameState
// Size: 0x28 (Inherited: 0x18)
struct FMPBaseAIGameState : FAIStateInfoBase
{
	struct TArray<struct FTeamScoreData> team_score_datas; // 0x18(0x10)
};

// Object: ScriptStruct AI.GlobalGameStateMPBase
// Size: 0x40 (Inherited: 0x18)
struct FGlobalGameStateMPBase : FAIStateInfoBase
{
	struct FMPBaseAIGameState Game; // 0x18(0x28)
};

// Object: ScriptStruct AI.BRBaseGlobalGameState
// Size: 0xF0 (Inherited: 0x18)
struct FBRBaseGlobalGameState : FAIStateInfoBase
{
	struct TArray<struct FAirDropBoxState> air_drop_box_states; // 0x18(0x10)
	struct TArray<struct FSpecialMeshState> special_meshes; // 0x28(0x10)
	struct FRedZoneState red_zone; // 0x38(0x30)
	struct FSafetyAreaState safety_area; // 0x68(0x48)
	struct TArray<struct FPlaneInfo> airplane_list; // 0xB0(0x10)
	struct FGlobalControlInfo control_info; // 0xC0(0x20)
	struct TArray<uint32_t> silent_list; // 0xE0(0x10)
};

// Object: ScriptStruct AI.NearbyMonsterGlobalGameState
// Size: 0x40 (Inherited: 0x18)
struct FNearbyMonsterGlobalGameState : FAIStateInfoBase
{
	struct FMonsterGlobalNearbyInfo global_nearby_info; // 0x18(0x28)
};

// Object: ScriptStruct AI.MonsterGlobalNearbyInfo
// Size: 0x28 (Inherited: 0x18)
struct FMonsterGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FMonsterState> monster_states; // 0x18(0x10)
};

// Object: ScriptStruct AI.DestructibleItemGlobalGameState
// Size: 0x40 (Inherited: 0x18)
struct FDestructibleItemGlobalGameState : FAIStateInfoBase
{
	struct FDestructibleItemGlobalNearbyInfo global_nearby_info; // 0x18(0x28)
};

// Object: ScriptStruct AI.DestructibleItemGlobalNearbyInfo
// Size: 0x28 (Inherited: 0x18)
struct FDestructibleItemGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FDestructibleItem> destructible_items; // 0x18(0x10)
};

// Object: ScriptStruct AI.DynamicItemGlobalGameState
// Size: 0x40 (Inherited: 0x18)
struct FDynamicItemGlobalGameState : FAIStateInfoBase
{
	struct FDynamicItemGlobalNearbyInfo global_nearby_info; // 0x18(0x28)
};

// Object: ScriptStruct AI.DynamicItemGlobalNearbyInfo
// Size: 0x28 (Inherited: 0x18)
struct FDynamicItemGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FDynamicItem> dynamic_items; // 0x18(0x10)
};

// Object: ScriptStruct AI.NearbyDoorGlobalGameState
// Size: 0x40 (Inherited: 0x18)
struct FNearbyDoorGlobalGameState : FAIStateInfoBase
{
	struct FDoorGlobalNearbyInfo global_nearby_info; // 0x18(0x28)
};

// Object: ScriptStruct AI.DoorGlobalNearbyInfo
// Size: 0x28 (Inherited: 0x18)
struct FDoorGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FDoorState> nearby_door; // 0x18(0x10)
};

// Object: ScriptStruct AI.VehicleGlobalGameState
// Size: 0x50 (Inherited: 0x18)
struct FVehicleGlobalGameState : FAIStateInfoBase
{
	struct FVehicleGlobalNearbyInfo global_nearby_info; // 0x18(0x28)
	struct TArray<struct FAIStateXYZ> vehicle_spot_position; // 0x40(0x10)
};

// Object: ScriptStruct AI.VehicleGlobalNearbyInfo
// Size: 0x28 (Inherited: 0x18)
struct FVehicleGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FVehicleState> nearby_vehicles; // 0x18(0x10)
};

// Object: ScriptStruct AI.VehicleDamageInfoContainer
// Size: 0x10 (Inherited: 0x0)
struct FVehicleDamageInfoContainer
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct AI.NearbyBaseGlobalGameState
// Size: 0x50 (Inherited: 0x18)
struct FNearbyBaseGlobalGameState : FAIStateInfoBase
{
	struct FBaseGlobalNearbyInfo global_nearby_info; // 0x18(0x38)
};

// Object: ScriptStruct AI.BaseGlobalNearbyInfo
// Size: 0x38 (Inherited: 0x18)
struct FBaseGlobalNearbyInfo : FAIStateInfoBase
{
	struct TArray<struct FItemStateData> nearby_item; // 0x18(0x10)
	struct TArray<struct FAINearbyThrown> nearby_thrown; // 0x28(0x10)
};

// Object: ScriptStruct AI.BaseModGlobalGameState
// Size: 0xA8 (Inherited: 0x18)
struct FBaseModGlobalGameState : FAIStateInfoBase
{
	struct FBaseModAIGameState Game; // 0x18(0x68)
	struct TArray<struct FSpecialZoneState> special_zones; // 0x80(0x10)
	struct TArray<struct FBattleVoiceRoomInfo> voice_room_list; // 0x90(0x10)
	uint8_t Pad_0xA0[0x8]; // 0xA0(0x8)
};

// Object: ScriptStruct AI.AIDamageSources
// Size: 0x48 (Inherited: 0x18)
struct FAIDamageSources : FAIStateInfoBase
{
	struct TArray<struct FAIStateXYZ> damage_source; // 0x18(0x10)
	struct TArray<int> damage_type; // 0x28(0x10)
	struct TArray<int> damage_weapon_type; // 0x38(0x10)
};

// Object: ScriptStruct AI.BulletHole
// Size: 0x18 (Inherited: 0x0)
struct FBulletHole
{
	struct FVector ImpactPoint; // 0x0(0xC)
	struct FVector SourcePoint; // 0xC(0xC)
};

// Object: ScriptStruct AI.BulletHoleRecordInfo
// Size: 0x28 (Inherited: 0x18)
struct FBulletHoleRecordInfo : FBulletHole
{
	struct APawn* ShootPawn; // 0x18(0x8)
	uint32_t ShooterId; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct AI.DebugAIParamConfig
// Size: 0x18 (Inherited: 0x0)
struct FDebugAIParamConfig
{
	int DistMin; // 0x0(0x4)
	int DistMax; // 0x4(0x4)
	struct FString NameAndDegree; // 0x8(0x10)
};

// Object: ScriptStruct AI.DiffCmd
// Size: 0x40 (Inherited: 0x0)
struct FDiffCmd
{
	struct UProperty* Property; // 0x0(0x8)
	struct UProperty* DiffProperty; // 0x8(0x8)
	struct UProperty* ValueProperty; // 0x10(0x8)
	struct UProperty* DelItemProperty; // 0x18(0x8)
	struct UProperty* UnChangedProperty; // 0x20(0x8)
	struct UProperty* DiffUnChangedProperty; // 0x28(0x8)
	uint8_t Pad_0x30[0x10]; // 0x30(0x10)
};

// Object: ScriptStruct AI.PropertyNameListIDMap
// Size: 0x50 (Inherited: 0x0)
struct FPropertyNameListIDMap
{
	struct TMap<struct FString, struct FDiffListIDMap> PropertyNameListIDMap; // 0x0(0x50)
};

// Object: ScriptStruct AI.DiffListIDMap
// Size: 0x50 (Inherited: 0x0)
struct FDiffListIDMap
{
	struct TMap<uint64_t, uint32_t> ListIDMap; // 0x0(0x50)
};

// Object: ScriptStruct AI.CollectorArray
// Size: 0x10 (Inherited: 0x0)
struct FCollectorArray
{
	struct TArray<struct UStateInfoCollectorBase*> Collectors; // 0x0(0x10)
};

// Object: ScriptStruct AI.CollectorInitInfo
// Size: 0x20 (Inherited: 0x0)
struct FCollectorInitInfo
{
	struct FString CollectorName; // 0x0(0x10)
	struct TArray<uint8_t> CollectPlayerType; // 0x10(0x10)
};

// Object: ScriptStruct AI.AIAttribute_CastEnergyWithCount
// Size: 0x1C (Inherited: 0x0)
struct FAIAttribute_CastEnergyWithCount
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
};

// Object: Class AI.AESpawner
// Size: 0x660 (Inherited: 0x618)
struct AAESpawner : ASTSpawnerBase
{
	struct FScriptMulticastDelegate OnUnitTakeDamage; // 0x618(0x10)
	uint8_t bEnableTeamAI : 1; // 0x628(0x1), Mask(0x1)
	uint8_t BitPad_0x628_1 : 7; // 0x628(0x1)
	uint8_t Pad_0x629[0x7]; // 0x629(0x7)
	struct TArray<struct UActorComponent*> TeamAIClasses; // 0x630(0x10)
	int SpawnerTeamID; // 0x640(0x4)
	enum class EBotCategray SpeciesCategory; // 0x644(0x1)
	uint8_t Pad_0x645[0x3]; // 0x645(0x3)
	int SpawnerCampItemID; // 0x648(0x4)
	int GroupID; // 0x64C(0x4)
	struct TArray<struct UActorComponent*> TeamAIComponents; // 0x650(0x10)


	// Object: Function AI.AESpawner.SwitchTeamAI
	// Flags: [Final|Native|Public]
	// Offset: 0x104784830
	// Params: [ Num(1) Size(0x1) ]
	void SwitchTeamAI(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10477AA60
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.AESpawner.OnUnitTakeDamageEvent
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1047846e0
	// Params: [ Num(4) Size(0x28) ]
	void OnUnitTakeDamageEvent(float Damage, struct FDamageEvent& DamageEvent, struct AActor* Victim, struct AActor* Causer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10477B1D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10477AA60
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function AI.AESpawner.OnUnitSpawned
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10478455c
	// Params: [ Num(3) Size(0xE8) ]
	void OnUnitSpawned(struct AActor* NewUnit, struct FSTSpawnParam& SpawnParam, struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.AESpawner.OnSpawnTimingRipe
	// Flags: [Native|Protected]
	// Offset: 0x1047844d0
	// Params: [ Num(1) Size(0x1) ]
	void OnSpawnTimingRipe(bool IsRipe);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x102B8C5A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168

	// Object: Function AI.AESpawner.OnOwnedMobDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104784304
	// Params: [ Num(6) Size(0xB8) ]
	void OnOwnedMobDead(struct ASTExtraSimpleCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AD04
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AESpawner.OnOwnedFakePlayerDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104784138
	// Params: [ Num(6) Size(0xB8) ]
	void OnOwnedFakePlayerDead(struct ASTExtraBaseCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AI.AESpawner.GetSpeciesCategory
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10478411c
	// Params: [ Num(1) Size(0x1) ]
	enum class EBotCategray GetSpeciesCategory();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AI.AESpawner.GetSpawnerTeamID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047840fc
	// Params: [ Num(1) Size(0x4) ]
	float GetSpawnerTeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0
	// [Call #15] RVA: 0x10516D168

	// Object: Function AI.AESpawner.GetSpawnerGroupID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047840dc
	// Params: [ Num(1) Size(0x4) ]
	float GetSpawnerGroupID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0

	// Object: Function AI.AESpawner.GenerateParamID
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(4) Size(0xE4) ]
	int GenerateParamID(int ConfigID, int BaseParamID, struct FSTSpawnParam& SpawnParam);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AI.AESpawner.DeactivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047840c0
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0

	// Object: Function AI.AESpawner.BPOnUnitSpawned
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xE0) ]
	void BPOnUnitSpawned(struct APawn* AIPawn, int ConfigID, struct FSTSpawnParam& SpawnParam);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AI.AESpawner.ActivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047840a4
	// Params: [ Num(0) Size(0x0) ]
	void ActivateSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10477AEB0
};

// Object: Class AI.AESpawnSubsystem
// Size: 0x3D0 (Inherited: 0x1D0)
struct UAESpawnSubsystem : USTSpawnSubsystem
{
	DelegateProperty OnCustomSpawnPreCheck; // 0x1C8(0x10)
	uint8_t bPopQueAfterCustomPreCheckFailed : 1; // 0x1D8(0x1), Mask(0x1)
	struct FMonsterParams CacheMobParams; // 0x1E0(0x60)
	struct FFakePlayerParams CacheFPParams; // 0x240(0x14)
	struct FAIPlayerParams CacheAIPParams; // 0x254(0xC)
	struct FVehicleParams CacheVehicleParams; // 0x260(0x14)
	uint8_t BitPad_0x274_1 : 7; // 0x274(0x1)
	uint8_t Pad_0x275[0x3]; // 0x275(0x3)
	struct FDecoratorParams CacheDecoratorParams; // 0x278(0x18)
	struct TMap<enum class EBotCategray, int> UnitsNumberThreshold; // 0x290(0x50)
	uint8_t Pad_0x2E0[0xF0]; // 0x2E0(0xF0)


	// Object: Function AI.AESpawnSubsystem.SpawnUnit
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x104785350
	// Params: [ Num(2) Size(0xD8) ]
	struct AActor* SpawnUnit(struct FSTSpawnParam SpawnParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B8CFE8
	// [Call #4] RVA: 0x102B8C5A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.AESpawnSubsystem.RegisterSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047852cc
	// Params: [ Num(1) Size(0x8) ]
	void RegisterSpawner(struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8CFE8
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function AI.AESpawnSubsystem.PreCheck
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x104785290
	// Params: [ Num(1) Size(0x1) ]
	bool PreCheck();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8CFE8
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.AESpawnSubsystem.ModifyThreshold
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1047851d8
	// Params: [ Num(2) Size(0x8) ]
	void ModifyThreshold(enum class EBotCategray Category, int Threshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10477BC88
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B8CFE8
	// [Call #11] RVA: 0x102B8C5A4

	// Object: Function AI.AESpawnSubsystem.GetUnitsNumByCategory
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10478514c
	// Params: [ Num(2) Size(0x8) ]
	int GetUnitsNumByCategory(enum class EBotCategray Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10477BB50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10477BC88
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function AI.AESpawnSubsystem.GetUnitConfigID
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047850b8
	// Params: [ Num(2) Size(0xC) ]
	int GetUnitConfigID(struct AActor* Unit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10477BB50
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10477BC88
	// [Call #11] RVA: 0x10516D168

	// Object: Function AI.AESpawnSubsystem.GetGroupedSpawners
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104785004
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct ASTSpawnerBase*> GetGroupedSpawners(int InGroupID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10477CAAC
	// [Call #4] RVA: 0x10478A8D4
	// [Call #5] RVA: 0x1047813C4
	// [Call #6] RVA: 0x1047813C4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10477BB50
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function AI.AESpawnSubsystem.EnQueue
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104784ebc
	// Params: [ Num(2) Size(0xD8) ]
	void EnQueue(struct FSTSpawnParam& SpawnParam, struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10477CAAC
	// [Call #11] RVA: 0x10478A8D4
	// [Call #12] RVA: 0x1047813C4
	// [Call #13] RVA: 0x1047813C4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AESpawnSubsystem.CleanQueue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104784ea0
	// Params: [ Num(0) Size(0x0) ]
	void CleanQueue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10477CAAC
	// [Call #11] RVA: 0x10478A8D4
	// [Call #12] RVA: 0x1047813C4
	// [Call #13] RVA: 0x1047813C4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function AI.AESpawnSubsystem.CheckCategoryLimit
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x104784dc0
	// Params: [ Num(3) Size(0xD) ]
	bool CheckCategoryLimit(struct ASTSpawnerBase* Spawner, int& AvailableBalance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x102B8C5A4
	// [Call #11] RVA: 0x106C8459C
};

// Object: Class AI.AIActionExecutionComponent
// Size: 0x270 (Inherited: 0x238)
struct UAIActionExecutionComponent : ULuaActorComponent
{
	struct AController* OwnerController; // 0x238(0x8)
	struct ANewFakePlayerAIController* MyAIController; // 0x240(0x8)
	struct ASTExtraPlayerController* MyPlayerController; // 0x248(0x8)
	struct ASTExtraBaseCharacter* MyPlayerPawn; // 0x250(0x8)
	struct UMLAIControllerComponent* MyMLAIControllerComp; // 0x258(0x8)
	uint8_t Pad_0x260[0x10]; // 0x260(0x10)


	// Object: Function AI.AIActionExecutionComponent.UseItem
	// Flags: [Final|Native|Public]
	// Offset: 0x1047865f8
	// Params: [ Num(2) Size(0x8) ]
	void UseItem(int ItemId, int WeaponSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469CB04
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.AIActionExecutionComponent.SwapAttachmentItem
	// Flags: [Final|Native|Public]
	// Offset: 0x104786508
	// Params: [ Num(3) Size(0xC) ]
	void SwapAttachmentItem(int ItemId, int SourceWeaponSlot, int TargetWeaponSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469CC3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10469CB04
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function AI.AIActionExecutionComponent.SetGrenadeLastSelectID
	// Flags: [Final|Native|Public]
	// Offset: 0x10478648c
	// Params: [ Num(1) Size(0x4) ]
	void SetGrenadeLastSelectID(int WeaponId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469D094
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469CC3C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10469CB04
	// [Call #16] RVA: 0x10519022C

	// Object: Function AI.AIActionExecutionComponent.SetFocusRotation
	// Flags: [Final|Native|Public]
	// Offset: 0x10478639c
	// Params: [ Num(3) Size(0xC) ]
	void SetFocusRotation(float InPitch, float InYaw, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469BE90
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469D094
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10469CC3C

	// Object: Function AI.AIActionExecutionComponent.SetCurShootingPose
	// Flags: [Final|Native|Public]
	// Offset: 0x104786388
	// Params: [ Num(0) Size(0x0) ]
	void SetCurShootingPose();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469BE90
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469D094
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.RescueTarget
	// Flags: [Final|Native|Public]
	// Offset: 0x10478630c
	// Params: [ Num(1) Size(0x8) ]
	void RescueTarget(struct ASTExtraBaseCharacter* RescueCharacter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469CCC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469BE90
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10469D094
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.OpenFixedRateOfDoors
	// Flags: [Final|Native|Public]
	// Offset: 0x10478621c
	// Params: [ Num(3) Size(0xC) ]
	void OpenFixedRateOfDoors(float fCheckRealPlayerDistance, float fOpenDoorDistance, float fOpenDoorRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469CE18
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469CCC4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.OpenDoor
	// Flags: [Final|Native|Public]
	// Offset: 0x104786208
	// Params: [ Num(0) Size(0x0) ]
	void OpenDoor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469CE18
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469CCC4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.OnPlayerRespawn
	// Flags: [Final|Native|Public]
	// Offset: 0x10478618c
	// Params: [ Num(1) Size(0x8) ]
	void OnPlayerRespawn(struct AUAEPlayerController* PC);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469B778
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469CE18
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10469CCC4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.AIActionExecutionComponent.OnFakePlayerRespawn
	// Flags: [Final|Native|Public]
	// Offset: 0x104786178
	// Params: [ Num(0) Size(0x0) ]
	void OnFakePlayerRespawn();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469B778
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469CE18
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10469CCC4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.AIActionExecutionComponent.IsValid
	// Flags: [Final|Native|Public]
	// Offset: 0x104786144
	// Params: [ Num(1) Size(0x1) ]
	bool IsValid();
	// [Call #1] RVA: 0x10469CF64
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10469B778
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10469CE18
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10469CCC4

	// Object: Function AI.AIActionExecutionComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	// Offset: 0x104786110
	// Params: [ Num(1) Size(0x1) ]
	bool IsFreeCamera();
	// [Call #1] RVA: 0x10469C9E8
	// [Call #2] RVA: 0x10469CF64
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469B778
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10469CE18
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	// Offset: 0x104786084
	// Params: [ Num(2) Size(0x10) ]
	struct APickUpWrapperActor* GetPickActorWithID(int UID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469C1B8
	// [Call #4] RVA: 0x10469C9E8
	// [Call #5] RVA: 0x10469CF64
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10469B778
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.GetOwnerBaseCharacter
	// Flags: [Final|Native|Public]
	// Offset: 0x104786050
	// Params: [ Num(1) Size(0x8) ]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter();
	// [Call #1] RVA: 0x10469CFE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10469C1B8
	// [Call #5] RVA: 0x10469C9E8
	// [Call #6] RVA: 0x10469CF64
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469B778
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.GetBackpackComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x10478601c
	// Params: [ Num(1) Size(0x8) ]
	struct UBackpackComponent* GetBackpackComponent();
	// [Call #1] RVA: 0x10469CB68
	// [Call #2] RVA: 0x10469CFE0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469C1B8
	// [Call #6] RVA: 0x10469C9E8
	// [Call #7] RVA: 0x10469CF64
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469B778
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.DropItem
	// Flags: [Final|Native|Public]
	// Offset: 0x104785f68
	// Params: [ Num(2) Size(0x8) ]
	void DropItem(int ItemId, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469CB78
	// [Call #6] RVA: 0x10469CB68
	// [Call #7] RVA: 0x10469CFE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469C1B8
	// [Call #11] RVA: 0x10469C9E8
	// [Call #12] RVA: 0x10469CF64
	// [Call #13] RVA: 0x10516D168

	// Object: Function AI.AIActionExecutionComponent.DoActionQuickMark
	// Flags: [Final|Native|Public]
	// Offset: 0x104785e78
	// Params: [ Num(3) Size(0xC) ]
	void DoActionQuickMark(int actorUID, int ItemId, int CheckRange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469C5EC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10469CB78
	// [Call #13] RVA: 0x10469CB68
	// [Call #14] RVA: 0x10469CFE0
	// [Call #15] RVA: 0x10516D168

	// Object: Function AI.AIActionExecutionComponent.DoActionMoveNew
	// Flags: [Final|Native|Public]
	// Offset: 0x104785cbc
	// Params: [ Num(6) Size(0x14) ]
	void DoActionMoveNew(bool IsStop, bool IsRun, float DirectionX, float DirectionY, float DirectionZ, int SwimUpRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10469BBC8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.DoActionMove
	// Flags: [Final|Native|Public]
	// Offset: 0x104785b80
	// Params: [ Num(4) Size(0x10) ]
	void DoActionMove(bool IsRun, float DirectionX, float DirectionY, float DirectionZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469BC04
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	// Offset: 0x104785a44
	// Params: [ Num(4) Size(0x10) ]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469C1DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.DisuseItem
	// Flags: [Final|Native|Public]
	// Offset: 0x104785990
	// Params: [ Num(2) Size(0x8) ]
	void DisuseItem(int ItemId, int WeaponSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469CBD8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10469C1DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIActionExecutionComponent.CloseDoor
	// Flags: [Final|Native|Public]
	// Offset: 0x10478597c
	// Params: [ Num(0) Size(0x0) ]
	void CloseDoor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469CBD8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10469C1DC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class AI.AIBasicStateInfoComponent
// Size: 0x238 (Inherited: 0x238)
struct UAIBasicStateInfoComponent : ULuaActorComponent
{

	// Object: Function AI.AIBasicStateInfoComponent.OnItemStateChanged
	// Flags: [Native|Public|HasDefaults]
	// Offset: 0x104786f50
	// Params: [ Num(1) Size(0xC) ]
	void OnItemStateChanged(struct FVector Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10516EACC

	// Object: Function AI.AIBasicStateInfoComponent.GetPickActorWithID
	// Flags: [Native|Public]
	// Offset: 0x104786ebc
	// Params: [ Num(2) Size(0x10) ]
	struct APickUpWrapperActor* GetPickActorWithID(int UID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
};

// Object: Class AI.AIBehaviorAdapter_VehicleBase
// Size: 0x390 (Inherited: 0x258)
struct UAIBehaviorAdapter_VehicleBase : UVehicleComponent
{
	float LoseSightRadius; // 0x258(0x4)
	float QueryEnemyRange; // 0x25C(0x4)
	float QueryEnemyAngle; // 0x260(0x4)
	float MinTimeLockTarget; // 0x264(0x4)
	float MaxRememberEnemySeconds; // 0x268(0x4)
	float PreciseHatredDecreaseSpeed; // 0x26C(0x4)
	uint8_t bCorrectAfterTurnOver : 1; // 0x270(0x1), Mask(0x1)
	uint8_t BitPad_0x270_1 : 7; // 0x270(0x1)
	uint8_t Pad_0x271[0x3]; // 0x271(0x3)
	float CorrectAfterTurnOverCD; // 0x274(0x4)
	float FollowSegmentTolerance; // 0x278(0x4)
	uint8_t Pad_0x27C[0x4]; // 0x27C(0x4)
	struct UCurveFloat* CurveThrottleInput; // 0x280(0x8)
	float MinAngleWhenPivotSteering; // 0x288(0x4)
	uint8_t Pad_0x28C[0x4]; // 0x28C(0x4)
	struct UCurveFloat* CurveThrottleRateWhenTurning; // 0x290(0x8)
	struct UCurveFloat* CurveSteeringInput; // 0x298(0x8)
	bool bUseBrakeWhenTurning; // 0x2A0(0x1)
	uint8_t Pad_0x2A1[0x3]; // 0x2A1(0x3)
	float MinRequiredSteeringChange; // 0x2A4(0x4)
	float MinLengthRateAlmostReach; // 0x2A8(0x4)
	uint8_t Pad_0x2AC[0x4]; // 0x2AC(0x4)
	struct UCurveFloat* CurveBrakeAlmostReach; // 0x2B0(0x8)
	float SteeringThresholdUseBrake; // 0x2B8(0x4)
	float SpeedThresholdUseBrake; // 0x2BC(0x4)
	uint8_t bBlockTest : 1; // 0x2C0(0x1), Mask(0x1)
	uint8_t BitPad_0x2C0_1 : 7; // 0x2C0(0x1)
	uint8_t Pad_0x2C1[0x3]; // 0x2C1(0x3)
	float BlockTestingTime; // 0x2C4(0x4)
	float BlockSpeedThresholdKMH; // 0x2C8(0x4)
	uint8_t Pad_0x2CC[0x4]; // 0x2CC(0x4)
	struct APlayerTombBox* DeadInventoryBoxTemplate; // 0x2D0(0x8)
	int DropID; // 0x2D8(0x4)
	uint8_t Pad_0x2DC[0x4]; // 0x2DC(0x4)
	struct FName WrapperBoxName; // 0x2E0(0x8)
	struct APlayerTombBox* DeadTombBox; // 0x2E8(0x8)
	bool bDebug; // 0x2F0(0x1)
	uint8_t Pad_0x2F1[0x3]; // 0x2F1(0x3)
	int DebugLevel; // 0x2F4(0x4)
	float DebugInterval; // 0x2F8(0x4)
	uint8_t Pad_0x2FC[0x4]; // 0x2FC(0x4)
	struct FString BehaviorServiceDebugInfo; // 0x300(0x10)
	uint8_t Pad_0x310[0x50]; // 0x310(0x50)
	struct ASTExtraVehicleBase* OwnerVehicle; // 0x360(0x8)
	uint8_t bCacheMeshOnHit : 1; // 0x368(0x1), Mask(0x1)
	uint8_t BitPad_0x368_1 : 7; // 0x368(0x1)
	uint8_t Pad_0x369[0x27]; // 0x369(0x27)


	// Object: Function AI.AIBehaviorAdapter_VehicleBase.Suicide
	// Flags: [Native|Public]
	// Offset: 0x1047880e4
	// Params: [ Num(0) Size(0x0) ]
	void Suicide();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.RPC_Client_SetServiceDebugInfo
	// Flags: [Net|Native|Event|NetMulticast|Protected]
	// Offset: 0x104788044
	// Params: [ Num(1) Size(0x10) ]
	void RPC_Client_SetServiceDebugInfo(struct FString Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.OnInit
	// Flags: [Native|Public]
	// Offset: 0x104788028
	// Params: [ Num(0) Size(0x0) ]
	void OnInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.OnDeath
	// Flags: [Native|Public]
	// Offset: 0x104787fa4
	// Params: [ Num(1) Size(0x8) ]
	void OnDeath(struct AController* InstigatedBy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.OnAICPossessed
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void OnAICPossessed(struct AController* InController);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.LuaCalculateHitRate
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	float LuaCalculateHitRate(float Distance, float BaseHitRate);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.IsAlive
	// Flags: [Native|Public|Const]
	// Offset: 0x104787f68
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.HandleOnVehicleUnderAttack
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104787ddc
	// Params: [ Num(5) Size(0x28) ]
	void HandleOnVehicleUnderAttack(struct AController* EventInstigator, struct FDamageEvent& DamageEvent, struct AActor* DamageCauser, float Damage, float OriginDamage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104691BB8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.HandleOnVehicleHealthStateChanged
	// Flags: [Native|Protected]
	// Offset: 0x104787d58
	// Params: [ Num(1) Size(0x1) ]
	void HandleOnVehicleHealthStateChanged(uint8_t InVehicleHealthState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104691BB8

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.HandleOnMeshHit
	// Flags: [Native|Protected|HasOutParms|HasDefaults]
	// Offset: 0x104787bc8
	// Params: [ Num(5) Size(0xB0) ]
	void HandleOnMeshHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.BroadcastServiceDebugInfo
	// Flags: [Native|Public]
	// Offset: 0x104787bac
	// Params: [ Num(0) Size(0x0) ]
	void BroadcastServiceDebugInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function AI.AIBehaviorAdapter_VehicleBase.BPReceiveDamage
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x21) ]
	void BPReceiveDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser, enum class EDamageType DamageEventType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class AI.AIBehaviorAdapter_Tank
// Size: 0x488 (Inherited: 0x390)
struct UAIBehaviorAdapter_Tank : UAIBehaviorAdapter_VehicleBase
{
	struct UCurveFloat* AimDurationCurve; // 0x390(0x8)
	struct FVector2D AimDurationDeviation; // 0x398(0x8)
	float ShootTurretCD; // 0x3A0(0x4)
	float BulletExplosionRange; // 0x3A4(0x4)
	float AimingLockRange; // 0x3A8(0x4)
	float AimingLockRangeWhenFiring; // 0x3AC(0x4)
	struct FVector2D TurretAimRange; // 0x3B0(0x8)
	uint8_t bPredictEnemyMove : 1; // 0x3B8(0x1), Mask(0x1)
	uint8_t BitPad_0x3B8_1 : 7; // 0x3B8(0x1)
	uint8_t Pad_0x3B9[0x3]; // 0x3B9(0x3)
	struct FVector2D TurretShootRange; // 0x3BC(0x8)
	uint8_t bAimingConstantLerp : 1; // 0x3C4(0x1), Mask(0x1)
	uint8_t BitPad_0x3C4_1 : 7; // 0x3C4(0x1)
	uint8_t Pad_0x3C5[0x3]; // 0x3C5(0x3)
	float TurretAimingInterpConstantSpeed; // 0x3C8(0x4)
	float TurretAimingInterpSpeed; // 0x3CC(0x4)
	float SimTurretAimingInterpConstantSpeed; // 0x3D0(0x4)
	float TurretAimingErrorTolerance; // 0x3D4(0x4)
	uint8_t bAlsoCheckArcLength : 1; // 0x3D8(0x1), Mask(0x1)
	uint8_t BitPad_0x3D8_1 : 7; // 0x3D8(0x1)
	uint8_t Pad_0x3D9[0x3]; // 0x3D9(0x3)
	float ShootTargetLocationOffset; // 0x3DC(0x4)
	uint8_t bTraceBlockShootTargetLocation : 1; // 0x3E0(0x1), Mask(0x1)
	uint8_t BitPad_0x3E0_1 : 7; // 0x3E0(0x1)
	uint8_t Pad_0x3E1[0x3]; // 0x3E1(0x3)
	int MaxTraceBlockTryTimes; // 0x3E4(0x4)
	uint8_t bResetTurretAfterDestroy : 1; // 0x3E8(0x1), Mask(0x1)
	uint8_t bFailedAimingWhenTurretCollided : 1; // 0x3E8(0x1), Mask(0x2)
	uint8_t BitPad_0x3E8_2 : 6; // 0x3E8(0x1)
	uint8_t Pad_0x3E9[0x7]; // 0x3E9(0x7)
	struct TMap<float, float> BaseHitRate; // 0x3F0(0x50)
	float ShootMGCD; // 0x440(0x4)
	struct FVector2D ShootMGDuration; // 0x444(0x8)
	float ShootMGInterval; // 0x44C(0x4)
	struct FVector2D ShootUpDownRange; // 0x450(0x8)
	struct FVector2D ShootLeftRightRange; // 0x458(0x8)
	struct FVector2D ShootLeftRightRangeDistance; // 0x460(0x8)
	struct FVector2D ShootTargetSpeedRange; // 0x468(0x8)
	struct FVector2D ShootTargetDistanceRangeDueToSpeed; // 0x470(0x8)
	struct FVector2D MGShootRange; // 0x478(0x8)
	uint8_t bShouldMissOnPurpose : 1; // 0x480(0x1), Mask(0x1)
	uint8_t bCacheUsingMG : 1; // 0x480(0x1), Mask(0x2)
	uint8_t bCacheUsingTurret : 1; // 0x480(0x1), Mask(0x4)
	uint8_t BitPad_0x480_3 : 5; // 0x480(0x1)
	uint8_t Pad_0x481[0x7]; // 0x481(0x7)


	// Object: Function AI.AIBehaviorAdapter_Tank.UpdateTurretAimingTarget
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1047874f0
	// Params: [ Num(4) Size(0x12) ]
	bool UpdateTurretAimingTarget(struct FVector& TargetLocation, float DeltaSeconds, bool FailedWhenCollided);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104690FE4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_Tank.ShootTurret
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047874bc
	// Params: [ Num(1) Size(0x1) ]
	bool ShootTurret();
	// [Call #1] RVA: 0x104690814
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104690FE4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_Tank.ShootMachineGun
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104787488
	// Params: [ Num(1) Size(0x1) ]
	bool ShootMachineGun();
	// [Call #1] RVA: 0x10469088C
	// [Call #2] RVA: 0x104690814
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104690FE4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_Tank.OnInit
	// Flags: [Native|Public]
	// Offset: 0x10478746c
	// Params: [ Num(0) Size(0x0) ]
	void OnInit();
	// [Call #1] RVA: 0x10469088C
	// [Call #2] RVA: 0x104690814
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104690FE4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function AI.AIBehaviorAdapter_Tank.OnDeath
	// Flags: [Native|Public]
	// Offset: 0x1047873e8
	// Params: [ Num(1) Size(0x8) ]
	void OnDeath(struct AController* InstigatedBy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469088C
	// [Call #4] RVA: 0x104690814
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104690FE4
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.AIBehaviorAdapter_Tank.IsTurretLockTarget
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104787314
	// Params: [ Num(3) Size(0x11) ]
	bool IsTurretLockTarget(struct FVector& TargetLocation, float LockRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469178C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10469088C
	// [Call #9] RVA: 0x104690814
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function AI.AIBehaviorAdapter_Tank.IsAlive
	// Flags: [Native|Public|Const]
	// Offset: 0x1047872d8
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10469178C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10469088C
	// [Call #9] RVA: 0x104690814
	// [Call #10] RVA: 0x10516D168

	// Object: Function AI.AIBehaviorAdapter_Tank.HandleOnVehicleHealthStateChanged
	// Flags: [Native|Public]
	// Offset: 0x104787254
	// Params: [ Num(1) Size(0x1) ]
	void HandleOnVehicleHealthStateChanged(uint8_t InVehicleHealthState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469178C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10469088C

	// Object: Function AI.AIBehaviorAdapter_Tank.BroadcastTankShootWeapon
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x1047871c8
	// Params: [ Num(1) Size(0x1) ]
	void BroadcastTankShootWeapon(bool IsTurret);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469178C
	// [Call #10] RVA: 0x10516D168
};

// Object: Class AI.AIPerceptionChildPickUpComponent
// Size: 0x288 (Inherited: 0x238)
struct UAIPerceptionChildPickUpComponent : ULuaActorComponent
{
	struct TSet<struct APickUpWrapperActor*> ChildPickUpWrapperActors; // 0x238(0x50)


	// Object: Function AI.AIPerceptionChildPickUpComponent.OnPickUpWrapperHideStateChange
	// Flags: [Final|Native|Public]
	// Offset: 0x104788560
	// Params: [ Num(2) Size(0x9) ]
	void OnPickUpWrapperHideStateChange(struct APickUpWrapperActor* PickUpActor, bool bHide);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046DD88C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x104783E8C
	// [Call #10] RVA: 0x105184F34
};

// Object: Class AI.AIPerceptionDynamicItemComponent
// Size: 0x3C8 (Inherited: 0x238)
struct UAIPerceptionDynamicItemComponent : ULuaActorComponent
{
	int Category; // 0x234(0x4)
	struct TArray<struct FChildDynamicItem> ChildArray; // 0x238(0x10)
	DelegateProperty GetDynamicItemDurabilityDelegate; // 0x248(0x10)
	bool CheckVisible; // 0x258(0x1)
	uint8_t Pad_0x25D[0x3]; // 0x25D(0x3)
	struct TArray<struct UStaticMeshComponent*> CheckVisibleMeshComponents; // 0x260(0x10)
	uint32_t CustomUInt32State; // 0x270(0x4)
	uint8_t Pad_0x274[0x4]; // 0x274(0x4)
	struct TMap<uint32_t, float> CustomAttributeMap; // 0x278(0x50)
	struct TMap<uint32_t, uint64_t> IntCustomAttributeMap; // 0x2C8(0x50)
	uint8_t Pad_0x318[0x10]; // 0x318(0x10)
	bool IsMovable; // 0x328(0x1)
	bool IsCheckVisAngle; // 0x329(0x1)
	bool IsFireSpreadingCalCenter; // 0x32A(0x1)
	bool bEnableState; // 0x32B(0x1)
	bool bIsDestructibleItem; // 0x32C(0x1)
	bool bUseMeshMapping; // 0x32D(0x1)
	uint8_t Pad_0x32E[0x7A]; // 0x32E(0x7A)
	struct UPhotonDestructibleMeshComponent* CachedDestructComp; // 0x3A8(0x8)
	struct UDamageableComponentBase* CachedDamageableComp; // 0x3B0(0x8)
	struct ASTExtraBaseCharacter* CachedCharacterOwner; // 0x3B8(0x8)
	uint8_t Pad_0x3C0[0x8]; // 0x3C0(0x8)


	// Object: Function AI.AIPerceptionDynamicItemComponent.UpdateIntCustomAttributeValue
	// Flags: [Final|Native|Public]
	// Offset: 0x104788c6c
	// Params: [ Num(3) Size(0x11) ]
	void UpdateIntCustomAttributeValue(uint32_t InCustomAttributeID, uint64_t InValue, bool bRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DE4A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.AIPerceptionDynamicItemComponent.UpdateInAICell
	// Flags: [Final|Native|Public]
	// Offset: 0x104788be8
	// Params: [ Num(1) Size(0x1) ]
	void UpdateInAICell(bool bForceUpdate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DDC1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DE4A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AI.AIPerceptionDynamicItemComponent.UpdateCustomAttributeValue
	// Flags: [Final|Native|Public]
	// Offset: 0x104788aec
	// Params: [ Num(3) Size(0x9) ]
	void UpdateCustomAttributeValue(uint32_t InCustomAttributeID, float InValue, bool bRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DE2EC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DDC1C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIPerceptionDynamicItemComponent.SetEnableState
	// Flags: [Final|Native|Public]
	// Offset: 0x104788a68
	// Params: [ Num(1) Size(0x1) ]
	void SetEnableState(bool bInEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE520
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DE2EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DDC1C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.AIPerceptionDynamicItemComponent.RemoveInAICell
	// Flags: [Final|Native|Public]
	// Offset: 0x104788a54
	// Params: [ Num(0) Size(0x0) ]
	void RemoveInAICell();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE520
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DE2EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DDC1C
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.AIPerceptionDynamicItemComponent.RemoveFromCache
	// Flags: [Final|Native|Public]
	// Offset: 0x104788a40
	// Params: [ Num(0) Size(0x0) ]
	void RemoveFromCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE520
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DE2EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DDC1C

	// Object: Function AI.AIPerceptionDynamicItemComponent.OnMeshAssetSet
	// Flags: [Final|Native|Public]
	// Offset: 0x104788a2c
	// Params: [ Num(0) Size(0x0) ]
	void OnMeshAssetSet();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE520
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DE2EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DDC1C

	// Object: Function AI.AIPerceptionDynamicItemComponent.GetUniqueID
	// Flags: [Final|Native|Public]
	// Offset: 0x1047889a0
	// Params: [ Num(2) Size(0xC) ]
	uint32_t GetUniqueID(struct AActor* DynamicItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DECA4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046DE520
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DE2EC

	// Object: Function AI.AIPerceptionDynamicItemComponent.GetIntCustomAttributeList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047888f8
	// Params: [ Num(1) Size(0x10) ]
	void GetIntCustomAttributeList(struct TArray<struct FIntAIAttribute>& OutIntCustomAttributeList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE370
	// [Call #4] RVA: 0x1046AFCC0
	// [Call #5] RVA: 0x1046AFCC0
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DECA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046DE520
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.AIPerceptionDynamicItemComponent.GetCustomAttributeList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104788850
	// Params: [ Num(1) Size(0x10) ]
	void GetCustomAttributeList(struct TArray<struct FAIAttribute>& OutCustomAttributeList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DE1C4
	// [Call #4] RVA: 0x1046AFD10
	// [Call #5] RVA: 0x1046AFD10
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DE370
	// [Call #10] RVA: 0x1046AFCC0
	// [Call #11] RVA: 0x1046AFCC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046DECA4
	// [Call #16] RVA: 0x10516D168
};

// Object: Class AI.AISoundCollectionComponent
// Size: 0x3B8 (Inherited: 0x238)
struct UAISoundCollectionComponent : ULuaActorComponent
{
	struct TMap<uint32_t, struct FCacheSoundState> CacheStepSounds; // 0x238(0x50)
	struct TMap<uint32_t, struct FCacheSoundState> CacheWeaponSounds; // 0x288(0x50)
	struct TMap<uint32_t, struct FCacheSoundState> CacheVehicleSounds; // 0x2D8(0x50)
	struct TMap<uint32_t, struct FCacheSoundState> CacheGrenadeSounds; // 0x328(0x50)
	uint8_t Pad_0x378[0x18]; // 0x378(0x18)
	float ClearStepSoundTime; // 0x390(0x4)
	float ClearWeaponSoundTime; // 0x394(0x4)
	float ClearVehicleSoundTime; // 0x398(0x4)
	float ClearGrenadeSoundTime; // 0x39C(0x4)
	int StepSoundMaxNum; // 0x3A0(0x4)
	int WeaponSoundMaxNum; // 0x3A4(0x4)
	int VehicleSoundMaxNum; // 0x3A8(0x4)
	int GrenadeSoundMaxNum; // 0x3AC(0x4)
	struct AController* OwnerController; // 0x3B0(0x8)


	// Object: Function AI.AISoundCollectionComponent.OnCollectionHearSound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1047894a8
	// Params: [ Num(3) Size(0x18) ]
	void OnCollectionHearSound(uint8_t SoundType, struct FVector& InPos, struct AActor* InSourceActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10469D21C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.AISoundCollectionComponent.OnAISoundManagerHear
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104789364
	// Params: [ Num(4) Size(0x20) ]
	void OnAISoundManagerHear(struct AActor* InTargetActor, uint8_t SoundType, struct FVector& InPos, struct AActor* InSourceActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469D71C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10469D21C

	// Object: Function AI.AISoundCollectionComponent.GetCollectSoundInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104789300
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FSoundState> GetCollectSoundInfo();
	// [Call #1] RVA: 0x10469D950
	// [Call #2] RVA: 0x1046E7000
	// [Call #3] RVA: 0x1046B2AA4
	// [Call #4] RVA: 0x1046B2AA4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10469D71C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class AI.AIStateInfoComponentBase
// Size: 0x348 (Inherited: 0x238)
struct UAIStateInfoComponentBase : UAIBasicStateInfoComponent
{
	bool IsTouchedPlayer; // 0x231(0x1)
	uint32_t FrameNo; // 0x234(0x4)
	struct ASTExtraPlayerController* MyPlayerController; // 0x238(0x8)
	int SkipFrameConfig; // 0x240(0x4)
	int SkipFrameConfigSecond; // 0x244(0x4)
	struct AController* OwnerController; // 0x248(0x8)
	struct ANewFakePlayerAIController* MyAIController; // 0x250(0x8)
	struct UAIActingComponent* AIActingComp; // 0x258(0x8)
	struct APawn* MyOwnerPawn; // 0x260(0x8)
	struct ABattleRoyaleGameModeBase* MyGameMode; // 0x268(0x8)
	struct TArray<struct FDamageSource> DamageSourcesInfoNew; // 0x270(0x10)
	struct TMap<int, struct APickUpWrapperActor*> CacheAINearbyItem; // 0x280(0x50)
	struct TArray<struct ASTExtraBaseCharacter*> CacheNearbyEnemies; // 0x2D0(0x10)
	struct FCacheNearbyItemState CacheNearbyItemState; // 0x2E0(0x20)
	struct UMLAIControllerComponent* MyMLAIControllerComp; // 0x300(0x8)
	uint32_t CacheModeMapId; // 0x308(0x4)
	uint8_t Pad_0x311[0x7]; // 0x311(0x7)
	struct UMLAISubSystem* MLAISubSystem; // 0x318(0x8)
	struct UAIStateInfoDataAsset* AIStateInfoDataAsset; // 0x320(0x8)
	struct UMLAIStateInfoManager* MLAIStateInfoManager; // 0x328(0x8)
	struct AAIWorldVolume* AIWorldVolume; // 0x330(0x8)
	uint8_t Pad_0x338[0x10]; // 0x338(0x10)


	// Object: Function AI.AIStateInfoComponentBase.QueryItemStates
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104789e94
	// Params: [ Num(14) Size(0x48) ]
	void QueryItemStates(int MaxBoxNum, int MaxItemNum, float AirDropBoxRangeInner, float AirDropBoxRangeOuter, float DeathBoxRange, float PickUpWrapperRange, float FindBuildingMaxRange, float FindBuildingMinRange, bool InIsUseItemSpotLoc, int MaxTreasureChestNum, float TreasureChestRange, int MaxWeedNum, float WeedRange, struct TArray<struct FItemStateData>& ItemStateDatas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.PrintCacheAINearbyItem
	// Flags: [Final|Native|Protected]
	// Offset: 0x104789e80
	// Params: [ Num(0) Size(0x0) ]
	void PrintCacheAINearbyItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AI.AIStateInfoComponentBase.OnPlayerRespawn
	// Flags: [Final|Native|Public]
	// Offset: 0x104789e04
	// Params: [ Num(1) Size(0x8) ]
	void OnPlayerRespawn(struct AUAEPlayerController* PC);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046ABA40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.AIStateInfoComponentBase.OnFakePlayerRespawn
	// Flags: [Final|Native|Public]
	// Offset: 0x104789df0
	// Params: [ Num(0) Size(0x0) ]
	void OnFakePlayerRespawn();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046ABA40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.OnAIStateRequestEnd
	// Flags: [Final|Native|Public]
	// Offset: 0x104789ddc
	// Params: [ Num(0) Size(0x0) ]
	void OnAIStateRequestEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046ABA40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.AIStateInfoComponentBase.IsValid
	// Flags: [Final|Native|Protected|Const]
	// Offset: 0x104789da8
	// Params: [ Num(1) Size(0x1) ]
	bool IsValid();
	// [Call #1] RVA: 0x1046AE670
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046ABA40
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.IsAvailableNearbyItemType
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104789d08
	// Params: [ Num(2) Size(0x19) ]
	bool IsAvailableNearbyItemType(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046AC4A0
	// [Call #5] RVA: 0x1046AE670
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046ABA40
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.IsAvailableBackpackItemType
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104789c68
	// Params: [ Num(2) Size(0x19) ]
	bool IsAvailableBackpackItemType(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046AC480
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046AC4A0
	// [Call #9] RVA: 0x1046AE670
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046ABA40

	// Object: Function AI.AIStateInfoComponentBase.HasPlayerAround
	// Flags: [Final|Native|Protected]
	// Offset: 0x104789c34
	// Params: [ Num(1) Size(0x1) ]
	bool HasPlayerAround();
	// [Call #1] RVA: 0x1046AC0E0
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046AC480
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046AC4A0
	// [Call #10] RVA: 0x1046AE670
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046ABA40

	// Object: Function AI.AIStateInfoComponentBase.GetViewForwardVector
	// Flags: [Final|Native|Protected|HasDefaults|Const]
	// Offset: 0x104789ba4
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetViewForwardVector(struct ACharacter* InCharacter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046AE294
	// [Call #4] RVA: 0x1046AC0E0
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046AC480
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046AC4A0
	// [Call #13] RVA: 0x1046AE670

	// Object: Function AI.AIStateInfoComponentBase.GetSoundInfo
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104789b40
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FSoundState> GetSoundInfo();
	// [Call #1] RVA: 0x1046ADBF0
	// [Call #2] RVA: 0x1046E7000
	// [Call #3] RVA: 0x1046B2AA4
	// [Call #4] RVA: 0x1046B2AA4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046AE294
	// [Call #9] RVA: 0x1046AC0E0
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046AC480
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046AC4A0

	// Object: Function AI.AIStateInfoComponentBase.GetProgressBarState
	// Flags: [Final|Native|Public]
	// Offset: 0x104789ad8
	// Params: [ Num(1) Size(0x28) ]
	struct FProgressBarState GetProgressBarState();
	// [Call #1] RVA: 0x1046AD734
	// [Call #2] RVA: 0x1046C1334
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1046ADBF0
	// [Call #7] RVA: 0x1046E7000
	// [Call #8] RVA: 0x1046B2AA4
	// [Call #9] RVA: 0x1046B2AA4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046AE294
	// [Call #14] RVA: 0x1046AC0E0
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046AC480
	// [Call #19] RVA: 0x1041EFFBC

	// Object: Function AI.AIStateInfoComponentBase.GetPlayerInteractInfo
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104789a74
	// Params: [ Num(1) Size(0x58) ]
	struct FAIPlayerInteractInfo GetPlayerInteractInfo();
	// [Call #1] RVA: 0x1046AC3D0
	// [Call #2] RVA: 0x10478B1CC
	// [Call #3] RVA: 0x1046AF114
	// [Call #4] RVA: 0x1046AF114
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1046AD734
	// [Call #7] RVA: 0x1046C1334
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1046ADBF0
	// [Call #12] RVA: 0x1046E7000
	// [Call #13] RVA: 0x1046B2AA4
	// [Call #14] RVA: 0x1046B2AA4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046AE294
	// [Call #19] RVA: 0x1046AC0E0
	// [Call #20] RVA: 0x1041EFFBC
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.GetOwnerBaseCharacter
	// Flags: [Final|Native|Protected|Const]
	// Offset: 0x104789a40
	// Params: [ Num(1) Size(0x8) ]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter();
	// [Call #1] RVA: 0x1046AE680
	// [Call #2] RVA: 0x1046AC3D0
	// [Call #3] RVA: 0x10478B1CC
	// [Call #4] RVA: 0x1046AF114
	// [Call #5] RVA: 0x1046AF114
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1046AD734
	// [Call #8] RVA: 0x1046C1334
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1046ADBF0
	// [Call #13] RVA: 0x1046E7000
	// [Call #14] RVA: 0x1046B2AA4
	// [Call #15] RVA: 0x1046B2AA4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046AE294
	// [Call #20] RVA: 0x1046AC0E0
	// [Call #21] RVA: 0x1041EFFBC

	// Object: Function AI.AIStateInfoComponentBase.GetNearbyItemState
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104789904
	// Params: [ Num(3) Size(0x20) ]
	void GetNearbyItemState(struct ASTExtraBaseCharacter* InPawn, bool& OutIsUseCacheItem, struct TArray<struct FItemStateData>& NearbyItems);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046AE2E4
	// [Call #8] RVA: 0x1046B1DDC
	// [Call #9] RVA: 0x1046B1DDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1046AE680
	// [Call #12] RVA: 0x1046AC3D0
	// [Call #13] RVA: 0x10478B1CC
	// [Call #14] RVA: 0x1046AF114
	// [Call #15] RVA: 0x1046AF114
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1046AD734
	// [Call #18] RVA: 0x1046C1334
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AI.AIStateInfoComponentBase.GetFrameNo
	// Flags: [Final|Native|Protected]
	// Offset: 0x1047898e8
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetFrameNo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046AE2E4
	// [Call #8] RVA: 0x1046B1DDC
	// [Call #9] RVA: 0x1046B1DDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1046AE680
	// [Call #12] RVA: 0x1046AC3D0
	// [Call #13] RVA: 0x10478B1CC
	// [Call #14] RVA: 0x1046AF114
	// [Call #15] RVA: 0x1046AF114
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1046AD734
	// [Call #18] RVA: 0x1046C1334
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AI.AIStateInfoComponentBase.GetDamageSourcesNew
	// Flags: [Final|Native|Public]
	// Offset: 0x104789858
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FDamageSource> GetDamageSourcesNew();
	// [Call #1] RVA: 0x1046E70A8
	// [Call #2] RVA: 0x1046C136C
	// [Call #3] RVA: 0x1046B2AF4
	// [Call #4] RVA: 0x1046B2AF4
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046AE2E4
	// [Call #15] RVA: 0x1046B1DDC
	// [Call #16] RVA: 0x1046B1DDC
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1046AE680
	// [Call #19] RVA: 0x1046AC3D0
	// [Call #20] RVA: 0x10478B1CC

	// Object: Function AI.AIStateInfoComponentBase.GetAIDestroyBulletProbInfo
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x1047897b0
	// Params: [ Num(1) Size(0x10) ]
	void GetAIDestroyBulletProbInfo(struct TArray<struct FAIDestroyBulletProbInfo>& AIDestroyBulletProbInfoList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046AC4E4
	// [Call #4] RVA: 0x1046E6E08
	// [Call #5] RVA: 0x1046E6E08
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1046E70A8
	// [Call #8] RVA: 0x1046C136C
	// [Call #9] RVA: 0x1046B2AF4
	// [Call #10] RVA: 0x1046B2AF4
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AI.AIStateInfoComponentBase.ClearDamageSources
	// Flags: [Final|Native|Public]
	// Offset: 0x10478979c
	// Params: [ Num(0) Size(0x0) ]
	void ClearDamageSources();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046AC4E4
	// [Call #4] RVA: 0x1046E6E08
	// [Call #5] RVA: 0x1046E6E08
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1046E70A8
	// [Call #8] RVA: 0x1046C136C
	// [Call #9] RVA: 0x1046B2AF4
	// [Call #10] RVA: 0x1046B2AF4
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class AI.AIStateInfoDataAsset
// Size: 0x258 (Inherited: 0x30)
struct UAIStateInfoDataAsset : UDataAsset
{
	struct TMap<int, int> ProgressSkillConfig; // 0x30(0x50)
	struct TArray<int> AvailableBackpackItemTypes; // 0x80(0x10)
	struct TMap<int, bool> AvailableNearbyItemTypes; // 0x90(0x50)
	struct TMap<int, int> GrenadeTypeConfig; // 0xE0(0x50)
	struct TMap<int, int> EquipmentItemIDMappingConfig; // 0x130(0x50)
	float VisibleAngle; // 0x180(0x4)
	struct FVector HeadOffset; // 0x184(0xC)
	float NearbyEnemyRange; // 0x190(0x4)
	float FogWeatherRangeScale; // 0x194(0x4)
	int NearbyEnemyMaxNum; // 0x198(0x4)
	bool IsSearchNearItem; // 0x19C(0x1)
	uint8_t Pad_0x19D[0x3]; // 0x19D(0x3)
	int NearbyItemMaxNum; // 0x1A0(0x4)
	int NearbyMaxBoxNum; // 0x1A4(0x4)
	float NearbyAirDropBoxRangeInner; // 0x1A8(0x4)
	float NearbyAirDropBoxRangeOuter; // 0x1AC(0x4)
	float NearbyDeathBoxRange; // 0x1B0(0x4)
	float NearbyPickUpWrapperRange; // 0x1B4(0x4)
	float CacheNearbyItemRangeCoefficient; // 0x1B8(0x4)
	int NearbyMaxTreasureChestNum; // 0x1BC(0x4)
	float NearbyTreasureChestRange; // 0x1C0(0x4)
	int NearbyMaxWeedNum; // 0x1C4(0x4)
	float NearbyWeedRange; // 0x1C8(0x4)
	float NearbyFindBuildingMaxRange; // 0x1CC(0x4)
	float NearbyFindBuildingMinRange; // 0x1D0(0x4)
	float ItemStateChangedRange; // 0x1D4(0x4)
	bool IsItemVisiable; // 0x1D8(0x1)
	bool IsUseItemSpotLoc; // 0x1D9(0x1)
	uint8_t Pad_0x1DA[0x2]; // 0x1DA(0x2)
	float NearbyObstacleRange; // 0x1DC(0x4)
	float NearbyThrownRange; // 0x1E0(0x4)
	float NearbySmokeRange; // 0x1E4(0x4)
	int NearbyThrownMaxNum; // 0x1E8(0x4)
	uint8_t Pad_0x1EC[0x4]; // 0x1EC(0x4)
	int NearbyDoorMaxNum; // 0x1F0(0x4)
	float NearbyVehicleRange; // 0x1F4(0x4)
	int NearbyVehicleMaxNum; // 0x1F8(0x4)
	float NearbyBulletHoleRange; // 0x1FC(0x4)
	int NearbyBulletHoleMaxNum; // 0x200(0x4)
	float NearbyDynamicItemsRange; // 0x204(0x4)
	float NearbyDynamicItemsVisibleAngle; // 0x208(0x4)
	int NearbyDynamicItemsMaxNum; // 0x20C(0x4)
	float NearbyMonsterRange; // 0x210(0x4)
	int NearbyMonsterMaxNum; // 0x214(0x4)
	float NearbyDigLandScapeActorRange; // 0x218(0x4)
	int NearbyDigLandScapeActorMaxNum; // 0x21C(0x4)
	bool bIgnoreTreeAIWhenNoPlayerAround; // 0x220(0x1)
	uint8_t Pad_0x221[0x3]; // 0x221(0x3)
	float IgnoreTreeAIRadius; // 0x224(0x4)
	bool UseBodyTPPCamera; // 0x228(0x1)
	uint8_t Pad_0x229[0x7]; // 0x229(0x7)
	struct TArray<int> IgnoredMonsterIDs; // 0x230(0x10)
	struct TArray<uint8_t> AvailableAvatarSlotTypes; // 0x240(0x10)
	uint32_t nCanMLAIBuildAttributeID; // 0x250(0x4)
	uint8_t Pad_0x254[0x4]; // 0x254(0x4)
};

// Object: Class AI.StateInfoCollectorBase
// Size: 0x58 (Inherited: 0x28)
struct UStateInfoCollectorBase : UObject
{
	uint32_t CollectType; // 0x28(0x4)
	bool HaveGloabalData; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
	struct UAIStateInfoDataAsset* AIStateInfoDataAsset; // 0x30(0x8)
	struct UMLAIStateInfoManager* MLAIStateInfoManager; // 0x38(0x8)
	struct UMLAISubSystem* MLAISubSystem; // 0x40(0x8)
	struct ABattleRoyaleGameMode* CurGameMode; // 0x48(0x8)
	struct AAIWorldVolume* AIWorldVolume; // 0x50(0x8)
};

// Object: Class AI.BaseMLAIStateInfoCollector
// Size: 0x250 (Inherited: 0x58)
struct UBaseMLAIStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FMLBaseAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FMLBaseAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FMLBaseAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffMLBaseAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
};

// Object: Class AI.BaseStateInfoCollector
// Size: 0x5F8 (Inherited: 0x58)
struct UBaseStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FBaseModAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FBaseModAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FBaseModAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffBaseModAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x120)
	struct FBaseModGlobalGameState CacheGlobalGameState; // 0x268(0xA8)
	struct FBaseModGlobalGameState LastGlobalGameState; // 0x310(0xA8)
	struct FDiffBaseModGlobalGameState DiffGlobalGameStateGeneral; // 0x3B8(0xF0)
	struct TMap<uint32_t, uint32_t> DiffStateInfoKeyMap; // 0x4A8(0x50)
	struct TSet<uint32_t> LastSilentMLAIMap; // 0x4F8(0x50)
	struct TSet<uint32_t> CurrentSilentMLAIMap; // 0x548(0x50)
	uint8_t Pad_0x598[0x60]; // 0x598(0x60)


	// Object: Function AI.BaseStateInfoCollector.RemoveBackpackItemUpdatedMap
	// Flags: [Final|Native|Public]
	// Offset: 0x10478d300
	// Params: [ Num(2) Size(0x5) ]
	void RemoveBackpackItemUpdatedMap(uint32_t PlayerKey, bool AllRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046C91EC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.BaseStateInfoCollector.OnBackpackItemListUpdated
	// Flags: [Final|Native|Public]
	// Offset: 0x10478d284
	// Params: [ Num(1) Size(0x4) ]
	void OnBackpackItemListUpdated(uint32_t PlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046C9044
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046C91EC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.BaseStateInfoCollector.AddBackpackItemListUpdatedDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x10478d1cc
	// Params: [ Num(2) Size(0xC) ]
	void AddBackpackItemListUpdatedDelegate(struct UBackpackComponent* InBackpackComp, uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046C8DB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046C9044
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046C91EC
	// [Call #14] RVA: 0x10519022C
};

// Object: Class AI.BRBaseStateInfoCollector
// Size: 0x5E0 (Inherited: 0x58)
struct UBRBaseStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FBRBaseAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffBRBaseAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x118)
	struct FBRBaseGlobalGameState CacheGlobalGameState; // 0x260(0xF0)
	struct FBRBaseGlobalGameState LastGlobalGameState; // 0x350(0xF0)
	struct FDiffBRBaseGlobalGameState DiffGlobalGameStateGeneral; // 0x440(0x168)
	uint8_t Pad_0x5A8[0x30]; // 0x5A8(0x30)
	struct UCircleMgrComponent* CircleMgr; // 0x5D8(0x8)
};

// Object: Class AI.BTD_CheckObstacleInCustomRange
// Size: 0x108 (Inherited: 0x88)
struct UBTD_CheckObstacleInCustomRange : UBTDecorator_BlackboardBase
{
	uint8_t ObstacleDetectionType; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
	struct FBlackboardKeySelector BBK_OriginLoc; // 0x90(0x28)
	uint8_t bDrawDebug : 1; // 0xB8(0x1), Mask(0x1)
	uint8_t BitPad_0xB8_1 : 7; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	int DrawSegments; // 0xBC(0x4)
	struct FVector SpaceSize; // 0xC0(0xC)
	float GravityScale; // 0xCC(0x4)
	float CustomMaxHeight; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct FBlackboardKeySelector BBK_CapsuleSweepFinalLoc; // 0xD8(0x28)
	float CapsuleScaleFactor; // 0x100(0x4)
	uint8_t Pad_0x104[0x4]; // 0x104(0x4)
};

// Object: Class AI.BTDecorator_AttrObserver
// Size: 0xA0 (Inherited: 0x88)
struct UBTDecorator_AttrObserver : UBTDecorator_BlackboardBase
{
	struct TArray<struct FAIAttrObserver> AttrObserverList; // 0x88(0x10)
	uint8_t bEnableObserver : 1; // 0x98(0x1), Mask(0x1)
	uint8_t BitPad_0x98_1 : 7; // 0x98(0x1)
	bool bUseBlackboardKey; // 0x99(0x1)
	uint8_t Pad_0x9A[0x6]; // 0x9A(0x6)
};

// Object: Class AI.BTDecorator_BlackboardValueCheck
// Size: 0x90 (Inherited: 0x60)
struct UBTDecorator_BlackboardValueCheck : UBTDecorator
{
	struct FBlackboardKeySelector StrategyKey; // 0x60(0x28)
	uint8_t EnumValue; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
};

// Object: Class AI.BTDecorator_CheckAreaID
// Size: 0x98 (Inherited: 0x88)
struct UBTDecorator_CheckAreaID : UBTDecorator_BlackboardBase
{
	struct TArray<int> AreaIDs; // 0x88(0x10)
};

// Object: Class AI.BTDecorator_CheckDSSwitchOpen
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_CheckDSSwitchOpen : UBTDecorator
{
	int SwitchId; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_CheckEnvironment
// Size: 0x90 (Inherited: 0x60)
struct UBTDecorator_CheckEnvironment : UBTDecorator
{
	struct FBlackboardKeySelector BBKTarget; // 0x60(0x28)
	bool bCheckInWater; // 0x88(0x1)
	bool bCheckInHouse; // 0x89(0x1)
	uint8_t Pad_0x8A[0x6]; // 0x8A(0x6)
};

// Object: Class AI.BTDecorator_CheckFlyingStatus
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_CheckFlyingStatus : UBTDecorator
{
	uint8_t CheckItem; // 0x5A(0x1)
};

// Object: Class AI.BTDecorator_CheckInOcclusionPose
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_CheckInOcclusionPose : UBTDecorator
{
	uint8_t checkPose; // 0x5A(0x1)
};

// Object: Class AI.BTDecorator_CheckShootingPose
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_CheckShootingPose : UBTDecorator
{
	uint8_t checkPose; // 0x5A(0x1)
};

// Object: Class AI.BTDecorator_DistanceCheck
// Size: 0xE8 (Inherited: 0x60)
struct UBTDecorator_DistanceCheck : UBTDecorator
{
	struct FBlackboardKeySelector CenterActorBlackBoardKey; // 0x60(0x28)
	struct FBlackboardKeySelector TargetActorBlackBoardKey; // 0x88(0x28)
	enum class ECompareLengthType CompareOperation; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x3]; // 0xB1(0x3)
	float Distance; // 0xB4(0x4)
	struct FBlackboardKeySelector CustomCheckDistanceBlackBoardKey; // 0xB8(0x28)
	enum class EDistanceCheckType DistanceCheckType; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
};

// Object: Class AI.BTDecorator_DoesDistanceSatisfy
// Size: 0xB8 (Inherited: 0x60)
struct UBTDecorator_DoesDistanceSatisfy : UBTDecorator
{
	struct FVector2D TestDistanceRange; // 0x5C(0x8)
	bool bCustomSrcLoc; // 0x64(0x1)
	bool bCompareInXY; // 0x65(0x1)
	struct FBlackboardKeySelector TargetBlackboardKey; // 0x68(0x28)
	struct FBlackboardKeySelector SrcBlackboardKey; // 0x90(0x28)
};

// Object: Class AI.BTDecorator_GameModeCheck
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_GameModeCheck : UBTDecorator
{
	int PlayerNumPerTeam; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_GeneralLineTrace
// Size: 0xC8 (Inherited: 0x60)
struct UBTDecorator_GeneralLineTrace : UBTDecorator
{
	struct TArray<enum class ECollisionChannel> traceObjectTypes; // 0x60(0x10)
	uint8_t lineTraceType; // 0x70(0x1)
	uint8_t Pad_0x71[0x3]; // 0x71(0x3)
	float ForwardTestForwardOffset; // 0x74(0x4)
	float ForwardTestHeightOffset; // 0x78(0x4)
	bool bIgnoreOwner; // 0x7C(0x1)
	bool bFromSelfToTarget; // 0x7D(0x1)
	uint8_t Pad_0x7E[0x2]; // 0x7E(0x2)
	struct FBlackboardKeySelector BBKTargetActor; // 0x80(0x28)
	bool bOnlyTickInverse; // 0xA8(0x1)
	bool bUseSingleTrace; // 0xA9(0x1)
	uint8_t Pad_0xAA[0x6]; // 0xAA(0x6)
	struct TArray<struct AActor*> IgnoreActorsClass; // 0xB0(0x10)
	bool bDebug; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x7]; // 0xC1(0x7)
};

// Object: Class AI.BTDecorator_HasOccludeBuildActor
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_HasOccludeBuildActor : UBTDecorator
{
};

// Object: Class AI.BTDecorator_HasPawnState
// Size: 0xA0 (Inherited: 0x88)
struct UBTDecorator_HasPawnState : UBTDecorator_BlackboardBase
{
	struct TArray<uint8_t> AIStates; // 0x88(0x10)
	bool IsMatchAll; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: Class AI.BTDecorator_HasPlayerAIState
// Size: 0x78 (Inherited: 0x60)
struct UBTDecorator_HasPlayerAIState : UBTDecorator
{
	struct TArray<uint8_t> AIStates; // 0x60(0x10)
	bool IsMatchAll; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
};

// Object: Class AI.BTDecorator_HasStaticOccludePos
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_HasStaticOccludePos : UBTDecorator
{
};

// Object: Class AI.BTDecorator_IsEnemyInBuilding
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_IsEnemyInBuilding : UBTDecorator
{
};

// Object: Class AI.BTDecorator_IsInSafetyCircle
// Size: 0x90 (Inherited: 0x60)
struct UBTDecorator_IsInSafetyCircle : UBTDecorator
{
	struct FBlackboardKeySelector CheckTargetBlackboardKey; // 0x60(0x28)
	uint8_t IsCheackByCircleType; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
};

// Object: Class AI.BTDecorator_IsMovementMode
// Size: 0xA0 (Inherited: 0x88)
struct UBTDecorator_IsMovementMode : UBTDecorator_BlackboardBase
{
	enum class EMovementMode MovementMode; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
	struct TArray<enum class EMovementMode> MovementModeArray; // 0x90(0x10)
};

// Object: Class AI.BTDecorator_IsOcclusionExist
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_IsOcclusionExist : UBTDecorator
{
};

// Object: Class AI.BTDecorator_IsOcclusionSafe
// Size: 0x98 (Inherited: 0x60)
struct UBTDecorator_IsOcclusionSafe : UBTDecorator
{
	struct FBlackboardKeySelector BBKeyTargetEnemy; // 0x60(0x28)
	float CheckRadiusXY; // 0x88(0x4)
	float CheckRadiusZ; // 0x8C(0x4)
	float OcclusionPadAngle; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
};

// Object: Class AI.BTDecorator_IsSkillReady
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_IsSkillReady : UBTDecorator
{
	int SkillID; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_IsWayPointNeedRotate
// Size: 0x88 (Inherited: 0x60)
struct UBTDecorator_IsWayPointNeedRotate : UBTDecorator
{
	struct FBlackboardKeySelector CurrentEventWayPointActor; // 0x60(0x28)
};

// Object: Class AI.BTDecorator_ItemNumberCheck
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator_ItemNumberCheck : UBTDecorator
{
	enum class EItemNumCheckType checkType; // 0x5A(0x1)
	int ItemId; // 0x5C(0x4)
	int ItemNum; // 0x60(0x4)
};

// Object: Class AI.BTDecorator_Mob_CheckJump
// Size: 0xA8 (Inherited: 0x88)
struct UBTDecorator_Mob_CheckJump : UBTDecorator_BlackboardBase
{
	int RandomReachablePointRadius; // 0x88(0x4)
	struct FVector2D JumpHighRange; // 0x8C(0x8)
	struct FVector2D JumpLowRange; // 0x94(0x8)
	int JumpStartOffsetZ; // 0x9C(0x4)
	int JumpHighThreshold; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
};

// Object: Class AI.BTDecorator_Mob_CheckJumpToLowDirect
// Size: 0x98 (Inherited: 0x88)
struct UBTDecorator_Mob_CheckJumpToLowDirect : UBTDecorator_BlackboardBase
{
	float JumpToLowThreshold; // 0x88(0x4)
	float CheckDistance; // 0x8C(0x4)
	float JumpToLowSpeed; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
};

// Object: Class AI.BTDecorator_Mob_CheckObstacle
// Size: 0x90 (Inherited: 0x88)
struct UBTDecorator_Mob_CheckObstacle : UBTDecorator_BlackboardBase
{
	int CheckDistance; // 0x88(0x4)
	int BackDistance; // 0x8C(0x4)
};

// Object: Class AI.BTDecorator_Mob_CloseEnough
// Size: 0x90 (Inherited: 0x88)
struct UBTDecorator_Mob_CloseEnough : UBTDecorator_BlackboardBase
{
	float AcceptableDistance; // 0x88(0x4)
	bool bCheckDistanceIn2D; // 0x8C(0x1)
	bool bReachTestIncludesAgentRadius; // 0x8D(0x1)
	bool bReachTestIncludesGoalRadius; // 0x8E(0x1)
	bool bCheckInTick; // 0x8F(0x1)
};

// Object: Class AI.BTDecorator_Mob_HasAIState
// Size: 0x78 (Inherited: 0x60)
struct UBTDecorator_Mob_HasAIState : UBTDecorator
{
	uint8_t AIState; // 0x5A(0x1)
	struct TArray<uint8_t> AdditionalStates; // 0x60(0x10)
	uint8_t LogicOp; // 0x70(0x1)
	uint8_t Pad_0x72[0x6]; // 0x72(0x6)
};

// Object: Class AI.BTDecorator_Mob_IsTargetAbove
// Size: 0x90 (Inherited: 0x88)
struct UBTDecorator_Mob_IsTargetAbove : UBTDecorator_BlackboardBase
{
	float AcceptableDistance; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
};

// Object: Class AI.BTDecorator_Mob_LineTrace
// Size: 0x98 (Inherited: 0x88)
struct UBTDecorator_Mob_LineTrace : UBTDecorator_BlackboardBase
{
	struct TArray<enum class ECollisionChannel> traceObjectTypes; // 0x88(0x10)
};

// Object: Class AI.BTDecorator_Mob_LinkCheckJumpWall
// Size: 0x90 (Inherited: 0x88)
struct UBTDecorator_Mob_LinkCheckJumpWall : UBTDecorator_BlackboardBase
{
	int KeepDistance; // 0x88(0x4)
	float LineTraceHeightOffset; // 0x8C(0x4)
};

// Object: Class AI.BTDecorator_Mob_Once
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_Mob_Once : UBTDecorator
{
	int AllowTimes; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_NearTargetLoc
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_NearTargetLoc : UBTDecorator
{
	float Range; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_NewCoolDown
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator_NewCoolDown : UBTDecorator_Cooldown
{
	bool DoNotCoolDownWhenSubNodeFailed; // 0x60(0x1)
	bool bEnableInitializeCoolDown; // 0x61(0x1)
	uint8_t Pad_0x62[0x6]; // 0x62(0x6)
};

// Object: Class AI.BTDecorator_NewSatisfyAttkDist
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator_NewSatisfyAttkDist : UBTDecorator
{
	float DefaultAttackDist; // 0x5C(0x4)
	bool bIsInversed; // 0x60(0x1)
	float ExtraDistance; // 0x64(0x4)
};

// Object: Class AI.BTDecorator_PreCheckLaunchMove
// Size: 0xE8 (Inherited: 0x60)
struct UBTDecorator_PreCheckLaunchMove : UBTDecorator
{
	bool bUseCustomDestLocation; // 0x5A(0x1)
	struct FBlackboardKeySelector KeyLaunchToTarget; // 0x60(0x28)
	float CustomDestDirAngle; // 0x88(0x4)
	float CustomDestDistance; // 0x8C(0x4)
	bool UsePawnHalfHeightAsOffsetOfTargetLocation; // 0x90(0x1)
	uint8_t Pad_0x92[0x2]; // 0x92(0x2)
	struct FVector OffsetOfTargetLocation; // 0x94(0xC)
	struct FVector2D JumpSpeedRange; // 0xA0(0x8)
	float JumpSpeedInterval; // 0xA8(0x4)
	enum class ESuggestProjVelocityTraceOption JumpProjTraceType; // 0xAC(0x1)
	uint8_t Pad_0xAD[0x3]; // 0xAD(0x3)
	float OverrideGravityZ; // 0xB0(0x4)
	float CollisionRadius; // 0xB4(0x4)
	bool bFavorHighArc; // 0xB8(0x1)
	bool bDrawDebug; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x6]; // 0xBA(0x6)
	struct FBlackboardKeySelector OutJumpVelocityBlackboardKey; // 0xC0(0x28)
};

// Object: Class AI.BTDecorator_Probability
// Size: 0xB8 (Inherited: 0x60)
struct UBTDecorator_Probability : UBTDecorator
{
	float ExecuteProbability; // 0x5C(0x4)
	bool bUseDifficultyLevel; // 0x60(0x1)
	uint8_t Pad_0x65[0x3]; // 0x65(0x3)
	struct TMap<int, float> DifficultyProbabilityCfg; // 0x68(0x50)
};

// Object: Class AI.AIQueryShapeDesc_Base
// Size: 0x28 (Inherited: 0x28)
struct UAIQueryShapeDesc_Base : UObject
{
};

// Object: Class AI.AIQueryShapeDesc_Cylinder
// Size: 0x48 (Inherited: 0x28)
struct UAIQueryShapeDesc_Cylinder : UAIQueryShapeDesc_Base
{
	struct FVector CenterOffset; // 0x28(0xC)
	float RadiusOutside; // 0x34(0x4)
	float RadiusInside; // 0x38(0x4)
	float Height; // 0x3C(0x4)
	float Angle; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: Class AI.BTDecorator_QueryTarget
// Size: 0xD8 (Inherited: 0x60)
struct UBTDecorator_QueryTarget : UBTDecorator
{
	struct UAIQueryShapeDesc_Base* QueryShape; // 0x60(0x8)
	uint8_t bUsePawnLocationAsCenter : 1; // 0x68(0x1), Mask(0x1)
	uint8_t BitPad_0x68_1 : 7; // 0x68(0x1)
	uint8_t Pad_0x69[0x3]; // 0x69(0x3)
	int AcceptPlayerCount; // 0x6C(0x4)
	uint8_t bSavePawnCount : 1; // 0x70(0x1), Mask(0x1)
	uint8_t BitPad_0x70_1 : 7; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
	struct FBlackboardKeySelector nSavePawnCount; // 0x78(0x28)
	struct FBlackboardKeySelector CenterLocationFromBBD; // 0xA0(0x28)
	struct FVector TargetAnchorOffset; // 0xC8(0xC)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
};

// Object: Class AI.BTDecorator_RandomStrategy
// Size: 0xD8 (Inherited: 0x60)
struct UBTDecorator_RandomStrategy : UBTDecorator
{
	struct FBlackboardKeySelector StrategyKey; // 0x60(0x28)
	struct TMap<uint8_t, float> StrategyWeight; // 0x88(0x50)
};

// Object: Class AI.BTDecorator_SatisfyAttkDist
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator_SatisfyAttkDist : UBTDecorator
{
	float AttackDist; // 0x5C(0x4)
	bool bIsInversed; // 0x60(0x1)
	uint8_t Pad_0x65[0x3]; // 0x65(0x3)
};

// Object: Class AI.BTDecorator_SatisfyAttkDistWithWeapon
// Size: 0xB8 (Inherited: 0x60)
struct UBTDecorator_SatisfyAttkDistWithWeapon : UBTDecorator
{
	float DefaultAttackDist; // 0x5C(0x4)
	bool bIsInversed; // 0x60(0x1)
	float ExtraDistance; // 0x64(0x4)
	struct TMap<enum class EWeaponTypeNew, float> WeaponTypeRange; // 0x68(0x50)
};

// Object: Class AI.BTDecorator_TargetEnemyLandedTimeCheck
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_TargetEnemyLandedTimeCheck : UBTDecorator
{
	float LandedCheckTime; // 0x5C(0x4)
};

// Object: Class AI.BTDecorator_TargetHasBuff
// Size: 0xA0 (Inherited: 0x60)
struct UBTDecorator_TargetHasBuff : UBTDecorator
{
	struct FBlackboardKeySelector BBKTarget; // 0x60(0x28)
	struct TArray<int> BuffIDs; // 0x88(0x10)
	bool bRequireAll; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: Class AI.BTDecorator_WeaponTypeCheck
// Size: 0x60 (Inherited: 0x60)
struct UBTDecorator_WeaponTypeCheck : UBTDecorator
{
	enum class EWeaponTypeNew WeaponType; // 0x5A(0x1)
};

// Object: Class AI.BTService_AdvancedShooting
// Size: 0xF8 (Inherited: 0x68)
struct UBTService_AdvancedShooting : UBTService
{
	uint8_t WeaponShotType; // 0x61(0x1)
	float DeviationScale; // 0x64(0x4)
	float ShootGunDeviationAngle; // 0x68(0x4)
	struct FVector2D RandomShootFreqRange; // 0x6C(0x8)
	struct FBlackboardKeySelector ReloadBlackBoardKey; // 0x78(0x28)
	bool bSetCanSeeTargetFlag; // 0xA0(0x1)
	bool bUseTargetEnemyCfg; // 0xA1(0x1)
	bool bNeedCheckBullets; // 0xA2(0x1)
	struct FVector2D ShootUpDownRange; // 0xA4(0x8)
	float TargetWidth; // 0xAC(0x4)
	struct FVector2D ShootLeftRightRange; // 0xB0(0x8)
	struct FVector2D ShootLeftRightRangeDistance; // 0xB8(0x8)
	struct FVector2D ShootTargetSpeedRange; // 0xC0(0x8)
	struct FVector2D ShootTargetDistanceRangeDueToSpeed; // 0xC8(0x8)
	bool bForceUseAIControllerRotation; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	float HitRateLerpSpeed; // 0xD4(0x4)
	bool bUseLerpHitRate; // 0xD8(0x1)
	bool bMissOnPurpose; // 0xD9(0x1)
	uint8_t Pad_0xDA[0x2]; // 0xDA(0x2)
	float ScaleForHitPart; // 0xDC(0x4)
	bool bStopShootingWhenCannotSee; // 0xE0(0x1)
	bool bEnableShootProbabilityCompensate; // 0xE1(0x1)
	uint8_t Pad_0xE2[0x6]; // 0xE2(0x6)
	struct UCurveFloat* LowSpeedScaleShootProbabilityCurve; // 0xE8(0x8)
	bool bShowDebugLine; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float LineLifeTime; // 0xF4(0x4)
};

// Object: Class AI.BTService_CheckAttackTarget
// Size: 0x70 (Inherited: 0x68)
struct UBTService_CheckAttackTarget : UBTService
{
	float SensedRadius; // 0x64(0x4)
	float EquipWeaponSensedRadius; // 0x68(0x4)
};

// Object: Class AI.BTService_CheckInAIBehaviorRegion
// Size: 0xC0 (Inherited: 0x68)
struct UBTService_CheckInAIBehaviorRegion : UBTService
{
	struct FBlackboardKeySelector BBKeyIsOutOfMaxDistance; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeySpawnPoint; // 0x90(0x28)
	bool bClearEnemyTargetWhenOutOfMaxDist; // 0xB8(0x1)
	bool bUseAIMaxMoveDistanceVolume; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x2]; // 0xBA(0x2)
	float HeightTestOffset; // 0xBC(0x4)
};

// Object: Class AI.BTService_CheckMaxDistanceFromSpawnPoint
// Size: 0xC8 (Inherited: 0x68)
struct UBTService_CheckMaxDistanceFromSpawnPoint : UBTService
{
	float MaxDistAllowedFromSpawnPoint; // 0x64(0x4)
	struct FBlackboardKeySelector BBKeyIsOutOfMaxDistance; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeySpawnPoint; // 0x90(0x28)
	bool bClearEnemyTargetWhenOutOfMaxDist; // 0xB8(0x1)
	bool bUseAIMaxMoveDistanceVolume; // 0xB9(0x1)
	float HeightTestOffset; // 0xBC(0x4)
	float HeightTestZOffset; // 0xC0(0x4)
	uint8_t Pad_0xC6[0x2]; // 0xC6(0x2)
};

// Object: Class AI.BTService_CheckMaxDistanceFromTargetPoint
// Size: 0xC0 (Inherited: 0x68)
struct UBTService_CheckMaxDistanceFromTargetPoint : UBTService
{
	float MaxDistAllowedFromWayPoint; // 0x64(0x4)
	struct FBlackboardKeySelector BBKeyIsOutOfMaxDistance; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeyTargetPoint; // 0x90(0x28)
	bool bClearEnemyTargetWhenOutOfMaxDist; // 0xB8(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
};

// Object: Class AI.BTService_ChooseEnemy
// Size: 0x1E8 (Inherited: 0x68)
struct UBTService_ChooseEnemy : UBTService
{
	uint8_t searchEnemyMethod; // 0x61(0x1)
	struct FBlackboardKeySelector BBKeySearchEnemyMethodIndex; // 0x68(0x28)
	float MaxRememberEnemyTimeInSeconds; // 0x90(0x4)
	float MaxRememberLastAttackedMeTimeInSeconds; // 0x94(0x4)
	float MaxTraceLastAttackedMeDistance; // 0x98(0x4)
	float MinTimeWhenCannotSeeTarget; // 0x9C(0x4)
	float MinTimeLockTarget; // 0xA0(0x4)
	float SensedRadius; // 0xA4(0x4)
	float EquipWeaponSensedRadius; // 0xA8(0x4)
	float EquipWeaponNightSensedRadius; // 0xAC(0x4)
	float EmergencyRadius; // 0xB0(0x4)
	uint8_t Pad_0xB5[0x3]; // 0xB5(0x3)
	struct TArray<struct FWeaponType2Range> WeaponType2Ranges; // 0xB8(0x10)
	struct TArray<struct FWeaponTypeToRange> DefaultWeaponTypeToRanges; // 0xC8(0x10)
	struct TMap<uint8_t, struct FWeatherToRange> WeatherToRange; // 0xD8(0x50)
	struct TMap<uint8_t, uint8_t> WeatherTypeToWeatherRange; // 0x128(0x50)
	float PVESensedRadius; // 0x178(0x4)
	float FinalCircleSensedRate; // 0x17C(0x4)
	float UnderGroundSensedRate; // 0x180(0x4)
	float DarkAreaSensedRate; // 0x184(0x4)
	float FinalCircleAIPriorityDistSqRate; // 0x188(0x4)
	bool bEnableWarning; // 0x18C(0x1)
	uint8_t Pad_0x18D[0x3]; // 0x18D(0x3)
	float WarningCD; // 0x190(0x4)
	bool bEnableSmokingVisibilityCheck; // 0x194(0x1)
	enum class ECollisionChannel SmokingVisibilityCheckChannel; // 0x195(0x1)
	uint8_t Pad_0x196[0x2]; // 0x196(0x2)
	struct FName SmokingVisibilityCheckTag; // 0x198(0x8)
	bool bEnablePeekShootingCheck; // 0x1A0(0x1)
	bool bEnablePeekShootingCheckAtOcclusion; // 0x1A1(0x1)
	uint8_t Pad_0x1A2[0x2]; // 0x1A2(0x2)
	float PeekShootingCheckAtOcclusionOfOcclusionRadius; // 0x1A4(0x4)
	struct TArray<uint8_t> PeekShootingCheckArray_Stand; // 0x1A8(0x10)
	struct TArray<uint8_t> PeekShootingCheckArray_Crouch; // 0x1B8(0x10)
	bool DoNotAttackNearDeathEnemyFirst; // 0x1C8(0x1)
	bool bIgnoreAIWhenNoPlayerAround; // 0x1C9(0x1)
	uint8_t Pad_0x1CA[0x2]; // 0x1CA(0x2)
	float IgnoreAIRadius; // 0x1CC(0x4)
	bool bClearEnemyWhenSameTeam; // 0x1D0(0x1)
	bool bSenseZombie; // 0x1D1(0x1)
	bool bCheckZombieTeam; // 0x1D2(0x1)
	bool bSelectEnemyInSafety; // 0x1D3(0x1)
	bool bShowDebugInfo; // 0x1D4(0x1)
	uint8_t Pad_0x1D5[0x3]; // 0x1D5(0x3)
	float DebugInfoLife; // 0x1D8(0x4)
	float DebugRadius; // 0x1DC(0x4)
	bool bIsBornLandFindEnemy; // 0x1E0(0x1)
	uint8_t Pad_0x1E1[0x7]; // 0x1E1(0x7)
};

// Object: Class AI.BTService_ChooseEnemyByShape
// Size: 0x200 (Inherited: 0x1E8)
struct UBTService_ChooseEnemyByShape : UBTService_ChooseEnemy
{
	struct TArray<struct FWeaponTypeToRangeWithPawnState> WeaponTypeToRangeWithPawnStates; // 0x1E8(0x10)
	bool bUseVisibilityTrace; // 0x1F8(0x1)
	bool bNotValidWeaponRangeForeTrue; // 0x1F9(0x1)
	uint8_t Pad_0x1FA[0x6]; // 0x1FA(0x6)
};

// Object: Class AI.BTService_ChooseEnemySingleTraining
// Size: 0x1E8 (Inherited: 0x1E8)
struct UBTService_ChooseEnemySingleTraining : UBTService_ChooseEnemy
{
	uint8_t bIgnoreVisibility : 1; // 0x1E1(0x1), Mask(0x1)
};

// Object: Class AI.BTService_ChooseFightbackEnemy
// Size: 0x70 (Inherited: 0x68)
struct UBTService_ChooseFightbackEnemy : UBTService
{
	float SensedRadius; // 0x64(0x4)
	float EquipWeaponSensedRadius; // 0x68(0x4)
	float EmergencyRadius; // 0x6C(0x4)
};

// Object: Class AI.BTService_ChooseMonsterEnemy
// Size: 0xA0 (Inherited: 0x68)
struct UBTService_ChooseMonsterEnemy : UBTService
{
	float SensedRadius; // 0x64(0x4)
	struct FBlackboardKeySelector BBKeyMonsterTarget; // 0x68(0x28)
	struct TArray<int> SupportedMonsterIDs; // 0x90(0x10)
};

// Object: Class AI.BTService_ChooseTeammate
// Size: 0x90 (Inherited: 0x68)
struct UBTService_ChooseTeammate : UBTService
{
	uint8_t SearchMethod; // 0x61(0x1)
	float SensedRadius; // 0x64(0x4)
	struct FBlackboardKeySelector OutTeammateBlackboardKey; // 0x68(0x28)
};

// Object: Class AI.BTService_CJChooseEnemy
// Size: 0x170 (Inherited: 0x68)
struct UBTService_CJChooseEnemy : UBTService
{
	bool bUpdateItemOptimize; // 0x61(0x1)
	struct TArray<struct FUpdateItemInterval> UpdateItemIntervalList; // 0x68(0x10)
	struct FBlackboardKeySelector OutTargetEnemyActor; // 0x78(0x28)
	struct FBlackboardKeySelector OutIsCanNotSeeTarget; // 0xA0(0x28)
	float MaxRememberLastAttackedMeTimeInSeconds; // 0xC8(0x4)
	int MaxTraceLastAttackedMeDistance; // 0xCC(0x4)
	struct TArray<struct FEnemyInfo> EnemyInfoList; // 0xD0(0x10)
	float MinTimeLockTarget; // 0xE0(0x4)
	float MinTimeWhenCannotSeeTarget; // 0xE4(0x4)
	int SensedRadius; // 0xE8(0x4)
	int EquipWeaponSensedRadius; // 0xEC(0x4)
	bool bUseFanChoose; // 0xF0(0x1)
	uint8_t Pad_0xF2[0x6]; // 0xF2(0x6)
	struct TArray<struct FSightFanInfo> FanInfoList; // 0xF8(0x10)
	bool bFindNearestEnemyPawn; // 0x108(0x1)
	uint8_t Pad_0x109[0x7]; // 0x109(0x7)
	struct FBlackboardKeySelector OutNearestEnemyPawnVisible; // 0x110(0x28)
	struct FBlackboardKeySelector OutNearestEnemyPawnInVisible; // 0x138(0x28)
	float NearestEnemyVisibleMemoryTime; // 0x160(0x4)
	int SensedNearestEnemyVisibleRadius; // 0x164(0x4)
	int SensedNearestEnemyInVisibleRadius; // 0x168(0x4)
	uint8_t Pad_0x16C[0x4]; // 0x16C(0x4)
};

// Object: Class AI.BTService_ClearTrouble
// Size: 0x90 (Inherited: 0x68)
struct UBTService_ClearTrouble : UBTService
{
	bool bOpenAIClearTrouble; // 0x61(0x1)
	float PathFindTestRadius; // 0x64(0x4)
	uint32_t UnreachablePointsToBeInTrouble; // 0x68(0x4)
	struct UNavigationQueryFilter* TestPathFilterClass; // 0x70(0x8)
	struct FInTroubleTeleportConfig TeleportCfg; // 0x78(0x10)
	bool bShowDebugPoint; // 0x88(0x1)
	uint8_t Pad_0x8A[0x6]; // 0x8A(0x6)
};

// Object: Class AI.BTService_Cruising
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Cruising : UBTService
{
};

// Object: Class AI.BTService_DebugInfo
// Size: 0x80 (Inherited: 0x68)
struct UBTService_DebugInfo : UBTService
{
	struct FString Info; // 0x68(0x10)
	bool bShowControllerName; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)


	// Object: Function AI.BTService_DebugInfo.GetInfo
	// Flags: [Native|Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104796adc
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetInfo();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870
};

// Object: Class AI.BTService_DeliverControl
// Size: 0x78 (Inherited: 0x68)
struct UBTService_DeliverControl : UBTService
{
	struct TArray<struct FDeliverControlRatingConfig> RatingConfig; // 0x68(0x10)
};

// Object: Class AI.BTService_DetectVehicle
// Size: 0xC0 (Inherited: 0x68)
struct UBTService_DetectVehicle : UBTService
{
	float QueryRange; // 0x64(0x4)
	float DetectionRange; // 0x68(0x4)
	float DetectionAngle; // 0x6C(0x4)
	struct FBlackboardKeySelector BBKeySensedVehicle; // 0x70(0x28)
	struct FBlackboardKeySelector BBKeyResult; // 0x98(0x28)
};

// Object: Class AI.BTService_DetectVehicleRisk
// Size: 0x110 (Inherited: 0x68)
struct UBTService_DetectVehicleRisk : UBTService
{
	float QueryRange; // 0x64(0x4)
	float DetectionRange; // 0x68(0x4)
	float SpeedThreshold; // 0x6C(0x4)
	struct FBlackboardKeySelector SensedRiskyVehicle; // 0x70(0x28)
	struct FBlackboardKeySelector RunawayPosition; // 0x98(0x28)
	struct FBlackboardKeySelector HasNearbyRiskyVehicle; // 0xC0(0x28)
	struct FBlackboardKeySelector IsRunningAway; // 0xE8(0x28)
};

// Object: Class AI.BTService_DistantJudge
// Size: 0xA8 (Inherited: 0x68)
struct UBTService_DistantJudge : UBTService
{
	struct FBlackboardKeySelector WatchTargetBlackBoardKey; // 0x68(0x28)
	struct TArray<struct FAIDistantJudgeNoftify> DistantJudges; // 0x90(0x10)
	bool ResetModifyBBData; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x7]; // 0xA1(0x7)
};

// Object: Class AI.BTService_FightDecisionSystem
// Size: 0x68 (Inherited: 0x68)
struct UBTService_FightDecisionSystem : UBTService
{
	float EnemyTraceRadius; // 0x64(0x4)
};

// Object: Class AI.BTService_FlyingChooseEnemy
// Size: 0x80 (Inherited: 0x68)
struct UBTService_FlyingChooseEnemy : UBTService
{
	bool bIgnoreVisibility; // 0x61(0x1)
	bool bIgnoreAI; // 0x62(0x1)
	float SensedRadius; // 0x64(0x4)
	float SensedAngle; // 0x68(0x4)
	float MinTimeLockTarget; // 0x6C(0x4)
	float MinTimeWhenCannotSeeTarget; // 0x70(0x4)
	float MaxRememberEnemyTimeInSeconds; // 0x74(0x4)
	bool bUseNewSetCurEnemy; // 0x78(0x1)
	uint8_t Pad_0x7F[0x1]; // 0x7F(0x1)
};

// Object: Class AI.BTService_FlyingTowerDefenseChooseEnemy
// Size: 0xD8 (Inherited: 0x80)
struct UBTService_FlyingTowerDefenseChooseEnemy : UBTService_FlyingChooseEnemy
{
	bool bEnableTowerDefenseTargeting; // 0x79(0x1)
	float SwitchToPlayerThreshold; // 0x7C(0x4)
	float SwitchBackThreshold; // 0x80(0x4)
	float HatredDecreaseSpeed; // 0x84(0x4)
	struct FBlackboardKeySelector DefendTargetKey; // 0x88(0x28)
	struct FBlackboardKeySelector AttackingPlayerFlagKey; // 0xB0(0x28)
};

// Object: Class AI.BTService_Focus
// Size: 0xA8 (Inherited: 0x98)
struct UBTService_Focus : UBTService_DefaultFocus
{
	uint8_t AIFocusPriority; // 0x91(0x1)
	bool ResetFocus; // 0x92(0x1)
	bool ClearFocusWhenCeaseRelevant; // 0x93(0x1)
	bool bAdjustByTargetPose; // 0x94(0x1)
	float FocusPointOffset_TargetCrouch; // 0x98(0x4)
	float FocusPointOffset_TargetProne; // 0x9C(0x4)
	float FocusPointOffset_TargetStand; // 0xA0(0x4)
};

// Object: Class AI.BTService_HealthCheck
// Size: 0x90 (Inherited: 0x68)
struct UBTService_HealthCheck : UBTService
{
	float HealthChangeVaule; // 0x64(0x4)
	struct FBlackboardKeySelector HealthChangeBlackBoardKey; // 0x68(0x28)
};

// Object: Class AI.BTService_LookAround
// Size: 0x80 (Inherited: 0x68)
struct UBTService_LookAround : UBTService
{
	struct FVector2D RotationSpeed; // 0x64(0x8)
	struct FVector2D RotationAngle; // 0x6C(0x8)
	struct FVector2D WaitTimeWhenStop; // 0x74(0x8)
	float AcceptToleranceInDegree; // 0x7C(0x4)
};

// Object: Class AI.BTService_Mob_AddHp
// Size: 0x70 (Inherited: 0x68)
struct UBTService_Mob_AddHp : UBTService
{
	int BuffID_AddHP; // 0x64(0x4)
	uint8_t addHPType; // 0x68(0x1)
	uint8_t Pad_0x6D[0x3]; // 0x6D(0x3)
};

// Object: Class AI.BTService_Mob_AdvancedMovementDetector
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Mob_AdvancedMovementDetector : UBTService
{
};

// Object: Class AI.BTService_Mob_AutoDestroy
// Size: 0x70 (Inherited: 0x68)
struct UBTService_Mob_AutoDestroy : UBTService
{
	float CheckRadius; // 0x64(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

// Object: Class AI.BTService_Mob_CheckLocation
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Mob_CheckLocation : UBTService
{
	float MaxAllowedDistanceFromSpawnPointSq; // 0x64(0x4)
};

// Object: Class AI.BTService_Mob_CheckLoseTarget
// Size: 0x70 (Inherited: 0x68)
struct UBTService_Mob_CheckLoseTarget : UBTService
{
	float LoseTargetThreshold; // 0x64(0x4)
	uint8_t bCheckNoPlayerNearby : 1; // 0x68(0x1), Mask(0x1)
	float CheckNoPlayerRange; // 0x6C(0x4)
};

// Object: Class AI.BTService_Mob_CheckPathExist
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Mob_CheckPathExist : UBTService
{
};

// Object: Class AI.BTService_Mob_ChooseEnemy
// Size: 0xD0 (Inherited: 0x68)
struct UBTService_Mob_ChooseEnemy : UBTService
{
	float MaxRememberEnemyTimeInSeconds; // 0x64(0x4)
	float MinTimeLockTarget; // 0x68(0x4)
	float MinTimeWhenCannotSeeTarget; // 0x6C(0x4)
	float SensedRadius; // 0x70(0x4)
	uint8_t searchType; // 0x74(0x1)
	float SensedAngle; // 0x78(0x4)
	bool SenseEnemyWithLineTrace; // 0x7C(0x1)
	uint8_t Pad_0x7E[0x2]; // 0x7E(0x2)
	float PreciseHatredDecreaseSpeed; // 0x80(0x4)
	bool SensedRadiusAdvanceInNight; // 0x84(0x1)
	uint8_t Pad_0x85[0x3]; // 0x85(0x3)
	float LoseSightRadius; // 0x88(0x4)
	bool DontAttackWhenTargetInWater; // 0x8C(0x1)
	bool bEnableWarning; // 0x8D(0x1)
	uint8_t Pad_0x8E[0x2]; // 0x8E(0x2)
	float WarningCD; // 0x90(0x4)
	float AttackVehicleInRadius; // 0x94(0x4)
	bool AttackVehicleInRadiusEnabled; // 0x98(0x1)
	uint8_t searchVehicleType; // 0x99(0x1)
	uint8_t Pad_0x9A[0x6]; // 0x9A(0x6)
	struct TArray<uint8_t> IgnoreVehicleTypes; // 0xA0(0x10)
	struct FName IgnoreTargetIfHasTag; // 0xB0(0x8)
	bool bSelectEnemyInSafety; // 0xB8(0x1)
	uint8_t bDoNotAttackNearDeathEnemyFirst : 1; // 0xB9(0x1), Mask(0x1)
	uint8_t bIgnoreNearDeathEnemy : 1; // 0xB9(0x1), Mask(0x2)
	uint8_t BitPad_0xB9_2 : 6; // 0xB9(0x1)
	uint8_t Pad_0xBA[0xE]; // 0xBA(0xE)
	struct ASTExtraSimpleCharacter* ControlledMobPawn; // 0xC8(0x8)
};

// Object: Class AI.BTService_Mob_ChooseEnemyByRule
// Size: 0xD8 (Inherited: 0xD0)
struct UBTService_Mob_ChooseEnemyByRule : UBTService_Mob_ChooseEnemy
{
	bool bSenseMonster; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
};

// Object: Class AI.BTService_Mob_ChooseEnemyBySingleRule
// Size: 0x108 (Inherited: 0xD0)
struct UBTService_Mob_ChooseEnemyBySingleRule : UBTService_Mob_ChooseEnemy
{
	uint8_t SearchEnemySingleRule; // 0xD0(0x1)
	uint8_t SearchEnemyEntityType; // 0xD1(0x1)
	uint8_t Pad_0xD2[0x6]; // 0xD2(0x6)
	struct FBlackboardKeySelector BBKeySearchEnemyMethodIndex; // 0xD8(0x28)
	uint8_t bRunBaseChooseEnemy : 1; // 0x100(0x1), Mask(0x1)
	uint8_t bForceUpdateTarget : 1; // 0x100(0x1), Mask(0x2)
	uint8_t BitPad_0x100_2 : 6; // 0x100(0x1)
	uint8_t Pad_0x101[0x7]; // 0x101(0x7)
};

// Object: Class AI.BTService_Mob_DetectionEnemy
// Size: 0xD0 (Inherited: 0xD0)
struct UBTService_Mob_DetectionEnemy : UBTService_Mob_ChooseEnemy
{
};

// Object: Class AI.BTService_Mob_Hearing
// Size: 0x78 (Inherited: 0x68)
struct UBTService_Mob_Hearing : UBTService
{
	float MinTimeLockTarget; // 0x64(0x4)
	float MaxTimeLockWhenNoNextSound; // 0x68(0x4)
	uint8_t searchType; // 0x6C(0x1)
	float AcceptableDistance; // 0x70(0x4)
	uint8_t Pad_0x75[0x3]; // 0x75(0x3)
};

// Object: Class AI.BTService_Mob_MoveBlockTimer
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Mob_MoveBlockTimer : UBTService
{
	float ClearBlockStatusTime; // 0x64(0x4)
};

// Object: Class AI.BTService_Mob_OpenDoor
// Size: 0x70 (Inherited: 0x68)
struct UBTService_Mob_OpenDoor : UBTService
{
	float OpenDoorRangeSq; // 0x64(0x4)
	float AutoOpenDoorInterval; // 0x68(0x4)
};

// Object: Class AI.BTService_Mob_TowerDefenseChooseEnemy
// Size: 0x130 (Inherited: 0xD0)
struct UBTService_Mob_TowerDefenseChooseEnemy : UBTService_Mob_ChooseEnemy
{
	bool bEnableTowerDefenseTargeting; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	float SwitchToPlayerThreshold; // 0xD4(0x4)
	float SwitchBackThreshold; // 0xD8(0x4)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
	struct FBlackboardKeySelector DefendTargetKey; // 0xE0(0x28)
	struct FBlackboardKeySelector AttackingPlayerFlagKey; // 0x108(0x28)
};

// Object: Class AI.BTService_ModifyBlackboardValue
// Size: 0xE0 (Inherited: 0x68)
struct UBTService_ModifyBlackboardValue : UBTService
{
	bool bEnterModifyBlackboardKey; // 0x61(0x1)
	struct FBlackboardKeySelector EnterModifyBlackboardKey; // 0x68(0x28)
	struct FString EnterSetValue; // 0x90(0x10)
	bool bExitModifyBlackboardKey; // 0xA0(0x1)
	uint8_t Pad_0xA2[0x6]; // 0xA2(0x6)
	struct FBlackboardKeySelector ExitModifyBlackboardKey; // 0xA8(0x28)
	struct FString ExitSetValue; // 0xD0(0x10)
};

// Object: Class AI.BTService_OccupyHandler
// Size: 0xB8 (Inherited: 0x68)
struct UBTService_OccupyHandler : UBTService
{
	struct FBlackboardKeySelector OutCurOccupyPointActor; // 0x68(0x28)
	struct FBlackboardKeySelector OutIsOccupying; // 0x90(0x28)
};

// Object: Class AI.BTService_OpenDoor
// Size: 0x68 (Inherited: 0x68)
struct UBTService_OpenDoor : UBTService
{
	float OpenDoorRange; // 0x64(0x4)
};

// Object: Class AI.BTService_QueryNearestTarget
// Size: 0xB8 (Inherited: 0x68)
struct UBTService_QueryNearestTarget : UBTService
{
	float RadiusInArea; // 0x64(0x4)
	struct FBlackboardKeySelector OutNearByPlayer; // 0x68(0x28)
	struct FBlackboardKeySelector OutHasNearByPlayer; // 0x90(0x28)
};

// Object: Class AI.BTService_QueryPlayerHoldingWeapon
// Size: 0xB8 (Inherited: 0x68)
struct UBTService_QueryPlayerHoldingWeapon : UBTService
{
	float RadiusInArea; // 0x64(0x4)
	struct FBlackboardKeySelector OutHasPlayerHoldingWeapon; // 0x68(0x28)
	struct FBlackboardKeySelector OutPlayerWhichHoldingWeapon; // 0x90(0x28)
};

// Object: Class AI.BTService_RescueHandler
// Size: 0x68 (Inherited: 0x68)
struct UBTService_RescueHandler : UBTService
{
	int RescueRange; // 0x64(0x4)
};

// Object: Class AI.BTService_SensedEnemy
// Size: 0xD0 (Inherited: 0x68)
struct UBTService_SensedEnemy : UBTService
{
	float IsNotSeeTargetTime; // 0x64(0x4)
	float SensedRadius; // 0x68(0x4)
	float EquipWeaponSensedRadius; // 0x6C(0x4)
	float EquipWeaponNightSensedRadius; // 0x70(0x4)
	float EmergencyRadius; // 0x74(0x4)
	struct TMap<int, float> AISensedEnemyPoseRatio; // 0x78(0x50)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
};

// Object: Class AI.BTService_SenseGrenade
// Size: 0x198 (Inherited: 0x68)
struct UBTService_SenseGrenade : UBTService
{
	struct TMap<uint8_t, bool> GrenadeSenseEnable; // 0x68(0x50)
	struct TArray<struct FBPAISenseGrenadeDistanceConfig> SenseDistanceConfig; // 0xB8(0x10)
	struct TMap<uint8_t, struct FAISenseGrenadeClassConfig> GrenadeClasses; // 0xC8(0x50)
	struct TArray<struct FAISenseGrenadeBBKeyInfo> GrenadeBBKeyConfig; // 0x118(0x10)
	struct TArray<enum class ECollisionChannel> GrenadeCollisionChannels; // 0x128(0x10)
	struct FBlackboardKeySelector BBKeyHasBeenFlashed; // 0x138(0x28)
	int FlashBombBuffID; // 0x160(0x4)
	uint8_t Pad_0x164[0x4]; // 0x164(0x4)
	struct FBlackboardKeySelector BBKeyHasSensedGrenade; // 0x168(0x28)
	float StopVelocityThreshold; // 0x190(0x4)
	uint8_t Pad_0x194[0x4]; // 0x194(0x4)
};

// Object: Class AI.BTService_Shooting
// Size: 0x68 (Inherited: 0x68)
struct UBTService_Shooting : UBTService
{
	float DeviationScale; // 0x64(0x4)
};

// Object: Class AI.BTService_SimpleCheckBehindEnemy
// Size: 0xA0 (Inherited: 0x68)
struct UBTService_SimpleCheckBehindEnemy : UBTService
{
	struct FBlackboardKeySelector IsFoundBehindEnemyKey; // 0x68(0x28)
	float SensedRadius; // 0x90(0x4)
	float SensedBehindAngle; // 0x94(0x4)
	float SensedHeightDiff; // 0x98(0x4)
	bool DontAttackWhenTargetInWater; // 0x9C(0x1)
	bool SenseEnemyWithLineTrace; // 0x9D(0x1)
	uint8_t Pad_0x9E[0x2]; // 0x9E(0x2)
};

// Object: Class AI.BTService_SimpleShooting
// Size: 0x80 (Inherited: 0x68)
struct UBTService_SimpleShooting : UBTService
{
	float DeviationScale; // 0x64(0x4)
	struct FVector2D ShootUpDownRange; // 0x68(0x8)
	struct FVector2D RandomShootFreqRange; // 0x70(0x8)
	bool bShowDebugLine; // 0x78(0x1)
	float LineLifeTime; // 0x7C(0x4)
};

// Object: Class AI.BTService_Tank_RotateTurret
// Size: 0xC8 (Inherited: 0x68)
struct UBTService_Tank_RotateTurret : UBTService
{
	uint8_t bResetRotation : 1; // 0x61(0x1), Mask(0x1)
	uint8_t bAimingTarget : 1; // 0x61(0x1), Mask(0x2)
	struct FBlackboardKeySelector BBKeyAimingTarget; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeyAimingFinished; // 0x90(0x28)
	float AimingLockRange; // 0xB8(0x4)
	uint8_t BitPad_0xBC_2 : 6; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
	struct UAIBehaviorAdapter_Tank* OwnerAdapter; // 0xC0(0x8)
};

// Object: Class AI.BTService_Tank_Shooting
// Size: 0xC0 (Inherited: 0x68)
struct UBTService_Tank_Shooting : UBTService
{
	uint8_t bForceUseMG : 1; // 0x61(0x1), Mask(0x1)
	uint8_t bForceUseTurret : 1; // 0x61(0x1), Mask(0x2)
	uint8_t bRecordCoolDownBBK : 1; // 0x61(0x1), Mask(0x4)
	struct FBlackboardKeySelector BBKeyShootingCD; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeyAimingFailed; // 0x90(0x28)
	struct UAIBehaviorAdapter_Tank* OwnerAdapter; // 0xB8(0x8)
};

// Object: Class AI.BTService_TargetAngleCheck
// Size: 0x98 (Inherited: 0x68)
struct UBTService_TargetAngleCheck : UBTService
{
	float FocusTime; // 0x64(0x4)
	float FocusDegree; // 0x68(0x4)
	float DistanceSqr; // 0x6C(0x4)
	struct FBlackboardKeySelector FocusState; // 0x70(0x28)
};

// Object: Class AI.BTService_TargetEnemyHP
// Size: 0x68 (Inherited: 0x68)
struct UBTService_TargetEnemyHP : UBTService
{
};

// Object: Class AI.BTService_TurnAround
// Size: 0x98 (Inherited: 0x68)
struct UBTService_TurnAround : UBTService
{
	struct FBlackboardKeySelector OutTatget; // 0x68(0x28)
	float TurnAroundVelocity; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
};

// Object: Class AI.BTService_UseSkill
// Size: 0x98 (Inherited: 0x68)
struct UBTService_UseSkill : UBTService
{
	int SkillID; // 0x64(0x4)
	float CoolDown; // 0x68(0x4)
	float CastSkillDistance; // 0x6C(0x4)
	struct FBlackboardKeySelector SkillTargetBlackBoardKey; // 0x70(0x28)
};

// Object: Class AI.BTService_VH_ChooseEnemy
// Size: 0x80 (Inherited: 0x68)
struct UBTService_VH_ChooseEnemy : UBTService
{
	uint8_t bUseHatred : 1; // 0x61(0x1), Mask(0x1)
	uint8_t bOnlyPlayer : 1; // 0x61(0x1), Mask(0x2)
	uint8_t QueryEnemyRule; // 0x62(0x1)
	struct TArray<struct AActor*> IgnoreActorsClass; // 0x68(0x10)
	struct UAIBehaviorAdapter_VehicleBase* OwnerAdapter; // 0x78(0x8)
};

// Object: Class AI.BTService_WeaponHandler
// Size: 0x68 (Inherited: 0x68)
struct UBTService_WeaponHandler : UBTService
{
};

// Object: Class AI.BTService_WeatherTimeCount
// Size: 0xC8 (Inherited: 0x68)
struct UBTService_WeatherTimeCount : UBTService
{
	struct FBlackboardKeySelector StartCurrentWeatherCountDownBlackboardKey; // 0x68(0x28)
	struct FBlackboardKeySelector IsCurrentWeatherBlackboardKey; // 0x90(0x28)
	uint8_t NewWeatherStatusType; // 0xB8(0x1)
	uint8_t Pad_0xB9[0xF]; // 0xB9(0xF)
};

// Object: Class AI.BTTask_AddItem
// Size: 0xB0 (Inherited: 0x70)
struct UBTTask_AddItem : UBTTaskNode
{
	struct TArray<struct FTaskAddItem> ItemDatas; // 0x70(0x10)
	uint8_t bItemIDUseBBK : 1; // 0x80(0x1), Mask(0x1)
	uint8_t BitPad_0x80_1 : 7; // 0x80(0x1)
	uint8_t Pad_0x81[0x7]; // 0x81(0x7)
	struct FBlackboardKeySelector BlackboardKey; // 0x88(0x28)
};

// Object: Class AI.BTTask_AdvancedWait
// Size: 0xC8 (Inherited: 0x78)
struct UBTTask_AdvancedWait : UBTTask_Wait
{
	bool bUseDifficultyLevel; // 0x74(0x1)
	struct TMap<int, struct FDifficultyTimeConfig> DifficultyTimeCfg; // 0x78(0x50)
};

// Object: Class AI.BTTask_AdvFindOcclusionPoint
// Size: 0x130 (Inherited: 0x98)
struct UBTTask_AdvFindOcclusionPoint : UBTTask_BlackboardBase
{
	float SearchRadius; // 0x98(0x4)
	float UseLastPointRadius; // 0x9C(0x4)
	struct FBlackboardKeySelector BBKeyOcclusionLocation; // 0xA0(0x28)
	bool bDebug; // 0xC8(0x1)
	bool bChoosePointByEnemy; // 0xC9(0x1)
	uint8_t Pad_0xCA[0x2]; // 0xCA(0x2)
	float CirclePainThreshold; // 0xCC(0x4)
	bool DoNotUseCurrentOcclusionFirst; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	float CurrentOcclusionRadius; // 0xD4(0x4)
	struct TArray<uint8_t> AcceptableOcclusionTypeArray; // 0xD8(0x10)
	bool bUsePointNearSelfCompareToEnemy; // 0xE8(0x1)
	bool bUseNavMeshDistance; // 0xE9(0x1)
	uint8_t Pad_0xEA[0x2]; // 0xEA(0x2)
	float MaxNavMeshSearchDistance; // 0xEC(0x4)
	uint8_t searchBestOcclusionMethod; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float OcclusionPointChooseZFactor; // 0xF4(0x4)
	float OcclusionPointChooseBushFactor; // 0xF8(0x4)
	bool ChooseAttackableOcclusionFirst; // 0xFC(0x1)
	uint8_t Pad_0xFD[0x3]; // 0xFD(0x3)
	float ChooseAttackableOcclusionFactor; // 0x100(0x4)
	float OcclusionPadAngle_Normal; // 0x104(0x4)
	float OcclusionPadAngle_Aggressive; // 0x108(0x4)
	bool ChooseAttackableOcclusionWithLineTrace; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	float SelfStandHalfHeight; // 0x110(0x4)
	bool ChooseTagOcclusionEnable; // 0x114(0x1)
	uint8_t Pad_0x115[0x3]; // 0x115(0x3)
	struct FString OcclusionTagForChosen; // 0x118(0x10)
	bool bIgnorePossibleAttackableOcclusion; // 0x128(0x1)
	uint8_t Pad_0x129[0x7]; // 0x129(0x7)
};

// Object: Class AI.BTTask_AnimalFindDirectedPoint
// Size: 0xE8 (Inherited: 0x70)
struct UBTTask_AnimalFindDirectedPoint : UBTTaskNode
{
	struct FVector2D DistanceRange; // 0x6C(0x8)
	struct FVector2D AngleRange; // 0x74(0x8)
	float TraceHeightOffset; // 0x7C(0x4)
	uint32_t TryFindLocNum; // 0x80(0x4)
	bool bDoWaterTest; // 0x84(0x1)
	bool bDoNavmeshProjectTest; // 0x85(0x1)
	struct UNavigationQueryFilter* ProjectFilterClass; // 0x88(0x8)
	bool bDoLimitFindPointArea; // 0x90(0x1)
	uint8_t Pad_0x93[0x5]; // 0x93(0x5)
	struct FBlackboardKeySelector TargetBlackboardKey; // 0x98(0x28)
	struct FBlackboardKeySelector OutputBlackboardKey; // 0xC0(0x28)
};

// Object: Class AI.BTTask_AnimalFindRandomPoint
// Size: 0xF0 (Inherited: 0x70)
struct UBTTask_AnimalFindRandomPoint : UBTTaskNode
{
	struct FVector2D SearchRadiusRange; // 0x6C(0x8)
	float TraceHeightOffset; // 0x74(0x4)
	uint32_t TryFindLocNum; // 0x78(0x4)
	bool bDoNavmeshProjectTest; // 0x7C(0x1)
	struct UNavigationQueryFilter* ProjectFilterClass; // 0x80(0x8)
	bool bDoOnlyStaticTrace; // 0x88(0x1)
	bool bDoWaterTest; // 0x89(0x1)
	bool bDoLimitFindPointArea; // 0x8A(0x1)
	float CollisionExcludeAngle; // 0x8C(0x4)
	bool bLimitResultInForwardAngle; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float LimitInForwardAngle; // 0x94(0x4)
	struct FBlackboardKeySelector CenterBlackboardKey; // 0x98(0x28)
	struct FBlackboardKeySelector OutputBlackboardKey; // 0xC0(0x28)
	bool bDebugDraw; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x3]; // 0xE9(0x3)
	float DebugDrawPointTime; // 0xEC(0x4)
};

// Object: Class AI.BTTask_AnimalMove
// Size: 0xD8 (Inherited: 0xB0)
struct UBTTask_AnimalMove : UBTTask_MoveTo
{
	uint8_t MovePose; // 0xAE(0x1)
	bool bRestorePoseWhenFinished; // 0xAF(0x1)
	bool bOpenCollisionDetect; // 0xB0(0x1)
	uint8_t Pad_0xB3[0x1]; // 0xB3(0x1)
	float CollisionDetectAdvancedTime; // 0xB4(0x4)
	float CollisionDetectFreq; // 0xB8(0x4)
	bool bUseSweep; // 0xBC(0x1)
	enum class ECollisionChannel TraceChannel; // 0xBD(0x1)
	bool bRandomAcceptableRadius; // 0xBE(0x1)
	uint8_t Pad_0xBF[0x1]; // 0xBF(0x1)
	struct FVector2D RandomAcceptableRadiusRange; // 0xC0(0x8)
	bool MoveWithOutPathFinding; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x3]; // 0xC9(0x3)
	float MoveFailReviseLocationInterval; // 0xCC(0x4)
	float MoveFailLocationSearchRadius; // 0xD0(0x4)
	bool bAsyncExecuteTask; // 0xD4(0x1)
	bool bShowTargetLoc; // 0xD5(0x1)
	bool bShowDetectLine; // 0xD6(0x1)
	uint8_t Pad_0xD7[0x1]; // 0xD7(0x1)
};

// Object: Class AI.BTTask_AnimalTeleport
// Size: 0xD0 (Inherited: 0x98)
struct UBTTask_AnimalTeleport : UBTTask_BlackboardBase
{
	float RangeMin; // 0x98(0x4)
	float RangeMax; // 0x9C(0x4)
	bool bDoOnlyStaticTrace; // 0xA0(0x1)
	bool OnlyTeleportToLand; // 0xA1(0x1)
	bool NotTeleportToHouse; // 0xA2(0x1)
	uint8_t Pad_0xA3[0x1]; // 0xA3(0x1)
	float OriginCheckRadius; // 0xA4(0x4)
	float DestCheckRadius; // 0xA8(0x4)
	float TraceHeightOffset; // 0xAC(0x4)
	float TargetLocZOffset; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct TArray<struct FString> ValidTraceActorIncludeName; // 0xB8(0x10)
	int TryFindLocNum; // 0xC8(0x4)
	bool bForceSuccess; // 0xCC(0x1)
	uint8_t Pad_0xCD[0x3]; // 0xCD(0x3)
};

// Object: Class AI.BTTask_BioVH_MoveTo
// Size: 0x138 (Inherited: 0xB0)
struct UBTTask_BioVH_MoveTo : UBTTask_MoveTo
{
	float ModifyMoveSpeed; // 0xB0(0x4)
	uint8_t bCheckBlock : 1; // 0xB4(0x1), Mask(0x1)
	uint8_t BitPad_0xB4_1 : 7; // 0xB4(0x1)
	uint8_t MoveType; // 0xB5(0x1)
	uint8_t bFaceToTarget : 1; // 0xB6(0x1), Mask(0x1)
	uint8_t BitPad_0xB6_1 : 7; // 0xB6(0x1)
	uint8_t Pad_0xB7[0x1]; // 0xB7(0x1)
	float FaceToTargetToleranceAngle; // 0xB8(0x4)
	float MaxDurationStayStuck; // 0xBC(0x4)
	float StuckSpeed; // 0xC0(0x4)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
	struct FBlackboardKeySelector BBKey_OutBlocked; // 0xC8(0x28)
	struct FBlackboardKeySelector BBKey_OutCannotReach; // 0xF0(0x28)
	float MaxExecutionDuration; // 0x118(0x4)
	bool IsCheckStuckUseMovePenetration; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	int MoveStuckFrameCount; // 0x120(0x4)
	uint8_t Pad_0x124[0x4]; // 0x124(0x4)
	struct ABioVehicleBase* BioVH; // 0x128(0x8)
	struct ABioVehicleAIController* BioVHAIC; // 0x130(0x8)
};

// Object: Class AI.BTTask_ChangeWalkSpeed
// Size: 0xA0 (Inherited: 0x70)
struct UBTTask_ChangeWalkSpeed : UBTTaskNode
{
	uint8_t iWalkType; // 0x69(0x1)
	bool bAccelerationConfig; // 0x6A(0x1)
	struct FBlackboardKeySelector KeyDefaultMaxAcceleration; // 0x70(0x28)
	bool IsEnableAcceleration; // 0x98(0x1)
	uint8_t Pad_0x9B[0x1]; // 0x9B(0x1)
	float MaxAcceleration; // 0x9C(0x4)
};

// Object: Class AI.BTTask_ClearBlackboardData
// Size: 0x98 (Inherited: 0x98)
struct UBTTask_ClearBlackboardData : UBTTask_BlackboardBase
{
};

// Object: Class AI.BTTask_ClearDelivery
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_ClearDelivery : UBTTaskNode
{
};

// Object: Class AI.BTTask_ConvertActorToRotaion
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_ConvertActorToRotaion : UBTTaskNode
{
	struct FBlackboardKeySelector ActorBlackboardKey; // 0x70(0x28)
	struct FBlackboardKeySelector ToRotationKey; // 0x98(0x28)
};

// Object: Class AI.BTTask_CopyBlackboardData
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_CopyBlackboardData : UBTTaskNode
{
	uint8_t ValueType; // 0x69(0x1)
	struct FBlackboardKeySelector SrcBlackboardKey; // 0x70(0x28)
	struct FBlackboardKeySelector TargetBlackboardKey; // 0x98(0x28)
};

// Object: Class AI.BTTask_CrowdMove
// Size: 0xE8 (Inherited: 0x98)
struct UBTTask_CrowdMove : UBTTask_BlackboardBase
{
	float StopMoveRadius; // 0x98(0x4)
	float UpdateDestIntervel; // 0x9C(0x4)
	bool bOpenPredictMovement; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float PredictMovementTime; // 0xA4(0x4)
	float ForceFacingTargetDist; // 0xA8(0x4)
	float TimeLimit; // 0xAC(0x4)
	bool bIsHalfFrame; // 0xB0(0x1)
	bool bSmoothLocation; // 0xB1(0x1)
	bool bSmoothRotation; // 0xB2(0x1)
	uint8_t Pad_0xB3[0x1]; // 0xB3(0x1)
	float SmoothLocationTime; // 0xB4(0x4)
	float SmoothRotationTime; // 0xB8(0x4)
	bool bOpenExceptCheck; // 0xBC(0x1)
	bool bOpenDebug; // 0xBD(0x1)
	bool bSetRotation; // 0xBE(0x1)
	bool bOpenSeparetionAdjust; // 0xBF(0x1)
	float TempMoveLocationRadius; // 0xC0(0x4)
	float UpdateTempLocIntervel; // 0xC4(0x4)
	uint8_t MoveType; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x7]; // 0xC9(0x7)
	struct UNavigationQueryFilter* FilterClass; // 0xD0(0x8)
	bool bEnableCustomSpeed; // 0xD8(0x1)
	uint8_t Pad_0xD9[0x3]; // 0xD9(0x3)
	float CustomSpeedValue; // 0xDC(0x4)
	float HeightOffsetForPathFinding; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
};

// Object: Class AI.BTTask_CrowdMoveToOcclusion
// Size: 0x128 (Inherited: 0xE8)
struct UBTTask_CrowdMoveToOcclusion : UBTTask_CrowdMove
{
	float SearchRadius; // 0xE4(0x4)
	float UseLastPointRadius; // 0xE8(0x4)
	float NearDistanceValue; // 0xEC(0x4)
	float PointInNearDistanceValue; // 0xF0(0x4)
	bool bChoosePointByEnemy; // 0xF4(0x1)
	bool bForceStand; // 0xF5(0x1)
	float CirclePainThreshold; // 0xF8(0x4)
	uint8_t Pad_0xFE[0x2]; // 0xFE(0x2)
	struct FBlackboardKeySelector EnemyBlackboardKey; // 0x100(0x28)
};

// Object: Class AI.BTTask_DealNextBuildingPathNode
// Size: 0xA0 (Inherited: 0x98)
struct UBTTask_DealNextBuildingPathNode : UBTTask_BlackboardBase
{
	float findSpotXYOffset; // 0x98(0x4)
	float findSpotZOffset; // 0x9C(0x4)
};

// Object: Class AI.BTTask_ShortDistanceMove
// Size: 0xE8 (Inherited: 0x98)
struct UBTTask_ShortDistanceMove : UBTTask_BlackboardBase
{
	uint8_t MoveType; // 0x98(0x1)
	uint8_t MovePathType; // 0x99(0x1)
	uint8_t Pad_0x9A[0x2]; // 0x9A(0x2)
	int SampleNumber; // 0x9C(0x4)
	struct FVector2D ControllPoint1; // 0xA0(0x8)
	struct FVector2D ControllPoint2; // 0xA8(0x8)
	struct FVector2D DirectionAngleRange; // 0xB0(0x8)
	struct FVector2D MoveTargetDistRange; // 0xB8(0x8)
	struct FVector2D ExecutionDuration; // 0xC0(0x8)
	float RePlanTime; // 0xC8(0x4)
	bool AlwaysSuccess; // 0xCC(0x1)
	uint8_t Pad_0xCD[0x3]; // 0xCD(0x3)
	float AcceptRadius; // 0xD0(0x4)
	bool StopOnOverlap; // 0xD4(0x1)
	bool UsePathfinding; // 0xD5(0x1)
	bool AllowPartialPath; // 0xD6(0x1)
	bool ProjectDestinationToNavigation; // 0xD7(0x1)
	float ExceptionRandomRadius; // 0xD8(0x4)
	bool DebugDrawPath; // 0xDC(0x1)
	uint8_t Pad_0xDD[0x3]; // 0xDD(0x3)
	struct UNavCostModifier* NavCostModifier; // 0xE0(0x8)
};

// Object: Class AI.BTTask_Escape
// Size: 0x128 (Inherited: 0xE8)
struct UBTTask_Escape : UBTTask_ShortDistanceMove
{
	float TryLineTestZOffset; // 0xE8(0x4)
	float TryLineTestDistance; // 0xEC(0x4)
	int MaxTrySampleTimes; // 0xF0(0x4)
	float MinTrySampleDistance; // 0xF4(0x4)
	float MinTryEscapeDistance; // 0xF8(0x4)
	float EscapeStopDistance; // 0xFC(0x4)
	struct FBlackboardKeySelector EnemyBlackboardKey; // 0x100(0x28)
};

// Object: Class AI.BTTask_MagicMove
// Size: 0xC8 (Inherited: 0xB0)
struct UBTTask_MagicMove : UBTTask_MoveTo
{
	uint8_t MoveType; // 0xAE(0x1)
	bool TickCheckMovePose; // 0xAF(0x1)
	float TimeLimit; // 0xB0(0x4)
	bool ForceSuccess; // 0xB4(0x1)
	bool MoveWithOutPathFinding; // 0xB5(0x1)
	bool GotoExceptionWhenFailed; // 0xB6(0x1)
	struct UNavCostModifier* NavCostModifier; // 0xB8(0x8)
	uint8_t bForceStandWhenAborted : 1; // 0xC0(0x1), Mask(0x1)
	uint8_t BitPad_0xC1_1 : 7; // 0xC1(0x1)
	uint8_t Pad_0xC2[0x6]; // 0xC2(0x6)
};

// Object: Class AI.BTTask_FindAndPickItem
// Size: 0xC8 (Inherited: 0xC8)
struct UBTTask_FindAndPickItem : UBTTask_MagicMove
{
};

// Object: Class AI.BTTask_FindAndPickupEquip
// Size: 0xB0 (Inherited: 0xB0)
struct UBTTask_FindAndPickupEquip : UBTTask_MoveTo
{
};

// Object: Class AI.BTTask_FindCustomActorWithTag
// Size: 0xC8 (Inherited: 0x98)
struct UBTTask_FindCustomActorWithTag : UBTTask_BlackboardBase
{
	float SphereRadius; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct TArray<enum class EObjectTypeQuery> QueryObjectType; // 0xA0(0x10)
	struct FName ActorTag; // 0xB0(0x8)
	struct AActor* ActorClassFilter; // 0xB8(0x8)
	float IgnoreDistance; // 0xC0(0x4)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
};

// Object: Class AI.BTTask_FindFlyingHoverPoint
// Size: 0x138 (Inherited: 0x70)
struct UBTTask_FindFlyingHoverPoint : UBTTaskNode
{
	uint8_t HoverType; // 0x69(0x1)
	struct TArray<uint8_t> LocProjectStrategyArray; // 0x70(0x10)
	struct FBlackboardKeySelector BBKeyHoverLoc1; // 0x80(0x28)
	struct FBlackboardKeySelector BBKeyHoverLoc2; // 0xA8(0x28)
	struct FBlackboardKeySelector BBKeyHoverLoc3; // 0xD0(0x28)
	struct FBlackboardKeySelector BBKeyHoverLoc4; // 0xF8(0x28)
	uint8_t OneSideShapeOType; // 0x120(0x1)
	uint8_t Pad_0x122[0x2]; // 0x122(0x2)
	struct FVector2D OneSideShapeOForwardLength; // 0x124(0x8)
	struct FVector2D OneSideShapeOSideDirectionLength; // 0x12C(0x8)
	uint8_t Pad_0x134[0x4]; // 0x134(0x4)
};

// Object: Class AI.BTTask_FindNearestTombBoxTask
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_FindNearestTombBoxTask : UBTTask_BlackboardBase
{
	float PlayerBackpackSearchRadius; // 0x98(0x4)
	float AirDropSearchRadius; // 0x9C(0x4)
	float AirDropBoxRadius; // 0xA0(0x4)
	float MaxPainFindInBlueCircle; // 0xA4(0x4)
};

// Object: Class AI.BTTask_FindOcclusionPoint
// Size: 0xD0 (Inherited: 0x98)
struct UBTTask_FindOcclusionPoint : UBTTask_BlackboardBase
{
	float SearchRadius; // 0x98(0x4)
	bool bOcclusionSaveToBlackBoard; // 0x9C(0x1)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
	struct FBlackboardKeySelector BBKeyOcclusionLocation; // 0xA0(0x28)
	bool bDebug; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x7]; // 0xC9(0x7)
};

// Object: Class AI.BTTask_FindRandPosInOccupyPt
// Size: 0xC8 (Inherited: 0x70)
struct UBTTask_FindRandPosInOccupyPt : UBTTaskNode
{
	struct FBlackboardKeySelector OutOccupyPointActor; // 0x70(0x28)
	struct FBlackboardKeySelector OutOccupyPos; // 0x98(0x28)
	int MaxTryFindTime; // 0xC0(0x4)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
};

// Object: Class AI.BTTask_FindTargetPTInHardPT
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_FindTargetPTInHardPT : UBTTaskNode
{
	struct FBlackboardKeySelector InHardPTKey; // 0x70(0x28)
	struct FBlackboardKeySelector OutTargetPTKey; // 0x98(0x28)
};

// Object: Class AI.BTTask_FindWayPoint
// Size: 0xE0 (Inherited: 0x98)
struct UBTTask_FindWayPoint : UBTTask_BlackboardBase
{
	float InPointRadius; // 0x98(0x4)
	uint8_t MaxRandIterTimes; // 0x9C(0x1)
	bool bRandUseNav; // 0x9D(0x1)
	bool bDebugDraw; // 0x9E(0x1)
	uint8_t Pad_0x9F[0x1]; // 0x9F(0x1)
	float DebugDrawPointTime; // 0xA0(0x4)
	float FindPointRange; // 0xA4(0x4)
	float RandomTargetLocRadius; // 0xA8(0x4)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
	struct FBlackboardKeySelector BBK_CurrentWayPoint; // 0xB0(0x28)
	bool bFindNextInRange; // 0xD8(0x1)
	uint8_t bUseNotTeamedWayPoints : 1; // 0xD9(0x1), Mask(0x1)
	uint8_t BitPad_0xD9_1 : 7; // 0xD9(0x1)
	uint8_t Pad_0xDA[0x6]; // 0xDA(0x6)
};

// Object: Class AI.BTTask_FindWayPointByIDList
// Size: 0xE8 (Inherited: 0x98)
struct UBTTask_FindWayPointByIDList : UBTTask_BlackboardBase
{
	bool bDebugDraw; // 0x98(0x1)
	uint8_t Pad_0x99[0x3]; // 0x99(0x3)
	float DebugDrawPointTime; // 0x9C(0x4)
	float FindPointRange; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct FBlackboardKeySelector BBK_CurrentWayPoint; // 0xA8(0x28)
	struct TArray<int> SpecificIDList; // 0xD0(0x10)
	uint8_t FindWayPointType; // 0xE0(0x1)
	uint8_t bUseNotTeamedWayPoints : 1; // 0xE1(0x1), Mask(0x1)
	uint8_t BitPad_0xE1_1 : 7; // 0xE1(0x1)
	uint8_t Pad_0xE2[0x6]; // 0xE2(0x6)
};

// Object: Class AI.BTTask_FinishOrder
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_FinishOrder : UBTTaskNode
{
	uint8_t bResult : 1; // 0x69(0x1), Mask(0x1)
};

// Object: Class AI.BTTask_FlyAlongSpline
// Size: 0x148 (Inherited: 0x70)
struct UBTTask_FlyAlongSpline : UBTTaskNode
{
	struct AActor* SplineActorClass; // 0x70(0x8)
	struct FVector SplineActorLocation; // 0x78(0xC)
	struct FRotator SplineActorRotation; // 0x84(0xC)
	struct FBlackboardKeySelector BBKeySplineLocation; // 0x90(0x28)
	struct FBlackboardKeySelector BBKeySplineActor; // 0xB8(0x28)
	float ReachAcceptableDistance; // 0xE0(0x4)
	float FullPathDuration; // 0xE4(0x4)
	float MaxFlyDuration; // 0xE8(0x4)
	float MaxProtectStationaryDuration; // 0xEC(0x4)
	bool bVelocityUpdateUseLerp; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float VelocityUpdateLerpSpeed; // 0xF4(0x4)
	bool bAutoFitSplineWithHorizonalCircle; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x3]; // 0xF9(0x3)
	float CircleRadius; // 0xFC(0x4)
	int AutoFitFactor; // 0x100(0x4)
	float SplineCurveTangentLength; // 0x104(0x4)
	float SplineCurveFirstTwoTangentLength; // 0x108(0x4)
	bool bStopWhenReadyToAttack; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	float ExecuteDurationAtLeast; // 0x110(0x4)
	struct FVector2D AttackDistRangeToTarget; // 0x114(0x8)
	bool bCompareInXY; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	struct FBlackboardKeySelector BBKeyTargetActor; // 0x120(0x28)
};

// Object: Class AI.BTTask_FlyTo
// Size: 0xD8 (Inherited: 0x70)
struct UBTTask_FlyTo : UBTTaskNode
{
	struct FBlackboardKeySelector BBKeyFlyToTarget; // 0x70(0x28)
	float FlySpeedRatio; // 0x98(0x4)
	bool bUse3DNavigation; // 0x9C(0x1)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
	float OverrideAgentRadius; // 0xA0(0x4)
	bool bEnableFlyCurveSimulate; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	float FlyCurvatureFactor; // 0xA8(0x4)
	float FlyCurveSimulationMinAngle; // 0xAC(0x4)
	int FlyCurveSimulationLineSegemnts; // 0xB0(0x4)
	uint8_t PathfindingThread; // 0xB4(0x1)
	uint8_t Pad_0xB5[0x3]; // 0xB5(0x3)
	struct TArray<uint8_t> PartialStrategyArray; // 0xB8(0x10)
	bool bBrakingBeforeDestination; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x3]; // 0xC9(0x3)
	float DistanceOfBrakingBeforeDestination; // 0xCC(0x4)
	float FlySpeedRatioOfBrakingBeforeDestination; // 0xD0(0x4)
	bool bDrawDebugPath; // 0xD4(0x1)
	uint8_t Pad_0xD5[0x3]; // 0xD5(0x3)
};

// Object: Class AI.BTTask_ForceIdle
// Size: 0xE8 (Inherited: 0x70)
struct UBTTask_ForceIdle : UBTTaskNode
{
	bool bUseCustomIdelParam; // 0x69(0x1)
	float IdleTime; // 0x6C(0x4)
	float RandomDeviation; // 0x70(0x4)
	bool bRandIdle; // 0x74(0x1)
	int IdleBlendSpaceValue; // 0x78(0x4)
	uint8_t Pad_0x7E[0x2]; // 0x7E(0x2)
	struct TArray<int> ValidIdleBSValues; // 0x80(0x10)
	struct FBlackboardKeySelector KeyIdleTime; // 0x90(0x28)
	struct FBlackboardKeySelector KeyIdleBlendSpaceValue; // 0xB8(0x28)
	bool bFinishResetIdle; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
};

// Object: Class AI.BTTask_GeneralActivateNextWayPoint
// Size: 0xD0 (Inherited: 0x70)
struct UBTTask_GeneralActivateNextWayPoint : UBTTaskNode
{
	float FindPointRange; // 0x6C(0x4)
	float HasReachedRadius; // 0x70(0x4)
	struct FBlackboardKeySelector CurrentWayPointActor; // 0x78(0x28)
	struct FBlackboardKeySelector LastWayPointActor; // 0xA0(0x28)
	bool ReachedEndNoNextWayPointRetFalse; // 0xC8(0x1)
	bool bFindNextInRange; // 0xC9(0x1)
	bool bSendEvent; // 0xCA(0x1)
	uint8_t Pad_0xCB[0x5]; // 0xCB(0x5)
};

// Object: Class AI.BTTask_GeneralAIWayPointPathSelector
// Size: 0xA0 (Inherited: 0x70)
struct UBTTask_GeneralAIWayPointPathSelector : UBTTaskNode
{
	struct FName NameOfWayPointSelector; // 0x70(0x8)
	struct FBlackboardKeySelector CurrentEventWayPointActor; // 0x78(0x28)
};

// Object: Class AI.BTTask_GeneralExecuteEventsOfWayPoint
// Size: 0xD0 (Inherited: 0x70)
struct UBTTask_GeneralExecuteEventsOfWayPoint : UBTTaskNode
{
	struct FBlackboardKeySelector CurrentEventWayPointActor; // 0x70(0x28)
	bool bEnableWait; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
	struct UCurveFloat* WaitTimeCurveFloat; // 0xA0(0x8)
	float FixedWaitTime; // 0xA8(0x4)
	bool bDirectRotateAIOrRotateToControllerRotation; // 0xAC(0x1)
	uint8_t Pad_0xAD[0x3]; // 0xAD(0x3)
	struct TArray<struct FWayPointEvent> CacheWayPointEvents; // 0xB0(0x10)
	struct AAIEventWayPointActor* CurrentEventWayPointActorPtr; // 0xC0(0x8)
	uint8_t Pad_0xC8[0x8]; // 0xC8(0x8)
};

// Object: Class AI.BTTask_GeneralExecuteEventsOfWayPointNew
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_GeneralExecuteEventsOfWayPointNew : UBTTaskNode
{
	struct FBlackboardKeySelector CurrentEventWayPointActor; // 0x70(0x28)
};

// Object: Class AI.BTTask_GeneralFindAttackablePosition
// Size: 0xF8 (Inherited: 0x70)
struct UBTTask_GeneralFindAttackablePosition : UBTTaskNode
{
	struct FBlackboardKeySelector BBKeyTargetEnemy; // 0x70(0x28)
	struct FBlackboardKeySelector BBKeyFoundAttackablePosition; // 0x98(0x28)
	uint8_t bReachableTest : 1; // 0xC0(0x1), Mask(0x1)
	uint8_t bFilterOutBehaviorRegion : 1; // 0xC0(0x1), Mask(0x2)
	uint8_t bUseNavSystem : 1; // 0xC0(0x1), Mask(0x4)
	uint8_t BitPad_0xC0_3 : 5; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x3]; // 0xC1(0x3)
	float MaxAttackableRadius; // 0xC4(0x4)
	float ScanMinOuterCircleRadius; // 0xC8(0x4)
	float ScanRingWidth; // 0xCC(0x4)
	int MaxIterations; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct TArray<struct FGeneralRandLocationRetryRule> retryRules; // 0xD8(0x10)
	float HeightTestOffset; // 0xE8(0x4)
	bool bUseCapsuleTrace; // 0xEC(0x1)
	uint8_t Pad_0xED[0x3]; // 0xED(0x3)
	float TraceCapsuleScale; // 0xF0(0x4)
	bool bOnlyLandscape; // 0xF4(0x1)
	uint8_t Pad_0xF5[0x3]; // 0xF5(0x3)
};

// Object: Class AI.BTTask_GeneralFindEscapePosition
// Size: 0xF0 (Inherited: 0x70)
struct UBTTask_GeneralFindEscapePosition : UBTTaskNode
{
	struct FBlackboardKeySelector BBKeyEscapeTarget; // 0x70(0x28)
	struct FBlackboardKeySelector BBKeyFoundEscapePosition; // 0x98(0x28)
	struct TArray<struct FGeneralRandLocationRetryRule> retryRules; // 0xC0(0x10)
	struct FVector2D EscapeDistanceRange; // 0xD0(0x8)
	bool bEnableEscapePointReachableTest; // 0xD8(0x1)
	bool bEnableMaxNavMeshDistanceCheck; // 0xD9(0x1)
	uint8_t Pad_0xDA[0x2]; // 0xDA(0x2)
	float fMaxNavMeshDistance; // 0xDC(0x4)
	bool bNoPartialPath; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x3]; // 0xE1(0x3)
	float HeightTestOffset; // 0xE4(0x4)
	bool bDebug; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
};

// Object: Class AI.BTTask_GeneralFindRandomPoint
// Size: 0x158 (Inherited: 0x70)
struct UBTTask_GeneralFindRandomPoint : UBTTaskNode
{
	struct FBlackboardKeySelector BBKey_OutPoint; // 0x70(0x28)
	int MaxTryTimes; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct FBlackboardKeySelector BBKey_BasePoint; // 0xA0(0x28)
	struct FBlackboardKeySelector BBKey_BaseRadiusRange; // 0xC8(0x28)
	struct FBlackboardKeySelector BBKey_BaseAngleRange; // 0xF0(0x28)
	struct FVector2D RandomRange; // 0x118(0x8)
	struct FVector2D RandomAngle; // 0x120(0x8)
	struct TArray<struct FVector2D> RandomAngleExtra; // 0x128(0x10)
	uint8_t bFilterBuilding : 1; // 0x138(0x1), Mask(0x1)
	uint8_t bFilterWater : 1; // 0x138(0x1), Mask(0x2)
	uint8_t bReachableTest : 1; // 0x138(0x1), Mask(0x4)
	uint8_t bFilterOutBehaviorRegion : 1; // 0x138(0x1), Mask(0x8)
	uint8_t bFindSpecialSurface : 1; // 0x138(0x1), Mask(0x10)
	uint8_t bUseBlackboardRange : 1; // 0x138(0x1), Mask(0x20)
	uint8_t BitPad_0x138_6 : 2; // 0x138(0x1)
	enum class EPhysicalSurface SurfaceType; // 0x139(0x1)
	uint8_t bUseNavmesh : 1; // 0x13A(0x1), Mask(0x1)
	uint8_t BitPad_0x13A_1 : 7; // 0x13A(0x1)
	uint8_t Pad_0x13B[0x5]; // 0x13B(0x5)
	struct FName SpecificNaVName; // 0x140(0x8)
	uint8_t bTraceBlock : 1; // 0x148(0x1), Mask(0x1)
	uint8_t BitPad_0x148_1 : 7; // 0x148(0x1)
	uint8_t Pad_0x149[0x3]; // 0x149(0x3)
	float SweepCapsuleScale; // 0x14C(0x4)
	enum class ECollisionChannel CollisionChannel; // 0x150(0x1)
	uint8_t Pad_0x151[0x3]; // 0x151(0x3)
	float MaxLocationTraceHeightZ; // 0x154(0x4)
};

// Object: Class AI.BTTask_GeneralSendEventOfEventWayPoint
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_GeneralSendEventOfEventWayPoint : UBTTaskNode
{
	struct FBlackboardKeySelector CurrentEventWayPointActor; // 0x70(0x28)
	struct FBlackboardKeySelector EventName; // 0x98(0x28)
};

// Object: Class AI.BTTask_GeneralStrategyMove
// Size: 0xC8 (Inherited: 0x98)
struct UBTTask_GeneralStrategyMove : UBTTask_BlackboardBase
{
	struct FVector2D DirectionAngleRange; // 0x98(0x8)
	struct FVector2D MoveTargetDistRange; // 0xA0(0x8)
	struct FVector2D ExecutionDuration; // 0xA8(0x8)
	float RePlanTime; // 0xB0(0x4)
	bool AlwaysSuccess; // 0xB4(0x1)
	uint8_t Pad_0xB5[0x3]; // 0xB5(0x3)
	float AcceptRadius; // 0xB8(0x4)
	bool StopOnOverlap; // 0xBC(0x1)
	bool UsePathfinding; // 0xBD(0x1)
	bool AllowPartialPath; // 0xBE(0x1)
	bool ProjectDestinationToNavigation; // 0xBF(0x1)
	float ExceptionRandomRadius; // 0xC0(0x4)
	bool bCanMoveWhenNoTarget; // 0xC4(0x1)
	bool bCheckWallPass; // 0xC5(0x1)
	bool DebugDrawPath; // 0xC6(0x1)
	uint8_t Pad_0xC7[0x1]; // 0xC7(0x1)
};

// Object: Class AI.BTTask_GeneralTriggerSkillEvent
// Size: 0x88 (Inherited: 0x70)
struct UBTTask_GeneralTriggerSkillEvent : UBTTaskNode
{
	bool bUseIndex; // 0x69(0x1)
	int skillindex; // 0x6C(0x4)
	int SkillID; // 0x70(0x4)
	struct FString EventName; // 0x78(0x10)
};

// Object: Class AI.BTTask_GetClosestPointFromVehicle
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_GetClosestPointFromVehicle : UBTTaskNode
{
	struct FBlackboardKeySelector OutClosestPoint; // 0x70(0x28)
	struct FBlackboardKeySelector OutHasClosestPoint; // 0x98(0x28)
};

// Object: Class AI.BTTask_GetRandomAttackablePosition
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_GetRandomAttackablePosition : UBTTask_BlackboardBase
{
	float AttackableRadius; // 0x98(0x4)
	float KeepDistanceFromTarget; // 0x9C(0x4)
	float RandomMoveRadius; // 0xA0(0x4)
	int RetryTimes; // 0xA4(0x4)
};

// Object: Class AI.BTTask_LaunchMove
// Size: 0x120 (Inherited: 0x70)
struct UBTTask_LaunchMove : UBTTaskNode
{
	bool bUseCacheJumpVelocity; // 0x69(0x1)
	struct FBlackboardKeySelector JumpVelocityBlackboardKey; // 0x70(0x28)
	bool bUseCustomDestLocation; // 0x98(0x1)
	uint8_t Pad_0x9A[0x6]; // 0x9A(0x6)
	struct FBlackboardKeySelector KeyLaunchToTarget; // 0xA0(0x28)
	float CustomDestDirAngle; // 0xC8(0x4)
	float CustomDestDistance; // 0xCC(0x4)
	bool UsePawnHalfHeightAsOffsetOfTargetLocation; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	struct FVector OffsetOfTargetLocation; // 0xD4(0xC)
	bool bDrawDebugLine; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x3]; // 0xE1(0x3)
	struct FVector2D JumpSpeedRange; // 0xE4(0x8)
	float JumpSpeedInterval; // 0xEC(0x4)
	enum class ESuggestProjVelocityTraceOption JumpProjTraceType; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float OverrideGravityZ; // 0xF4(0x4)
	float CollisionRadius; // 0xF8(0x4)
	bool bFavorHighArc; // 0xFC(0x1)
	bool bDrawDebug; // 0xFD(0x1)
	uint8_t Pad_0xFE[0x2]; // 0xFE(0x2)
	float CacheLastTossSpeed; // 0x100(0x4)
	int CacheLastIterations; // 0x104(0x4)
	struct FVector CacheLastTossVelocity; // 0x108(0xC)
	float CacheLastTossVelocityHorizontal; // 0x114(0x4)
	float CacheLastTossVelocityHertical; // 0x118(0x4)
	uint8_t Pad_0x11C[0x4]; // 0x11C(0x4)
};

// Object: Class AI.BTTask_MagicMoveAndJump
// Size: 0xD0 (Inherited: 0xC8)
struct UBTTask_MagicMoveAndJump : UBTTask_MagicMove
{
	float MinJumpInterval; // 0xC4(0x4)
	float MaxJumpInterval; // 0xC8(0x4)
};

// Object: Class AI.BTTask_Mob_CastSkill
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_Mob_CastSkill : UBTTaskNode
{
	int SkillID; // 0x6C(0x4)
	int skillindex; // 0x70(0x4)
	bool bFailWhenCastFailed; // 0x74(0x1)
};

// Object: Class AI.BTTask_Mob_EnterState
// Size: 0xA0 (Inherited: 0x98)
struct UBTTask_Mob_EnterState : UBTTask_BlackboardBase
{
	uint8_t IState; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: Class AI.BTTask_Mob_Explode
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_Mob_Explode : UBTTask_BlackboardBase
{
	int ExplodeSkillIndex; // 0x98(0x4)
	int SkillID; // 0x9C(0x4)
	enum class EUTSkillEventType ExplodeSkillType; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x7]; // 0xA1(0x7)
};

// Object: Class AI.BTTask_Mob_FaceEnemy
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_Mob_FaceEnemy : UBTTask_BlackboardBase
{
	float AcceptableAngle; // 0x98(0x4)
	float turnSpeed; // 0x9C(0x4)
	bool bUsePhysRotate; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float MaxExecuteTime; // 0xA4(0x4)
};

// Object: Class AI.BTTask_Mob_FindNextPathPosition
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_Mob_FindNextPathPosition : UBTTaskNode
{
	float SearchDistanceFromSpawnPointSq; // 0x6C(0x4)
};

// Object: Class AI.BTTask_Mob_FindNextPatrolPosition
// Size: 0xD8 (Inherited: 0x70)
struct UBTTask_Mob_FindNextPatrolPosition : UBTTaskNode
{
	float SearchDistanceFromSpawnPoint; // 0x6C(0x4)
	bool bEnableRaycastTest; // 0x70(0x1)
	float MinSquaredDistanceFromSpawnPoint; // 0x74(0x4)
	bool bIsCenterApplyBlackBoardValue; // 0x78(0x1)
	uint8_t Pad_0x7A[0x6]; // 0x7A(0x6)
	struct FBlackboardKeySelector CustomCenterTarget; // 0x80(0x28)
	bool bIsRadiusApplyBlackBoardValue; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x7]; // 0xA9(0x7)
	struct FBlackboardKeySelector CustomRadius; // 0xB0(0x28)
};

// Object: Class AI.BTTask_Mob_FindPosByTarget
// Size: 0xD0 (Inherited: 0x98)
struct UBTTask_Mob_FindPosByTarget : UBTTask_BlackboardBase
{
	float SearchRadius; // 0x98(0x4)
	bool bUseNav; // 0x9C(0x1)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
	struct TArray<struct FMobRandLocationRetryRule> retryRules; // 0xA0(0x10)
	bool StopWhenFindPos; // 0xB0(0x1)
	bool KeepCloseToEnemy; // 0xB1(0x1)
	uint8_t Pad_0xB2[0x2]; // 0xB2(0x2)
	float MinMoveDistance; // 0xB4(0x4)
	float HeightTestOffset; // 0xB8(0x4)
	bool SimulateMoveWithLineCheck; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)
	float SimulateMoveDistance; // 0xC0(0x4)
	float SimulateCapsuleRadius; // 0xC4(0x4)
	float SimulateCapsuleHalfHeight; // 0xC8(0x4)
	bool IsDirForwardToTarget; // 0xCC(0x1)
	uint8_t Pad_0xCD[0x3]; // 0xCD(0x3)
};

// Object: Class AI.BTTask_Mob_FindRandomAttackablePosition
// Size: 0xD8 (Inherited: 0x98)
struct UBTTask_Mob_FindRandomAttackablePosition : UBTTask_BlackboardBase
{
	float AttackableRadius; // 0x98(0x4)
	float KeepDistanceFromTarget; // 0x9C(0x4)
	float MinMoveDistance; // 0xA0(0x4)
	bool WithLineTrace; // 0xA4(0x1)
	uint8_t lineTraceType; // 0xA5(0x1)
	uint8_t Pad_0xA6[0x2]; // 0xA6(0x2)
	float CustomLineTraceHeightOffset; // 0xA8(0x4)
	bool WithLineTraceTop; // 0xAC(0x1)
	uint8_t Pad_0xAD[0x3]; // 0xAD(0x3)
	float HeightTestOffset; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct TArray<struct FMobRandLocationRetryRule> retryRules; // 0xB8(0x10)
	bool ReachableTest; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x3]; // 0xC9(0x3)
	float ReachableTestRadius; // 0xCC(0x4)
	bool EnableTriggerCastSkillBlockAfterFailed; // 0xD0(0x1)
	bool bDrawDebug; // 0xD1(0x1)
	uint8_t Pad_0xD2[0x2]; // 0xD2(0x2)
	int TriggerCastSkillBlockAfterFailedTimes; // 0xD4(0x4)
};

// Object: Class AI.BTTask_Mob_GetNearDeathCharNearby
// Size: 0xC8 (Inherited: 0x98)
struct UBTTask_Mob_GetNearDeathCharNearby : UBTTask_BlackboardBase
{
	struct FBlackboardKeySelector TargetChar; // 0x98(0x28)
	float SearchRadius; // 0xC0(0x4)
	float CheckInterval; // 0xC4(0x4)
};

// Object: Class AI.BTTask_Mob_GetRandomAttackTargetInRadius
// Size: 0xB8 (Inherited: 0x98)
struct UBTTask_Mob_GetRandomAttackTargetInRadius : UBTTask_BlackboardBase
{
	int TriggerMinTimes; // 0x98(0x4)
	int TriggerMaxTimes; // 0x9C(0x4)
	int ChooseCurEnemyProbability; // 0xA0(0x4)
	uint8_t searchType; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	float SearchRadius; // 0xA8(0x4)
	struct FVector SpecificLocation; // 0xAC(0xC)
};

// Object: Class AI.BTTask_Mob_GetRandomSkill
// Size: 0xA0 (Inherited: 0x98)
struct UBTTask_Mob_GetRandomSkill : UBTTask_BlackboardBase
{
	bool DontChangeSkillWhenTargetNearBossContainer; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: Class AI.BTTask_Mob_GetTargetVehicle
// Size: 0xC0 (Inherited: 0x98)
struct UBTTask_Mob_GetTargetVehicle : UBTTask_BlackboardBase
{
	struct FBlackboardKeySelector TargetVehicle; // 0x98(0x28)
};

// Object: Class AI.BTTask_Mob_GetVehicleNearby
// Size: 0xC8 (Inherited: 0x98)
struct UBTTask_Mob_GetVehicleNearby : UBTTask_BlackboardBase
{
	struct FBlackboardKeySelector TargetVehicle; // 0x98(0x28)
	float SearchRadius; // 0xC0(0x4)
	float CheckInterval; // 0xC4(0x4)
};

// Object: Class AI.BTTask_Mob_LeaveState
// Size: 0xA0 (Inherited: 0x98)
struct UBTTask_Mob_LeaveState : UBTTask_BlackboardBase
{
	uint8_t IState; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
};

// Object: Class AI.BTTask_Mob_LinkGetJumpVelocity
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_Mob_LinkGetJumpVelocity : UBTTask_BlackboardBase
{
	float JumpForwardOffset; // 0x98(0x4)
	struct FVector2D JumpSpeedRange; // 0x9C(0x8)
	enum class ESuggestProjVelocityTraceOption Stride_JumpProjTraceType; // 0xA4(0x1)
	bool SetJumpFaceAngle; // 0xA5(0x1)
	uint8_t Pad_0xA6[0x2]; // 0xA6(0x2)
};

// Object: Class AI.BTTask_Mob_MoveTo
// Size: 0xD0 (Inherited: 0xB0)
struct UBTTask_Mob_MoveTo : UBTTask_MoveTo
{
	float BlockTimeLimit; // 0xB0(0x4)
	float BlockVelocitySizeThreshold; // 0xB4(0x4)
	bool BlockDistCheck; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	float BlockThresholdValidMoveDist; // 0xBC(0x4)
	float BlockThresholdValidMoveTime; // 0xC0(0x4)
	float BlockThresholdValidVelocitySize; // 0xC4(0x4)
	bool ForceSuccess; // 0xC8(0x1)
	bool GotoExceptionWhenFailed; // 0xC9(0x1)
	bool SupportWalkType; // 0xCA(0x1)
	uint8_t iWalkType; // 0xCB(0x1)
	uint8_t bMobUsePathFinding : 1; // 0xCC(0x1), Mask(0x1)
	uint8_t BitPad_0xCC_1 : 7; // 0xCC(0x1)
	bool bEnableDebugLog; // 0xCD(0x1)
	bool bUseNodeMemoryForBlockState; // 0xCE(0x1)
	uint8_t Pad_0xCF[0x1]; // 0xCF(0x1)
};

// Object: Class AI.BTTask_Mob_NewFindPatrolPosition
// Size: 0xB0 (Inherited: 0x70)
struct UBTTask_Mob_NewFindPatrolPosition : UBTTaskNode
{
	float SearchDistanceFromSpawnPoint; // 0x6C(0x4)
	float MinMoveDistance; // 0x70(0x4)
	float fHalfAngle; // 0x74(0x4)
	int MaxExecuteTimes; // 0x78(0x4)
	float ExceptionRandomRadius; // 0x7C(0x4)
	bool bEnableRaycastTest; // 0x80(0x1)
	uint8_t Pad_0x85[0x3]; // 0x85(0x3)
	struct FBlackboardKeySelector KeyTargetLocation; // 0x88(0x28)
};

// Object: Class AI.BTTask_Mob_SnakeMove
// Size: 0xB8 (Inherited: 0x98)
struct UBTTask_Mob_SnakeMove : UBTTask_BlackboardBase
{
	float NormalDis; // 0x98(0x4)
	struct FVector2D DisOffset; // 0x9C(0x8)
	struct FVector2D AngleOffset; // 0xA4(0x8)
	float TaskMaxTime; // 0xAC(0x4)
	float AcceptRadius; // 0xB0(0x4)
	bool StopOnOverlap; // 0xB4(0x1)
	bool UsePathfinding; // 0xB5(0x1)
	bool AllowPartialPath; // 0xB6(0x1)
	bool ProjectDestinationToNavigation; // 0xB7(0x1)
};

// Object: Class AI.BTTask_Mob_Suicide
// Size: 0x98 (Inherited: 0x98)
struct UBTTask_Mob_Suicide : UBTTask_BlackboardBase
{
};

// Object: Class AI.BTTask_Mob_SwimDirect
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_Mob_SwimDirect : UBTTask_BlackboardBase
{
	float SwimVelocitySize; // 0x98(0x4)
	float AcceptableRadius; // 0x9C(0x4)
	bool bReachTestIncludesAgentRadius; // 0xA0(0x1)
	bool bReachTestIncludesGoalRadius; // 0xA1(0x1)
	uint8_t Pad_0xA2[0x6]; // 0xA2(0x6)
};

// Object: Class AI.BTTask_MobCMD_CastSkill
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_MobCMD_CastSkill : UBTTaskNode
{
	struct FBlackboardKeySelector SkillIndexBlackBoardKey; // 0x70(0x28)
};

// Object: Class AI.BTTask_ModifyBlackboardData
// Size: 0xB0 (Inherited: 0x98)
struct UBTTask_ModifyBlackboardData : UBTTask_BlackboardBase
{
	uint8_t ValueType; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
	struct FString SetValue; // 0xA0(0x10)
};

// Object: Class AI.BTTask_MoveAround
// Size: 0xF8 (Inherited: 0x98)
struct UBTTask_MoveAround : UBTTask_BlackboardBase
{
	float MoveRadius; // 0x98(0x4)
	float RotationSpeed; // 0x9C(0x4)
	uint8_t MoveType; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	struct FVector2D WaitTimeRange; // 0xA4(0x8)
	struct FVector2D ExecutionDuration; // 0xAC(0x8)
	float AcceptRadius; // 0xB4(0x4)
	bool bIncludeNeighborVerts; // 0xB8(0x1)
	bool bSetFocus; // 0xB9(0x1)
	bool bCanMoveWhenNoTarget; // 0xBA(0x1)
	uint8_t Pad_0xBB[0x1]; // 0xBB(0x1)
	struct FVector2D DirectionAngleRange; // 0xBC(0x8)
	struct FVector2D MoveTargetDistRange; // 0xC4(0x8)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct FBlackboardKeySelector EnemyBlackboardKey; // 0xD0(0x28)
};

// Object: Class AI.BTTask_MoveToOcclusion
// Size: 0x170 (Inherited: 0xC8)
struct UBTTask_MoveToOcclusion : UBTTask_MagicMove
{
	float SearchRadius; // 0xC4(0x4)
	float UseLastPointRadius; // 0xC8(0x4)
	bool bChoosePointByEnemy; // 0xCC(0x1)
	bool bForceStand; // 0xCD(0x1)
	float CirclePainThreshold; // 0xD0(0x4)
	bool DoNotUseCurrentOcclusionFirst; // 0xD4(0x1)
	uint8_t Pad_0xD7[0x1]; // 0xD7(0x1)
	float CurrentOcclusionRadius; // 0xD8(0x4)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
	struct TArray<uint8_t> AcceptableOcclusionTypeArray; // 0xE0(0x10)
	bool bUsePointNearSelfCompareToEnemy; // 0xF0(0x1)
	bool bUseNavMeshDistance; // 0xF1(0x1)
	uint8_t Pad_0xF2[0x2]; // 0xF2(0x2)
	float MaxNavMeshSearchDistance; // 0xF4(0x4)
	uint8_t searchBestOcclusionMethod; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x3]; // 0xF9(0x3)
	float OcclusionPointChooseZFactor; // 0xFC(0x4)
	float OcclusionPointChooseBushFactor; // 0x100(0x4)
	bool ChooseAttackableOcclusionFirst; // 0x104(0x1)
	uint8_t Pad_0x105[0x3]; // 0x105(0x3)
	float ChooseAttackableOcclusionFactor; // 0x108(0x4)
	float OcclusionPadAngle_Normal; // 0x10C(0x4)
	float OcclusionPadAngle_Aggressive; // 0x110(0x4)
	bool ChooseAttackableOcclusionWithLineTrace; // 0x114(0x1)
	uint8_t Pad_0x115[0x3]; // 0x115(0x3)
	float SelfStandHalfHeight; // 0x118(0x4)
	bool ChooseTagOcclusionEnable; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	struct FString OcclusionTagForChosen; // 0x120(0x10)
	bool bIgnorePossibleAttackableOcclusion; // 0x130(0x1)
	uint8_t bChooseGeneratedOcclusionPoints : 1; // 0x131(0x1), Mask(0x1)
	uint8_t BitPad_0x131_1 : 7; // 0x131(0x1)
	bool bDebug; // 0x132(0x1)
	uint8_t Pad_0x133[0x5]; // 0x133(0x5)
	struct FBlackboardKeySelector EnemyBlackboardKey; // 0x138(0x28)
	uint8_t MovingPoseType; // 0x160(0x1)
	uint8_t Pad_0x161[0x3]; // 0x161(0x3)
	float MoveToOcclusionKeepCurPoseDistance; // 0x164(0x4)
	uint8_t finishMovePoseType; // 0x168(0x1)
	uint8_t Pad_0x169[0x3]; // 0x169(0x3)
	float OccupiedRadius; // 0x16C(0x4)
};

// Object: Class AI.BTTask_MoveToSafeArea
// Size: 0xD8 (Inherited: 0xC8)
struct UBTTask_MoveToSafeArea : UBTTask_MagicMove
{
	float RadiusScale; // 0xC4(0x4)
	float BlueCircleOffsetRadius; // 0xC8(0x4)
	struct FVector2D RandomLength; // 0xCC(0x8)
};

// Object: Class AI.BTTask_PickUpItemAtTombBox
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PickUpItemAtTombBox : UBTTaskNode
{
	float DeltaTime; // 0x6C(0x4)
	int MaxPickCount; // 0x70(0x4)
};

// Object: Class AI.BTTask_RotateToTarget
// Size: 0xB0 (Inherited: 0x70)
struct UBTTask_RotateToTarget : UBTTaskNode
{
	struct FBlackboardKeySelector InRotationTarget; // 0x70(0x28)
	struct UCurveFloat* TimeCurve; // 0x98(0x8)
	float DefaultWaitTime; // 0xA0(0x4)
	float FinishWaitTime; // 0xA4(0x4)
	bool bShowLog; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x7]; // 0xA9(0x7)
};

// Object: Class AI.BTTask_RunBBSubTree
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_RunBBSubTree : UBTTaskNode
{
	struct FBlackboardKeySelector SubBehaviorTreeBlackBoardKey; // 0x70(0x28)
};

// Object: Class AI.BTTask_RunMultiDynamicSubTree
// Size: 0x88 (Inherited: 0x70)
struct UBTTask_RunMultiDynamicSubTree : UBTTaskNode
{
	struct UBehaviorTree* MainBehaviorAsset; // 0x70(0x8)
	struct TArray<struct FBlackBoardSubTreeConfig> SubBehaviorAssetArray; // 0x78(0x10)
};

// Object: Class AI.BTTask_SeekFlyPoint
// Size: 0x100 (Inherited: 0x70)
struct UBTTask_SeekFlyPoint : UBTTaskNode
{
	struct FBlackboardKeySelector BBKeyTargetEnemy; // 0x70(0x28)
	struct FBlackboardKeySelector BBKeyFoundFlyPoint; // 0x98(0x28)
	uint8_t ChooseFlyPointCenterLocType; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x3]; // 0xC1(0x3)
	struct FVector2D ChooseFlyPointHorizontalRadiusRange; // 0xC4(0x8)
	struct FVector2D ChooseFlyPointHeightRange; // 0xCC(0x8)
	uint8_t HorizontalAngleType; // 0xD4(0x1)
	uint8_t Pad_0xD5[0x3]; // 0xD5(0x3)
	struct FVector2D ChooseFlyPointAngleRange; // 0xD8(0x8)
	float AcceptableMinMoveDistance; // 0xE0(0x4)
	float AcceptableMinVerticalAngle; // 0xE4(0x4)
	float AcceptableMaxHorizontalAngleFromLastMove; // 0xE8(0x4)
	int MaxSearchTimes; // 0xEC(0x4)
	int PerConditionExtraSearchTimes; // 0xF0(0x4)
	float OverrideAgentRadius; // 0xF4(0x4)
	bool bFirstInChooseAsBornLocation; // 0xF8(0x1)
	bool FlyToLastPointWhenFailed; // 0xF9(0x1)
	uint8_t Pad_0xFA[0x6]; // 0xFA(0x6)
};

// Object: Class AI.BTTask_SetDownwardPos
// Size: 0xE8 (Inherited: 0x70)
struct UBTTask_SetDownwardPos : UBTTaskNode
{
	struct FBlackboardKeySelector ActorBlackboardKey; // 0x70(0x28)
	struct FBlackboardKeySelector PosBlackboardKey; // 0x98(0x28)
	float DownwardTraceDistance; // 0xC0(0x4)
	float OffsetZ; // 0xC4(0x4)
	struct TArray<struct UObject*> TracableObjectTemplate; // 0xC8(0x10)
	bool bForceSuccess; // 0xD8(0x1)
	uint8_t Pad_0xD9[0x3]; // 0xD9(0x3)
	float SearchRadius; // 0xDC(0x4)
	bool bIgnoreStartPenetratingLoc; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
};

// Object: Class AI.BTTask_SpawnItem
// Size: 0xB0 (Inherited: 0x98)
struct UBTTask_SpawnItem : UBTTask_BlackboardBase
{
	float CheckNoPlayerRadiusSquare; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct TArray<struct FAIEquipSpawnGroupDataBase> SpawnEquipDataBase; // 0xA0(0x10)
};

// Object: Class AI.BTTask_StrategyMove
// Size: 0xF0 (Inherited: 0x98)
struct UBTTask_StrategyMove : UBTTask_BlackboardBase
{
	bool bIsSimpleCharacter; // 0x98(0x1)
	uint8_t MoveType; // 0x99(0x1)
	uint8_t MovePathType; // 0x9A(0x1)
	uint8_t Pad_0x9B[0x1]; // 0x9B(0x1)
	int SampleNumber; // 0x9C(0x4)
	struct FVector2D ControllPoint1; // 0xA0(0x8)
	struct FVector2D ControllPoint2; // 0xA8(0x8)
	struct FVector2D DirectionAngleRange; // 0xB0(0x8)
	struct FVector2D MoveTargetDistRange; // 0xB8(0x8)
	struct FVector2D ExecutionDuration; // 0xC0(0x8)
	bool bStopMoveWhenExecutionDurationRanOut; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x3]; // 0xC9(0x3)
	float RePlanTime; // 0xCC(0x4)
	bool AlwaysSuccess; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	float AcceptRadius; // 0xD4(0x4)
	bool StopOnOverlap; // 0xD8(0x1)
	bool UsePathfinding; // 0xD9(0x1)
	bool AllowPartialPath; // 0xDA(0x1)
	bool ProjectDestinationToNavigation; // 0xDB(0x1)
	float ExceptionRandomRadius; // 0xDC(0x4)
	bool bCanMoveWhenNoTarget; // 0xE0(0x1)
	bool bCheckWallPass; // 0xE1(0x1)
	bool DebugDrawPath; // 0xE2(0x1)
	uint8_t Pad_0xE3[0x5]; // 0xE3(0x5)
	struct UNavCostModifier* NavCostModifier; // 0xE8(0x8)
};

// Object: Class AI.BTTask_SummonActor
// Size: 0xC0 (Inherited: 0x70)
struct UBTTask_SummonActor : UBTTaskNode
{
	struct AActor* SummonActorClass; // 0x70(0x8)
	int SummonNum; // 0x78(0x4)
	int MaxSummonNum; // 0x7C(0x4)
	int MonsterResID; // 0x80(0x4)
	bool bUseSummonPoint; // 0x84(0x1)
	uint8_t Pad_0x85[0x3]; // 0x85(0x3)
	struct TArray<enum class EObjectTypeQuery> QueryObjectType; // 0x88(0x10)
	float SphereRadius; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct AActor* SummonLocationClass; // 0xA0(0x8)
	struct FVector OffsetMax; // 0xA8(0xC)
	struct FVector OffsetMin; // 0xB4(0xC)


	// Object: Function AI.BTTask_SummonActor.GetSummonLocations
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1047af464
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FVector> GetSummonLocations(struct AActor* Invoker);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104764D80
	// [Call #4] RVA: 0x10246DCBC
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x105190870
};

// Object: Class AI.BTTask_SwimInput
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_SwimInput : UBTTaskNode
{
	float SwimUpRate; // 0x6C(0x4)
};

// Object: Class AI.BTTask_TeleportToSpecLoc
// Size: 0xB8 (Inherited: 0x98)
struct UBTTask_TeleportToSpecLoc : UBTTask_BlackboardBase
{
	float RangeMin; // 0x98(0x4)
	float RangeMax; // 0x9C(0x4)
	bool OnlyTeleportToLand; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float OriginCheckSquare; // 0xA4(0x4)
	float DestCheckSquare; // 0xA8(0x4)
	float TraceHeight; // 0xAC(0x4)
	int HouseCheckTimes; // 0xB0(0x4)
	bool bCheckSight; // 0xB4(0x1)
	bool bForceSuccess; // 0xB5(0x1)
	uint8_t Pad_0xB6[0x2]; // 0xB6(0x2)
};

// Object: Class AI.BTTask_TryFightback
// Size: 0xD8 (Inherited: 0xC8)
struct UBTTask_TryFightback : UBTTask_MagicMove
{
	float MaxTraceRadius; // 0xC4(0x4)
	float MaxTraceTime; // 0xC8(0x4)
	float CheckTargetVisableTimeIntervel; // 0xCC(0x4)
	bool bIsCheckHasWeapon; // 0xD0(0x1)
	float MinEnemyInSightTime; // 0xD4(0x4)
};

// Object: Class AI.BTTask_VH_Locate
// Size: 0x118 (Inherited: 0x70)
struct UBTTask_VH_Locate : UBTTaskNode
{
	uint8_t LocateType; // 0x69(0x1)
	struct FBlackboardKeySelector BBKey_OutPoint; // 0x70(0x28)
	int MaxTryTimes; // 0x98(0x4)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
	struct FBlackboardKeySelector BBKey_BasePoint; // 0xA0(0x28)
	struct FVector2D RandomRange; // 0xC8(0x8)
	float RandomAngle; // 0xD0(0x4)
	struct FVector2D AttackRange; // 0xD4(0x8)
	uint8_t Pad_0xDC[0x4]; // 0xDC(0x4)
	struct TArray<struct FLocationRetryRule> retryRules; // 0xE0(0x10)
	float HeightTestOffset; // 0xF0(0x4)
	uint8_t bFilterBuilding : 1; // 0xF4(0x1), Mask(0x1)
	uint8_t bFilterWater : 1; // 0xF4(0x1), Mask(0x2)
	uint8_t bFilterOutBehaviorRegion : 1; // 0xF4(0x1), Mask(0x4)
	uint8_t bReachableTest : 1; // 0xF4(0x1), Mask(0x8)
	uint8_t bUseNavmesh : 1; // 0xF4(0x1), Mask(0x10)
	uint8_t BitPad_0xF4_5 : 3; // 0xF4(0x1)
	uint8_t Pad_0xF5[0x3]; // 0xF5(0x3)
	struct FName SpecificNaVName; // 0xF8(0x8)
	enum class ECollisionChannel CollisionChannel; // 0x100(0x1)
	uint8_t Pad_0x101[0x3]; // 0x101(0x3)
	float MaxLocationTraceHeightZ; // 0x104(0x4)
	uint8_t bDebug : 1; // 0x108(0x1), Mask(0x1)
	uint8_t BitPad_0x108_1 : 7; // 0x108(0x1)
	uint8_t Pad_0x109[0x7]; // 0x109(0x7)
	struct UAIBehaviorAdapter_Tank* OwnerAdapter; // 0x110(0x8)
};

// Object: Class AI.BTTask_VH_NavigateTo
// Size: 0xF8 (Inherited: 0xB0)
struct UBTTask_VH_NavigateTo : UBTTask_MoveTo
{
	uint8_t AIVHMoveType; // 0xAE(0x1)
	uint8_t bLimitTime : 1; // 0xAF(0x1), Mask(0x1)
	struct FVector2D ExecutionDuration; // 0xB0(0x8)
	uint8_t bModifyUsePathFinding : 1; // 0xB8(0x1), Mask(0x1)
	uint8_t bStopEngineWhenTaskFinished : 1; // 0xB8(0x1), Mask(0x2)
	uint8_t BitPad_0xB9_3 : 5; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x2]; // 0xBA(0x2)
	float AcceptableAngle; // 0xBC(0x4)
	struct FVector2D DirectionAngleRange; // 0xC0(0x8)
	struct FVector2D MoveTargetDistRange; // 0xC8(0x8)
	float ThrottleInputScale; // 0xD0(0x4)
	uint8_t bNoSteering : 1; // 0xD4(0x1), Mask(0x1)
	uint8_t BitPad_0xD4_1 : 7; // 0xD4(0x1)
	uint8_t Pad_0xD5[0x3]; // 0xD5(0x3)
	struct FVector2D Deviation; // 0xD8(0x8)
	float DistanceExtendRate; // 0xE0(0x4)
	float Throttle; // 0xE4(0x4)
	float TowardAngle; // 0xE8(0x4)
	uint8_t bTrackingTargetWhenRotateToward : 1; // 0xEC(0x1), Mask(0x1)
	uint8_t BitPad_0xEC_1 : 7; // 0xEC(0x1)
	uint8_t Pad_0xED[0x3]; // 0xED(0x3)
	struct UAIBehaviorAdapter_Tank* OwnerAdapter; // 0xF0(0x8)
};

// Object: Class AI.BTTask_WayPointDirectMove
// Size: 0xA8 (Inherited: 0x98)
struct UBTTask_WayPointDirectMove : UBTTask_BlackboardBase
{
	bool bAllowPartialPath; // 0x98(0x1)
	uint8_t Pad_0x99[0x3]; // 0x99(0x3)
	float AcceptableRadius; // 0x9C(0x4)
	bool bAllowStrafe; // 0xA0(0x1)
	bool bReachTestIncludesAgentRadius; // 0xA1(0x1)
	bool bReachTestIncludesGoalRadius; // 0xA2(0x1)
	bool bProjectGoalLocation; // 0xA3(0x1)
	bool bUsePathfinding; // 0xA4(0x1)
	bool bMoveToActor; // 0xA5(0x1)
	uint8_t Pad_0xA6[0x2]; // 0xA6(0x2)
};

// Object: Class AI.BTTask_WayPointListMove
// Size: 0xB8 (Inherited: 0x98)
struct UBTTask_WayPointListMove : UBTTask_BlackboardBase
{
	bool bAllowPartialPath; // 0x98(0x1)
	uint8_t Pad_0x99[0x3]; // 0x99(0x3)
	float AcceptableRadius; // 0x9C(0x4)
	bool bAllowStrafe; // 0xA0(0x1)
	bool bReachTestIncludesAgentRadius; // 0xA1(0x1)
	bool bReachTestIncludesGoalRadius; // 0xA2(0x1)
	bool bProjectGoalLocation; // 0xA3(0x1)
	bool bUsePathfinding; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	struct TArray<struct FVector> OverrideWayPointList; // 0xA8(0x10)
};

// Object: Class AI.BTTaskNode_CastSkill
// Size: 0x78 (Inherited: 0x70)
struct UBTTaskNode_CastSkill : UBTTaskNode
{
	int skillindex; // 0x6C(0x4)
	int SkillID; // 0x70(0x4)
};

// Object: Class AI.BTTaskNode_CharacterCastNoneTargetSkill
// Size: 0xD8 (Inherited: 0x98)
struct UBTTaskNode_CharacterCastNoneTargetSkill : UBTTask_BlackboardBase
{
	int SkillID; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct FBlackboardKeySelector SkillIDBlackBoardKey; // 0xA0(0x28)
	int RescueRange; // 0xC8(0x4)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct ASTExtraBaseCharacter* RescueCharacter; // 0xD0(0x8)
};

// Object: Class AI.BTTaskNode_CharacterCastOnTargetSkill
// Size: 0xC8 (Inherited: 0x98)
struct UBTTaskNode_CharacterCastOnTargetSkill : UBTTask_BlackboardBase
{
	int SkillID; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct FBlackboardKeySelector SkillIDBlackBoardKey; // 0xA0(0x28)
};

// Object: Class AI.BTTaskNode_CharacterCastSkill
// Size: 0x198 (Inherited: 0x98)
struct UBTTaskNode_CharacterCastSkill : UBTTask_BlackboardBase
{
	uint8_t throwMethod; // 0x98(0x1)
	bool bUseHighThrowFirst; // 0x99(0x1)
	uint8_t Pad_0x9A[0x2]; // 0x9A(0x2)
	struct FVector2D AcceptableHighThrowPitchRangle; // 0x9C(0x8)
	struct FVector2D AcceptableLowThrowPitchRangle; // 0xA4(0x8)
	struct FVector HighThrowStartOffset_Stand; // 0xAC(0xC)
	struct FVector HighThrowStartOffset_Crouch; // 0xB8(0xC)
	struct FVector HighThrowStartOffset_Prone; // 0xC4(0xC)
	struct FVector LowThrowStartOffset_Stand; // 0xD0(0xC)
	struct FVector LowThrowStartOffset_Crouch; // 0xDC(0xC)
	struct FVector LowThrowStartOffset_Prone; // 0xE8(0xC)
	float HighThrowSpeed; // 0xF4(0x4)
	float LowThrowSpeed; // 0xF8(0x4)
	struct FRotator HighThrowViewOffsetRotation; // 0xFC(0xC)
	struct FRotator LowThrowViewOffsetRotation; // 0x108(0xC)
	float ProjectileCollisionRadius; // 0x114(0x4)
	enum class ESuggestProjVelocityTraceOption ProjVelocityTraceType; // 0x118(0x1)
	uint8_t Pad_0x119[0x3]; // 0x119(0x3)
	float fReplanThrowAngleDistance; // 0x11C(0x4)
	struct TArray<struct FAITaskNodeThrowGrenadeTargetLocRandomableConfig> TargetLocRandomableConfig; // 0x120(0x10)
	bool bDebug; // 0x130(0x1)
	uint8_t Pad_0x131[0x3]; // 0x131(0x3)
	int SkillID; // 0x134(0x4)
	struct FBlackboardKeySelector SkillIDBlackBoardKey; // 0x138(0x28)
	bool bNeedCheckItem; // 0x160(0x1)
	uint8_t Pad_0x161[0x3]; // 0x161(0x3)
	int CheckExitItemID; // 0x164(0x4)
	int CheckExitItemType; // 0x168(0x4)
	float SkillMinReleaseInterval; // 0x16C(0x4)
	float SkillMaxReleaseInterval; // 0x170(0x4)
	float FaceToTargetSpeed; // 0x174(0x4)
	float HighThrowDistance; // 0x178(0x4)
	uint8_t Pad_0x17C[0x4]; // 0x17C(0x4)
	struct UCurveFloat* HighThrowDistanceToPitchCurve; // 0x180(0x8)
	struct UCurveFloat* LowThrowDistanceToPitchCurve; // 0x188(0x8)
	bool UseNewTargetLocWhenNormalModeAiming; // 0x190(0x1)
	uint8_t Pad_0x191[0x7]; // 0x191(0x7)
};

// Object: Class AI.BTTaskNode_CheckOcclusionSafe
// Size: 0xA0 (Inherited: 0x98)
struct UBTTaskNode_CheckOcclusionSafe : UBTTask_BlackboardBase
{
	float CheckRadius; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
};

// Object: Class AI.BTTaskNode_ClearCurrentEnemy
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_ClearCurrentEnemy : UBTTaskNode
{
};

// Object: Class AI.BTTaskNode_ClearFocus
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_ClearFocus : UBTTaskNode
{
	uint8_t ClearedFocus; // 0x69(0x1)
};

// Object: Class AI.BTTaskNode_EmptyShot
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_EmptyShot : UBTTaskNode
{
	float FireTime; // 0x6C(0x4)
};

// Object: Class AI.BTTaskNode_EquipItemDirectly
// Size: 0x80 (Inherited: 0x70)
struct UBTTaskNode_EquipItemDirectly : UBTTaskNode
{
	float CheckNoPlayerRadiusSquare; // 0x6C(0x4)
	struct TArray<struct FAIEquipSpawnGroup> RandomSpawnEquipGroupSet; // 0x70(0x10)
};

// Object: Class AI.BTTaskNode_EquipOrUnWeapon
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_EquipOrUnWeapon : UBTTaskNode
{
	bool Equip; // 0x69(0x1)
	bool FailedWhenEquipSuccess; // 0x6A(0x1)
	bool bEquipGrenade; // 0x6B(0x1)
	int GrenadeID; // 0x6C(0x4)
};

// Object: Class AI.BTTaskNode_FindBuilding
// Size: 0xC0 (Inherited: 0x98)
struct UBTTaskNode_FindBuilding : UBTTask_BlackboardBase
{
	struct TArray<struct FFindBuildingRatingConfig> RatingConfig; // 0x98(0x10)
	bool OnlySafeBuildings; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x3]; // 0xA9(0x3)
	float MaxMoveSpeed; // 0xAC(0x4)
	float findSpotXYOffset; // 0xB0(0x4)
	float findSpotZOffset; // 0xB4(0x4)
	float GoBackThreshold; // 0xB8(0x4)
	uint8_t Pad_0xBC[0x4]; // 0xBC(0x4)
};

// Object: Class AI.BTTaskNode_FindItemSpot
// Size: 0x98 (Inherited: 0x98)
struct UBTTaskNode_FindItemSpot : UBTTask_BlackboardBase
{
};

// Object: Class AI.BTTaskNode_FindPosByTarget
// Size: 0xA0 (Inherited: 0x98)
struct UBTTaskNode_FindPosByTarget : UBTTask_BlackboardBase
{
	float SearchRadius; // 0x98(0x4)
	bool bUseNav; // 0x9C(0x1)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
};

// Object: Class AI.BTTaskNode_ForceSuccess
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_ForceSuccess : UBTTaskNode
{
	bool IsForceSuccess; // 0x69(0x1)
};

// Object: Class AI.BTTaskNode_HumanAction
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_HumanAction : UBTTaskNode
{
	uint8_t SetAction; // 0x69(0x1)
};

// Object: Class AI.BTTaskNode_MeleeAttack
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_MeleeAttack : UBTTaskNode
{
};

// Object: Class AI.BTTaskNode_MonsterCastSkill
// Size: 0xA8 (Inherited: 0x98)
struct UBTTaskNode_MonsterCastSkill : UBTTask_BlackboardBase
{
	int skillindex; // 0x98(0x4)
	int SkillID; // 0x9C(0x4)
	enum class EUTSkillEventType SkillType; // 0xA0(0x1)
	bool bCanCastWithoutTarget; // 0xA1(0x1)
	bool bIgnoreSkillCastDistanceCheck; // 0xA2(0x1)
	uint8_t Pad_0xA3[0x5]; // 0xA3(0x5)
};

// Object: Class AI.BTTaskNode_MonsterJumpToPos
// Size: 0x98 (Inherited: 0x98)
struct UBTTaskNode_MonsterJumpToPos : UBTTask_BlackboardBase
{
};

// Object: Class AI.BTTaskNode_NewParachuteJumpBase
// Size: 0xB8 (Inherited: 0x70)
struct UBTTaskNode_NewParachuteJumpBase : UBTTaskNode
{
	float RandomStartJumpTime; // 0x6C(0x4)
	float RandomEndJumpTime; // 0x70(0x4)
	float JumpRadius; // 0x74(0x4)
	float JumpHeight; // 0x78(0x4)
	float MoveForwardRate; // 0x7C(0x4)
	float OpenParachuteHeight; // 0x80(0x4)
	float CheckOpenParachuteFreq; // 0x84(0x4)
	float ForceForwardHeight; // 0x88(0x4)
	float CloseParachuteHeight; // 0x8C(0x4)
	float CheckCloseParachuteFreq; // 0x90(0x4)
	float LockFocusTime; // 0x94(0x4)
	float DelayClearParachuteTime; // 0x98(0x4)
	float MaxFallingTime; // 0x9C(0x4)
	bool bNotiyParachuteComp; // 0xA0(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	struct FName IgnoreOpen; // 0xA8(0x8)
	bool UseFakePlayerAIControllerDoLandingSuccess; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)


	// Object: Function AI.BTTaskNode_NewParachuteJumpBase.DelayClearParachute
	// Flags: [Final|Native|Protected]
	// Offset: 0x1047b50dc
	// Params: [ Num(1) Size(0x8) ]
	void DelayClearParachute(struct ASTExtraPlayerCharacter* ControlledPawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104773084
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class AI.BTTaskNode_NewParachuteJump
// Size: 0xB8 (Inherited: 0xB8)
struct UBTTaskNode_NewParachuteJump : UBTTaskNode_NewParachuteJumpBase
{
};

// Object: Class AI.BTTaskNode_NewParachuteJumpBigEvent
// Size: 0xC0 (Inherited: 0xB8)
struct UBTTaskNode_NewParachuteJumpBigEvent : UBTTaskNode_NewParachuteJump
{
	struct FVector JumpTargetPosition; // 0xB4(0xC)
};

// Object: Class AI.BTTaskNode_NewParachuteJumpDoubleCircle
// Size: 0xC8 (Inherited: 0xB8)
struct UBTTaskNode_NewParachuteJumpDoubleCircle : UBTTaskNode_NewParachuteJumpBase
{
	float OuterRadiusDeltaValue; // 0xB4(0x4)
	float InnerRadiusDeltaValue; // 0xB8(0x4)
	float JumpRangeDistance; // 0xBC(0x4)
	float MaxTargetPositonDistance; // 0xC0(0x4)
	int MaxAttempt; // 0xC4(0x4)
};

// Object: Class AI.BTTaskNode_ParachuteJump
// Size: 0x80 (Inherited: 0x70)
struct UBTTaskNode_ParachuteJump : UBTTaskNode
{
	float TimeLimit; // 0x6C(0x4)
	float RandomRadius; // 0x70(0x4)
	float JumpStartTime; // 0x74(0x4)
	float JumpEndTime; // 0x78(0x4)
};

// Object: Class AI.BTTaskNode_ParachuteJumpV3
// Size: 0x98 (Inherited: 0x70)
struct UBTTaskNode_ParachuteJumpV3 : UBTTaskNode
{
	float RandomStartJumpTime; // 0x6C(0x4)
	float RandomEndJumpTime; // 0x70(0x4)
	float JumpRadius; // 0x74(0x4)
	float JumpHeight; // 0x78(0x4)
	float RandomAccelerateStart; // 0x7C(0x4)
	float RandomAccelerateEnd; // 0x80(0x4)
	float OpenParachuteHeight; // 0x84(0x4)
	float CheckOpenParachuteFreq; // 0x88(0x4)
	float CloseParachuteHeight; // 0x8C(0x4)
	float CheckCloseParachuteFreq; // 0x90(0x4)
};

// Object: Class AI.BTTaskNode_PickItemsAtSpot
// Size: 0x78 (Inherited: 0x70)
struct UBTTaskNode_PickItemsAtSpot : UBTTaskNode
{
	float DeltaTime; // 0x6C(0x4)
	int MaxPickCount; // 0x70(0x4)
};

// Object: Class AI.BTTaskNode_PlayEmote
// Size: 0x110 (Inherited: 0x70)
struct UBTTaskNode_PlayEmote : UBTTaskNode
{
	struct TMap<int, float> RandomEmoteIDWithWeightMap; // 0x70(0x50)
	struct TMap<int, float> EmotePlayTimeMap; // 0xC0(0x50)
};

// Object: Class AI.BTTaskNode_PlaySound
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_PlaySound : UBTTaskNode
{
	int SoundID; // 0x6C(0x4)
};

// Object: Class AI.BTTaskNode_PostLuaEvent
// Size: 0xB0 (Inherited: 0x70)
struct UBTTaskNode_PostLuaEvent : UBTTaskNode
{
	struct FString EventType; // 0x70(0x10)
	struct FString EventID; // 0x80(0x10)
	struct FString CallLuaFuncName; // 0x90(0x10)
	struct FString Params; // 0xA0(0x10)
};

// Object: Class AI.BTTaskNode_RefreshWeaponBBD
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_RefreshWeaponBBD : UBTTaskNode
{
};

// Object: Class AI.BTTaskNode_Rescue
// Size: 0x98 (Inherited: 0x98)
struct UBTTaskNode_Rescue : UBTTask_BlackboardBase
{
};

// Object: Class AI.BTTaskNode_StopMeleeAttack
// Size: 0xA0 (Inherited: 0x98)
struct UBTTaskNode_StopMeleeAttack : UBTTask_BlackboardBase
{
	float StopTimeout; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
};

// Object: Class AI.BTTaskNode_StopShooting
// Size: 0x70 (Inherited: 0x70)
struct UBTTaskNode_StopShooting : UBTTaskNode
{
};

// Object: Class AI.BTTaskNode_TakeMedicine
// Size: 0x80 (Inherited: 0x70)
struct UBTTaskNode_TakeMedicine : UBTTaskNode
{
	int MedicineIndex; // 0x6C(0x4)
	uint8_t Pad_0x74[0xC]; // 0x74(0xC)
};

// Object: Class AI.CustomDamageEventComponent
// Size: 0x370 (Inherited: 0x238)
struct UCustomDamageEventComponent : ULuaActorComponent
{
	struct FScriptMulticastDelegate OnSpawnActor; // 0x238(0x10)
	struct UDataTable* EventDataTable; // 0x248(0x28)
	float ActorSpawnGlobalCooldown; // 0x270(0x4)
	uint8_t Pad_0x274[0x4]; // 0x274(0x4)
	struct FScriptMulticastDelegate OnThrowBox; // 0x278(0x10)
	uint8_t Pad_0x288[0x4]; // 0x288(0x4)
	float OwnerHealthPercentage; // 0x28C(0x4)
	uint8_t Pad_0x290[0x10]; // 0x290(0x10)
	struct TArray<struct FTriggeredCustomDamageEvent> ClientEvents; // 0x2A0(0x10)
	uint8_t Pad_0x2B0[0x70]; // 0x2B0(0x70)
	struct TMap<struct FName, struct UObject*> CacheUObjectMap; // 0x320(0x50)


	// Object: Function AI.CustomDamageEventComponent.OnRep_ClientEvents
	// Flags: [Final|Native|Protected]
	// Offset: 0x1047b6628
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ClientEvents();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10508F76C
	// [Call #3] RVA: 0x104783E8C
	// [Call #4] RVA: 0x105184F34
	// [Call #5] RVA: 0x105190648
	// [Call #6] RVA: 0x1036A6C08
	// [Call #7] RVA: 0x104783E8C
	// [Call #8] RVA: 0x105184F34
	// [Call #9] RVA: 0x105190648
};

// Object: Class AI.CharacterCustomDamageEventComponent
// Size: 0x378 (Inherited: 0x370)
struct UCharacterCustomDamageEventComponent : UCustomDamageEventComponent
{
	uint8_t Pad_0x370[0x8]; // 0x370(0x8)


	// Object: Function AI.CharacterCustomDamageEventComponent.OnTakeDamageEvent
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047b5f90
	// Params: [ Num(4) Size(0x28) ]
	void OnTakeDamageEvent(float Damage, struct FDamageEvent& DamageEvent, struct AActor* Victim, struct AActor* Causer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DEF20
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x105190870
};

// Object: Class AI.MercenaryAICharacterBase
// Size: 0x7450 (Inherited: 0x7430)
struct AMercenaryAICharacterBase : ASTExtraPlayerCharacter
{
	float AttachedActorFoldWeaponMinAngle; // 0x742C(0x4)
	bool bShouldUseGameModeNetCullingDist; // 0x7430(0x1)
	float AttachedActorFoldWeaponMaxAngle; // 0x7434(0x4)
	float AttachedPlayerHeightOffset; // 0x7438(0x4)
	struct FVector GrenadeThrowOffset; // 0x743C(0xC)
	uint8_t Pad_0x7449[0x7]; // 0x7449(0x7)
};

// Object: Class AI.MercenaryJumpObstacleInfoCollector
// Size: 0x250 (Inherited: 0x58)
struct UMercenaryJumpObstacleInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FMercenaryJumpObstacleAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffMercenaryJumpObstacleAllPlayerInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
};

// Object: Class AI.MercenaryPassengerCameraModifierBase
// Size: 0xB8 (Inherited: 0x48)
struct UMercenaryPassengerCameraModifierBase : UCameraModifier
{
	struct FVector2D LimitViewYawRange_Grenade; // 0x44(0x8)
	struct FPassengerCameraViewLimit TppViewLimit; // 0x4C(0x24)
	struct FPassengerCameraViewLimit FppViewLimit; // 0x70(0x24)
	struct FPassengerCameraViewLimit BowViewLimit; // 0x94(0x24)
};

// Object: Class AI.MLAIControllerComponent
// Size: 0x848 (Inherited: 0x238)
struct UMLAIControllerComponent : ULuaActorComponent
{
	struct UActorComponent* AISoundCollectCompClass; // 0x238(0x8)
	struct UActorComponent* MLAIParachuteJumpCompClass; // 0x240(0x8)
	struct UAIActionExecutionComponent* AIActionExecutionComp; // 0x248(0x8)
	struct UAIBasicStateInfoComponent* AIStateInfoComp; // 0x250(0x8)
	struct UAISoundCollectionComponent* AISoundCollectComp; // 0x258(0x8)
	struct UMLAIParachuteJumpComponent* MLAIParachuteJumpComp; // 0x260(0x8)
	struct UTeammateMLAIControllerComponent* TeammateMLAIControllerComp; // 0x268(0x8)
	float HearRadius; // 0x270(0x4)
	uint8_t Pad_0x274[0x4]; // 0x274(0x4)
	struct TMap<enum class ESTEPoseState, struct FCameraViewPitchLimitData> CameraViewPitchLimitDataMap; // 0x278(0x50)
	struct FCameraViewPitchLimitData FreeFallCameraViewPitchLimitData; // 0x2C8(0x8)
	struct FVector PrePos; // 0x2D0(0xC)
	float PreTickTime; // 0x2DC(0x4)
	uint8_t Pad_0x2E0[0x8]; // 0x2E0(0x8)
	struct AController* OwnerController; // 0x2E8(0x8)
	struct ANewFakePlayerAIController* MyAIController; // 0x2F0(0x8)
	struct ASTExtraPlayerController* MyPlayerController; // 0x2F8(0x8)
	uint8_t Pad_0x300[0x14]; // 0x300(0x14)
	float FindNavLocationRadius; // 0x314(0x4)
	int MaxNavLocationFindTimes; // 0x318(0x4)
	bool bUseLerpRotation; // 0x31C(0x1)
	uint8_t Pad_0x31D[0x3]; // 0x31D(0x3)
	float LerpRotationThreshold; // 0x320(0x4)
	bool IsForceTargetRotation; // 0x324(0x1)
	uint8_t Pad_0x325[0x3]; // 0x325(0x3)
	float FirstLerpRotationDeltaTime; // 0x328(0x4)
	float FreeCameraTurnVelocity; // 0x32C(0x4)
	float TurnVelocity; // 0x330(0x4)
	uint8_t Pad_0x334[0x4]; // 0x334(0x4)
	struct FAIShootingPoseOffsetInfo shootingPoseOffsetInfo; // 0x338(0x70)
	float AutoOpenDoorRange; // 0x3A8(0x4)
	uint8_t Pad_0x3AC[0x8]; // 0x3AC(0x8)
	bool IsModifyDamageLuaOverride; // 0x3B4(0x1)
	uint8_t Pad_0x3B5[0x3]; // 0x3B5(0x3)
	float RatingDamageScaleLuaOverride; // 0x3B8(0x4)
	bool bShouldSendVehicleInfo; // 0x3BC(0x1)
	uint8_t Pad_0x3BD[0x1B]; // 0x3BD(0x1B)
	bool IsChangeStatePC; // 0x3D8(0x1)
	uint8_t Pad_0x3D9[0x3]; // 0x3D9(0x3)
	uint32_t AllyMasterID; // 0x3DC(0x4)
	uint32_t AIProvider; // 0x3E0(0x4)
	uint8_t Pad_0x3E4[0x464]; // 0x3E4(0x464)


	// Object: Function AI.MLAIControllerComponent.UnBindDelegates
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cbc8c
	// Params: [ Num(1) Size(0x1) ]
	void UnBindDelegates(bool IsEndPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469E63C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.MLAIControllerComponent.SetShowDebugAILevelTime
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1047cbc18
	// Params: [ Num(1) Size(0x4) ]
	void SetShowDebugAILevelTime(float InSetShowDebugAILevelTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A2080
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10469E63C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.MLAIControllerComponent.SetMLAIStyle
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cbb9c
	// Params: [ Num(1) Size(0x4) ]
	void SetMLAIStyle(uint32_t NewAIStyle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A25A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A2080
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469E63C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.MLAIControllerComponent.SetLuaAIParamConfigString
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cba78
	// Params: [ Num(2) Size(0x14) ]
	void SetLuaAIParamConfigString(struct FString InAIParamConfigString, int InLuaAIParamType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1046A18EC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A25A8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A2080
	// [Call #20] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.SetIsMLAI
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb9f4
	// Params: [ Num(1) Size(0x1) ]
	void SetIsMLAI(bool InIsMLAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A208C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x1046A18EC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A25A8
	// [Call #20] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.SetCurShootingPose
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb978
	// Params: [ Num(1) Size(0x1) ]
	void SetCurShootingPose(uint8_t InCurAIShootingPose);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469CF50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A208C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1046A18EC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.SetAllyMasterID
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb8fc
	// Params: [ Num(1) Size(0x4) ]
	void SetAllyMasterID(uint32_t InAllyMasterID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A1808
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10469CF50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A208C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x1046A18EC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function AI.MLAIControllerComponent.SetAIProvider
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb880
	// Params: [ Num(1) Size(0x4) ]
	void SetAIProvider(uint32_t AIProvider);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A17F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A1808
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469CF50
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A208C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.MLAIControllerComponent.SetAIParams
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047cb7cc
	// Params: [ Num(1) Size(0x408) ]
	void SetAIParams(struct FGameModeAIPlayerParams& InAIParams);
	// [Call #1] RVA: 0x1032216FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046A265C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A17F8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A1808
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10469CF50

	// Object: Function AI.MLAIControllerComponent.SetAILevel
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb750
	// Params: [ Num(1) Size(0x4) ]
	void SetAILevel(uint32_t NewAILevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A2568
	// [Call #4] RVA: 0x1032216FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A265C
	// [Call #8] RVA: 0x1025A2064
	// [Call #9] RVA: 0x1025A2064
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A17F8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A1808

	// Object: Function AI.MLAIControllerComponent.IsValid
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb71c
	// Params: [ Num(1) Size(0x1) ]
	bool IsValid();
	// [Call #1] RVA: 0x10469CF74
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046A2568
	// [Call #5] RVA: 0x1032216FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A265C
	// [Call #9] RVA: 0x1025A2064
	// [Call #10] RVA: 0x1025A2064
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A17F8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A1808

	// Object: Function AI.MLAIControllerComponent.IsTeammateMLAI
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb6e8
	// Params: [ Num(1) Size(0x1) ]
	bool IsTeammateMLAI();
	// [Call #1] RVA: 0x1046A267C
	// [Call #2] RVA: 0x10469CF74
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A2568
	// [Call #6] RVA: 0x1032216FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A265C
	// [Call #10] RVA: 0x1025A2064
	// [Call #11] RVA: 0x1025A2064
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A17F8
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb6b4
	// Params: [ Num(1) Size(0x1) ]
	bool IsFreeCamera();
	// [Call #1] RVA: 0x10469C9F8
	// [Call #2] RVA: 0x1046A267C
	// [Call #3] RVA: 0x10469CF74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A2568
	// [Call #7] RVA: 0x1032216FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A265C
	// [Call #11] RVA: 0x1025A2064
	// [Call #12] RVA: 0x1025A2064
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A17F8

	// Object: Function AI.MLAIControllerComponent.InitAIStateInfoComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb638
	// Params: [ Num(1) Size(0x8) ]
	void InitAIStateInfoComponent(struct UAIBasicStateInfoComponent* AIStateInfoComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A204C
	// [Call #4] RVA: 0x10469C9F8
	// [Call #5] RVA: 0x1046A267C
	// [Call #6] RVA: 0x10469CF74
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A2568
	// [Call #10] RVA: 0x1032216FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A265C
	// [Call #14] RVA: 0x1025A2064
	// [Call #15] RVA: 0x1025A2064
	// [Call #16] RVA: 0x106C8459C

	// Object: Function AI.MLAIControllerComponent.InitAIActionExecutionComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb5bc
	// Params: [ Num(1) Size(0x8) ]
	void InitAIActionExecutionComponent(struct UAIActionExecutionComponent* InAIActionExecutionComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A2070
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A204C
	// [Call #7] RVA: 0x10469C9F8
	// [Call #8] RVA: 0x1046A267C
	// [Call #9] RVA: 0x10469CF74
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A2568
	// [Call #13] RVA: 0x1032216FC
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1047cb584
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetViewRotation();
	// [Call #1] RVA: 0x1046A1D98
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046A2070
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A204C
	// [Call #8] RVA: 0x10469C9F8
	// [Call #9] RVA: 0x1046A267C
	// [Call #10] RVA: 0x10469CF74
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A2568

	// Object: Function AI.MLAIControllerComponent.GetViewForwardVector
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1047cb54c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetViewForwardVector();
	// [Call #1] RVA: 0x1046A1EA4
	// [Call #2] RVA: 0x1046A1D98
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A2070
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A204C
	// [Call #9] RVA: 0x10469C9F8
	// [Call #10] RVA: 0x1046A267C
	// [Call #11] RVA: 0x10469CF74
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function AI.MLAIControllerComponent.GetOwnerBaseCharacter
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb518
	// Params: [ Num(1) Size(0x8) ]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter();
	// [Call #1] RVA: 0x10469CFF8
	// [Call #2] RVA: 0x1046A1EA4
	// [Call #3] RVA: 0x1046A1D98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A2070
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A204C
	// [Call #10] RVA: 0x10469C9F8
	// [Call #11] RVA: 0x1046A267C
	// [Call #12] RVA: 0x10469CF74

	// Object: Function AI.MLAIControllerComponent.GetMLAIStyle
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb4e4
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetMLAIStyle();
	// [Call #1] RVA: 0x1046A2588
	// [Call #2] RVA: 0x10469CFF8
	// [Call #3] RVA: 0x1046A1EA4
	// [Call #4] RVA: 0x1046A1D98
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A2070
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A204C
	// [Call #11] RVA: 0x10469C9F8
	// [Call #12] RVA: 0x1046A267C

	// Object: Function AI.MLAIControllerComponent.GetMLAIParachuteJumpComp
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb4c8
	// Params: [ Num(1) Size(0x8) ]
	struct UMLAIParachuteJumpComponent* GetMLAIParachuteJumpComp();
	// [Call #1] RVA: 0x1046A2588
	// [Call #2] RVA: 0x10469CFF8
	// [Call #3] RVA: 0x1046A1EA4
	// [Call #4] RVA: 0x1046A1D98
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A2070
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A204C
	// [Call #11] RVA: 0x10469C9F8
	// [Call #12] RVA: 0x1046A267C

	// Object: Function AI.MLAIControllerComponent.GetIsMLAI
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb494
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsMLAI();
	// [Call #1] RVA: 0x1046A2540
	// [Call #2] RVA: 0x1046A2588
	// [Call #3] RVA: 0x10469CFF8
	// [Call #4] RVA: 0x1046A1EA4
	// [Call #5] RVA: 0x1046A1D98
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A2070
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A204C
	// [Call #12] RVA: 0x10469C9F8

	// Object: Function AI.MLAIControllerComponent.GetBackpackComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb460
	// Params: [ Num(1) Size(0x8) ]
	struct UBackpackComponent* GetBackpackComponent();
	// [Call #1] RVA: 0x10469CCA4
	// [Call #2] RVA: 0x1046A2540
	// [Call #3] RVA: 0x1046A2588
	// [Call #4] RVA: 0x10469CFF8
	// [Call #5] RVA: 0x1046A1EA4
	// [Call #6] RVA: 0x1046A1D98
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A2070
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A204C

	// Object: Function AI.MLAIControllerComponent.GetAllyMasterID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb42c
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetAllyMasterID();
	// [Call #1] RVA: 0x1046A1800
	// [Call #2] RVA: 0x10469CCA4
	// [Call #3] RVA: 0x1046A2540
	// [Call #4] RVA: 0x1046A2588
	// [Call #5] RVA: 0x10469CFF8
	// [Call #6] RVA: 0x1046A1EA4
	// [Call #7] RVA: 0x1046A1D98
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A2070
	// [Call #11] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.GetAIStateInfoComp
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb410
	// Params: [ Num(1) Size(0x8) ]
	struct UAIBasicStateInfoComponent* GetAIStateInfoComp();
	// [Call #1] RVA: 0x1046A1800
	// [Call #2] RVA: 0x10469CCA4
	// [Call #3] RVA: 0x1046A2540
	// [Call #4] RVA: 0x1046A2588
	// [Call #5] RVA: 0x10469CFF8
	// [Call #6] RVA: 0x1046A1EA4
	// [Call #7] RVA: 0x1046A1D98
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A2070

	// Object: Function AI.MLAIControllerComponent.GetAIProvider
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb3dc
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetAIProvider();
	// [Call #1] RVA: 0x10469E298
	// [Call #2] RVA: 0x1046A1800
	// [Call #3] RVA: 0x10469CCA4
	// [Call #4] RVA: 0x1046A2540
	// [Call #5] RVA: 0x1046A2588
	// [Call #6] RVA: 0x10469CFF8
	// [Call #7] RVA: 0x1046A1EA4
	// [Call #8] RVA: 0x1046A1D98
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A2070

	// Object: Function AI.MLAIControllerComponent.GetAIParams
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb3a4
	// Params: [ Num(1) Size(0x408) ]
	struct FGameModeAIPlayerParams GetAIParams();
	// [Call #1] RVA: 0x1046A2634
	// [Call #2] RVA: 0x10469E298
	// [Call #3] RVA: 0x1046A1800
	// [Call #4] RVA: 0x10469CCA4
	// [Call #5] RVA: 0x1046A2540
	// [Call #6] RVA: 0x1046A2588
	// [Call #7] RVA: 0x10469CFF8
	// [Call #8] RVA: 0x1046A1EA4
	// [Call #9] RVA: 0x1046A1D98
	// [Call #10] RVA: 0x10516D168

	// Object: Function AI.MLAIControllerComponent.GetAILevel
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb370
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetAILevel();
	// [Call #1] RVA: 0x1046A2614
	// [Call #2] RVA: 0x1046A2634
	// [Call #3] RVA: 0x10469E298
	// [Call #4] RVA: 0x1046A1800
	// [Call #5] RVA: 0x10469CCA4
	// [Call #6] RVA: 0x1046A2540
	// [Call #7] RVA: 0x1046A2588
	// [Call #8] RVA: 0x10469CFF8
	// [Call #9] RVA: 0x1046A1EA4
	// [Call #10] RVA: 0x1046A1D98

	// Object: Function AI.MLAIControllerComponent.GetAIActionExecutionComp
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047cb354
	// Params: [ Num(1) Size(0x8) ]
	struct UAIActionExecutionComponent* GetAIActionExecutionComp();
	// [Call #1] RVA: 0x1046A2614
	// [Call #2] RVA: 0x1046A2634
	// [Call #3] RVA: 0x10469E298
	// [Call #4] RVA: 0x1046A1800
	// [Call #5] RVA: 0x10469CCA4
	// [Call #6] RVA: 0x1046A2540
	// [Call #7] RVA: 0x1046A2588
	// [Call #8] RVA: 0x10469CFF8
	// [Call #9] RVA: 0x1046A1EA4
	// [Call #10] RVA: 0x1046A1D98

	// Object: Function AI.MLAIControllerComponent.FreshShootingPose
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb340
	// Params: [ Num(0) Size(0x0) ]
	void FreshShootingPose();
	// [Call #1] RVA: 0x1046A2614
	// [Call #2] RVA: 0x1046A2634
	// [Call #3] RVA: 0x10469E298
	// [Call #4] RVA: 0x1046A1800
	// [Call #5] RVA: 0x10469CCA4
	// [Call #6] RVA: 0x1046A2540
	// [Call #7] RVA: 0x1046A2588
	// [Call #8] RVA: 0x10469CFF8
	// [Call #9] RVA: 0x1046A1EA4

	// Object: Function AI.MLAIControllerComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb204
	// Params: [ Num(4) Size(0x10) ]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10469C1EC
	// [Call #10] RVA: 0x1046A2614
	// [Call #11] RVA: 0x1046A2634
	// [Call #12] RVA: 0x10469E298
	// [Call #13] RVA: 0x1046A1800

	// Object: Function AI.MLAIControllerComponent.CheckCameraViewPitchLimit
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1047cb16c
	// Params: [ Num(2) Size(0xD) ]
	bool CheckCameraViewPitchLimit(struct FRotator& InOutTargetRot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469BF70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10469C1EC
	// [Call #13] RVA: 0x1046A2614

	// Object: Function AI.MLAIControllerComponent.BindDelegates
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cb158
	// Params: [ Num(0) Size(0x0) ]
	void BindDelegates();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10469BF70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10469C1EC
	// [Call #13] RVA: 0x1046A2614
};

// Object: Class AI.MLAIDestructibleInfoCollector
// Size: 0x388 (Inherited: 0x58)
struct UMLAIDestructibleInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FDestructibleItemAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffDestructibleItemAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FDestructibleItemGlobalGameState CacheGlobalGameState; // 0x250(0x40)
	struct FDestructibleItemGlobalGameState LastGlobalGameState; // 0x290(0x40)
	struct FDiffDestructibleItemGlobalGameState DiffGlobalGameStateGeneral; // 0x2D0(0x68)
	struct TMap<uint64_t, struct FDestructibleItem> CacheDestructibleItems; // 0x338(0x50)
};

// Object: Class AI.MLAIDynamicItemInfoCollector
// Size: 0x388 (Inherited: 0x58)
struct UMLAIDynamicItemInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FDynamicItemAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffDynamicItemAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FDynamicItemGlobalGameState CacheGlobalGameState; // 0x250(0x40)
	struct FDynamicItemGlobalGameState LastGlobalGameState; // 0x290(0x40)
	struct FDiffDynamicItemGlobalGameState DiffGlobalGameStateGeneral; // 0x2D0(0x68)
	struct TMap<uint64_t, struct FDynamicItem> CacheDynamicItems; // 0x338(0x50)
};

// Object: Class AI.MLAILandScapeInfoCollector
// Size: 0x2F0 (Inherited: 0x58)
struct UMLAILandScapeInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FLandScapeAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FLandScapeAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FLandScapeAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffLandScapeAllPlayerInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FLandScapeGlobalGameInfo CacheGlobalGameState; // 0x250(0x28)
	struct FLandScapeGlobalGameInfo LastGlobalGameState; // 0x278(0x28)
	struct FDiffLandScapeGlobalGameInfo DiffGlobalGameStateGeneral; // 0x2A0(0x50)
};

// Object: Class AI.MLAINearbyDoorInfoCollector
// Size: 0x388 (Inherited: 0x58)
struct UMLAINearbyDoorInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FNearbyDoorAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffNearbyDoorAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FNearbyDoorGlobalGameState CacheGlobalGameState; // 0x250(0x40)
	struct FNearbyDoorGlobalGameState LastGlobalGameState; // 0x290(0x40)
	struct FDiffNearbyDoorGlobalGameState DiffGlobalGameStateGeneral; // 0x2D0(0x68)
	struct TMap<uint64_t, struct FDoorState> CacheDoorStates; // 0x338(0x50)
};

// Object: Class AI.MLAINearbyMonsterInfoCollector
// Size: 0x388 (Inherited: 0x58)
struct UMLAINearbyMonsterInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FNearbyMonsterAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffNearbyMonsterAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FNearbyMonsterGlobalGameState CacheGlobalGameState; // 0x250(0x40)
	struct FNearbyMonsterGlobalGameState LastGlobalGameState; // 0x290(0x40)
	struct TMap<uint64_t, struct FMonsterState> CacheMonsterStats; // 0x2D0(0x50)
	struct FDiffNearbyMonsterGlobalGameState DiffGlobalGameStateGeneral; // 0x320(0x68)
};

// Object: Class AI.MLAINearbyPlayerInfoCollector
// Size: 0x250 (Inherited: 0x58)
struct UMLAINearbyPlayerInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FNearbyPlayerAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FNearbyPlayerAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FNearbyPlayerAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffNearbyPlayerAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
};

// Object: Class AI.MLAINearbyStateInfoCollector
// Size: 0x430 (Inherited: 0x58)
struct UMLAINearbyStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FBaseNearbyAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffBaseNearbyAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FNearbyBaseGlobalGameState CacheGlobalGameState; // 0x250(0x50)
	struct FNearbyBaseGlobalGameState LastGlobalGameState; // 0x2A0(0x50)
	struct FDiffBaseNearbyGlobalGameState DiffGlobalGameStateGeneral; // 0x2F0(0xA0)
	struct TMap<uint64_t, struct FItemStateData> CacheItemData; // 0x390(0x50)
	struct TMap<uint64_t, struct FAINearbyThrown> CacheAINearbyThrown; // 0x3E0(0x50)
};

// Object: Class AI.MLAIParachuteJumpComponent
// Size: 0x290 (Inherited: 0x238)
struct UMLAIParachuteJumpComponent : ULuaActorComponent
{
	float JumpRadius; // 0x234(0x4)
	float JumpHeight; // 0x238(0x4)
	float OpenParachuteHeight; // 0x23C(0x4)
	float CheckOpenParachuteFreq; // 0x240(0x4)
	float CloseParachuteHeight; // 0x244(0x4)
	float CheckCloseParachuteFreq; // 0x248(0x4)
	float DelayClearParachuteTime; // 0x24C(0x4)
	float MaxFallingTime; // 0x250(0x4)
	uint8_t JumpingPhase; // 0x254(0x1)
	struct ANewFakePlayerAIController* OwnerController; // 0x258(0x8)
	struct ASTExtraPlayerController* OwnerPlayerController; // 0x260(0x8)
	float FallingTime; // 0x268(0x4)
	float CheckCountTime; // 0x26C(0x4)
	bool bLandingInLowHeight; // 0x270(0x1)
	uint8_t Pad_0x272[0x2]; // 0x272(0x2)
	struct FVector LastLocation; // 0x274(0xC)
	bool bDellJumpToLandExcute; // 0x280(0x1)
	bool bNotiyParachuteComp; // 0x281(0x1)
	uint8_t Pad_0x282[0x6]; // 0x282(0x6)
	struct FName IgnoreOpen; // 0x288(0x8)


	// Object: Function AI.MLAIParachuteJumpComponent.ParachuteMove
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd614
	// Params: [ Num(2) Size(0x8) ]
	void ParachuteMove(float ForwardRate, float RightRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A4584
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.OpenParachute
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd600
	// Params: [ Num(0) Size(0x0) ]
	void OpenParachute();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A4584
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.OnAIEnterFighting
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd5ec
	// Params: [ Num(0) Size(0x0) ]
	void OnAIEnterFighting();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A4584
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.JumpFromPoint
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd5d8
	// Params: [ Num(0) Size(0x0) ]
	void JumpFromPoint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A4584
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.JumpFromPlane
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd5c4
	// Params: [ Num(0) Size(0x0) ]
	void JumpFromPlane();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A4584
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.EnterParachuteJumpPhase
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x1047cd4e4
	// Params: [ Num(2) Size(0x18) ]
	void EnterParachuteJumpPhase(struct FVector& StartLoc, struct FRotator& StartRot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A4584
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIParachuteJumpComponent.EndJump
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd460
	// Params: [ Num(1) Size(0x1) ]
	void EndJump(bool bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A3388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A4584

	// Object: Function AI.MLAIParachuteJumpComponent.CloseParachute
	// Flags: [Final|Native|Public]
	// Offset: 0x1047cd44c
	// Params: [ Num(0) Size(0x0) ]
	void CloseParachute();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A3388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class AI.MLAIStateInfoManager
// Size: 0x550 (Inherited: 0x28)
struct UMLAIStateInfoManager : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString LuaFilePath; // 0x80(0x10)
	bool bDiffSwitch; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct UAIStateInfoDataAsset* AIStateInfoDataAsset; // 0x98(0x8)
	struct TArray<struct UStateInfoCollectorBase*> StateInfoCollectorList; // 0xA0(0x10)
	struct TMap<uint8_t, struct FCollectorArray> PlayerTypeStateInfoCollectorMap; // 0xB0(0x50)
	struct UMLAISubSystem* MLAISubSystem; // 0x100(0x8)
	struct TMap<struct FString, struct UObject*> CollectorNameToClassMap; // 0x108(0x50)
	struct TMap<struct ASTExtraPlayerCharacter*, bool> CacheMLAIs; // 0x158(0x50)
	struct TMap<struct ASTExtraPlayerCharacter*, bool> CachePlayerAndBTAIs; // 0x1A8(0x50)
	struct TMap<uint32_t, bool> CacheCandidateAIs; // 0x1F8(0x50)
	struct TMap<uint32_t, bool> AlreadySendDeadStateMap; // 0x248(0x50)
	struct TMap<uint8_t, struct FDiffListIDMap> DiffPlayerIDToListIDMap; // 0x298(0x50)
	struct TMap<uint64_t, struct FPropertyNameListIDMap> DiffAIPlayerInfoListIDMaps; // 0x2E8(0x50)
	uint8_t Pad_0x338[0x20]; // 0x338(0x20)
	struct ABattleRoyaleGameMode* GameMode; // 0x358(0x8)
	uint8_t Pad_0x360[0xA0]; // 0x360(0xA0)
	bool CheckGlobalGameStateShouldCollectInfo; // 0x400(0x1)
	uint8_t CheckGlobalCollectPlayerType; // 0x401(0x1)
	bool bUseCombineAIStateInfo; // 0x402(0x1)
	uint8_t Pad_0x403[0xAD]; // 0x403(0xAD)
	struct TMap<uint32_t, struct UAIStateInfoComponentBase*> AIStateInfoCompMap; // 0x4B0(0x50)
	struct TMap<uint32_t, struct UMLAIControllerComponent*> MLAIControllerCompMap; // 0x500(0x50)


	// Object: Function AI.MLAIStateInfoManager.StartRequestCache
	// Flags: [Native|Public]
	// Offset: 0x1047e3f44
	// Params: [ Num(0) Size(0x0) ]
	void StartRequestCache();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.MLAIStateInfoManager.SetUseNewDiffCmds
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3ec0
	// Params: [ Num(1) Size(0x1) ]
	void SetUseNewDiffCmds(bool InUseNewDiffCmds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D5B0C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.MLAIStateInfoManager.SetOpenHeadAndMuzzleInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3e3c
	// Params: [ Num(1) Size(0x1) ]
	void SetOpenHeadAndMuzzleInfo(bool InOpenHeadAndMuzzleInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D5B00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D5B0C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIStateInfoManager.ResetWhiteList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3e28
	// Params: [ Num(0) Size(0x0) ]
	void ResetWhiteList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D5B00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D5B0C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAIStateInfoManager.InitCollectorList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3d44
	// Params: [ Num(1) Size(0x10) ]
	void InitCollectorList(struct TArray<struct FCollectorInitInfo> CollectorInitInfoList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047EADBC
	// [Call #4] RVA: 0x1046D3E44
	// [Call #5] RVA: 0x1047EAF44
	// [Call #6] RVA: 0x1047EAF44
	// [Call #7] RVA: 0x1047EAF44
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x1047EAF44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046D5B00
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046D5B0C
	// [Call #18] RVA: 0x10519022C

	// Object: Function AI.MLAIStateInfoManager.InitCollector
	// Flags: [Native|Public]
	// Offset: 0x1047e3d28
	// Params: [ Num(0) Size(0x0) ]
	void InitCollector();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047EADBC
	// [Call #4] RVA: 0x1046D3E44
	// [Call #5] RVA: 0x1047EAF44
	// [Call #6] RVA: 0x1047EAF44
	// [Call #7] RVA: 0x1047EAF44
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x1047EAF44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046D5B00
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046D5B0C

	// Object: Function AI.MLAIStateInfoManager.Init
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3cac
	// Params: [ Num(1) Size(0x8) ]
	void Init(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D3748
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1047EADBC
	// [Call #7] RVA: 0x1046D3E44
	// [Call #8] RVA: 0x1047EAF44
	// [Call #9] RVA: 0x1047EAF44
	// [Call #10] RVA: 0x1047EAF44
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x1047EAF44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046D5B00
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAIStateInfoManager.GetSinglePlayerStateInfoToCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3bf8
	// Params: [ Num(2) Size(0x10) ]
	void GetSinglePlayerStateInfoToCache(struct UWorld* InWorld, struct ASTExtraPlayerCharacter* Player);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046D56A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046D3748
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047EADBC
	// [Call #12] RVA: 0x1046D3E44
	// [Call #13] RVA: 0x1047EAF44
	// [Call #14] RVA: 0x1047EAF44
	// [Call #15] RVA: 0x1047EAF44
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x1047EAF44
	// [Call #19] RVA: 0x106C8459C

	// Object: Function AI.MLAIStateInfoManager.GetGlobalGameStateToCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3b7c
	// Params: [ Num(1) Size(0x8) ]
	void GetGlobalGameStateToCache(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D48D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046D56A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046D3748
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1047EADBC
	// [Call #15] RVA: 0x1046D3E44
	// [Call #16] RVA: 0x1047EAF44

	// Object: Function AI.MLAIStateInfoManager.GetDiffGlobalGameStateToCacheGeneral
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3b00
	// Params: [ Num(1) Size(0x8) ]
	void GetDiffGlobalGameStateToCacheGeneral(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D496C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D48D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046D56A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046D3748

	// Object: Function AI.MLAIStateInfoManager.GetDiffAllPlayerAIStateInfoToCacheGeneral
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3a84
	// Params: [ Num(1) Size(0x8) ]
	void GetDiffAllPlayerAIStateInfoToCacheGeneral(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D49E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D496C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046D48D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046D56A4

	// Object: Function AI.MLAIStateInfoManager.GetAllPlayerStateInfoToCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e3a08
	// Params: [ Num(1) Size(0x8) ]
	void GetAllPlayerStateInfoToCache(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D4230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D49E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046D496C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046D48D8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.MLAIStateInfoManager.EndRequestCache
	// Flags: [Native|Public]
	// Offset: 0x1047e39ec
	// Params: [ Num(0) Size(0x0) ]
	void EndRequestCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D4230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046D49E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046D496C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046D48D8
	// [Call #13] RVA: 0x10516D168

	// Object: Function AI.MLAIStateInfoManager.CollectCandidateAIStateInfoToCache
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e38c8
	// Params: [ Num(3) Size(0x48) ]
	void CollectCandidateAIStateInfoToCache(struct UWorld* InWorld, uint8_t CollectPlayerType, struct FAIActingCandidateData& CandidateData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x103597A48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046D502C
	// [Call #9] RVA: 0x103597344
	// [Call #10] RVA: 0x103597344
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046D4230
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046D49E0

	// Object: Function AI.MLAIStateInfoManager.CollectAIStateInfoToCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e37d4
	// Params: [ Num(3) Size(0x18) ]
	void CollectAIStateInfoToCache(struct UWorld* InWorld, uint8_t CollectPlayerType, struct ASTExtraBaseCharacter* PlayerPawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046D4F40
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x103597A48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046D502C
	// [Call #16] RVA: 0x103597344
	// [Call #17] RVA: 0x103597344
	// [Call #18] RVA: 0x106C8459C
};

// Object: Class AI.MLAISubSystem
// Size: 0xA58 (Inherited: 0x30)
struct UMLAISubSystem : UWorldSubsystem
{
	struct FScriptMulticastDelegate OnAIStateRequestEnd; // 0x30(0x10)
	struct TMap<uint32_t, struct FAIPlayerInteractInfo> CachePlayerDamageInfo; // 0x40(0x50)
	struct TMap<uint32_t, struct FVehicleDamageInfoContainer> CacheVehicleDamageInfo; // 0x90(0x50)
	int MaxCacheDamageInfoNum; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
	struct TArray<struct UAIBasicStateInfoComponent*> AIStateInfoComps; // 0xE8(0x10)
	struct TArray<struct FBulletHoleRecordInfo> CacheBulletHoles; // 0xF8(0x10)
	struct TArray<int> PlayerAvailableBackpackItemTypes; // 0x108(0x10)
	struct TArray<struct FString> TeammateStateWhiteList; // 0x118(0x10)
	struct TArray<struct TWeakObjectPtr<struct AAirDropBoxActor>> AirDropBoxActors; // 0x128(0x10)
	uint8_t Pad_0x138[0x3C0]; // 0x138(0x3C0)
	struct TMap<uint32_t, bool> AlreadySendDeadStateMap; // 0x4F8(0x50)
	uint8_t Pad_0x548[0x8]; // 0x548(0x8)
	struct FRedZoneState CacheRedZoneInfo; // 0x550(0x30)
	float AirAttackTotalTime; // 0x580(0x4)
	uint8_t Pad_0x584[0x4]; // 0x584(0x4)
	struct UAirAttackComponent* AirAttackComp; // 0x588(0x8)
	struct FBRBaseGlobalGameState GlobalGameState; // 0x590(0xF0)
	struct TArray<struct FSpecialZoneState> SpecialZones; // 0x680(0x10)
	uint8_t Pad_0x690[0x70]; // 0x690(0x70)
	struct TMap<uint32_t, int> CachePlayerRevivalTypes; // 0x700(0x50)
	struct UMLAIStateInfoManager* MLAIStateInfoManager; // 0x750(0x8)
	struct TMap<uint32_t, struct FString> VoiceRoomInfoMap; // 0x758(0x50)
	struct TMap<uint32_t, struct FString> VoiceServerURLMap; // 0x7A8(0x50)
	struct TMap<int, int> ItemDurabilityMap; // 0x7F8(0x50)
	int AirDropTag; // 0x848(0x4)
	uint8_t Pad_0x84C[0x4]; // 0x84C(0x4)
	float ProduceSoundInterval; // 0x850(0x4)
	int nCanJumpToSky; // 0x854(0x4)
	int nNewbieRealHiddenScore; // 0x858(0x4)
	int nNewbieMatchCount; // 0x85C(0x4)
	int nModGameType; // 0x860(0x4)
	int OverrideMapID; // 0x864(0x4)
	struct TSet<uint32_t> TeammateMLAITeamIDSet; // 0x868(0x50)
	struct TArray<uint32_t> SilentMLAIList; // 0x8B8(0x10)
	bool WhitelistPlayerStatesSwitch; // 0x8C8(0x1)
	uint8_t Pad_0x8C9[0x7]; // 0x8C9(0x7)
	struct TArray<uint32_t> PlayerWhitelist; // 0x8D0(0x10)
	struct TMap<struct APawn*, struct APawn*> PlayerWhiteMercenary2MasterMap; // 0x8E0(0x50)
	bool IncludesMasterTeammatesSwitch; // 0x930(0x1)
	uint8_t Pad_0x931[0x3]; // 0x931(0x3)
	float MercenaryPerceptionDist; // 0x934(0x4)
	float MasterPerceptionDist; // 0x938(0x4)
	float UpdateMercenaryPlayerWhiteInterval; // 0x93C(0x4)
	struct TSet<uint32_t> AICheckVisibilityFilteredActors; // 0x940(0x50)
	struct TArray<struct TWeakObjectPtr<struct UAIPerceptionDynamicItemComponent>> CachedDynamicItemComponents; // 0x990(0x10)
	struct TArray<struct TWeakObjectPtr<struct UAIPerceptionDynamicItemComponent>> CachedDestructibleItemComponents; // 0x9A0(0x10)
	uint8_t Pad_0x9B0[0x58]; // 0x9B0(0x58)
	struct TArray<struct ASpecialZoneActor*> CacheDynamicSpecialZone; // 0xA08(0x10)
	struct TArray<struct ASpecialZoneActor*> PendingUpdateSpecialZones; // 0xA18(0x10)
	uint8_t Pad_0xA28[0x18]; // 0xA28(0x18)
	struct ABattleRoyaleGameMode* CurGameMode; // 0xA40(0x8)
	uint8_t Pad_0xA48[0x8]; // 0xA48(0x8)
	struct UDataTableProxy* ItemTable; // 0xA50(0x8)


	// Object: Function AI.MLAISubSystem.UpdateSpecialZoneStateChanged
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e77a8
	// Params: [ Num(1) Size(0x8) ]
	void UpdateSpecialZoneStateChanged(struct ASpecialZoneActor* InSpecialZone);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A5E88
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.MLAISubSystem.UpdateSpecialZoneInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e76d4
	// Params: [ Num(1) Size(0x88) ]
	void UpdateSpecialZoneInfo(struct FSpecialZoneState& NewZoneInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A6E08
	// [Call #4] RVA: 0x1046AFC88
	// [Call #5] RVA: 0x1046AFC88
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A5E88
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function AI.MLAISubSystem.UpdateRedZoneState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e7658
	// Params: [ Num(1) Size(0x8) ]
	void UpdateRedZoneState(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A6E08
	// [Call #7] RVA: 0x1046AFC88
	// [Call #8] RVA: 0x1046AFC88
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A5E88
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function AI.MLAISubSystem.UpdateMercenaryPlayerWhite
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e7644
	// Params: [ Num(0) Size(0x0) ]
	void UpdateMercenaryPlayerWhite();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A6E08
	// [Call #7] RVA: 0x1046AFC88
	// [Call #8] RVA: 0x1046AFC88
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A5E88
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function AI.MLAISubSystem.UpdateAirDropBoxStates
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e7630
	// Params: [ Num(0) Size(0x0) ]
	void UpdateAirDropBoxStates();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7230
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A6E08
	// [Call #7] RVA: 0x1046AFC88
	// [Call #8] RVA: 0x1046AFC88
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A5E88
	// [Call #13] RVA: 0x10519022C

	// Object: Function AI.MLAISubSystem.UnregisterSpecialMapping
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e7598
	// Params: [ Num(1) Size(0x10) ]
	void UnregisterSpecialMapping(struct FString Key);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8F48
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A7230
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A6E08
	// [Call #13] RVA: 0x1046AFC88
	// [Call #14] RVA: 0x1046AFC88
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.UnregisterDynamicItemComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e751c
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterDynamicItemComponent(struct UAIPerceptionDynamicItemComponent* InDynamicItemComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8E00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8F48
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A7230
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.UnregisterDestructibleItemComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e74a0
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterDestructibleItemComponent(struct UAIPerceptionDynamicItemComponent* InComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8ED8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8E00
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A8F48
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A7230

	// Object: Function AI.MLAISubSystem.StartRequestCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e748c
	// Params: [ Num(0) Size(0x0) ]
	void StartRequestCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8ED8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8E00
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A8F48
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A7230

	// Object: Function AI.MLAISubSystem.SetWhitelistPlayerStatesSwitch
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e7378
	// Params: [ Num(3) Size(0x3) ]
	void SetWhitelistPlayerStatesSwitch(bool InSwitch, bool InReset, bool InCheckGlobalState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A86A8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A8ED8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A8E00
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.SetVehicleWeekPointConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e72b8
	// Params: [ Num(1) Size(0x50) ]
	void SetVehicleWeekPointConfig(struct TMap<uint32_t, struct FString> InVehicleWeekPointConfig);
	// [Call #1] RVA: 0x101FA6568
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046BADD8
	// [Call #5] RVA: 0x1046A6D18
	// [Call #6] RVA: 0x101FA6894
	// [Call #7] RVA: 0x101FA6894
	// [Call #8] RVA: 0x101FA6894
	// [Call #9] RVA: 0x101FA6894
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A86A8
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A8ED8

	// Object: Function AI.MLAISubSystem.SetUseTablePool
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e723c
	// Params: [ Num(1) Size(0x4) ]
	void SetUseTablePool(int InUseTablePool);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7864
	// [Call #4] RVA: 0x101FA6568
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046BADD8
	// [Call #8] RVA: 0x1046A6D18
	// [Call #9] RVA: 0x101FA6894
	// [Call #10] RVA: 0x101FA6894
	// [Call #11] RVA: 0x101FA6894
	// [Call #12] RVA: 0x101FA6894
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A86A8

	// Object: Function AI.MLAISubSystem.SetStrAIAttribute
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e712c
	// Params: [ Num(3) Size(0x18) ]
	void SetStrAIAttribute(uint32_t InPlayerKey, uint32_t InAttributeID, struct FString InAttributeValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A8430
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A7864
	// [Call #14] RVA: 0x101FA6568
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046BADD8
	// [Call #18] RVA: 0x1046A6D18
	// [Call #19] RVA: 0x101FA6894
	// [Call #20] RVA: 0x101FA6894
	// [Call #21] RVA: 0x101FA6894
	// [Call #22] RVA: 0x101FA6894
	// [Call #23] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.SetReportAllDynamicItems
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e70a8
	// Params: [ Num(1) Size(0x1) ]
	void SetReportAllDynamicItems(bool bInEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8E60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A8430
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A7864
	// [Call #17] RVA: 0x101FA6568
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.SetPlayerRevivalType
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6ff4
	// Params: [ Num(2) Size(0x8) ]
	void SetPlayerRevivalType(uint32_t InPlayerKey, int InRevivalType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A75B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A8E60
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A8430
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.SetPlayerAttributeModifyCompConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6f34
	// Params: [ Num(1) Size(0x50) ]
	void SetPlayerAttributeModifyCompConfig(struct TMap<uint32_t, struct FString> InAttributeModifyCompConfig);
	// [Call #1] RVA: 0x101FA6568
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046BADD8
	// [Call #5] RVA: 0x1046A6DB8
	// [Call #6] RVA: 0x101FA6894
	// [Call #7] RVA: 0x101FA6894
	// [Call #8] RVA: 0x101FA6894
	// [Call #9] RVA: 0x101FA6894
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A75B8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046A8E60
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetPawnStateConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6e74
	// Params: [ Num(1) Size(0x50) ]
	void SetPawnStateConfig(struct TMap<int, uint32_t> InPawnStateConfig);
	// [Call #1] RVA: 0x10325277C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1047EB4EC
	// [Call #5] RVA: 0x1046A6CC8
	// [Call #6] RVA: 0x103252AF0
	// [Call #7] RVA: 0x103252AF0
	// [Call #8] RVA: 0x103252AF0
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x101FA6568
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046BADD8
	// [Call #15] RVA: 0x1046A6DB8
	// [Call #16] RVA: 0x101FA6894
	// [Call #17] RVA: 0x101FA6894
	// [Call #18] RVA: 0x101FA6894
	// [Call #19] RVA: 0x101FA6894
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x1046A75B8

	// Object: Function AI.MLAISubSystem.SetOverrideMapID
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6df8
	// Params: [ Num(1) Size(0x4) ]
	void SetOverrideMapID(int InOverrideMapID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A87D4
	// [Call #4] RVA: 0x10325277C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047EB4EC
	// [Call #8] RVA: 0x1046A6CC8
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x103252AF0
	// [Call #11] RVA: 0x103252AF0
	// [Call #12] RVA: 0x103252AF0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x101FA6568
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046BADD8
	// [Call #18] RVA: 0x1046A6DB8
	// [Call #19] RVA: 0x101FA6894
	// [Call #20] RVA: 0x101FA6894
	// [Call #21] RVA: 0x101FA6894
	// [Call #22] RVA: 0x101FA6894
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetOpenBTCameraInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6d74
	// Params: [ Num(1) Size(0x1) ]
	void SetOpenBTCameraInfo(bool InOpenBTCameraInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A81D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A87D4
	// [Call #7] RVA: 0x10325277C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047EB4EC
	// [Call #11] RVA: 0x1046A6CC8
	// [Call #12] RVA: 0x103252AF0
	// [Call #13] RVA: 0x103252AF0
	// [Call #14] RVA: 0x103252AF0
	// [Call #15] RVA: 0x103252AF0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x101FA6568
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046BADD8
	// [Call #21] RVA: 0x1046A6DB8
	// [Call #22] RVA: 0x101FA6894
	// [Call #23] RVA: 0x101FA6894

	// Object: Function AI.MLAISubSystem.SetNonMLAIBuffConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6cb4
	// Params: [ Num(1) Size(0x50) ]
	void SetNonMLAIBuffConfig(struct TMap<int, uint32_t> InBuffIDs);
	// [Call #1] RVA: 0x10325277C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1047EB4EC
	// [Call #5] RVA: 0x1046A6C78
	// [Call #6] RVA: 0x103252AF0
	// [Call #7] RVA: 0x103252AF0
	// [Call #8] RVA: 0x103252AF0
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A81D8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A87D4
	// [Call #17] RVA: 0x10325277C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1047EB4EC
	// [Call #21] RVA: 0x1046A6CC8
	// [Call #22] RVA: 0x103252AF0
	// [Call #23] RVA: 0x103252AF0

	// Object: Function AI.MLAISubSystem.SetNewbieRealHiddenScore
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6c38
	// Params: [ Num(1) Size(0x4) ]
	void SetNewbieRealHiddenScore(int InNewbieRealHiddenScore);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A87B4
	// [Call #4] RVA: 0x10325277C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047EB4EC
	// [Call #8] RVA: 0x1046A6C78
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x103252AF0
	// [Call #11] RVA: 0x103252AF0
	// [Call #12] RVA: 0x103252AF0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A81D8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A87D4

	// Object: Function AI.MLAISubSystem.SetNewbieMatchCount
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6bbc
	// Params: [ Num(1) Size(0x4) ]
	void SetNewbieMatchCount(int InNewbieMatchCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A87C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A87B4
	// [Call #7] RVA: 0x10325277C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047EB4EC
	// [Call #11] RVA: 0x1046A6C78
	// [Call #12] RVA: 0x103252AF0
	// [Call #13] RVA: 0x103252AF0
	// [Call #14] RVA: 0x103252AF0
	// [Call #15] RVA: 0x103252AF0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A81D8

	// Object: Function AI.MLAISubSystem.SetNeedAllInfo
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1047e6b40
	// Params: [ Num(1) Size(0x1) ]
	void SetNeedAllInfo(bool bInNeedAllInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7874
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A87C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A87B4
	// [Call #10] RVA: 0x10325277C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047EB4EC
	// [Call #14] RVA: 0x1046A6C78
	// [Call #15] RVA: 0x103252AF0
	// [Call #16] RVA: 0x103252AF0
	// [Call #17] RVA: 0x103252AF0
	// [Call #18] RVA: 0x103252AF0
	// [Call #19] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.SetModGameType
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6ac4
	// Params: [ Num(1) Size(0x4) ]
	void SetModGameType(int InModGameType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A87CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A7874
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A87C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A87B4
	// [Call #13] RVA: 0x10325277C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetMLAIStateInfoManager
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6a48
	// Params: [ Num(1) Size(0x8) ]
	void SetMLAIStateInfoManager(struct UMLAIStateInfoManager* InMLAIStateInfoManager);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A75B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A87CC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A7874
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A87C0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetMLAIBuffConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6988
	// Params: [ Num(1) Size(0x50) ]
	void SetMLAIBuffConfig(struct TMap<int, uint32_t> InBuffIDs);
	// [Call #1] RVA: 0x10325277C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1047EB4EC
	// [Call #5] RVA: 0x1046A6C28
	// [Call #6] RVA: 0x103252AF0
	// [Call #7] RVA: 0x103252AF0
	// [Call #8] RVA: 0x103252AF0
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A75B0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A87CC
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A7874

	// Object: Function AI.MLAISubSystem.SetIntAIAttribute
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6898
	// Params: [ Num(3) Size(0x10) ]
	void SetIntAIAttribute(uint32_t InPlayerKey, uint32_t InAttributeID, uint64_t InAttributeValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A8308
	// [Call #8] RVA: 0x10325277C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047EB4EC
	// [Call #12] RVA: 0x1046A6C28
	// [Call #13] RVA: 0x103252AF0
	// [Call #14] RVA: 0x103252AF0
	// [Call #15] RVA: 0x103252AF0
	// [Call #16] RVA: 0x103252AF0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A75B0

	// Object: Function AI.MLAISubSystem.SetCDSkillConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e67d8
	// Params: [ Num(1) Size(0x50) ]
	void SetCDSkillConfig(struct TMap<int, uint32_t> InAttributeCDSkillConfigs);
	// [Call #1] RVA: 0x10325277C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1047EB4EC
	// [Call #5] RVA: 0x1046A6BD8
	// [Call #6] RVA: 0x103252AF0
	// [Call #7] RVA: 0x103252AF0
	// [Call #8] RVA: 0x103252AF0
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A8308
	// [Call #18] RVA: 0x10325277C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1047EB4EC
	// [Call #22] RVA: 0x1046A6C28
	// [Call #23] RVA: 0x103252AF0
	// [Call #24] RVA: 0x103252AF0
	// [Call #25] RVA: 0x103252AF0

	// Object: Function AI.MLAISubSystem.SetBackpackItemUpdatedMapSwitch
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1047e675c
	// Params: [ Num(1) Size(0x1) ]
	void SetBackpackItemUpdatedMapSwitch(bool bInSwitch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7880
	// [Call #4] RVA: 0x10325277C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047EB4EC
	// [Call #8] RVA: 0x1046A6BD8
	// [Call #9] RVA: 0x103252AF0
	// [Call #10] RVA: 0x103252AF0
	// [Call #11] RVA: 0x103252AF0
	// [Call #12] RVA: 0x103252AF0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A8308
	// [Call #21] RVA: 0x10325277C

	// Object: Function AI.MLAISubSystem.SetAirDropLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1047e6698
	// Params: [ Num(2) Size(0x10) ]
	void SetAirDropLocation(int InAirDropTag, struct FVector& AirDropLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A76E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A7880
	// [Call #9] RVA: 0x10325277C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047EB4EC
	// [Call #13] RVA: 0x1046A6BD8
	// [Call #14] RVA: 0x103252AF0
	// [Call #15] RVA: 0x103252AF0
	// [Call #16] RVA: 0x103252AF0
	// [Call #17] RVA: 0x103252AF0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetAIAttributeModifyCompConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e65d8
	// Params: [ Num(1) Size(0x50) ]
	void SetAIAttributeModifyCompConfig(struct TMap<uint32_t, struct FString> InAttributeModifyCompConfig);
	// [Call #1] RVA: 0x101FA6568
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046BADD8
	// [Call #5] RVA: 0x1046A6D68
	// [Call #6] RVA: 0x101FA6894
	// [Call #7] RVA: 0x101FA6894
	// [Call #8] RVA: 0x101FA6894
	// [Call #9] RVA: 0x101FA6894
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A76E0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046A7880
	// [Call #19] RVA: 0x10325277C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.SetAIAttribute_CastEnergyWithCount
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e63c4
	// Params: [ Num(8) Size(0x20) ]
	void SetAIAttribute_CastEnergyWithCount(uint32_t InPlayerKey, uint32_t InAttributeID, int InCurCount, float InCurEnergy, float InLastActiveTime, int InMaxCount, float InMaxEnergy, float InDeltaEnergy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A855C
	// [Call #18] RVA: 0x101FA6568
	// [Call #19] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.SetAIAttribute
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e62d4
	// Params: [ Num(3) Size(0xC) ]
	void SetAIAttribute(uint32_t InPlayerKey, uint32_t InAttributeID, float InAttributeValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A81E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.ResetAttributeIDToPlayerKeysMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e61b0
	// Params: [ Num(2) Size(0x18) ]
	void ResetAttributeIDToPlayerKeysMap(uint32_t InAttributeID, struct TArray<uint32_t> InPlayerKeys);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10231FD0C
	// [Call #6] RVA: 0x1046A8AB4
	// [Call #7] RVA: 0x101F8B9C8
	// [Call #8] RVA: 0x101F8B9C8
	// [Call #9] RVA: 0x101F8B9C8
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8B9C8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A81E4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.RemoveSpecialZoneInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e60fc
	// Params: [ Num(2) Size(0x8) ]
	void RemoveSpecialZoneInfo(uint32_t ZoneID, uint32_t Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A6F24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10231FD0C
	// [Call #11] RVA: 0x1046A8AB4
	// [Call #12] RVA: 0x101F8B9C8
	// [Call #13] RVA: 0x101F8B9C8
	// [Call #14] RVA: 0x101F8B9C8
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8B9C8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.RemoveMercenary2MasterMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e6048
	// Params: [ Num(2) Size(0x10) ]
	void RemoveMercenary2MasterMap(struct APawn* MercenaryAI, struct APawn* Master);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A8878
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A6F24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10231FD0C
	// [Call #16] RVA: 0x1046A8AB4
	// [Call #17] RVA: 0x101F8B9C8
	// [Call #18] RVA: 0x101F8B9C8

	// Object: Function AI.MLAISubSystem.RemoveFromSilentMLAIList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5fcc
	// Params: [ Num(1) Size(0x4) ]
	void RemoveFromSilentMLAIList(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8654
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A8878
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A6F24
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.RemoveFromPlayerWhitelist
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5f50
	// Params: [ Num(1) Size(0x4) ]
	void RemoveFromPlayerWhitelist(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8724
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8654
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A8878
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A6F24

	// Object: Function AI.MLAISubSystem.RemoveAICheckVisibilityFilteredActor
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5ed4
	// Params: [ Num(1) Size(0x4) ]
	void RemoveAICheckVisibilityFilteredActor(uint32_t ActorId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8D8C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8724
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A8654
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A8878

	// Object: Function AI.MLAISubSystem.RegisterSpecialMapping
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5dfc
	// Params: [ Num(2) Size(0x14) ]
	void RegisterSpecialMapping(struct FString Key, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A8F14
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A8D8C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A8724
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A8654

	// Object: Function AI.MLAISubSystem.RegisterDynamicItemComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5d80
	// Params: [ Num(1) Size(0x8) ]
	void RegisterDynamicItemComponent(struct UAIPerceptionDynamicItemComponent* InDynamicItemComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8D94
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A8F14
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A8D8C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A8724

	// Object: Function AI.MLAISubSystem.RegisterDestructibleItemComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5d04
	// Params: [ Num(1) Size(0x8) ]
	void RegisterDestructibleItemComponent(struct UAIPerceptionDynamicItemComponent* InComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8E6C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8D94
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A8F14
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A8D8C

	// Object: Function AI.MLAISubSystem.OnVehicleDamageInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5b18
	// Params: [ Num(7) Size(0x30) ]
	void OnVehicleDamageInfo(struct AController* InstigatorController, struct AController* VictimController, int DamageTypeId, float Damage, bool bIsFatalHealthCost, struct AActor* DamageCauser, struct AActor* VictimVehicle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A5720
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046A8E6C

	// Object: Function AI.MLAISubSystem.OnPlayerStartFire
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5a64
	// Params: [ Num(2) Size(0x8) ]
	void OnPlayerStartFire(uint32_t PlayerKey, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A5A74
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.OnPlayerPickUpItem
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e59e8
	// Params: [ Num(1) Size(0x4) ]
	void OnPlayerPickUpItem(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A6850
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A5A74
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.OnPlayerDamageInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e5794
	// Params: [ Num(8) Size(0x39) ]
	void OnPlayerDamageInfo(struct ASTExtraPlayerState* InstigatorPlayerState, struct ASTExtraPlayerState* VictimPlayerState, float Damage, struct FDamageEvent& DamageEvent, float DamageBeforeCalArmor, bool bIsFatalHealthCost, struct AActor* DamageCauser, bool bIsNearDeathHealthCost);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A51B0

	// Object: Function AI.MLAISubSystem.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1047e5718
	// Params: [ Num(1) Size(0xC) ]
	void OnItemStateChanged(struct FVector Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A67E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.OnAirDropBoxSpawn
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e569c
	// Params: [ Num(1) Size(0x8) ]
	void OnAirDropBoxSpawn(struct AAirDropBoxActor* AirDropBoxActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7514
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A67E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.OnAirAttackInfo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1047e54fc
	// Params: [ Num(4) Size(0x64) ]
	void OnAirAttackInfo(uint8_t airattacktype, int waveIndex, struct FAirAttackOrder& InAirAttackOrder, struct FVector& InAirAttackArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A55A8
	// [Call #10] RVA: 0x10311028C
	// [Call #11] RVA: 0x10311028C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A7514
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.IsAvailableBackpackItemType
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x1047e545c
	// Params: [ Num(2) Size(0x19) ]
	bool IsAvailableBackpackItemType(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046A7218
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A55A8
	// [Call #14] RVA: 0x10311028C
	// [Call #15] RVA: 0x10311028C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.IsAIBotGame
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5428
	// Params: [ Num(1) Size(0x1) ]
	bool IsAIBotGame();
	// [Call #1] RVA: 0x1046A4CC0
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A7218
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A55A8
	// [Call #15] RVA: 0x10311028C

	// Object: Function AI.MLAISubSystem.InsertPlayerWhitelist
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e53ac
	// Params: [ Num(1) Size(0x4) ]
	void InsertPlayerWhitelist(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A86F8
	// [Call #4] RVA: 0x1046A4CC0
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A7218
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.InsertIntoSilentMLAIList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5330
	// Params: [ Num(1) Size(0x4) ]
	void InsertIntoSilentMLAIList(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8628
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A86F8
	// [Call #7] RVA: 0x1046A4CC0
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A7218
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.GetVoiceRoomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e5288
	// Params: [ Num(1) Size(0x10) ]
	void GetVoiceRoomInfo(struct TArray<struct FBattleVoiceRoomInfo>& BattleVoiceRoomInfos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7924
	// [Call #4] RVA: 0x1046E7B80
	// [Call #5] RVA: 0x1046E7B80
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A8628
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A86F8
	// [Call #13] RVA: 0x1046A4CC0
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.GetServerIPAddress
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5224
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetServerIPAddress();
	// [Call #1] RVA: 0x1046A8A48
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A7924
	// [Call #9] RVA: 0x1046E7B80
	// [Call #10] RVA: 0x1046E7B80
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A8628
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A86F8
	// [Call #18] RVA: 0x1046A4CC0

	// Object: Function AI.MLAISubSystem.GetLossTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e5198
	// Params: [ Num(2) Size(0xC) ]
	float GetLossTime(struct ASTExtraPlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A6F84
	// [Call #4] RVA: 0x1046A8A48
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A7924
	// [Call #12] RVA: 0x1046E7B80
	// [Call #13] RVA: 0x1046E7B80
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A8628
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.GetItemDurability
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e510c
	// Params: [ Num(2) Size(0x8) ]
	int GetItemDurability(int InTypeSpecificID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8B44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A6F84
	// [Call #7] RVA: 0x1046A8A48
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A7924
	// [Call #15] RVA: 0x1046E7B80
	// [Call #16] RVA: 0x1046E7B80
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.GetCacheStrAIAttributes
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e5028
	// Params: [ Num(2) Size(0x18) ]
	void GetCacheStrAIAttributes(uint32_t InPlayerKey, struct TArray<struct FStrAIAttribute>& StrAttributes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A8088
	// [Call #6] RVA: 0x1046E806C
	// [Call #7] RVA: 0x1046E806C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A8B44
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A6F84
	// [Call #15] RVA: 0x1046A8A48
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function AI.MLAISubSystem.GetCacheIntAIAttributes
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e4f44
	// Params: [ Num(2) Size(0x18) ]
	void GetCacheIntAIAttributes(uint32_t InPlayerKey, struct TArray<struct FIntAIAttribute>& IntAttributes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A7F1C
	// [Call #6] RVA: 0x1046AFCC0
	// [Call #7] RVA: 0x1046AFCC0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A8088
	// [Call #14] RVA: 0x1046E806C
	// [Call #15] RVA: 0x1046E806C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A8B44

	// Object: Function AI.MLAISubSystem.GetCacheAIAttributes
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e4e60
	// Params: [ Num(2) Size(0x18) ]
	void GetCacheAIAttributes(uint32_t InPlayerKey, struct TArray<struct FAIAttribute>& Attributes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A7B60
	// [Call #6] RVA: 0x1046AFD10
	// [Call #7] RVA: 0x1046AFD10
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A7F1C
	// [Call #14] RVA: 0x1046AFCC0
	// [Call #15] RVA: 0x1046AFCC0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.GetAndCheckAirDopTag
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4e2c
	// Params: [ Num(1) Size(0x4) ]
	int GetAndCheckAirDopTag();
	// [Call #1] RVA: 0x1046A7648
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A7B60
	// [Call #7] RVA: 0x1046AFD10
	// [Call #8] RVA: 0x1046AFD10
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A7F1C
	// [Call #15] RVA: 0x1046AFCC0
	// [Call #16] RVA: 0x1046AFCC0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.FindPlayerWhiteRange
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x1047e4d74
	// Params: [ Num(2) Size(0x10) ]
	void FindPlayerWhiteRange(struct FVector InLocation, float InRange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A896C
	// [Call #6] RVA: 0x1046A7648
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A7B60
	// [Call #12] RVA: 0x1046AFD10
	// [Call #13] RVA: 0x1046AFD10
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.FindMasterTeamMateList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4cf8
	// Params: [ Num(1) Size(0x8) ]
	void FindMasterTeamMateList(struct APawn* Master);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A88B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A896C
	// [Call #9] RVA: 0x1046A7648
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A7B60
	// [Call #15] RVA: 0x1046AFD10
	// [Call #16] RVA: 0x1046AFD10
	// [Call #17] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.EndRequestCache
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4ce4
	// Params: [ Num(0) Size(0x0) ]
	void EndRequestCache();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A88B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A896C
	// [Call #9] RVA: 0x1046A7648
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A7B60
	// [Call #15] RVA: 0x1046AFD10
	// [Call #16] RVA: 0x1046AFD10

	// Object: Function AI.MLAISubSystem.ClearSpecialMappings
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4cd0
	// Params: [ Num(0) Size(0x0) ]
	void ClearSpecialMappings();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A88B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A896C
	// [Call #9] RVA: 0x1046A7648
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A7B60
	// [Call #15] RVA: 0x1046AFD10

	// Object: Function AI.MLAISubSystem.ClearAttributeIDToPlayerKeysMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4c54
	// Params: [ Num(1) Size(0x4) ]
	void ClearAttributeIDToPlayerKeysMap(uint32_t InAttributeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8B3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A88B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A896C
	// [Call #12] RVA: 0x1046A7648
	// [Call #13] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.ChangeMLAIInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e4ae8
	// Params: [ Num(4) Size(0x78) ]
	void ChangeMLAIInfo(struct AFakePlayerAIController* AIController, struct FString Name, uint64_t DisplayUID, struct FPlayerOBInfo& OBInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046A7044
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A8B3C
	// [Call #16] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.CanGetState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4a5c
	// Params: [ Num(2) Size(0x5) ]
	bool CanGetState(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8750
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046A7044
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.CanFindInSilentMLAIList
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e49d0
	// Params: [ Num(2) Size(0x5) ]
	bool CanFindInSilentMLAIList(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8680
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A8750
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046A7044
	// [Call #16] RVA: 0x101F8130C

	// Object: Function AI.MLAISubSystem.AddVoiceServerURLInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e48fc
	// Params: [ Num(2) Size(0x18) ]
	void AddVoiceServerURLInfo(uint32_t PlayerKey, struct FString BattleVoiceServerURL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A78D8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A8680
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046A8750
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AI.MLAISubSystem.AddVoiceRoomInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4828
	// Params: [ Num(2) Size(0x18) ]
	void AddVoiceRoomInfo(uint32_t TeamID, struct FString BattleVoiceRoomID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A788C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A78D8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A8680

	// Object: Function AI.MLAISubSystem.AddTeammateMLAITeamID
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e47ac
	// Params: [ Num(1) Size(0x4) ]
	void AddTeammateMLAITeamID(uint32_t TeamID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A7B18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A788C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A78D8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function AI.MLAISubSystem.AddPendingUpdateSpecialZone
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4730
	// Params: [ Num(1) Size(0x8) ]
	void AddPendingUpdateSpecialZone(struct ASpecialZoneActor* InSpecialZone);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A60EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046A7B18
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046A788C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.AddMercenary2MasterMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e4638
	// Params: [ Num(3) Size(0x11) ]
	void AddMercenary2MasterMap(struct APawn* MercenaryAI, struct APawn* Master, bool bIncludesTeammates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A87DC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A60EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A7B18
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.MLAISubSystem.AddAICheckVisibilityFilteredActor
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e45bc
	// Params: [ Num(1) Size(0x4) ]
	void AddAICheckVisibilityFilteredActor(uint32_t ActorId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A8D60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046A87DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046A60EC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

// Object: Class AI.MLAITrainingComponent
// Size: 0x1B0 (Inherited: 0x178)
struct UMLAITrainingComponent : UActorComponent
{
	bool IsBeginRequestAIState; // 0x178(0x1)
	bool IsEndRequestAIState; // 0x179(0x1)
	bool bPauseGameAfterSendPacket; // 0x17A(0x1)
	uint8_t Pad_0x17B[0x5]; // 0x17B(0x5)
	struct APlayerState* PauseGamePlayerState; // 0x180(0x8)
	bool bIsPausing; // 0x188(0x1)
	uint8_t Pad_0x189[0x27]; // 0x189(0x27)


	// Object: Function AI.MLAITrainingComponent.StopRunnable
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9164
	// Params: [ Num(0) Size(0x0) ]
	void StopRunnable();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.MLAITrainingComponent.SetPauseGamePlayerState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e90e8
	// Params: [ Num(1) Size(0x8) ]
	void SetPauseGamePlayerState(struct APlayerState* InPlayerState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046A9BBC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.MLAITrainingComponent.SetPause
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9018
	// Params: [ Num(3) Size(0x9) ]
	bool SetPause(bool bInPause, float InPauseTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046A96EC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046A9BBC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.MLAITrainingComponent.SendAIStateRequest
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e8f34
	// Params: [ Num(1) Size(0x10) ]
	void SendAIStateRequest(struct TArray<uint8_t> Packet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FFC894
	// [Call #4] RVA: 0x1046A9A50
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046A96EC
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1046A9BBC

	// Object: Function AI.MLAITrainingComponent.IsRequestAIState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e8f00
	// Params: [ Num(1) Size(0x1) ]
	bool IsRequestAIState();
	// [Call #1] RVA: 0x1046A9B8C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FFC894
	// [Call #5] RVA: 0x1046A9A50
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046A96EC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1046A9BBC

	// Object: Function AI.MLAITrainingComponent.InitRunnable
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e8e10
	// Params: [ Num(3) Size(0xC) ]
	void InitRunnable(float InStartCollectingInterval, float InSendInterval, float InTimeOutInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A988C
	// [Call #8] RVA: 0x1046A9B8C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FFC894
	// [Call #12] RVA: 0x1046A9A50
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AI.MLAITrainingComponent.EndRequestAIState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e8dfc
	// Params: [ Num(0) Size(0x0) ]
	void EndRequestAIState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046A988C
	// [Call #8] RVA: 0x1046A9B8C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FFC894
	// [Call #12] RVA: 0x1046A9A50
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
};

// Object: Class AI.MPStateInfoCollector
// Size: 0x3B8 (Inherited: 0x58)
struct UMPStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FMPBaseAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffMPBaseAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x118)
	struct FMPBaseGlobalGameState CacheGlobalGameState; // 0x260(0x40)
	struct FMPBaseGlobalGameState LastGlobalGameState; // 0x2A0(0x40)
	struct FMPBaseGlobalGameState DiffGlobalGameState; // 0x2E0(0x40)
	struct FDiffMPBaseGlobalGameState DiffGlobalGameStateGeneral; // 0x320(0x68)
	uint8_t Pad_0x388[0x30]; // 0x388(0x30)
};

// Object: Class AI.SpecialZoneShapeComponent
// Size: 0x9D0 (Inherited: 0x9D0)
struct USpecialZoneShapeComponent : UPrimitiveComponent
{
	float SphereRadius; // 0x9C8(0x4)
};

// Object: Class AI.SpecialZoneActor
// Size: 0x6C0 (Inherited: 0x570)
struct ASpecialZoneActor : ALuaActor
{
	int ZoneID; // 0x56C(0x4)
	float Radius; // 0x570(0x4)
	int Type; // 0x574(0x4)
	bool IsDynamic; // 0x578(0x1)
	int CustomState; // 0x57C(0x4)
	struct TMap<uint32_t, float> CustomAttributeMap; // 0x580(0x50)
	struct TMap<uint32_t, uint64_t> IntCustomAttributeMap; // 0x5D0(0x50)
	bool IsDestructibleMesh; // 0x620(0x1)
	bool IsInstanced; // 0x621(0x1)
	uint8_t Pad_0x623[0x1]; // 0x623(0x1)
	int InstancedMaxNum; // 0x624(0x4)
	struct TMap<struct FString, int> StaticMeshNameToType; // 0x628(0x50)
	bool CheckNearHaveAI; // 0x678(0x1)
	uint8_t Pad_0x679[0x3]; // 0x679(0x3)
	float CheckAIDist; // 0x67C(0x4)
	struct USpecialZoneShapeComponent* SpecialZoneShapeComponent; // 0x680(0x8)
	struct AActor* CacheParentActor; // 0x688(0x8)
	uint8_t Pad_0x690[0x4]; // 0x690(0x4)
	uint32_t ExtraState; // 0x694(0x4)
	float Health; // 0x698(0x4)
	bool IsSpawnBTAINeedCheck; // 0x69C(0x1)
	uint8_t SpecialZoneType; // 0x69D(0x1)
	uint8_t Pad_0x69E[0xA]; // 0x69E(0xA)
	struct AAIWorldVolume* AIWorldVolume; // 0x6A8(0x8)
	struct UInstancedStaticMeshComponent* CacheInstancedMeshComp; // 0x6B0(0x8)
	struct USTDestructionComponent* CacheDestructibleMeshComp; // 0x6B8(0x8)


	// Object: Function AI.SpecialZoneActor.UpdateType
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9e48
	// Params: [ Num(1) Size(0x4) ]
	void UpdateType(int InType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC500
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.SpecialZoneActor.UpdateIntCustomAttributeValue
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e9d1c
	// Params: [ Num(3) Size(0x11) ]
	void UpdateIntCustomAttributeValue(uint32_t& InCustomAttributeID, uint64_t& InValue, bool& bRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DC444
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DC500
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function AI.SpecialZoneActor.UpdateHealth
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9ca0
	// Params: [ Num(1) Size(0x4) ]
	void UpdateHealth(float InHealth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC508
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DC444
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DC500
	// [Call #14] RVA: 0x10519022C

	// Object: Function AI.SpecialZoneActor.UpdateExtraState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9c24
	// Params: [ Num(1) Size(0x4) ]
	void UpdateExtraState(uint32_t InExtraState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC3B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046DC508
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DC444
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.SpecialZoneActor.UpdateCustomState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9ba8
	// Params: [ Num(1) Size(0x4) ]
	void UpdateCustomState(int InCustomState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC3AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046DC3B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DC508
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AI.SpecialZoneActor.UpdateCustomAttributeValue
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e9a7c
	// Params: [ Num(3) Size(0x9) ]
	void UpdateCustomAttributeValue(uint32_t& InCustomAttributeID, float& InValue, bool& bRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DC3BC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DC3AC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DC3B4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.SpecialZoneActor.HandleFragmentsStateChanged
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e995c
	// Params: [ Num(3) Size(0x18) ]
	void HandleFragmentsStateChanged(int FragmentItemIndex, uint8_t State, struct TArray<uint8_t>& FragmentState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DC580
	// [Call #8] RVA: 0x1024C87F0
	// [Call #9] RVA: 0x1024C87F0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1046DC3BC

	// Object: Function AI.SpecialZoneActor.GetSpecialZoneState
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e98f8
	// Params: [ Num(1) Size(0x88) ]
	struct FSpecialZoneState GetSpecialZoneState();
	// [Call #1] RVA: 0x1046DBBF8
	// [Call #2] RVA: 0x1046A609C
	// [Call #3] RVA: 0x1046AFC88
	// [Call #4] RVA: 0x1046AFC88
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046DC580
	// [Call #13] RVA: 0x1024C87F0
	// [Call #14] RVA: 0x1024C87F0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function AI.SpecialZoneActor.GetIntCustomAttributeList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e9850
	// Params: [ Num(1) Size(0x10) ]
	void GetIntCustomAttributeList(struct TArray<struct FIntAIAttribute>& OutIntCustomAttributeList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC278
	// [Call #4] RVA: 0x1046AFCC0
	// [Call #5] RVA: 0x1046AFCC0
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1046DBBF8
	// [Call #8] RVA: 0x1046A609C
	// [Call #9] RVA: 0x1046AFC88
	// [Call #10] RVA: 0x1046AFC88
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1046DC580
	// [Call #19] RVA: 0x1024C87F0
	// [Call #20] RVA: 0x1024C87F0
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AI.SpecialZoneActor.GetCustomAttributeList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047e97a8
	// Params: [ Num(1) Size(0x10) ]
	void GetCustomAttributeList(struct TArray<struct FAIAttribute>& OutCustomAttributeList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC150
	// [Call #4] RVA: 0x1046AFD10
	// [Call #5] RVA: 0x1046AFD10
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DC278
	// [Call #10] RVA: 0x1046AFCC0
	// [Call #11] RVA: 0x1046AFCC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1046DBBF8
	// [Call #14] RVA: 0x1046A609C
	// [Call #15] RVA: 0x1046AFC88
	// [Call #16] RVA: 0x1046AFC88
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AI.SpecialZoneActor.ClearCustomAttributeMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1047e9794
	// Params: [ Num(0) Size(0x0) ]
	void ClearCustomAttributeMap();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DC150
	// [Call #4] RVA: 0x1046AFD10
	// [Call #5] RVA: 0x1046AFD10
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DC278
	// [Call #10] RVA: 0x1046AFCC0
	// [Call #11] RVA: 0x1046AFCC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1046DBBF8
	// [Call #14] RVA: 0x1046A609C
	// [Call #15] RVA: 0x1046AFC88
	// [Call #16] RVA: 0x1046AFC88
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
};

// Object: Class AI.STStrategyLocation_Range
// Size: 0x150 (Inherited: 0x100)
struct USTStrategyLocation_Range : USTStrategyLocation
{
	uint8_t bUseNavmesh : 1; // 0x100(0x1), Mask(0x1)
	uint8_t BitPad_0x100_1 : 7; // 0x100(0x1)
	uint8_t Pad_0x101[0x3]; // 0x101(0x3)
	float Range; // 0x104(0x4)
	int MaxTryTimes; // 0x108(0x4)
	uint8_t bCheckPlayerSight : 1; // 0x10C(0x1), Mask(0x1)
	uint8_t BitPad_0x10C_1 : 7; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	float VerticalOffset; // 0x110(0x4)
	float PlayerViewDistance; // 0x114(0x4)
	enum class ECollisionChannel CollisionChannel; // 0x118(0x1)
	uint8_t Pad_0x119[0x3]; // 0x119(0x3)
	float MaxLocationTraceHeightZ; // 0x11C(0x4)
	struct TArray<struct FSpawnArea> CustomAreas; // 0x120(0x10)
	bool bOnlyOnLandscape; // 0x130(0x1)
	uint8_t Pad_0x131[0x7]; // 0x131(0x7)
	struct FName LandscapeTag; // 0x138(0x8)
	uint8_t Pad_0x140[0x10]; // 0x140(0x10)


	// Object: Function AI.STStrategyLocation_Range.ModifyBaseLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1047ea65c
	// Params: [ Num(1) Size(0xC) ]
	void ModifyBaseLocation(struct FVector InLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function AI.STStrategyLocation_Range.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047ea524
	// Params: [ Num(4) Size(0x21) ]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D5E0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function AI.STStrategyLocation_Range.AddSpawnArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047ea460
	// Params: [ Num(2) Size(0x21) ]
	void AddSpawnArea(struct FSpawnArea NewArea, bool ForceAdd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10477CFE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B8D5E0
	// [Call #13] RVA: 0x102B8D5E0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AI.STStrategyLocation_Range.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047ea3dc
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10477CFE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B8D5E0
};

// Object: Class AI.STStrategySpecies_Candidate
// Size: 0x108 (Inherited: 0x108)
struct USTStrategySpecies_Candidate : USTStrategySpecies
{

	// Object: Function AI.STStrategySpecies_Candidate.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1047ed0e4
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9C340
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AI.STStrategySpecies_Candidate.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047ed060
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B9C340
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B8D5E0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class AI.STStrategySpecies_Lua
// Size: 0x108 (Inherited: 0x108)
struct USTStrategySpecies_Lua : USTStrategySpecies
{

	// Object: Function AI.STStrategySpecies_Lua.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1047ed3f8
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9C340
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AI.STStrategySpecies_Lua.LuaSupply
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void LuaSupply(int ReferencedCount);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class AI.STStrategyTiming_Event
// Size: 0x110 (Inherited: 0xF0)
struct USTStrategyTiming_Event : USTStrategyTiming
{
	struct FString EventID; // 0xF0(0x10)
	struct FString EventName; // 0x100(0x10)


	// Object: Function AI.STStrategyTiming_Event.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047ed7c4
	// Params: [ Num(1) Size(0x4) ]
	void TickStrategy(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function AI.STStrategyTiming_Event.OnSpawnEventBroadcast
	// Flags: [Final|Native|Public]
	// Offset: 0x1047ed748
	// Params: [ Num(1) Size(0x4) ]
	void OnSpawnEventBroadcast(uint32_t SpawnerID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10477DA5C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.STStrategyTiming_Event.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047ed6c4
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10477DA5C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
};

// Object: Class AI.TeammateMLAIControllerComponent
// Size: 0x680 (Inherited: 0x238)
struct UTeammateMLAIControllerComponent : ULuaActorComponent
{
	struct FString DefaultLuaFilePath; // 0x238(0x10)
	struct FGameModeAIPlayerParams AIParams; // 0x248(0x408)
	uint32_t AILevel; // 0x650(0x4)
	uint32_t MLAIStyle; // 0x654(0x4)
	uint32_t TargetPlayerKey; // 0x658(0x4)
	uint8_t Pad_0x65C[0x4]; // 0x65C(0x4)
	struct ASTExtraPlayerController* OwnerPlayerController; // 0x660(0x8)
	float DefaultExitTime; // 0x668(0x4)
	uint8_t Pad_0x66C[0x4]; // 0x66C(0x4)
	struct FTimerHandle TeammateMLAIExitTimer; // 0x670(0x8)
	bool bIsTakeOverTeammate; // 0x678(0x1)
	uint8_t Pad_0x679[0x7]; // 0x679(0x7)


	// Object: Function AI.TeammateMLAIControllerComponent.SetMLAIStyle
	// Flags: [Final|Native|Public]
	// Offset: 0x1047eddb0
	// Params: [ Num(1) Size(0x4) ]
	void SetMLAIStyle(uint32_t NewAIStyle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DD5B4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AI.TeammateMLAIControllerComponent.SetIsMLAI
	// Flags: [Final|Native|Public]
	// Offset: 0x1047edd2c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsMLAI(bool InIsMLAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DD488
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046DD5B4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function AI.TeammateMLAIControllerComponent.SetAIParams
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047edc78
	// Params: [ Num(1) Size(0x408) ]
	void SetAIParams(struct FGameModeAIPlayerParams& InAIParams);
	// [Call #1] RVA: 0x1032216FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046DD610
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DD488
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DD5B4
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function AI.TeammateMLAIControllerComponent.SetAILevel
	// Flags: [Final|Native|Public]
	// Offset: 0x1047edbfc
	// Params: [ Num(1) Size(0x4) ]
	void SetAILevel(uint32_t NewAILevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DD55C
	// [Call #4] RVA: 0x1032216FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DD610
	// [Call #8] RVA: 0x1025A2064
	// [Call #9] RVA: 0x1025A2064
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DD488
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046DD5B4

	// Object: Function AI.TeammateMLAIControllerComponent.OnTeammateMLAILost
	// Flags: [Final|Native|Public]
	// Offset: 0x1047edbe8
	// Params: [ Num(0) Size(0x0) ]
	void OnTeammateMLAILost();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DD55C
	// [Call #4] RVA: 0x1032216FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DD610
	// [Call #8] RVA: 0x1025A2064
	// [Call #9] RVA: 0x1025A2064
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DD488
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046DD5B4

	// Object: Function AI.TeammateMLAIControllerComponent.OnTeammateMLAIExit
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047edbd4
	// Params: [ Num(0) Size(0x0) ]
	void OnTeammateMLAIExit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046DD55C
	// [Call #4] RVA: 0x1032216FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DD610
	// [Call #8] RVA: 0x1025A2064
	// [Call #9] RVA: 0x1025A2064
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1046DD488
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1046DD5B4

	// Object: Function AI.TeammateMLAIControllerComponent.OnControllerStateChanged
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1047edb50
	// Params: [ Num(1) Size(0x1) ]
	void OnControllerStateChanged(uint8_t StateType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046DD55C
	// [Call #6] RVA: 0x1032216FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DD610
	// [Call #10] RVA: 0x1025A2064
	// [Call #11] RVA: 0x1025A2064
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1046DD488

	// Object: Function AI.TeammateMLAIControllerComponent.IsTakeOverTeammate
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047edb1c
	// Params: [ Num(1) Size(0x1) ]
	bool IsTakeOverTeammate();
	// [Call #1] RVA: 0x1046DD618
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1046DD55C
	// [Call #7] RVA: 0x1032216FC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046DD610
	// [Call #11] RVA: 0x1025A2064
	// [Call #12] RVA: 0x1025A2064
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function AI.TeammateMLAIControllerComponent.GetMLAIStyle
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047edae8
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetMLAIStyle();
	// [Call #1] RVA: 0x1046DD5AC
	// [Call #2] RVA: 0x1046DD618
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046DD55C
	// [Call #8] RVA: 0x1032216FC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1046DD610
	// [Call #12] RVA: 0x1025A2064
	// [Call #13] RVA: 0x1025A2064
	// [Call #14] RVA: 0x106C8459C

	// Object: Function AI.TeammateMLAIControllerComponent.GetAIParams
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047edab0
	// Params: [ Num(1) Size(0x408) ]
	struct FGameModeAIPlayerParams GetAIParams();
	// [Call #1] RVA: 0x1046DD608
	// [Call #2] RVA: 0x1046DD5AC
	// [Call #3] RVA: 0x1046DD618
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046DD55C
	// [Call #9] RVA: 0x1032216FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1046DD610
	// [Call #13] RVA: 0x1025A2064

	// Object: Function AI.TeammateMLAIControllerComponent.GetAILevel
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1047eda7c
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetAILevel();
	// [Call #1] RVA: 0x1046DD600
	// [Call #2] RVA: 0x1046DD608
	// [Call #3] RVA: 0x1046DD5AC
	// [Call #4] RVA: 0x1046DD618
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1046DD55C
	// [Call #10] RVA: 0x1032216FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class AI.VehicleAIController
// Size: 0x940 (Inherited: 0x8B0)
struct AVehicleAIController : ABasicAIController
{
	struct ASTExtraVehicleBase* ControlledVehicle; // 0x8B0(0x8)
	struct FAIVehicleStateData AIVehicleStateData; // 0x8B8(0x80)
	struct UAIBehaviorAdapter_VehicleBase* AIBehaviorAdapter; // 0x938(0x8)


	// Object: Function AI.VehicleAIController.SetCurEnemy
	// Flags: [Native|Public]
	// Offset: 0x1047ee390
	// Params: [ Num(1) Size(0x8) ]
	void SetCurEnemy(struct APawn* NewEnemy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.VehicleAIController.GetVehiclePathFollow
	// Flags: [Final|Native|Public]
	// Offset: 0x1047ee35c
	// Params: [ Num(1) Size(0x8) ]
	struct UVehiclePathFollowingComponent* GetVehiclePathFollow();
	// [Call #1] RVA: 0x104699948
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.VehicleAIController.GetCurEnemy
	// Flags: [Native|Public]
	// Offset: 0x1047ee320
	// Params: [ Num(1) Size(0x8) ]
	struct APawn* GetCurEnemy();
	// [Call #1] RVA: 0x104699948
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.VehicleAIController.GetAIHitRate
	// Flags: [Native|Public]
	// Offset: 0x1047ee28c
	// Params: [ Num(2) Size(0x8) ]
	float GetAIHitRate(float Distance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104699948
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.VehicleAIController.ExplodeAndDeath
	// Flags: [Native|Public]
	// Offset: 0x1047ee270
	// Params: [ Num(0) Size(0x0) ]
	void ExplodeAndDeath();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104699948
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870

	// Object: Function AI.VehicleAIController.DelayInitVehicleWeapon
	// Flags: [Final|Native|Protected]
	// Offset: 0x1047ee25c
	// Params: [ Num(0) Size(0x0) ]
	void DelayInitVehicleWeapon();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104699948
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
};

// Object: Class AI.VehicleAIUserComponent
// Size: 0x368 (Inherited: 0x368)
struct UVehicleAIUserComponent : UVehicleUserComponentBase
{

	// Object: Function AI.VehicleAIUserComponent.ServerVehicleLeanOut
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047eeba4
	// Params: [ Num(1) Size(0x1) ]
	void ServerVehicleLeanOut(bool bLeanOut);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AI.VehicleAIUserComponent.ServerExitVehicleEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047eeb20
	// Params: [ Num(1) Size(0x1) ]
	void ServerExitVehicleEx(bool bMustExit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046E1394
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.VehicleAIUserComponent.ServerExitVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047eeb0c
	// Params: [ Num(0) Size(0x0) ]
	void ServerExitVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046E1394
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AI.VehicleAIUserComponent.ServerEnterVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047eea54
	// Params: [ Num(2) Size(0x9) ]
	void ServerEnterVehicle(struct ASTExtraVehicleBase* InVehicle, uint8_t SeatType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046E11D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1046E1394
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function AI.VehicleAIUserComponent.ServerChangeVehicleSeat
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047ee9d0
	// Params: [ Num(1) Size(0x4) ]
	void ServerChangeVehicleSeat(int InSeatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046E11D8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046E1394
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AI.VehicleAIUserComponent.MulticastExitVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x1047ee9b4
	// Params: [ Num(0) Size(0x0) ]
	void MulticastExitVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1046E11D8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1046E1394
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function AI.VehicleAIUserComponent.MulticastEnterVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x1047ee834
	// Params: [ Num(5) Size(0x18) ]
	void MulticastEnterVehicle(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraPlayerCharacter* Pawn, bool bSuccess, uint8_t SeatType, int SeatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function AI.VehicleAIUserComponent.MulticastChangeVehicleSeat
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x1047ee7b0
	// Params: [ Num(1) Size(0x4) ]
	void MulticastChangeVehicleSeat(int InSeatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
};

// Object: Class AI.VehicleCustomDamageEventComponent
// Size: 0x378 (Inherited: 0x370)
struct UVehicleCustomDamageEventComponent : UCustomDamageEventComponent
{
	uint8_t Pad_0x370[0x8]; // 0x370(0x8)


	// Object: Function AI.VehicleCustomDamageEventComponent.OnVehicleHPFuelChanged
	// Flags: [Final|Native|Public]
	// Offset: 0x1047eef90
	// Params: [ Num(2) Size(0x8) ]
	void OnVehicleHPFuelChanged(float Hp, float Fuel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1046E1DE4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105190870
};

// Object: Class AI.VehiclePathFollowingComponent
// Size: 0x370 (Inherited: 0x348)
struct UVehiclePathFollowingComponent : UPathFollowingComponent
{
	float Writable_Throttle; // 0x344(0x4)
	uint8_t bWritable_SteeringOnly : 1; // 0x348(0x1), Mask(0x1)
	uint8_t bWritable_ThrottleOnly : 1; // 0x348(0x1), Mask(0x2)
	uint8_t BitPad_0x34C_2 : 6; // 0x34C(0x1)
	uint8_t Pad_0x34D[0x3]; // 0x34D(0x3)
	struct UAIBehaviorAdapter_VehicleBase* VehicleAdapter; // 0x350(0x8)
	bool bPathDebug; // 0x358(0x1)
	uint8_t Pad_0x359[0x17]; // 0x359(0x17)
};

// Object: Class AI.VehicleStateInfoCollector
// Size: 0x400 (Inherited: 0x58)
struct UVehicleStateInfoCollector : UStateInfoCollectorBase
{
	struct TMap<uint32_t, struct FVehicleAIStateInfo> LastAllPlayerStateInfoMap; // 0x58(0x50)
	struct TMap<uint32_t, struct FVehicleAIStateInfo> CurrentAllPlayerStateInfoMap; // 0xA8(0x50)
	struct TMap<uint32_t, struct FVehicleAIStateInfo> CacheAllPlayersInfo; // 0xF8(0x50)
	struct FDiffVehicleAllPlayersInfo CacheDiffAllPlayersInfoGeneral; // 0x148(0x108)
	struct FVehicleGlobalGameState CacheGlobalGameState; // 0x250(0x50)
	struct FVehicleGlobalGameState LastGlobalGameState; // 0x2A0(0x50)
	struct FDiffVehicleGlobalGameState DiffGlobalGameStateGeneral; // 0x2F0(0x78)
	struct TMap<uint64_t, struct FVehicleState> CacheVehicleStates; // 0x368(0x50)
	uint8_t Pad_0x3B8[0x48]; // 0x3B8(0x48)


	// Object: Function AI.VehicleStateInfoCollector.HandleGameModeStateChanged
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1047ef358
	// Params: [ Num(1) Size(0x10) ]
	void HandleGameModeStateChanged(struct FGameModeStateChangedParams& Params);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046D9C60
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x1047EF540
	// [Call #8] RVA: 0x101F8305C
	// [Call #9] RVA: 0x1046EF074
	// [Call #10] RVA: 0x106C8459C
};

