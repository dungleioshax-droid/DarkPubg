#pragma once

#include <cstdint>

// Object: ScriptStruct MediaCompositing.MediaPlaneParameters
// Size: 0x38 (Inherited: 0x0)
struct FMediaPlaneParameters
{
	struct UMaterialInterface* Material; // 0x0(0x8)
	struct FName TextureParameterName; // 0x8(0x8)
	bool bFillScreen; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	struct FVector2D FillScreenAmount; // 0x14(0x8)
	struct FVector2D FixedSize; // 0x1C(0x8)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct UTexture* RenderTexture; // 0x28(0x8)
	struct UMaterialInstanceDynamic* DynamicMaterial; // 0x30(0x8)
};

// Object: ScriptStruct MediaCompositing.MovieSceneMediaSectionTemplate
// Size: 0x48 (Inherited: 0x18)
struct FMovieSceneMediaSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieSceneMediaSectionParams Params; // 0x18(0x30)
};

// Object: ScriptStruct MediaCompositing.MovieSceneMediaSectionParams
// Size: 0x30 (Inherited: 0x0)
struct FMovieSceneMediaSectionParams
{
	struct UMediaSoundComponent* MediaSoundComponent; // 0x0(0x8)
	struct UMediaSource* MediaSource; // 0x8(0x8)
	struct UMediaTexture* MediaTexture; // 0x10(0x8)
	struct UMediaPlayer* MediaPlayer; // 0x18(0x8)
	float SectionStartTime; // 0x20(0x4)
	float SectionEndTime; // 0x24(0x4)
	bool bLooping; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float StartTimeOffset; // 0x2C(0x4)
};

// Object: Class MediaCompositing.MediaPlane
// Size: 0x4B8 (Inherited: 0x4B0)
struct AMediaPlane : AActor
{
	struct UMediaPlaneComponent* MediaPlane; // 0x4B0(0x8)
};

// Object: Class MediaCompositing.MediaPlaneComponent
// Size: 0xA90 (Inherited: 0x9D0)
struct UMediaPlaneComponent : UPrimitiveComponent
{
	struct FMediaPlaneParameters Plane; // 0x9C8(0x38)
	uint8_t Pad_0xA08[0x88]; // 0xA08(0x88)


	// Object: Function MediaCompositing.MediaPlaneComponent.SetMediaPlane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c2a52c
	// Params: [ Num(1) Size(0x38) ]
	void SetMediaPlane(struct FMediaPlaneParameters Plane);
	// [Call #1] RVA: 0x102C268B0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C26F5C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function MediaCompositing.MediaPlaneComponent.OnRenderTextureChanged
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2a518
	// Params: [ Num(0) Size(0x0) ]
	void OnRenderTextureChanged();
	// [Call #1] RVA: 0x102C268B0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C26F5C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function MediaCompositing.MediaPlaneComponent.GetPlane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c2a4e8
	// Params: [ Num(1) Size(0x38) ]
	struct FMediaPlaneParameters GetPlane();
	// [Call #1] RVA: 0x102C268B0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C26F5C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class MediaCompositing.MediaPlaneFrustumComponent
// Size: 0x9D0 (Inherited: 0x9D0)
struct UMediaPlaneFrustumComponent : UPrimitiveComponent
{
};

// Object: Class MediaCompositing.MovieSceneMediaSection
// Size: 0xE0 (Inherited: 0xB0)
struct UMovieSceneMediaSection : UMovieSceneSection
{
	struct UMediaSource* MediaSource; // 0xB0(0x8)
	bool bLooping; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x3]; // 0xB9(0x3)
	float StartTimeOffset; // 0xBC(0x4)
	struct UMediaTexture* MediaTexture; // 0xC0(0x8)
	struct UMediaSoundComponent* MediaSoundComponent; // 0xC8(0x8)
	bool bUseExternalMediaPlayer; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
	struct UMediaPlayer* ExternalMediaPlayer; // 0xD8(0x8)
};

// Object: Class MediaCompositing.MovieSceneMediaTrack
// Size: 0x80 (Inherited: 0x80)
struct UMovieSceneMediaTrack : UMovieScenePropertyTrack
{
};

