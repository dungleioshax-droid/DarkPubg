#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass LoadedClassManager_BP.LoadedClassManager_BP_C
// Size: 0x400 (Inherited: 0x3A8)
struct ULoadedClassManager_BP_C : UUAELoadedClassManager
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3A8(0x8)
	struct TMap<struct FString, struct FString> BPTableName2TableName; // 0x3B0(0x50)


	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadEffectItemBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadEffectItemBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadBPTableData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x20) ]
	void LoadBPTableData(struct FString BPTableName, struct FString tableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.Load3DIconBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void Load3DIconBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadInFillingBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadInFillingBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehiclePropsBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadVehiclePropsBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadDecalBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadDecalBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSkillPropsBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadSkillPropsBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPetAvatarBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadPetAvatarBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadVehilceRefitBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSeasonMissionBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadSeasonMissionBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarPatternBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadAvatarPatternBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarColorBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadAvatarColorBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehicleBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadVehicleBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPlaneBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadPlaneBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadEmoteBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadEmoteBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadConsumableBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadConsumableBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadGameModeBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadGameModeBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadAvatarBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadWeaponBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void LoadWeaponBPTable(struct FString BPTableName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitBPTableMap();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap_Mod
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitBPTableMap_Mod();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LoadedClassManager_BP.LoadedClassManager_BP_C.ExecuteUbergraph_LoadedClassManager_BP
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_LoadedClassManager_BP(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

