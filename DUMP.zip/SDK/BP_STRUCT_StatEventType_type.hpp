#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_StatEventType_type.BP_STRUCT_StatEventType_type
// Size: 0x14 (Inherited: 0x0)
struct FBP_STRUCT_StatEventType_type
{
	struct FString DisplayName_0_7D516B402CBFB7AB2A776EB00D8D1405; // 0x0(0x10)
	int id_1_49A788C0256E4AF90B9DAE5205E4F254; // 0x10(0x4)
};

