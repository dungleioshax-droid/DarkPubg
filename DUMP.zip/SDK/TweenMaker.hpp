#pragma once

#include <cstdint>

// Object: Enum TweenMaker.ETweenGenericType
enum class ETweenGenericType : uint8_t
{
	Any = 0,
	Move = 1,
	Scale = 2,
	Rotate = 3,
	RotateAroundPoint = 4,
	FollowSpline = 5,
	MaterialVector = 6,
	MaterialScalar = 7,
	WidgetAngle = 8,
	WidgetOpacity = 9,
	WidgetShear = 10,
	CustomVector = 11,
	CustomFloat = 12,
	CustomVector2D = 13,
	ETweenGenericType_MAX = 14
};

// Object: Enum TweenMaker.ETweenReferenceAxis
enum class ETweenReferenceAxis : uint8_t
{
	XAxis = 0,
	YAxis = 1,
	ZAxis = 2,
	ETweenReferenceAxis_MAX = 3
};

// Object: Enum TweenMaker.ETweenFloatType
enum class ETweenFloatType : uint8_t
{
	MaterialScalarFromTo = 0,
	MaterialScalarTo = 1,
	RotateAroundPoint = 2,
	FollowSpline = 3,
	WidgetAngleTo = 4,
	WidgetOpacityTo = 5,
	Custom = 6,
	ETweenFloatType_MAX = 7
};

// Object: Enum TweenMaker.ETweenLinearColorType
enum class ETweenLinearColorType : uint8_t
{
	MaterialVectorFromTo = 0,
	MaterialVectorTo = 1,
	ETweenLinearColorType_MAX = 2
};

// Object: Enum TweenMaker.ETweenRotatorType
enum class ETweenRotatorType : uint8_t
{
	RotateTo = 0,
	RotateBy = 1,
	ETweenRotatorType_MAX = 2
};

// Object: Enum TweenMaker.ETweenVector2DType
enum class ETweenVector2DType : uint8_t
{
	MoveTo = 0,
	MoveBy = 1,
	ScaleTo = 2,
	ScaleBy = 3,
	ShearTo = 4,
	Custom = 5,
	ETweenVector2DType_MAX = 6
};

// Object: Enum TweenMaker.ETweenVectorType
enum class ETweenVectorType : uint8_t
{
	MoveTo = 0,
	MoveBy = 1,
	ScaleTo = 2,
	ScaleBy = 3,
	Custom = 4,
	ETweenVectorType_MAX = 5
};

// Object: Enum TweenMaker.ETweenTargetType
enum class ETweenTargetType : uint8_t
{
	Actor = 0,
	SceneComponent = 1,
	UMG = 2,
	Material = 3,
	Custom = 4,
	ETweenTargetType_MAX = 5
};

// Object: Enum TweenMaker.ETweenLoopType
enum class ETweenLoopType : uint8_t
{
	Yoyo = 0,
	Restart = 1,
	ETweenLoopType_MAX = 2
};

// Object: Enum TweenMaker.ETweenEaseType
enum class ETweenEaseType : uint8_t
{
	Linear = 0,
	EaseInQuad = 1,
	EaseOutQuad = 2,
	EaseInOutQuad = 3,
	EaseOutInQuad = 4,
	EaseInCubic = 5,
	EaseOutCubic = 6,
	EaseInOutCubic = 7,
	EaseOutInCubic = 8,
	EaseInQuart = 9,
	EaseOutQuart = 10,
	EaseInOutQuart = 11,
	EaseOutInQuart = 12,
	EaseInQuint = 13,
	EaseOutQuint = 14,
	EaseInOutQuint = 15,
	EaseOutInQuint = 16,
	EaseInSine = 17,
	EaseOutSine = 18,
	EaseInOutSine = 19,
	EaseOutInSine = 20,
	EaseInExpo = 21,
	EaseOutExpo = 22,
	EaseInOutExpo = 23,
	EaseOutInExpo = 24,
	EaseInCirc = 25,
	EaseOutCirc = 26,
	EaseInOutCirc = 27,
	EaseOutInCirc = 28,
	EaseInElastic = 29,
	EaseOutElastic = 30,
	EaseInOutElastic = 31,
	EaseOutInElastic = 32,
	EaseInBack = 33,
	EaseOutBack = 34,
	EaseInOutBack = 35,
	EaseOutInBack = 36,
	EaseInBounce = 37,
	EaseOutBounce = 38,
	EaseInOutBounce = 39,
	EaseOutInBounce = 40,
	ETweenEaseType_MAX = 41
};

// Object: ScriptStruct TweenMaker.ParallelTween
// Size: 0x20 (Inherited: 0x0)
struct FParallelTween
{
	struct TArray<struct UBaseTween*> ParallelTweens; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct TweenMaker.DistSquaredToTickInterval
// Size: 0x8 (Inherited: 0x0)
struct FDistSquaredToTickInterval
{
	float DistSquared; // 0x0(0x4)
	float TickInterval; // 0x4(0x4)
};

// Object: Class TweenMaker.BaseTween
// Size: 0x98 (Inherited: 0x28)
struct UBaseTween : UObject
{
	uint8_t Pad_0x28[0x30]; // 0x28(0x30)
	struct UTweenContainer* mOwningTweenContainer; // 0x58(0x8)
	uint8_t Pad_0x60[0x38]; // 0x60(0x38)


	// Object: Function TweenMaker.BaseTween.TogglePauseTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102023a94
	// Params: [ Num(1) Size(0x1) ]
	void TogglePauseTween(bool SkipTween);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200D044
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function TweenMaker.BaseTween.SetTweenName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102023a18
	// Params: [ Num(1) Size(0x8) ]
	void SetTweenName(struct FName TweenName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200CFB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200D044
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function TweenMaker.BaseTween.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10202399c
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float NewTimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200D088
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200CFB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200D044
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function TweenMaker.BaseTween.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102023920
	// Params: [ Num(1) Size(0x4) ]
	void SetDelay(float NewDelay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200D080
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200D088
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200CFB8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10200D044
	// [Call #13] RVA: 0x10519022C

	// Object: Function TweenMaker.BaseTween.ResumeTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10202390c
	// Params: [ Num(0) Size(0x0) ]
	void ResumeTween();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200D080
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200D088
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200CFB8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10200D044
	// [Call #13] RVA: 0x10519022C

	// Object: Function TweenMaker.BaseTween.PauseTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102023888
	// Params: [ Num(1) Size(0x1) ]
	void PauseTween(bool SkipTween);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200D02C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200D080
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200D088
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10200CFB8
	// [Call #13] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenWidgetOpacityTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020236c4
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenFloat* JoinTweenWidgetOpacityTo(struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D584
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10200D02C

	// Object: Function TweenMaker.BaseTween.JoinTweenWidgetAngleTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102023500
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenFloat* JoinTweenWidgetAngleTo(struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D578
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenShearWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202333c
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenVector2D* JoinTweenShearWidgetTo(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D5CC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102023004
	// Params: [ Num(12) Size(0x30) ]
	struct UTweenFloat* JoinTweenSceneComponentFollowSpline(struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102022e40
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenVector2D* JoinTweenScaleWidgetTo(struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D5B4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102022c7c
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenVector2D* JoinTweenScaleWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D5C0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102022a24
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenScaleSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D414

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020227cc
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenScaleSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D420

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102022574
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenScaleActorTo(struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3E4

	// Object: Function TweenMaker.BaseTween.JoinTweenScaleActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202231c
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenScaleActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3F0

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020220c4
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenRotator* JoinTweenRotateSceneComponentTo(struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D458

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102021e6c
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenRotator* JoinTweenRotateSceneComponentBy(struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D464

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102021b9c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenFloat* JoinTweenRotateSceneComponentAroundPointByOffset(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102021850
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloat* JoinTweenRotateSceneComponentAroundPoint(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020215f8
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenRotator* JoinTweenRotateActorTo(struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D440

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020213a0
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenRotator* JoinTweenRotateActorBy(struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D44C

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020210d0
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenFloat* JoinTweenRotateActorAroundPointByOffset(struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenRotateActorAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102020d84
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloat* JoinTweenRotateActorAroundPoint(struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102020bc0
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenVector2D* JoinTweenMoveWidgetTo(struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D59C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020209fc
	// Params: [ Num(7) Size(0x28) ]
	struct UTweenVector2D* JoinTweenMoveWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200D5A8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020207a4
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenMoveSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3FC

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202054c
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenMoveSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D408

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020202f4
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenMoveActorTo(struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3CC

	// Object: Function TweenMaker.BaseTween.JoinTweenMoveActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202009c
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector* JoinTweenMoveActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3D8

	// Object: Function TweenMaker.BaseTween.JoinTweenMaterialVectorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201fe98
	// Params: [ Num(8) Size(0x38) ]
	struct UTweenLinearColor* JoinTweenMaterialVectorTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200D48C
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenMaterialVectorFromTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201fc50
	// Params: [ Num(9) Size(0x48) ]
	struct UTweenLinearColor* JoinTweenMaterialVectorFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D470

	// Object: Function TweenMaker.BaseTween.JoinTweenMaterialFloatTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201fa50
	// Params: [ Num(8) Size(0x30) ]
	struct UTweenFloat* JoinTweenMaterialFloatTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200D4A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenMaterialFloatFromTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201f814
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenFloat* JoinTweenMaterialFloatFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D498

	// Object: Function TweenMaker.BaseTween.JoinTweenCustomVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201f618
	// Params: [ Num(8) Size(0x30) ]
	struct UTweenVector2D* JoinTweenCustomVector2D(struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200D5D8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.JoinTweenCustomVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201f410
	// Params: [ Num(8) Size(0x38) ]
	struct UTweenVector* JoinTweenCustomVector(struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200D42C
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenCustomFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201f210
	// Params: [ Num(8) Size(0x28) ]
	struct UTweenFloat* JoinTweenCustomFloat(struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200D590
	// [Call #16] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.JoinTweenActorFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201eed8
	// Params: [ Num(12) Size(0x30) ]
	struct UTweenFloat* JoinTweenActorFollowSpline(struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.IsTweenPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201eebc
	// Params: [ Num(1) Size(0x1) ]
	bool IsTweenPaused();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.IsTweening
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201ee88
	// Params: [ Num(1) Size(0x1) ]
	bool IsTweening();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.GetTweenTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201ee50
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetTweenTarget();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.GetTweenName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201ee34
	// Params: [ Num(1) Size(0x8) ]
	struct FName GetTweenName();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.GetTweenElapsedTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201ee18
	// Params: [ Num(1) Size(0x4) ]
	float GetTweenElapsedTime();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.GetTweenDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201edfc
	// Params: [ Num(1) Size(0x4) ]
	float GetTweenDuration();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.GetTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201ede0
	// Params: [ Num(1) Size(0x8) ]
	struct UTweenContainer* GetTweenContainer();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10201edc4
	// Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.DeleteTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10201edb0
	// Params: [ Num(0) Size(0x0) ]
	void DeleteTween();
	// [Call #1] RVA: 0x1051A2A1C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenWidgetOpacityTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201eb74
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenFloat* AppendTweenWidgetOpacityTo(struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D34C

	// Object: Function TweenMaker.BaseTween.AppendTweenWidgetAngleTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201e938
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenFloat* AppendTweenWidgetAngleTo(struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D33C

	// Object: Function TweenMaker.BaseTween.AppendTweenShearWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201e6fc
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector2D* AppendTweenShearWidgetTo(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D3AC

	// Object: Function TweenMaker.BaseTween.AppendTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201e344
	// Params: [ Num(14) Size(0x38) ]
	struct UTweenFloat* AppendTweenSceneComponentFollowSpline(struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201e108
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector2D* AppendTweenScaleWidgetTo(struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D38C

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201decc
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector2D* AppendTweenScaleWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D39C

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201dbfc
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenScaleSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201d92c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenScaleSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201d65c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenScaleActorTo(struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenScaleActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201d38c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenScaleActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201d0bc
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* AppendTweenRotateSceneComponentTo(struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201cdec
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* AppendTweenRotateSceneComponentBy(struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201caa4
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenFloat* AppendTweenRotateSceneComponentAroundPointByOffset(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201c6e0
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloat* AppendTweenRotateSceneComponentAroundPoint(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201c410
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* AppendTweenRotateActorTo(struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201c140
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* AppendTweenRotateActorBy(struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201bdf8
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenFloat* AppendTweenRotateActorAroundPointByOffset(struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenRotateActorAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201ba34
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloat* AppendTweenRotateActorAroundPoint(struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201b7f8
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector2D* AppendTweenMoveWidgetTo(struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D36C

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201b5bc
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenVector2D* AppendTweenMoveWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200D37C

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201b2ec
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenMoveSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201b01c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenMoveSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201ad4c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenMoveActorTo(struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenMoveActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201aa7c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* AppendTweenMoveActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.BaseTween.AppendTweenMaterialVectorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201a800
	// Params: [ Num(10) Size(0x40) ]
	struct UTweenLinearColor* AppendTweenMaterialVectorTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenMaterialVectorFromTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10201a540
	// Params: [ Num(11) Size(0x50) ]
	struct UTweenLinearColor* AppendTweenMaterialVectorFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenMaterialFloatTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201a2c8
	// Params: [ Num(10) Size(0x38) ]
	struct UTweenFloat* AppendTweenMaterialFloatTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenMaterialFloatFromTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10201a014
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenFloat* AppendTweenMaterialFloatFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenCustomVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102019da0
	// Params: [ Num(10) Size(0x38) ]
	struct UTweenVector2D* AppendTweenCustomVector2D(struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenCustomVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102019b20
	// Params: [ Num(10) Size(0x40) ]
	struct UTweenVector* AppendTweenCustomVector(struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenCustomFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020198a8
	// Params: [ Num(10) Size(0x30) ]
	struct UTweenFloat* AppendTweenCustomFloat(struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, int mNumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.BaseTween.AppendTweenActorFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020194f0
	// Params: [ Num(14) Size(0x38) ]
	struct UTweenFloat* AppendTweenActorFollowSpline(struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t mLoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenContainer
// Size: 0x68 (Inherited: 0x28)
struct UTweenContainer : UObject
{
	struct UTweenManagerComponent* OwningTweenManager; // 0x28(0x8)
	struct TArray<struct FParallelTween> mSequences; // 0x30(0x10)
	uint8_t Pad_0x40[0x28]; // 0x40(0x28)


	// Object: Function TweenMaker.TweenContainer.TogglePauseTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025c14
	// Params: [ Num(0) Size(0x0) ]
	void TogglePauseTweenContainer();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x1051903D0
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenContainer.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025b98
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float NewTimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102000788
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x1051903D0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenContainer.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025ae0
	// Params: [ Num(2) Size(0x5) ]
	void SetLoop(int NumLoops, uint8_t LoopType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020007E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102000788
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x1051903D0

	// Object: Function TweenMaker.TweenContainer.ResumeTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025acc
	// Params: [ Num(0) Size(0x0) ]
	void ResumeTweenContainer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020007E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102000788
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenContainer.PauseTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025ab8
	// Params: [ Num(0) Size(0x0) ]
	void PauseTweenContainer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020007E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102000788
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenContainer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102025a84
	// Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
	// [Call #1] RVA: 0x1020009F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020007E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102000788
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function TweenMaker.TweenContainer.IsObjectTweeningInContainer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202595c
	// Params: [ Num(4) Size(0x19) ]
	bool IsObjectTweeningInContainer(struct UObject*& TweenTarget, uint8_t TweensType, struct UBaseTween*& TweenFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102000918
	// [Call #8] RVA: 0x1020009F0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020007E0

	// Object: Function TweenMaker.TweenContainer.DeleteTweensInContainerByObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102025888
	// Params: [ Num(2) Size(0x9) ]
	void DeleteTweensInContainerByObject(struct UObject*& TweenTarget, uint8_t TweensType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10200081C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102000918
	// [Call #13] RVA: 0x1020009F0

	// Object: Function TweenMaker.TweenContainer.DeleteTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102025874
	// Params: [ Num(0) Size(0x0) ]
	void DeleteTweenContainer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10200081C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102000918
	// [Call #13] RVA: 0x1020009F0
};

// Object: Class TweenMaker.TweenFloat
// Size: 0x1E8 (Inherited: 0x98)
struct UTweenFloat : UBaseTween
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x98(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0xA8(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0xB8(0x10)
	struct FScriptMulticastDelegate OnTweenActorHit; // 0xC8(0x10)
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // 0xD8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // 0xE8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // 0xF8(0x10)
	uint8_t Pad_0x108[0xE0]; // 0x108(0xE0)


	// Object: Function TweenMaker.TweenFloat.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x1020268fc
	// Params: [ Num(5) Size(0xB0) ]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102011EC8
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenFloat.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x102026728
	// Params: [ Num(6) Size(0xA8) ]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102011D08
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloat.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x1020265dc
	// Params: [ Num(4) Size(0xA8) ]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102011B24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloat.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	// Offset: 0x102026528
	// Params: [ Num(2) Size(0x10) ]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102011988
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102011B24
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloat.GetCurrentValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10202650c
	// Params: [ Num(1) Size(0x4) ]
	float GetCurrentValue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102011988
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102011B24
	// [Call #16] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenFloatLatentFactory
// Size: 0x58 (Inherited: 0x28)
struct UTweenFloatLatentFactory : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x28(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0x38(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0x48(0x10)


	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202e0ec
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102004400

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202de8c
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102004360

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202dabc
	// Params: [ Num(14) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202d750
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202d368
	// Params: [ Num(15) Size(0x58) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202cffc
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202cc14
	// Params: [ Num(15) Size(0x58) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202c978
	// Params: [ Num(10) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202c6a0
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202c404
	// Params: [ Num(10) Size(0x38) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202c034
	// Params: [ Num(14) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202bd24
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenWidgetOpacityTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202ba14
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenWidgetAngleTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202b588
	// Params: [ Num(17) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenSceneComponentFollowSpline(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202b164
	// Params: [ Num(16) Size(0x58) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202acc8
	// Params: [ Num(18) Size(0x68) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateSceneComponentAroundPoint(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202a8a4
	// Params: [ Num(16) Size(0x58) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateActorAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10202a408
	// Params: [ Num(18) Size(0x68) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateActorAroundPoint(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202a0bc
	// Params: [ Num(13) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenMaterialFloatTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FName ParameterName, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102029d34
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenMaterialFloatFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020299e8
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenCustomFloat(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202955c
	// Params: [ Num(17) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenActorFollowSpline(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102029284
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102028fac
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102028b5c
	// Params: [ Num(16) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102028774
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102028314
	// Params: [ Num(17) Size(0x60) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102027f2c
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102027acc
	// Params: [ Num(17) Size(0x60) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020277b8
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102027468
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102027154
	// Params: [ Num(12) Size(0x40) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102026d04
	// Params: [ Num(16) Size(0x48) ]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenFloatStandardFactory
// Size: 0x28 (Inherited: 0x28)
struct UTweenFloatStandardFactory : UObject
{

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102036e20
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenFloat* BP_JoinTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102002298

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102036bd8
	// Params: [ Num(9) Size(0x30) ]
	struct UTweenFloat* BP_JoinTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020021F8

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102036818
	// Params: [ Num(14) Size(0x38) ]
	struct UTweenFloat* BP_JoinTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020364c4
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenFloat* BP_JoinTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020360f4
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloat* BP_JoinTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102035da0
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenFloat* BP_JoinTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020359d0
	// Params: [ Num(15) Size(0x50) ]
	struct UTweenFloat* BP_JoinTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203574c
	// Params: [ Num(10) Size(0x38) ]
	struct UTweenFloat* BP_JoinTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203548c
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenFloat* BP_JoinTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102035208
	// Params: [ Num(10) Size(0x38) ]
	struct UTweenFloat* BP_JoinTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102034e48
	// Params: [ Num(14) Size(0x38) ]
	struct UTweenFloat* BP_JoinTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102034b0c
	// Params: [ Num(12) Size(0x40) ]
	void BP_CreateTweenWidgetOpacityTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020347d0
	// Params: [ Num(12) Size(0x40) ]
	void BP_CreateTweenWidgetAngleTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020342c8
	// Params: [ Num(18) Size(0x49) ]
	void BP_CreateTweenSceneComponentFollowSpline(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102033e30
	// Params: [ Num(17) Size(0x51) ]
	void BP_CreateTweenRotateSceneComponentAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203391c
	// Params: [ Num(19) Size(0x61) ]
	void BP_CreateTweenRotateSceneComponentAroundPoint(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102033484
	// Params: [ Num(17) Size(0x51) ]
	void BP_CreateTweenRotateActorAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102032f70
	// Params: [ Num(19) Size(0x61) ]
	void BP_CreateTweenRotateActorAroundPoint(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102032bf4
	// Params: [ Num(13) Size(0x48) ]
	void BP_CreateTweenMaterialFloatTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FName ParameterName, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203283c
	// Params: [ Num(14) Size(0x4C) ]
	void BP_CreateTweenMaterialFloatFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020324c4
	// Params: [ Num(13) Size(0x44) ]
	void BP_CreateTweenCustomFloat(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102031fbc
	// Params: [ Num(18) Size(0x49) ]
	void BP_CreateTweenActorFollowSpline(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102031cfc
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenFloat* BP_AppendTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102031a3c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenFloat* BP_AppendTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020315fc
	// Params: [ Num(16) Size(0x40) ]
	struct UTweenFloat* BP_AppendTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203122c
	// Params: [ Num(15) Size(0x48) ]
	struct UTweenFloat* BP_AppendTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102030de4
	// Params: [ Num(17) Size(0x58) ]
	struct UTweenFloat* BP_AppendTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102030a14
	// Params: [ Num(15) Size(0x48) ]
	struct UTweenFloat* BP_AppendTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, uint8_t ReferenceAxis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020305cc
	// Params: [ Num(17) Size(0x58) ]
	struct UTweenFloat* BP_AppendTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1020302d0
	// Params: [ Num(12) Size(0x40) ]
	struct UTweenFloat* BP_AppendTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202ff98
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenFloat* BP_AppendTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202fc9c
	// Params: [ Num(12) Size(0x40) ]
	struct UTweenFloat* BP_AppendTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, float From, float To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10202f85c
	// Params: [ Num(16) Size(0x40) ]
	struct UTweenFloat* BP_AppendTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenLinearColor
// Size: 0x168 (Inherited: 0x98)
struct UTweenLinearColor : UBaseTween
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x98(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0xA8(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0xB8(0x10)
	uint8_t Pad_0xC8[0xA0]; // 0xC8(0xA0)


	// Object: Function TweenMaker.TweenLinearColor.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102037d10
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetCurrentValue();
	// [Call #1] RVA: 0x10203941C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102039368
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenLinearColorLatentFactory
// Size: 0x58 (Inherited: 0x28)
struct UTweenLinearColorLatentFactory : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x28(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0x38(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0x48(0x10)


	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_JoinLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102038ee8
	// Params: [ Num(10) Size(0x48) ]
	struct UTweenLinearColorLatentFactory* BP_JoinLatentTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_JoinLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102038c04
	// Params: [ Num(11) Size(0x58) ]
	struct UTweenLinearColorLatentFactory* BP_JoinLatentTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_CreateLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020388b4
	// Params: [ Num(13) Size(0x58) ]
	struct UTweenLinearColorLatentFactory* BP_CreateLatentTweenMaterialVectorTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenLinearColor*& OutTween, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_CreateLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102038520
	// Params: [ Num(14) Size(0x68) ]
	struct UTweenLinearColorLatentFactory* BP_CreateLatentTweenMaterialVectorFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenLinearColor*& OutTween, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_AppendLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102038208
	// Params: [ Num(12) Size(0x50) ]
	struct UTweenLinearColorLatentFactory* BP_AppendLatentTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenLinearColorLatentFactory.BP_AppendLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102037eac
	// Params: [ Num(13) Size(0x60) ]
	struct UTweenLinearColorLatentFactory* BP_AppendLatentTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenLinearColorStandardFactory
// Size: 0x28 (Inherited: 0x28)
struct UTweenLinearColorStandardFactory : UObject
{

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_JoinTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203a85c
	// Params: [ Num(10) Size(0x48) ]
	struct UTweenLinearColor* BP_JoinTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_JoinTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203a590
	// Params: [ Num(11) Size(0x58) ]
	struct UTweenLinearColor* BP_JoinTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_CreateTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203a210
	// Params: [ Num(13) Size(0x54) ]
	void BP_CreateTweenMaterialVectorTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& Tween, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_CreateTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102039e4c
	// Params: [ Num(14) Size(0x64) ]
	void BP_CreateTweenMaterialVectorFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& Tween, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_AppendTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102039b4c
	// Params: [ Num(12) Size(0x50) ]
	struct UTweenLinearColor* BP_AppendTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenLinearColorStandardFactory.BP_AppendTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102039808
	// Params: [ Num(13) Size(0x60) ]
	struct UTweenLinearColor* BP_AppendTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor From, struct FLinearColor To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenManagerActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct ATweenManagerActor : AActor
{

	// Object: Function TweenMaker.TweenManagerActor.IsObjectTweening
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203b5a0
	// Params: [ Num(4) Size(0x19) ]
	bool IsObjectTweening(struct UObject*& TweenTarget, uint8_t TweensType, struct UBaseTween*& TweenFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10200B7FC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenManagerActor.FindTweenByName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203b49c
	// Params: [ Num(4) Size(0x19) ]
	bool FindTweenByName(struct FName TweenName, uint8_t TweenType, struct UBaseTween*& TweenFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10200B988
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10200B7FC
	// [Call #15] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenManagerActor.DeleteAllTweensByObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203b3c8
	// Params: [ Num(3) Size(0xA) ]
	bool DeleteAllTweensByObject(struct UObject*& TweenTarget, uint8_t TweensType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10200B544
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10200B988
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenManagerActor.DeleteAllTweens
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10203b394
	// Params: [ Num(1) Size(0x4) ]
	int DeleteAllTweens();
	// [Call #1] RVA: 0x10200B4C8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200B544
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200B988
	// [Call #14] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenManagerActor.BP_CreateTweenContainerStatic
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203b25c
	// Params: [ Num(4) Size(0x14) ]
	void BP_CreateTweenContainerStatic(struct UTweenContainer*& TweenContainer, int NumLoops, uint8_t LoopType, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200B470
	// [Call #10] RVA: 0x10200B4C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200B544
};

// Object: Class TweenMaker.TweenManagerComponent
// Size: 0x288 (Inherited: 0x178)
struct UTweenManagerComponent : UActorComponent
{
	struct TArray<struct FDistSquaredToTickInterval> ConfigTickLODInfo; // 0x178(0x10)
	struct TArray<struct UTweenContainer*> mTweenContainers; // 0x188(0x10)
	uint8_t Pad_0x198[0xF0]; // 0x198(0xF0)


	// Object: Function TweenMaker.TweenManagerComponent.UpdateNameMap
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x10203bf2c
	// Params: [ Num(3) Size(0x18) ]
	void UpdateNameMap(struct UBaseTween* pTween, struct FName& pPreviousName, struct FName& pNewName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10200C9A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenManagerComponent.TweenDestroyed
	// Flags: [Final|Native|Private]
	// Offset: 0x10203beb0
	// Params: [ Num(1) Size(0x8) ]
	void TweenDestroyed(struct UBaseTween* pTween);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10200CB24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10200C9A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenManagerComponent.IsObjectTweening
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203bd88
	// Params: [ Num(4) Size(0x19) ]
	bool IsObjectTweening(struct UObject*& TweenTarget, uint8_t TweensType, struct UBaseTween*& TweenFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10200B850
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10200CB24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenManagerComponent.FindTweenByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203bc74
	// Params: [ Num(4) Size(0x19) ]
	bool FindTweenByName(struct FName TweenName, uint8_t TweenType, struct UBaseTween*& TweenFound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10200B9DC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10200B850

	// Object: Function TweenMaker.TweenManagerComponent.DeleteAllTweensByObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203bb98
	// Params: [ Num(3) Size(0xA) ]
	bool DeleteAllTweensByObject(struct UObject*& TweenTarget, uint8_t TweensType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10200B580
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10200B9DC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenManagerComponent.DeleteAllTweens
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10203bb64
	// Params: [ Num(1) Size(0x4) ]
	int DeleteAllTweens();
	// [Call #1] RVA: 0x10200B4E8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10200B580
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10200B9DC

	// Object: Function TweenMaker.TweenManagerComponent.BP_CreateTweenContainer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10203ba1c
	// Params: [ Num(4) Size(0x14) ]
	void BP_CreateTweenContainer(struct UTweenContainer*& TweenContainer, int NumLoops, uint8_t LoopType, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10200C17C
	// [Call #10] RVA: 0x10200B4E8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10200B580
};

// Object: Class TweenMaker.TweenRotator
// Size: 0x200 (Inherited: 0x98)
struct UTweenRotator : UBaseTween
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x98(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0xA8(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0xB8(0x10)
	struct FScriptMulticastDelegate OnTweenActorHit; // 0xC8(0x10)
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // 0xD8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // 0xE8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // 0xF8(0x10)
	uint8_t Pad_0x108[0xF8]; // 0x108(0xF8)


	// Object: Function TweenMaker.TweenRotator.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x10203c778
	// Params: [ Num(5) Size(0xB0) ]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020145FC
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenRotator.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x10203c5a4
	// Params: [ Num(6) Size(0xA8) ]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020144AC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotator.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x10203c458
	// Params: [ Num(4) Size(0xA8) ]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102014338
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenRotator.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	// Offset: 0x10203c3a4
	// Params: [ Num(2) Size(0x10) ]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10201420C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102014338
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenRotator.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10203c368
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetCurrentValue();
	// [Call #1] RVA: 0x104F4AACC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10201420C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C8CD38
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102014338
};

// Object: Class TweenMaker.TweenRotatorLatentFactory
// Size: 0x58 (Inherited: 0x28)
struct UTweenRotatorLatentFactory : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x28(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0x38(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0x48(0x10)


	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203f0a8
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203edb4
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203eac0
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203e7cc
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203e424
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203e07c
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203dcd4
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203d92c
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203d5c0
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203d254
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203cee8
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203cb7c
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenRotatorStandardFactory
// Size: 0x28 (Inherited: 0x28)
struct UTweenRotatorStandardFactory : UObject
{

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102041f70
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* BP_JoinTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102041c94
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* BP_JoinTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020419b8
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* BP_JoinTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020416dc
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenRotator* BP_JoinTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020412bc
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenRotateSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102040e9c
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenRotateSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102040a7c
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenRotateActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204065c
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenRotateActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102040308
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenRotator* BP_AppendTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203ffb4
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenRotator* BP_AppendTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203fc60
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenRotator* BP_AppendTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10203f90c
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenRotator* BP_AppendTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenVector
// Size: 0x1C0 (Inherited: 0x98)
struct UTweenVector : UBaseTween
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x98(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0xA8(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0xB8(0x10)
	struct FScriptMulticastDelegate OnTweenActorHit; // 0xC8(0x10)
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // 0xD8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // 0xE8(0x10)
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // 0xF8(0x10)
	uint8_t Pad_0x108[0xB8]; // 0x108(0xB8)


	// Object: Function TweenMaker.TweenVector.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x102043324
	// Params: [ Num(5) Size(0xB0) ]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102015E34
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C

	// Object: Function TweenMaker.TweenVector.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x102043150
	// Params: [ Num(6) Size(0xA8) ]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102015CE4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x102043004
	// Params: [ Num(4) Size(0xA8) ]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102015B70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	// Offset: 0x102042f50
	// Params: [ Num(2) Size(0x10) ]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102015A44
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102015B70
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102042f2c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetCurrentValue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102015A44
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102015B70
};

// Object: Class TweenMaker.TweenVector2D
// Size: 0x128 (Inherited: 0x98)
struct UTweenVector2D : UBaseTween
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x98(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0xA8(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0xB8(0x10)
	uint8_t Pad_0xC8[0x60]; // 0xC8(0x60)


	// Object: Function TweenMaker.TweenVector2D.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10204372c
	// Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetCurrentValue();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102047014
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenVector2DLatentFactory
// Size: 0x58 (Inherited: 0x28)
struct UTweenVector2DLatentFactory : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x28(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0x38(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0x48(0x10)


	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020468a4
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102006D68

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102046644
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102006CD8

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020463e4
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102006D20

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102046184
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102006ADC

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102045f24
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102006C90

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102045c8c
	// Params: [ Num(10) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204597c
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenShearWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204566c
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenScaleWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204535c
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenScaleWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204504c
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenMoveWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102044d3c
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenMoveWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020449f4
	// Params: [ Num(13) Size(0x50) ]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenCustomVector2D(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204471c
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102044444
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204416c
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102043e94
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102043bbc
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020438ac
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenVector2DStandardFactory
// Size: 0x28 (Inherited: 0x28)
struct UTweenVector2DStandardFactory : UObject
{

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204a0e4
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2D* BP_JoinTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102002514

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102049e9c
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2D* BP_JoinTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10200247C

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102049c54
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2D* BP_JoinTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020024C8

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102049a0c
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2D* BP_JoinTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1020023E4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020497c4
	// Params: [ Num(9) Size(0x38) ]
	struct UTweenVector2D* BP_JoinTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102002430

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102049544
	// Params: [ Num(10) Size(0x40) ]
	struct UTweenVector2D* BP_JoinTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102049208
	// Params: [ Num(12) Size(0x44) ]
	void BP_CreateTweenShearWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102048ecc
	// Params: [ Num(12) Size(0x44) ]
	void BP_CreateTweenScaleWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102048b90
	// Params: [ Num(12) Size(0x44) ]
	void BP_CreateTweenScaleWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102048854
	// Params: [ Num(12) Size(0x44) ]
	void BP_CreateTweenMoveWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102048518
	// Params: [ Num(12) Size(0x44) ]
	void BP_CreateTweenMoveWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020481a4
	// Params: [ Num(13) Size(0x4C) ]
	void BP_CreateTweenCustomVector2D(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102047ee4
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2D* BP_AppendTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102047c24
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2D* BP_AppendTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102047964
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2D* BP_AppendTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020476a4
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2D* BP_AppendTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020473e4
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVector2D* BP_AppendTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020470ec
	// Params: [ Num(12) Size(0x48) ]
	struct UTweenVector2D* BP_AppendTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector2D From, struct FVector2D To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class TweenMaker.TweenVectorLatentFactory
// Size: 0x58 (Inherited: 0x28)
struct UTweenVectorLatentFactory : UBlueprintAsyncActionBase
{
	struct FScriptMulticastDelegate OnTweenStart; // 0x28(0x10)
	struct FScriptMulticastDelegate OnTweenUpdate; // 0x38(0x10)
	struct FScriptMulticastDelegate OnTweenEnd; // 0x48(0x10)


	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204ff68
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204fc74
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204f980
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204f68c
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204f398
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204f0a4
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204edb0
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204eabc
	// Params: [ Num(11) Size(0x40) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204e818
	// Params: [ Num(10) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204e470
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204e0c8
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204dd20
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204d978
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204d5d0
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204d228
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204ce80
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204cad8
	// Params: [ Num(14) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204c784
	// Params: [ Num(13) Size(0x58) ]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenCustomVector(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204c418
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204c0ac
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204bd40
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204b9d4
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204b668
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204b2fc
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204af90
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204ac24
	// Params: [ Num(13) Size(0x48) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10204a908
	// Params: [ Num(12) Size(0x50) ]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class TweenMaker.TweenVectorStandardFactory
// Size: 0x28 (Inherited: 0x28)
struct UTweenVectorStandardFactory : UObject
{

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102056a90
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020567b4
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020564d8
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020561fc
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102055f20
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102055c44
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102055968
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10205568c
	// Params: [ Num(11) Size(0x38) ]
	struct UTweenVector* BP_JoinTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102055400
	// Params: [ Num(10) Size(0x48) ]
	struct UTweenVector* BP_JoinTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102054fe0
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenScaleSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102054bc0
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenScaleSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020547a0
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenScaleActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102054380
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenScaleActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102053f60
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenMoveSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102053b40
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenMoveSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102053720
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenMoveActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102053300
	// Params: [ Num(15) Size(0x49) ]
	void BP_CreateTweenMoveActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex, bool EnableTickLOD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102052f80
	// Params: [ Num(13) Size(0x54) ]
	void BP_CreateTweenCustomVector(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102052c2c
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020528d8
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102052584
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102052230
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102051edc
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102051b88
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102051834
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector To, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020514e0
	// Params: [ Num(13) Size(0x40) ]
	struct UTweenVector* BP_AppendTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, uint8_t EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1020511dc
	// Params: [ Num(12) Size(0x50) ]
	struct UTweenVector* BP_AppendTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector From, struct FVector To, float Duration, uint8_t EaseType, int NumLoops, uint8_t LoopType, float Delay, float TimeScale, int SequenceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

