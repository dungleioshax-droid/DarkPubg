#pragma once

#include <cstdint>

// Object: Enum MediaAssets.EMediaWebcamCaptureDeviceFilter
enum class EMediaWebcamCaptureDeviceFilter : uint8_t
{
	DepthSensor = 1,
	Front = 2,
	Rear = 4,
	Unknown = 8,
	EMediaWebcamCaptureDeviceFilter_MAX = 9
};

// Object: Enum MediaAssets.EMediaVideoCaptureDeviceFilter
enum class EMediaVideoCaptureDeviceFilter : uint8_t
{
	Card = 1,
	Software = 2,
	Unknown = 4,
	Webcam = 8,
	EMediaVideoCaptureDeviceFilter_MAX = 9
};

// Object: Enum MediaAssets.EMediaAudioCaptureDeviceFilter
enum class EMediaAudioCaptureDeviceFilter : uint8_t
{
	Card = 1,
	Microphone = 2,
	Software = 4,
	Unknown = 8,
	EMediaAudioCaptureDeviceFilter_MAX = 9
};

// Object: Enum MediaAssets.EMediaPlayerTrack
enum class EMediaPlayerTrack : uint8_t
{
	Audio = 0,
	Caption = 1,
	Metadata = 2,
	Script = 3,
	Subtitle = 4,
	Text = 5,
	Video = 6,
	EMediaPlayerTrack_MAX = 7
};

// Object: Enum MediaAssets.EMediaSoundChannels
enum class EMediaSoundChannels : uint8_t
{
	Mono = 0,
	Stereo = 1,
	Surround = 2,
	EMediaSoundChannels_MAX = 3
};

// Object: ScriptStruct MediaAssets.MediaCaptureDevice
// Size: 0x28 (Inherited: 0x0)
struct FMediaCaptureDevice
{
	struct FText DisplayName; // 0x0(0x18)
	struct FString URL; // 0x18(0x10)
};

// Object: Class MediaAssets.MediaSource
// Size: 0x30 (Inherited: 0x28)
struct UMediaSource : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)


	// Object: Function MediaAssets.MediaSource.Validate
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf2e84
	// Params: [ Num(1) Size(0x1) ]
	bool Validate();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x106BF31E4
	// [Call #5] RVA: 0x106BE8BB8
	// [Call #6] RVA: 0x106BE8BDC
	// [Call #7] RVA: 0x106BE8BE4

	// Object: Function MediaAssets.MediaSource.GetUrl
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf2e18
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x106BF31E4
	// [Call #9] RVA: 0x106BE8BB8
};

// Object: Class MediaAssets.BaseMediaSource
// Size: 0x38 (Inherited: 0x30)
struct UBaseMediaSource : UMediaSource
{
	struct FName PlayerName; // 0x30(0x8)
};

// Object: Class MediaAssets.FileMediaSource
// Size: 0x50 (Inherited: 0x38)
struct UFileMediaSource : UBaseMediaSource
{
	struct FString FilePath; // 0x38(0x10)
	bool PrecacheFile; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)


	// Object: Function MediaAssets.FileMediaSource.SetFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bee420
	// Params: [ Num(1) Size(0x10) ]
	void SetFilePath(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE6448
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
};

// Object: Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106beeb14
	// Params: [ Num(2) Size(0x14) ]
	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BEA324
	// [Call #6] RVA: 0x106BF36EC
	// [Call #7] RVA: 0x106BF36EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106beea30
	// Params: [ Num(2) Size(0x14) ]
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BEA1F0
	// [Call #6] RVA: 0x106BF36EC
	// [Call #7] RVA: 0x106BF36EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BEA324
	// [Call #14] RVA: 0x106BF36EC
	// [Call #15] RVA: 0x106BF36EC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bee94c
	// Params: [ Num(2) Size(0x14) ]
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BEA0BC
	// [Call #6] RVA: 0x106BF36EC
	// [Call #7] RVA: 0x106BF36EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BEA1F0
	// [Call #14] RVA: 0x106BF36EC
	// [Call #15] RVA: 0x106BF36EC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class MediaAssets.MediaPlayer
// Size: 0x138 (Inherited: 0x28)
struct UMediaPlayer : UObject
{
	struct FScriptMulticastDelegate OnEndReached; // 0x28(0x10)
	struct FScriptMulticastDelegate OnMediaClosed; // 0x38(0x10)
	struct FScriptMulticastDelegate OnMediaOpened; // 0x48(0x10)
	struct FScriptMulticastDelegate OnMediaOpenFailed; // 0x58(0x10)
	struct FScriptMulticastDelegate OnPlaybackResumed; // 0x68(0x10)
	struct FScriptMulticastDelegate OnPlaybackSuspended; // 0x78(0x10)
	struct FScriptMulticastDelegate OnSeekCompleted; // 0x88(0x10)
	struct FScriptMulticastDelegate OnTracksChanged; // 0x98(0x10)
	struct FScriptMulticastDelegate OnMediaPlayFirstFrame; // 0xA8(0x10)
	struct FTimespan CacheAhead; // 0xB8(0x8)
	struct FTimespan CacheBehind; // 0xC0(0x8)
	struct FTimespan CacheBehindGame; // 0xC8(0x8)
	bool NativeAudioOut; // 0xD0(0x1)
	bool PlayOnOpen; // 0xD1(0x1)
	uint8_t Shuffle : 1; // 0xD2(0x1), Mask(0x1)
	uint8_t Loop : 1; // 0xD2(0x1), Mask(0x2)
	uint8_t BitPad_0xD2_2 : 6; // 0xD2(0x1)
	uint8_t Pad_0xD3[0x5]; // 0xD3(0x5)
	struct UMediaPlaylist* Playlist; // 0xD8(0x8)
	int PlaylistIndex; // 0xE0(0x4)
	float HorizontalFieldOfView; // 0xE4(0x4)
	float VerticalFieldOfView; // 0xE8(0x4)
	struct FRotator ViewRotation; // 0xEC(0xC)
	uint8_t Pad_0xF8[0x28]; // 0xF8(0x28)
	struct FGuid PlayerGuid; // 0x120(0x10)
	uint8_t Pad_0x130[0x8]; // 0x130(0x8)


	// Object: Function MediaAssets.MediaPlayer.SupportsSeeking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf0ce8
	// Params: [ Num(1) Size(0x1) ]
	bool SupportsSeeking();
	// [Call #1] RVA: 0x106BE7C8C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlayer.SupportsScrubbing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf0cb4
	// Params: [ Num(1) Size(0x1) ]
	bool SupportsScrubbing();
	// [Call #1] RVA: 0x106BE7C84
	// [Call #2] RVA: 0x106BE7C8C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlayer.SupportsRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf0be4
	// Params: [ Num(3) Size(0x6) ]
	bool SupportsRate(float Rate, bool Unthinned);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7C7C
	// [Call #6] RVA: 0x106BE7C84
	// [Call #7] RVA: 0x106BE7C8C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlayer.SetViewRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x106bf0b08
	// Params: [ Num(3) Size(0xE) ]
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7C38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7C7C
	// [Call #11] RVA: 0x106BE7C84
	// [Call #12] RVA: 0x106BE7C8C
	// [Call #13] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlayer.SetViewField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0a00
	// Params: [ Num(4) Size(0xA) ]
	bool SetViewField(float Horizontal, float Vertical, bool Absolute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7C30
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7C38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0900
	// Params: [ Num(4) Size(0xD) ]
	bool SetVideoTrackFrameRate(int TrackIndex, int FormatIndex, float FrameRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7C28
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7C30
	// [Call #15] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.SetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0800
	// Params: [ Num(4) Size(0xD) ]
	bool SetTrackFormat(uint8_t TrackType, int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7C20
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7C28
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0774
	// Params: [ Num(2) Size(0x5) ]
	bool SetRate(float Rate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7C18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7C20
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf06e0
	// Params: [ Num(2) Size(0x2) ]
	bool SetLooping(bool Looping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7BF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7C18
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BE7C20

	// Object: Function MediaAssets.MediaPlayer.SetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0664
	// Params: [ Num(1) Size(0x8) ]
	void SetDesiredPlayerName(struct FName PlayerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7BE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7BF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7C18
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.SetCancelPending
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf05e0
	// Params: [ Num(1) Size(0x1) ]
	void SetCancelPending(bool flag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7C94
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7BE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7BF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7C18

	// Object: Function MediaAssets.MediaPlayer.SelectTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0518
	// Params: [ Num(3) Size(0x9) ]
	bool SelectTrack(uint8_t TrackType, int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7BE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7C94
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7BE8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7BF4

	// Object: Function MediaAssets.MediaPlayer.Seek
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x106bf0480
	// Params: [ Num(2) Size(0x9) ]
	bool Seek(struct FTimespan& Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7BD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7BE0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7C94
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7BE8

	// Object: Function MediaAssets.MediaPlayer.Rewind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf044c
	// Params: [ Num(1) Size(0x1) ]
	bool Rewind();
	// [Call #1] RVA: 0x106BE7BB4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE7BD8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7BE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7C94
	// [Call #13] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.Reopen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0418
	// Params: [ Num(1) Size(0x1) ]
	bool Reopen();
	// [Call #1] RVA: 0x106BE7B9C
	// [Call #2] RVA: 0x106BE7BB4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7BD8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7BE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BE7C94

	// Object: Function MediaAssets.MediaPlayer.Previous
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf03e4
	// Params: [ Num(1) Size(0x1) ]
	bool Previous();
	// [Call #1] RVA: 0x106BE7A64
	// [Call #2] RVA: 0x106BE7B9C
	// [Call #3] RVA: 0x106BE7BB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7BD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7BE0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf03b0
	// Params: [ Num(1) Size(0x1) ]
	bool Play();
	// [Call #1] RVA: 0x106BE7A58
	// [Call #2] RVA: 0x106BE7A64
	// [Call #3] RVA: 0x106BE7B9C
	// [Call #4] RVA: 0x106BE7BB4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7BD8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7BE0

	// Object: Function MediaAssets.MediaPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf037c
	// Params: [ Num(1) Size(0x1) ]
	bool Pause();
	// [Call #1] RVA: 0x106BE7A4C
	// [Call #2] RVA: 0x106BE7A58
	// [Call #3] RVA: 0x106BE7A64
	// [Call #4] RVA: 0x106BE7B9C
	// [Call #5] RVA: 0x106BE7BB4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7BD8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BE7BE0

	// Object: Function MediaAssets.MediaPlayer.OpenUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf02d4
	// Params: [ Num(2) Size(0x11) ]
	bool OpenUrl(struct FString URL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7910
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x106BE7A4C
	// [Call #8] RVA: 0x106BE7A58
	// [Call #9] RVA: 0x106BE7A64
	// [Call #10] RVA: 0x106BE7B9C
	// [Call #11] RVA: 0x106BE7BB4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7BD8

	// Object: Function MediaAssets.MediaPlayer.OpenSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0248
	// Params: [ Num(2) Size(0x9) ]
	bool OpenSource(struct UMediaSource* MediaSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7728
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7910
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BE7A4C
	// [Call #11] RVA: 0x106BE7A58
	// [Call #12] RVA: 0x106BE7A64
	// [Call #13] RVA: 0x106BE7B9C
	// [Call #14] RVA: 0x106BE7BB4

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0180
	// Params: [ Num(3) Size(0xD) ]
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE74D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7728
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7910
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BE7A4C
	// [Call #16] RVA: 0x106BE7A58

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf00f4
	// Params: [ Num(2) Size(0x9) ]
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF3738
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE74D8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7728
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7910

	// Object: Function MediaAssets.MediaPlayer.OpenFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf004c
	// Params: [ Num(2) Size(0x11) ]
	bool OpenFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7398
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BF3738
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE74D8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.Next
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf0018
	// Params: [ Num(1) Size(0x1) ]
	bool Next();
	// [Call #1] RVA: 0x106BE71F4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE7398
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BF3738
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE74D8

	// Object: Function MediaAssets.MediaPlayer.IsReady
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beffe4
	// Params: [ Num(1) Size(0x1) ]
	bool IsReady();
	// [Call #1] RVA: 0x106BE71EC
	// [Call #2] RVA: 0x106BE71F4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7398
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BF3738
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BE74D8

	// Object: Function MediaAssets.MediaPlayer.IsPreparing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beffb0
	// Params: [ Num(1) Size(0x1) ]
	bool IsPreparing();
	// [Call #1] RVA: 0x106BE71E4
	// [Call #2] RVA: 0x106BE71EC
	// [Call #3] RVA: 0x106BE71F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7398
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BF3738
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beff7c
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x106BE71DC
	// [Call #2] RVA: 0x106BE71E4
	// [Call #3] RVA: 0x106BE71EC
	// [Call #4] RVA: 0x106BE71F4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7398
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BF3738
	// [Call #14] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beff48
	// Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
	// [Call #1] RVA: 0x106BE71D4
	// [Call #2] RVA: 0x106BE71DC
	// [Call #3] RVA: 0x106BE71E4
	// [Call #4] RVA: 0x106BE71EC
	// [Call #5] RVA: 0x106BE71F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7398
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BF3738

	// Object: Function MediaAssets.MediaPlayer.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beff14
	// Params: [ Num(1) Size(0x1) ]
	bool IsLooping();
	// [Call #1] RVA: 0x106BE71CC
	// [Call #2] RVA: 0x106BE71D4
	// [Call #3] RVA: 0x106BE71DC
	// [Call #4] RVA: 0x106BE71E4
	// [Call #5] RVA: 0x106BE71EC
	// [Call #6] RVA: 0x106BE71F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7398
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BF3738

	// Object: Function MediaAssets.MediaPlayer.IsConnecting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befee0
	// Params: [ Num(1) Size(0x1) ]
	bool IsConnecting();
	// [Call #1] RVA: 0x106BE71C4
	// [Call #2] RVA: 0x106BE71CC
	// [Call #3] RVA: 0x106BE71D4
	// [Call #4] RVA: 0x106BE71DC
	// [Call #5] RVA: 0x106BE71E4
	// [Call #6] RVA: 0x106BE71EC
	// [Call #7] RVA: 0x106BE71F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7398
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.IsBuffering
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befeac
	// Params: [ Num(1) Size(0x1) ]
	bool IsBuffering();
	// [Call #1] RVA: 0x106BE71BC
	// [Call #2] RVA: 0x106BE71C4
	// [Call #3] RVA: 0x106BE71CC
	// [Call #4] RVA: 0x106BE71D4
	// [Call #5] RVA: 0x106BE71DC
	// [Call #6] RVA: 0x106BE71E4
	// [Call #7] RVA: 0x106BE71EC
	// [Call #8] RVA: 0x106BE71F4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7398
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function MediaAssets.MediaPlayer.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befe78
	// Params: [ Num(1) Size(0x1) ]
	bool HasError();
	// [Call #1] RVA: 0x106BE71B4
	// [Call #2] RVA: 0x106BE71BC
	// [Call #3] RVA: 0x106BE71C4
	// [Call #4] RVA: 0x106BE71CC
	// [Call #5] RVA: 0x106BE71D4
	// [Call #6] RVA: 0x106BE71DC
	// [Call #7] RVA: 0x106BE71E4
	// [Call #8] RVA: 0x106BE71EC
	// [Call #9] RVA: 0x106BE71F4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7398
	// [Call #13] RVA: 0x101F8130C

	// Object: Function MediaAssets.MediaPlayer.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befe40
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetViewRotation();
	// [Call #1] RVA: 0x106BE7170
	// [Call #2] RVA: 0x106BE71B4
	// [Call #3] RVA: 0x106BE71BC
	// [Call #4] RVA: 0x106BE71C4
	// [Call #5] RVA: 0x106BE71CC
	// [Call #6] RVA: 0x106BE71D4
	// [Call #7] RVA: 0x106BE71DC
	// [Call #8] RVA: 0x106BE71E4
	// [Call #9] RVA: 0x106BE71EC
	// [Call #10] RVA: 0x106BE71F4
	// [Call #11] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befd54
	// Params: [ Num(3) Size(0x18) ]
	struct FString GetVideoTrackType(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7168
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BE7170
	// [Call #11] RVA: 0x106BE71B4
	// [Call #12] RVA: 0x106BE71BC
	// [Call #13] RVA: 0x106BE71C4
	// [Call #14] RVA: 0x106BE71CC
	// [Call #15] RVA: 0x106BE71D4
	// [Call #16] RVA: 0x106BE71DC

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befc70
	// Params: [ Num(3) Size(0x18) ]
	struct FFloatRange GetVideoTrackFrameRates(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7118
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7168
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BE7170
	// [Call #16] RVA: 0x106BE71B4

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befbac
	// Params: [ Num(3) Size(0xC) ]
	float GetVideoTrackFrameRate(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7110
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7118
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7168

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackDimensions
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befae8
	// Params: [ Num(3) Size(0x10) ]
	struct FIntPoint GetVideoTrackDimensions(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7108
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7110
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7118

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106befa24
	// Params: [ Num(3) Size(0xC) ]
	float GetVideoTrackAspectRatio(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7100
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7108
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7110

	// Object: Function MediaAssets.MediaPlayer.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef9f0
	// Params: [ Num(1) Size(0x4) ]
	float GetVerticalFieldOfView();
	// [Call #1] RVA: 0x106BE70C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7100
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7108
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef9b8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();
	// [Call #1] RVA: 0x106BE70B4
	// [Call #2] RVA: 0x106BE70C0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE7100
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7108
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetTrackLanguage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef8c8
	// Params: [ Num(3) Size(0x18) ]
	struct FString GetTrackLanguage(uint8_t TrackType, int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE70AC
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BE70B4
	// [Call #11] RVA: 0x106BE70C0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BE7100

	// Object: Function MediaAssets.MediaPlayer.GetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef800
	// Params: [ Num(3) Size(0xC) ]
	int GetTrackFormat(uint8_t TrackType, int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE70A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE70AC
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BE70B4
	// [Call #16] RVA: 0x106BE70C0

	// Object: Function MediaAssets.MediaPlayer.GetTrackDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef710
	// Params: [ Num(3) Size(0x20) ]
	struct FText GetTrackDisplayName(uint8_t TrackType, int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE709C
	// [Call #6] RVA: 0x104F0F4CC
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE70A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef6dc
	// Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetTime();
	// [Call #1] RVA: 0x106BE7094
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE709C
	// [Call #7] RVA: 0x104F0F4CC
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE70A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetSupportedRates
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef5e0
	// Params: [ Num(2) Size(0x11) ]
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7038
	// [Call #6] RVA: 0x10277B634
	// [Call #7] RVA: 0x10277B634
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x106BE7094
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE709C
	// [Call #15] RVA: 0x104F0F4CC
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C

	// Object: Function MediaAssets.MediaPlayer.GetSelectedTrack
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef554
	// Params: [ Num(2) Size(0x8) ]
	int GetSelectedTrack(uint8_t TrackType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7030
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7038
	// [Call #9] RVA: 0x10277B634
	// [Call #10] RVA: 0x10277B634
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x106BE7094
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef520
	// Params: [ Num(1) Size(0x4) ]
	float GetRate();
	// [Call #1] RVA: 0x106BE7028
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE7030
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7038
	// [Call #10] RVA: 0x10277B634
	// [Call #11] RVA: 0x10277B634
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106BE7094
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef504
	// Params: [ Num(1) Size(0x4) ]
	int GetPlaylistIndex();
	// [Call #1] RVA: 0x106BE7028
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE7030
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7038
	// [Call #10] RVA: 0x10277B634
	// [Call #11] RVA: 0x10277B634
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106BE7094
	// [Call #14] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.GetPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef4e8
	// Params: [ Num(1) Size(0x8) ]
	struct UMediaPlaylist* GetPlaylist();
	// [Call #1] RVA: 0x106BE7028
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE7030
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7038
	// [Call #10] RVA: 0x10277B634
	// [Call #11] RVA: 0x10277B634
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x106BE7094

	// Object: Function MediaAssets.MediaPlayer.GetPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef4b4
	// Params: [ Num(1) Size(0x8) ]
	struct FName GetPlayerName();
	// [Call #1] RVA: 0x106BE7020
	// [Call #2] RVA: 0x106BE7028
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7030
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7038
	// [Call #11] RVA: 0x10277B634
	// [Call #12] RVA: 0x10277B634
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x106BE7094

	// Object: Function MediaAssets.MediaPlayer.GetNumTracks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef428
	// Params: [ Num(2) Size(0x8) ]
	int GetNumTracks(uint8_t TrackType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7010
	// [Call #4] RVA: 0x106BE7020
	// [Call #5] RVA: 0x106BE7028
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7030
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetNumTrackFormats
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef360
	// Params: [ Num(3) Size(0xC) ]
	int GetNumTrackFormats(uint8_t TrackType, int TrackIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE7018
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE7010
	// [Call #9] RVA: 0x106BE7020
	// [Call #10] RVA: 0x106BE7028
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetMediaName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef2f4
	// Params: [ Num(1) Size(0x18) ]
	struct FText GetMediaName();
	// [Call #1] RVA: 0x104F0F4CC
	// [Call #2] RVA: 0x101FBDBE8
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7018
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7010
	// [Call #13] RVA: 0x106BE7020
	// [Call #14] RVA: 0x106BE7028

	// Object: Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef2c0
	// Params: [ Num(1) Size(0x4) ]
	float GetHorizontalFieldOfView();
	// [Call #1] RVA: 0x106BE6FC8
	// [Call #2] RVA: 0x104F0F4CC
	// [Call #3] RVA: 0x101FBDBE8
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE7018
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BE7010
	// [Call #14] RVA: 0x106BE7020

	// Object: Function MediaAssets.MediaPlayer.GetDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef28c
	// Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetDuration();
	// [Call #1] RVA: 0x106BE6FC0
	// [Call #2] RVA: 0x106BE6FC8
	// [Call #3] RVA: 0x104F0F4CC
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE7018
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE7010
	// [Call #15] RVA: 0x106BE7020

	// Object: Function MediaAssets.MediaPlayer.GetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef258
	// Params: [ Num(1) Size(0x8) ]
	struct FName GetDesiredPlayerName();
	// [Call #1] RVA: 0x106BE6FB4
	// [Call #2] RVA: 0x106BE6FC0
	// [Call #3] RVA: 0x106BE6FC8
	// [Call #4] RVA: 0x104F0F4CC
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7018
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7010

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef16c
	// Params: [ Num(3) Size(0x18) ]
	struct FString GetAudioTrackType(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE6FAC
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x106BE6FB4
	// [Call #11] RVA: 0x106BE6FC0
	// [Call #12] RVA: 0x106BE6FC8
	// [Call #13] RVA: 0x104F0F4CC
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bef0a8
	// Params: [ Num(3) Size(0xC) ]
	int GetAudioTrackSampleRate(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE6FA4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE6FAC
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x106BE6FB4
	// [Call #16] RVA: 0x106BE6FC0
	// [Call #17] RVA: 0x106BE6FC8

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackChannels
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beefe4
	// Params: [ Num(3) Size(0xC) ]
	int GetAudioTrackChannels(int TrackIndex, int FormatIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE6F9C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE6FA4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE6FAC
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function MediaAssets.MediaPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106beefd0
	// Params: [ Num(0) Size(0x0) ]
	void Close();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE6F9C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BE6FA4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE6FAC
	// [Call #16] RVA: 0x101F8156C

	// Object: Function MediaAssets.MediaPlayer.CanPlayUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106beef28
	// Params: [ Num(2) Size(0x11) ]
	bool CanPlayUrl(struct FString URL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE6EC0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE6F9C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BE6FA4

	// Object: Function MediaAssets.MediaPlayer.CanPlaySource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106beee9c
	// Params: [ Num(2) Size(0x9) ]
	bool CanPlaySource(struct UMediaSource* MediaSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE6E20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE6EC0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BE6F9C
	// [Call #15] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlayer.CanPause
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106beee68
	// Params: [ Num(1) Size(0x1) ]
	bool CanPause();
	// [Call #1] RVA: 0x106BE6E18
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BE6E20
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BE6EC0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE6F9C
};

// Object: Class MediaAssets.MediaPlaylist
// Size: 0x40 (Inherited: 0x28)
struct UMediaPlaylist : UObject
{
	uint8_t Loop : 1; // 0x28(0x1), Mask(0x1)
	uint8_t BitPad_0x28_1 : 7; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct TArray<struct UMediaSource*> Items; // 0x30(0x10)


	// Object: Function MediaAssets.MediaPlaylist.Replace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf272c
	// Params: [ Num(3) Size(0x11) ]
	bool Replace(int Index, struct UMediaSource* Replacement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE8438
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlaylist.RemoveAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf26a0
	// Params: [ Num(2) Size(0x5) ]
	bool RemoveAt(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE83F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE8438
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlaylist.Remove
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf2614
	// Params: [ Num(2) Size(0x9) ]
	bool Remove(struct UMediaSource* MediaSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE839C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE83F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE8438
	// [Call #12] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlaylist.Num
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf25f8
	// Params: [ Num(1) Size(0x4) ]
	int Num();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE839C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE83F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE8438
	// [Call #12] RVA: 0x10519022C

	// Object: Function MediaAssets.MediaPlaylist.Insert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf2540
	// Params: [ Num(2) Size(0xC) ]
	void Insert(struct UMediaSource* MediaSource, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BE8318
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE839C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE83F0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlaylist.GetRandom
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bf24a4
	// Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetRandom(int& OutIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE72D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BE8318
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE839C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlaylist.GetPrevious
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bf2408
	// Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetPrevious(int& InOutIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7B40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE72D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BE8318
	// [Call #12] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlaylist.GetNext
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106bf236c
	// Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetNext(int& InOutIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE734C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE7B40
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE72D0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function MediaAssets.MediaPlaylist.Get
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf22e0
	// Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* Get(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7704
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE734C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7B40
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE72D0

	// Object: Function MediaAssets.MediaPlaylist.AddUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf2238
	// Params: [ Num(2) Size(0x11) ]
	bool AddUrl(struct FString URL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE7954
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7704
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE734C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7B40

	// Object: Function MediaAssets.MediaPlaylist.AddFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf2190
	// Params: [ Num(2) Size(0x11) ]
	bool AddFile(struct FString FilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE73DC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BE7954
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BE7704
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function MediaAssets.MediaPlaylist.Add
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106bf2104
	// Params: [ Num(2) Size(0x9) ]
	bool Add(struct UMediaSource* MediaSource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BE78B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BE73DC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BE7954
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106BE7704
};

// Object: Class MediaAssets.MediaSoundComponent
// Size: 0x750 (Inherited: 0x6D0)
struct UMediaSoundComponent : USynthComponent
{
	int Channels; // 0x6D0(0x4)
	uint8_t Pad_0x6D4[0x4]; // 0x6D4(0x4)
	struct UMediaPlayer* MediaPlayer; // 0x6D8(0x8)
	uint8_t Pad_0x6E0[0x70]; // 0x6E0(0x70)
};

// Object: Class MediaAssets.MediaTexture
// Size: 0x158 (Inherited: 0xE8)
struct UMediaTexture : UTexture
{
	enum class ETextureAddress AddressX; // 0xE8(0x1)
	enum class ETextureAddress AddressY; // 0xE9(0x1)
	bool AutoClear; // 0xEA(0x1)
	uint8_t Pad_0xEB[0x1]; // 0xEB(0x1)
	struct FLinearColor ClearColor; // 0xEC(0x10)
	uint8_t Pad_0xFC[0x4]; // 0xFC(0x4)
	struct UMediaPlayer* MediaPlayer; // 0x100(0x8)
	uint8_t Pad_0x108[0x50]; // 0x108(0x50)


	// Object: Function MediaAssets.MediaTexture.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf3090
	// Params: [ Num(1) Size(0x4) ]
	int GetWidth();
	// [Call #1] RVA: 0x106BE8BE4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870

	// Object: Function MediaAssets.MediaTexture.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf305c
	// Params: [ Num(1) Size(0x4) ]
	int GetHeight();
	// [Call #1] RVA: 0x106BE8BDC
	// [Call #2] RVA: 0x106BE8BE4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function MediaAssets.MediaTexture.GetAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106bf3028
	// Params: [ Num(1) Size(0x4) ]
	float GetAspectRatio();
	// [Call #1] RVA: 0x106BE8BB8
	// [Call #2] RVA: 0x106BE8BDC
	// [Call #3] RVA: 0x106BE8BE4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
};

// Object: Class MediaAssets.PlatformMediaSource
// Size: 0x38 (Inherited: 0x30)
struct UPlatformMediaSource : UMediaSource
{
	struct UMediaSource* MediaSource; // 0x30(0x8)
};

// Object: Class MediaAssets.StreamMediaSource
// Size: 0x48 (Inherited: 0x38)
struct UStreamMediaSource : UBaseMediaSource
{
	struct FString StreamUrl; // 0x38(0x10)
};

