#pragma once

#include <cstdint>

// Object: Enum ClusterReplication.EClusterEntityState
enum class EClusterEntityState : uint8_t
{
	STATE_Original = 0,
	STATE_WithData = 1,
	STATE_WithNoData = 2,
	STATE_MAX = 3
};

// Object: Enum ClusterReplication.EAOIEntityType
enum class EAOIEntityType : uint8_t
{
	Static = 0,
	Static_UGC = 1,
	Dynamic = 2,
	Dynamic_Custom = 3,
	EAOIEntityType_MAX = 4
};

// Object: ScriptStruct ClusterReplication.ClusterAOIConfig
// Size: 0x38 (Inherited: 0x0)
struct FClusterAOIConfig
{
	float AOIClusterSize; // 0x0(0x4)
	float AOIClusterTolerantSize; // 0x4(0x4)
	int AOIClusterRelativeIterator; // 0x8(0x4)
	int16_t SelectedGroup; // 0xC(0x2)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	struct FVector AOIMinPoint; // 0x10(0xC)
	struct FVector AOIMaxPoint; // 0x1C(0xC)
	struct TArray<int16_t> AOIEntityCounts; // 0x28(0x10)
};

// Object: Class ClusterReplication.ClusterReplicationSubsystem
// Size: 0x5B8 (Inherited: 0x28)
struct UClusterReplicationSubsystem : UObject
{
	uint8_t Pad_0x28[0x590]; // 0x28(0x590)


	// Object: Function ClusterReplication.ClusterReplicationSubsystem.SetAutoClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025209f8
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoClearCache(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function ClusterReplication.ClusterReplicationSubsystem.SetAutoCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102520978
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoCache(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function ClusterReplication.ClusterReplicationSubsystem.RemoveAllCachedObjectData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102520960
	// Params: [ Num(0) Size(0x0) ]
	void RemoveAllCachedObjectData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class ClusterReplication.ClusterEntityInterface
// Size: 0x28 (Inherited: 0x28)
struct IClusterEntityInterface : IInterface
{
};

