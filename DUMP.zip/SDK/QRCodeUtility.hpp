#pragma once

#include <cstdint>

// Object: Enum QRCodeUtility.EZXingFormat
enum class EZXingFormat : uint8_t
{
	NONE = 0,
	AZTEC = 1,
	CODABAR = 2,
	CODE_39 = 3,
	CODE_93 = 4,
	CODE_128 = 5,
	DATA_MATRIX = 6,
	EAN_8 = 7,
	EAN_13 = 8,
	ITF = 9,
	MAXICODE = 10,
	PDF_417 = 11,
	QR_CODE = 12,
	RSS_14 = 13,
	RSS_EXPANDED = 14,
	UPC_A = 15,
	UPC_E = 16,
	UPC_EAN_EXTENSION = 17,
	EZXingFormat_MAX = 18
};

// Object: ScriptStruct QRCodeUtility.ZXingScanResult
// Size: 0x28 (Inherited: 0x0)
struct FZXingScanResult
{
	uint8_t Format; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString Text; // 0x8(0x10)
	struct TArray<struct FVector2D> Points; // 0x18(0x10)
};

// Object: Class QRCodeUtility.VideoThumbnailGenerator
// Size: 0x28 (Inherited: 0x28)
struct UVideoThumbnailGenerator : UBlueprintFunctionLibrary
{

	// Object: Function QRCodeUtility.VideoThumbnailGenerator.GenerateVideoThumbnailAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10271817c
	// Params: [ Num(3) Size(0x28) ]
	void GenerateVideoThumbnailAsync(struct FString videoPath, int thumbnailSize, DelegateProperty& OnThumbnailGenerated);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102713D88
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class QRCodeUtility.ZXingScanner
// Size: 0x28 (Inherited: 0x28)
struct UZXingScanner : UBlueprintFunctionLibrary
{

	// Object: Function QRCodeUtility.ZXingScanner.Encode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027186b8
	// Params: [ Num(2) Size(0x18) ]
	struct UTexture2D* Encode(struct FString Text);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10271462C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x10518366C
	// [Call #12] RVA: 0x10518366C

	// Object: Function QRCodeUtility.ZXingScanner.Decode
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102718568
	// Params: [ Num(4) Size(0x41) ]
	bool Decode(struct UTexture2D* Texture, struct FZXingScanResult& OutResult, struct FVector4& InRect);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102714624
	// [Call #8] RVA: 0x102714BA0
	// [Call #9] RVA: 0x102714BA0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10271462C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
};

