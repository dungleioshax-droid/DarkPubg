#pragma once

#include <cstdint>

// Object: Enum AudioMixer.ESubmixEffectDynamicsPeakMode
enum class ESubmixEffectDynamicsPeakMode : uint8_t
{
	MeanSquared = 0,
	RootMeanSquared = 1,
	Peak = 2,
	Count = 3,
	ESubmixEffectDynamicsPeakMode_MAX = 4
};

// Object: Enum AudioMixer.ESubmixEffectDynamicsProcessorType
enum class ESubmixEffectDynamicsProcessorType : uint8_t
{
	Compressor = 0,
	Limiter = 1,
	Expander = 2,
	Gate = 3,
	Count = 4,
	ESubmixEffectDynamicsProcessorType_MAX = 5
};

// Object: ScriptStruct AudioMixer.SubmixEffectDynamicsProcessorSettings
// Size: 0x28 (Inherited: 0x0)
struct FSubmixEffectDynamicsProcessorSettings
{
	uint8_t DynamicsProcessorType; // 0x0(0x1)
	uint8_t PeakMode; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	float LookAheadMsec; // 0x4(0x4)
	float AttackTimeMsec; // 0x8(0x4)
	float ReleaseTimeMsec; // 0xC(0x4)
	float ThresholdDb; // 0x10(0x4)
	float Ratio; // 0x14(0x4)
	float KneeBandwidthDb; // 0x18(0x4)
	float InputGainDb; // 0x1C(0x4)
	float OutputGainDb; // 0x20(0x4)
	uint8_t bChannelLinked : 1; // 0x24(0x1), Mask(0x1)
	uint8_t bAnalogMode : 1; // 0x24(0x1), Mask(0x2)
	uint8_t BitPad_0x24_2 : 6; // 0x24(0x1)
	uint8_t Pad_0x25[0x3]; // 0x25(0x3)
};

// Object: ScriptStruct AudioMixer.SubmixEffectSubmixEQSettings
// Size: 0x10 (Inherited: 0x0)
struct FSubmixEffectSubmixEQSettings
{
	struct TArray<struct FSubmixEffectEQBand> EQBands; // 0x0(0x10)
};

// Object: ScriptStruct AudioMixer.SubmixEffectEQBand
// Size: 0x10 (Inherited: 0x0)
struct FSubmixEffectEQBand
{
	float Frequency; // 0x0(0x4)
	float Bandwidth; // 0x4(0x4)
	float GainDb; // 0x8(0x4)
	uint8_t bEnabled : 1; // 0xC(0x1), Mask(0x1)
	uint8_t BitPad_0xC_1 : 7; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct AudioMixer.SubmixEffectReverbSettings
// Size: 0x30 (Inherited: 0x0)
struct FSubmixEffectReverbSettings
{
	float Density; // 0x0(0x4)
	float Diffusion; // 0x4(0x4)
	float Gain; // 0x8(0x4)
	float GainHF; // 0xC(0x4)
	float DecayTime; // 0x10(0x4)
	float DecayHFRatio; // 0x14(0x4)
	float ReflectionsGain; // 0x18(0x4)
	float ReflectionsDelay; // 0x1C(0x4)
	float LateGain; // 0x20(0x4)
	float LateDelay; // 0x24(0x4)
	float AirAbsorptionGainHF; // 0x28(0x4)
	float WetLevel; // 0x2C(0x4)
};

// Object: Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e40c
	// Params: [ Num(4) Size(0x15) ]
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int EntryIndex, bool bBypassed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106974C0C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e324
	// Params: [ Num(3) Size(0x14) ]
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int EntryIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106974B48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106974C0C
	// [Call #17] RVA: 0x10519022C

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e278
	// Params: [ Num(2) Size(0x10) ]
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10697484C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106974B48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e1c4
	// Params: [ Num(3) Size(0x14) ]
	int GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106974CE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10697484C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106974B48

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e150
	// Params: [ Num(1) Size(0x8) ]
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10697494C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106974CE0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10697484C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698e06c
	// Params: [ Num(3) Size(0x20) ]
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry entry);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106974A24
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10697494C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106974CE0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10698dfc0
	// Params: [ Num(2) Size(0x10) ]
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106974684
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106974A24
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10697494C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0xD0 (Inherited: 0x40)
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset
{
	uint8_t Pad_0x40[0x68]; // 0x40(0x68)
	struct FSubmixEffectDynamicsProcessorSettings Settings; // 0xA8(0x28)


	// Object: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10698ea2c
	// Params: [ Num(1) Size(0x28) ]
	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& InSettings);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106983AB4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10698DF58
	// [Call #8] RVA: 0x105184F34
};

// Object: Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0xA0 (Inherited: 0x40)
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset
{
	uint8_t Pad_0x40[0x50]; // 0x40(0x50)
	struct FSubmixEffectSubmixEQSettings Settings; // 0x90(0x10)


	// Object: Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10698edd4
	// Params: [ Num(1) Size(0x10) ]
	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106984298
	// [Call #4] RVA: 0x106986954
	// [Call #5] RVA: 0x106986954
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10698DF58
	// [Call #11] RVA: 0x105184F34
};

// Object: Class AudioMixer.SubmixEffectReverbPreset
// Size: 0xE0 (Inherited: 0x40)
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset
{
	uint8_t Pad_0x40[0x70]; // 0x40(0x70)
	struct FSubmixEffectReverbSettings Settings; // 0xB0(0x30)


	// Object: Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10698f15c
	// Params: [ Num(2) Size(0xC) ]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106984800
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function AudioMixer.SubmixEffectReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10698f0a0
	// Params: [ Num(1) Size(0x30) ]
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10698482C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106984800
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class AudioMixer.SynthSound
// Size: 0x2F0 (Inherited: 0x2D0)
struct USynthSound : USoundWaveProcedural
{
	uint8_t Pad_0x2D0[0x20]; // 0x2D0(0x20)
};

// Object: Class AudioMixer.SynthComponent
// Size: 0x6D0 (Inherited: 0x3A0)
struct USynthComponent : USceneComponent
{
	uint8_t bAutoDestroy : 1; // 0x399(0x1), Mask(0x1)
	uint8_t bStopWhenOwnerDestroyed : 1; // 0x399(0x1), Mask(0x2)
	uint8_t bAllowSpatialization : 1; // 0x399(0x1), Mask(0x4)
	uint8_t bOverrideAttenuation : 1; // 0x399(0x1), Mask(0x8)
	struct USoundAttenuation* AttenuationSettings; // 0x3A0(0x8)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x3A8(0x2B8)
	struct USoundConcurrency* ConcurrencySettings; // 0x660(0x8)
	struct USoundClass* SoundClass; // 0x668(0x8)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x670(0x8)
	struct USoundSubmix* SoundSubmix; // 0x678(0x8)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x680(0x10)
	uint8_t bIsUISound : 1; // 0x690(0x1), Mask(0x1)
	uint8_t BitPad_0x690_5 : 3; // 0x690(0x1)
	uint8_t Pad_0x691[0x7]; // 0x691(0x7)
	struct USynthSound* Synth; // 0x698(0x8)
	struct UAudioComponent* AudioComponent; // 0x6A0(0x8)
	uint8_t Pad_0x6A8[0x28]; // 0x6A8(0x28)


	// Object: Function AudioMixer.SynthComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10698f5bc
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function AudioMixer.SynthComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10698f5a8
	// Params: [ Num(0) Size(0x0) ]
	void Start();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C

	// Object: Function AudioMixer.SynthComponent.SetSubmixSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10698f4f0
	// Params: [ Num(2) Size(0xC) ]
	void SetSubmixSend(struct USoundSubmix* Submix, float SendLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069807B0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AudioMixer.SynthComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10698f4bc
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x106980798
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1069807B0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

