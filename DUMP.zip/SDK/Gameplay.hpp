#pragma once

#include <cstdint>

// Object: Enum Gameplay.EBattleItemOperationType
enum class EBattleItemOperationType : uint8_t
{
	Pickup = 0,
	Drop = 1,
	Use = 2,
	Disuse = 3,
	Enable = 4,
	Disable = 5,
	EBattleItemOperationType_MAX = 6
};

// Object: Enum Gameplay.EBattleItemOperationFailedReason
enum class EBattleItemOperationFailedReason : uint8_t
{
	PickupFailed_Default = 0,
	PickupFailed_CapacityExceeded = 1,
	PickupFailed_ItemCountExceeded = 2,
	PickupFailed_PickupLimitExceeded = 3,
	DropFailed_Default = 16,
	UseFailed_Default = 32,
	UseFailed_CapacityExceeded = 33,
	UseFailed_SafeBagCapacityExceeded = 34,
	DisuseFailed_Default = 48,
	DisuseFailed_CapacityExceeded = 49,
	DisuseFailed_SafeBagCapacityExceeded = 50,
	EBattleItemOperationFailedReason_MAX = 51
};

// Object: Enum Gameplay.EBattleItemChangeAreaType
enum class EBattleItemChangeAreaType : uint8_t
{
	AllItem = 0,
	PartItemCaseCapacity = 1,
	PartItemCaseNum = 2,
	AllWantedNum = 3,
	EBattleItemChangeAreaType_MAX = 4
};

// Object: Enum Gameplay.EPickUpCheckResult
enum class EPickUpCheckResult : uint8_t
{
	EPUFR_OK = 0,
	EPUFR_DelayAdd = 1,
	EPUFR_Forbidden = 2,
	EPUFR_MAX = 3
};

// Object: Enum Gameplay.ECharacterGender
enum class ECharacterGender : uint8_t
{
	Male = 0,
	Female = 1,
	ECharacterGender_MAX = 2
};

// Object: Enum Gameplay.ECharacterPoseType
enum class ECharacterPoseType : uint8_t
{
	ECharPose_Stand = 0,
	ECharPose_Crouch = 1,
	ECharPose_Prone = 2,
	ECharPose_Max = 3
};

// Object: Enum Gameplay.ECharacterVehicleAnimType
enum class ECharacterVehicleAnimType : uint8_t
{
	ECharVehAnim_Idle = 0,
	ECharVehAnim_IdleWithWeapon = 1,
	ECharVehAnim_LeanOut = 2,
	ECharVehAnim_LeanIn = 3,
	ECharVehAnim_Aim = 4,
	ECharVehAnim_Scope = 5,
	ECharVehAnim_AimFPPCommon = 6,
	ECharVehAnim_MotorbikeIdle = 7,
	ECharVehAnim_MotorbikeVacate = 8,
	ECharVehAnim_MotorbikeDriverLeaning = 9,
	ECharVehAnim_MotorbikeDriverLeaningLowSpeed = 10,
	ECharVehAnim_MotorbikeDriverLeaningGroundPitch = 11,
	ECharVehAnim_MotorbikePassengerIdleBaseDriverOff = 12,
	ECharVehAnim_MotorbikePassengerIdleBaseWithGunDriverOff = 13,
	ECharVehAnim_MotorbikePassengerIdleBaseWithMeleeDriverOff = 14,
	ECharVehAnim_MotorbikePassengerIdleBaseWithThrowObjDriverOff = 15,
	ECharVehAnim_MotorbikePassengerDriverOffAim = 16,
	ECharVehAnim_MotorbikePassengerIdleLeaning = 17,
	ECharVehAnim_MotorbikePassengerIdleBaseDriverOn = 18,
	ECharVehAnim_MotorbikePassengerIdleBaseWithGunDriverOn = 19,
	ECharVehAnim_MotorbikePassengerIdleBaseWithMeleeDriverOn = 20,
	ECharVehAnim_MotorbikePassengerIdleBaseWithThrowObjDriverOn = 21,
	ECharVehAnim_Jump0 = 22,
	ECharVehAnim_Jump1 = 23,
	ECharVehAnim_Jump2 = 24,
	ECharVehAnim_Jump3 = 25,
	ECharVehAnim_SpeedUpByFoot = 26,
	ECharVehAnim_BrakeByFoot = 27,
	ECharVehAnim_Falling = 28,
	ECharVehAnim_FallLand_Additve = 29,
	ECharVehAnim_FallLand_Hard = 30,
	ECharVehAnim_Enter = 31,
	ECharVehAnim_Enter2 = 32,
	ECharVehAnim_Leave = 33,
	ECharVehAnim_StandIdle = 34,
	ECharVehAnim_IdleProne = 35,
	ECharVehAnim_EnterProne = 36,
	ECharVehAnim_LeaveProne = 37,
	ECharVehAnim_VehicleWeaponReload = 38,
	ECharVehAnim_VehicleWeaponFire = 39,
	ECharVehAnim_VehicleWeaponAimOffset = 40,
	ECharVehAnim_VehicleWeaponEquip = 41,
	ECharVehAnim_VehicleWeaponUnEquip = 42,
	ECharVehAnim_MotorgliderIdle = 43,
	ECharVehAnim_MotorgliderSteer = 44,
	ECharVehAnim_IdleWithWeapon_Down = 45,
	ECharVehAnim_DriverFoward = 46,
	ECharVehAnim_Bike_NormalDriveAnim = 47,
	ECharVehAnim_Bike_SprintDriveAnim = 48,
	ECharVehAnim_Bike_SpeedLeaningAnim = 49,
	ECharVehAnim_Bike_DriveLeaningHorizontalAnim = 50,
	ECharVehAnim_Bike_DriveLeaningVerticalAnim = 51,
	ECharVehAnim_Bike_DriveAnticipation = 52,
	ECharVehAnim_Bike_AirLeaningHorizontal = 53,
	ECharVehAnim_Bike_AirLeaningVertical = 54,
	ECharVehAnim_Bike_DriveHeadAO = 55,
	ECharVehAnim_Bike_DriveSteering = 56,
	ECharVehAnim_DlyingInVehicle_Idle = 57,
	ECharVehAnim_IdleWithDualGun = 58,
	ECharVehAnim_AimWithDualGun = 59,
	ECharVehAnim_HoldGrenadeAimModify = 60,
	ECharVehAnim_Max = 61
};

// Object: Enum Gameplay.ECharacterAnimType
enum class ECharacterAnimType : uint8_t
{
	ECharAnim_Move = 0,
	ECharAnim_Aim = 1,
	ECharAnim_ToStand = 2,
	ECharAnim_ToCrouch = 3,
	ECharAnim_ToProne = 4,
	ECharAnim_PickM = 5,
	ECharAnim_PickL = 6,
	ECharAnim_Equip_Primary = 7,
	ECharAnim_Equip_Secondary = 8,
	ECharAnim_Equip_Pistol = 9,
	ECharAnim_Equip_Melee = 10,
	ECharAnim_Equip_Thrown = 11,
	ECharAnim_Hurt = 12,
	ECharAnim_Reload = 13,
	ECharAnim_TacticsReload = 14,
	ECharAnim_JuggleStypeReload = 15,
	ECharAnim_ReloadType1 = 16,
	ECharAnim_ReloadType2 = 17,
	ECharAnim_Fire_Single = 18,
	ECharAnim_Fire_Burst = 19,
	ECharAnim_Fire_Auto = 20,
	ECharAnim_Accumulate = 21,
	ECharAnim_PostFire = 22,
	ECharAnim_Turn_L = 23,
	ECharAnim_Turn_R = 24,
	ECharAnim_PullingPlug = 25,
	ECharAnim_PutDownWeapon = 26,
	ECharAnim_WeaponIdle = 27,
	ECharAnim_VehWeaponIdle = 28,
	ECharAnim_VehWeaponIdle_Down = 29,
	ECharAnim_VehWeaponAim = 30,
	ECharAnim_VehWeaponReload = 31,
	ECharAnim_Peek = 32,
	ECharAnim_PeekScope = 33,
	ECharAnim_PeekLeftAim = 34,
	ECharAnim_PeekRightAim = 35,
	ECharAnim_ForegripAnim = 36,
	ECharAnim_Fire_Scope = 37,
	ECharAnim_Fire_Peek = 38,
	ECharAnim_SprintToProne = 39,
	ECharAnim_OpenDoor = 40,
	ECharAnim_Shovel = 41,
	ECharAnim_StandbyIdle_1 = 42,
	ECharAnim_StandbyIdle_2 = 43,
	ECharAnim_ColdStandbyIdle_1 = 44,
	ECharAnim_ColdStandbyIdle_2 = 45,
	ECharAnim_MovementUpBodyOverride = 46,
	ECharAnim_GrenadeLaunchAnim = 47,
	ECharAnim_GrenadeLaunchReload = 48,
	ECharAnim_GrenadeLaunchTacticsReload = 49,
	ECharAnim_FillGas = 50,
	ECharAnim_DropWeapon = 51,
	ECharAnim_ShoulderWeaponIdle = 52,
	ECharAnim_BeCarriedBackMove = 53,
	ECharAnim_BeCarriedBackPickM = 54,
	ECharAnim_BeCarriedBackPickL = 55,
	ECharAnim_BeCarriedBackOpenDoor = 56,
	ECharAnim_ScopeBlendAnim = 57,
	ECharAnim_MovementLowerBodyOverride = 58,
	ECharAnim_WeaponStandBase = 59,
	ECharAnim_Max = 60
};

// Object: Enum Gameplay.ECharacterMoveDragReason
enum class ECharacterMoveDragReason : uint8_t
{
	CMDR_UnknowReason = 0,
	CMDR_ExceedsDistance = 1,
	CMDR_MovementModeError = 2,
	CMDR_PassWall = 3,
	CMDR_Imprisonment = 4,
	CMDR_ServerControlPunish = 5,
	CMDR_ClientLocAndRotErrorProne = 6,
	CMDR_ResolvingTimeDiscrepancy = 7,
	CMDR_ExceedMaxZMove = 8,
	CMDR_OtherSecurity = 9,
	CMDR_LagPktOrSpeedOverLimit = 10,
	CMDR_MovementBaseError = 11,
	CMDR_TimeStampError = 12,
	CMDR_ModifyBaseMoveable = 13,
	CMDR_MAX = 14
};

// Object: Enum Gameplay.ECharAnimEventType
enum class ECharAnimEventType : uint8_t
{
	ECharAnimEvent_PoseChange = 0,
	ECharAnimEvent_PickUp = 1,
	ECharAnimEvent_Fire = 2,
	ECharAnimEvent_Reload = 3,
	ECharAnimEvent_Switch = 4,
	ECharAnimEvent_Peek = 5,
	ECharAnimEvent_PeekAim = 6,
	ECharAnimEvent_Bolt = 7,
	ECharAnimEvent_FillGas = 8,
	ECharAnimEvent_DropWeapon = 9,
	ECharAnimEvent_BeCarriedBackPickUp = 10,
	ECharAnimEvent_PostFire = 11,
	ECharAnimEvent_Max = 12
};

// Object: Enum Gameplay.ECharacterJumpType
enum class ECharacterJumpType : uint8_t
{
	ECharJump_InPlace = 0,
	ECharJump_Forward = 1,
	ECharJump_Max = 2
};

// Object: Enum Gameplay.ECharacterParachuteAnimType
enum class ECharacterParachuteAnimType : uint8_t
{
	ECharParachuteAnim_FreeFalling = 0,
	ECharParachuteAnim_Parachute = 1,
	ECharParachuteAnim_ParachuteEnter = 2,
	ECharParachuteAnim_ParachuteLand = 3,
	ECharParachuteAnim_FreeFallingTurn = 4,
	ECharParachuteAnim_FreeFallingStart = 5,
	ECharParachuteAnim_FreeFallingShake = 6,
	ECharParachuteAnim_FreeFallAerialShow = 7,
	ECharParachuteAnim_Max = 8
};

// Object: Enum Gameplay.EMentorPlayerType
enum class EMentorPlayerType : uint8_t
{
	MPT_NormalPlayer = 0,
	MPT_Veteran = 1,
	MPT_Recruit = 2,
	MPT_MAX = 3
};

// Object: Enum Gameplay.EEventCounterDefine
enum class EEventCounterDefine : uint8_t
{
	PlayerGotoSnowMountain = 1,
	PlayerGotoIceLand = 2,
	PlayerUseMoveablePlatform = 3,
	PlayerTurboDrop = 4,
	PlayerWingedFlightCount = 5,
	PlayerWingedFlightTotalDist = 6,
	PlayerUseCoin = 7,
	PlayerEasterEgg = 8,
	PlayerDuckGameTime = 9,
	PlayerBeeGameTime = 10,
	PlayerDuckGameCount = 11,
	PlayerBeeGameCount = 12,
	PlayerBlindBoxCount = 13,
	PlayerDuckShootingRangeCount = 14,
	PlayerPlaygroundSpringJumpCount = 15,
	PlayerTownSpringJumpCount = 16,
	PlayerMakeFiresNum = 17,
	PlayerChichenBBQNum = 18,
	PlayerUseKFNum = 19,
	PlayerUseUAVNum = 20,
	PlayerKFUsingTime = 21,
	PlayerUAVUsingTime = 22,
	PlayerSkateboardUsingCount = 23,
	PlayerSkateboardUsingTime = 24,
	PlayerSkateboardUsingDistance = 25,
	PlayerOpenTreasureBoxCount = 26,
	PlayerEatCakeCount = 27,
	PlayerUseDrinkMachineCount = 28,
	PlayerUseLeapPlatformCount = 29,
	PlayerPrayTotemsCount = 30,
	PlayerPickupMushroomCount = 31,
	PlayerUseBallonCount = 32,
	PlayerUseQuickSight = 33,
	PlayerPickingFruitCount = 34,
	PlayerInteractivePowerTotemCount = 35,
	PlayerInteractiveStrategyTotemCount = 36,
	PlayerInteractiveGuardTotemCount = 37,
	PlayerUseLookOutCount = 38,
	PlayerDancingInIslandCount = 39,
	PlayerFirstEnterVehicleType = 45,
	PlayerFirstEnterVehicleTime = 46,
	PlayerPlayVideoCount = 51,
	PlayerTakeBoatInWaterFallCount = 52,
	PlayerAceTaskStatusStat = 64,
	PlayerAcePillar1RewardTime = 65,
	PlayerAcePillar2RewardTime = 66,
	PlayerAcePillar3RewardTime = 67,
	PlayerAcePillar4RewardTime = 68,
	PlayerAcePillar5RewardTime = 69,
	PlayerAcePillarTotalCount = 70,
	PlayerDamageSteelDoorCount = 71,
	PlayerShowAceTaskPanelCount = 72,
	PlayerKillMetroAICount = 73,
	PlayerEnterUndergroundCount = 74,
	PlayerEnterRadiationCount = 75,
	PlayerUseSnowCockGrenadeCount = 76,
	PlayerUseSnowmanGrenadeCount = 77,
	PlayerEnterFloatIceCount = 78,
	PlayerInteractPineCount = 79,
	PlayerEnterWinterHouseCount = 84,
	PlayerEnterIceGardenCount = 85,
	PlayerDestroyPaperWallWithStickyBombCount = 89,
	PlayerUsePanzerFaustCount = 90,
	PlayerKillMonsterCount = 91,
	PlayerUseCrystalCount = 92,
	PlayerEnterDestroyedApex = 93,
	PlayerCollectLightBallCount = 94,
	PlayerKilledInSectManCount = 95,
	PlayerUseTeleport = 96,
	TeleportFromTrain = 120,
	A1StationEnter = 121,
	A1StationExit = 122,
	A2StationEnter = 123,
	A2StationExit = 124,
	A3StationEnter = 125,
	A3StationExit = 126,
	A4StationEnter = 127,
	A4StationExit = 128,
	A5StationEnter = 129,
	A5StationExit = 130,
	A6StationEnter = 131,
	A6StationExit = 132,
	B1StationEnter = 133,
	B1StationExit = 134,
	B2StationEnter = 135,
	B2StationExit = 136,
	B3StationEnter = 137,
	B3StationExit = 138,
	B4StationEnter = 139,
	B4StationExit = 140,
	C1StationEnter = 141,
	C1StationExit = 142,
	C2StationEnter = 143,
	C2StationExit = 144,
	C3StationEnter = 145,
	C3StationExit = 146,
	C4StationEnter = 147,
	C4StationExit = 148,
	C5StationEnter = 149,
	C5StationExit = 150,
	D1StationEnter = 151,
	D1StationExit = 152,
	D2StationEnter = 153,
	D2StationExit = 154,
	D3StationEnter = 155,
	D3StationExit = 156,
	D4StationEnter = 157,
	D4StationExit = 158,
	D5StationEnter = 159,
	D5StationExit = 160,
	EEventCounterDefine_MAX = 161
};

// Object: Enum Gameplay.ETLog_BackpackEquipmentSlotType
enum class ETLog_BackpackEquipmentSlotType : uint8_t
{
	EBackpackEquipmentSlotType_None = 0,
	EBackpackEquipmentSlotType_WeaponSlot1 = 1,
	EBackpackEquipmentSlotType_WeaponSlot2 = 2,
	EBackpackEquipmentSlotType_HelmetSlot = 3,
	EBackpackEquipmentSlotType_ArmorSlot = 4,
	EBackpackEquipmentSlotType_BagSlot = 5,
	EBackpackEquipmentSlotType_Weapon1GunPoint = 6,
	EBackpackEquipmentSlotType_Weapon1Grip = 7,
	EBackpackEquipmentSlotType_Weapon1Magazine = 8,
	EBackpackEquipmentSlotType_Weapon1Gunstock = 9,
	EBackpackEquipmentSlotType_Weapon1OpticalSight = 10,
	EBackpackEquipmentSlotType_Weapon2GunPoint = 11,
	EBackpackEquipmentSlotType_Weapon2Grip = 12,
	EBackpackEquipmentSlotType_Weapon2Magazine = 13,
	EBackpackEquipmentSlotType_Weapon2Gunstock = 14,
	EBackpackEquipmentSlotType_Weapon2OpticalSight = 15,
	EBackpackEquipmentSlotType_MAX = 16
};

// Object: Enum Gameplay.EWeaponDistanceType
enum class EWeaponDistanceType : uint8_t
{
	Gun = 1,
	CloseCombat = 2,
	Thrown = 3,
	EWeaponDistanceType_MAX = 4
};

// Object: Enum Gameplay.ELobbyCharacterAnimType
enum class ELobbyCharacterAnimType : uint8_t
{
	ELobbyCharAnim_Boy = 0,
	ELobbyCharAnim_Girl = 1,
	ELobbyCharAnim_Max = 2
};

// Object: Enum Gameplay.EGridGenerateType
enum class EGridGenerateType : uint8_t
{
	Invalid = 0,
	Normal = 1,
	EGridGenerateType_MAX = 2
};

// Object: Enum Gameplay.EAutoRotationMode
enum class EAutoRotationMode : uint8_t
{
	Normal = 0,
	Pendulum = 1,
	CustomCurve = 2,
	EAutoRotationMode_MAX = 3
};

// Object: Enum Gameplay.EDIYProjectDirection
enum class EDIYProjectDirection : uint8_t
{
	X = 1,
	X_ = 2,
	Y = 3,
	Y_ = 4,
	Z = 5,
	Z_ = 6,
	EDIYProjectDirection_MAX = 7
};

// Object: Enum Gameplay.EBattleDataType
enum class EBattleDataType : uint8_t
{
	None = 0,
	All = 1,
	SimpleAll = 2,
	PlayerInfo = 3,
	SimplePlayerInfo = 4,
	WeaponAvatar = 5,
	WeaponAvatarDIY = 6,
	EBattleDataType_MAX = 7
};

// Object: Enum Gameplay.EAntiMoveSpecialFlags
enum class EAntiMoveSpecialFlags : uint8_t
{
	StandOnMovableBase = 1,
	EAntiMoveSpecialFlags_MAX = 2
};

// Object: Enum Gameplay.EVehicleMoveDragReason
enum class EVehicleMoveDragReason : uint8_t
{
	Unknown = 0,
	ServerCorrection = 1,
	PunishBySecurity = 2,
	BeyondErrorThreshold = 3,
	CorrectionWithoutPassengers = 4,
	UseReplicatedMovementWhenRepMovementTimeout = 5,
	UseReplicatedLocAndRotWhenRepMovementTimeout = 6,
	StopSimulateWhenRepMovementTimeout = 7,
	EVehicleMoveDragReason_MAX = 8
};

// Object: Enum Gameplay.EDeathMatchSubModeType
enum class EDeathMatchSubModeType : uint8_t
{
	DeathMatch = 0,
	HardPoint = 1,
	ArmsRace = 2,
	EDeathMatchSubModeType_MAX = 3
};

// Object: Enum Gameplay.EIDCardDestroyReasonType
enum class EIDCardDestroyReasonType : uint8_t
{
	EDRT_Revived = 0,
	EDRT_Timeout = 1,
	EDRT_PlayerExit = 2,
	EDRT_TeamTerminated = 3,
	EDRT_MAX = 4
};

// Object: Enum Gameplay.ERevivalFailedReasonType
enum class ERevivalFailedReasonType : uint8_t
{
	ERFRT_Succeed = 0,
	ERFRT_PlayerDead = 1,
	ERFRT_Cancel = 2,
	ERFRT_IDCardDestroyed = 3,
	ERFRT_Interrupt = 4,
	ERFRT_BeHit = 5,
	ERFRT_Max_DoNothing = 6,
	ERFRT_MAX = 7
};

// Object: Enum Gameplay.EObserverEnemyTraceType
enum class EObserverEnemyTraceType : uint8_t
{
	None = 0,
	FriendObserve = 1,
	DeathObserve = 2,
	Both = 3,
	EObserverEnemyTraceType_MAX = 4
};

// Object: Enum Gameplay.ERealtimeReportType
enum class ERealtimeReportType : uint8_t
{
	CharMove1 = 1,
	ERealtimeReportType_MAX = 2
};

// Object: Enum Gameplay.ERealtimePunishType
enum class ERealtimePunishType : uint8_t
{
	Invalid = 0,
	CharMove = 1,
	AutoAim = 2,
	ERealtimePunishType_MAX = 3
};

// Object: Enum Gameplay.EPrisonBreak
enum class EPrisonBreak : uint8_t
{
	ClientMaxSpeed = 1,
	ClientDamageRate = 2,
	ClientParachuteSpeed = 4,
	ClientCoronaDataEmpty = 8,
	ClientCoronaDataCrcErr = 16,
	EPrisonBreak_MAX = 17
};

// Object: Enum Gameplay.ERegionType
enum class ERegionType : uint8_t
{
	SizeInvalid = 0,
	SizeSmall = 1,
	SizeMedium = 2,
	SizeLarge = 3,
	ERegionType_MAX = 4
};

// Object: Enum Gameplay.EVehicleSpotRandomType
enum class EVehicleSpotRandomType : uint8_t
{
	Vehicle_TotalCount = 0,
	Vehicle_Probability = 1,
	Vehicle_MAX = 2
};

// Object: Enum Gameplay.ESpotType
enum class ESpotType : uint8_t
{
	ESpotType_A = 0,
	ESpotType_B = 1,
	ESpotType_C = 2,
	ESpotType_D = 3,
	ESpotType_E = 4,
	ESpotType_F = 5,
	ESpotType_G = 6,
	ESpotType_H = 7,
	ESpotType_I = 8,
	ESpotType_J = 9,
	ESpotType_K = 10,
	ESpotType_L = 11,
	ESpotType_M = 12,
	ESpotType_N = 13,
	ESpotType_O = 14,
	ESpotType_P = 15,
	ESpotType_Q = 16,
	ESpotType_R = 17,
	ESpotType_S = 18,
	ESpotType_T = 19,
	ESpotType_U = 20,
	ESpotType_V = 21,
	ESpotType_W = 22,
	ESpotType_X = 23,
	ESpotType_Y = 24,
	ESpotType_Z = 25,
	ESpotType_A1 = 26,
	ESpotType_B1 = 27,
	ESpotType_C1 = 28,
	ESpotType_D1 = 29,
	ESpotType_E1 = 30,
	ESpotType_F1 = 31,
	ESpotType_G1 = 32,
	ESpotType_H1 = 33,
	ESpotType_I1 = 34,
	ESpotType_J1 = 35,
	ESpotType_K1 = 36,
	ESpotType_L1 = 37,
	ESpotType_M1 = 38,
	ESpotType_N1 = 39,
	ESpotType_O1 = 40,
	ESpotType_P1 = 41,
	ESpotType_Q1 = 42,
	ESpotType_R1 = 43,
	ESpotType_S1 = 44,
	ESpotType_T1 = 45,
	ESpotType_U1 = 46,
	ESpotType_V1 = 47,
	ESpotType_W1 = 48,
	ESpotType_X1 = 49,
	ESpotType_Y1 = 50,
	ESpotType_Z1 = 51,
	ESpotType_MAX = 52
};

// Object: Enum Gameplay.ESpotGroupType
enum class ESpotGroupType : uint8_t
{
	ESpotGroup_A = 0,
	ESpotGroup_B = 1,
	ESpotGroup_C = 2,
	ESpotGroup_D = 3,
	ESpotGroup_E = 4,
	ESpotGroup_F = 5,
	ESpotGroup_G = 6,
	ESpotGroup_H = 7,
	ESpotGroup_I = 8,
	ESpotGroup_J = 9,
	ESpotGroup_K = 10,
	ESpotGroup_L = 11,
	ESpotGroup_M = 12,
	ESpotGroup_N = 13,
	ESpotGroup_O = 14,
	ESpotGroup_P = 15,
	ESpotGroup_Q = 16,
	ESpotGroup_R = 17,
	ESpotGroup_S = 18,
	ESpotGroup_T = 19,
	ESpotGroup_U = 20,
	ESpotGroup_V = 21,
	ESpotGroup_W = 22,
	ESpotGroup_X = 23,
	ESpotGroup_Y = 24,
	ESpotGroup_Z = 25,
	ESpotGroup_MAX = 26
};

// Object: Enum Gameplay.ESVehAnimVehicleType
enum class ESVehAnimVehicleType : uint8_t
{
	Anim_VT_Unknown = 0,
	Anim_VT_Motorbike = 1,
	Anim_VT_Motorbike_SideCart = 2,
	Anim_VT_Dacia = 3,
	Anim_VT_UAZ = 4,
	Anim_VT_Buggy = 5,
	Anim_VT_PG117 = 6,
	Anim_VT_Aquarail = 7,
	Anim_VT_MiniBus = 8,
	Anim_VT_PickUp = 9,
	Anim_VT_Mirado = 10,
	Anim_VT_Rony = 11,
	Anim_VT_Surfboard = 12,
	Anim_VT_UH60 = 13,
	Anim_VT_Amphibious = 14,
	Anim_VT_Tuk = 15,
	Anim_VT_Scooter = 16,
	Anim_VT_Motorglider = 17,
	Anim_VT_MAX = 18
};

// Object: Enum Gameplay.ECharacterAnimTypeAsynLoaded
enum class ECharacterAnimTypeAsynLoaded : uint8_t
{
	ECharAnimAsyn_Swim_Up = 0,
	ECharAnimAsyn_Swim_Down = 1,
	ECharAnimAsyn_Max = 2
};

// Object: Enum Gameplay.ECharacterViewType
enum class ECharacterViewType : uint8_t
{
	ECharacterView_TPPandFPP = 0,
	ECharacterView_TPP = 1,
	ECharacterView_FPP = 2,
	ECharacterView_Max = 3
};

// Object: Enum Gameplay.EVehicleSeatType
enum class EVehicleSeatType : uint8_t
{
	EVehSeatType_Driver = 0,
	EVehSeatType_Left = 1,
	EVehSeatType_Right = 2,
	EVehSeatType_Max = 3
};

// Object: Enum Gameplay.EVehicleType
enum class EVehicleType : uint8_t
{
	EVehType_Buggy = 0,
	EVehType_UAZ = 1,
	EVehType_Motorcycle = 2,
	EVehType_Dacia = 3,
	EVehType_PG_117 = 4,
	EVehType_Max = 5
};

// Object: Enum Gameplay.ECharacterShovelPhase
enum class ECharacterShovelPhase : uint8_t
{
	ECharShovel_Enter = 0,
	ECharShovel_Shoveling = 1,
	ECharShovel_Leave = 2,
	ECharShovel_Crouch_Leave = 3,
	ECharShovel_Max = 4
};

// Object: Enum Gameplay.ECharacterJumpPhase
enum class ECharacterJumpPhase : uint8_t
{
	EJumpPhase_PreJump = 0,
	EJumpPhase_FallLoop0 = 1,
	EJumpPhase_FallLoop1 = 2,
	EJumpPhase_Land0 = 3,
	EJumpPhase_Land1 = 4,
	EJumpPhase_GrenadeJump_0 = 5,
	EJumpPhase_GrenadeJump_1 = 6,
	EJumpPhase_GrenadeFall_0 = 7,
	EJumpPhase_GrenadeFall_1 = 8,
	EJumpPhase_Max = 9
};

// Object: Enum Gameplay.ECharaAnimListType
enum class ECharaAnimListType : uint8_t
{
	ECharaAnimListType_TPP = 1,
	ECharaAnimListType_FPP = 2,
	ECharaAnimListType_Jump = 3,
	ECharaAnimListType_JumpFPP = 4,
	ECharaAnimListType_Shield = 5,
	EcharaAnimListType_Vehicle = 6,
	ECharaAnimListType_Shovel = 7,
	ECharaAnimListType_ShovelFPP = 8,
	ECharaAnimListType_Max = 9
};

// Object: Enum Gameplay.EBornItemFlag
enum class EBornItemFlag : uint8_t
{
	CANCARRYONPLANE = 1,
	EBornItemFlag_MAX = 2
};

// Object: Enum Gameplay.EGameOverReason
enum class EGameOverReason : uint8_t
{
	Exit = 0,
	NoJoinPlayers = 1,
	NoActivePlayers = 2,
	NoActivePlayersButHaveObservers = 3,
	InterruptGame = 4,
	EGameOverReason_MAX = 5
};

// Object: Enum Gameplay.EIndependentSpotType
enum class EIndependentSpotType : uint8_t
{
	ItemSpot = 0,
	VehicleSpot = 1,
	EIndependentSpotType_MAX = 2
};

// Object: Enum Gameplay.ELevelSequenceStartPlayType
enum class ELevelSequenceStartPlayType : uint8_t
{
	ELvSeqStartPlayType_Enable = 0,
	ELvSeqStartPlayType_Disable = 1,
	ELvSeqStartPlayType_Check = 2,
	ELvSeqStartPlayType_MAX = 3
};

// Object: Enum Gameplay.ECharSpecialLevelSequenceType
enum class ECharSpecialLevelSequenceType : uint8_t
{
	ECharSpecLvSeq_WeaponCheck = 0,
	ECharSpecLvSeq_WeaponShow = 1,
	ECharSpecLvSeq_WeaponHighlightMoment = 2,
	ECharSpecLvSeq_Max = 3
};

// Object: Enum Gameplay.ESequenceRelevantType
enum class ESequenceRelevantType : uint8_t
{
	Default = 0,
	OnlySelf = 1,
	Team = 2,
	ESequenceRelevantType_MAX = 3
};

// Object: Enum Gameplay.ECharacterShowSceneType
enum class ECharacterShowSceneType : uint8_t
{
	ECharacterShowSceneType_Lobby = 0,
	ECharacterShowSceneType_GameEndAvatarScene = 1,
	ECharacterShowSceneType_LobbyWithCar = 2,
	ECharacterShowSceneType_LobbySystem = 3,
	ECharacterShowSceneType_LobbyPure = 4,
	ECharacterShowSceneType_Max = 5
};

// Object: Enum Gameplay.ELobbyCharacterPosIndex
enum class ELobbyCharacterPosIndex : uint8_t
{
	Self = 0,
	Second = 1,
	Third = 2,
	Fourth = 3,
	ELobbyCharacterPosIndex_Max = 4
};

// Object: Enum Gameplay.EPlayerStatisticTypeForPCOB
enum class EPlayerStatisticTypeForPCOB : uint8_t
{
	None = 0,
	KillNumByDriveVehicle = 100,
	PoisonTotalDamage = 200,
	EPlayerStatisticTypeForPCOB_MAX = 201
};

// Object: Enum Gameplay.EActorSpawnType
enum class EActorSpawnType : uint8_t
{
	EStatic_Config = 0,
	EDynamic_Generator = 1,
	LevelEvent_Trrigger = 2,
	EActorSpawnType_MAX = 3
};

// Object: Enum Gameplay.EMonsterBornType
enum class EMonsterBornType : uint8_t
{
	EMonsterBornType_Burrow = 0,
	EMonsterBornType_ClimbWall = 1,
	EMonsterBornType_Fall = 2,
	EMonsterBornType_ProneToStand = 3,
	EMonsterBornType_Garbage = 5,
	EMonsterBornType_BreakWall = 6,
	EMonsterBornType_LyingOnTheGround = 7,
	EMonsterBornType_Max = 8
};

// Object: Enum Gameplay.EWeatherType
enum class EWeatherType : uint8_t
{
	EWeatherType_None = 0,
	EWeatherType_Sunday = 1,
	EWeatherType_Rainy = 2,
	EWeatherType_Foggy = 3,
	EWeatherType_Dark = 4,
	EWeatherType_Night = 5,
	EWeatherType_DayToNight = 6,
	EWeatherType_SnowToSquall = 7,
	EWeatherType_SnowToSquall2 = 8,
	EWeatherType_Aurora = 9,
	EWeatherType_Max = 10
};

// Object: ScriptStruct Gameplay.ItemOperationInfo
// Size: 0x20 (Inherited: 0x0)
struct FItemOperationInfo
{
	struct FItemDefineID DefineID; // 0x0(0x18)
	uint8_t BattleItemOperationType; // 0x18(0x1)
	uint8_t Reason; // 0x19(0x1)
	uint8_t Pad_0x1A[0x2]; // 0x1A(0x2)
	int Count; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerPetInfo
// Size: 0x20 (Inherited: 0x0)
struct FGameModePlayerPetInfo
{
	int PetId; // 0x0(0x4)
	int PetLevel; // 0x4(0x4)
	int PetCfgId; // 0x8(0x4)
	int PetColor; // 0xC(0x4)
	struct TArray<int> PetAvatarList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.DailyTaskStoreInfo
// Size: 0xC (Inherited: 0x0)
struct FDailyTaskStoreInfo
{
	int TaskID; // 0x0(0x4)
	int State; // 0x4(0x4)
	int Progress; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.PlayerEffectItemInfo
// Size: 0xC (Inherited: 0x0)
struct FPlayerEffectItemInfo
{
	int Slot; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	int Count; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerParams
// Size: 0x3F8 (Inherited: 0x0)
struct FGameModePlayerParams
{
	bool bEnablePlaneBanner; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString PlanetailResLink; // 0x8(0x10)
	uint64_t UID; // 0x18(0x8)
	struct FString OpenID; // 0x20(0x10)
	int ZoneID; // 0x30(0x4)
	uint8_t PlatID; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	struct FName PlayerType; // 0x38(0x8)
	struct FString PlayerName; // 0x40(0x10)
	uint32_t PlayerKey; // 0x50(0x4)
	int TeamID; // 0x54(0x4)
	int64_t IdxInTeam; // 0x58(0x8)
	uint64_t PreTeamID; // 0x60(0x8)
	int PlayerBornPointID; // 0x68(0x4)
	bool bTeamLeader; // 0x6C(0x1)
	bool bIsGM; // 0x6D(0x1)
	uint8_t Gender; // 0x6E(0x1)
	uint8_t SpeciesType; // 0x6F(0x1)
	uint8_t SpeciesGrade; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
	struct FString PIC_URL; // 0x78(0x10)
	int Level; // 0x88(0x4)
	int Segment_Level; // 0x8C(0x4)
	int AceImprintShowId; // 0x90(0x4)
	int AceImprintBaseId; // 0x94(0x4)
	int AvatarBoxId; // 0x98(0x4)
	bool bAIPlayer; // 0x9C(0x1)
	uint8_t Pad_0x9D[0x3]; // 0x9D(0x3)
	uint64_t MLAIDisplayUID; // 0xA0(0x8)
	struct TArray<struct FGameModePlayerItem> ItemList; // 0xA8(0x10)
	struct TArray<struct FGameModePlayerItem> fireworksInfo; // 0xB8(0x10)
	struct TArray<int> equip_plating_list; // 0xC8(0x10)
	struct TArray<struct FGameModePlayerRolewearInfo> AllWear; // 0xD8(0x10)
	int RolewearIndex; // 0xE8(0x4)
	uint8_t Pad_0xEC[0x4]; // 0xEC(0x4)
	struct TArray<struct FGameModePlayerExpressionItem> ExpressionItemList; // 0xF0(0x10)
	struct TArray<struct FGameModePlayerTaskData> TaskDataList; // 0x100(0x10)
	struct TArray<struct FGameModePlayerItem> WeaponAvatarList; // 0x110(0x10)
	struct TArray<struct FGameModePlayerItem> VehicleAvatarList; // 0x120(0x10)
	struct TArray<struct FVehicleAvatarData> VehicleAdvanceAvatarList; // 0x130(0x10)
	struct FGameModePlayerEquipmentAvatar EquipmentAvatar; // 0x140(0x30)
	struct TArray<struct FGameModeWeaponDIYPlanData> WeaponDIYPlanData; // 0x170(0x10)
	int VehicleSkinInReady; // 0x180(0x4)
	uint8_t Pad_0x184[0x4]; // 0x184(0x4)
	struct FGameModePlayerAliasInfo AliasInfo; // 0x188(0x48)
	struct FGameModePlayerUpassInfo UpassInfo; // 0x1D0(0x38)
	struct FGameModePlayerPetInfo PetInfo; // 0x208(0x20)
	struct TArray<struct FGameModePlayerPetInfo> AdditionalPetInfo; // 0x228(0x10)
	int UsingAdditionalPetIndex; // 0x238(0x4)
	uint8_t Pad_0x23C[0x4]; // 0x23C(0x4)
	struct TArray<struct FGameModePlayerKnapsackExtInfo> KnapsackExtInfoList; // 0x240(0x10)
	struct TArray<struct FGameModePlayeWeaponSchemeInfo> WeaponSchemeInfoList; // 0x250(0x10)
	int CurWeaponSchemeIndex; // 0x260(0x4)
	int PveLevel; // 0x264(0x4)
	struct TArray<int> CharSkillList; // 0x268(0x10)
	struct FGameModePlayerBanChat banChat; // 0x278(0x18)
	struct FGameModePlayerBanChat banTarget; // 0x290(0x18)
	struct TArray<struct FSpecialPickItem> SpecialPickItem; // 0x2A8(0x10)
	struct FAchievementPrize EquippedAchievementPrize; // 0x2B8(0xC)
	uint8_t Pad_0x2C4[0x4]; // 0x2C4(0x4)
	struct TArray<int> audioChat; // 0x2C8(0x10)
	struct FName CurrentPlayerState; // 0x2D8(0x8)
	struct FName CurrentCharacterState; // 0x2E0(0x8)
	float SyncedTimestamp; // 0x2E8(0x4)
	float DestinyValue; // 0x2EC(0x4)
	float WarmScore; // 0x2F0(0x4)
	float AIAllocMarkValue; // 0x2F4(0x4)
	int LeaderCount; // 0x2F8(0x4)
	uint8_t Pad_0x2FC[0x4]; // 0x2FC(0x4)
	uint64_t LastGameLeaderUID; // 0x300(0x8)
	struct TArray<uint64_t> LastGameTeammatesUID; // 0x308(0x10)
	uint64_t LastGameBattleID; // 0x318(0x8)
	float RatingScore; // 0x320(0x4)
	bool bDoPlayerUseAutoFollow; // 0x324(0x1)
	uint8_t Pad_0x325[0x3]; // 0x325(0x3)
	float MaxRankingScore; // 0x328(0x4)
	uint32_t ObserverFlags; // 0x32C(0x4)
	uint64_t WatchPlayerKey; // 0x330(0x8)
	bool bIsHawkEyeSpectator; // 0x338(0x1)
	uint8_t Pad_0x339[0x3]; // 0x339(0x3)
	int HawkEyeSpectateMaxMatchCount; // 0x33C(0x4)
	int HawkEyeSpectateUsedMatchCount; // 0x340(0x4)
	uint8_t PlatformGender; // 0x344(0x1)
	uint8_t Pad_0x345[0x3]; // 0x345(0x3)
	int planeAvatarId; // 0x348(0x4)
	int DyeDebugFlag; // 0x34C(0x4)
	struct FString Nation; // 0x350(0x10)
	int MatchLabel; // 0x360(0x4)
	bool OnlyTeammateSeeAvatar; // 0x364(0x1)
	uint8_t Pad_0x365[0x3]; // 0x365(0x3)
	int64_t LastGameResultTime; // 0x368(0x8)
	int64_t CorpsID; // 0x370(0x8)
	int64_t Campid; // 0x378(0x8)
	bool bUsedSimulation; // 0x380(0x1)
	bool bRoomCanKickPlayer; // 0x381(0x1)
	bool bCanDownloadInBattle; // 0x382(0x1)
	uint8_t Pad_0x383[0x5]; // 0x383(0x5)
	struct FString IpCountryStr; // 0x388(0x10)
	bool bRoomOwner; // 0x398(0x1)
	uint8_t Pad_0x399[0x3]; // 0x399(0x3)
	int VeteranRecruitIndex; // 0x39C(0x4)
	int MatchStrategyLabel; // 0x3A0(0x4)
	uint8_t Pad_0x3A4[0x4]; // 0x3A4(0x4)
	struct TArray<struct FDailyTaskStoreInfo> DailyTaskStoreList; // 0x3A8(0x10)
	int LandId; // 0x3B8(0x4)
	int FollowType; // 0x3BC(0x4)
	uint64_t FollowUID; // 0x3C0(0x8)
	uint32_t TaskSyncToDsTs; // 0x3C8(0x4)
	uint8_t Pad_0x3CC[0x4]; // 0x3CC(0x4)
	uint64_t LuckmateUID; // 0x3D0(0x8)
	struct FString GameAPPIDFromDS; // 0x3D8(0x10)
	float RealHiddenScore; // 0x3E8(0x4)
	float RealScoreMu; // 0x3EC(0x4)
	float RealScoreSigma; // 0x3F0(0x4)
	uint8_t Pad_0x3F4[0x4]; // 0x3F4(0x4)
};

// Object: ScriptStruct Gameplay.AchievementPrize
// Size: 0xC (Inherited: 0x0)
struct FAchievementPrize
{
	int MedalAvatarID; // 0x0(0x4)
	int NotifyTitleAvatarID; // 0x4(0x4)
	int ScoreBoardAvatarID; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.SpecialPickItem
// Size: 0xC (Inherited: 0x0)
struct FSpecialPickItem
{
	int item_id; // 0x0(0x4)
	int cur_count; // 0x4(0x4)
	int total_count; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerBanChat
// Size: 0x18 (Inherited: 0x0)
struct FGameModePlayerBanChat
{
	int end_time; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Reason; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayeWeaponSchemeInfo
// Size: 0x18 (Inherited: 0x0)
struct FGameModePlayeWeaponSchemeInfo
{
	int SchemeIndex; // 0x0(0x4)
	bool IsLocked; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct TArray<struct FGameModePlayeWeaponSchemeSlotInfo> SlotList; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayeWeaponSchemeSlotInfo
// Size: 0x20 (Inherited: 0x0)
struct FGameModePlayeWeaponSchemeSlotInfo
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	int Count; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<int> AttachList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerKnapsackExtInfo
// Size: 0x90 (Inherited: 0x0)
struct FGameModePlayerKnapsackExtInfo
{
	struct FGameModePlayerKnapsackSingleInfo KnapsackExtInfo; // 0x0(0x88)
	bool IsLocked; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	int WearIndex; // 0x8C(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerKnapsackSingleInfo
// Size: 0x88 (Inherited: 0x0)
struct FGameModePlayerKnapsackSingleInfo
{
	int Parachute; // 0x0(0x4)
	int ParachuteGlider; // 0x4(0x4)
	int BagSkin; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<int> BagSkinList; // 0x10(0x10)
	int HelmetSkin; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<int> HelmetSkinList; // 0x28(0x10)
	int FlySkin; // 0x38(0x4)
	int GrenadeSkin; // 0x3C(0x4)
	struct FGameModePlayerConsumableAvatar ConsumableAvatarList; // 0x40(0x10)
	struct TArray<struct FGameModePlayerItem> WeaponList; // 0x50(0x10)
	struct TArray<struct FGameModePlayerItem> VehicleSkinList; // 0x60(0x10)
	struct TArray<struct FGameModePlayerItem> BackPackPendantList; // 0x70(0x10)
	int ShowVehicleSkin; // 0x80(0x4)
	int WingmanSkin; // 0x84(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerItem
// Size: 0x20 (Inherited: 0x0)
struct FGameModePlayerItem
{
	int ItemTableID; // 0x0(0x4)
	int Count; // 0x4(0x4)
	struct TArray<int> AdditionIntData; // 0x8(0x10)
	bool bDropped; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
};

// Object: ScriptStruct Gameplay.GameModePlayerConsumableAvatar
// Size: 0x10 (Inherited: 0x0)
struct FGameModePlayerConsumableAvatar
{
	int GrenadeAvatarShoulei; // 0x0(0x4)
	int GrenadeAvatarSmoke; // 0x4(0x4)
	int GrenadeAvatarStun; // 0x8(0x4)
	int GrenadeAvatarBurn; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerUpassInfo
// Size: 0x38 (Inherited: 0x0)
struct FGameModePlayerUpassInfo
{
	int updateTime; // 0x0(0x4)
	int upassLevel; // 0x4(0x4)
	int upassScore; // 0x8(0x4)
	bool isBattleTitle; // 0xC(0x1)
	bool isUI; // 0xD(0x1)
	bool battleShow; // 0xE(0x1)
	bool isBuy; // 0xF(0x1)
	struct FString iconUrl; // 0x10(0x10)
	bool mainSwitch; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	int upassKeepBuy; // 0x24(0x4)
	int upassCurValue; // 0x28(0x4)
	int pass_type; // 0x2C(0x4)
	int nUpassPrimePlusCard; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerAliasInfo
// Size: 0x48 (Inherited: 0x0)
struct FGameModePlayerAliasInfo
{
	int aliasID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString aliasTitle; // 0x8(0x10)
	struct FString aliasNation; // 0x18(0x10)
	int aliasRank; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString aliasPartnerName; // 0x30(0x10)
	int aliasPartnerRelation; // 0x40(0x4)
	int aliasRankID; // 0x44(0x4)
};

// Object: ScriptStruct Gameplay.GameModeWeaponDIYPlanData
// Size: 0x8 (Inherited: 0x0)
struct FGameModeWeaponDIYPlanData
{
	int WeaponAvatarID; // 0x0(0x4)
	int PlanID; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerEquipmentAvatar
// Size: 0x30 (Inherited: 0x0)
struct FGameModePlayerEquipmentAvatar
{
	int BagAvatar; // 0x0(0x4)
	int HelmetAvatar; // 0x4(0x4)
	int ArmorAvatar; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<int> BagAvatarList; // 0x10(0x10)
	struct TArray<int> HelmetAvatarList; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.VehicleAvatarData
// Size: 0x28 (Inherited: 0x0)
struct FVehicleAvatarData
{
	int VehicleSkinID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<int> VehicleStyleIDList; // 0x8(0x10)
	struct TArray<struct FVehicleAvatarStyle> VehicleAvatarStyle; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.VehicleAvatarStyle
// Size: 0x10 (Inherited: 0x0)
struct FVehicleAvatarStyle
{
	int ModelID; // 0x0(0x4)
	int ColorID; // 0x4(0x4)
	int PatternID; // 0x8(0x4)
	int ParticleID; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerTaskData
// Size: 0x18 (Inherited: 0x0)
struct FGameModePlayerTaskData
{
	int task_id; // 0x0(0x4)
	int process; // 0x4(0x4)
	struct FString ext_info; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerExpressionItem
// Size: 0x20 (Inherited: 0x20)
struct FGameModePlayerExpressionItem : FGameModePlayerItem
{
};

// Object: ScriptStruct Gameplay.GameModePlayerRolewearInfo
// Size: 0x18 (Inherited: 0x0)
struct FGameModePlayerRolewearInfo
{
	struct TArray<struct FGameModePlayerItem> RolewearInfo; // 0x0(0x10)
	bool IsLocked; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct Gameplay.LobbyWatchInfo
// Size: 0x8 (Inherited: 0x0)
struct FLobbyWatchInfo
{
	uint32_t WatchedPlayerKey; // 0x0(0x4)
	bool bIsHawkEyeSpectator; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Gameplay.VehicleAvatarSkinList
// Size: 0x10 (Inherited: 0x0)
struct FVehicleAvatarSkinList
{
	struct TArray<int> SkinList; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.GameModeWeaponAvatarData
// Size: 0x8 (Inherited: 0x0)
struct FGameModeWeaponAvatarData
{
	int ParentID; // 0x0(0x4)
	int AvatarSpecificID; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerItems
// Size: 0x10 (Inherited: 0x0)
struct FGameModePlayerItems
{
	struct TArray<struct FGameModePlayerItem> Items; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.PlayerOBInfo
// Size: 0x58 (Inherited: 0x0)
struct FPlayerOBInfo
{
	bool IsEnableOB; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	uint64_t UID; // 0x8(0x8)
	int ZoneID; // 0x10(0x4)
	uint32_t PlayerKey; // 0x14(0x4)
	int BattleMode; // 0x18(0x4)
	bool ValidBattleInfo; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
	int GameCount; // 0x20(0x4)
	int WinCount; // 0x24(0x4)
	int TopTenCount; // 0x28(0x4)
	int KillNum; // 0x2C(0x4)
	float KDNum; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FTPlanExtraOBInfo TPlanInfo; // 0x38(0x20)
};

// Object: ScriptStruct Gameplay.TPlanExtraOBInfo
// Size: 0x20 (Inherited: 0x0)
struct FTPlanExtraOBInfo
{
	int GameCount; // 0x0(0x4)
	int Military; // 0x4(0x4)
	int64_t Income; // 0x8(0x8)
	float EscapeRate; // 0x10(0x4)
	int KillNum; // 0x14(0x4)
	float KDNum; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.PlayerNetStats
// Size: 0x40 (Inherited: 0x0)
struct FPlayerNetStats
{
	struct FString ClientAddr; // 0x0(0x10)
	struct FString LocalAddr; // 0x10(0x10)
	float AvgPing; // 0x20(0x4)
	float MaxPing; // 0x24(0x4)
	float HighPingPercent; // 0x28(0x4)
	uint8_t Pad_0x2C[0x14]; // 0x2C(0x14)
};

// Object: ScriptStruct Gameplay.WeatherInfo
// Size: 0x18 (Inherited: 0x0)
struct FWeatherInfo
{
	struct FString WeatherLevelName; // 0x0(0x10)
	int WeatherID; // 0x10(0x4)
	float WeatherTime; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.GameModeStateChangedParams
// Size: 0x10 (Inherited: 0x0)
struct FGameModeStateChangedParams
{
	struct FName GameModeState; // 0x0(0x8)
	bool bAliveOnNonePlayer; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Gameplay.TLog_ActivityEventType
// Size: 0x10 (Inherited: 0x0)
struct FTLog_ActivityEventType
{
	uint8_t ActivityEventID; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	struct FVector ActivityEventLoc; // 0x4(0xC)
};

// Object: ScriptStruct Gameplay.PlayerAnimData
// Size: 0x10 (Inherited: 0x0)
struct FPlayerAnimData
{
	struct UAnimationAsset* Animation; // 0x0(0x8)
	float Rate; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.CustomAccessoriesData
// Size: 0xC (Inherited: 0x0)
struct FCustomAccessoriesData
{
	int WeaponId; // 0x0(0x4)
	int Index; // 0x4(0x4)
	int ItemId; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.PlayerVehAnimList
// Size: 0x188 (Inherited: 0x0)
struct FPlayerVehAnimList
{
	uint8_t Pad_0x0[0x4]; // 0x0(0x4)
	int FrameCounter; // 0x4(0x4)
	struct UAnimationAsset* IdleAnim; // 0x8(0x8)
	struct UAnimationAsset* IdleGunAnimLayerBlend; // 0x10(0x8)
	struct UAnimationAsset* IdleMotorbikeAnim; // 0x18(0x8)
	struct UAnimationAsset* VacateMotorbikeAnim; // 0x20(0x8)
	struct UAnimationAsset* IdleMotorBikeDirverLeaningAnim; // 0x28(0x8)
	struct UAnimationAsset* IdleMotorBikeDirverLeaningLowSpeedAnim; // 0x30(0x8)
	struct UAnimationAsset* MotorBikeDirverLeaningGroundPitchAnim; // 0x38(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseDriverOffAnim; // 0x40(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithGunDriverOffAnim; // 0x48(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithDualGunDriverOffAnim; // 0x50(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithMeleeDriverOffAnim; // 0x58(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithThrowObjDriverOffAnim; // 0x60(0x8)
	struct UAnimationAsset* PassengerDriverOffAimAim; // 0x68(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleLeaningAnim; // 0x70(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseDriverOnAnim; // 0x78(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithGunDriverOnAnim; // 0x80(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithMeleeDriverOnAnim; // 0x88(0x8)
	struct UAnimationAsset* PassengerMotorBikeIdleBaseWithThrowObjDriverOnAnim; // 0x90(0x8)
	struct UAnimationAsset* LeanOutAnim; // 0x98(0x8)
	struct UAnimationAsset* LeanInAnim; // 0xA0(0x8)
	struct UAnimationAsset* AimAnim; // 0xA8(0x8)
	struct UAnimationAsset* WeaponIdleAddition; // 0xB0(0x8)
	struct UAnimationAsset* WeaponAimAddition; // 0xB8(0x8)
	struct UAnimationAsset* WeaponDualAimAddition; // 0xC0(0x8)
	struct UAnimationAsset* WeaponReloadAddition; // 0xC8(0x8)
	struct UAnimationAsset* SurfBoard_IdleAnim; // 0xD0(0x8)
	struct UAnimationAsset* SurfBoard_MoveAnim; // 0xD8(0x8)
	struct UAnimationAsset* SurfBoard_JumpAnim; // 0xE0(0x8)
	struct UAnimationAsset* SurfBoard_LandAnim; // 0xE8(0x8)
	struct UAnimationAsset* SurfBoard_JumpLeftTurnAnim; // 0xF0(0x8)
	struct UAnimationAsset* SurfBoard_JumpRightTurnAnim; // 0xF8(0x8)
	struct UAnimationAsset* Ski_JumpStationary; // 0x100(0x8)
	struct UAnimationAsset* Ski_DownTurnLR; // 0x108(0x8)
	struct UAnimationAsset* Ski_DownTurnRL; // 0x110(0x8)
	struct UAnimationAsset* Ski_DownTurnFD; // 0x118(0x8)
	struct UAnimationAsset* Ski_Falling; // 0x120(0x8)
	struct UAnimationAsset* Ski_DownFallLandingAdditive; // 0x128(0x8)
	struct UAnimationAsset* Ski_DownFallLandingHard; // 0x130(0x8)
	struct UAnimationAsset* VehicleWeaponIdleAnim; // 0x138(0x8)
	struct UAnimationAsset* VehicleWeaponEquipAnim; // 0x140(0x8)
	struct UAnimationAsset* VehicleWeaponUnEquipAnim; // 0x148(0x8)
	struct UAnimationAsset* VehicleWeaponReloadAnim; // 0x150(0x8)
	struct UAnimationAsset* VehicleWeaponAimOffsetAnim; // 0x158(0x8)
	struct UAnimationAsset* MotorgliderSteerAnim; // 0x160(0x8)
	struct UAnimationAsset* MotorgliderIdleAnim; // 0x168(0x8)
	struct UAnimationAsset* VehicleDriverForwardAnim; // 0x170(0x8)
	struct UAnimationAsset* DyingInVehicleIdleAnim; // 0x178(0x8)
	struct UAnimationAsset* HoldGrenadeAimModify; // 0x180(0x8)
};

// Object: ScriptStruct Gameplay.GameModeAIPlayerParams
// Size: 0x408 (Inherited: 0x3F8)
struct FGameModeAIPlayerParams : FGameModePlayerParams
{
	uint8_t AIType; // 0x3F4(0x1)
	uint32_t AILevel; // 0x3F8(0x4)
	bool bMLAIPlayer; // 0x3FC(0x1)
	bool bMLDelivery; // 0x3FD(0x1)
	uint8_t Pad_0x3FF[0x1]; // 0x3FF(0x1)
	uint32_t MLBotType; // 0x400(0x4)
	bool bBornIslandAI; // 0x404(0x1)
	bool bAITakeOver; // 0x405(0x1)
	uint8_t Pad_0x406[0x2]; // 0x406(0x2)
};

// Object: ScriptStruct Gameplay.PlayerPickUpInfo
// Size: 0x20 (Inherited: 0x0)
struct FPlayerPickUpInfo
{
	uint64_t PlayerUID; // 0x0(0x8)
	int ItemSpesificID; // 0x8(0x4)
	int Count; // 0xC(0x4)
	struct TArray<int> DataList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.GameDataMining
// Size: 0x48 (Inherited: 0x0)
struct FGameDataMining
{
	struct FString BattleID; // 0x0(0x10)
	struct FVector PlaneStartPoint; // 0x10(0xC)
	struct FVector PlaneEndPoint; // 0x1C(0xC)
	struct TArray<struct FCircleDataMining> CircleDataMining; // 0x28(0x10)
	struct TArray<struct FGameWatchReport> WatchReport; // 0x38(0x10)
};

// Object: ScriptStruct Gameplay.GameWatchReport
// Size: 0x38 (Inherited: 0x0)
struct FGameWatchReport
{
	uint16_t AreaID; // 0x0(0x2)
	uint8_t PlatID; // 0x2(0x1)
	uint8_t Pad_0x3[0x5]; // 0x3(0x5)
	struct FString ZoneID; // 0x8(0x10)
	uint64_t player_uid; // 0x18(0x8)
	float total_time; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<struct FWatchFlow> watch_flow; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.WatchFlow
// Size: 0x10 (Inherited: 0x0)
struct FWatchFlow
{
	uint64_t UID; // 0x0(0x8)
	uint32_t sec; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.CircleDataMining
// Size: 0x14 (Inherited: 0x0)
struct FCircleDataMining
{
	struct FVector WhiteCircleCenter; // 0x0(0xC)
	bool bDestinyCircle; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	int LeftPlayerNum; // 0x10(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerShowUpassInfo
// Size: 0xB0 (Inherited: 0x0)
struct FGameModePlayerShowUpassInfo
{
	struct FString PlayerName; // 0x0(0x10)
	int updateTime; // 0x10(0x4)
	int upassLevel; // 0x14(0x4)
	int upassScore; // 0x18(0x4)
	int planeAvatarId; // 0x1C(0x4)
	bool isBattleTitle; // 0x20(0x1)
	bool isUI; // 0x21(0x1)
	bool battleShow; // 0x22(0x1)
	bool isBuy; // 0x23(0x1)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString iconUrl; // 0x28(0x10)
	struct FString Nation; // 0x38(0x10)
	struct FGameModePlayerAliasInfo AliasInfo; // 0x48(0x48)
	int upassKeepBuy; // 0x90(0x4)
	int upassCurValue; // 0x94(0x4)
	int pass_type; // 0x98(0x4)
	int nUpassPrimePlusCard; // 0x9C(0x4)
	struct FString PlayerUID; // 0xA0(0x10)
};

// Object: ScriptStruct Gameplay.DSSwitchInfo
// Size: 0x18 (Inherited: 0x0)
struct FDSSwitchInfo
{
	int KeyNum; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString SValue; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerBattleResultData
// Size: 0x618 (Inherited: 0x0)
struct FGameModePlayerBattleResultData
{
	struct FString Reason; // 0x0(0x10)
	int RemainingPlayerCount; // 0x10(0x4)
	int TotalPlayerCount; // 0x14(0x4)
	int RemainingTeamCount; // 0x18(0x4)
	int TotalTeamCount; // 0x1C(0x4)
	float OnlineTime; // 0x20(0x4)
	bool IsSolo; // 0x24(0x1)
	bool IsSafeExit; // 0x25(0x1)
	uint8_t Pad_0x26[0x2]; // 0x26(0x2)
	uint64_t Killer; // 0x28(0x8)
	uint64_t killer_ig_uid; // 0x30(0x8)
	uint64_t KillerAIDisplayUID; // 0x38(0x8)
	struct FString KillerName; // 0x40(0x10)
	struct FString BeKilledOpenID; // 0x50(0x10)
	uint32_t KillerType; // 0x60(0x4)
	uint32_t KillerDeliveryType; // 0x64(0x4)
	int KillerWeaponID; // 0x68(0x4)
	uint32_t DeadCircleIndex; // 0x6C(0x4)
	int ShootWeaponShotNum; // 0x70(0x4)
	int ShootWeaponShotNumPicth; // 0x74(0x4)
	int ShootWeaponShotAndHitPlayerNum; // 0x78(0x4)
	int ShootWeaponShotAndHitPlayerNumNoAI; // 0x7C(0x4)
	int ShootWeaponShotHeadNum; // 0x80(0x4)
	int ShootWeaponShotHeadNumNoAI; // 0x84(0x4)
	int HealTimes; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
	struct TArray<struct FString> KillFlow; // 0x90(0x10)
	struct TArray<struct FString> KnockOutFlow; // 0xA0(0x10)
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // 0xB0(0x10)
	struct TMap<int, struct FTLog_BornLandGrenadeData> TLog_BornLandGrenadeData; // 0xC0(0x50)
	int PickUpItemTimes; // 0x110(0x4)
	uint8_t Pad_0x114[0x4]; // 0x114(0x4)
	struct TMap<int, int> TLog_BulletCount; // 0x118(0x50)
	uint64_t parachute_leader_uid; // 0x168(0x8)
	struct TArray<struct FUseItemFlow> UseItemFlow; // 0x170(0x10)
	struct TArray<struct FUseBuffFlow> UseBuffFlow; // 0x180(0x10)
	struct TArray<struct FBuildingEnterFlow> BuildingEnterFlow; // 0x190(0x10)
	struct TArray<struct FDestroyVehicleWheelFlow> DestroyVehicleWheelFlow; // 0x1A0(0x10)
	int destroyVehicleNum; // 0x1B0(0x4)
	int is_escape; // 0x1B4(0x4)
	struct TArray<struct FTLog_KillInfo> PlayerKillAIInfo; // 0x1B8(0x10)
	struct TArray<struct FTLog_KillInfo> PlayerNearDeathDuoToAI; // 0x1C8(0x10)
	struct FTLog_KillInfo AIKillPlayerInfo; // 0x1D8(0x28)
	struct TArray<struct FGameModeTeammateBattleResultData> TeammateList; // 0x200(0x10)
	struct TArray<struct FGameModeLikeResultData> Like; // 0x210(0x10)
	struct TArray<uint64_t> BeLiked; // 0x220(0x10)
	uint32_t Switch; // 0x230(0x4)
	uint8_t Pad_0x234[0x4]; // 0x234(0x4)
	struct TArray<uint32_t> Self; // 0x238(0x10)
	struct TArray<struct FGameModeTeammateLableCheckData> LabelCheck; // 0x248(0x10)
	struct FVector LandLocation; // 0x258(0xC)
	int LandTime; // 0x264(0x4)
	struct FVector ParachuteLocation; // 0x268(0xC)
	struct FVector DeadLocation; // 0x274(0xC)
	struct FString DeadDamangeType; // 0x280(0x10)
	int PveDeadAttacker; // 0x290(0x4)
	int PveStageId; // 0x294(0x4)
	struct FString DeadTimeStr; // 0x298(0x10)
	struct FString logoutime; // 0x2A8(0x10)
	float Pronetime; // 0x2B8(0x4)
	float BeInWaterTime; // 0x2BC(0x4)
	float SwimmingDistance; // 0x2C0(0x4)
	int BeDownTimes; // 0x2C4(0x4)
	int BeSavedTimes; // 0x2C8(0x4)
	int PickUpAirDrops; // 0x2CC(0x4)
	struct FEquipmentData EquipmentData; // 0x2D0(0x70)
	int Rank; // 0x340(0x4)
	int TotalScore; // 0x344(0x4)
	int ProneTimes; // 0x348(0x4)
	int CrouchTimes; // 0x34C(0x4)
	int JumpTimes; // 0x350(0x4)
	int TouchDownAreaID; // 0x354(0x4)
	int TouchDownLocTypeID; // 0x358(0x4)
	uint8_t Pad_0x35C[0x4]; // 0x35C(0x4)
	struct TArray<int> TouchDownAreaList; // 0x360(0x10)
	struct TArray<struct FGameModePlayerTaskData> CompletedTaskList; // 0x370(0x10)
	struct TArray<struct FReportCollection> SpecialCollectionList; // 0x380(0x10)
	struct TArray<struct FWeaponDamageRecord> WeaponDamageRecordList; // 0x390(0x10)
	struct FGrenadeDamageRecord GrenadeDamageRecord; // 0x3A0(0x28)
	struct FKniveDamageRecord KniveDamageRecord; // 0x3C8(0x28)
	struct TArray<int> SecretAreaIDList; // 0x3F0(0x10)
	int KillNumInVehicle; // 0x400(0x4)
	float TotalSprintDistance; // 0x404(0x4)
	float TotalBeenDamageAmount; // 0x408(0x4)
	float DestroyVehicleWheelNum; // 0x40C(0x4)
	struct TArray<int> BuildFlow; // 0x410(0x10)
	struct TArray<int> DestroyShelterFlow; // 0x420(0x10)
	float ShelterTakeDamage; // 0x430(0x4)
	float HitShelterDamage; // 0x434(0x4)
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // 0x438(0x10)
	struct TArray<struct FKnockOutData> KnockOutList; // 0x448(0x10)
	bool IsKickedFromGame; // 0x458(0x1)
	uint8_t Pad_0x459[0x3]; // 0x459(0x3)
	int KillMonsterNum; // 0x45C(0x4)
	int LightCandleNum; // 0x460(0x4)
	int KillMagicWalkAI; // 0x464(0x4)
	int SendMagicWalkAI; // 0x468(0x4)
	float BattleStateTime; // 0x46C(0x4)
	bool bIsGameTerminator; // 0x470(0x1)
	uint8_t Pad_0x471[0x7]; // 0x471(0x7)
	struct TMap<int, int> ActivityButtonCount; // 0x478(0x50)
	struct FTLog_SpecialStats TLog_SpecialStats; // 0x4C8(0x8)
	float TotalDamage; // 0x4D0(0x4)
	int FirstMoveBattles; // 0x4D4(0x4)
	int TotalBattles; // 0x4D8(0x4)
	float DamageAmountFPP; // 0x4DC(0x4)
	int FPPSwitchTimes; // 0x4E0(0x4)
	int MeleeKillTimes; // 0x4E4(0x4)
	float MeleeDamageAmount; // 0x4E8(0x4)
	float RangedDamagedAmount; // 0x4EC(0x4)
	float VehicleDamageAmount; // 0x4F0(0x4)
	int OpenAirDropBoxesNum; // 0x4F4(0x4)
	int FollowState; // 0x4F8(0x4)
	uint8_t Pad_0x4FC[0x4]; // 0x4FC(0x4)
	struct TArray<struct FString> DestroyVehicleFlow; // 0x500(0x10)
	int UseHelicoperNum; // 0x510(0x4)
	float UseHelicoperDistance; // 0x514(0x4)
	int RevivalNum; // 0x518(0x4)
	int BeRevivedNum; // 0x51C(0x4)
	int DrivingHelicopterTime; // 0x520(0x4)
	int InHelicopterTime; // 0x524(0x4)
	int SnowBoardJumpActionCount; // 0x528(0x4)
	int EmoteOnTelpherCount; // 0x52C(0x4)
	struct TArray<int> FindBlackMonsterIDs; // 0x530(0x10)
	int KillSnowManCount; // 0x540(0x4)
	uint8_t Pad_0x544[0x4]; // 0x544(0x4)
	struct TMap<uint8_t, int> EventCounterMap; // 0x548(0x50)
	struct TMap<int, int> GeneralCounterMap; // 0x598(0x50)
	struct FTLog_Micphone MicphoneTlog; // 0x5E8(0x18)
	int NormalItemNum; // 0x600(0x4)
	int SeniorItemNum; // 0x604(0x4)
	struct TArray<struct FSpecialWeaponRecord> SpecicalWeaponRecordList; // 0x608(0x10)
};

// Object: ScriptStruct Gameplay.SpecialWeaponRecord
// Size: 0x8 (Inherited: 0x0)
struct FSpecialWeaponRecord
{
	int WeaponId; // 0x0(0x4)
	int FireCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.TLog_Micphone
// Size: 0x18 (Inherited: 0x0)
struct FTLog_Micphone
{
	float TeammateMicrophoneTime; // 0x0(0x4)
	float TeammateSpeakerTime; // 0x4(0x4)
	float EnemyMicrophoneTime; // 0x8(0x4)
	float EnemySpeakerTime; // 0xC(0x4)
	float TeammateInterphoneTime; // 0x10(0x4)
	float EnemyInterphoneTime; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.TLog_SpecialStats
// Size: 0x8 (Inherited: 0x0)
struct FTLog_SpecialStats
{
	float MonsterDamageInNight1; // 0x0(0x4)
	float MonsterDamageInNight2; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.KnockOutData
// Size: 0x10 (Inherited: 0x0)
struct FKnockOutData
{
	uint64_t AttackerID; // 0x0(0x8)
	int Times; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.VehicleDriveDisData
// Size: 0x30 (Inherited: 0x0)
struct FVehicleDriveDisData
{
	uint64_t DriverID; // 0x0(0x8)
	int VehicleType; // 0x8(0x4)
	int AvatarID; // 0xC(0x4)
	float DriveDistance; // 0x10(0x4)
	float DriveTime; // 0x14(0x4)
	float VehicleJumpDistanceMax; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<uint64_t> PeopleInCar; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.KniveDamageRecord
// Size: 0x28 (Inherited: 0x0)
struct FKniveDamageRecord
{
	int HeadShootCount; // 0x0(0x4)
	int LimbsShootCount; // 0x4(0x4)
	int BodyShootCount; // 0x8(0x4)
	int HandShootCount; // 0xC(0x4)
	int FootShootCount; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FKniveDamageRecordItem> Knives; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.KniveDamageRecordItem
// Size: 0x1C (Inherited: 0x0)
struct FKniveDamageRecordItem
{
	int WeaponId; // 0x0(0x4)
	float TotalDamage; // 0x4(0x4)
	int KillCount; // 0x8(0x4)
	int KnockNumber; // 0xC(0x4)
	int AvatarID; // 0x10(0x4)
	int TotalUseTime; // 0x14(0x4)
	int TotalOwnTime; // 0x18(0x4)
};

// Object: ScriptStruct Gameplay.GrenadeDamageRecord
// Size: 0x28 (Inherited: 0x0)
struct FGrenadeDamageRecord
{
	int HitCount; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<int> HitDistanceArray; // 0x8(0x10)
	struct TArray<struct FGrenadeDamageRecordItem> Grenades; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.GrenadeDamageRecordItem
// Size: 0x18 (Inherited: 0x0)
struct FGrenadeDamageRecordItem
{
	int WeaponId; // 0x0(0x4)
	float TotalDamage; // 0x4(0x4)
	int FireCount; // 0x8(0x4)
	int KillCount; // 0xC(0x4)
	int KnockNumber; // 0x10(0x4)
	int AvatarID; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.WeaponDamageRecord
// Size: 0x60 (Inherited: 0x0)
struct FWeaponDamageRecord
{
	int WeaponId; // 0x0(0x4)
	float TotalDamage; // 0x4(0x4)
	int FireCount; // 0x8(0x4)
	int HeadShootCount; // 0xC(0x4)
	int LimbsShootCount; // 0x10(0x4)
	int BodyShootCount; // 0x14(0x4)
	int HandShootCount; // 0x18(0x4)
	int FootShootCount; // 0x1C(0x4)
	int UniqueHitCount; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<int> HitDistanceArray; // 0x28(0x10)
	int TotalUseTime; // 0x38(0x4)
	int TotalOwnTime; // 0x3C(0x4)
	int KillCount; // 0x40(0x4)
	int KnockNumber; // 0x44(0x4)
	struct TArray<int> Associations; // 0x48(0x10)
	int AvatarID; // 0x58(0x4)
	int DIYPlanID; // 0x5C(0x4)
};

// Object: ScriptStruct Gameplay.ReportCollection
// Size: 0x8 (Inherited: 0x0)
struct FReportCollection
{
	int item_id; // 0x0(0x4)
	int Count; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.EquipmentData
// Size: 0x70 (Inherited: 0x0)
struct FEquipmentData
{
	int HelmetID; // 0x0(0x4)
	int ArmorID; // 0x4(0x4)
	int BackPackID; // 0x8(0x4)
	int MainWeapon1ID; // 0xC(0x4)
	struct TArray<int> MainWeapon1AttachmentsID; // 0x10(0x10)
	int MainWeapon2ID; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<int> MainWeapon2AttachmentsID; // 0x28(0x10)
	int ViceWeaponID; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct TArray<int> ViceWeaponAttachmentsID; // 0x40(0x10)
	int CloseWeaponID; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<int> ThrowWeaponsID; // 0x58(0x10)
	uint8_t IsLuckyClothing; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
};

// Object: ScriptStruct Gameplay.GameModeTeammateLableCheckData
// Size: 0x10 (Inherited: 0x0)
struct FGameModeTeammateLableCheckData
{
	uint32_t Mask; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	uint64_t UID; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.GameModeLikeResultData
// Size: 0x18 (Inherited: 0x0)
struct FGameModeLikeResultData
{
	struct TArray<uint32_t> Like; // 0x0(0x10)
	uint64_t UID; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.GameModeTeammateBattleResultData
// Size: 0x1C8 (Inherited: 0x0)
struct FGameModeTeammateBattleResultData
{
	struct FString Name; // 0x0(0x10)
	uint64_t UID; // 0x10(0x8)
	int Kill; // 0x18(0x4)
	int AIKills; // 0x1C(0x4)
	struct FString State; // 0x20(0x10)
	float travelDistance; // 0x30(0x4)
	float marchDistance; // 0x34(0x4)
	float DriveDistance; // 0x38(0x4)
	float MonsterCatchupDistance; // 0x3C(0x4)
	float DamageAmount; // 0x40(0x4)
	float RealPlayerDamageAmount; // 0x44(0x4)
	float HealAmount; // 0x48(0x4)
	int AssistNum; // 0x4C(0x4)
	struct TArray<uint64_t> AssistTeammatesList; // 0x50(0x10)
	int HeadShotNum; // 0x60(0x4)
	int HeadShotNumNoAI; // 0x64(0x4)
	float surviveTime; // 0x68(0x4)
	float surviveTimeFromPlane; // 0x6C(0x4)
	int rescueTimes; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct TArray<uint64_t> RescueTeammatesList; // 0x78(0x10)
	int DestroyVehicles; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
	struct TArray<struct FString> KillFlow; // 0x90(0x10)
	struct TArray<struct FString> KnockOutFlow; // 0xA0(0x10)
	float OutsideBlueCircleTime; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // 0xB8(0x10)
	int FirstOpenedAirDropBoxNum; // 0xC8(0x4)
	float HitEnemyHeadAmount; // 0xCC(0x4)
	float TotalBeenDamageAmount; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct TArray<struct FPlayEmoteData> FPlayEmoteDataArray; // 0xD8(0x10)
	int FirstOpenedPlayerTombBoxNum; // 0xE8(0x4)
	float InDamageAmount; // 0xEC(0x4)
	int ProneTimes; // 0xF0(0x4)
	int CrouchTimes; // 0xF4(0x4)
	int JumpTimes; // 0xF8(0x4)
	int KillMonsterNum; // 0xFC(0x4)
	struct TMap<int, int> MonsterID2KillNum; // 0x100(0x50)
	int LightCandleNum; // 0x150(0x4)
	uint8_t Pad_0x154[0x4]; // 0x154(0x4)
	struct TMap<int, int> ActivityButtonCount; // 0x158(0x50)
	float TotalDamageAmountToMonsters; // 0x1A8(0x4)
	float TotalDamageAmountFromMonsters; // 0x1AC(0x4)
	int MonsterHeadShotKilledTimes; // 0x1B0(0x4)
	int BeMonsterDownTimes; // 0x1B4(0x4)
	bool bIsGameTerminator; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x3]; // 0x1B9(0x3)
	int mainWeaponID; // 0x1BC(0x4)
	float MaxWeaponAccurate; // 0x1C0(0x4)
	float MaxWeaponHeadShotRate; // 0x1C4(0x4)
};

// Object: ScriptStruct Gameplay.PlayEmoteData
// Size: 0x8 (Inherited: 0x0)
struct FPlayEmoteData
{
	int EmoteIndex; // 0x0(0x4)
	int AreaID; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.TLog_KillInfo
// Size: 0x28 (Inherited: 0x0)
struct FTLog_KillInfo
{
	int FakePlayerID; // 0x0(0x4)
	int DeadTime; // 0x4(0x4)
	int AILastFightTime; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<int> PlayerAreas; // 0x10(0x10)
	int ArmorID; // 0x20(0x4)
	int HelmetID; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.DestroyVehicleWheelFlow
// Size: 0x8 (Inherited: 0x0)
struct FDestroyVehicleWheelFlow
{
	int AreaID; // 0x0(0x4)
	int UseCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.BuildingEnterFlow
// Size: 0x58 (Inherited: 0x0)
struct FBuildingEnterFlow
{
	int BuildingID; // 0x0(0x4)
	int EnterCount; // 0x4(0x4)
	struct TMap<int, int> AreaCountMap; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.UseBuffFlow
// Size: 0x58 (Inherited: 0x0)
struct FUseBuffFlow
{
	int BuffID; // 0x0(0x4)
	int UseCount; // 0x4(0x4)
	struct TMap<int, int> AreaCountMap; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.UseItemFlow
// Size: 0x58 (Inherited: 0x0)
struct FUseItemFlow
{
	int ItemSpesificID; // 0x0(0x4)
	int UseCount; // 0x4(0x4)
	struct TMap<int, int> AreaCountMap; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.TLog_BornLandGrenadeData
// Size: 0x10 (Inherited: 0x0)
struct FTLog_BornLandGrenadeData
{
	int PickupCount; // 0x0(0x4)
	int ThrowCount; // 0x4(0x4)
	int HitOthersCount; // 0x8(0x4)
	int HitedByOthersCount; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.TLog_PickUpItemFlow
// Size: 0x40 (Inherited: 0x0)
struct FTLog_PickUpItemFlow
{
	int ItemSpesificID; // 0x0(0x4)
	int Count; // 0x4(0x4)
	struct FVector Location; // 0x8(0xC)
	int SourceType; // 0x14(0x4)
	int AdditionalParam; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString TimeStr; // 0x20(0x10)
	uint64_t InstanceID; // 0x30(0x8)
	uint64_t OwnerUID; // 0x38(0x8)
};

// Object: ScriptStruct Gameplay.GameModePlayerBattleResultData_SuperCold
// Size: 0x38 (Inherited: 0x0)
struct FGameModePlayerBattleResultData_SuperCold
{
	int MakeFiresNum; // 0x0(0x4)
	int DeerBBQNum; // 0x4(0x4)
	int ChichenBBQNum; // 0x8(0x4)
	int UseKFNum; // 0xC(0x4)
	int UseUAVNum; // 0x10(0x4)
	int KFUsingTime; // 0x14(0x4)
	int UAVUsingTime; // 0x18(0x4)
	int SkateboardUsingCount; // 0x1C(0x4)
	int SkateboardUsingTime; // 0x20(0x4)
	int SkateboardUsingDistance; // 0x24(0x4)
	struct TArray<struct FKillAnimalData> AnimalKillFlow; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.KillAnimalData
// Size: 0x8 (Inherited: 0x0)
struct FKillAnimalData
{
	uint8_t AnimalType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int KillNum; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.OnePlayerWeapon
// Size: 0x20 (Inherited: 0x0)
struct FOnePlayerWeapon
{
	struct FString PlayerID; // 0x0(0x10)
	struct TArray<struct FWeaponReport> Weapons; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.WeaponReport
// Size: 0x68 (Inherited: 0x0)
struct FWeaponReport
{
	int WeaponId; // 0x0(0x4)
	int FireCount; // 0x4(0x4)
	int AdsFireCount; // 0x8(0x4)
	int HitCount; // 0xC(0x4)
	int UniqueHitCount; // 0x10(0x4)
	int KillCount; // 0x14(0x4)
	float TotalDamage; // 0x18(0x4)
	float TotalMonsterDamage; // 0x1C(0x4)
	float TotalRealPlayerDamage; // 0x20(0x4)
	float TotalNormalAIDamage; // 0x24(0x4)
	float TotalMLAIDamage; // 0x28(0x4)
	int TotalOwnTime; // 0x2C(0x4)
	int TotalUseTime; // 0x30(0x4)
	int KnockDownCount; // 0x34(0x4)
	int HeadShootCount; // 0x38(0x4)
	int KillAICount; // 0x3C(0x4)
	int KnockDownAICount; // 0x40(0x4)
	int HeadShootAICount; // 0x44(0x4)
	int HitAICount; // 0x48(0x4)
	int UniqueHitAICount; // 0x4C(0x4)
	int UseCount; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<struct FHitFlow> HitFlow; // 0x58(0x10)
};

// Object: ScriptStruct Gameplay.HitFlow
// Size: 0x38 (Inherited: 0x0)
struct FHitFlow
{
	int AimType; // 0x0(0x4)
	int Distance; // 0x4(0x4)
	int IsKill; // 0x8(0x4)
	float Damage; // 0xC(0x4)
	bool bFallOnGround; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct TArray<uint8_t> PlayerStates; // 0x18(0x10)
	uint8_t HitPos; // 0x28(0x1)
	bool IsAI; // 0x29(0x1)
	uint8_t Pad_0x2A[0x2]; // 0x2A(0x2)
	uint32_t HitPlayerKey; // 0x2C(0x4)
	int TimeStamp; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.GameBaseInfo
// Size: 0x90 (Inherited: 0x0)
struct FGameBaseInfo
{
	struct FString GameSvrId; // 0x0(0x10)
	struct FString GameAppID; // 0x10(0x10)
	struct FString OpenID; // 0x20(0x10)
	uint16_t AreaID; // 0x30(0x2)
	uint8_t PlatID; // 0x32(0x1)
	uint8_t Pad_0x33[0x5]; // 0x33(0x5)
	struct FString ZoneID; // 0x38(0x10)
	uint64_t BattleID; // 0x48(0x8)
	struct FString UserName; // 0x50(0x10)
	uint64_t RoleID; // 0x60(0x8)
	uint8_t RoleType; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
	struct FString PicUrl; // 0x70(0x10)
	struct FString GameAPPIDFromDS; // 0x80(0x10)
};

// Object: ScriptStruct Gameplay.DamageInfo
// Size: 0xB8 (Inherited: 0x0)
struct FDamageInfo
{
	uint32_t DamageType; // 0x0(0x4)
	bool bIsHeadShot; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	float Distance; // 0x8(0x4)
	uint32_t Time; // 0xC(0x4)
	uint32_t DamageValue; // 0x10(0x4)
	uint32_t AttackerID; // 0x14(0x4)
	struct FVector AttackerLoc; // 0x18(0xC)
	uint32_t AttackerBulletNumInClip; // 0x24(0x4)
	uint32_t AttackerSightType; // 0x28(0x4)
	uint32_t AttackerWeaponType; // 0x2C(0x4)
	uint32_t AttackerWeaponScopeID; // 0x30(0x4)
	uint32_t AttackerShotTimes; // 0x34(0x4)
	uint64_t AttackerState; // 0x38(0x8)
	struct TArray<uint8_t> AttackerStateArray; // 0x40(0x10)
	bool bAttackerMoving; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	uint64_t VictimID; // 0x58(0x8)
	uint32_t VictimType; // 0x60(0x4)
	uint32_t VictimDeliveryType; // 0x64(0x4)
	int CircleIndex; // 0x68(0x4)
	struct FVector VictimLoc; // 0x6C(0xC)
	uint32_t VictimState; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	struct TArray<uint8_t> VictimStateArray; // 0x80(0x10)
	bool bVictimInWater; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	int VictimVehicleType; // 0x94(0x4)
	float VictimVelocity; // 0x98(0x4)
	uint32_t AttackerAreaID; // 0x9C(0x4)
	uint32_t AlivePlayerNum; // 0xA0(0x4)
	uint32_t VictimTeamID; // 0xA4(0x4)
	int FloorType; // 0xA8(0x4)
	uint32_t AttackerWeaponAvatarID; // 0xAC(0x4)
	uint32_t AttackerVehicleShapeType; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
};

// Object: ScriptStruct Gameplay.ActivityEventReportData
// Size: 0x14 (Inherited: 0x0)
struct FActivityEventReportData
{
	uint8_t EventID; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int Count; // 0x4(0x4)
	struct FVector Location; // 0x8(0xC)
};

// Object: ScriptStruct Gameplay.SpecialPickItemState
// Size: 0x8 (Inherited: 0x0)
struct FSpecialPickItemState
{
	int item_id; // 0x0(0x4)
	bool bIsCollectionCompleted; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Gameplay.TLog_PropEquipUnequipFlow
// Size: 0x18 (Inherited: 0x0)
struct FTLog_PropEquipUnequipFlow
{
	int ItemSpesificID; // 0x0(0x4)
	uint8_t SlotType; // 0x4(0x1)
	bool bEquip; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	struct FString TimeStr; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.AIDeliveryTlogData
// Size: 0x58 (Inherited: 0x0)
struct FAIDeliveryTlogData
{
	uint64_t UID; // 0x0(0x8)
	struct TMap<uint32_t, struct FAIDeliveryInfo> DeliveryMap; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.AIDeliveryInfo
// Size: 0x10 (Inherited: 0x0)
struct FAIDeliveryInfo
{
	int DeliveryStartTime; // 0x0(0x4)
	bool bSuccess; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	int DeliveryArrivalTime; // 0x8(0x4)
	int EventTypeId; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.BuildMaterialData
// Size: 0x8 (Inherited: 0x0)
struct FBuildMaterialData
{
	int MatID; // 0x0(0x4)
	int MatCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.MonsterTreasureBoxData
// Size: 0x18 (Inherited: 0x0)
struct FMonsterTreasureBoxData
{
	float BoxStartTime; // 0x0(0x4)
	struct FVector BoxLocation; // 0x4(0xC)
	uint64_t BoxStartPlayer; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.PlayerBaseInfoInOB
// Size: 0x24 (Inherited: 0x0)
struct FPlayerBaseInfoInOB
{
	struct FVector_NetQuantize Location; // 0x0(0xC)
	int Health; // 0xC(0x4)
	int HealthMax; // 0x10(0x4)
	int LiveState; // 0x14(0x4)
	int KillNum; // 0x18(0x4)
	int KillNumBeforeDie; // 0x1C(0x4)
	uint32_t PlayerKey; // 0x20(0x4)
};

// Object: ScriptStruct Gameplay.PlayerStaticInfoInOB
// Size: 0x58 (Inherited: 0x0)
struct FPlayerStaticInfoInOB
{
	struct FString PlayerName; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
	struct FString PlayerOpenID; // 0x20(0x10)
	struct FString PicUrl; // 0x30(0x10)
	int TeamID; // 0x40(0x4)
	uint8_t IndexInMap; // 0x44(0x1)
	uint8_t Pad_0x45[0x3]; // 0x45(0x3)
	uint64_t UID; // 0x48(0x8)
	uint32_t PlayerKey; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: ScriptStruct Gameplay.AllStarReportData
// Size: 0x8 (Inherited: 0x0)
struct FAllStarReportData
{
	bool bShowReportFlag; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int BeReportedNum; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.DailyTaskReportInfo
// Size: 0x30 (Inherited: 0x0)
struct FDailyTaskReportInfo
{
	uint64_t UID; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint32_t TaskSyncToDsTs; // 0xC(0x4)
	struct TArray<struct FDailyTaskStoreInfo> TaskInfo; // 0x10(0x10)
	struct TArray<struct FDailyTaskAwardInfo> RewardInfo; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.DailyTaskAwardInfo
// Size: 0x18 (Inherited: 0x0)
struct FDailyTaskAwardInfo
{
	int TaskID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FTaskAwardItemInfo> AwardList; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.TaskAwardItemInfo
// Size: 0x8 (Inherited: 0x0)
struct FTaskAwardItemInfo
{
	int ItemId; // 0x0(0x4)
	int ItemNum; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.PlayerInfoInOB
// Size: 0xA0 (Inherited: 0x24)
struct FPlayerInfoInOB : FPlayerBaseInfoInOB
{
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	uint64_t UID; // 0x28(0x8)
	struct FString PlayerName; // 0x30(0x10)
	struct FString PlayerOpenID; // 0x40(0x10)
	struct FString PicUrl; // 0x50(0x10)
	bool ShowPicUrl; // 0x60(0x1)
	uint8_t Pad_0x61[0x3]; // 0x61(0x3)
	int TeamID; // 0x64(0x4)
	struct FString TeamName; // 0x68(0x10)
	struct TWeakObjectPtr<struct APawn> Character; // 0x78(0x8)
	bool IsFiring; // 0x80(0x1)
	bool bHasDied; // 0x81(0x1)
	uint8_t Pad_0x82[0x1E]; // 0x82(0x1E)
};

// Object: ScriptStruct Gameplay.ParachuteData
// Size: 0x90 (Inherited: 0x0)
struct FParachuteData
{
	uint64_t UID; // 0x0(0x8)
	float SlideDuration; // 0x8(0x4)
	uint8_t FollowState; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	struct FVector ClientLandLocation; // 0x10(0xC)
	struct FVector ClientLocation; // 0x1C(0xC)
	struct FVector ServerLandLocation; // 0x28(0xC)
	float SlideStartTime; // 0x34(0x4)
	float SlideEndTime; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString InputCount; // 0x40(0x10)
	struct FString PositionCheck; // 0x50(0x10)
	struct FString ClientPositionDiff; // 0x60(0x10)
	float LastCorrectionTime; // 0x70(0x4)
	float LastCorrectionHeight; // 0x74(0x4)
	struct FVector LastCorrectionLocation; // 0x78(0xC)
	struct FVector LastCorrectedLocation; // 0x84(0xC)
};

// Object: ScriptStruct Gameplay.PlayerPositionFlow
// Size: 0x48 (Inherited: 0x0)
struct FPlayerPositionFlow
{
	struct FPlayBaseInfo PlayerBaseInfo; // 0x0(0x30)
	int FirstPointTimestamp; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<struct FIntPosition2D> PointList; // 0x38(0x10)
};

// Object: ScriptStruct Gameplay.IntPosition2D
// Size: 0x8 (Inherited: 0x0)
struct FIntPosition2D
{
	int X; // 0x0(0x4)
	int Y; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.PlayBaseInfo
// Size: 0x30 (Inherited: 0x0)
struct FPlayBaseInfo
{
	uint64_t RoleID; // 0x0(0x8)
	struct FString OpenID; // 0x8(0x10)
	uint8_t PlatID; // 0x18(0x1)
	uint8_t Pad_0x19[0x1]; // 0x19(0x1)
	uint16_t AreaID; // 0x1A(0x2)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString ZoneID; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.VehicleMoveFlow
// Size: 0x40 (Inherited: 0x0)
struct FVehicleMoveFlow
{
	uint64_t RoleID; // 0x0(0x8)
	struct FString OpenID; // 0x8(0x10)
	uint8_t PlatID; // 0x18(0x1)
	uint8_t Pad_0x19[0x1]; // 0x19(0x1)
	uint16_t AreaID; // 0x1A(0x2)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString ZoneID; // 0x20(0x10)
	struct TArray<struct FVehicleMovePoint> PointList; // 0x30(0x10)
};

// Object: ScriptStruct Gameplay.VehicleMovePoint
// Size: 0x28 (Inherited: 0x0)
struct FVehicleMovePoint
{
	uint32_t UniqueId; // 0x0(0x4)
	uint8_t Type; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	int X; // 0x8(0x4)
	int Y; // 0xC(0x4)
	int Z; // 0x10(0x4)
	int Speed; // 0x14(0x4)
	uint8_t VehicleN2oUse; // 0x18(0x1)
	uint8_t VehicleCarPetUse; // 0x19(0x1)
	uint8_t Pad_0x1A[0x2]; // 0x1A(0x2)
	int VehicleMoveDistance; // 0x1C(0x4)
	int TimeStamp; // 0x20(0x4)
	uint8_t RoleType; // 0x24(0x1)
	uint8_t Pad_0x25[0x3]; // 0x25(0x3)
};

// Object: ScriptStruct Gameplay.UAEWindowRepData
// Size: 0x50 (Inherited: 0x0)
struct FUAEWindowRepData
{
	struct FTransform Transform; // 0x0(0x30)
	struct FString PathToLoad; // 0x30(0x10)
	int ID; // 0x40(0x4)
	bool bBroken; // 0x44(0x1)
	uint8_t Pad_0x45[0x3]; // 0x45(0x3)
	struct APawn* LastInstigatorPawn; // 0x48(0x8)
};

// Object: ScriptStruct Gameplay.OBPlayerWeaponRecord
// Size: 0x18 (Inherited: 0x0)
struct FOBPlayerWeaponRecord
{
	uint64_t OBPlayerWeaponRecord_UID; // 0x0(0x8)
	struct TArray<struct FOBSingleWeaponRecord> WeaponReport; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.OBSingleWeaponRecord
// Size: 0x10 (Inherited: 0x0)
struct FOBSingleWeaponRecord
{
	int OBSingleWeaponRecord_WeaponID; // 0x0(0x4)
	float TotalDamage; // 0x4(0x4)
	int KillCount; // 0x8(0x4)
	int KnockDownCount; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.AIPlayerInfoInOB
// Size: 0x20 (Inherited: 0x0)
struct FAIPlayerInfoInOB
{
	struct FString PlayerKey; // 0x0(0x10)
	int TeamID; // 0x10(0x4)
	struct TWeakObjectPtr<struct APawn> Character; // 0x14(0x8)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.FriendObserver
// Size: 0x18 (Inherited: 0x0)
struct FFriendObserver
{
	struct FString PlayerName; // 0x0(0x10)
	uint8_t Gender; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct Gameplay.DIYMergedTexData
// Size: 0x48 (Inherited: 0x0)
struct FDIYMergedTexData
{
	struct TArray<struct FDIYOneTexData> TextureList; // 0x0(0x10)
	int TexPathID; // 0x10(0x4)
	struct FDIYParamData DIYParam; // 0x14(0x30)
	int SlotID; // 0x44(0x4)
};

// Object: ScriptStruct Gameplay.DIYParamData
// Size: 0x30 (Inherited: 0x0)
struct FDIYParamData
{
	int Direction; // 0x0(0x4)
	int ColorID; // 0x4(0x4)
	float Opacity; // 0x8(0x4)
	float Rotation; // 0xC(0x4)
	float ScaleX; // 0x10(0x4)
	float ScaleY; // 0x14(0x4)
	float OffSetX; // 0x18(0x4)
	float OffSetY; // 0x1C(0x4)
	float UClipX; // 0x20(0x4)
	float UClipY; // 0x24(0x4)
	float VClipX; // 0x28(0x4)
	float VClipY; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.DIYOneTexData
// Size: 0x34 (Inherited: 0x0)
struct FDIYOneTexData
{
	int TexPathID; // 0x0(0x4)
	struct FDIYParamData DIYParam; // 0x4(0x30)
};

// Object: ScriptStruct Gameplay.ResponResult
// Size: 0x1 (Inherited: 0x0)
struct FResponResult
{
	bool bResponed; // 0x0(0x1)
};

// Object: ScriptStruct Gameplay.WeaponDIYData
// Size: 0x50 (Inherited: 0x1)
struct FWeaponDIYData : FResponResult
{
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int WeaponId; // 0x4(0x4)
	int PlanID; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<struct FDIYMergedTexData> DIYData; // 0x10(0x10)
	struct TArray<int> MatParam; // 0x20(0x10)
	struct TArray<int> MirroParam; // 0x30(0x10)
	struct TArray<int> SlotMatParam; // 0x40(0x10)
};

// Object: ScriptStruct Gameplay.VehicleMoveDragData
// Size: 0x20 (Inherited: 0x0)
struct FVehicleMoveDragData
{
	struct TArray<struct FVehicleMoveDrag> MoveDrag; // 0x0(0x10)
	struct TArray<struct FVehicleMoveDrag> SimulatedMoveDrag; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.VehicleMoveDrag
// Size: 0x28 (Inherited: 0x0)
struct FVehicleMoveDrag
{
	int Minute; // 0x0(0x4)
	uint8_t VehicleType; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct TArray<uint8_t> Reasons; // 0x8(0x10)
	struct TArray<int> Counters; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.HisarData
// Size: 0x38 (Inherited: 0x0)
struct FHisarData
{
	struct FAppInstallData AppInstallData; // 0x0(0x28)
	struct FString DeviceID; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.AppInstallData
// Size: 0x28 (Inherited: 0x0)
struct FAppInstallData
{
	int64_t FirstInstallTime; // 0x0(0x8)
	struct FGuid Guid; // 0x8(0x10)
	struct FString GuidStr; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.HitFireBtnFlow
// Size: 0x80 (Inherited: 0x0)
struct FHitFireBtnFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	uint64_t BattleID; // 0x40(0x8)
	uint64_t UID; // 0x48(0x8)
	int MapID; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString ClientVersion; // 0x58(0x10)
	int MatchMode; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct TArray<struct FHitFireBtnSampleCluster> HitFireBtnSampleClusterArray; // 0x70(0x10)
};

// Object: ScriptStruct Gameplay.HitFireBtnSampleCluster
// Size: 0x18 (Inherited: 0x0)
struct FHitFireBtnSampleCluster
{
	float StartTime; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FHitFireBtnSample> HitFireBtnSampleArray; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.HitFireBtnSample
// Size: 0x18 (Inherited: 0x0)
struct FHitFireBtnSample
{
	float LocX; // 0x0(0x4)
	float LocY; // 0x4(0x4)
	uint64_t StartFrame; // 0x8(0x8)
	uint64_t EndFrame; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.AntiDataFlow
// Size: 0x88 (Inherited: 0x0)
struct FAntiDataFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	uint64_t BattleID; // 0x40(0x8)
	uint64_t UID; // 0x48(0x8)
	struct FString ClientVersion; // 0x50(0x10)
	int MatchMode; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct FString FlowDataStr; // 0x68(0x10)
	struct FString FlowDataStr2; // 0x78(0x10)
};

// Object: ScriptStruct Gameplay.BattleResultData
// Size: 0x88 (Inherited: 0x0)
struct FBattleResultData
{
	struct FString Reason; // 0x0(0x10)
	uint32_t RemainingPlayerCount; // 0x10(0x4)
	uint32_t TotalPlayerCount; // 0x14(0x4)
	uint32_t RemainingTeamCount; // 0x18(0x4)
	uint32_t TotalTeamCount; // 0x1C(0x4)
	bool IsSolo; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	uint32_t ShootWeaponShotNum; // 0x24(0x4)
	uint32_t ShootWeaponShotAndHitPlayerNum; // 0x28(0x4)
	uint32_t HealTimes; // 0x2C(0x4)
	float marchDistance; // 0x30(0x4)
	float DriveDistance; // 0x34(0x4)
	uint32_t destroyVehicleNum; // 0x38(0x4)
	uint32_t add_exp; // 0x3C(0x4)
	uint32_t add_gold; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	uint64_t battle_id; // 0x48(0x8)
	uint32_t max_game_num; // 0x50(0x4)
	uint32_t person_rank; // 0x54(0x4)
	uint32_t team_rank; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct TArray<struct FMemBTResultData> BP_ARRAY_TeammateList; // 0x60(0x10)
	struct FResultRatingData BP_STRUCT_BTRating; // 0x70(0x18)
};

// Object: ScriptStruct Gameplay.ResultRatingData
// Size: 0x18 (Inherited: 0x0)
struct FResultRatingData
{
	int rank_rating; // 0x0(0x4)
	int kill_rating; // 0x4(0x4)
	int win_rating; // 0x8(0x4)
	int change_rank_rating; // 0xC(0x4)
	int change_kill_rating; // 0x10(0x4)
	int change_win_rating; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.MemBTResultData
// Size: 0x58 (Inherited: 0x0)
struct FMemBTResultData
{
	struct FString Name; // 0x0(0x10)
	uint32_t Kill; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString State; // 0x18(0x10)
	float travelDistance; // 0x28(0x4)
	float DamageAmount; // 0x2C(0x4)
	float surviveTime; // 0x30(0x4)
	uint32_t AssistNum; // 0x34(0x4)
	uint32_t HeadShotNum; // 0x38(0x4)
	uint32_t rescueTimes; // 0x3C(0x4)
	float HealAmount; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	uint64_t UID; // 0x48(0x8)
	uint8_t ShouldShowAddFriendBtn; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
};

// Object: ScriptStruct Gameplay.DIYVehicleParamData
// Size: 0x28 (Inherited: 0x0)
struct FDIYVehicleParamData
{
	int TexPathID; // 0x0(0x4)
	struct FVector Location; // 0x4(0xC)
	struct FVector Normal; // 0x10(0xC)
	float Rotation; // 0x1C(0x4)
	float Scale; // 0x20(0x4)
	bool Mirror; // 0x24(0x1)
	bool bEnableDepthCompare; // 0x25(0x1)
	uint8_t Pad_0x26[0x2]; // 0x26(0x2)
};

// Object: ScriptStruct Gameplay.VehCharAnimData
// Size: 0x40 (Inherited: 0x0)
struct FVehCharAnimData
{
	enum class ECharacterVehicleAnimType VehAnimType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UAnimationAsset* VehAnimSoftPtr; // 0x8(0x28)
	uint8_t Pad_0x30[0x10]; // 0x30(0x10)
};

// Object: ScriptStruct Gameplay.LobbyCharacterWeaponAnimData
// Size: 0x28 (Inherited: 0x0)
struct FLobbyCharacterWeaponAnimData
{
	enum class ELobbyCharacterPosIndex PosIndex; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString CharPosName; // 0x8(0x10)
	struct TArray<struct FLobbyCharacterGenderWeaponAnimData> GenderWeaponAnimList; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.LobbyCharacterGenderWeaponAnimData
// Size: 0x78 (Inherited: 0x0)
struct FLobbyCharacterGenderWeaponAnimData
{
	enum class ELobbyCharacterAnimType GenderType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString GenderTypeName; // 0x8(0x10)
	struct UAnimationAsset* WeaponAnimSoftPtr; // 0x18(0x28)
	struct UAnimationAsset* WeaponAddAnimSoftPtr; // 0x40(0x28)
	struct TArray<struct UAnimationAsset*> WeaponPlayAnimSoftPtrArray; // 0x68(0x10)
};

// Object: ScriptStruct Gameplay.GridGeneratorSpawnData
// Size: 0x10 (Inherited: 0x0)
struct FGridGeneratorSpawnData
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	int UniqueId; // 0x8(0x4)
	uint8_t RegionSize; // 0xC(0x1)
	bool bBeforeFighting; // 0xD(0x1)
	bool bDontTrigger; // 0xE(0x1)
	uint8_t Pad_0xF[0x1]; // 0xF(0x1)
};

// Object: ScriptStruct Gameplay.SpotGroupProperty
// Size: 0x28 (Inherited: 0x0)
struct FSpotGroupProperty
{
	enum class ESpotGroupType SpotGroupType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int SpotGroupPercent; // 0x4(0x4)
	struct TArray<struct FSpotTypeProperty> SpotTypeProperties; // 0x8(0x10)
	bool bRepeatGenerateItem; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	float RepeatGenerateItemCDMin; // 0x1C(0x4)
	float RepeatGenerateItemCDMax; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.SpotTypeProperty
// Size: 0x38 (Inherited: 0x0)
struct FSpotTypeProperty
{
	enum class ESpotType SpotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int SpotPercentMin; // 0x4(0x4)
	int SpotPercentMax; // 0x8(0x4)
	int SpotPercentDot; // 0xC(0x4)
	int ItemPerSpotMin; // 0x10(0x4)
	int ItemPerSpotMax; // 0x14(0x4)
	struct TArray<struct FSpotWeight> WeightsPerValue; // 0x18(0x10)
	struct TArray<struct FSpotWeight> WeightsPerCategory; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.SpotWeight
// Size: 0x18 (Inherited: 0x0)
struct FSpotWeight
{
	struct FString Name; // 0x0(0x10)
	int Weight; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.ItemGenerateSpawnData
// Size: 0x68 (Inherited: 0x0)
struct FItemGenerateSpawnData
{
	int KeyID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString ItemValue; // 0x8(0x10)
	struct FString ItemCategory; // 0x18(0x10)
	int ItemWeight; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString ItemPath; // 0x30(0x10)
	int ItemStackCount; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FString ItemTogetherPath; // 0x48(0x10)
	int ItemTogetherStackCount; // 0x58(0x4)
	int ItemTogetherCountMin; // 0x5C(0x4)
	int ItemTogetherCountMax; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
};

// Object: ScriptStruct Gameplay.AIStrategyInfo
// Size: 0x38 (Inherited: 0x0)
struct FAIStrategyInfo
{
	int64_t TS; // 0x0(0x8)
	uint8_t circle; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	uint64_t BattleID; // 0x10(0x8)
	int MapID; // 0x18(0x4)
	int rai; // 0x1C(0x4)
	int fai; // 0x20(0x4)
	int Zone; // 0x24(0x4)
	struct TArray<struct FAIstrategyPlayerTeam> Teams; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.AIstrategyPlayerTeam
// Size: 0x20 (Inherited: 0x0)
struct FAIstrategyPlayerTeam
{
	struct TArray<struct FAIstrategyPlayerInfo> teamMember; // 0x0(0x10)
	struct TArray<struct FString> countries; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.AIstrategyPlayerInfo
// Size: 0x10 (Inherited: 0x0)
struct FAIstrategyPlayerInfo
{
	struct TArray<uint64_t> PlayerInfo; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.SpecialPickInfo
// Size: 0xC (Inherited: 0x0)
struct FSpecialPickInfo
{
	int item_id; // 0x0(0x4)
	int cur_count; // 0x4(0x4)
	int total_count; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.IncNetArray
// Size: 0x20 (Inherited: 0x0)
struct FIncNetArray
{
	struct TArray<struct FNetArrayUnit> IncArray; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.NetArrayUnit
// Size: 0x50 (Inherited: 0x0)
struct FNetArrayUnit
{
	struct FBattleItemNet Unit; // 0x0(0x48)
	bool bMarkDelete; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: ScriptStruct Gameplay.BattleItemNet
// Size: 0x48 (Inherited: 0x0)
struct FBattleItemNet
{
	struct FItemDefineID DefineID; // 0x0(0x18)
	int Count; // 0x18(0x4)
	bool bEquipping; // 0x1C(0x1)
	uint8_t ItemStoreArea; // 0x1D(0x1)
	uint8_t Pad_0x1E[0x2]; // 0x1E(0x2)
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // 0x20(0x10)
	struct TArray<struct FItemAssociation> Associations; // 0x30(0x10)
	int Durability; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct Gameplay.WorldTileSpotArray
// Size: 0x18 (Inherited: 0x0)
struct FWorldTileSpotArray
{
	int WorldCompositionID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct USpotSceneComponent*> AllSpotComponents; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GroupSpotComponentArray
// Size: 0x18 (Inherited: 0x0)
struct FGroupSpotComponentArray
{
	enum class ESpotGroupType GroupType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct UGroupSpotSceneComponent*> AllGroupComponents; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.PlayerAvatarData
// Size: 0x18 (Inherited: 0x1)
struct FPlayerAvatarData : FResponResult
{
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct FAvatarBackpack> AvatarBackpackData; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.AvatarBackpack
// Size: 0x20 (Inherited: 0x0)
struct FAvatarBackpack
{
	struct TArray<int> WeaponAvatarList; // 0x0(0x10)
	struct TArray<int> VehicleAvatarList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.PlayerInfoData
// Size: 0xE8 (Inherited: 0x1)
struct FPlayerInfoData : FResponResult
{
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString PlayerType; // 0x8(0x10)
	struct FString PlayerName; // 0x18(0x10)
	uint32_t PlayerKey; // 0x28(0x4)
	bool bIsGM; // 0x2C(0x1)
	uint8_t PlayerGender; // 0x2D(0x1)
	uint8_t Pad_0x2E[0x2]; // 0x2E(0x2)
	int TeamID; // 0x30(0x4)
	bool UsePlayerInfoTeamID; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	int64_t Campid; // 0x38(0x8)
	int PlayerBornPointID; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct TArray<struct FGameModePlayerItem> ItemList; // 0x48(0x10)
	struct TArray<struct FGameModePlayerExpressionItem> ExpressionItemList; // 0x58(0x10)
	struct FGameModePlayerEquipmentAvatar EquipmentAvatar; // 0x68(0x30)
	struct TArray<struct FGameModePlayerRolewearInfo> AllWear; // 0x98(0x10)
	struct FGameModePlayerUpassInfo UpassInfo; // 0xA8(0x38)
	int planeAvatarId; // 0xE0(0x4)
	int RolewearIndex; // 0xE4(0x4)
};

// Object: ScriptStruct Gameplay.GenerateMonsterFlow
// Size: 0x28 (Inherited: 0x0)
struct FGenerateMonsterFlow
{
	struct FString BattleID; // 0x0(0x10)
	int BattleMode; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FGenerateMonsterPhaseFlow> GenerateMonsterPhaseList; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.GenerateMonsterPhaseFlow
// Size: 0x18 (Inherited: 0x0)
struct FGenerateMonsterPhaseFlow
{
	int WeatherID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FGenerateOneMonsterFlow> GenerateOneMonsterFlowList; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GenerateOneMonsterFlow
// Size: 0x10 (Inherited: 0x0)
struct FGenerateOneMonsterFlow
{
	int MonsterID; // 0x0(0x4)
	int GenerateNum; // 0x4(0x4)
	int DeadNum; // 0x8(0x4)
	int KilledByPlayerNum; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GameModeParams
// Size: 0x10 (Inherited: 0x0)
struct FGameModeParams
{
	struct FName CurrentGameModeState; // 0x0(0x8)
	int MaxKillTime; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.CharacterStateChangedParams
// Size: 0x18 (Inherited: 0x0)
struct FCharacterStateChangedParams
{
	struct FPlayerID PlayerID; // 0x0(0x10)
	struct FName CharacterState; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.PlayerID
// Size: 0x10 (Inherited: 0x0)
struct FPlayerID
{
	struct FName PlayerType; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.DSPlayerTeamParams
// Size: 0x18 (Inherited: 0x0)
struct FDSPlayerTeamParams
{
	struct FPlayerID PlayerID; // 0x0(0x10)
	int TeamID; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.PlayerStateChangedParams
// Size: 0x38 (Inherited: 0x0)
struct FPlayerStateChangedParams
{
	struct FPlayerID PlayerID; // 0x0(0x10)
	struct FName PlayerState; // 0x10(0x8)
	struct FString Reason; // 0x18(0x10)
	struct FString BanMsg; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.GameModePatchTableData
// Size: 0x140 (Inherited: 0x0)
struct FGameModePatchTableData
{
	struct TMap<int, struct FItemTableStruct> Item; // 0x0(0x50)
	struct TMap<int, struct FPickUpCountSettingTableStruct> PickUpCountSetting; // 0x50(0x50)
	struct TMap<int, struct FBackpackMappingTableStruct> BackpackMapping; // 0xA0(0x50)
	struct TMap<int, struct FWeaponAttachmentsTableStruct> WeaponAttachments; // 0xF0(0x50)
};

// Object: ScriptStruct Gameplay.WeaponAttachmentsTableStruct
// Size: 0x7C (Inherited: 0x0)
struct FWeaponAttachmentsTableStruct
{
	int KeyID; // 0x0(0x4)
	int Muzzle1ID; // 0x4(0x4)
	int Muzzle2ID; // 0x8(0x4)
	int Muzzle3ID; // 0xC(0x4)
	int Muzzle4ID; // 0x10(0x4)
	int Muzzle5ID; // 0x14(0x4)
	int Muzzle6ID; // 0x18(0x4)
	int Upper1ID; // 0x1C(0x4)
	int Upper2ID; // 0x20(0x4)
	int Upper3ID; // 0x24(0x4)
	int Upper4ID; // 0x28(0x4)
	int Upper5ID; // 0x2C(0x4)
	int Upper6ID; // 0x30(0x4)
	int Upper7ID; // 0x34(0x4)
	int Stock1ID; // 0x38(0x4)
	int Stock2ID; // 0x3C(0x4)
	int Magazine1ID; // 0x40(0x4)
	int Magazine2ID; // 0x44(0x4)
	int Magazine3ID; // 0x48(0x4)
	int Magazine4ID; // 0x4C(0x4)
	int Magazine5ID; // 0x50(0x4)
	int Magazine6ID; // 0x54(0x4)
	int Lower1ID; // 0x58(0x4)
	int Lower2ID; // 0x5C(0x4)
	int Lower3ID; // 0x60(0x4)
	int Lower4ID; // 0x64(0x4)
	int Lower5ID; // 0x68(0x4)
	int BulletID; // 0x6C(0x4)
	int ProposeBulletNum; // 0x70(0x4)
	int AIMinAttackDist; // 0x74(0x4)
	int AIMaxAttackDist; // 0x78(0x4)
};

// Object: ScriptStruct Gameplay.BackpackMappingTableStruct
// Size: 0x20 (Inherited: 0x0)
struct FBackpackMappingTableStruct
{
	int SkinID; // 0x0(0x4)
	int ItemIDLv1; // 0x4(0x4)
	int ItemIDLv2; // 0x8(0x4)
	int ItemIDLv3; // 0xC(0x4)
	int SkinItemIDLv1; // 0x10(0x4)
	int SkinItemIDLv2; // 0x14(0x4)
	int SkinItemIDLv3; // 0x18(0x4)
	int LobbyShowItemID; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.PickUpCountSettingTableStruct
// Size: 0x8 (Inherited: 0x0)
struct FPickUpCountSettingTableStruct
{
	int ItemId; // 0x0(0x4)
	int PickUpMaxCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.ItemTableStruct
// Size: 0xB0 (Inherited: 0x0)
struct FItemTableStruct
{
	int ItemId; // 0x0(0x4)
	int itemType; // 0x4(0x4)
	int ItemSubType; // 0x8(0x4)
	int BPID; // 0xC(0x4)
	int Durability; // 0x10(0x4)
	int AIFullVaule; // 0x14(0x4)
	bool Equippable; // 0x18(0x1)
	bool Consumable; // 0x19(0x1)
	bool AutoEquipandDrop; // 0x1A(0x1)
	uint8_t Pad_0x1B[0x1]; // 0x1B(0x1)
	int MaxCount; // 0x1C(0x4)
	int WeightforOrder; // 0x20(0x4)
	int UnitWeight_f; // 0x24(0x4)
	int RedEmotionFightId; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct FString PickupSound; // 0x30(0x10)
	struct FString DropSound; // 0x40(0x10)
	struct FString EquipSound; // 0x50(0x10)
	struct FString UnEquipSound; // 0x60(0x10)
	struct FString PickUpBank; // 0x70(0x10)
	struct FString DropBank; // 0x80(0x10)
	struct FString EquipBank; // 0x90(0x10)
	struct FString UnEquipBank; // 0xA0(0x10)
};

// Object: ScriptStruct Gameplay.DSNetSaturateResult
// Size: 0x10 (Inherited: 0x0)
struct FDSNetSaturateResult
{
	float SaturateTime; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	uint64_t SaturateFrames; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.VehicleMoveDragDataFriendly
// Size: 0x20 (Inherited: 0x0)
struct FVehicleMoveDragDataFriendly
{
	struct TArray<struct FVehicleMoveDragFriendly> MoveDrag; // 0x0(0x10)
	struct TArray<struct FVehicleMoveDragFriendly> SimulatedMoveDrag; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.VehicleMoveDragFriendly
// Size: 0x58 (Inherited: 0x0)
struct FVehicleMoveDragFriendly
{
	int Minute; // 0x0(0x4)
	uint8_t VehicleType; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct TMap<uint8_t, int> Counters; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.VehicleProtectionReportData
// Size: 0x60 (Inherited: 0x0)
struct FVehicleProtectionReportData
{
	uint8_t VehicleType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TMap<uint8_t, int> Counters; // 0x8(0x50)
	bool FromClient; // 0x58(0x1)
	uint8_t Pad_0x59[0x7]; // 0x59(0x7)
};

// Object: ScriptStruct Gameplay.VehicleCorrectionData
// Size: 0x58 (Inherited: 0x0)
struct FVehicleCorrectionData
{
	uint8_t VehicleType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TMap<uint8_t, int> Counters; // 0x8(0x50)
};

// Object: ScriptStruct Gameplay.CharacterShootVerifyStat
// Size: 0x50 (Inherited: 0x0)
struct FCharacterShootVerifyStat
{
	struct TMap<uint8_t, int> ShootVerifyStat; // 0x0(0x50)
};

// Object: ScriptStruct Gameplay.CharacterShootVerifyData
// Size: 0x50 (Inherited: 0x0)
struct FCharacterShootVerifyData
{
	struct TMap<uint8_t, int> ShootVerifyFailed; // 0x0(0x50)
};

// Object: ScriptStruct Gameplay.ParachuteDragData
// Size: 0x8 (Inherited: 0x0)
struct FParachuteDragData
{
	uint32_t MyDrag; // 0x0(0x4)
	uint32_t OtherDrag; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.CharacterMoveDragData
// Size: 0x20 (Inherited: 0x0)
struct FCharacterMoveDragData
{
	struct TArray<struct FCharacterMoveDrag> Drag; // 0x0(0x10)
	struct TArray<struct FCharacterSimulateMoveDrag> SimulateDrag; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.CharacterSimulateMoveDrag
// Size: 0x10 (Inherited: 0x0)
struct FCharacterSimulateMoveDrag
{
	int Minute; // 0x0(0x4)
	int Count; // 0x4(0x4)
	int DragCount; // 0x8(0x4)
	int ShakeCount; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.CharacterMoveDrag
// Size: 0x68 (Inherited: 0x0)
struct FCharacterMoveDrag
{
	int Minute; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TMap<uint8_t, int> ReasonCount; // 0x8(0x50)
	struct TArray<struct FDistanceDragData> ExceedsDistances; // 0x58(0x10)
};

// Object: ScriptStruct Gameplay.DistanceDragData
// Size: 0x18 (Inherited: 0x0)
struct FDistanceDragData
{
	float CX; // 0x0(0x4)
	float CY; // 0x4(0x4)
	float CZ; // 0x8(0x4)
	float SX; // 0xC(0x4)
	float SY; // 0x10(0x4)
	float sz; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.VehicleAvatarReplaceCfg
// Size: 0x30 (Inherited: 0x0)
struct FVehicleAvatarReplaceCfg
{
	int OriginID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<int> SkinIDList; // 0x8(0x10)
	struct TArray<float> ProbabilityDistribute; // 0x18(0x10)
	int MaxNum; // 0x28(0x4)
	int CurrentNum; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.GameModeIslandParams
// Size: 0x14 (Inherited: 0x0)
struct FGameModeIslandParams
{
	int IslandDefaultLifeTime; // 0x0(0x4)
	int IslandSpecialLifeTime; // 0x4(0x4)
	int IslandMinimumPlayerNum; // 0x8(0x4)
	int IslandMinimumAliveTime; // 0xC(0x4)
	int IslandInactivePlayerKickoutTime; // 0x10(0x4)
};

// Object: ScriptStruct Gameplay.DynamicBattleRankInfo
// Size: 0x10 (Inherited: 0x0)
struct FDynamicBattleRankInfo
{
	int BattleRank; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	uint64_t PlayerUID; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.InfectionRoundTlogData
// Size: 0xE8 (Inherited: 0x0)
struct FInfectionRoundTlogData
{
	int Round; // 0x0(0x4)
	int WinCamp; // 0x4(0x4)
	float PlayTime; // 0x8(0x4)
	bool bSpawnRevenger; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	float RevengerExistTime; // 0x10(0x4)
	int RevengerDoSkillCount; // 0x14(0x4)
	int ZombieReviveCount; // 0x18(0x4)
	int NormalZombieDoSkillCount; // 0x1C(0x4)
	int InvisibleZombieDoSkillCount; // 0x20(0x4)
	int ThrowerZombieDoSkillCount; // 0x24(0x4)
	int MotherZombieDoSkillCount; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FInfectionPlayerDeadTlogData> DeadList; // 0x30(0x10)
	int NormalZombieChooseTimes; // 0x40(0x4)
	int InvisibleZombieChooseTimes; // 0x44(0x4)
	struct TArray<int> ZombieLevelList; // 0x48(0x10)
	struct TArray<int> EnhancerUserList; // 0x58(0x10)
	struct TArray<struct FInfectionSpringUseData> SpringUseList; // 0x68(0x10)
	struct TMap<int, struct FInfectionRoundTlogGuidData> GuidCount; // 0x78(0x50)
	int PlayerNumber; // 0xC8(0x4)
	float ZombieAbsorbingTime; // 0xCC(0x4)
	float RevengerAbsorbingTime; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct TArray<struct FInfectionRoundPlayerTlogData> playerList; // 0xD8(0x10)
};

// Object: ScriptStruct Gameplay.InfectionRoundPlayerTlogData
// Size: 0xF8 (Inherited: 0x0)
struct FInfectionRoundPlayerTlogData
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	struct FString Country; // 0x58(0x10)
	uint64_t CharacterID; // 0x68(0x8)
	int64_t ClientStartTime; // 0x70(0x8)
	uint32_t PlayerKey; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	uint64_t RoleID; // 0x80(0x8)
	uint8_t RoleType; // 0x88(0x1)
	uint8_t RoleTypeEnd; // 0x89(0x1)
	uint8_t Pad_0x8A[0x2]; // 0x8A(0x2)
	uint32_t RoleTypeSwitchTime; // 0x8C(0x4)
	float PlayerJumpHeightMax; // 0x90(0x4)
	float PlayerJumpSpeedMax; // 0x94(0x4)
	uint32_t PlayerMoveDistance; // 0x98(0x4)
	uint32_t PlayerMoveTime; // 0x9C(0x4)
	struct TArray<float> PlayerMoveSpeedArray; // 0xA0(0x10)
	uint32_t PlayerKilled; // 0xB0(0x4)
	uint32_t PlayerHurtCount; // 0xB4(0x4)
	uint32_t PlayerDamageCount; // 0xB8(0x4)
	uint32_t KillingCount; // 0xBC(0x4)
	uint32_t AssistCount; // 0xC0(0x4)
	uint32_t GunKillingTimes; // 0xC4(0x4)
	uint32_t HeadshotCounts; // 0xC8(0x4)
	float DamageAmount; // 0xCC(0x4)
	uint32_t GunHitTimes; // 0xD0(0x4)
	uint32_t GunShotTimes; // 0xD4(0x4)
	uint32_t MovingDistance; // 0xD8(0x4)
	uint32_t HealAmount; // 0xDC(0x4)
	uint32_t CureCount; // 0xE0(0x4)
	uint32_t CareRoundCheckUp; // 0xE4(0x4)
	uint32_t KillZombiesCount; // 0xE8(0x4)
	uint32_t KillHumanCount; // 0xEC(0x4)
	float Damage4Avenger; // 0xF0(0x4)
	int Headshot4Avenger; // 0xF4(0x4)
};

// Object: ScriptStruct Gameplay.InfectionRoundTlogGuidData
// Size: 0xC (Inherited: 0x0)
struct FInfectionRoundTlogGuidData
{
	int GuidTriggerCount; // 0x0(0x4)
	int GuidHandCloseCount; // 0x4(0x4)
	int GuidArriveCloseCount; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.InfectionSpringUseData
// Size: 0x1C (Inherited: 0x0)
struct FInfectionSpringUseData
{
	int SpringTag; // 0x0(0x4)
	int NormalPlayerUseTimes; // 0x4(0x4)
	int AvengerPlayerUseTimes; // 0x8(0x4)
	int MotherZombieUseTimes; // 0xC(0x4)
	int NormalZombieUseTimes; // 0x10(0x4)
	int InvisibleZombieUseTimes; // 0x14(0x4)
	int ThrowerZombieUseTimes; // 0x18(0x4)
};

// Object: ScriptStruct Gameplay.InfectionPlayerDeadTlogData
// Size: 0x20 (Inherited: 0x0)
struct FInfectionPlayerDeadTlogData
{
	int DeadPawnSubType; // 0x0(0x4)
	float DeadPosiX; // 0x4(0x4)
	float DeadPosiY; // 0x8(0x4)
	float DeadPosiZ; // 0xC(0x4)
	int KillPawnSubType; // 0x10(0x4)
	float KillPosiX; // 0x14(0x4)
	float KillPosiY; // 0x18(0x4)
	float KillPosiZ; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.InfectionZombieLevelData
// Size: 0x8 (Inherited: 0x0)
struct FInfectionZombieLevelData
{
	int Level; // 0x0(0x4)
	int Num; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.InfectionBattleResultData
// Size: 0x28 (Inherited: 0x0)
struct FInfectionBattleResultData
{
	struct TArray<struct FInfectionPlayerBattleResultData> playerList; // 0x0(0x10)
	int PlayTime; // 0x10(0x4)
	int KillZombieNum; // 0x14(0x4)
	int InfectedHumanNum; // 0x18(0x4)
	int BecomeHeroNum; // 0x1C(0x4)
	uint64_t EscapePlayerUid; // 0x20(0x8)
};

// Object: ScriptStruct Gameplay.InfectionPlayerBattleResultData
// Size: 0x88 (Inherited: 0x0)
struct FInfectionPlayerBattleResultData
{
	uint64_t UID; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString PlayerName; // 0x10(0x10)
	int PlayerScore; // 0x20(0x4)
	int Rank; // 0x24(0x4)
	int Kills; // 0x28(0x4)
	int Infections; // 0x2C(0x4)
	int DamageAmount; // 0x30(0x4)
	int RoundNum; // 0x34(0x4)
	float GamePlayTime; // 0x38(0x4)
	int BeMatrixMonsterTimes; // 0x3C(0x4)
	int BeRevengerPlayerTimes; // 0x40(0x4)
	int RevengerPlayerKillWinTimes; // 0x44(0x4)
	int BeMonsterWinTimes; // 0x48(0x4)
	int BePersonWinTimes; // 0x4C(0x4)
	int UseSpringJumpTimes; // 0x50(0x4)
	int UseEnhancerTimes; // 0x54(0x4)
	int DamageToMonster; // 0x58(0x4)
	int DamageToRevengerPlayer; // 0x5C(0x4)
	int ChooseZombieFirstTimes; // 0x60(0x4)
	int ChooseZombieSecondTimes; // 0x64(0x4)
	float TotalDamage; // 0x68(0x4)
	float TotalSprintDistance; // 0x6C(0x4)
	int OpenAirDropBoxesNum; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct TArray<struct FString> KillFlow; // 0x78(0x10)
};

// Object: ScriptStruct Gameplay.VehicleBattleResultData
// Size: 0x68 (Inherited: 0x0)
struct FVehicleBattleResultData
{
	struct TArray<struct FVehiclePlayerBattleResultData> playerList; // 0x0(0x10)
	struct TArray<struct FVehicleCampKills> VehicleCampKills; // 0x10(0x10)
	int WinCampID; // 0x20(0x4)
	float GamePlayTime; // 0x24(0x4)
	int MatchPointNum; // 0x28(0x4)
	int WinCampTreasureScore; // 0x2C(0x4)
	int FailCampTreasureScore; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<struct FVehicleBattleVehicleStatiscs> VehicleStaticsList; // 0x38(0x10)
	struct TArray<struct FVehicleBattleWeaponStatiscs> WeaponStatiscsList; // 0x48(0x10)
	int VehicleStuckResetTimes; // 0x58(0x4)
	int HealthPropItemTimes; // 0x5C(0x4)
	int NormalPropItemTimes; // 0x60(0x4)
	int SuperPropItemTimes; // 0x64(0x4)
};

// Object: ScriptStruct Gameplay.VehicleBattleWeaponStatiscs
// Size: 0x10 (Inherited: 0x0)
struct FVehicleBattleWeaponStatiscs
{
	int WeaponId; // 0x0(0x4)
	int ChooseTimes; // 0x4(0x4)
	int TotalDamage; // 0x8(0x4)
	int Kills; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.VehicleBattleVehicleStatiscs
// Size: 0x18 (Inherited: 0x0)
struct FVehicleBattleVehicleStatiscs
{
	int VehicleID; // 0x0(0x4)
	int ChooseTimes; // 0x4(0x4)
	int DeadTimes; // 0x8(0x4)
	int Kills; // 0xC(0x4)
	float VehicleWeaponDamage; // 0x10(0x4)
	float HitDamage; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.VehicleCampKills
// Size: 0x8 (Inherited: 0x0)
struct FVehicleCampKills
{
	int Campid; // 0x0(0x4)
	int Kills; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.VehiclePlayerBattleResultData
// Size: 0x98 (Inherited: 0x0)
struct FVehiclePlayerBattleResultData
{
	uint64_t UID; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString PlayerName; // 0x10(0x10)
	int TeamID; // 0x20(0x4)
	int Campid; // 0x24(0x4)
	int Score; // 0x28(0x4)
	int Distance; // 0x2C(0x4)
	int KillNum; // 0x30(0x4)
	int AssistKillNum; // 0x34(0x4)
	int DriverKillNum; // 0x38(0x4)
	int ShooterKillNum; // 0x3C(0x4)
	int BeKillNum; // 0x40(0x4)
	int TeamKillNum; // 0x44(0x4)
	int GetItemNum; // 0x48(0x4)
	int OpenTreasureNum; // 0x4C(0x4)
	int ShootTreasureNum; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<struct FUseItemFlow> UseItemFlow; // 0x58(0x10)
	int StrikeKillVehicleNum; // 0x68(0x4)
	int ItemKillVehicleNum; // 0x6C(0x4)
	int GunKillVehicleNum; // 0x70(0x4)
	float CauseDamage; // 0x74(0x4)
	int GemStoneCount; // 0x78(0x4)
	bool HasFinished; // 0x7C(0x1)
	uint8_t Pad_0x7D[0x3]; // 0x7D(0x3)
	float FinishedTime; // 0x80(0x4)
	bool IsEscape; // 0x84(0x1)
	uint8_t Pad_0x85[0x3]; // 0x85(0x3)
	int VehicleID; // 0x88(0x4)
	int VehicleShapeType; // 0x8C(0x4)
	float ExitPlayerPlayTime; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
};

// Object: ScriptStruct Gameplay.VehicleReportList
// Size: 0x10 (Inherited: 0x0)
struct FVehicleReportList
{
	struct TArray<struct FVehicleReportEntry> VehicleReports; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.VehicleReportEntry
// Size: 0x18 (Inherited: 0x0)
struct FVehicleReportEntry
{
	uint32_t VehicleID; // 0x0(0x4)
	int VehicleShapeType; // 0x4(0x4)
	bool IsDestroyed; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float FirstAttackedTime; // 0xC(0x4)
	float LastAttackedTime; // 0x10(0x4)
	bool Drived; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
};

// Object: ScriptStruct Gameplay.AIProxyNetInfo
// Size: 0x8 (Inherited: 0x0)
struct FAIProxyNetInfo
{
	uint32_t MaxBufferUsedSize; // 0x0(0x4)
	float MaxSendSpeed; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.AntiCheatDetailData
// Size: 0x28 (Inherited: 0x0)
struct FAntiCheatDetailData
{
	uint16_t AreaID; // 0x0(0x2)
	uint8_t PlatID; // 0x2(0x1)
	uint8_t Pad_0x3[0x5]; // 0x3(0x5)
	struct FString ZoneID; // 0x8(0x10)
	struct TArray<struct FWeaponAntiData> WeaponAntiDataList; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.WeaponAntiData
// Size: 0x18 (Inherited: 0x0)
struct FWeaponAntiData
{
	uint16_t MuzzleFloorHeight; // 0x0(0x2)
	int16_t MuzzleActorHeadHeight; // 0x2(0x2)
	uint16_t ImplactPointAndActorDis; // 0x4(0x2)
	uint16_t ImplactPointAndBulletDis; // 0x6(0x2)
	uint16_t ImplactPoinPosChange; // 0x8(0x2)
	uint16_t BulletAndGunAngle; // 0xA(0x2)
	uint16_t NetDelay; // 0xC(0x2)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	uint32_t ShooterPosDis; // 0x10(0x4)
	uint32_t VictmPosDis; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.AntiMoveCheatFlow
// Size: 0x28 (Inherited: 0x0)
struct FAntiMoveCheatFlow
{
	uint16_t AreaID; // 0x0(0x2)
	uint8_t PlatID; // 0x2(0x1)
	uint8_t Pad_0x3[0x5]; // 0x3(0x5)
	struct FString ZoneID; // 0x8(0x10)
	int CheatType1; // 0x18(0x4)
	int CheatType2; // 0x1C(0x4)
	int CheatType3; // 0x20(0x4)
	float Ping; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.AntiCheatMovementRawData
// Size: 0x18 (Inherited: 0x0)
struct FAntiCheatMovementRawData
{
	int16_t MinVelocity; // 0x0(0x2)
	int16_t MaxVelocity; // 0x2(0x2)
	int16_t AvgVelocity; // 0x4(0x2)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	uint64_t PlayerStatus; // 0x8(0x8)
	int16_t PlayerPing; // 0x10(0x2)
	uint8_t SpecialFlags; // 0x12(0x1)
	uint8_t Pad_0x13[0x5]; // 0x13(0x5)
};

// Object: ScriptStruct Gameplay.ZNQBattleResultData
// Size: 0x4C (Inherited: 0x0)
struct FZNQBattleResultData
{
	int DuckGameCount; // 0x0(0x4)
	int BeeGameCount; // 0x4(0x4)
	int BlindBoxCount; // 0x8(0x4)
	int DuckShootingRangeCount; // 0xC(0x4)
	int ActivedDuckGameNum; // 0x10(0x4)
	int ActivedBeeGameNum; // 0x14(0x4)
	int ActivedBlindBoxNum; // 0x18(0x4)
	int ActivedDuckShootingRangeNum; // 0x1C(0x4)
	int MaxCoinCarried; // 0x20(0x4)
	int ParachutePlaygroundPlayer; // 0x24(0x4)
	int DuckGameHighCount; // 0x28(0x4)
	int DuckGameMiddleCount; // 0x2C(0x4)
	int DuckGameLowCount; // 0x30(0x4)
	int BeeGameHighCount; // 0x34(0x4)
	int BeeGameMiddleCount; // 0x38(0x4)
	int BeeGameLowCount; // 0x3C(0x4)
	int DuckShootingRangeHighCount; // 0x40(0x4)
	int DuckShootingRangeMiddleCount; // 0x44(0x4)
	int DuckShootingRangeLowCount; // 0x48(0x4)
};

// Object: ScriptStruct Gameplay.HardPointBattleResultData
// Size: 0x28 (Inherited: 0x0)
struct FHardPointBattleResultData
{
	float HardPointEnterOccupiedStateMaxTime; // 0x0(0x4)
	int TotalPoint; // 0x4(0x4)
	struct TArray<struct FTLog_HardPointActorFlow> HardPointActorFlowList; // 0x8(0x10)
	struct TArray<struct FHardPointTeamBattleResultData> TeamResultDatas; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.HardPointTeamBattleResultData
// Size: 0x18 (Inherited: 0x0)
struct FHardPointTeamBattleResultData
{
	int TeamID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FHardPointPlayerBattleResultData> TeamPlayerResultDatas; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.HardPointPlayerBattleResultData
// Size: 0x30 (Inherited: 0x0)
struct FHardPointPlayerBattleResultData
{
	uint64_t UID; // 0x0(0x8)
	int OccupyScore; // 0x8(0x4)
	float OccupyTime; // 0xC(0x4)
	int OccupyNum; // 0x10(0x4)
	float DamageToTheInHardPointEnemy; // 0x14(0x4)
	int PickUpWeaponBoxNum; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<struct FTLog_PickUpItemFlow> PickUpItemFlowData; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.TLog_HardPointActorFlow
// Size: 0x28 (Inherited: 0x0)
struct FTLog_HardPointActorFlow
{
	int HardPointID; // 0x0(0x4)
	float ActivatedTime; // 0x4(0x4)
	struct TArray<int> OccupiedTeamSequenceRecords; // 0x8(0x10)
	struct TArray<struct FHardPointActorTeamScoreResultData> TeamScoreDataList; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.HardPointActorTeamScoreResultData
// Size: 0x8 (Inherited: 0x0)
struct FHardPointActorTeamScoreResultData
{
	int TeamID; // 0x0(0x4)
	int Score; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.CharacterOverrideAttrData
// Size: 0x18 (Inherited: 0x0)
struct FCharacterOverrideAttrData
{
	struct FString AttrName; // 0x0(0x10)
	float AttrValue; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.StatueBaseData
// Size: 0x68 (Inherited: 0x0)
struct FStatueBaseData
{
	struct FString ClassPath; // 0x0(0x10)
	struct FString MatPath; // 0x10(0x10)
	struct FString TeamFlag; // 0x20(0x10)
	struct FString TeamName; // 0x30(0x10)
	struct FVector Loc; // 0x40(0xC)
	struct FRotator Rot; // 0x4C(0xC)
	struct FVector Scale; // 0x58(0xC)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
};

// Object: ScriptStruct Gameplay.SeasonStatueData
// Size: 0x78 (Inherited: 0x0)
struct FSeasonStatueData
{
	struct FString Name; // 0x0(0x10)
	struct FVector Loc; // 0x10(0xC)
	struct FRotator Rot; // 0x1C(0xC)
	struct FVector Scale; // 0x28(0xC)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FString Nation; // 0x38(0x10)
	int AGender; // 0x48(0x4)
	int Head; // 0x4C(0x4)
	int hair; // 0x50(0x4)
	int WeaponId; // 0x54(0x4)
	struct TArray<int> AvatarList; // 0x58(0x10)
	struct TArray<struct FGameModePlayerItem> AvatarWithAdditionList; // 0x68(0x10)
};

// Object: ScriptStruct Gameplay.DSCorpsInfo
// Size: 0x20 (Inherited: 0x0)
struct FDSCorpsInfo
{
	uint64_t CorpsID; // 0x0(0x8)
	struct FString CorpsName; // 0x8(0x10)
	int Icon; // 0x18(0x4)
	int SegmentLevel; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.DynamicTriggerConfig
// Size: 0x20 (Inherited: 0x0)
struct FDynamicTriggerConfig
{
	struct TArray<struct FDynamicTriggerTransform> Transforms; // 0x0(0x10)
	struct FString TriggerClassPath; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.DynamicTriggerTransform
// Size: 0x18 (Inherited: 0x0)
struct FDynamicTriggerTransform
{
	struct FVector Loc; // 0x0(0xC)
	struct FRotator Rot; // 0xC(0xC)
};

// Object: ScriptStruct Gameplay.MissionBoardConfig
// Size: 0x50 (Inherited: 0x0)
struct FMissionBoardConfig
{
	struct FString ResPath; // 0x0(0x10)
	struct FVector Loc; // 0x10(0xC)
	struct FRotator Rot; // 0x1C(0xC)
	struct FVector Scale; // 0x28(0xC)
	float Progress; // 0x34(0x4)
	struct FString CountOrTime; // 0x38(0x10)
	int TipId; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct Gameplay.AdvertisementActorConfig
// Size: 0x50 (Inherited: 0x0)
struct FAdvertisementActorConfig
{
	struct FString ResPath; // 0x0(0x10)
	struct FString HttpImgPath; // 0x10(0x10)
	struct FVector Loc; // 0x20(0xC)
	struct FRotator Rot; // 0x2C(0xC)
	struct FVector Scale; // 0x38(0xC)
	int ID; // 0x44(0x4)
	int CulDistance; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct Gameplay.DynamicLoadItem
// Size: 0x40 (Inherited: 0x0)
struct FDynamicLoadItem
{
	struct TArray<struct FDynamicBuildingGroupTransform> TransArray; // 0x0(0x10)
	int ActID; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString Path; // 0x18(0x10)
	bool IsClearAfterStart; // 0x28(0x1)
	bool IsPlayerStartPot; // 0x29(0x1)
	uint8_t Pad_0x2A[0x6]; // 0x2A(0x6)
	struct TArray<int> PosIdxList; // 0x30(0x10)
};

// Object: ScriptStruct Gameplay.DynamicBuildingGroupTransform
// Size: 0x18 (Inherited: 0x0)
struct FDynamicBuildingGroupTransform
{
	float LocX; // 0x0(0x4)
	float LocY; // 0x4(0x4)
	float LocZ; // 0x8(0x4)
	float RotX; // 0xC(0x4)
	float RotY; // 0x10(0x4)
	float RotZ; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.RoomCustomParams
// Size: 0x40 (Inherited: 0x0)
struct FRoomCustomParams
{
	int CircleSpeedMultiplicator; // 0x0(0x4)
	bool bAutoOpendoor; // 0x4(0x1)
	bool bAutoPickup; // 0x5(0x1)
	bool bAudioVisual; // 0x6(0x1)
	bool bShowSkull; // 0x7(0x1)
	bool bAutoAimAt; // 0x8(0x1)
	bool bGunRemoveBullet; // 0x9(0x1)
	uint8_t Pad_0xA[0x2]; // 0xA(0x2)
	int BlueCircleDamageMultiplicator; // 0xC(0x4)
	bool bUseFirstWhiteCircleDelayTime; // 0x10(0x1)
	bool bUseFirstSafeZoneAppearTime; // 0x11(0x1)
	bool bUseFirstWhiteCircleRadiusMultiplicator; // 0x12(0x1)
	uint8_t Pad_0x13[0x1]; // 0x13(0x1)
	int FirstWhiteCircleDelayTime; // 0x14(0x4)
	int FirstSafeZoneAppearTime; // 0x18(0x4)
	int FirstWhiteCircleRadiusMultiplicator; // 0x1C(0x4)
	bool EnableRedZone; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
	struct TArray<struct FCustomCircleParams> CustomCircleParamsList; // 0x28(0x10)
	bool bFuzzyInformation; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
};

// Object: ScriptStruct Gameplay.CustomCircleParams
// Size: 0x1C (Inherited: 0x0)
struct FCustomCircleParams
{
	int Stage; // 0x0(0x4)
	int delayTime; // 0x4(0x4)
	int SafeZoneAppeartime; // 0x8(0x4)
	int LastTime; // 0xC(0x4)
	int CircleDamage; // 0x10(0x4)
	int BlueCircleRadius; // 0x14(0x4)
	int WhiteCircleRadius; // 0x18(0x4)
};

// Object: ScriptStruct Gameplay.BattleCustomConfig
// Size: 0x18 (Inherited: 0x0)
struct FBattleCustomConfig
{
	struct FString Config; // 0x0(0x10)
	float Value; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.BattleData
// Size: 0x8 (Inherited: 0x0)
struct FBattleData
{
	int WatcherNum; // 0x0(0x4)
	int CircleNum; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.GameModeGameOverData
// Size: 0x1 (Inherited: 0x0)
struct FGameModeGameOverData
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Gameplay.GameModeTeamBattleResultData
// Size: 0xD8 (Inherited: 0x0)
struct FGameModeTeamBattleResultData
{
	struct FString Reason; // 0x0(0x10)
	int RemainTeamCount; // 0x10(0x4)
	int RemainAlivePlayerCount; // 0x14(0x4)
	float PlaneDirectionX; // 0x18(0x4)
	float PlaneDirectionY; // 0x1C(0x4)
	struct TMap<struct FString, struct FString> PlayersLogoutTime; // 0x20(0x50)
	struct TMap<struct FString, float> PlayersOnlineTime; // 0x70(0x50)
	struct TArray<struct FGameModeCorpsDetailData> RealTimeCorpsRank; // 0xC0(0x10)
	bool bIsGameTerminator; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
};

// Object: ScriptStruct Gameplay.GameModeCorpsDetailData
// Size: 0x30 (Inherited: 0x0)
struct FGameModeCorpsDetailData
{
	struct FString Name; // 0x0(0x10)
	int CorpsHeadIcon; // 0x10(0x4)
	int KilledNum; // 0x14(0x4)
	int SegmentLevel; // 0x18(0x4)
	int RealtimeRank; // 0x1C(0x4)
	int DefeatPlayerNum; // 0x20(0x4)
	float TotalDamage; // 0x24(0x4)
	float SurvivalTime; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.PlayerTotalWeaponsConfig
// Size: 0x18 (Inherited: 0x0)
struct FPlayerTotalWeaponsConfig
{
	int DefaultSelectedIndex; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FPlayerWeaponsConfig> WeaponsConfigList; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.PlayerWeaponsConfig
// Size: 0x20 (Inherited: 0x0)
struct FPlayerWeaponsConfig
{
	struct FString ConfigName; // 0x0(0x10)
	struct TArray<struct FSingleWeaponConfig> WeaponDataList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.SingleWeaponConfig
// Size: 0x18 (Inherited: 0x0)
struct FSingleWeaponConfig
{
	int WeaponId; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<int> AttachMentIDList; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.BornItem
// Size: 0xC (Inherited: 0x0)
struct FBornItem
{
	int BornItemID; // 0x0(0x4)
	int BornItemCount; // 0x4(0x4)
	int BornItemFlags; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.GameModePlayerItemPackInfo
// Size: 0x30 (Inherited: 0x0)
struct FGameModePlayerItemPackInfo
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	int Count; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	uint64_t InstanceID; // 0x10(0x8)
	int ItemDurability; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<struct FGameModePlayerItemAttachData> AttachList; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerItemAttachData
// Size: 0x10 (Inherited: 0x0)
struct FGameModePlayerItemAttachData
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	uint64_t InstanceID; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.GameModePlayerWeaponPackInfo
// Size: 0x30 (Inherited: 0x0)
struct FGameModePlayerWeaponPackInfo
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	int Count; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	uint64_t InstanceID; // 0x10(0x8)
	int WeaponDurability; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct TArray<struct FGameModePlayerWeaponAttachData> AttachList; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerWeaponAttachData
// Size: 0x10 (Inherited: 0x0)
struct FGameModePlayerWeaponAttachData
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	uint64_t InstanceID; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.GameModePlayerArmorPackInfo
// Size: 0x28 (Inherited: 0x0)
struct FGameModePlayerArmorPackInfo
{
	int ItemId; // 0x0(0x4)
	int Count; // 0x4(0x4)
	uint64_t InstanceID; // 0x8(0x8)
	int ItemDurability; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FGameModePlayerArmorAttachData> AttachList; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.GameModePlayerArmorAttachData
// Size: 0x10 (Inherited: 0x0)
struct FGameModePlayerArmorAttachData
{
	int SlotIndex; // 0x0(0x4)
	int ItemId; // 0x4(0x4)
	uint64_t InstanceID; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.SocialIslandGameResult
// Size: 0x70 (Inherited: 0x0)
struct FSocialIslandGameResult
{
	uint64_t UID; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<struct FDailyTaskStoreInfo> TaskInfo; // 0x10(0x10)
	struct TArray<struct FDailyTaskAwardInfo> RewardInfo; // 0x20(0x10)
	int HighScoreCount; // 0x30(0x4)
	int TrainCount; // 0x34(0x4)
	int TotalTargetScore; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct TArray<uint64_t> Interaction; // 0x40(0x10)
	int StayTime; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<int> DuelDurations; // 0x58(0x10)
	int DuelApplyCount; // 0x68(0x4)
	int DuelStartCount; // 0x6C(0x4)
};

// Object: ScriptStruct Gameplay.PlayerOBBattleInfo
// Size: 0x30 (Inherited: 0x0)
struct FPlayerOBBattleInfo
{
	uint64_t UID; // 0x0(0x8)
	int BattleMode; // 0x8(0x4)
	bool ValidBattleInfo; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	int GameCount; // 0x10(0x4)
	int WinCount; // 0x14(0x4)
	int TopTenCount; // 0x18(0x4)
	int KillNum; // 0x1C(0x4)
	struct FString KDNum; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.ReportFatalDamage
// Size: 0x30 (Inherited: 0x0)
struct FReportFatalDamage
{
	struct FString PlayerName; // 0x0(0x10)
	uint64_t PlayerUID; // 0x10(0x8)
	uint64_t OriginUID; // 0x18(0x8)
	double OccurTime; // 0x20(0x8)
	bool bIsDeliver; // 0x28(0x1)
	bool bIsMLAI; // 0x29(0x1)
	bool bIsPlayerAI; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x5]; // 0x2B(0x5)
};

// Object: ScriptStruct Gameplay.ParachuteInfo
// Size: 0x28 (Inherited: 0x0)
struct FParachuteInfo
{
	int LeaderCount; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	uint64_t LastGameLeaderUID; // 0x8(0x8)
	struct TArray<uint64_t> LastGameTeammatesUID; // 0x10(0x10)
	uint64_t LastGameBattleID; // 0x20(0x8)
};

// Object: ScriptStruct Gameplay.ThemeRewardStateInfo
// Size: 0xC (Inherited: 0x0)
struct FThemeRewardStateInfo
{
	int ID; // 0x0(0x4)
	int State; // 0x4(0x4)
	float LastUseTimeStamp; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.DeathMatchBattleResultData
// Size: 0x58 (Inherited: 0x0)
struct FDeathMatchBattleResultData
{
	uint8_t SubModeType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct FDeathMatchTeamBattleResultData> TeamResultDatas; // 0x8(0x10)
	int PlayerNumber; // 0x18(0x4)
	int RealPlayerNumber; // 0x1C(0x4)
	int PlayTime; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	uint64_t FirstKillPlayer; // 0x28(0x8)
	uint64_t LastKillPlayer; // 0x30(0x8)
	struct FString VsTeamGameFlow; // 0x38(0x10)
	struct TArray<struct FBRTDMWinLevelInfoTeamScoreResultData> WinLevelInfo; // 0x48(0x10)
};

// Object: ScriptStruct Gameplay.BRTDMWinLevelInfoTeamScoreResultData
// Size: 0x8 (Inherited: 0x0)
struct FBRTDMWinLevelInfoTeamScoreResultData
{
	int LevelIndex; // 0x0(0x4)
	int WinBornArea; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.DeathMatchTeamBattleResultData
// Size: 0x30 (Inherited: 0x0)
struct FDeathMatchTeamBattleResultData
{
	int TeamID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Result; // 0x8(0x10)
	int TeamRank; // 0x18(0x4)
	int TeamScore; // 0x1C(0x4)
	struct TArray<struct FDeathMatchPlayerBattleResultData> TeamPlayerResultDatas; // 0x20(0x10)
};

// Object: ScriptStruct Gameplay.DeathMatchPlayerBattleResultData
// Size: 0x268 (Inherited: 0x0)
struct FDeathMatchPlayerBattleResultData
{
	uint64_t UID; // 0x0(0x8)
	uint32_t PlayerKey; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString PlayerName; // 0x10(0x10)
	int TeamID; // 0x20(0x4)
	int PlayerScore; // 0x24(0x4)
	int Rank; // 0x28(0x4)
	int Kills; // 0x2C(0x4)
	int rescueTimes; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<uint64_t> RescueTeammatesList; // 0x38(0x10)
	int Assists; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct TArray<uint64_t> AssistTeammatesList; // 0x50(0x10)
	int OccupyScore; // 0x60(0x4)
	int Deaths; // 0x64(0x4)
	int MaxContinuouKills; // 0x68(0x4)
	int SuperGodNum; // 0x6C(0x4)
	int RevengeNum; // 0x70(0x4)
	int DieInBaseRegionNum; // 0x74(0x4)
	int DamageAmount; // 0x78(0x4)
	int HeadShotNum; // 0x7C(0x4)
	int ShootWeaponShotNum; // 0x80(0x4)
	int ShootWeaponShotAndHitPlayerNum; // 0x84(0x4)
	int GunKillingTimes; // 0x88(0x4)
	int MeleeKillTimes; // 0x8C(0x4)
	float RangedDamagedAmount; // 0x90(0x4)
	float MeleeDamageAmount; // 0x94(0x4)
	float MovingDistance; // 0x98(0x4)
	float HealAmount; // 0x9C(0x4)
	int CureCount; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct FEquipmentData EquipmentData; // 0xA8(0x70)
	struct TArray<uint64_t> TeamMemberList; // 0x118(0x10)
	struct TMap<int, int> MedalList; // 0x128(0x50)
	struct TArray<struct FTimeToMedal> TimeToMedalList; // 0x178(0x10)
	float surviveTime; // 0x188(0x4)
	uint8_t Pad_0x18C[0x4]; // 0x18C(0x4)
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // 0x190(0x10)
	struct TArray<struct FUseItemFlow> UseItemFlow; // 0x1A0(0x10)
	float TotalDamage; // 0x1B0(0x4)
	float TotalSprintDistance; // 0x1B4(0x4)
	int OpenAirDropBoxesNum; // 0x1B8(0x4)
	uint8_t Pad_0x1BC[0x4]; // 0x1BC(0x4)
	struct FOnePlayerWeapon WeaponRecord; // 0x1C0(0x20)
	float Pronetime; // 0x1E0(0x4)
	uint8_t Pad_0x1E4[0x4]; // 0x1E4(0x4)
	struct TArray<struct FString> KillFlow; // 0x1E8(0x10)
	bool HasEscape; // 0x1F8(0x1)
	uint8_t Pad_0x1F9[0x7]; // 0x1F9(0x7)
	struct FString VsReadinessSwitchFlow; // 0x200(0x10)
	int CostGold; // 0x210(0x4)
	uint8_t Pad_0x214[0x4]; // 0x214(0x4)
	struct TMap<int, int> GeneralCounterMap; // 0x218(0x50)
};

// Object: ScriptStruct Gameplay.TimeToMedal
// Size: 0x8 (Inherited: 0x0)
struct FTimeToMedal
{
	int MedalID; // 0x0(0x4)
	float TimeStamp; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.PlayerDeathRoundData
// Size: 0x38 (Inherited: 0x0)
struct FPlayerDeathRoundData
{
	uint64_t UID; // 0x0(0x8)
	int TeamID; // 0x8(0x4)
	int Kills; // 0xC(0x4)
	int DamageAmount; // 0x10(0x4)
	float HealAmount; // 0x14(0x4)
	float surviveTime; // 0x18(0x4)
	int ShootWeaponShotNum; // 0x1C(0x4)
	int ShootWeaponShotAndHitPlayerNum; // 0x20(0x4)
	int Deaths; // 0x24(0x4)
	int PlayTime; // 0x28(0x4)
	struct FVector DeadLocation; // 0x2C(0xC)
};

// Object: ScriptStruct Gameplay.AirDropBoxDataFlow
// Size: 0x20 (Inherited: 0x0)
struct FAirDropBoxDataFlow
{
	struct TArray<struct FAirDropBoxData> AirDropBoxDataList; // 0x0(0x10)
	struct FString BattleID; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.AirDropBoxData
// Size: 0x38 (Inherited: 0x0)
struct FAirDropBoxData
{
	int AirDropBoxId; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FAirDropBoxDataItem> DataList; // 0x8(0x10)
	int Reason; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	uint64_t CallerPlayerID; // 0x20(0x8)
	struct FVector Location; // 0x28(0xC)
	float DropTime; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.AirDropBoxDataItem
// Size: 0x8 (Inherited: 0x0)
struct FAirDropBoxDataItem
{
	int ItemSpesificID; // 0x0(0x4)
	int Count; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.PlayerAssistInfo
// Size: 0x20 (Inherited: 0x0)
struct FPlayerAssistInfo
{
	uint64_t KillerUID; // 0x0(0x8)
	uint64_t VictimUID; // 0x8(0x8)
	struct TArray<uint64_t> AssistUIDArray; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.PickUpSpecialItemFlow
// Size: 0x8 (Inherited: 0x0)
struct FPickUpSpecialItemFlow
{
	int ItemSpesificID; // 0x0(0x4)
	int pickCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.HeavyWeaponBoxItemFlow
// Size: 0x20 (Inherited: 0x0)
struct FHeavyWeaponBoxItemFlow
{
	struct FString BoxName; // 0x0(0x10)
	struct TArray<int> ItemIdList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.HeavyWeaponBoxOpenPlayerFlow
// Size: 0x28 (Inherited: 0x0)
struct FHeavyWeaponBoxOpenPlayerFlow
{
	struct FString BoxName; // 0x0(0x10)
	int WaitTimeFromActiveToOpen; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	int64_t UID; // 0x18(0x8)
	uint32_t TeamID; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.HeavyWeaponBoxActivationFlow
// Size: 0x18 (Inherited: 0x0)
struct FHeavyWeaponBoxActivationFlow
{
	struct FString BoxName; // 0x0(0x10)
	int64_t ActiveTime; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.HeavyWeaponBoxSpawnFlow
// Size: 0x28 (Inherited: 0x0)
struct FHeavyWeaponBoxSpawnFlow
{
	struct FString BoxName; // 0x0(0x10)
	int64_t SpawnTime; // 0x10(0x8)
	struct FString SpawnLocation; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.ItemRegionCircle
// Size: 0x38 (Inherited: 0x0)
struct FItemRegionCircle
{
	struct FVector Center; // 0x0(0xC)
	float Radius; // 0xC(0x4)
	float RadiusSquared2D; // 0x10(0x4)
	uint8_t Pad_0x14[0x24]; // 0x14(0x24)
};

// Object: ScriptStruct Gameplay.GroupTypeSceneComponents
// Size: 0x18 (Inherited: 0x0)
struct FGroupTypeSceneComponents
{
	int GroupType; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct USceneComponent*> SceneComponents; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.ItemSpawnClass
// Size: 0x10 (Inherited: 0x0)
struct FItemSpawnClass
{
	struct UObject* ItemClass; // 0x0(0x8)
	int ItemCount; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.ItemSpawnData
// Size: 0x70 (Inherited: 0x0)
struct FItemSpawnData
{
	struct FName RowName; // 0x0(0x8)
	int KeyID; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString ItemValue; // 0x10(0x10)
	struct FString ItemCategory; // 0x20(0x10)
	int ItemWeight; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FString ItemPath; // 0x38(0x10)
	int ItemStackCount; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct FString ItemTogetherPath; // 0x50(0x10)
	int ItemTogetherStackCount; // 0x60(0x4)
	int ItemTogetherCountMin; // 0x64(0x4)
	int ItemTogetherCountMax; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

// Object: ScriptStruct Gameplay.PrimeCircleArea
// Size: 0x18 (Inherited: 0x0)
struct FPrimeCircleArea
{
	struct TArray<struct FVector> Anchors; // 0x0(0x10)
	int PrimeConfigIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.PrimeItemCircleConfig
// Size: 0x10 (Inherited: 0x0)
struct FPrimeItemCircleConfig
{
	struct TArray<struct FSpotGroupProperty> PrimeItemCircleProperties; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.DynamicSpotConfig
// Size: 0x58 (Inherited: 0x0)
struct FDynamicSpotConfig
{
	struct FString Comment; // 0x0(0x10)
	bool bDefaultEnable; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct FString DynamicSpotPath; // 0x18(0x10)
	struct FCustomSpotConfig CustomSpotConfig; // 0x28(0x1C)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct TArray<struct FSpotGroupProperty> SpotGroupProperties; // 0x48(0x10)
};

// Object: ScriptStruct Gameplay.CustomSpotConfig
// Size: 0x1C (Inherited: 0x0)
struct FCustomSpotConfig
{
	bool bGenerateAtBeginning; // 0x0(0x1)
	bool bGroupNumCtrl; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	int NeedGroupMin; // 0x4(0x4)
	int NeedGroupMax; // 0x8(0x4)
	bool bSpotPerGroupNumCtrl; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	int NeedSpotPerGroupMin; // 0x10(0x4)
	int NeedSpotPerGroupMax; // 0x14(0x4)
	bool bUseCookedRotator; // 0x18(0x1)
	bool bOverrideNearItem; // 0x19(0x1)
	bool bNearItem; // 0x1A(0x1)
	bool bUseDefaultSpotGroupProperties; // 0x1B(0x1)
};

// Object: ScriptStruct Gameplay.RepeatItemSpotData
// Size: 0x130 (Inherited: 0x0)
struct FRepeatItemSpotData
{
	uint8_t Pad_0x0[0xD0]; // 0x0(0xD0)
	float RepeatGenerateCD; // 0xD0(0x4)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	int64_t LastGenerateItemTime; // 0xD8(0x8)
	struct TMap<struct FString, int> CacheItemValeCategory; // 0xE0(0x50)
};

// Object: ScriptStruct Gameplay.ItemGenerateSpawnDataArray
// Size: 0x20 (Inherited: 0x0)
struct FItemGenerateSpawnDataArray
{
	struct FString ValueCatetory; // 0x0(0x10)
	struct TArray<struct FItemGenerateSpawnData> AllGenerateSpawnDatas; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.ExtraItemSpawn
// Size: 0x28 (Inherited: 0x0)
struct FExtraItemSpawn
{
	int SpawnPercent; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString SpawnItemValue; // 0x8(0x10)
	struct FString SpawnItemCategory; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.AreaItemsLimit
// Size: 0xC0 (Inherited: 0x0)
struct FAreaItemsLimit
{
	struct FRegionID RegionID; // 0x0(0xC)
	bool IsBeginGenerateItem; // 0xC(0x1)
	bool IsCheckRecoverItem; // 0xD(0x1)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	struct TArray<struct FVector> AvailablePosi; // 0x10(0x10)
	struct TMap<int, struct FAreaItemsNum> ItemsMaxLimit; // 0x20(0x50)
	struct TMap<int, struct FAreaItemsNum> ItemsMinLimit; // 0x70(0x50)
};

// Object: ScriptStruct Gameplay.AreaItemsNum
// Size: 0x18 (Inherited: 0x0)
struct FAreaItemsNum
{
	int LimitNum; // 0x0(0x4)
	int CurNum; // 0x4(0x4)
	struct FString WrapperPath; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.AreaItemsLimitEdit
// Size: 0x28 (Inherited: 0x0)
struct FAreaItemsLimitEdit
{
	int AreaX; // 0x0(0x4)
	int AreaY; // 0x4(0x4)
	struct TArray<struct FGenerateItemLimit> ItemsMaxLimitEdit; // 0x8(0x10)
	struct TArray<struct FGenerateItemLimit> ItemsMinLimitEdit; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.GenerateItemLimit
// Size: 0x18 (Inherited: 0x0)
struct FGenerateItemLimit
{
	int ItemId; // 0x0(0x4)
	int ItemNum; // 0x4(0x4)
	struct FString WrapperPath; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.ItemGenerateTableRow
// Size: 0x40 (Inherited: 0x8)
struct FItemGenerateTableRow : FTableRowBase
{
	int ID; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FString Value; // 0x10(0x10)
	struct FString Catetory; // 0x20(0x10)
	struct TArray<struct FItemGenerateSpawnData> AllGenerateSpawnDatas; // 0x30(0x10)
};

// Object: ScriptStruct Gameplay.ItemSpotSceneComponentArray
// Size: 0x18 (Inherited: 0x0)
struct FItemSpotSceneComponentArray
{
	enum class ESpotType SpotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct UItemSpotSceneComponent*> AllSpots; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.RevivalRecordBaseInfo
// Size: 0x40 (Inherited: 0x0)
struct FRevivalRecordBaseInfo
{
	struct FString OpenID; // 0x0(0x10)
	uint16_t AreaID; // 0x10(0x2)
	uint8_t PlatID; // 0x12(0x1)
	uint8_t Pad_0x13[0x5]; // 0x13(0x5)
	struct FString ZoneID; // 0x18(0x10)
	struct FString UserName; // 0x28(0x10)
	uint64_t RoleID; // 0x38(0x8)
};

// Object: ScriptStruct Gameplay.ReportIDCardDestroyFlow
// Size: 0x58 (Inherited: 0x40)
struct FReportIDCardDestroyFlow : FRevivalRecordBaseInfo
{
	uint8_t DestroyReason; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
	struct FString DestroyTime; // 0x48(0x10)
};

// Object: ScriptStruct Gameplay.ReportIDCardPickUpFlow
// Size: 0x50 (Inherited: 0x40)
struct FReportIDCardPickUpFlow : FRevivalRecordBaseInfo
{
	uint64_t PickerUID; // 0x40(0x8)
	int RemainingCountDown; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
};

// Object: ScriptStruct Gameplay.ReportIDCardProduceFlow
// Size: 0x50 (Inherited: 0x40)
struct FReportIDCardProduceFlow : FRevivalRecordBaseInfo
{
	struct FString DeathTime; // 0x40(0x10)
};

// Object: ScriptStruct Gameplay.ReportRevivalFlow
// Size: 0x78 (Inherited: 0x40)
struct FReportRevivalFlow : FRevivalRecordBaseInfo
{
	uint8_t RevivalFailedReason; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
	struct FString TowerLocation; // 0x48(0x10)
	struct FString RevivalTime; // 0x58(0x10)
	struct TArray<struct FPlayerRevivalInfo> PlayerRevivalInfos; // 0x68(0x10)
};

// Object: ScriptStruct Gameplay.PlayerRevivalInfo
// Size: 0x18 (Inherited: 0x0)
struct FPlayerRevivalInfo
{
	int64_t RevivedPlayerUID; // 0x0(0x8)
	int64_t PickerUID; // 0x8(0x8)
	int TimeAfterIDCardPicked; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.FingerTouchFlow
// Size: 0x98 (Inherited: 0x0)
struct FFingerTouchFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	uint64_t BattleID; // 0x40(0x8)
	uint64_t UID; // 0x48(0x8)
	int MapID; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FString ClientVersion; // 0x58(0x10)
	int MatchMode; // 0x68(0x4)
	int ViewportWidth; // 0x6C(0x4)
	int ViewportHeight; // 0x70(0x4)
	float DPIScale; // 0x74(0x4)
	struct TArray<struct FFingerTouchCluster> Clusters; // 0x78(0x10)
	struct TArray<struct FFireSample> FireSamples; // 0x88(0x10)
};

// Object: ScriptStruct Gameplay.FireSample
// Size: 0x28 (Inherited: 0x0)
struct FFireSample
{
	float LocX; // 0x0(0x4)
	float LocY; // 0x4(0x4)
	double StartTime; // 0x8(0x8)
	double EndTime; // 0x10(0x8)
	uint64_t StartFrame; // 0x18(0x8)
	uint64_t EndFrame; // 0x20(0x8)
};

// Object: ScriptStruct Gameplay.FingerTouchCluster
// Size: 0x18 (Inherited: 0x0)
struct FFingerTouchCluster
{
	float StartTime; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FFingerTouchSample> Samples; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.FingerTouchSample
// Size: 0x1C (Inherited: 0x0)
struct FFingerTouchSample
{
	int FingerIndex; // 0x0(0x4)
	float PressLocX; // 0x4(0x4)
	float PressLocY; // 0x8(0x4)
	float PressTime; // 0xC(0x4)
	float ReleaseLocX; // 0x10(0x4)
	float ReleaseLocY; // 0x14(0x4)
	float ReleaseTime; // 0x18(0x4)
};

// Object: ScriptStruct Gameplay.TssAntiFlow
// Size: 0x1C (Inherited: 0x0)
struct FTssAntiFlow
{
	int GunID; // 0x0(0x4)
	int KillAICnt; // 0x4(0x4)
	int KillRealPlayerCnt; // 0x8(0x4)
	uint32_t ShotTime; // 0xC(0x4)
	uint32_t SendIndex; // 0x10(0x4)
	uint8_t ErrorCode; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	uint32_t ReportLog; // 0x18(0x4)
};

// Object: ScriptStruct Gameplay.PlayerNetworkData
// Size: 0x10 (Inherited: 0x0)
struct FPlayerNetworkData
{
	uint64_t UID; // 0x0(0x8)
	int TotalOutOfOrderPackets; // 0x8(0x4)
	int MaxOutOfOrderPacketsPerSec; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.ClientNetworkData
// Size: 0x30 (Inherited: 0x0)
struct FClientNetworkData
{
	uint64_t UID; // 0x0(0x8)
	int AvgPing; // 0x8(0x4)
	int MaxPing; // 0xC(0x4)
	int MinPing; // 0x10(0x4)
	int LostPackRate; // 0x14(0x4)
	int AvgNoOutlier; // 0x18(0x4)
	int StdNoOutlier; // 0x1C(0x4)
	int NumNoOutlier; // 0x20(0x4)
	int InLoss; // 0x24(0x4)
	int OutLoss; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.NetworkData
// Size: 0x2C (Inherited: 0x0)
struct FNetworkData
{
	int AlivePlayerNum; // 0x0(0x4)
	int ConnectionNum; // 0x4(0x4)
	int OnlineNum; // 0x8(0x4)
	int HighPingNum; // 0xC(0x4)
	int NoConPktPerSec; // 0x10(0x4)
	int NoConBadPktPerSec; // 0x14(0x4)
	int DisConPktPerSec; // 0x18(0x4)
	int WorstFrameMSPerSec; // 0x1C(0x4)
	int BlockNonConnBurst; // 0x20(0x4)
	int BlockNetConnBurst; // 0x24(0x4)
	int DropPktCntPerSec; // 0x28(0x4)
};

// Object: ScriptStruct Gameplay.HeartBeatData
// Size: 0x18 (Inherited: 0x0)
struct FHeartBeatData
{
	int AlivePlayerNum; // 0x0(0x4)
	int AINum; // 0x4(0x4)
	int MonsterNum; // 0x8(0x4)
	int ConnectionNum; // 0xC(0x4)
	int OnlineNum; // 0x10(0x4)
	int HighPingNum; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.EquipmentFlow
// Size: 0x78 (Inherited: 0x0)
struct FEquipmentFlow
{
	uint64_t UID; // 0x0(0x8)
	int EventType; // 0x8(0x4)
	int GameTime; // 0xC(0x4)
	int MainWeapon1ID; // 0x10(0x4)
	int MainWeapon2ID; // 0x14(0x4)
	int ViceWeaponID; // 0x18(0x4)
	int HelmetID; // 0x1C(0x4)
	int VestID; // 0x20(0x4)
	int BackPackID; // 0x24(0x4)
	struct TMap<int, int> Equipments; // 0x28(0x50)
};

// Object: ScriptStruct Gameplay.RealtimeVerifyInfo
// Size: 0x70 (Inherited: 0x0)
struct FRealtimeVerifyInfo
{
	uint16_t AreaID; // 0x0(0x2)
	uint8_t PlatID; // 0x2(0x1)
	uint8_t Pad_0x3[0x5]; // 0x3(0x5)
	struct FString ZoneID; // 0x8(0x10)
	int HitCountsNoAI; // 0x18(0x4)
	int HeadshotCountsNoAI; // 0x1C(0x4)
	int ShotCounts; // 0x20(0x4)
	int Kills; // 0x24(0x4)
	int PrisonBreaks; // 0x28(0x4)
	int JumpMaxHeight2; // 0x2C(0x4)
	int SkeletonLengthCheckInvaildNum; // 0x30(0x4)
	int MuzzleAndOwnerPosInVaildNum; // 0x34(0x4)
	int ImpactActorPosOffsetBigNum; // 0x38(0x4)
	int TotalImpactCharacterNum; // 0x3C(0x4)
	int WeaponScopeHeightBigNum; // 0x40(0x4)
	int WeaponScopeDisBigNum; // 0x44(0x4)
	int OwnerHeadAndMuzzleBlockNum; // 0x48(0x4)
	int ImpactPointAndBulletDisBigNum; // 0x4C(0x4)
	int ShootVerifyInvalidNum; // 0x50(0x4)
	float TotalSkeletonLengthMax; // 0x54(0x4)
	int TimeAccTimes; // 0x58(0x4)
	int SpeedQuickCheck; // 0x5C(0x4)
	float ShootVerifyClientHitAABBCount; // 0x60(0x4)
	float ShootVerifyDSAABBMissCount; // 0x64(0x4)
	float PlayerZ; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
};

// Object: ScriptStruct Gameplay.SecMrpcsFlow
// Size: 0x88 (Inherited: 0x0)
struct FSecMrpcsFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	struct FString UserName; // 0x58(0x10)
	uint64_t SvrRoleID; // 0x68(0x8)
	uint8_t SecMrpcsFlowID; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
	struct FString MrpcsFlowStr; // 0x78(0x10)
};

// Object: ScriptStruct Gameplay.ClientSecMrpcsFlow
// Size: 0x18 (Inherited: 0x0)
struct FClientSecMrpcsFlow
{
	uint8_t SecMrpcsFlowID; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<uint8_t> MrpcsFlowData; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.GameMisKillFlow
// Size: 0x80 (Inherited: 0x0)
struct FGameMisKillFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	uint64_t MyRoleID; // 0x28(0x8)
	struct FString MyOpenID; // 0x30(0x10)
	uint16_t AreaID; // 0x40(0x2)
	uint8_t PlatID; // 0x42(0x1)
	uint8_t Pad_0x43[0x5]; // 0x43(0x5)
	struct FString ZoneID; // 0x48(0x10)
	uint64_t BattleID; // 0x58(0x8)
	struct FString DeadDamangeType; // 0x60(0x10)
	uint64_t TeammateRoleID; // 0x70(0x8)
	int bConfirmMisKill; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: ScriptStruct Gameplay.GameEndReport
// Size: 0xB0 (Inherited: 0x0)
struct FGameEndReport
{
	int PvePoliceOfficeTriggerCount; // 0x0(0x4)
	int PveZombieGrenadeCount; // 0x4(0x4)
	int PveGenerateZombieByNoTeamMate; // 0x8(0x4)
	int NoneAIGameTime; // 0xC(0x4)
	struct TMap<int, int> AISpawnCountMap; // 0x10(0x50)
	struct TMap<int, int> AIEnterFightingCountMap; // 0x60(0x50)
};

// Object: ScriptStruct Gameplay.VerifyInfoFlow
// Size: 0x40 (Inherited: 0x0)
struct FVerifyInfoFlow
{
	struct FString GameAppID; // 0x0(0x10)
	struct FString OpenID; // 0x10(0x10)
	uint64_t UID; // 0x20(0x8)
	uint64_t BattleID; // 0x28(0x8)
	int LocationX; // 0x30(0x4)
	int LocationY; // 0x34(0x4)
	int LocationZ; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct Gameplay.VoiceTeamQuit
// Size: 0x30 (Inherited: 0x0)
struct FVoiceTeamQuit
{
	struct FString AntsVoiceTeamID; // 0x0(0x10)
	struct FString AntsVoiceRoomID; // 0x10(0x10)
	int AntsVoiceTeamMemberID; // 0x20(0x4)
	int AntsVoiceRoomMemberID; // 0x24(0x4)
	uint64_t UID; // 0x28(0x8)
};

// Object: ScriptStruct Gameplay.VoiceTeamCreate
// Size: 0x30 (Inherited: 0x0)
struct FVoiceTeamCreate
{
	struct FString AntsVoiceTeamID; // 0x0(0x10)
	struct FString AntsVoiceRoomID; // 0x10(0x10)
	int AntsVoiceTeamMemberID; // 0x20(0x4)
	int AntsVoiceRoomMemberID; // 0x24(0x4)
	uint64_t UID; // 0x28(0x8)
};

// Object: ScriptStruct Gameplay.WatchGamePlayerInfoClickFlow
// Size: 0x10 (Inherited: 0x0)
struct FWatchGamePlayerInfoClickFlow
{
	uint64_t WatchPlayer_UID; // 0x0(0x8)
	int WatchTimes; // 0x8(0x4)
	float Duration; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting
// Size: 0x118 (Inherited: 0x0)
struct FGameSetting
{
	uint64_t RoleID; // 0x0(0x8)
	struct FGameSetting_BasicSetting BasicSetting; // 0x8(0x2C)
	struct FGameSetting_ArtQuality ArtQuality; // 0x34(0x8)
	struct FGameSetting_Operate Operate; // 0x3C(0x8)
	struct FGameSetting_Vehicle Vehicle; // 0x44(0x8)
	struct FGameSetting_Sensibility Sensibility; // 0x4C(0x88)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
	struct FGameSetting_PickUp PickUp; // 0xD8(0x40)
};

// Object: ScriptStruct Gameplay.GameSetting_PickUp
// Size: 0x40 (Inherited: 0x0)
struct FGameSetting_PickUp
{
	bool AutoPickUpSwitcher; // 0x0(0x1)
	bool AutoPickupPistol; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	struct FGameSetting_PickUp_Drug Drug; // 0x4(0x18)
	struct FGamesetting_PickUp_Grenade Grenade; // 0x1C(0x10)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FGameSetting_PickUp_WeaponBullet> WeaponBulletList; // 0x30(0x10)
};

// Object: ScriptStruct Gameplay.GameSetting_PickUp_WeaponBullet
// Size: 0x8 (Inherited: 0x0)
struct FGameSetting_PickUp_WeaponBullet
{
	int WeaponId; // 0x0(0x4)
	int BulletCount; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.Gamesetting_PickUp_Grenade
// Size: 0x10 (Inherited: 0x0)
struct FGamesetting_PickUp_Grenade
{
	int IncendiaryBomb; // 0x0(0x4)
	int ShockBomb; // 0x4(0x4)
	int SmokeBomb; // 0x8(0x4)
	int GrenadeFragmented; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_PickUp_Drug
// Size: 0x18 (Inherited: 0x0)
struct FGameSetting_PickUp_Drug
{
	int MedicalTreatment; // 0x0(0x4)
	int Bandage; // 0x4(0x4)
	int PainKiller; // 0x8(0x4)
	int Adrenaline; // 0xC(0x4)
	int EnergyDrink; // 0x10(0x4)
	int FirstAidKit; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Sensibility
// Size: 0x88 (Inherited: 0x0)
struct FGameSetting_Sensibility
{
	int CameraLensSensibility; // 0x0(0x4)
	struct FGameSetting_Sensibility_FreeCam Sens_FreeCamera; // 0x4(0xC)
	struct FGameSetting_Sensibility_Cam Sens_Camera; // 0x10(0x28)
	struct FGameSetting_Sensibility_Fire Sens_Fire; // 0x38(0x28)
	struct FGameSetting_Sensibility_Gyroscope Sens_Gyroscope; // 0x60(0x28)
};

// Object: ScriptStruct Gameplay.GameSetting_Sensibility_Gyroscope
// Size: 0x28 (Inherited: 0x0)
struct FGameSetting_Sensibility_Gyroscope
{
	float GyroscopeSenNoneSniper; // 0x0(0x4)
	float GyroscopeSenNoneSniperFP; // 0x4(0x4)
	float GyroscopeSenRedDotSniper; // 0x8(0x4)
	float GyroscopeSen2XSniper; // 0xC(0x4)
	float GyroscopeSen3XSniper; // 0x10(0x4)
	float GyroscopeSen4XSniper; // 0x14(0x4)
	float GyroscopeSen6XSniper; // 0x18(0x4)
	float GyroscopeSen8XSniper; // 0x1C(0x4)
	float GyroscopeShoulderSniper; // 0x20(0x4)
	float GyroscopeShoulderSniperFP; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Sensibility_Fire
// Size: 0x28 (Inherited: 0x0)
struct FGameSetting_Sensibility_Fire
{
	float FireCamLensSenNoneSniper; // 0x0(0x4)
	float FireCamLensSenNoneSniperFP; // 0x4(0x4)
	float FireCamLensSenRedDotSniper; // 0x8(0x4)
	float FireCamLensSen2XSniper; // 0xC(0x4)
	float FireCamLensSen3XSniper; // 0x10(0x4)
	float FireCamLensSen4XSniper; // 0x14(0x4)
	float FireCamLensSen6XSniper; // 0x18(0x4)
	float FireCamLensSen8XSniper; // 0x1C(0x4)
	float FireCamLensSenShoulderSniper; // 0x20(0x4)
	float FireCamLensSenShoulderSniperFP; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Sensibility_Cam
// Size: 0x28 (Inherited: 0x0)
struct FGameSetting_Sensibility_Cam
{
	float CamLensSenNoneSniper; // 0x0(0x4)
	float CamLensSenNoneSniperFP; // 0x4(0x4)
	float CamLensSenRedDotSniper; // 0x8(0x4)
	float CamLensSen2XSniper; // 0xC(0x4)
	float CamLensSen3XSniper; // 0x10(0x4)
	float CamLensSen4XSniper; // 0x14(0x4)
	float CamLensSen6XSniper; // 0x18(0x4)
	float CamLensSen8XSniper; // 0x1C(0x4)
	float CamLensSenShoulderSniper; // 0x20(0x4)
	float CamLensSenShoulderSniperFP; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Sensibility_FreeCam
// Size: 0xC (Inherited: 0x0)
struct FGameSetting_Sensibility_FreeCam
{
	float VehicleEye; // 0x0(0x4)
	float ParachuteEye; // 0x4(0x4)
	float CamFpFreeEye; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Vehicle
// Size: 0x8 (Inherited: 0x0)
struct FGameSetting_Vehicle
{
	int VehicleControlMode; // 0x0(0x4)
	int DrivingViewMode; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.GameSetting_Operate
// Size: 0x8 (Inherited: 0x0)
struct FGameSetting_Operate
{
	int FireMode; // 0x0(0x4)
	bool Touch_3D_Switcher; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Gameplay.GameSetting_ArtQuality
// Size: 0x8 (Inherited: 0x0)
struct FGameSetting_ArtQuality
{
	int ArtStyle; // 0x0(0x4)
	bool AntiAliasingSwitch; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
};

// Object: ScriptStruct Gameplay.GameSetting_BasicSetting
// Size: 0x2C (Inherited: 0x0)
struct FGameSetting_BasicSetting
{
	int CrossHairColor; // 0x0(0x4)
	bool AimAssist; // 0x4(0x1)
	bool WallFeedBack; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	int SingleShotWeaponShootMode; // 0x8(0x4)
	int ShotGunShootMode; // 0xC(0x4)
	bool LeftRightShoot; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	int LRShootMode; // 0x14(0x4)
	bool LRShootSniperSwitch; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int LeftHandFire; // 0x1C(0x4)
	int Gyroscope; // 0x20(0x4)
	bool AutoOpenDoor; // 0x24(0x1)
	bool IntelligentDrugs; // 0x25(0x1)
	bool ActorAnimationSwitch; // 0x26(0x1)
	bool FPViewSwitch; // 0x27(0x1)
	bool ShoulderEnable; // 0x28(0x1)
	bool ShoulderMode; // 0x29(0x1)
	uint8_t Pad_0x2A[0x2]; // 0x2A(0x2)
};

// Object: ScriptStruct Gameplay.SecPlayerKillFlow
// Size: 0x108 (Inherited: 0x0)
struct FSecPlayerKillFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	struct FString UserName; // 0x58(0x10)
	uint64_t SvrRoleID; // 0x68(0x8)
	int64_t ClientStartTime; // 0x70(0x8)
	uint8_t SecPlayerKillFlowID; // 0x78(0x1)
	uint8_t Pad_0x79[0x3]; // 0x79(0x3)
	int GunID; // 0x7C(0x4)
	uint64_t KilledPlayerRoleID; // 0x80(0x8)
	struct FRecoilInfo RecoilInfo; // 0x88(0x36)
	uint8_t Pad_0xBE[0x2]; // 0xBE(0x2)
	int LocationX; // 0xC0(0x4)
	int LocationY; // 0xC4(0x4)
	int LocationZ; // 0xC8(0x4)
	int KilledLocationX; // 0xCC(0x4)
	int KilledLocationY; // 0xD0(0x4)
	int KilledLocationZ; // 0xD4(0x4)
	int BornPointID; // 0xD8(0x4)
	int KilledBornPointID; // 0xDC(0x4)
	int TeamID; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
	struct FString GameModeID; // 0xE8(0x10)
	uint64_t PawnState; // 0xF8(0x8)
	uint64_t KilledPawnState; // 0x100(0x8)
};

// Object: ScriptStruct Gameplay.RecoilInfo
// Size: 0x36 (Inherited: 0x0)
struct FRecoilInfo
{
	int16_t VerticalRecoilMin; // 0x0(0x2)
	int16_t VerticalRecoilMax; // 0x2(0x2)
	int16_t VerticalRecoilVariation; // 0x4(0x2)
	int16_t VerticalRecoveryModifier; // 0x6(0x2)
	int16_t VerticalRecoveryClamp; // 0x8(0x2)
	int16_t VerticalRecoveryMax; // 0xA(0x2)
	int16_t LeftMax; // 0xC(0x2)
	int16_t RightMax; // 0xE(0x2)
	int16_t HorizontalTendency; // 0x10(0x2)
	int16_t BulletPerSwitch; // 0x12(0x2)
	int16_t TimePerSwitch; // 0x14(0x2)
	bool SwitchOnTime; // 0x16(0x1)
	uint8_t Pad_0x17[0x1]; // 0x17(0x1)
	int16_t RecoilSpeedVertical; // 0x18(0x2)
	int16_t RecoilSpeedHorizontal; // 0x1A(0x2)
	int16_t RecovertySpeedVertical; // 0x1C(0x2)
	int16_t RecoilValueClimb; // 0x1E(0x2)
	int16_t RecoilValueFail; // 0x20(0x2)
	int16_t RecoilModifierStand; // 0x22(0x2)
	int16_t RecoilModifierCrouch; // 0x24(0x2)
	int16_t RecoilModifierProne; // 0x26(0x2)
	int16_t RecoilHorizontalMinScalar; // 0x28(0x2)
	int16_t BurstEmptyDelay; // 0x2A(0x2)
	bool ShootSightReturn; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x1]; // 0x2D(0x1)
	int16_t ShootSightReturnSpeed; // 0x2E(0x2)
	int16_t AccessoriesVRecoilFactor; // 0x30(0x2)
	int16_t AccessoriesHRecoilFactor; // 0x32(0x2)
	int16_t AccessoriesRecoveryFactor; // 0x34(0x2)
};

// Object: ScriptStruct Gameplay.ClientSecPlayerKillFlow
// Size: 0x90 (Inherited: 0x0)
struct FClientSecPlayerKillFlow
{
	int64_t ClientStartTime; // 0x0(0x8)
	uint8_t SecPlayerKillFlowID; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	int GunID; // 0xC(0x4)
	uint32_t KilledPlayerKey; // 0x10(0x4)
	struct FRecoilInfo RecoilInfo; // 0x14(0x36)
	uint8_t Pad_0x4A[0x2]; // 0x4A(0x2)
	int LocationX; // 0x4C(0x4)
	int LocationY; // 0x50(0x4)
	int LocationZ; // 0x54(0x4)
	int KilledLocationX; // 0x58(0x4)
	int KilledLocationY; // 0x5C(0x4)
	int KilledLocationZ; // 0x60(0x4)
	int KilledTeamID; // 0x64(0x4)
	int TeamID; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct FString GameModeID; // 0x70(0x10)
	uint64_t PawnState; // 0x80(0x8)
	uint64_t KilledPawnState; // 0x88(0x8)
};

// Object: ScriptStruct Gameplay.PlayerBehaviorFlow
// Size: 0x98 (Inherited: 0x0)
struct FPlayerBehaviorFlow
{
	uint64_t FrameCounter; // 0x0(0x8)
	uint64_t BattleID; // 0x8(0x8)
	bool IsTargetPlayer; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct FString Name; // 0x18(0x10)
	uint32_t PlayerKey; // 0x28(0x4)
	uint32_t RelevantPlayerKey; // 0x2C(0x4)
	int LocationX; // 0x30(0x4)
	int LocationY; // 0x34(0x4)
	int LocationZ; // 0x38(0x4)
	int RotationP; // 0x3C(0x4)
	int RotationY; // 0x40(0x4)
	int RotationR; // 0x44(0x4)
	struct FString Stats; // 0x48(0x10)
	bool IsDying; // 0x58(0x1)
	uint8_t Pad_0x59[0x3]; // 0x59(0x3)
	float Breath; // 0x5C(0x4)
	int SpeedX; // 0x60(0x4)
	int SpeedY; // 0x64(0x4)
	int SpeedZ; // 0x68(0x4)
	float Health; // 0x6C(0x4)
	float Energy; // 0x70(0x4)
	int CurrentWeaponID; // 0x74(0x4)
	int Ammo; // 0x78(0x4)
	int SightId; // 0x7C(0x4)
	bool IsBeAttacking; // 0x80(0x1)
	uint8_t Pad_0x81[0x3]; // 0x81(0x3)
	int BeAttackDirX; // 0x84(0x4)
	int BeAttackDirY; // 0x88(0x4)
	int BeAttackDirZ; // 0x8C(0x4)
	int MedicineId; // 0x90(0x4)
	bool IsHaveSound; // 0x94(0x1)
	uint8_t Pad_0x95[0x3]; // 0x95(0x3)
};

// Object: ScriptStruct Gameplay.HurtFlow
// Size: 0x120 (Inherited: 0x0)
struct FHurtFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct FString EnemyOpenID; // 0x98(0x10)
	struct FString EnemyUserName; // 0xA8(0x10)
	uint64_t EnemyRoleID; // 0xB8(0x8)
	int EnemyRoleType; // 0xC0(0x4)
	uint32_t HurtTime; // 0xC4(0x4)
	int HurtType; // 0xC8(0x4)
	int HitType; // 0xCC(0x4)
	int DamageStart; // 0xD0(0x4)
	int DamageReduce; // 0xD4(0x4)
	int ArmorDef; // 0xD8(0x4)
	int HPstart; // 0xDC(0x4)
	int HPEnd; // 0xE0(0x4)
	int ArmorHPStart1; // 0xE4(0x4)
	int ArmorHPEnd1; // 0xE8(0x4)
	int ArmorHPStart2; // 0xEC(0x4)
	int ArmorHPEnd2; // 0xF0(0x4)
	int CarHPStart; // 0xF4(0x4)
	int CarHPEnd; // 0xF8(0x4)
	int FallHeight; // 0xFC(0x4)
	int HypoxiaTime; // 0x100(0x4)
	int HypoxiaHurtTotal; // 0x104(0x4)
	int PlayerKilled; // 0x108(0x4)
	int ArmorKill; // 0x10C(0x4)
	int CarKill; // 0x110(0x4)
	int IfIsAI; // 0x114(0x4)
	int CircleIndex; // 0x118(0x4)
	uint32_t HurtFlowID; // 0x11C(0x4)
};

// Object: ScriptStruct Gameplay.SecAttackFlow
// Size: 0xC0 (Inherited: 0x0)
struct FSecAttackFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint8_t PlatID; // 0x38(0x1)
	uint8_t Pad_0x39[0x1]; // 0x39(0x1)
	uint16_t AreaID; // 0x3A(0x2)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	uint64_t RoleID; // 0x60(0x8)
	struct FString TargetUserName; // 0x68(0x10)
	struct FString TargetOpenID; // 0x78(0x10)
	uint64_t TargetRoleID; // 0x88(0x8)
	struct FString HitPart; // 0x90(0x10)
	int GunID; // 0xA0(0x4)
	uint8_t PlayerKill; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	uint64_t AttackFlowID; // 0xA8(0x8)
	int KillAICnt; // 0xB0(0x4)
	int KillRealPlayerCnt; // 0xB4(0x4)
	int16_t BulletDown; // 0xB8(0x2)
	uint8_t Pad_0xBA[0x6]; // 0xBA(0x6)
};

// Object: ScriptStruct Gameplay.AttackFlow
// Size: 0x1D8 (Inherited: 0x0)
struct FAttackFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct FString TargetOpenID; // 0x98(0x10)
	struct FString TargetUserName; // 0xA8(0x10)
	uint64_t TargetRoleID; // 0xB8(0x8)
	uint8_t TargetRoleType; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x7]; // 0xC1(0x7)
	struct FString GunName; // 0xC8(0x10)
	struct FString GunPartsType; // 0xD8(0x10)
	uint8_t SightType; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x3]; // 0xE9(0x3)
	int BulletSpeed; // 0xEC(0x4)
	uint8_t MagazineMax; // 0xF0(0x1)
	uint8_t MagazineLeft; // 0xF1(0x1)
	uint8_t Pad_0xF2[0x2]; // 0xF2(0x2)
	int ShotFrequency; // 0xF4(0x4)
	int BulletDamage; // 0xF8(0x4)
	int16_t BulletDown; // 0xFC(0x2)
	uint8_t BulletDamageReduce; // 0xFE(0x1)
	uint8_t Pad_0xFF[0x1]; // 0xFF(0x1)
	int Recoil; // 0x100(0x4)
	int ReloadTime; // 0x104(0x4)
	struct FString PlayerState; // 0x108(0x10)
	uint8_t ShotPose; // 0x118(0x1)
	uint8_t FireType; // 0x119(0x1)
	uint8_t bHoldBreath : 1; // 0x11A(0x1), Mask(0x1)
	uint8_t BitPad_0x11A_1 : 7; // 0x11A(0x1)
	uint8_t Sideways; // 0x11B(0x1)
	int ShootingDeviationX; // 0x11C(0x4)
	int ShootingDeviationY; // 0x120(0x4)
	uint32_t ZeroDistance; // 0x124(0x4)
	uint32_t ShotTime; // 0x128(0x4)
	int HitTime; // 0x12C(0x4)
	int PlayerPositionX; // 0x130(0x4)
	int PlayerPositionY; // 0x134(0x4)
	int PlayerPositionZ; // 0x138(0x4)
	int GunPositionX; // 0x13C(0x4)
	int GunPositionY; // 0x140(0x4)
	int GunPositionZ; // 0x144(0x4)
	int BulletsBornPositionX; // 0x148(0x4)
	int BulletsBornPositionY; // 0x14C(0x4)
	int BulletsBornPositionZ; // 0x150(0x4)
	uint32_t LastHitTime; // 0x154(0x4)
	uint32_t BulletFlyDistance; // 0x158(0x4)
	uint32_t BulletFlyTime; // 0x15C(0x4)
	int HitPositionX; // 0x160(0x4)
	int HitPositionY; // 0x164(0x4)
	int HitPositionZ; // 0x168(0x4)
	uint8_t HitPart; // 0x16C(0x1)
	uint8_t bHitCar : 1; // 0x16D(0x1), Mask(0x1)
	uint8_t bTireOut : 1; // 0x16D(0x1), Mask(0x2)
	uint8_t BitPad_0x16D_2 : 6; // 0x16D(0x1)
	uint8_t BulletCost; // 0x16E(0x1)
	uint8_t Pad_0x16F[0x1]; // 0x16F(0x1)
	int HPstart; // 0x170(0x4)
	int HPEnd; // 0x174(0x4)
	int ArmorHPStart; // 0x178(0x4)
	int ArmorHPEnd; // 0x17C(0x4)
	int CarHPStart; // 0x180(0x4)
	int CarHPEnd; // 0x184(0x4)
	uint8_t PlayerKill; // 0x188(0x1)
	uint8_t bArmorKill : 1; // 0x189(0x1), Mask(0x1)
	uint8_t bCarKill : 1; // 0x189(0x1), Mask(0x2)
	uint8_t BitPad_0x189_2 : 6; // 0x189(0x1)
	uint8_t Pad_0x18A[0x2]; // 0x18A(0x2)
	int RecoilMoveX; // 0x18C(0x4)
	int RecoilMoveY; // 0x190(0x4)
	int WeaponAimFOV; // 0x194(0x4)
	int BulletDamageDebuff; // 0x198(0x4)
	int BulletDamageBuff; // 0x19C(0x4)
	int BulletType; // 0x1A0(0x4)
	uint32_t AtackFlowID; // 0x1A4(0x4)
	int AutoAimSpeed; // 0x1A8(0x4)
	int AutoAimSpeedRateMax; // 0x1AC(0x4)
	int AutoAimRangeMax; // 0x1B0(0x4)
	int AutoAimRangeRateMax; // 0x1B4(0x4)
	int GunID; // 0x1B8(0x4)
	int IfIsOnCar; // 0x1BC(0x4)
	bool InMoveablePlatform; // 0x1C0(0x1)
	uint8_t Pad_0x1C1[0x3]; // 0x1C1(0x3)
	int KillAICnt; // 0x1C4(0x4)
	int KillRealPlayerCnt; // 0x1C8(0x4)
	float CameraRotationX; // 0x1CC(0x4)
	float CameraRotationY; // 0x1D0(0x4)
	float CameraRotationZ; // 0x1D4(0x4)
};

// Object: ScriptStruct Gameplay.AimFlow
// Size: 0x128 (Inherited: 0x0)
struct FAimFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	int AimTime; // 0x94(0x4)
	struct FString ShotCDTime; // 0x98(0x10)
	int ShotCount; // 0xA8(0x4)
	int ShotHitCount; // 0xAC(0x4)
	int ShotHeadHitCount; // 0xB0(0x4)
	int ShotPersonHitCount; // 0xB4(0x4)
	int ShotPersonKillCount; // 0xB8(0x4)
	uint8_t Pad_0xBC[0x4]; // 0xBC(0x4)
	struct FString HitDistance; // 0xC0(0x10)
	struct FString HitEachDistance; // 0xD0(0x10)
	struct FString HitAngle; // 0xE0(0x10)
	struct FString HitEachCdTime; // 0xF0(0x10)
	struct FString HitPartInfo; // 0x100(0x10)
	struct FString PlayerState; // 0x110(0x10)
	uint8_t bHoldBreath : 1; // 0x120(0x1), Mask(0x1)
	uint8_t BitPad_0x120_1 : 7; // 0x120(0x1)
	uint8_t SightType; // 0x121(0x1)
	uint8_t Pad_0x122[0x2]; // 0x122(0x2)
	uint32_t AimFlowID; // 0x124(0x4)
};

// Object: ScriptStruct Gameplay.GameEndFlow
// Size: 0x200 (Inherited: 0x0)
struct FGameEndFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct FString ClientVersion; // 0x98(0x10)
	uint32_t OverTime; // 0xA8(0x4)
	uint8_t EndType; // 0xAC(0x1)
	uint8_t KillCount; // 0xAD(0x1)
	uint8_t AssistsCount; // 0xAE(0x1)
	uint8_t DropCount; // 0xAF(0x1)
	uint8_t SaveCount; // 0xB0(0x1)
	uint8_t RebornCount; // 0xB1(0x1)
	uint8_t AliveType : 1; // 0xB2(0x1), Mask(0x1)
	uint8_t BitPad_0xB2_1 : 7; // 0xB2(0x1)
	uint8_t Pad_0xB3[0x1]; // 0xB3(0x1)
	int GoldGet; // 0xB4(0x4)
	int DiamondGet; // 0xB8(0x4)
	int ExpGet; // 0xBC(0x4)
	uint8_t WinRank; // 0xC0(0x1)
	uint8_t TotalPlayers; // 0xC1(0x1)
	uint8_t Pad_0xC2[0x2]; // 0xC2(0x2)
	int PlayerRank; // 0xC4(0x4)
	int RankEnd; // 0xC8(0x4)
	int TeamID; // 0xCC(0x4)
	struct FString TeamPlayer1; // 0xD0(0x10)
	struct FString TeamPlayer2; // 0xE0(0x10)
	struct FString TeamPlayer3; // 0xF0(0x10)
	uint8_t TeamPlayer1AliveType : 1; // 0x100(0x1), Mask(0x1)
	uint8_t TeamPlayer2AliveType : 1; // 0x100(0x1), Mask(0x2)
	uint8_t TeamPlayer3AliveType : 1; // 0x100(0x1), Mask(0x4)
	uint8_t BitPad_0x100_3 : 5; // 0x100(0x1)
	uint8_t TeamPlayer1Kill; // 0x101(0x1)
	uint8_t TeamPlayer2Kill; // 0x102(0x1)
	uint8_t TeamPlayer3Kill; // 0x103(0x1)
	uint32_t GameEndFlowID; // 0x104(0x4)
	uint8_t AIKillCount; // 0x108(0x1)
	uint8_t KillHeadShotCount; // 0x109(0x1)
	uint8_t RoundCircleCount; // 0x10A(0x1)
	uint8_t PlayerLastKillGet; // 0x10B(0x1)
	int ChangeWearingCount; // 0x10C(0x4)
	struct TArray<int> ChangeWearingCountInReady; // 0x110(0x10)
	struct TArray<int> ChangeWearingCountInBattle; // 0x120(0x10)
	float AllowChangeWearingTime; // 0x130(0x4)
	float BattleStateTime; // 0x134(0x4)
	struct TArray<int> UseQuickMsgIDArray; // 0x138(0x10)
	struct TArray<int> UseQuickMsgCountArray; // 0x148(0x10)
	struct TArray<int> UseWheelMsgIDArray; // 0x158(0x10)
	struct TArray<int> UseWheelMsgCountArray; // 0x168(0x10)
	struct TArray<int> InexistentAvatarStat; // 0x178(0x10)
	struct TArray<int> InexistentAvatarInBornStat; // 0x188(0x10)
	struct TArray<int> InexistentWeaponAvatarStat; // 0x198(0x10)
	struct TArray<int> InexistentVehicleAvatarStat; // 0x1A8(0x10)
	int InexistentPlaneAvatarStat; // 0x1B8(0x4)
	int InexistentEmoteAvatarStat; // 0x1BC(0x4)
	uint8_t ShowMsgCnt; // 0x1C0(0x1)
	uint8_t UserConfirmCnt; // 0x1C1(0x1)
	uint8_t UserCancelCnt; // 0x1C2(0x1)
	uint8_t UserDoNothingCnt; // 0x1C3(0x1)
	float FPSBeforeAdapt; // 0x1C4(0x4)
	float FPSAfterAdapt; // 0x1C8(0x4)
	float TeammateMicrophoneTime; // 0x1CC(0x4)
	float TeammateSpeakerTime; // 0x1D0(0x4)
	float EnemyMicrophoneTime; // 0x1D4(0x4)
	float EnemySpeakerTime; // 0x1D8(0x4)
	float TeammateInterphoneTime; // 0x1DC(0x4)
	float EnemyInterphoneTime; // 0x1E0(0x4)
	uint8_t PlayerUseQuickSight; // 0x1E4(0x1)
	uint8_t PlayerUseShoulderCnt; // 0x1E5(0x1)
	uint8_t Pad_0x1E6[0x2]; // 0x1E6(0x2)
	int MaxVehicleToLandHeight; // 0x1E8(0x4)
	int MaxVehicleInAirInterval; // 0x1EC(0x4)
	int PlayerMoveSpeedMax; // 0x1F0(0x4)
	int PlayerJumpHeightMax; // 0x1F4(0x4)
	int PlayerJumpSpeedMax; // 0x1F8(0x4)
	uint8_t Pad_0x1FC[0x4]; // 0x1FC(0x4)
};

// Object: ScriptStruct Gameplay.TeammatHurtFlow
// Size: 0x10 (Inherited: 0x0)
struct FTeammatHurtFlow
{
	struct TArray<struct FTeammatHurtFlowNode> TeammatHurtList; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.TeammatHurtFlowNode
// Size: 0x60 (Inherited: 0x0)
struct FTeammatHurtFlowNode
{
	struct FString HurtPlayerName; // 0x0(0x10)
	int GameModeType; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString MakeHurtPlayerName; // 0x18(0x10)
	struct FString DataTimes; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	struct FString OpenID; // 0x50(0x10)
};

// Object: ScriptStruct Gameplay.ForbitPickFlow
// Size: 0x10 (Inherited: 0x0)
struct FForbitPickFlow
{
	struct TArray<struct FForbitPickFlowNode> forbitList; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.ForbitPickFlowNode
// Size: 0x48 (Inherited: 0x0)
struct FForbitPickFlowNode
{
	struct FString PlayerName; // 0x0(0x10)
	uint16_t AreaID; // 0x10(0x2)
	uint8_t PlatID; // 0x12(0x1)
	uint8_t Pad_0x13[0x5]; // 0x13(0x5)
	struct FString ZoneID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	struct TArray<int> forbitNumList; // 0x38(0x10)
};

// Object: ScriptStruct Gameplay.ClientGameEndFlow
// Size: 0x148 (Inherited: 0x0)
struct FClientGameEndFlow
{
	int64_t ClientStartTime; // 0x0(0x8)
	struct TArray<int> MrpcsFlow; // 0x8(0x10)
	struct FString ClientVersion; // 0x18(0x10)
	uint32_t OverTime; // 0x28(0x4)
	uint8_t EndType; // 0x2C(0x1)
	uint8_t KillCount; // 0x2D(0x1)
	uint8_t AssistsCount; // 0x2E(0x1)
	uint8_t DropCount; // 0x2F(0x1)
	uint8_t SaveCount; // 0x30(0x1)
	uint8_t RebornCount; // 0x31(0x1)
	uint8_t AliveType : 1; // 0x32(0x1), Mask(0x1)
	uint8_t BitPad_0x32_1 : 7; // 0x32(0x1)
	uint8_t Pad_0x33[0x1]; // 0x33(0x1)
	int GoldGet; // 0x34(0x4)
	int DiamondGet; // 0x38(0x4)
	int ExpGet; // 0x3C(0x4)
	uint8_t WinRank; // 0x40(0x1)
	uint8_t TotalPlayers; // 0x41(0x1)
	uint8_t Pad_0x42[0x2]; // 0x42(0x2)
	int PlayerRank; // 0x44(0x4)
	int RankEnd; // 0x48(0x4)
	int TeamID; // 0x4C(0x4)
	struct FString TeamPlayer1; // 0x50(0x10)
	struct FString TeamPlayer2; // 0x60(0x10)
	struct FString TeamPlayer3; // 0x70(0x10)
	uint8_t TeamPlayer1AliveType : 1; // 0x80(0x1), Mask(0x1)
	uint8_t TeamPlayer2AliveType : 1; // 0x80(0x1), Mask(0x2)
	uint8_t TeamPlayer3AliveType : 1; // 0x80(0x1), Mask(0x4)
	uint8_t BitPad_0x80_3 : 5; // 0x80(0x1)
	uint8_t TeamPlayer1Kill; // 0x81(0x1)
	uint8_t TeamPlayer2Kill; // 0x82(0x1)
	uint8_t TeamPlayer3Kill; // 0x83(0x1)
	uint32_t GameEndFlowID; // 0x84(0x4)
	uint8_t RoundCircleCount; // 0x88(0x1)
	uint8_t Pad_0x89[0x7]; // 0x89(0x7)
	struct TArray<int> UseQuickMsgIDArray; // 0x90(0x10)
	struct TArray<int> UseQuickMsgCountArray; // 0xA0(0x10)
	struct TArray<int> UseWheelMsgIDArray; // 0xB0(0x10)
	struct TArray<int> UseWheelMsgCountArray; // 0xC0(0x10)
	struct TArray<int> InexistentAvatarStat; // 0xD0(0x10)
	struct TArray<int> InexistentAvatarInBornStat; // 0xE0(0x10)
	struct TArray<int> InexistentWeaponAvatarStat; // 0xF0(0x10)
	struct TArray<int> InexistentVehicleAvatarStat; // 0x100(0x10)
	int InexistentPlaneAvatarStat; // 0x110(0x4)
	int InexistentEmoteAvatarStat; // 0x114(0x4)
	uint8_t ShowMsgCnt; // 0x118(0x1)
	uint8_t UserConfirmCnt; // 0x119(0x1)
	uint8_t UserCancelCnt; // 0x11A(0x1)
	uint8_t UserDoNothingCnt; // 0x11B(0x1)
	float FPSBeforeAdapt; // 0x11C(0x4)
	float FPSAfterAdapt; // 0x120(0x4)
	float TeammateMicrophoneTime; // 0x124(0x4)
	float TeammateSpeakerTime; // 0x128(0x4)
	float EnemyMicrophoneTime; // 0x12C(0x4)
	float EnemySpeakerTime; // 0x130(0x4)
	float TeammateInterphoneTime; // 0x134(0x4)
	float EnemyInterphoneTime; // 0x138(0x4)
	uint8_t PlayerUseQuickSight; // 0x13C(0x1)
	uint8_t PlayerUseShoulderCnt; // 0x13D(0x1)
	uint8_t Pad_0x13E[0x2]; // 0x13E(0x2)
	int PlayerMoveSpeedMax; // 0x140(0x4)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
};

// Object: ScriptStruct Gameplay.InexistentAvatarFlow
// Size: 0x1E0 (Inherited: 0x0)
struct FInexistentAvatarFlow
{
	uint8_t Pad_0x0[0x1E0]; // 0x0(0x1E0)
};

// Object: ScriptStruct Gameplay.DSFinalCircleFlow
// Size: 0xB8 (Inherited: 0x0)
struct FDSFinalCircleFlow
{
	int64_t dtEventTime; // 0x0(0x8)
	uint64_t BattleID; // 0x8(0x8)
	uint64_t RoleID; // 0x10(0x8)
	uint32_t GameStartTime; // 0x18(0x4)
	uint32_t FlowReportTime; // 0x1C(0x4)
	uint32_t NewCircleBornTime; // 0x20(0x4)
	int NewCircleCount; // 0x24(0x4)
	int RecoveryTotal; // 0x28(0x4)
	int EnergyRecoveryTotal; // 0x2C(0x4)
	int PlayerMoveDis; // 0x30(0x4)
	int PlayerDriveMoveDis; // 0x34(0x4)
	int PlayerDriveMoveTime; // 0x38(0x4)
	int PlayerCreepMoveTime; // 0x3C(0x4)
	int RecordType; // 0x40(0x4)
	int PlayerKillRealPlayerCount; // 0x44(0x4)
	int PlayerKillMLDeliverAICount; // 0x48(0x4)
	int PlayerKillMLAICount; // 0x4C(0x4)
	int PlayerKillBehaviorTreeDeliverAICount; // 0x50(0x4)
	int PlayerKillBehaviorTreeAICount; // 0x54(0x4)
	int KillerType; // 0x58(0x4)
	int KnockDownRealPlayerCount; // 0x5C(0x4)
	int KnockDownMLDeliverAICount; // 0x60(0x4)
	int KnockDownMLAICount; // 0x64(0x4)
	int KnockDownBehaviorTreeDeliverAICount; // 0x68(0x4)
	int KnockDownBehaviorTreeAICount; // 0x6C(0x4)
	int BeKnockDownRealPlayerCount; // 0x70(0x4)
	int BeKnockDownMLDeliverAICount; // 0x74(0x4)
	int BeKnockDownMLAICount; // 0x78(0x4)
	int BeKnockDownBehaviorTreeDeliverAICount; // 0x7C(0x4)
	int BeKnockDownBehaviorTreeAICount; // 0x80(0x4)
	int DamageRealPlayerAmount; // 0x84(0x4)
	int DamageMLDeliverAIAmount; // 0x88(0x4)
	int DamageMLAIAmount; // 0x8C(0x4)
	int DamageBehaviorTreeDeliverAIAmount; // 0x90(0x4)
	int DamageBehaviorTreeAIAmount; // 0x94(0x4)
	int DamageFromRealPlayerAmount; // 0x98(0x4)
	int DamageFromMLDeliverAIAmount; // 0x9C(0x4)
	int DamageFromMLAIAmount; // 0xA0(0x4)
	int DamageFromBehaviorTreeDeliverAIAmount; // 0xA4(0x4)
	int DamageFromBehaviorTreeAIAmount; // 0xA8(0x4)
	int TeammateNum; // 0xAC(0x4)
	int MapID; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
};

// Object: ScriptStruct Gameplay.CircleFlow
// Size: 0x2B0 (Inherited: 0x0)
struct FCircleFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	struct FString PicUrl; // 0x88(0x10)
	uint64_t RoleID; // 0x98(0x8)
	uint8_t RoleType; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	uint32_t GameStartTime; // 0xA4(0x4)
	uint32_t NewCircleBornTime; // 0xA8(0x4)
	int NewCirclePositionX; // 0xAC(0x4)
	int NewCirclePositionY; // 0xB0(0x4)
	int NewCirclePositionRadius; // 0xB4(0x4)
	int NewCircleCount; // 0xB8(0x4)
	int PlayerPositionX; // 0xBC(0x4)
	int PlayerPositionY; // 0xC0(0x4)
	int PlayerPositionZ; // 0xC4(0x4)
	int PlayerHP; // 0xC8(0x4)
	uint32_t OldCircleMoveTime; // 0xCC(0x4)
	uint32_t OldCircleMoveEndTime; // 0xD0(0x4)
	int PlayerOutTime; // 0xD4(0x4)
	int CirclePoisonCount; // 0xD8(0x4)
	int CirclePoisonMin; // 0xDC(0x4)
	int CirclePoisonMax; // 0xE0(0x4)
	int CirclePoisonAvg; // 0xE4(0x4)
	int CirclePoisonTotal; // 0xE8(0x4)
	int CirclePoisonDrop; // 0xEC(0x4)
	int CirclePoisonDead; // 0xF0(0x4)
	int RecoveryCount; // 0xF4(0x4)
	int RecoveryMin; // 0xF8(0x4)
	int RecoveryMax; // 0xFC(0x4)
	int RecoveryTotal; // 0x100(0x4)
	int EnergyRecoveryCount; // 0x104(0x4)
	int EnergyRecoveryMin; // 0x108(0x4)
	int EnergyRecoveryMax; // 0x10C(0x4)
	int EnergyRecoveryTotal; // 0x110(0x4)
	uint8_t Pad_0x114[0x4]; // 0x114(0x4)
	struct FString RecoveryItemCounts; // 0x118(0x10)
	int EnergyStartLv; // 0x128(0x4)
	int EnergyStartTime; // 0x12C(0x4)
	struct FString EnergyItemUse; // 0x130(0x10)
	int EnergyLvTimeInfo; // 0x140(0x4)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
	struct FString EnergyRunFastTime; // 0x148(0x10)
	struct FString EnergyRecoveryLvTimeInfo; // 0x158(0x10)
	int EnergyEndLv; // 0x168(0x4)
	int EnergyEndTime; // 0x16C(0x4)
	int PlayerMoveDis; // 0x170(0x4)
	int PlayerSpeedMax; // 0x174(0x4)
	int PlayerSpeedAvg; // 0x178(0x4)
	int PlayerCarSpeedMax; // 0x17C(0x4)
	int PlayerCarSpeedAvg; // 0x180(0x4)
	int PlayerSquatMoveDis; // 0x184(0x4)
	int PlayerSquatMoveTime; // 0x188(0x4)
	int PlayerCreepMoveDis; // 0x18C(0x4)
	int PlayerCreepMoveTime; // 0x190(0x4)
	int PlayerRunMoveDis; // 0x194(0x4)
	int PlayerRunMoveTime; // 0x198(0x4)
	int PlayerDriveMoveDis; // 0x19C(0x4)
	int PlayerDriveMoveTime; // 0x1A0(0x4)
	int PlayerCar; // 0x1A4(0x4)
	int PlayerCameraDistanceMax; // 0x1A8(0x4)
	uint32_t SecCircleFlowID; // 0x1AC(0x4)
	int RecordType; // 0x1B0(0x4)
	uint8_t AutoAimType; // 0x1B4(0x1)
	uint8_t Pad_0x1B5[0x3]; // 0x1B5(0x3)
	int AutoAimTime; // 0x1B8(0x4)
	int PlayerKillCount; // 0x1BC(0x4)
	int PlayerKillAICount; // 0x1C0(0x4)
	int PlayerHeadKillCount; // 0x1C4(0x4)
	int PlayerKillRealPlayerCount; // 0x1C8(0x4)
	int PlayerKillMLDeliverAICount; // 0x1CC(0x4)
	int PlayerKillMLAICount; // 0x1D0(0x4)
	int PlayerKillBehaviorTreeDeliverAICount; // 0x1D4(0x4)
	int PlayerKillBehaviorTreeAICount; // 0x1D8(0x4)
	int KillerType; // 0x1DC(0x4)
	int KnockDownRealPlayerCount; // 0x1E0(0x4)
	int KnockDownMLDeliverAICount; // 0x1E4(0x4)
	int KnockDownMLAICount; // 0x1E8(0x4)
	int KnockDownBehaviorTreeDeliverAICount; // 0x1EC(0x4)
	int KnockDownBehaviorTreeAICount; // 0x1F0(0x4)
	int BeKnockDownRealPlayerCount; // 0x1F4(0x4)
	int BeKnockDownMLDeliverAICount; // 0x1F8(0x4)
	int BeKnockDownMLAICount; // 0x1FC(0x4)
	int BeKnockDownBehaviorTreeDeliverAICount; // 0x200(0x4)
	int BeKnockDownBehaviorTreeAICount; // 0x204(0x4)
	int DamageRealPlayerAmount; // 0x208(0x4)
	int DamageMLDeliverAIAmount; // 0x20C(0x4)
	int DamageMLAIAmount; // 0x210(0x4)
	int DamageBehaviorTreeDeliverAIAmount; // 0x214(0x4)
	int DamageBehaviorTreeAIAmount; // 0x218(0x4)
	int DamageFromRealPlayerAmount; // 0x21C(0x4)
	int DamageFromMLDeliverAIAmount; // 0x220(0x4)
	int DamageFromMLAIAmount; // 0x224(0x4)
	int DamageFromBehaviorTreeDeliverAIAmount; // 0x228(0x4)
	int DamageFromBehaviorTreeAIAmount; // 0x22C(0x4)
	int AssistCount; // 0x230(0x4)
	int AirDropCount; // 0x234(0x4)
	int PickUpItemTimes; // 0x238(0x4)
	int RescueCount; // 0x23C(0x4)
	int ShotWeaponCount; // 0x240(0x4)
	int PlayerHatID; // 0x244(0x4)
	int PlayerMaskID; // 0x248(0x4)
	int PlayerShirtID; // 0x24C(0x4)
	int PlayerPantsID; // 0x250(0x4)
	int MedicineEnergyCnt; // 0x254(0x4)
	int MedicineAdrenalineCnt; // 0x258(0x4)
	int MedicinePainkillerCnt; // 0x25C(0x4)
	int MedicineBandageCnt; // 0x260(0x4)
	int MedicineFirstAidKitCnt; // 0x264(0x4)
	int MedicineTreatmentCnt; // 0x268(0x4)
	float OccupiedCapacity; // 0x26C(0x4)
	float ArmorPoints; // 0x270(0x4)
	int TeammateNum; // 0x274(0x4)
	int MainWeaponId1; // 0x278(0x4)
	int MainWeaponBulletId1; // 0x27C(0x4)
	int MainWeaponBulletNum1; // 0x280(0x4)
	int MainWeaponId2; // 0x284(0x4)
	int MainWeaponBulletId2; // 0x288(0x4)
	int MainWeaponBulletNum2; // 0x28C(0x4)
	int SubWeaponID; // 0x290(0x4)
	int SubWeaponBulletId; // 0x294(0x4)
	int SubWeaponBulletNum; // 0x298(0x4)
	uint8_t Pad_0x29C[0x4]; // 0x29C(0x4)
	struct FString MrpcsFlowStr; // 0x2A0(0x10)
};

// Object: ScriptStruct Gameplay.DSCircleFlow
// Size: 0x28 (Inherited: 0x0)
struct FDSCircleFlow
{
	uint32_t GameStartTime; // 0x0(0x4)
	uint32_t NewCircleBornTime; // 0x4(0x4)
	int NewCircleCount; // 0x8(0x4)
	int RecoveryTotal; // 0xC(0x4)
	int EnergyRecoveryTotal; // 0x10(0x4)
	int PlayerMoveDis; // 0x14(0x4)
	int PlayerDriveMoveDis; // 0x18(0x4)
	int PlayerDriveMoveTime; // 0x1C(0x4)
	int PlayerCreepMoveTime; // 0x20(0x4)
	int RecordType; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.ClientCircleFlow
// Size: 0x158 (Inherited: 0x0)
struct FClientCircleFlow
{
	int64_t ClientStartTime; // 0x0(0x8)
	struct TArray<int> MrpcsFlow; // 0x8(0x10)
	struct FString PicUrl; // 0x18(0x10)
	uint32_t GameStartTime; // 0x28(0x4)
	uint32_t NewCircleBornTime; // 0x2C(0x4)
	int NewCirclePositionX; // 0x30(0x4)
	int NewCirclePositionY; // 0x34(0x4)
	int NewCirclePositionRadius; // 0x38(0x4)
	int NewCircleCount; // 0x3C(0x4)
	int PlayerPositionX; // 0x40(0x4)
	int PlayerPositionY; // 0x44(0x4)
	int PlayerPositionZ; // 0x48(0x4)
	int PlayerHP; // 0x4C(0x4)
	uint32_t OldCircleMoveTime; // 0x50(0x4)
	uint32_t OldCircleMoveEndTime; // 0x54(0x4)
	uint32_t PlayerOutTime; // 0x58(0x4)
	int CirclePoisonCount; // 0x5C(0x4)
	int CirclePoisonMin; // 0x60(0x4)
	int CirclePoisonMax; // 0x64(0x4)
	int CirclePoisonAvg; // 0x68(0x4)
	int CirclePoisonTotal; // 0x6C(0x4)
	int CirclePoisonDrop; // 0x70(0x4)
	int CirclePoisonDead; // 0x74(0x4)
	int RecoveryCount; // 0x78(0x4)
	int RecoveryMin; // 0x7C(0x4)
	int RecoveryMax; // 0x80(0x4)
	int RecoveryTotal; // 0x84(0x4)
	int EnergyRecoveryCount; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
	struct TArray<struct FRecoveryItemCount> RecoveryItemCounts; // 0x90(0x10)
	int EnergyRecoveryMin; // 0xA0(0x4)
	int EnergyRecoveryMax; // 0xA4(0x4)
	int EnergyRecoveryTotal; // 0xA8(0x4)
	int EnergyStartLv; // 0xAC(0x4)
	int EnergyStartTime; // 0xB0(0x4)
	uint8_t Pad_0xB4[0x4]; // 0xB4(0x4)
	struct FString EnergyItemUse; // 0xB8(0x10)
	int EnergyLvTimeInfo; // 0xC8(0x4)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct FString EnergyRunFastTime; // 0xD0(0x10)
	struct FString EnergyRecoveryLvTimeInfo; // 0xE0(0x10)
	int EnergyEndLv; // 0xF0(0x4)
	int EnergyEndTime; // 0xF4(0x4)
	int PlayerMoveDis; // 0xF8(0x4)
	int PlayerSpeedMax; // 0xFC(0x4)
	int PlayerSpeedAvg; // 0x100(0x4)
	int PlayerCarSpeedMax; // 0x104(0x4)
	int PlayerCarSpeedAvg; // 0x108(0x4)
	int PlayerSquatMoveDis; // 0x10C(0x4)
	int PlayerSquatMoveTime; // 0x110(0x4)
	int PlayerCreepMoveDis; // 0x114(0x4)
	int PlayerCreepMoveTime; // 0x118(0x4)
	int PlayerRunMoveDis; // 0x11C(0x4)
	int PlayerRunMoveTime; // 0x120(0x4)
	int PlayerDriveMoveDis; // 0x124(0x4)
	int PlayerDriveMoveTime; // 0x128(0x4)
	int PlayerCar; // 0x12C(0x4)
	int PlayerCameraDistanceMax; // 0x130(0x4)
	uint32_t SecCircleFlowID; // 0x134(0x4)
	int RecordType; // 0x138(0x4)
	uint8_t AutoAimType; // 0x13C(0x1)
	uint8_t Pad_0x13D[0x3]; // 0x13D(0x3)
	int AutoAimTime; // 0x140(0x4)
	uint8_t Pad_0x144[0x4]; // 0x144(0x4)
	struct TArray<uint8_t> MrpcsFlowData; // 0x148(0x10)
};

// Object: ScriptStruct Gameplay.RecoveryItemCount
// Size: 0x8 (Inherited: 0x0)
struct FRecoveryItemCount
{
	uint32_t ItemId; // 0x0(0x4)
	uint32_t Count; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.JumpFlow
// Size: 0x150 (Inherited: 0x0)
struct FJumpFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct FString PicUrl; // 0x98(0x10)
	struct FString MapName; // 0xA8(0x10)
	uint8_t WeatherID; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x7]; // 0xB9(0x7)
	int64_t GameStartTime; // 0xC0(0x8)
	uint32_t StartJumpTime; // 0xC8(0x4)
	uint32_t EndJumpTime; // 0xCC(0x4)
	uint32_t PlayerJumpTime; // 0xD0(0x4)
	uint32_t PlayerOpenTime; // 0xD4(0x4)
	uint32_t PlayerLandTime; // 0xD8(0x4)
	int PlayerJumpPositionX; // 0xDC(0x4)
	int PlayerJumpPositionY; // 0xE0(0x4)
	int PlayerJumpPositionZ; // 0xE4(0x4)
	int PlaneJumpPositionX; // 0xE8(0x4)
	int PlaneJumpPositionY; // 0xEC(0x4)
	int PlaneJumpPositionZ; // 0xF0(0x4)
	int PlayerLandPositionX; // 0xF4(0x4)
	int PlayerLandPositionY; // 0xF8(0x4)
	int PlayerLandPositionZ; // 0xFC(0x4)
	uint32_t PlayerLandDistance; // 0x100(0x4)
	uint32_t PlayerSpeedMax1; // 0x104(0x4)
	uint32_t PlayerSpeedMax2; // 0x108(0x4)
	uint8_t Pad_0x10C[0x4]; // 0x10C(0x4)
	struct FString AntsVoiceTeamID; // 0x110(0x10)
	struct FString AntsVoiceRoomID; // 0x120(0x10)
	int AntsVoiceTeamMemberID; // 0x130(0x4)
	int AntsVoiceRoomMemberID; // 0x134(0x4)
	struct FString FollowPlayerUID; // 0x138(0x10)
	uint32_t ExitFollowTime; // 0x148(0x4)
	uint8_t Pad_0x14C[0x4]; // 0x14C(0x4)
};

// Object: ScriptStruct Gameplay.ClientJumpFlow
// Size: 0xC0 (Inherited: 0x0)
struct FClientJumpFlow
{
	int64_t ClientStartTime; // 0x0(0x8)
	struct TArray<int> MrpcsFlow; // 0x8(0x10)
	struct FString MapName; // 0x18(0x10)
	uint8_t WeatherID; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	int64_t GameStartTime; // 0x30(0x8)
	uint32_t StartJumpTime; // 0x38(0x4)
	uint32_t EndJumpTime; // 0x3C(0x4)
	uint32_t PlayerJumpTime; // 0x40(0x4)
	uint32_t PlayerOpenTime; // 0x44(0x4)
	uint32_t PlayerLandTime; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct FString FollowPlayerUID; // 0x50(0x10)
	uint32_t ExitFollowTime; // 0x60(0x4)
	int PlayerJumpPositionX; // 0x64(0x4)
	int PlayerJumpPositionY; // 0x68(0x4)
	int PlayerJumpPositionZ; // 0x6C(0x4)
	int PlaneJumpPositionX; // 0x70(0x4)
	int PlaneJumpPositionY; // 0x74(0x4)
	int PlaneJumpPositionZ; // 0x78(0x4)
	int PlayerLandPositionX; // 0x7C(0x4)
	int PlayerLandPositionY; // 0x80(0x4)
	int PlayerLandPositionZ; // 0x84(0x4)
	uint32_t PlayerLandDistance; // 0x88(0x4)
	uint32_t PlayerSpeedMax1; // 0x8C(0x4)
	uint32_t PlayerSpeedMax2; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
	struct FString AntsVoiceTeamID; // 0x98(0x10)
	struct FString AntsVoiceRoomID; // 0xA8(0x10)
	int AntsVoiceTeamMemberID; // 0xB8(0x4)
	int AntsVoiceRoomMemberID; // 0xBC(0x4)
};

// Object: ScriptStruct Gameplay.GameStartFlow
// Size: 0x1B8 (Inherited: 0x0)
struct FGameStartFlow
{
	struct FString GameSvrId; // 0x0(0x10)
	int64_t dtEventTime; // 0x10(0x8)
	struct FString GameAppID; // 0x18(0x10)
	struct FString OpenID; // 0x28(0x10)
	uint16_t AreaID; // 0x38(0x2)
	uint8_t PlatID; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x5]; // 0x3B(0x5)
	struct FString ZoneID; // 0x40(0x10)
	uint64_t BattleID; // 0x50(0x8)
	int64_t ClientStartTime; // 0x58(0x8)
	int MrpcsFlowcount_; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
	struct TArray<int> MrpcsFlow; // 0x68(0x10)
	struct FString UserName; // 0x78(0x10)
	uint64_t RoleID; // 0x88(0x8)
	uint8_t RoleType; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct FString PicUrl; // 0x98(0x10)
	uint32_t SvrUserMoney1; // 0xA8(0x4)
	uint32_t SvrUserMoney2; // 0xAC(0x4)
	uint32_t SvrUserMoney3; // 0xB0(0x4)
	int SvrRoundRank; // 0xB4(0x4)
	int SvrRoundRank1; // 0xB8(0x4)
	int SvrRoundRank2; // 0xBC(0x4)
	int SvrRoundRank3; // 0xC0(0x4)
	uint8_t Pad_0xC4[0x4]; // 0xC4(0x4)
	uint64_t SvrRoleID; // 0xC8(0x8)
	uint8_t SvrRoleType; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
	struct FString SvrMapName; // 0xD8(0x10)
	uint8_t SvrWeatherid; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
	struct FString SvrItemList; // 0xF0(0x10)
	int64_t WaitStartTime; // 0x100(0x8)
	int64_t WaitEndTime; // 0x108(0x8)
	struct FString MapName; // 0x110(0x10)
	uint8_t WeatherID; // 0x120(0x1)
	uint8_t Pad_0x121[0x7]; // 0x121(0x7)
	struct FString ItemList; // 0x128(0x10)
	uint8_t GameType; // 0x138(0x1)
	uint8_t TeamType; // 0x139(0x1)
	uint8_t AutoMatch; // 0x13A(0x1)
	uint8_t PlayerCount; // 0x13B(0x1)
	int TeamID; // 0x13C(0x4)
	struct FString TeamPlayer1; // 0x140(0x10)
	struct FString TeamPlayer2; // 0x150(0x10)
	struct FString TeamPlayer3; // 0x160(0x10)
	int TeamPlayer1Rank; // 0x170(0x4)
	int TeamPlayer2Rank; // 0x174(0x4)
	int TeamPlayer3Rank; // 0x178(0x4)
	uint32_t SecGameStartFlowFlowID; // 0x17C(0x4)
	struct FString AntsVoiceTeamID; // 0x180(0x10)
	struct FString AntsVoiceRoomID; // 0x190(0x10)
	int AntsVoiceTeamMemberID; // 0x1A0(0x4)
	int AntsVoiceRoomMemberID; // 0x1A4(0x4)
	struct FString IP; // 0x1A8(0x10)
};

// Object: ScriptStruct Gameplay.ClientGameStartFlow
// Size: 0xA8 (Inherited: 0x0)
struct FClientGameStartFlow
{
	int64_t ClientStartTime; // 0x0(0x8)
	struct TArray<int> MrpcsFlow; // 0x8(0x10)
	struct FString MapName; // 0x18(0x10)
	uint8_t WeatherID; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FString ItemList; // 0x30(0x10)
	uint8_t TeamType; // 0x40(0x1)
	uint8_t Pad_0x41[0x3]; // 0x41(0x3)
	int TeamID; // 0x44(0x4)
	struct FString TeamPlayer1; // 0x48(0x10)
	struct FString TeamPlayer2; // 0x58(0x10)
	struct FString TeamPlayer3; // 0x68(0x10)
	uint32_t SecGameStartFlowFlowID; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
	struct FString AntsVoiceTeamID; // 0x80(0x10)
	struct FString AntsVoiceRoomID; // 0x90(0x10)
	int AntsVoiceTeamMemberID; // 0xA0(0x4)
	int AntsVoiceRoomMemberID; // 0xA4(0x4)
};

// Object: ScriptStruct Gameplay.IntPosition3D
// Size: 0xC (Inherited: 0x0)
struct FIntPosition3D
{
	int X; // 0x0(0x4)
	int Y; // 0x4(0x4)
	int Z; // 0x8(0x4)
};

// Object: ScriptStruct Gameplay.PlayerRouteFlow
// Size: 0x78 (Inherited: 0x0)
struct FPlayerRouteFlow
{
	struct FString GameAppID; // 0x0(0x10)
	uint8_t PlatID; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
	struct FString OpenID; // 0x18(0x10)
	uint64_t UID; // 0x28(0x8)
	uint64_t BattleID; // 0x30(0x8)
	uint8_t SeasonID; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FString PlayerName; // 0x40(0x10)
	struct TArray<struct FPosAndTime> Route; // 0x50(0x10)
	struct FPosAndTime End; // 0x60(0x18)
};

// Object: ScriptStruct Gameplay.PosAndTime
// Size: 0x18 (Inherited: 0x0)
struct FPosAndTime
{
	int LocationX; // 0x0(0x4)
	int LocationY; // 0x4(0x4)
	int LocationZ; // 0x8(0x4)
	int Time; // 0xC(0x4)
	uint64_t PlayerState; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.ItemGenerateSpawnClass
// Size: 0xD8 (Inherited: 0x0)
struct FItemGenerateSpawnClass
{
	int ID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UObject* ItemClass; // 0x8(0x8)
	struct FString ItemPath; // 0x10(0x10)
	int ItemCount; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString MetaData; // 0x28(0x10)
	struct FString ItemValue; // 0x38(0x10)
	struct FString ItemCategory; // 0x48(0x10)
	bool bRepeatGenerateItem; // 0x58(0x1)
	bool IsNearItem; // 0x59(0x1)
	uint8_t Pad_0x5A[0x2]; // 0x5A(0x2)
	struct FVector SpotGenerateLoc; // 0x5C(0xC)
	struct FVector SpotGroupLoc; // 0x68(0xC)
	struct FRotator SpotRotator; // 0x74(0xC)
	int SpotPercent; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct FString SpotDefaultTag; // 0x88(0x10)
	uint8_t Pad_0x98[0x8]; // 0x98(0x8)
	struct AActor* HostActor; // 0xA0(0x8)
	struct TWeakObjectPtr<struct AActor> AttachedActor; // 0xA8(0x8)
	uint8_t Pad_0xB0[0x14]; // 0xB0(0x14)
	int SpotIndex; // 0xC4(0x4)
	bool Random; // 0xC8(0x1)
	bool IsStickToTheGround; // 0xC9(0x1)
	uint8_t Pad_0xCA[0x2]; // 0xCA(0x2)
	struct FVector RelativeLoc; // 0xCC(0xC)
};

// Object: ScriptStruct Gameplay.VehicleSpotDebugData
// Size: 0x38 (Inherited: 0x0)
struct FVehicleSpotDebugData
{
	struct FString VehicleSpotName; // 0x0(0x10)
	enum class ESpotType SpotType; // 0x10(0x1)
	enum class ESpotGroupType SpotGroupType; // 0x11(0x1)
	uint8_t Pad_0x12[0x6]; // 0x12(0x6)
	struct FString VehiclePath; // 0x18(0x10)
	float VehicleLocationX; // 0x28(0x4)
	float VehicleLocationY; // 0x2C(0x4)
	float VehicleLocationZ; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.VehicleGenerateStatisticsData
// Size: 0x60 (Inherited: 0x0)
struct FVehicleGenerateStatisticsData
{
	struct TArray<struct FVehicleSpotStatisticsData> VehicleSpotStatisticsData; // 0x0(0x10)
	struct TMap<struct FString, struct FVehicleClassStatisticsData> VehicleClassStatisticsData; // 0x10(0x50)
};

// Object: ScriptStruct Gameplay.VehicleClassStatisticsData
// Size: 0x20 (Inherited: 0x8)
struct FVehicleClassStatisticsData : FTableRowBase
{
	struct FString VehiclePath; // 0x8(0x10)
	bool bValidPath; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int AllVehicleCount; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.VehicleSpotStatisticsData
// Size: 0x30 (Inherited: 0x8)
struct FVehicleSpotStatisticsData : FTableRowBase
{
	enum class ESpotType SpotType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct FString VehiclePath; // 0x10(0x10)
	float VehicleLocationX; // 0x20(0x4)
	float VehicleLocationY; // 0x24(0x4)
	float VehicleLocationZ; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.ItemGenerateStatisticsData
// Size: 0x110 (Inherited: 0x0)
struct FItemGenerateStatisticsData
{
	int AllGroupSpotCount; // 0x0(0x4)
	int AllValidGroupSpotCount; // 0x4(0x4)
	int AllSpotCount; // 0x8(0x4)
	int AllValidSpotCount; // 0xC(0x4)
	struct TMap<enum class ESpotGroupType, struct FItemGroupStatisticsData> GroupStatisticsData; // 0x10(0x50)
	struct TMap<struct FString, struct FBuildingStatisticsData> BuildingStatisticsData; // 0x60(0x50)
	struct TMap<struct FString, struct FItemClassStatisticsData> ItemStatisticsData; // 0xB0(0x50)
	struct TArray<struct FAreaItemStatisticsData> AreaItemStatisticsData; // 0x100(0x10)
};

// Object: ScriptStruct Gameplay.AreaItemStatisticsData
// Size: 0x50 (Inherited: 0x8)
struct FAreaItemStatisticsData : FTableRowBase
{
	struct FString ItemName; // 0x8(0x10)
	int UID; // 0x18(0x4)
	int ItemId; // 0x1C(0x4)
	int GroupType; // 0x20(0x4)
	int SpotType; // 0x24(0x4)
	struct FString AreaName; // 0x28(0x10)
	struct FVector Location; // 0x38(0xC)
	float X; // 0x44(0x4)
	float Y; // 0x48(0x4)
	int GameTime; // 0x4C(0x4)
};

// Object: ScriptStruct Gameplay.ItemClassStatisticsData
// Size: 0x38 (Inherited: 0x8)
struct FItemClassStatisticsData : FTableRowBase
{
	struct FString ItemPath; // 0x8(0x10)
	bool bValidPath; // 0x18(0x1)
	uint8_t Pad_0x19[0x3]; // 0x19(0x3)
	int ItemCount; // 0x1C(0x4)
	struct FString ItemTogetherPath; // 0x20(0x10)
	int ItemTogetherCount; // 0x30(0x4)
	bool bValidTogetherPath; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
};

// Object: ScriptStruct Gameplay.BuildingStatisticsData
// Size: 0x80 (Inherited: 0x8)
struct FBuildingStatisticsData : FTableRowBase
{
	struct FString BuildingName; // 0x8(0x10)
	float BuildingLocationX; // 0x18(0x4)
	float BuildingLocationY; // 0x1C(0x4)
	int AllGroupSpotCount; // 0x20(0x4)
	int AllValidGroupSpotCount; // 0x24(0x4)
	int AllSpotCount; // 0x28(0x4)
	int AllValidSpotCount; // 0x2C(0x4)
	struct TMap<enum class ESpotType, struct FItemSpotStatisticsData> SpotStatisticsData; // 0x30(0x50)
};

// Object: ScriptStruct Gameplay.ItemSpotStatisticsData
// Size: 0x18 (Inherited: 0x8)
struct FItemSpotStatisticsData : FTableRowBase
{
	enum class ESpotType SpotType; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	int AllSpotCount; // 0xC(0x4)
	int AllValidSpotCount; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Gameplay.ItemGroupStatisticsData
// Size: 0x20 (Inherited: 0x8)
struct FItemGroupStatisticsData : FTableRowBase
{
	enum class ESpotGroupType SpotGroupType; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	int AllGroupSpotCount; // 0xC(0x4)
	int AllValidGroupSpotCount; // 0x10(0x4)
	int AllSpotCount; // 0x14(0x4)
	int AllValidSpotCount; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.SpotStatisticsData
// Size: 0x60 (Inherited: 0x8)
struct FSpotStatisticsData : FTableRowBase
{
	enum class ESpotGroupType GroupType; // 0x8(0x1)
	enum class ESpotType SpotType; // 0x9(0x1)
	uint8_t Pad_0xA[0x6]; // 0xA(0x6)
	struct FString AreaName; // 0x10(0x10)
	struct FString SpotDefaultTag; // 0x20(0x10)
	bool NearItem; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	struct FVector Location; // 0x34(0xC)
	float X; // 0x40(0x4)
	float Y; // 0x44(0x4)
	float Z; // 0x48(0x4)
	bool RandomRot; // 0x4C(0x1)
	uint8_t Pad_0x4D[0x3]; // 0x4D(0x3)
	struct FRotator Rotator; // 0x50(0xC)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
};

// Object: ScriptStruct Gameplay.VehicleGenerateRandomInfo
// Size: 0x28 (Inherited: 0x0)
struct FVehicleGenerateRandomInfo
{
	struct FString VehicleType; // 0x0(0x10)
	struct FString VehiclePath; // 0x10(0x10)
	float FuelPercent; // 0x20(0x4)
	bool SnapFloor; // 0x24(0x1)
	bool bActiveByStartVolume; // 0x25(0x1)
	uint8_t Pad_0x26[0x2]; // 0x26(0x2)
};

// Object: ScriptStruct Gameplay.VehicleGenerateSpawnData
// Size: 0x30 (Inherited: 0x0)
struct FVehicleGenerateSpawnData
{
	int KeyID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString VehicleType; // 0x8(0x10)
	struct FString VehiclePath; // 0x18(0x10)
	int VehicleWeight; // 0x28(0x4)
	bool SnapFloor; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
};

// Object: ScriptStruct Gameplay.TreasureBoxSpotProperty
// Size: 0x20 (Inherited: 0x0)
struct FTreasureBoxSpotProperty
{
	enum class ESpotType SpotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct FSpotWeight> WeightsPerCategory; // 0x8(0x10)
	int TotalCountRangeMin; // 0x18(0x4)
	int TotalCountRangeMax; // 0x1C(0x4)
};

// Object: ScriptStruct Gameplay.VehicleSpotProperty
// Size: 0x38 (Inherited: 0x0)
struct FVehicleSpotProperty
{
	enum class ESpotType SpotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct FSpotWeight> WeightsPerCategory; // 0x8(0x10)
	int FuelPercentMin; // 0x18(0x4)
	int FuelPercentMax; // 0x1C(0x4)
	bool bActiveByStartVolume; // 0x20(0x1)
	enum class EVehicleSpotRandomType RandomType; // 0x21(0x1)
	uint8_t Pad_0x22[0x2]; // 0x22(0x2)
	float TotalCountMultiplierWithPalyerCount; // 0x24(0x4)
	int TotalCountRangeMin; // 0x28(0x4)
	int TotalCountRangeMax; // 0x2C(0x4)
	float ProbabilityPersent; // 0x30(0x4)
	float ProbabilityPersentWithPalyerCount; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.CharCustomAnimInstacneData
// Size: 0x20 (Inherited: 0x0)
struct FCharCustomAnimInstacneData
{
	struct FUAEBlackboardKeySelector CustomAnimInstacneType; // 0x0(0x8)
	struct UAnimInstance* CustomAnimInstacneSoftPtr; // 0x8(0x8)
	struct FString CustomAnimInstanceName; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.CharCustomAnimData
// Size: 0x58 (Inherited: 0x0)
struct FCharCustomAnimData
{
	struct FUAEBlackboardKeySelector CustomAnimType; // 0x0(0x8)
	struct UAnimationAsset* CustomAnimSoftPtr; // 0x8(0x28)
	struct UAnimationAsset* CustomAnim; // 0x30(0x8)
	struct FString CustomAnimName; // 0x38(0x10)
	uint8_t Pad_0x48[0x10]; // 0x48(0x10)
};

// Object: ScriptStruct Gameplay.CharParachuteAnimData
// Size: 0x48 (Inherited: 0x0)
struct FCharParachuteAnimData
{
	enum class ECharacterParachuteAnimType ParachuteAnimType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UAnimationAsset* ParachuteAnimSoftPtr; // 0x8(0x28)
	struct UAnimationAsset* ParachuteAnim; // 0x30(0x8)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
};

// Object: ScriptStruct Gameplay.GetAnimUtil
// Size: 0x20 (Inherited: 0x0)
struct FGetAnimUtil
{
	struct TArray<struct FSoftObjectPath> PendingList; // 0x0(0x10)
	struct UUAECharacterAnimListSubSystem* AnimListSubSystem; // 0x10(0x8)
	uint8_t Pad_0x18[0x8]; // 0x18(0x8)
};

// Object: ScriptStruct Gameplay.CharacterVehAnimModifyData
// Size: 0x38 (Inherited: 0x0)
struct FCharacterVehAnimModifyData
{
	uint8_t VehicleType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int SeatIdx; // 0x4(0x4)
	enum class ECharacterVehicleAnimType VehicleAnimType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct UAnimationAsset* VehicleAnimSoftPtr; // 0x10(0x28)
};

// Object: ScriptStruct Gameplay.CharAnimModifyData
// Size: 0x38 (Inherited: 0x0)
struct FCharAnimModifyData
{
	int AppliedGameMode; // 0x0(0x4)
	enum class ECharaAnimListType ModifyAnimListType; // 0x4(0x1)
	enum class ECharacterAnimType AnimType; // 0x5(0x1)
	enum class ECharacterPoseType PoseType; // 0x6(0x1)
	enum class ECharacterJumpType JumpType; // 0x7(0x1)
	enum class ECharacterJumpPhase JumpPhase; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct UAnimationAsset* PoseAnimSoftPtr; // 0x10(0x28)
};

// Object: ScriptStruct Gameplay.CharacterMovementAnimData
// Size: 0xA0 (Inherited: 0x0)
struct FCharacterMovementAnimData
{
	enum class ECharacterAnimType AnimType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FName AnimTypeName; // 0x8(0x8)
	struct FChararacterPoseAnimData PoseAnim_Stand; // 0x10(0x30)
	struct FChararacterPoseAnimData PoseAnim_Crouch; // 0x40(0x30)
	struct FChararacterPoseAnimData PoseAnim_Prone; // 0x70(0x30)
};

// Object: ScriptStruct Gameplay.ChararacterPoseAnimData
// Size: 0x30 (Inherited: 0x0)
struct FChararacterPoseAnimData
{
	enum class ECharacterPoseType PoseType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UAnimationAsset* PoseAnimSoftPtr; // 0x8(0x28)
};

// Object: ScriptStruct Gameplay.AsyncLoadCharAnimParams
// Size: 0x28 (Inherited: 0x0)
struct FAsyncLoadCharAnimParams
{
	uint8_t Pad_0x0[0x28]; // 0x0(0x28)
};

// Object: ScriptStruct Gameplay.CharacterAnimStartAsynLoadParam
// Size: 0x2 (Inherited: 0x0)
struct FCharacterAnimStartAsynLoadParam
{
	enum class ECharacterAnimTypeAsynLoaded AnimType; // 0x0(0x1)
	enum class ECharacterViewType CharacterViewType; // 0x1(0x1)
};

// Object: ScriptStruct Gameplay.CharacterAnimAsynLoadCompleteParam
// Size: 0x48 (Inherited: 0x0)
struct FCharacterAnimAsynLoadCompleteParam
{
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString AnimsCatorgeryName; // 0x8(0x10)
	enum class ECharacterViewType CharacterViewType; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
	struct UAnimationAsset* SoftPtrAnimation; // 0x20(0x28)
};

// Object: ScriptStruct Gameplay.CharacterAsynLoadedTypeAnim
// Size: 0x78 (Inherited: 0x0)
struct FCharacterAsynLoadedTypeAnim
{
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString AnimsCatorgeryName; // 0x8(0x10)
	struct FCharacterAnimTypeAsynLoadedPhaseData Anim; // 0x18(0x60)
};

// Object: ScriptStruct Gameplay.CharacterAnimTypeAsynLoadedPhaseData
// Size: 0x60 (Inherited: 0x0)
struct FCharacterAnimTypeAsynLoadedPhaseData
{
	struct FString PhaseName; // 0x0(0x10)
	struct TMap<enum class ECharacterViewType, struct UAnimationAsset*> PhaseAnimSoftPtr; // 0x10(0x50)
};

// Object: ScriptStruct Gameplay.CharacterShovelAnimData
// Size: 0xC0 (Inherited: 0x0)
struct FCharacterShovelAnimData
{
	struct FCharacterShovelPhaseData ShovelPhase_Enter; // 0x0(0x30)
	struct FCharacterShovelPhaseData ShovelPhase_Shoveling; // 0x30(0x30)
	struct FCharacterShovelPhaseData ShovelPhase_Leave; // 0x60(0x30)
	struct FCharacterShovelPhaseData ShovelPhase_Crouch_Leave; // 0x90(0x30)
};

// Object: ScriptStruct Gameplay.CharacterShovelPhaseData
// Size: 0x30 (Inherited: 0x0)
struct FCharacterShovelPhaseData
{
	uint8_t ShovelPhase; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UAnimationAsset* PhaseAnimSoftPtr; // 0x8(0x28)
};

// Object: ScriptStruct Gameplay.CharacterJumpAnimData
// Size: 0x1C0 (Inherited: 0x0)
struct FCharacterJumpAnimData
{
	enum class ECharacterJumpType JumpType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FName JumpTypeName; // 0x8(0x8)
	struct FChararacterJumpPhaseData JumpPhase_PreJump; // 0x10(0x30)
	struct FChararacterJumpPhaseData JumpPhase_FallLoop0; // 0x40(0x30)
	struct FChararacterJumpPhaseData JumpPhase_FallLoop1; // 0x70(0x30)
	struct FChararacterJumpPhaseData JumpPhase_Land0; // 0xA0(0x30)
	struct FChararacterJumpPhaseData JumpPhase_Land1; // 0xD0(0x30)
	struct FChararacterJumpPhaseData JumpPhase_GrenadeJump_0; // 0x100(0x30)
	struct FChararacterJumpPhaseData JumpPhase_GrenadeJump_1; // 0x130(0x30)
	struct FChararacterJumpPhaseData JumpPhase_GrenadeFall_0; // 0x160(0x30)
	struct FChararacterJumpPhaseData JumpPhase_GrenadeFall_1; // 0x190(0x30)
};

// Object: ScriptStruct Gameplay.ChararacterJumpPhaseData
// Size: 0x30 (Inherited: 0x0)
struct FChararacterJumpPhaseData
{
	enum class ECharacterJumpPhase JumpPhase; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct UAnimationAsset* PhaseAnimSoftPtr; // 0x8(0x28)
};

// Object: ScriptStruct Gameplay.AsyncLoadCharVehAnimParams
// Size: 0x18 (Inherited: 0x0)
struct FAsyncLoadCharVehAnimParams
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct Gameplay.DynamicLoadActors
// Size: 0x10 (Inherited: 0x0)
struct FDynamicLoadActors
{
	struct TArray<struct AActor*> ActorArray; // 0x0(0x10)
};

// Object: ScriptStruct Gameplay.DSAIDropInfo
// Size: 0x20 (Inherited: 0x0)
struct FDSAIDropInfo
{
	uint64_t BattleID; // 0x0(0x8)
	int nts; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct TArray<struct FDSAIDropItem> ais; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.DSAIDropItem
// Size: 0x10 (Inherited: 0x0)
struct FDSAIDropItem
{
	uint64_t UID; // 0x0(0x8)
	int Time; // 0x8(0x4)
	uint8_t hlv; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};

// Object: ScriptStruct Gameplay.SpawnItemStat
// Size: 0x38 (Inherited: 0x0)
struct FSpawnItemStat
{
	struct FString ItemCategory; // 0x0(0x10)
	struct FString ItemValue; // 0x10(0x10)
	int Together; // 0x20(0x4)
	int Count; // 0x24(0x4)
	struct FString TriggerName; // 0x28(0x10)
};

// Object: ScriptStruct Gameplay.DamageMatchGroup
// Size: 0x50 (Inherited: 0x0)
struct FDamageMatchGroup
{
	struct TMap<int, float> DamageMatchPairs; // 0x0(0x50)
};

// Object: ScriptStruct Gameplay.SeqActorBindingData
// Size: 0x18 (Inherited: 0x0)
struct FSeqActorBindingData
{
	struct FString TrackName; // 0x0(0x10)
	struct AActor* BindingActor; // 0x10(0x8)
};

// Object: ScriptStruct Gameplay.CharSpecialLevelSequenceData
// Size: 0xF0 (Inherited: 0x0)
struct FCharSpecialLevelSequenceData
{
	enum class ECharSpecialLevelSequenceType LevelSequenceType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FLevelSequenceConfig LevelSequenceConfig; // 0x8(0xE8)
};

// Object: ScriptStruct Gameplay.LevelSequenceConfig
// Size: 0xE8 (Inherited: 0x0)
struct FLevelSequenceConfig
{
	struct FSoftClassPath SequenceActorTemplate; // 0x0(0x18)
	struct ULevelSequence* LevelSequence; // 0x18(0x28)
	float LevelSequenceDuration; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct TMap<struct FString, struct FString> TrackBindingInfos; // 0x48(0x50)
	struct TMap<struct FString, struct FSoftObjectPath> TrackBindingObjects; // 0x98(0x50)
};

// Object: ScriptStruct Gameplay.LobbyAsyncLoadCharAnimParams
// Size: 0x20 (Inherited: 0x0)
struct FLobbyAsyncLoadCharAnimParams
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct Gameplay.PlayerAMInfo
// Size: 0x28 (Inherited: 0x0)
struct FPlayerAMInfo
{
	uint64_t PlayerUID; // 0x0(0x8)
	struct TArray<struct FBattleItemSpectatingData> PlayerCollectItem; // 0x8(0x10)
	struct TArray<struct FBattleItemSpectatingData> PlayerUseItem; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.PlayerSightUsageInfoCompress
// Size: 0x18 (Inherited: 0x0)
struct FPlayerSightUsageInfoCompress
{
	struct TArray<uint8_t> TotalUseTime; // 0x0(0x10)
	uint8_t Index; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct Gameplay.PlayerSightUsageInfo
// Size: 0x20 (Inherited: 0x0)
struct FPlayerSightUsageInfo
{
	struct TArray<float> LastStartTime; // 0x0(0x10)
	struct TArray<int> TotalUsage; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.PlayerStatisticForPCOB
// Size: 0x20 (Inherited: 0x0)
struct FPlayerStatisticForPCOB
{
	struct TArray<int> StatisticInt; // 0x0(0x10)
	struct TArray<float> StatisticFloat; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.GatherPlayerInfoForPCOB
// Size: 0x8 (Inherited: 0x0)
struct FGatherPlayerInfoForPCOB
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
};

// Object: ScriptStruct Gameplay.GatherPlayerFloatInfoForPCOB
// Size: 0x10 (Inherited: 0x8)
struct FGatherPlayerFloatInfoForPCOB : FGatherPlayerInfoForPCOB
{
	float Num; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.GatherPlayerIntInfoForPCOB
// Size: 0x10 (Inherited: 0x8)
struct FGatherPlayerIntInfoForPCOB : FGatherPlayerInfoForPCOB
{
	int Num; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Gameplay.PlayerFiringList
// Size: 0x10 (Inherited: 0x0)
struct FPlayerFiringList
{
	uint64_t PlayerFiringIndexLow; // 0x0(0x8)
	uint64_t PlayerFiringIndexHigh; // 0x8(0x8)
};

// Object: ScriptStruct Gameplay.PlayerBreathInfoList
// Size: 0x20 (Inherited: 0x0)
struct FPlayerBreathInfoList
{
	uint64_t PlayerIndexLow; // 0x0(0x8)
	uint64_t PlayerIndexHigh; // 0x8(0x8)
	struct TArray<uint8_t> BreathList; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.PlayerKeyIndexForSort
// Size: 0x8 (Inherited: 0x0)
struct FPlayerKeyIndexForSort
{
	uint32_t PlayerKey; // 0x0(0x4)
	uint32_t Index; // 0x4(0x4)
};

// Object: ScriptStruct Gameplay.PlanAGPlayerReportData
// Size: 0x30 (Inherited: 0x0)
struct FPlanAGPlayerReportData
{
	uint64_t UID; // 0x0(0x8)
	int TeamID; // 0x8(0x4)
	int TwoTargetScore; // 0xC(0x4)
	int FiveTargetScore; // 0x10(0x4)
	int FourColorTargetScore; // 0x14(0x4)
	int GophersTargetScore; // 0x18(0x4)
	int DishTargetScore; // 0x1C(0x4)
	int AirdropTargetScore; // 0x20(0x4)
	int SpeedUpTargetNum; // 0x24(0x4)
	int BulletNum; // 0x28(0x4)
	float CurrentCityShootingAccuracy; // 0x2C(0x4)
};

// Object: ScriptStruct Gameplay.PlanAGTeamReportData
// Size: 0x88 (Inherited: 0x0)
struct FPlanAGTeamReportData
{
	int TeamID; // 0x0(0x4)
	int TwoTargetScore; // 0x4(0x4)
	int FiveTargetScore; // 0x8(0x4)
	int FourColorTargetScore; // 0xC(0x4)
	int GophersTargetScore; // 0x10(0x4)
	int DishTargetScore; // 0x14(0x4)
	int AirdropTargetScore; // 0x18(0x4)
	int SpeedUpTargetNum; // 0x1C(0x4)
	int CurrentCityTwoTargetScore; // 0x20(0x4)
	int CurrentCityFiveTargetScore; // 0x24(0x4)
	int CurrentCityFourColorTargetScore; // 0x28(0x4)
	int CurrentCityGophersTargetScore; // 0x2C(0x4)
	int CurrentCityDishTargetScore; // 0x30(0x4)
	int CurrentCityAirdropTargetScore; // 0x34(0x4)
	int CurrentCitySpeedUpTargetNum; // 0x38(0x4)
	float ShootingAccuracy; // 0x3C(0x4)
	float TeamChecktime; // 0x40(0x4)
	int TeamOrder; // 0x44(0x4)
	float CurrentCityStayTime; // 0x48(0x4)
	float OverTime; // 0x4C(0x4)
	struct TArray<float> StageCompletedTime; // 0x50(0x10)
	struct TArray<float> EnterStageTimeStamp; // 0x60(0x10)
	int VehicleResetNum; // 0x70(0x4)
	int Fuel; // 0x74(0x4)
	int FuelMax; // 0x78(0x4)
	int Speed; // 0x7C(0x4)
	int RefuelingTime; // 0x80(0x4)
	float CompletionProgress; // 0x84(0x4)
};

// Object: ScriptStruct Gameplay.AirDropBoxInOb
// Size: 0x14 (Inherited: 0x0)
struct FAirDropBoxInOb
{
	int boxId; // 0x0(0x4)
	bool Flying; // 0x4(0x1)
	bool IsEmpty; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	struct FVector pos; // 0x8(0xC)
};

// Object: ScriptStruct Gameplay.TeamInfoInOB
// Size: 0x38 (Inherited: 0x0)
struct FTeamInfoInOB
{
	int TeamID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString TeamName; // 0x8(0x10)
	bool IsShowLogo; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
	struct FString LogoPicUrl; // 0x20(0x10)
	int KillNum; // 0x30(0x4)
	int LiveMemberNum; // 0x34(0x4)
};

// Object: ScriptStruct Gameplay.PlayerAfterMatchAPI
// Size: 0x48 (Inherited: 0x0)
struct FPlayerAfterMatchAPI
{
	uint32_t PlayerKey; // 0x0(0x4)
	int InDamage; // 0x4(0x4)
	int Heal; // 0x8(0x4)
	int HeadShotNum; // 0xC(0x4)
	int SurvivalTime; // 0x10(0x4)
	int DriveDistance; // 0x14(0x4)
	int marchDistance; // 0x18(0x4)
	int Assists; // 0x1C(0x4)
	float OutsideBlueCircleTime; // 0x20(0x4)
	int Knockouts; // 0x24(0x4)
	int rescueTimes; // 0x28(0x4)
	int UseSmokeGrenadeNum; // 0x2C(0x4)
	int UseFragGrenadeNum; // 0x30(0x4)
	int UseBurnGrenadeNum; // 0x34(0x4)
	int UseFlashGrenadeNum; // 0x38(0x4)
	int PoisonTotalDamage; // 0x3C(0x4)
	int UseSelfRescueTime; // 0x40(0x4)
	int UseEmergencyCallTime; // 0x44(0x4)
};

// Object: ScriptStruct Gameplay.PlayerRealTimeAPI
// Size: 0x28 (Inherited: 0x0)
struct FPlayerRealTimeAPI
{
	uint32_t PlayerKey; // 0x0(0x4)
	int AIKillNum; // 0x4(0x4)
	int GotAirDropNum; // 0x8(0x4)
	int MaxKillDistance; // 0xC(0x4)
	int Damage; // 0x10(0x4)
	int KillNumInVehicle; // 0x14(0x4)
	int KillNumByGrenade; // 0x18(0x4)
	int Rank; // 0x1C(0x4)
	bool IsOutsideBlueCircle; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	int BossKillNum; // 0x24(0x4)
};

// Object: ScriptStruct Gameplay.UAESpawnActorParam
// Size: 0x90 (Inherited: 0x0)
struct FUAESpawnActorParam
{
	int TemplateID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UObject* ActorClass; // 0x8(0x8)
	struct FVector SpawnLocation; // 0x10(0xC)
	struct FRotator SpawnRotator; // 0x1C(0xC)
	struct FVector SpawnOffsetLoc; // 0x28(0xC)
	uint8_t CollisionHandling; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	float RandomRadius; // 0x38(0x4)
	bool RandomRotYaw; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
	struct TArray<struct AActor*> TraceAvoidClass; // 0x40(0x10)
	struct AActor* Owner; // 0x50(0x8)
	struct APawn* Instigator; // 0x58(0x8)
	struct FString MakerName; // 0x60(0x10)
	bool IsTracePos; // 0x70(0x1)
	bool IsHalfCapsulePull; // 0x71(0x1)
	enum class EActorSpawnType SpawnType; // 0x72(0x1)
	uint8_t Pad_0x73[0x1]; // 0x73(0x1)
	int ZTraceOffset; // 0x74(0x4)
	int MonsterBornType; // 0x78(0x4)
	int MonsterFrontBornType; // 0x7C(0x4)
	uint8_t FeatureSetType; // 0x80(0x1)
	uint8_t Pad_0x81[0xF]; // 0x81(0xF)
};

// Object: ScriptStruct Gameplay.UAESpotDataSerialize
// Size: 0x210 (Inherited: 0x0)
struct FUAESpotDataSerialize
{
	uint8_t Pad_0x0[0x210]; // 0x0(0x210)
};

// Object: ScriptStruct Gameplay.UAEWindowPackageData
// Size: 0x60 (Inherited: 0x0)
struct FUAEWindowPackageData
{
	struct TWeakObjectPtr<struct AUAEHouseActor> HouseActor; // 0x0(0x8)
	struct UObject* WindowClass; // 0x8(0x8)
	struct FUAEWindowRepData WindowData; // 0x10(0x50)
};

// Object: ScriptStruct Gameplay.BackupVehicleSpotData
// Size: 0x24 (Inherited: 0x0)
struct FBackupVehicleSpotData
{
	int ID; // 0x0(0x4)
	enum class ESpotGroupType SpotGroupType; // 0x4(0x1)
	enum class ESpotType SpotType; // 0x5(0x1)
	uint8_t Pad_0x6[0x2]; // 0x6(0x2)
	struct FVector SpotGenerateLoc; // 0x8(0xC)
	struct FRotator SpotRotator; // 0x14(0xC)
	bool bRandomRotation; // 0x20(0x1)
	bool bUsed; // 0x21(0x1)
	uint8_t Pad_0x22[0x2]; // 0x22(0x2)
};

// Object: ScriptStruct Gameplay.VehicleSpotComponentArray
// Size: 0x18 (Inherited: 0x0)
struct FVehicleSpotComponentArray
{
	enum class ESpotType SpotType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct UVehicleSpotSceneComponent*> AllSpots; // 0x8(0x10)
};

// Object: ScriptStruct Gameplay.VehicleGenerateSpawnDataArray
// Size: 0x20 (Inherited: 0x0)
struct FVehicleGenerateSpawnDataArray
{
	struct FString Catetory; // 0x0(0x10)
	struct TArray<struct FVehicleGenerateSpawnData> AllGenerateSpawnDatas; // 0x10(0x10)
};

// Object: ScriptStruct Gameplay.TotalWeaponReport
// Size: 0x28 (Inherited: 0x0)
struct FTotalWeaponReport
{
	struct FString BattleID; // 0x0(0x10)
	int BattleMode; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FOnePlayerWeapon> TotalWeaponRecord; // 0x18(0x10)
};

// Object: ScriptStruct Gameplay.WeatherLevelInfo
// Size: 0x20 (Inherited: 0x0)
struct FWeatherLevelInfo
{
	int WeatherID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString WeatherLevelName; // 0x8(0x10)
	float WeatherTime; // 0x18(0x4)
	int WeatherSyncCount; // 0x1C(0x4)
};

// Object: Class Gameplay.BackpackRepActor
// Size: 0x4E8 (Inherited: 0x4C0)
struct ABackpackRepActor : APlayerReliableSequentialSyncActor
{
	struct UBackpackComponent* BackpackComp; // 0x4C0(0x8)
	struct FIncNetArray ItemListNet; // 0x4C8(0x20)


	// Object: Function Gameplay.BackpackRepActor.OnRep_ItemListNet
	// Flags: [Final|Native|Public]
	// Offset: 0x1046012b4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ItemListNet();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C

	// Object: Function Gameplay.BackpackRepActor.NotifyItemUpdated
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046011ac
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemUpdated(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104560208
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.BackpackRepActor.NotifyItemRemoved
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046010a4
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemRemoved(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104560214
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041E55E0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104560208
	// [Call #18] RVA: 0x1041E56B0
	// [Call #19] RVA: 0x1041E56B0
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function Gameplay.BackpackRepActor.NotifyItemEmpty
	// Flags: [Final|Native|Public]
	// Offset: 0x104601028
	// Params: [ Num(1) Size(0x4) ]
	void NotifyItemEmpty(int Slack);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104560220
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E55E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104560214
	// [Call #11] RVA: 0x1041E56B0
	// [Call #12] RVA: 0x1041E56B0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041E55E0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackRepActor.NotifyItemAdded
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104600f20
	// Params: [ Num(2) Size(0xD8) ]
	void NotifyItemAdded(struct FItemDefineID& DefineID, struct FBattleItemData& ItemData);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E55E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045601FC
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104560220
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041E55E0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class Gameplay.UAEGameMode
// Size: 0x16C0 (Inherited: 0x5E8)
struct AUAEGameMode : ALuaGameMode
{
	struct TWeakObjectPtr<struct UObject> UtilsPtr; // 0x5E8(0x8)
	float GridCheckSize; // 0x5F0(0x4)
	float DeepCheckSize; // 0x5F4(0x4)
	float HeightCheckSize; // 0x5F8(0x4)
	int MaxPlayerLimit; // 0x5FC(0x4)
	uint8_t Pad_0x600[0xC]; // 0x600(0xC)
	bool bEnableClimbing; // 0x60C(0x1)
	bool IsUseFpsVault; // 0x60D(0x1)
	bool bBornWithApple; // 0x60E(0x1)
	bool bUseDefaultResultRules; // 0x60F(0x1)
	int AntiDataCD; // 0x610(0x4)
	bool PlayerValidCheckResult; // 0x614(0x1)
	uint8_t Pad_0x615[0x3]; // 0x615(0x3)
	int WeatherID; // 0x618(0x4)
	uint8_t Pad_0x61C[0x4]; // 0x61C(0x4)
	struct FString WeatherName; // 0x620(0x10)
	int RoomMode; // 0x630(0x4)
	int SeasonIdx; // 0x634(0x4)
	float MeteorShowerRatio; // 0x638(0x4)
	uint8_t Pad_0x63C[0x4]; // 0x63C(0x4)
	struct FString ItemTableName; // 0x640(0x10)
	struct UClass* ItemClassPath; // 0x650(0x28)
	struct FString ReplayPushURL; // 0x678(0x10)
	int ReplayType; // 0x688(0x4)
	uint8_t Pad_0x68C[0x4]; // 0x68C(0x4)
	struct FString ReplayTitle; // 0x690(0x10)
	uint8_t EnableObserverEnemyTrace; // 0x6A0(0x1)
	uint8_t Pad_0x6A1[0x7]; // 0x6A1(0x7)
	struct TArray<struct FString> ItemSpawnTableList; // 0x6A8(0x10)
	struct TArray<struct FString> IgnoreItemClassPathList; // 0x6B8(0x10)
	struct TArray<struct FDSSwitchInfo> DsSwitch; // 0x6C8(0x10)
	struct TArray<int> TimeIDSwitch; // 0x6D8(0x10)
	struct TMap<uint64_t, struct FCharacterMoveDragData> CharacterMoveDragDataMap; // 0x6E8(0x50)
	struct TMap<uint64_t, struct FParachuteDragData> ParachuteDragDataMap; // 0x738(0x50)
	struct TMap<uint64_t, struct FVehicleMoveDragDataFriendly> VehicleMoveDrag; // 0x788(0x50)
	struct TArray<struct FVehicleCorrectionData> VehicleCorrections; // 0x7D8(0x10)
	struct TArray<struct FVehicleProtectionReportData> VehicleProtections; // 0x7E8(0x10)
	struct TMap<uint64_t, struct FCharacterShootVerifyData> CharacterShootVerifyDataMap; // 0x7F8(0x50)
	struct TMap<uint64_t, struct FCharacterShootVerifyStat> CharacterShootVerifyStatMap; // 0x848(0x50)
	uint32_t ServerStartTime; // 0x898(0x4)
	bool bOpenChangeWearing; // 0x89C(0x1)
	bool bEnableVehicleInReady; // 0x89D(0x1)
	uint8_t Pad_0x89E[0x2]; // 0x89E(0x2)
	struct UClass* PickupBoxConfigClassPath; // 0x8A0(0x28)
	bool bUseAutoGroupParachuteTeam; // 0x8C8(0x1)
	uint8_t Pad_0x8C9[0x7]; // 0x8C9(0x7)
	struct FString PickupBoxConfigDataTableName; // 0x8D0(0x10)
	struct FString VehicleTableName; // 0x8E0(0x10)
	struct UClass* VehicleClassPath; // 0x8F0(0x28)
	bool IsUsingSceneDropWeight; // 0x918(0x1)
	bool IsRegionItemGenerate; // 0x919(0x1)
	uint8_t Pad_0x91A[0x2]; // 0x91A(0x2)
	struct FVector RegionCenter; // 0x91C(0xC)
	float RegionRadius; // 0x928(0x4)
	uint8_t Pad_0x92C[0x4]; // 0x92C(0x4)
	struct TMap<struct FString, float> BattleCustomConfig; // 0x930(0x50)
	int MaxAllowReplicatedCharacterCount; // 0x980(0x4)
	int AINoRepTimeInReady; // 0x984(0x4)
	struct AUAEOBState* ObserverPlayerStateClass; // 0x988(0x8)
	bool bEnableDamage; // 0x990(0x1)
	uint8_t Pad_0x991[0x3]; // 0x991(0x3)
	float NearDeathRestoredOriginHealth; // 0x994(0x4)
	float NearDeathDecreateBreathRate; // 0x998(0x4)
	float RescueOtherRestoreDuration; // 0x99C(0x4)
	float RescueSelfRestoreDuration; // 0x9A0(0x4)
	float DeadTombBoxLifeSpan; // 0x9A4(0x4)
	int DefaultPlayerBornPointID; // 0x9A8(0x4)
	bool bPlayerExitClearPlayerData; // 0x9AC(0x1)
	bool bEnableDSTickLua; // 0x9AD(0x1)
	bool bClientIgnoreMLAI; // 0x9AE(0x1)
	uint8_t Pad_0x9AF[0x1]; // 0x9AF(0x1)
	struct FString ActorGridGeneratorClassPath; // 0x9B0(0x10)
	struct TArray<struct UGroupSpotSceneComponent*> ItemGroupComponents; // 0x9C0(0x10)
	struct AActor* ChosenPlayerStartBuildingGroup; // 0x9D0(0x8)
	struct TArray<struct FDynamicTriggerConfig> DynamicTriggerConfigs; // 0x9D8(0x10)
	struct TArray<struct AActor*> DynamicTriggers; // 0x9E8(0x10)
	int IsGameModeFpp; // 0x9F8(0x4)
	bool IsGameModeBandSpot; // 0x9FC(0x1)
	uint8_t Pad_0x9FD[0x3]; // 0x9FD(0x3)
	struct TArray<struct FDynamicLoadItem> DynamicLoadItemArray; // 0xA00(0x10)
	struct TMap<struct FDynamicLoadItem, struct FDynamicLoadActors> DynamicLoadItemMap; // 0xA10(0x50)
	struct TArray<struct FVehicleAvatarReplaceCfg> VehicleAvatarReplaceCfgList; // 0xA60(0x10)
	bool IsOpenItemGenerate; // 0xA70(0x1)
	bool IsOpenVehicleGenerate; // 0xA71(0x1)
	uint8_t Pad_0xA72[0x6]; // 0xA72(0x6)
	struct TArray<int> DynamicLevelArray; // 0xA78(0x10)
	struct FString RoomType; // 0xA88(0x10)
	bool bCanLedgeGrab; // 0xA98(0x1)
	bool bOpenForbitTeammatePickUp; // 0xA99(0x1)
	bool bOpenTeammateImprisonment; // 0xA9A(0x1)
	uint8_t Pad_0xA9B[0x1]; // 0xA9B(0x1)
	int ZoneID; // 0xA9C(0x4)
	int nClientType; // 0xAA0(0x4)
	int MainModeID; // 0xAA4(0x4)
	int RealPlayerNums; // 0xAA8(0x4)
	bool bABTestModify; // 0xAAC(0x1)
	uint8_t Pad_0xAAD[0x4B]; // 0xAAD(0x4B)
	struct FScriptMulticastDelegate OnGameModeStateChanged; // 0xAF8(0x10)
	uint8_t Pad_0xB08[0x110]; // 0xB08(0x110)
	DelegateProperty SendTeammateResultWhenChicken; // 0xC18(0x10)
	DelegateProperty HaveSentTeamBattleResult; // 0xC28(0x10)
	struct FScriptMulticastDelegate SendTeamBattleResult; // 0xC38(0x10)
	uint8_t Pad_0xC48[0x110]; // 0xC48(0x110)
	struct FScriptMulticastDelegate SendGameStopJoin; // 0xD58(0x10)
	uint8_t Pad_0xD68[0x420]; // 0xD68(0x420)
	bool bIsPreCreatingPlayerController; // 0x1188(0x1)
	uint8_t Pad_0x1189[0x13F]; // 0x1189(0x13F)
	float OBInfoTimeStep; // 0x12C8(0x4)
	uint8_t Pad_0x12CC[0x2C]; // 0x12CC(0x2C)
	struct TArray<struct FAirDropBoxInOb> AirDropBoxInfoList; // 0x12F8(0x10)
	struct TArray<struct AUAEPlayerController*> KickFlagControllerList; // 0x1308(0x10)
	struct TArray<struct AUAEPlayerController*> ObserverControllerList; // 0x1318(0x10)
	uint8_t Pad_0x1328[0xD8]; // 0x1328(0xD8)
	struct AUAEAdvertisementActor* AdvertisementActorBP; // 0x1400(0x8)
	struct TArray<struct FAdvertisementActorConfig> AdvConfigList; // 0x1408(0x10)
	struct TArray<struct AUAEAdvertisementActor*> AdvActorList; // 0x1418(0x10)
	struct TArray<struct FMissionBoardConfig> MissionBoardConfigList; // 0x1428(0x10)
	bool bEnablePlaneBanner; // 0x1438(0x1)
	uint8_t Pad_0x1439[0x7]; // 0x1439(0x7)
	struct FString HttpPlaneBannerLeftImgPath; // 0x1440(0x10)
	struct FString HttpPlaneBannerRightImgPath; // 0x1450(0x10)
	struct FString GrenadeEffectPath; // 0x1460(0x10)
	bool bUseSpecialGrenadeEffect; // 0x1470(0x1)
	bool bAnniversarySignalGunEffect; // 0x1471(0x1)
	bool bAvatarDownloadInBattle; // 0x1472(0x1)
	bool bOpenAnniversaryActivity; // 0x1473(0x1)
	uint8_t Pad_0x1474[0x4]; // 0x1474(0x4)
	struct FString FestivalAirDropBoxMesh; // 0x1478(0x10)
	bool bUseFestivalAirDropBox; // 0x1488(0x1)
	uint8_t Pad_0x1489[0x3]; // 0x1489(0x3)
	float FestivalAirDropProb; // 0x148C(0x4)
	float MonsterDropPar; // 0x1490(0x4)
	float SceneDropParam; // 0x1494(0x4)
	uint32_t DSOpenSwtich; // 0x1498(0x4)
	uint8_t Pad_0x149C[0x4]; // 0x149C(0x4)
	struct UItemGeneratorComponent* ItemGenerator; // 0x14A0(0x8)
	struct UVehicleAndTreasureBoxGeneratorComponent* VehicleGenerator; // 0x14A8(0x8)
	bool bGameNeedReplay; // 0x14B0(0x1)
	uint8_t Pad_0x14B1[0x7]; // 0x14B1(0x7)
	struct TArray<uint32_t> NeedReplayPlayers; // 0x14B8(0x10)
	struct TArray<struct FSeasonStatueData> SeasonStatueList; // 0x14C8(0x10)
	struct FString SeasonStatueClassPath; // 0x14D8(0x10)
	struct FString StatueBaseClassPath; // 0x14E8(0x10)
	struct FStatueBaseData StatueBaseInfo; // 0x14F8(0x68)
	int BattleStopJoin; // 0x1560(0x4)
	int nSignalGunEffectId; // 0x1564(0x4)
	struct TArray<struct FCharacterOverrideAttrData> CharacterOverrideAttrs; // 0x1568(0x10)
	uint8_t Pad_0x1578[0xA0]; // 0x1578(0xA0)
	bool UseGMSpawnItemSpotDefaultTag; // 0x1618(0x1)
	uint8_t Pad_0x1619[0x7]; // 0x1619(0x7)
	struct FString GMSpawnItemSpotDefaultTag; // 0x1620(0x10)
	uint8_t Pad_0x1630[0x80]; // 0x1630(0x80)
	bool bStandAloneGameMode; // 0x16B0(0x1)
	bool bStandAloneLuaGenAIData; // 0x16B1(0x1)
	uint8_t Pad_0x16B2[0x2]; // 0x16B2(0x2)
	int StandAloneTestPlayerKey; // 0x16B4(0x4)
	struct FName StandAloneTestPlayerType; // 0x16B8(0x8)


	// Object: Function Gameplay.UAEGameMode.WriteStatistics
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x10465f930
	// Params: [ Num(0) Size(0x0) ]
	void WriteStatistics();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.UAEGameMode.SyncPlayerNames
	// Flags: [Native|Public]
	// Offset: 0x10465f914
	// Params: [ Num(0) Size(0x0) ]
	void SyncPlayerNames();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.UAEGameMode.SyncNewCorpsData
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465f864
	// Params: [ Num(1) Size(0x10) ]
	void SyncNewCorpsData(struct TArray<struct FDSCorpsInfo>& OutCorpsData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104664E68
	// [Call #4] RVA: 0x104664E68
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.UAEGameMode.SpawnUAEPawnFor
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10465f76c
	// Params: [ Num(3) Size(0x48) ]
	struct APawn* SpawnUAEPawnFor(struct AController* NewPlayer, struct FTransform Trans);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104664E68
	// [Call #8] RVA: 0x104664E68
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Gameplay.UAEGameMode.SetVehicleReportEntry
	// Flags: [Final|Native|Public]
	// Offset: 0x10465f698
	// Params: [ Num(2) Size(0x1C) ]
	void SetVehicleReportEntry(uint32_t InUniqueID, struct FVehicleReportEntry InEntry);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104664C5C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104664E68

	// Object: Function Gameplay.UAEGameMode.SetPlayerOpenId
	// Flags: [Native|Public]
	// Offset: 0x10465f5bc
	// Params: [ Num(2) Size(0x18) ]
	void SetPlayerOpenId(uint32_t InPlayerKey, struct FString InPlayerOpenID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104664C5C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.SetMaxWeaponReportNum
	// Flags: [Final|Native|Public]
	// Offset: 0x10465f544
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxWeaponReportNum(int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104664C5C

	// Object: Function Gameplay.UAEGameMode.SetKillerPlayerKey
	// Flags: [Native|Public]
	// Offset: 0x10465f484
	// Params: [ Num(2) Size(0xC) ]
	void SetKillerPlayerKey(struct AController* VictimPlayer, uint32_t KillerPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.SetGameEndReportData
	// Flags: [Native|Public]
	// Offset: 0x10465f468
	// Params: [ Num(0) Size(0x0) ]
	void SetGameEndReportData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameMode.RetrieveTeamBattleResultData
	// Flags: [Native|Public]
	// Offset: 0x10465f3ac
	// Params: [ Num(2) Size(0xE0) ]
	struct FGameModeTeamBattleResultData RetrieveTeamBattleResultData(int TeamID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104664A20
	// [Call #4] RVA: 0x10338260C
	// [Call #5] RVA: 0x10338260C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.RetrieveBattleData
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465f318
	// Params: [ Num(1) Size(0x8) ]
	void RetrieveBattleData(struct FBattleData& OutBattleData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104664A20
	// [Call #6] RVA: 0x10338260C
	// [Call #7] RVA: 0x10338260C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.RestartPlayerAtPlayerStart
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10465f25c
	// Params: [ Num(2) Size(0x10) ]
	void RestartPlayerAtPlayerStart(struct AController* NewPlayer, struct AActor* StartSpot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104664A20
	// [Call #10] RVA: 0x10338260C
	// [Call #11] RVA: 0x10338260C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameMode.ResetGameParamsFromGameMode
	// Flags: [Native|Public]
	// Offset: 0x10465f240
	// Params: [ Num(0) Size(0x0) ]
	void ResetGameParamsFromGameMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104664A20
	// [Call #10] RVA: 0x10338260C
	// [Call #11] RVA: 0x10338260C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameMode.Rescue
	// Flags: [Native|Public]
	// Offset: 0x10465f184
	// Params: [ Num(2) Size(0x10) ]
	void Rescue(struct APawn* RescueWho, struct APawn* Hero);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.RegisterItemGroupSpotsByTag
	// Flags: [Native|Public]
	// Offset: 0x10465f0c8
	// Params: [ Num(2) Size(0x10) ]
	void RegisterItemGroupSpotsByTag(struct FName Tag, struct UGroupSpotSceneComponent* GroupSpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.RegisterItemGroupSpots
	// Flags: [Native|Public]
	// Offset: 0x10465f044
	// Params: [ Num(1) Size(0x8) ]
	void RegisterItemGroupSpots(struct UGroupSpotSceneComponent* GroupSpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.RefreshWorldActiveRange
	// Flags: [Native|Public]
	// Offset: 0x10465f028
	// Params: [ Num(0) Size(0x0) ]
	void RefreshWorldActiveRange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.RefreshWatchTeammates
	// Flags: [Native|Public]
	// Offset: 0x10465ef68
	// Params: [ Num(2) Size(0xC) ]
	void RefreshWatchTeammates(struct AUAEPlayerController* InController, int InTeamID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.RefreshPlayerNames
	// Flags: [Native|Public]
	// Offset: 0x10465ed2c
	// Params: [ Num(6) Size(0x2C) ]
	void RefreshPlayerNames(uint32_t InPlayerKey, struct FString InPlayerName, int TeamID, bool IsLogin, uint64_t UID, int IdxInTeam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameMode.RecoardAlivePlayerNum
	// Flags: [Native|Public]
	// Offset: 0x10465ecf0
	// Params: [ Num(1) Size(0x4) ]
	int RecoardAlivePlayerNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0

	// Object: Function Gameplay.UAEGameMode.PreCreatePlayerController
	// Flags: [Native|Public]
	// Offset: 0x10465ec5c
	// Params: [ Num(2) Size(0x10) ]
	struct APlayerController* PreCreatePlayerController(uint32_t PlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnStandAloneGameEnd
	// Flags: [Native|Public]
	// Offset: 0x10465ec40
	// Params: [ Num(0) Size(0x0) ]
	void OnStandAloneGameEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.OnReportNetworkData
	// Flags: [Native|Public]
	// Offset: 0x10465ec24
	// Params: [ Num(0) Size(0x0) ]
	void OnReportNetworkData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnPlayerFiring
	// Flags: [Native|Public]
	// Offset: 0x10465eba0
	// Params: [ Num(1) Size(0x4) ]
	void OnPlayerFiring(uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnPlayerControlDestroyEnd
	// Flags: [Native|Public]
	// Offset: 0x10465eb1c
	// Params: [ Num(1) Size(0x4) ]
	void OnPlayerControlDestroyEnd(uint32_t PlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.OnPlayerBreathChange
	// Flags: [Native|Public]
	// Offset: 0x10465ea5c
	// Params: [ Num(2) Size(0x8) ]
	void OnPlayerBreathChange(uint32_t InPlayerKey, float InBreath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnObserverLogout
	// Flags: [Native|Protected]
	// Offset: 0x10465e9d8
	// Params: [ Num(1) Size(0x8) ]
	void OnObserverLogout(struct AUAEPlayerController* InController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnObserverLogin
	// Flags: [Native|Protected]
	// Offset: 0x10465e954
	// Params: [ Num(1) Size(0x8) ]
	void OnObserverLogin(struct AUAEPlayerController* InController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnMsg
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10465e8b4
	// Params: [ Num(1) Size(0x10) ]
	void OnMsg(struct FString Msg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnAirDropBoxLanded
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10465e7e8
	// Params: [ Num(2) Size(0x10) ]
	void OnAirDropBoxLanded(int boxId, struct FVector& pos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.OnAirDropBoxEmpty
	// Flags: [Native|Public]
	// Offset: 0x10465e764
	// Params: [ Num(1) Size(0x4) ]
	void OnAirDropBoxEmpty(int boxId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyPlayerExitWhenNotStarted
	// Flags: [Native|Public]
	// Offset: 0x10465e64c
	// Params: [ Num(3) Size(0x20) ]
	void NotifyPlayerExitWhenNotStarted(uint32_t PlayerKey, struct FName PlayerType, struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyPlayerExit
	// Flags: [Native|Public]
	// Offset: 0x10465e31c
	// Params: [ Num(8) Size(0x40) ]
	void NotifyPlayerExit(uint32_t PlayerKey, struct FName PlayerType, bool bDestroyPlayerController, bool bDestroyCharacter, bool bSendFailure, struct FString FailureMessage, struct FName ParamState, struct FString ParamReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x101F8122C

	// Object: Function Gameplay.UAEGameMode.NotifyPlayerAbleToExitSafely
	// Flags: [Native|Public]
	// Offset: 0x10465e25c
	// Params: [ Num(2) Size(0x10) ]
	void NotifyPlayerAbleToExitSafely(uint32_t PlayerKey, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyGameModeParamsChanged
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465e1c4
	// Params: [ Num(1) Size(0x10) ]
	void NotifyGameModeParamsChanged(struct FGameModeParams& GameModeParams);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.NotifyGameModeLuckmate
	// Flags: [Native|Public]
	// Offset: 0x10465e108
	// Params: [ Num(2) Size(0x10) ]
	void NotifyGameModeLuckmate(int64_t MyUID, int64_t LuckmateUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.NotifyGameModeInit
	// Flags: [Native|Public]
	// Offset: 0x10465e0ec
	// Params: [ Num(0) Size(0x0) ]
	void NotifyGameModeInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyExistPlayerReEnter
	// Flags: [Native|Public]
	// Offset: 0x10465e068
	// Params: [ Num(1) Size(0x4) ]
	void NotifyExistPlayerReEnter(uint32_t PlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyAIPlayerEnter
	// Flags: [Native|Public]
	// Offset: 0x10465df54
	// Params: [ Num(3) Size(0x6) ]
	void NotifyAIPlayerEnter(uint32_t PlayerKey, bool IsMLAI, bool bTeammateAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.NotifyAIDropInfo
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465de54
	// Params: [ Num(2) Size(0x28) ]
	void NotifyAIDropInfo(int NewAI, struct FDSAIDropInfo& Info);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1035998C8
	// [Call #6] RVA: 0x1035998C8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.ModifyVehicleDamage
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465dcb8
	// Params: [ Num(6) Size(0x34) ]
	float ModifyVehicleDamage(float Damage, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* VictimVehicle, struct AActor* DamageCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.ModifyDamage
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465db1c
	// Params: [ Num(6) Size(0x34) ]
	float ModifyDamage(float Damage, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AController* VictimController, struct AActor* DamageCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.Killed
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465d990
	// Params: [ Num(5) Size(0x30) ]
	void Killed(struct AController* Killer, struct AController* VictimPlayer, struct AActor* DamageCauser, struct APawn* VictimPawn, struct FDamageEvent& DamageEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.IsStandAloneGameMode
	// Flags: [Native|Public]
	// Offset: 0x10465d954
	// Params: [ Num(1) Size(0x1) ]
	bool IsStandAloneGameMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.IsSatisfyGeneratorArea
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10465d8bc
	// Params: [ Num(2) Size(0xD) ]
	bool IsSatisfyGeneratorArea(struct FVector& Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.IsCollectingOBData
	// Flags: [Native|Public|Const]
	// Offset: 0x10465d880
	// Params: [ Num(1) Size(0x1) ]
	bool IsCollectingOBData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.InitWorldActiveRange
	// Flags: [Native|Public]
	// Offset: 0x10465d864
	// Params: [ Num(0) Size(0x0) ]
	void InitWorldActiveRange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.InitSeasonStatue
	// Flags: [Native|Public]
	// Offset: 0x10465d848
	// Params: [ Num(0) Size(0x0) ]
	void InitSeasonStatue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.InitMissionBoard
	// Flags: [Native|Public]
	// Offset: 0x10465d82c
	// Params: [ Num(0) Size(0x0) ]
	void InitMissionBoard();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.InitGenerator
	// Flags: [Native|Public]
	// Offset: 0x10465d810
	// Params: [ Num(0) Size(0x0) ]
	void InitGenerator();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.InitGameParamsFromGameMode
	// Flags: [Native|Public]
	// Offset: 0x10465d7f4
	// Params: [ Num(0) Size(0x0) ]
	void InitGameParamsFromGameMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.InitDynamicTriggers
	// Flags: [Native|Public]
	// Offset: 0x10465d7d8
	// Params: [ Num(0) Size(0x0) ]
	void InitDynamicTriggers();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.InitDynamicBuildingGroups
	// Flags: [Native|Public]
	// Offset: 0x10465d7bc
	// Params: [ Num(0) Size(0x0) ]
	void InitDynamicBuildingGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.InitBornWithApple
	// Flags: [Native|Public]
	// Offset: 0x10465d7a0
	// Params: [ Num(0) Size(0x0) ]
	void InitBornWithApple();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.Heartbeat
	// Flags: [Final|Native|Public]
	// Offset: 0x10465d78c
	// Params: [ Num(0) Size(0x0) ]
	void Heartbeat();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A85DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.HasVehicleReportEntry
	// Flags: [Final|Native|Public]
	// Offset: 0x10465d700
	// Params: [ Num(2) Size(0x5) ]
	bool HasVehicleReportEntry(uint32_t InUniqueID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1046649FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045A85DC

	// Object: Function Gameplay.UAEGameMode.HasDynamicBuildingGroup
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465d6cc
	// Params: [ Num(1) Size(0x1) ]
	bool HasDynamicBuildingGroup();
	// [Call #1] RVA: 0x1045A8418
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1046649FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.HandlePlayerPaintDecalResponse
	// Flags: [Native|Public]
	// Offset: 0x10465d55c
	// Params: [ Num(5) Size(0x1C) ]
	void HandlePlayerPaintDecalResponse(uint32_t PlayerKey, struct FName PlayerType, int Result, int DecalId, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045A8418
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1046649FC

	// Object: Function Gameplay.UAEGameMode.GotoNearDeath
	// Flags: [Native|Public]
	// Offset: 0x10465d4a0
	// Params: [ Num(2) Size(0x10) ]
	void GotoNearDeath(struct AController* DamageInstigator, struct APawn* VictimPawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045A8418

	// Object: Function Gameplay.UAEGameMode.GetWeaponReportByWeaponRecord
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x30) ]
	struct FOnePlayerWeapon GetWeaponReportByWeaponRecord(struct FString PlayerKey);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEGameMode.GetWeaponDamageFromRecord
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x18) ]
	float GetWeaponDamageFromRecord(struct FString PlayerKey, int TargetWeaponType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEGameMode.GetVehicleReportEntry
	// Flags: [Final|Native|Public]
	// Offset: 0x10465d404
	// Params: [ Num(2) Size(0x1C) ]
	struct FVehicleReportEntry GetVehicleReportEntry(uint32_t InUniqueID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10466435C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetSurvivingTeamCount
	// Flags: [Native|Public]
	// Offset: 0x10465d3c8
	// Params: [ Num(1) Size(0x4) ]
	int GetSurvivingTeamCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10466435C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetSurvivingCharacterCount
	// Flags: [Native|Public]
	// Offset: 0x10465d38c
	// Params: [ Num(1) Size(0x4) ]
	int GetSurvivingCharacterCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10466435C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetRescueDuration
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10465d2c0
	// Params: [ Num(3) Size(0x14) ]
	float GetRescueDuration(struct AActor* WhoRescue, struct AActor* RescueWho);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10466435C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.GetPlayerTotalShootNum
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x14) ]
	int GetPlayerTotalShootNum(struct FString PlayerKey);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEGameMode.GetPlayerStateListWithTeamID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465d1d0
	// Params: [ Num(3) Size(0x20) ]
	struct TArray<struct AUAEPlayerState*> GetPlayerStateListWithTeamID(int TeamID, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AC488
	// [Call #6] RVA: 0x10466430C
	// [Call #7] RVA: 0x10351E554
	// [Call #8] RVA: 0x10351E554
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetPlayerRealtimeVerifyInfo
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465d0c8
	// Params: [ Num(2) Size(0x78) ]
	void GetPlayerRealtimeVerifyInfo(uint32_t PlayerKey, struct FRealtimeVerifyInfo& RealtimeVerifyInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AC488
	// [Call #13] RVA: 0x10466430C
	// [Call #14] RVA: 0x10351E554
	// [Call #15] RVA: 0x10351E554
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetPlayerControllerWithUID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465d03c
	// Params: [ Num(2) Size(0x10) ]
	struct AUAEPlayerController* GetPlayerControllerWithUID(uint64_t UID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045AC2B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045AC488
	// [Call #16] RVA: 0x10466430C

	// Object: Function Gameplay.UAEGameMode.GetPlayerControllerListWithTeamID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465cf4c
	// Params: [ Num(3) Size(0x20) ]
	struct TArray<struct AUAEPlayerController*> GetPlayerControllerListWithTeamID(int TeamID, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AC384
	// [Call #6] RVA: 0x1046642BC
	// [Call #7] RVA: 0x1045D2098
	// [Call #8] RVA: 0x1045D2098
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AC2B8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEGameMode.GetPlayerAndRealAiNum
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465ceb4
	// Params: [ Num(1) Size(0x18) ]
	void GetPlayerAndRealAiNum(struct FHeartBeatData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045AC384
	// [Call #8] RVA: 0x1046642BC
	// [Call #9] RVA: 0x1045D2098
	// [Call #10] RVA: 0x1045D2098
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045AC2B8
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.GetObserverControllerList
	// Flags: [Final|Native|Public]
	// Offset: 0x10465ce50
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AUAEPlayerController*> GetObserverControllerList();
	// [Call #1] RVA: 0x1045AD594
	// [Call #2] RVA: 0x1046642BC
	// [Call #3] RVA: 0x1045D2098
	// [Call #4] RVA: 0x1045D2098
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AC384
	// [Call #13] RVA: 0x1046642BC
	// [Call #14] RVA: 0x1045D2098
	// [Call #15] RVA: 0x1045D2098
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetMonsterNum
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10465cdb8
	// Params: [ Num(1) Size(0x18) ]
	void GetMonsterNum(struct FHeartBeatData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045AD594
	// [Call #4] RVA: 0x1046642BC
	// [Call #5] RVA: 0x1045D2098
	// [Call #6] RVA: 0x1045D2098
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045AC384
	// [Call #15] RVA: 0x1046642BC

	// Object: Function Gameplay.UAEGameMode.GetMaxWeaponReportNum
	// Flags: [Final|Native|Public]
	// Offset: 0x10465cd9c
	// Params: [ Num(1) Size(0x4) ]
	int GetMaxWeaponReportNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045AD594
	// [Call #4] RVA: 0x1046642BC
	// [Call #5] RVA: 0x1045D2098
	// [Call #6] RVA: 0x1045D2098
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.GetClassicPlaneDirection
	// Flags: [Native|Public|HasDefaults]
	// Offset: 0x10465cd5c
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetClassicPlaneDirection();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045AD594
	// [Call #4] RVA: 0x1046642BC
	// [Call #5] RVA: 0x1045D2098
	// [Call #6] RVA: 0x1045D2098
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.FindPlayerStateWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465cc94
	// Params: [ Num(3) Size(0x18) ]
	struct AUAEPlayerState* FindPlayerStateWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AC1F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045AD594
	// [Call #9] RVA: 0x1046642BC
	// [Call #10] RVA: 0x1045D2098
	// [Call #11] RVA: 0x1045D2098
	// [Call #12] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameMode.FindPlayerControllerWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465cbcc
	// Params: [ Num(3) Size(0x18) ]
	struct AUAEPlayerController* FindPlayerControllerWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AA168
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045AC1F4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.FindPlayerControllerByUId
	// Flags: [Native|Public|Const]
	// Offset: 0x10465cb38
	// Params: [ Num(2) Size(0x10) ]
	struct APlayerController* FindPlayerControllerByUId(uint64_t UID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045AA168
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AC1F4

	// Object: Function Gameplay.UAEGameMode.FindControllerWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465ca70
	// Params: [ Num(3) Size(0x18) ]
	struct AController* FindControllerWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AC040
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AA168

	// Object: Function Gameplay.UAEGameMode.DestroyNoActiveWorldActor
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10465c98c
	// Params: [ Num(2) Size(0x10) ]
	void DestroyNoActiveWorldActor(struct FVector& Location, float& Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045AC040
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.DestroyCharacterForPlayerController
	// Flags: [Native|Public]
	// Offset: 0x10465c908
	// Params: [ Num(1) Size(0x8) ]
	void DestroyCharacterForPlayerController(struct APlayerController* PC);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045AC040

	// Object: Function Gameplay.UAEGameMode.DestroyAllPickUpObjs
	// Flags: [Final|Native|Public]
	// Offset: 0x10465c8f4
	// Params: [ Num(0) Size(0x0) ]
	void DestroyAllPickUpObjs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045AC040

	// Object: Function Gameplay.UAEGameMode.DeleteSeasonStatue
	// Flags: [Native|Public]
	// Offset: 0x10465c8d8
	// Params: [ Num(0) Size(0x0) ]
	void DeleteSeasonStatue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045AC040

	// Object: Function Gameplay.UAEGameMode.DeleteDynamicLoadItem
	// Flags: [Native|Public]
	// Offset: 0x10465c8bc
	// Params: [ Num(0) Size(0x0) ]
	void DeleteDynamicLoadItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.DebugEnterFriendObserver
	// Flags: [Native|Public]
	// Offset: 0x10465c838
	// Params: [ Num(1) Size(0x8) ]
	void DebugEnterFriendObserver(struct AUAEPlayerController* InController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.CreateDynamicBuildingGroups
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x10465c7bc
	// Params: [ Num(1) Size(0xC) ]
	void CreateDynamicBuildingGroups(struct FVector Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A7B20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAEGameMode.ChangeName
	// Flags: [Native|Public]
	// Offset: 0x10465c698
	// Params: [ Num(3) Size(0x19) ]
	void ChangeName(struct AController* Controller, struct FString NewName, bool bNameChange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045A7B20
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEGameMode.AddAirDropBox
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10465c5cc
	// Params: [ Num(2) Size(0x10) ]
	void AddAirDropBox(int boxId, struct FVector& pos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

// Object: Class Gameplay.UAEGameState
// Size: 0x650 (Inherited: 0x5C8)
struct AUAEGameState : ALuaGameState
{
	struct FName RepPropertyCategory; // 0x5C8(0x8)
	uint8_t Pad_0x5D0[0x5]; // 0x5D0(0x5)
	bool bTeamIDChgDeactivePawn; // 0x5D5(0x1)
	uint8_t Pad_0x5D6[0x52]; // 0x5D6(0x52)
	struct FString WeaponAttrReloadTableName; // 0x628(0x10)
	struct FString DamageSearchTableName; // 0x638(0x10)
	bool IsInitTable; // 0x648(0x1)
	bool bOverrideInstigatorEnable; // 0x649(0x1)
	uint8_t Pad_0x64A[0x6]; // 0x64A(0x6)


	// Object: Function Gameplay.UAEGameState.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104666404
	// Params: [ Num(2) Size(0x18) ]
	void SendLuaDSToClient(int ID, struct TArray<uint8_t>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045AEA58
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.UAEGameState.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104666328
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaDSToClient(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045AEA58
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function Gameplay.UAEGameState.HasTimeIDSwitch
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104666294
	// Params: [ Num(2) Size(0x5) ]
	bool HasTimeIDSwitch(int TimeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045AEA58
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEGameState.CheckDSSwitchOpen
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104666200
	// Params: [ Num(2) Size(0x5) ]
	bool CheckDSSwitchOpen(int SwitchId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class Gameplay.ItemActorComponent
// Size: 0x238 (Inherited: 0x238)
struct UItemActorComponent : ULuaActorComponent
{
};

// Object: Class Gameplay.BaseGeneratorComponent
// Size: 0x338 (Inherited: 0x238)
struct UBaseGeneratorComponent : UItemActorComponent
{
	bool bWorldTileGenerator; // 0x231(0x1)
	bool bModeStateControl; // 0x232(0x1)
	int GenerateSpotCountPerTick; // 0x234(0x4)
	struct FString ItemTableName; // 0x238(0x10)
	struct TArray<struct FString> ItemSpawnTableList; // 0x248(0x10)
	struct UUAEDataTable* ItemTable; // 0x258(0x8)
	bool IsWriteStatisticsToLog; // 0x260(0x1)
	uint8_t Pad_0x267[0x1]; // 0x267(0x1)
	struct TMap<enum class ESpotGroupType, struct FGroupSpotComponentArray> AllGroupSpots; // 0x268(0x50)
	struct TArray<struct USpotSceneComponent*> AllSpotsToTick; // 0x2B8(0x10)
	struct TMap<int, struct FWorldTileSpotArray> WorldTileSpots; // 0x2C8(0x50)
	struct FString CookedFilePath; // 0x318(0x10)
	struct TArray<struct FString> CookedFileAddPathArray; // 0x328(0x10)


	// Object: Function Gameplay.BaseGeneratorComponent.RegisterWorldTileSpot
	// Flags: [Native|Public]
	// Offset: 0x104601c64
	// Params: [ Num(1) Size(0x8) ]
	void RegisterWorldTileSpot(struct USpotSceneComponent* Spot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.BaseGeneratorComponent.RegisterSpotComponentToTick
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104601be0
	// Params: [ Num(1) Size(0x8) ]
	void RegisterSpotComponentToTick(struct USpotSceneComponent* SpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.BaseGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104601b5c
	// Params: [ Num(1) Size(0x8) ]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.BaseGeneratorComponent.GetRandomCategory
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x104601a74
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BaseGeneratorComponent.GeneratorWorldTileSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1046019c0
	// Params: [ Num(1) Size(0x18) ]
	void GeneratorWorldTileSpots(struct FWorldTileSpotArray& SpotArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045605E8
	// [Call #4] RVA: 0x10236C650
	// [Call #5] RVA: 0x10236C650
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102362AB0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.BaseGeneratorComponent.GenerateSpots
	// Flags: [Native|Public]
	// Offset: 0x1046019a4
	// Params: [ Num(0) Size(0x0) ]
	void GenerateSpots();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045605E8
	// [Call #4] RVA: 0x10236C650
	// [Call #5] RVA: 0x10236C650
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102362AB0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.BaseGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Public]
	// Offset: 0x104601920
	// Params: [ Num(1) Size(0x4) ]
	void GenerateSpotOnTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045605E8
	// [Call #6] RVA: 0x10236C650
	// [Call #7] RVA: 0x10236C650
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102362AB0
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.BaseGeneratorComponent.GeneratePickupActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1046016d8
	// Params: [ Num(6) Size(0x108) ]
	struct AActor* GeneratePickupActor(struct UObject* ActorClass, struct FVector& ActorLocation, struct FRotator& ActorRotator, uint8_t SpawnActorCollisionHandlingMethod, struct FItemGenerateSpawnClass ItemData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x103836714
	// [Call #12] RVA: 0x104560E30
	// [Call #13] RVA: 0x10236AF34
	// [Call #14] RVA: 0x10236AF34
	// [Call #15] RVA: 0x10236AF34
	// [Call #16] RVA: 0x10236AF34
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.BaseGeneratorComponent.CheckTileLevelsVisible
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046016c4
	// Params: [ Num(0) Size(0x0) ]
	void CheckTileLevelsVisible();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x103836714
	// [Call #12] RVA: 0x104560E30
	// [Call #13] RVA: 0x10236AF34
	// [Call #14] RVA: 0x10236AF34
	// [Call #15] RVA: 0x10236AF34
	// [Call #16] RVA: 0x10236AF34
};

// Object: Class Gameplay.ItemGeneratorComponent
// Size: 0xA08 (Inherited: 0x338)
struct UItemGeneratorComponent : UBaseGeneratorComponent
{
	struct FVector ItemGenerateOffset; // 0x338(0xC)
	enum class ESpotGroupType BornIslandGroupType; // 0x344(0x1)
	bool bStatisticsValid; // 0x345(0x1)
	uint8_t Pad_0x346[0x2]; // 0x346(0x2)
	struct FItemGenerateStatisticsData ItemStatisticsData; // 0x348(0x110)
	struct TSet<struct FString> IgnoreItemClassPathSet; // 0x458(0x50)
	struct TArray<struct FSpotGroupProperty> SpotGroupPropertys; // 0x4A8(0x10)
	bool UseSpotGroupPropertysEx; // 0x4B8(0x1)
	bool UseAreaID; // 0x4B9(0x1)
	uint8_t Pad_0x4BA[0x6]; // 0x4BA(0x6)
	struct TArray<struct FString> AreaIDList; // 0x4C0(0x10)
	struct TArray<struct FItemRegionCircle> ReplacedGeneratorRegionMap; // 0x4D0(0x10)
	struct TArray<struct FSpotGroupProperty> SpotGroupPropertysEx; // 0x4E0(0x10)
	struct TArray<struct FExtraItemSpawn> ExtraSpawnItemsList; // 0x4F0(0x10)
	struct TMap<enum class ESpotGroupType, struct FSpotGroupProperty> SpotGroupPropertysDic; // 0x500(0x50)
	struct FSpotGroupProperty DefaultSpotGroupProperty; // 0x550(0x28)
	struct UCurveFloat* SpotRateCurve; // 0x578(0x8)
	struct UCurveFloat* ItemRateCurve; // 0x580(0x8)
	struct TMap<struct FString, float> CategoryRates; // 0x588(0x50)
	struct TMap<struct FString, struct FItemGenerateSpawnDataArray> ItemGenerateSpawnDatas; // 0x5D8(0x50)
	struct TArray<struct AActor*> BornIslandItems; // 0x628(0x10)
	struct TArray<struct UItemGroupSpotSceneComponent*> AllValidGroups; // 0x638(0x10)
	bool bIsGenerateBornIslandItems; // 0x648(0x1)
	bool bIsGenerateMainlandItems; // 0x649(0x1)
	bool bIsGenerateWorldTileItems; // 0x64A(0x1)
	uint8_t Pad_0x64B[0x5]; // 0x64B(0x5)
	struct FDateTime GenerateBornIslandTime; // 0x650(0x8)
	struct FDateTime GenerateMainlandTime; // 0x658(0x8)
	bool bUseLocalSpotFile; // 0x660(0x1)
	uint8_t Pad_0x661[0x57]; // 0x661(0x57)
	struct TArray<struct FRepeatItemSpotData> AllRepeatItemSpotData; // 0x6B8(0x10)
	uint8_t Pad_0x6C8[0x10]; // 0x6C8(0x10)
	struct TArray<struct FItemGenerateSpawnClass> AllItemSpotDataToTick; // 0x6D8(0x10)
	uint8_t Pad_0x6E8[0x50]; // 0x6E8(0x50)
	struct FString CookedBandFilePath; // 0x738(0x10)
	bool bIsAreaItemLimit; // 0x748(0x1)
	uint8_t Pad_0x749[0x7]; // 0x749(0x7)
	struct TArray<struct FAreaItemsLimitEdit> AreaItemsLimit; // 0x750(0x10)
	struct TMap<struct FRegionID, struct FAreaItemsLimit> AreaItemsLimitMaps; // 0x760(0x50)
	bool bUseDynamicSpotConfig; // 0x7B0(0x1)
	uint8_t Pad_0x7B1[0x7]; // 0x7B1(0x7)
	struct TArray<struct FDynamicSpotConfig> DynamicSpotConfigs; // 0x7B8(0x10)
	uint8_t Pad_0x7C8[0x50]; // 0x7C8(0x50)
	int RandomSpotCountPerTick; // 0x818(0x4)
	uint8_t Pad_0x81C[0x54]; // 0x81C(0x54)
	struct FScriptMulticastDelegate PreCalculateCompleted; // 0x870(0x10)
	bool bCheckPreCalculateComplete; // 0x880(0x1)
	bool bEnablePrimeItemCircle; // 0x881(0x1)
	uint8_t Pad_0x882[0x6]; // 0x882(0x6)
	struct TArray<struct FPrimeItemCircleConfig> PrimeItemCircleConfigs; // 0x888(0x10)
	uint8_t Pad_0x898[0x30]; // 0x898(0x30)
	struct TMap<struct FVector, struct UUAESpotGroupObject*> SpotGroupObjectsMapByLoc; // 0x8C8(0x50)
	uint8_t Pad_0x918[0xA1]; // 0x918(0xA1)
	bool bRemovableMode; // 0x9B9(0x1)
	uint8_t Pad_0x9BA[0x2]; // 0x9BA(0x2)
	int RemoveGeneratedItemPerTick; // 0x9BC(0x4)
	int RemoveDropGroundItemPerTick; // 0x9C0(0x4)
	bool bAddHouseActorSerializeData; // 0x9C4(0x1)
	uint8_t Pad_0x9C5[0x43]; // 0x9C5(0x43)


	// Object: Function Gameplay.ItemGeneratorComponent.WriteItemSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104632c80
	// Params: [ Num(0) Size(0x0) ]
	void WriteItemSpotStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteItemClassStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	// Offset: 0x104632c6c
	// Params: [ Num(0) Size(0x0) ]
	void WriteItemClassStatisticsDatas_V15();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteItemClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104632c58
	// Params: [ Num(0) Size(0x0) ]
	void WriteItemClassStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteGroupStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104632c44
	// Params: [ Num(0) Size(0x0) ]
	void WriteGroupStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteBuildingStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104632c30
	// Params: [ Num(0) Size(0x0) ]
	void WriteBuildingStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteAreaItemStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104632c1c
	// Params: [ Num(0) Size(0x0) ]
	void WriteAreaItemStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteAllStatisticsDatasToLog
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x104632c00
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllStatisticsDatasToLog();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.WriteAllStatisticsDatas
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104632be4
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.TryLoadItemSpawnTableByTableMgr
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104632b34
	// Params: [ Num(2) Size(0x11) ]
	bool TryLoadItemSpawnTableByTableMgr(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGeneratorComponent.SetRandomSeed
	// Flags: [Final|Native|Public]
	// Offset: 0x104632ab8
	// Params: [ Num(1) Size(0x4) ]
	void SetRandomSeed(int Seed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E028
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function Gameplay.ItemGeneratorComponent.SetCatetoryRate
	// Flags: [Final|Native|Public]
	// Offset: 0x1046329f8
	// Params: [ Num(1) Size(0x50) ]
	void SetCatetoryRate(struct TMap<struct FString, float> Rates);
	// [Call #1] RVA: 0x101F865E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F86BAC
	// [Call #5] RVA: 0x10456FD28
	// [Call #6] RVA: 0x101F87D90
	// [Call #7] RVA: 0x101F87D90
	// [Call #8] RVA: 0x101F87D90
	// [Call #9] RVA: 0x101F87D90
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10456E028
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.RemoveSpotInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104632964
	// Params: [ Num(2) Size(0x2) ]
	bool RemoveSpotInfo(bool bFirstEnterState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E260
	// [Call #4] RVA: 0x101F865E4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F86BAC
	// [Call #8] RVA: 0x10456FD28
	// [Call #9] RVA: 0x101F87D90
	// [Call #10] RVA: 0x101F87D90
	// [Call #11] RVA: 0x101F87D90
	// [Call #12] RVA: 0x101F87D90
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10456E028
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Gameplay.ItemGeneratorComponent.RemoveItemOnTick
	// Flags: [Final|Native|Public]
	// Offset: 0x104632950
	// Params: [ Num(0) Size(0x0) ]
	void RemoveItemOnTick();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E260
	// [Call #4] RVA: 0x101F865E4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F86BAC
	// [Call #8] RVA: 0x10456FD28
	// [Call #9] RVA: 0x101F87D90
	// [Call #10] RVA: 0x101F87D90
	// [Call #11] RVA: 0x101F87D90
	// [Call #12] RVA: 0x101F87D90
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10456E028
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.RemoveDropGround
	// Flags: [Final|Native|Public]
	// Offset: 0x1046328bc
	// Params: [ Num(2) Size(0x2) ]
	bool RemoveDropGround(bool bFirstEnterState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E4F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10456E260
	// [Call #7] RVA: 0x101F865E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F86BAC
	// [Call #11] RVA: 0x10456FD28
	// [Call #12] RVA: 0x101F87D90
	// [Call #13] RVA: 0x101F87D90
	// [Call #14] RVA: 0x101F87D90
	// [Call #15] RVA: 0x101F87D90
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.RegisterItemGenerateSpawnData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046327f4
	// Params: [ Num(1) Size(0x68) ]
	void RegisterItemGenerateSpawnData(struct FItemGenerateSpawnData Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102372988
	// [Call #4] RVA: 0x10456CC48
	// [Call #5] RVA: 0x102372B2C
	// [Call #6] RVA: 0x102372B2C
	// [Call #7] RVA: 0x102372B2C
	// [Call #8] RVA: 0x102372B2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10456E4F0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10456E260
	// [Call #16] RVA: 0x101F865E4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.RegisterBornIslandItem
	// Flags: [Native|Public]
	// Offset: 0x104632770
	// Params: [ Num(1) Size(0x8) ]
	void RegisterBornIslandItem(struct AActor* Item);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102372988
	// [Call #6] RVA: 0x10456CC48
	// [Call #7] RVA: 0x102372B2C
	// [Call #8] RVA: 0x102372B2C
	// [Call #9] RVA: 0x102372B2C
	// [Call #10] RVA: 0x102372B2C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10456E4F0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.ReadItemGenerateTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10463267c
	// Params: [ Num(2) Size(0x18) ]
	struct UUAEDataTable* ReadItemGenerateTable(struct FString TablePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10456F1CC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102372988
	// [Call #17] RVA: 0x10456CC48
	// [Call #18] RVA: 0x102372B2C
	// [Call #19] RVA: 0x102372B2C
	// [Call #20] RVA: 0x102372B2C
	// [Call #21] RVA: 0x102372B2C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.ReAddAllSpot
	// Flags: [Final|Native|Public]
	// Offset: 0x104632668
	// Params: [ Num(0) Size(0x0) ]
	void ReAddAllSpot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10456F1CC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102372988
	// [Call #17] RVA: 0x10456CC48
	// [Call #18] RVA: 0x102372B2C
	// [Call #19] RVA: 0x102372B2C
	// [Call #20] RVA: 0x102372B2C
	// [Call #21] RVA: 0x102372B2C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.RandomSingleGroup
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104632534
	// Params: [ Num(3) Size(0x40) ]
	struct UItemGroupSpotSceneComponent* RandomSingleGroup(struct TArray<struct UGroupSpotSceneComponent*>& Groups, struct FSpotGroupProperty& GroupProperty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456FF68
	// [Call #6] RVA: 0x10236BA78
	// [Call #7] RVA: 0x10236C7D4
	// [Call #8] RVA: 0x10236BA78
	// [Call #9] RVA: 0x10236C7D4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x10456F1CC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.RandomGroupsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104632478
	// Params: [ Num(1) Size(0x28) ]
	void RandomGroupsByType(struct FSpotGroupProperty& GroupProperty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456C294
	// [Call #4] RVA: 0x10236BA78
	// [Call #5] RVA: 0x10236BA78
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10456FF68
	// [Call #12] RVA: 0x10236BA78
	// [Call #13] RVA: 0x10236C7D4
	// [Call #14] RVA: 0x10236BA78
	// [Call #15] RVA: 0x10236C7D4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.RandomBornIslandGroups
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10463245c
	// Params: [ Num(0) Size(0x0) ]
	void RandomBornIslandGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456C294
	// [Call #4] RVA: 0x10236BA78
	// [Call #5] RVA: 0x10236BA78
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10456FF68
	// [Call #12] RVA: 0x10236BA78
	// [Call #13] RVA: 0x10236C7D4
	// [Call #14] RVA: 0x10236BA78
	// [Call #15] RVA: 0x10236C7D4
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.OnAsyncLoadItemClassFinish
	// Flags: [Final|Native|Public]
	// Offset: 0x104632284
	// Params: [ Num(2) Size(0x100) ]
	void OnAsyncLoadItemClassFinish(struct UClass* ActorClassPtr, struct FItemGenerateSpawnClass SpawnClass);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10270DC50
	// [Call #7] RVA: 0x103836714
	// [Call #8] RVA: 0x104566264
	// [Call #9] RVA: 0x10236AF34
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x10236AF34
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x10236AF34
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x10236AF34
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.LuaCustomFunctionAfterGenerate
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104632138
	// Params: [ Num(2) Size(0xE0) ]
	void LuaCustomFunctionAfterGenerate(struct FItemGenerateSpawnClass& SpawnClass, struct AActor* ItemActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101FE9F3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.LuaAddRandomItemClassArray
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104632010
	// Params: [ Num(2) Size(0xD9) ]
	bool LuaAddRandomItemClassArray(struct FItemGenerateSpawnClass SpawnClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103836714
	// [Call #4] RVA: 0x10236AF34
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x10236AF34
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10236AF34

	// Object: Function Gameplay.ItemGeneratorComponent.LoadItemGenerateTable
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104631ff4
	// Params: [ Num(0) Size(0x0) ]
	void LoadItemGenerateTable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103836714
	// [Call #4] RVA: 0x10236AF34
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x10236AF34
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.IsCatetoryEnabled
	// Flags: [Final|Native|Protected]
	// Offset: 0x104631fc0
	// Params: [ Num(1) Size(0x1) ]
	bool IsCatetoryEnabled();
	// [Call #1] RVA: 0x10456F1F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x103836714
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x10236AF34
	// [Call #8] RVA: 0x10236AF34
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.InitCatetorys
	// Flags: [Final|Native|Protected]
	// Offset: 0x104631fac
	// Params: [ Num(0) Size(0x0) ]
	void InitCatetorys();
	// [Call #1] RVA: 0x10456F1F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x103836714
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x10236AF34
	// [Call #8] RVA: 0x10236AF34
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.InitCategoryEx
	// Flags: [Final|Native|Protected]
	// Offset: 0x104631f98
	// Params: [ Num(0) Size(0x0) ]
	void InitCategoryEx();
	// [Call #1] RVA: 0x10456F1F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x103836714
	// [Call #5] RVA: 0x10236AF34
	// [Call #6] RVA: 0x10236AF34
	// [Call #7] RVA: 0x10236AF34
	// [Call #8] RVA: 0x10236AF34
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.GMTrackGroundCheck
	// Flags: [Final|Native|Public]
	// Offset: 0x104631db8
	// Params: [ Num(7) Size(0x30) ]
	struct TArray<struct FVector> GMTrackGroundCheck(struct UObject* CheckClass, float FloatUp, float FloatDown, float SinkUp, float SinkTop, bool bCheckBounds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10457127C
	// [Call #14] RVA: 0x10246DCBC
	// [Call #15] RVA: 0x101F8C3A4
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10456F1F0

	// Object: Function Gameplay.ItemGeneratorComponent.GMGenerateAllSpot
	// Flags: [Final|Native|Public]
	// Offset: 0x104631cc4
	// Params: [ Num(2) Size(0x11) ]
	bool GMGenerateAllSpot(struct FString ItemPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10457100C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.GMEnableRefreshAllSpotWithSeed
	// Flags: [Final|Native|Public]
	// Offset: 0x104631c48
	// Params: [ Num(1) Size(0x4) ]
	void GMEnableRefreshAllSpotWithSeed(int Seed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E030
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x10457100C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.GetSpotTags
	// Flags: [Final|Native|Public]
	// Offset: 0x104631be4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSpotTags();
	// [Call #1] RVA: 0x104566598
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10456E030
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x10457100C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.GetSpotLocsByTag
	// Flags: [Final|Native|Public]
	// Offset: 0x104631b14
	// Params: [ Num(2) Size(0x20) ]
	struct TArray<struct FVector> GetSpotLocsByTag(struct FString ExTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456646C
	// [Call #4] RVA: 0x10246DCBC
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x104566598
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10456E030
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x10457100C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Gameplay.ItemGeneratorComponent.GetSpotLocInPolygon
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104631978
	// Params: [ Num(4) Size(0x28) ]
	int GetSpotLocInPolygon(struct TArray<struct FVector> Anchors, struct TArray<struct FVector>& OutLocs, int RandomNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FD7408
	// [Call #8] RVA: 0x104567F3C
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8C3A4
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10456646C
	// [Call #21] RVA: 0x10246DCBC
	// [Call #22] RVA: 0x101F8C3A4
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8C3A4

	// Object: Function Gameplay.ItemGeneratorComponent.GetSpotLocInCircle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104631804
	// Params: [ Num(5) Size(0x28) ]
	int GetSpotLocInCircle(struct FVector Center, float Radius, struct TArray<struct FVector>& OutLocs, int RandomNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104567C08
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8C3A4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.GetSpotGroupPropertyByGroupType
	// Flags: [Final|Native|Public]
	// Offset: 0x104631768
	// Params: [ Num(2) Size(0x30) ]
	struct FSpotGroupProperty GetSpotGroupPropertyByGroupType(enum class ESpotGroupType SpotGroupType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104569480
	// [Call #4] RVA: 0x10456F17C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104567C08
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x101F8C3A4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.GetRandomItemClassArray
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104631544
	// Params: [ Num(6) Size(0x41) ]
	bool GetRandomItemClassArray(struct FString& Value, struct FString& Category, struct TArray<struct FItemGenerateSpawnClass>& Results, bool RepeatGenerateItem, struct UItemSpotSceneComponent* SpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10456D718
	// [Call #12] RVA: 0x10236AEE8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x10236AEE8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.GetRandomCategory
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10463145c
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.GetItemDefineID
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	int GetItemDefineID(struct UObject* PickUpClass);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.ItemGeneratorComponent.GetCatetoryRate
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046313b4
	// Params: [ Num(2) Size(0x14) ]
	float GetCatetoryRate(struct FString Catetory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456F204
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102362AB0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Public]
	// Offset: 0x104631330
	// Params: [ Num(1) Size(0x4) ]
	void GenerateSpotOnTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456F204
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102362AB0
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.GenerateNewRandomSeed
	// Flags: [Final|Native|Public]
	// Offset: 0x10463131c
	// Params: [ Num(0) Size(0x0) ]
	void GenerateNewRandomSeed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456F204
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102362AB0
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.FindASpawnLoc
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104631250
	// Params: [ Num(3) Size(0x20) ]
	struct FVector FindASpawnLoc(struct UWorld* InWorld, struct FVector TraceStart);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456BA58
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10456F204
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.EnableRemoveItem
	// Flags: [Final|Native|Public]
	// Offset: 0x10463123c
	// Params: [ Num(0) Size(0x0) ]
	void EnableRemoveItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456BA58
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10456F204
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.EnableRefreshAllSpot
	// Flags: [Final|Native|Public]
	// Offset: 0x104631228
	// Params: [ Num(0) Size(0x0) ]
	void EnableRefreshAllSpot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456BA58
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10456F204
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.EnablePrimeItemPolygon
	// Flags: [Final|Native|Public]
	// Offset: 0x104631104
	// Params: [ Num(2) Size(0x14) ]
	void EnablePrimeItemPolygon(struct TArray<struct FVector> Anchors, int PrimeConfigIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD7408
	// [Call #6] RVA: 0x1045667C4
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10456BA58

	// Object: Function Gameplay.ItemGeneratorComponent.EnablePrimeItemCircle
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104631010
	// Params: [ Num(3) Size(0x14) ]
	void EnablePrimeItemCircle(struct FVector Center, float Radius, int PrimeConfigIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10456751C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD7408
	// [Call #13] RVA: 0x1045667C4
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x101F8C3A4
	// [Call #16] RVA: 0x101F8C3A4
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8C3A4
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.EnableDynamicSpotConfigByIndex
	// Flags: [Final|Native|Public]
	// Offset: 0x104630f94
	// Params: [ Num(1) Size(0x4) ]
	void EnableDynamicSpotConfigByIndex(int DynamicIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104565154
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10456751C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FD7408
	// [Call #16] RVA: 0x1045667C4
	// [Call #17] RVA: 0x101F8C3A4
	// [Call #18] RVA: 0x101F8C3A4

	// Object: Function Gameplay.ItemGeneratorComponent.DoPickUp
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104630e64
	// Params: [ Num(3) Size(0x28) ]
	void DoPickUp(int ItemSpotDataIndex, struct FString Value, struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104565154
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Gameplay.ItemGeneratorComponent.DeleteBornIslandItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104630e50
	// Params: [ Num(0) Size(0x0) ]
	void DeleteBornIslandItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104565154
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.CheckShouldGenerateItem
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104630dbc
	// Params: [ Num(2) Size(0x5) ]
	bool CheckShouldGenerateItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104565154

	// Object: Function Gameplay.ItemGeneratorComponent.CheckRecoverItems
	// Flags: [Final|Native|Public]
	// Offset: 0x104630da8
	// Params: [ Num(0) Size(0x0) ]
	void CheckRecoverItems();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104565154

	// Object: Function Gameplay.ItemGeneratorComponent.CheckInPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104630ca4
	// Params: [ Num(3) Size(0x21) ]
	bool CheckInPolygon(struct FVector& pos, struct TArray<struct FVector>& Anchors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104567638
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.CheckInCircle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104630b70
	// Params: [ Num(4) Size(0x1D) ]
	bool CheckInCircle(struct FVector& pos, struct FVector& Center, float& Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045675D0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104567638
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemGeneratorComponent.AddIgnoreItemClassPath
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104630ac8
	// Params: [ Num(1) Size(0x10) ]
	void AddIgnoreItemClassPath(struct TArray<struct FString>& IgnoreItemClassList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104570EF0
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045675D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGeneratorComponent.AddDropGround
	// Flags: [Final|Native|Public]
	// Offset: 0x104630a4c
	// Params: [ Num(1) Size(0x8) ]
	void AddDropGround(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10456E920
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104570EF0
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045675D0
};

// Object: Class Gameplay.UAEPlayerState
// Size: 0x13F0 (Inherited: 0x5F8)
struct AUAEPlayerState : ALuaPlayerState
{
	bool IsForcedNetRelevant; // 0x5F8(0x1)
	bool IsSoloCheckTeamID; // 0x5F9(0x1)
	uint8_t Pad_0x5FA[0x2]; // 0x5FA(0x2)
	float surviveTime; // 0x5FC(0x4)
	float surviveTimeFromPlane; // 0x600(0x4)
	uint8_t Pad_0x604[0x4]; // 0x604(0x4)
	float Pronetime; // 0x608(0x4)
	uint8_t Pad_0x60C[0x8]; // 0x60C(0x8)
	int MovingCount; // 0x614(0x4)
	float marchDistance; // 0x618(0x4)
	float travelDistance; // 0x61C(0x4)
	float DriveDistance; // 0x620(0x4)
	float MonsterCatchupDistance; // 0x624(0x4)
	int destroyVehicleNum; // 0x628(0x4)
	int rescueTimes; // 0x62C(0x4)
	struct TArray<uint64_t> RescueTeammatesList; // 0x630(0x10)
	int NormalItemsNum; // 0x640(0x4)
	int SeniorItemsNum; // 0x644(0x4)
	int GVMemberID; // 0x648(0x4)
	uint8_t Pad_0x64C[0x4]; // 0x64C(0x4)
	struct FName PlayerType; // 0x650(0x8)
	uint64_t FinalTeamleaderUID; // 0x658(0x8)
	uint32_t PlayerKey; // 0x660(0x4)
	uint8_t Pad_0x664[0x4]; // 0x664(0x4)
	struct FString PlayerUID; // 0x668(0x10)
	struct FString MLAIStringUID; // 0x678(0x10)
	bool bPSEnsure; // 0x688(0x1)
	uint8_t Pad_0x689[0x7]; // 0x689(0x7)
	struct FString iconUrl; // 0x690(0x10)
	int Gender; // 0x6A0(0x4)
	int PlayerLevel; // 0x6A4(0x4)
	int SegmentLevel; // 0x6A8(0x4)
	float RealHiddenScore; // 0x6AC(0x4)
	int AceImprintShowId; // 0x6B0(0x4)
	int AceImprintBaseId; // 0x6B4(0x4)
	int AvatarBoxId; // 0x6B8(0x4)
	int planeAvatarId; // 0x6BC(0x4)
	int Campid; // 0x6C0(0x4)
	int resID; // 0x6C4(0x4)
	uint64_t UID; // 0x6C8(0x8)
	uint64_t MLAIDisplayUID; // 0x6D0(0x8)
	struct FString OpenID; // 0x6D8(0x10)
	int ZoneID; // 0x6E8(0x4)
	uint8_t Pad_0x6EC[0x4]; // 0x6EC(0x4)
	struct FString Nation; // 0x6F0(0x10)
	int TeamID; // 0x700(0x4)
	uint8_t Pad_0x704[0x4]; // 0x704(0x4)
	int64_t IdxInTeam; // 0x708(0x8)
	uint64_t PreTeamID; // 0x710(0x8)
	int PreTeamChatState; // 0x718(0x4)
	int PlayerBornPointID; // 0x71C(0x4)
	int Kills; // 0x720(0x4)
	int KillsBeforeDie; // 0x724(0x4)
	int Knockouts; // 0x728(0x4)
	int AIKills; // 0x72C(0x4)
	int RealPlayerKills; // 0x730(0x4)
	int BossKills; // 0x734(0x4)
	int DeathsCount; // 0x738(0x4)
	uint8_t Pad_0x73C[0x4]; // 0x73C(0x4)
	int MlAIDeliverNum; // 0x740(0x4)
	int OriginalMlAIDeliverNum; // 0x744(0x4)
	int Assists; // 0x748(0x4)
	uint8_t Pad_0x74C[0x4]; // 0x74C(0x4)
	struct TArray<uint64_t> AssistTeammatesList; // 0x750(0x10)
	struct TMap<int, bool> AssistKillPlayers; // 0x760(0x50)
	struct TArray<int> OvertimeAssistsTime; // 0x7B0(0x10)
	uint8_t PlatformGender; // 0x7C0(0x1)
	uint8_t Pad_0x7C1[0x3]; // 0x7C1(0x3)
	int MatchStrategyLabel; // 0x7C4(0x4)
	int MatchLabel; // 0x7C8(0x4)
	uint32_t Killer; // 0x7CC(0x4)
	uint32_t KillerIGPlayerKey; // 0x7D0(0x4)
	uint8_t Pad_0x7D4[0x4]; // 0x7D4(0x4)
	struct FString BeKilledOpenID; // 0x7D8(0x10)
	struct FString KillerName; // 0x7E8(0x10)
	uint32_t KillerType; // 0x7F8(0x4)
	int KillerWeaponID; // 0x7FC(0x4)
	uint32_t KillerDeliveryType; // 0x800(0x4)
	uint32_t DeadCircleIndex; // 0x804(0x4)
	uint64_t MisKillTeammatePlayerKey; // 0x808(0x8)
	int ShootWeaponShotNum; // 0x810(0x4)
	int ShootWeaponShotNumPicth; // 0x814(0x4)
	int ShootWeaponShotAndHitPlayerNum; // 0x818(0x4)
	int ShootWeaponShotAndHitPlayerNumNoAI; // 0x81C(0x4)
	int ShootWeaponShotHeadNum; // 0x820(0x4)
	int ShootWeaponShotHeadNumNoAI; // 0x824(0x4)
	int HeadShotNum; // 0x828(0x4)
	int HeadShotNumNoAI; // 0x82C(0x4)
	int KillNumByGrende; // 0x830(0x4)
	int UseFragGrenadeNum; // 0x834(0x4)
	int UseSmokeGrenadeNum; // 0x838(0x4)
	int UseFlashGrenadeNum; // 0x83C(0x4)
	int UseBurnGrenadeNum; // 0x840(0x4)
	int MaxKillDistance; // 0x844(0x4)
	int HealTimes; // 0x848(0x4)
	float DamageAmount; // 0x84C(0x4)
	float DamageAmountFPP; // 0x850(0x4)
	int FPPSwitchTimes; // 0x854(0x4)
	float RealPlayerDamageAmount; // 0x858(0x4)
	int MeleeKillTimes; // 0x85C(0x4)
	float MeleeDamageAmount; // 0x860(0x4)
	float RangedDamagedAmount; // 0x864(0x4)
	float VehicleDamageAmount; // 0x868(0x4)
	int FirstMoveBattles; // 0x86C(0x4)
	int TotalBattles; // 0x870(0x4)
	float HealAmount; // 0x874(0x4)
	struct TArray<struct FString> KillFlow; // 0x878(0x10)
	struct TArray<struct FString> KnockOutFlow; // 0x888(0x10)
	struct TArray<struct FKnockOutData> KnockOutList; // 0x898(0x10)
	float InDamageAmount; // 0x8A8(0x4)
	uint8_t Pad_0x8AC[0x14]; // 0x8AC(0x14)
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // 0x8C0(0x10)
	int PickUpItemTimes; // 0x8D0(0x4)
	bool bIsForbidItemFlowMerge; // 0x8D4(0x1)
	uint8_t Pad_0x8D5[0x3]; // 0x8D5(0x3)
	struct TMap<int, int> ConsumeItemUseCount; // 0x8D8(0x50)
	struct TMap<int, struct FTLog_BornLandGrenadeData> TLog_BornLandGrenadeData; // 0x928(0x50)
	struct FAIDeliveryTlogData TLog_AIDeliveryTlogData; // 0x978(0x58)
	bool bHasSendAIDeliverData; // 0x9D0(0x1)
	uint8_t Pad_0x9D1[0x7]; // 0x9D1(0x7)
	struct TMap<int, bool> TLog_PickUpItemIdMap; // 0x9D8(0x50)
	struct TArray<struct FGameModeLikeResultData> Like; // 0xA28(0x10)
	uint32_t Switch; // 0xA38(0x4)
	uint8_t Pad_0xA3C[0x4]; // 0xA3C(0x4)
	struct TArray<uint32_t> Self; // 0xA40(0x10)
	struct TArray<struct FGameModeTeammateLableCheckData> LabelCheck; // 0xA50(0x10)
	struct TArray<struct FUseItemFlow> UseItemFlow; // 0xA60(0x10)
	struct TArray<struct FUseBuffFlow> UseBuffFlow; // 0xA70(0x10)
	struct TArray<struct FBuildingEnterFlow> BuildingEnterFlow; // 0xA80(0x10)
	struct TArray<struct FTLog_PropEquipUnequipFlow> TLog_PropEquipUnequipFlowData; // 0xA90(0x10)
	struct TMap<int, int> TLog_BulletCount; // 0xAA0(0x50)
	struct FTLog_SpecialStats TLog_SpecialStats; // 0xAF0(0x8)
	bool bIsOutsideBlueCircle; // 0xAF8(0x1)
	uint8_t Pad_0xAF9[0x3]; // 0xAF9(0x3)
	float OutsideBlueCircleTime; // 0xAFC(0x4)
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // 0xB00(0x10)
	int FirstOpenedAirDropBoxNum; // 0xB10(0x4)
	int FirstOpenedPlayerTombBoxNum; // 0xB14(0x4)
	int FirstOpenedTreasureBoxNum; // 0xB18(0x4)
	float HitEnemyHeadAmount; // 0xB1C(0x4)
	struct TArray<int> BuildFlow; // 0xB20(0x10)
	struct TArray<int> DestroyShelterFlow; // 0xB30(0x10)
	float ShelterTakeDamage; // 0xB40(0x4)
	float HitShelterDamage; // 0xB44(0x4)
	struct FVector LandLocation; // 0xB48(0xC)
	struct FVector ParachuteLocation; // 0xB54(0xC)
	int LandTime; // 0xB60(0x4)
	struct FVector DeadLocation; // 0xB64(0xC)
	struct FString DeadDamangeType; // 0xB70(0x10)
	int PveDeadAttacker; // 0xB80(0x4)
	int PveStageId; // 0xB84(0x4)
	struct FString DeadTimeStr; // 0xB88(0x10)
	int NearDeathDamageType; // 0xB98(0x4)
	uint32_t NearDeathCauserId; // 0xB9C(0x4)
	bool NearDeathIsHeadShot; // 0xBA0(0x1)
	uint8_t Pad_0xBA1[0x3]; // 0xBA1(0x3)
	int BeDownTimes; // 0xBA4(0x4)
	int BeSavedTimes; // 0xBA8(0x4)
	uint8_t Pad_0xBAC[0x4]; // 0xBAC(0x4)
	struct FEquipmentData EquipmentData; // 0xBB0(0x70)
	int PersonalRank; // 0xC20(0x4)
	uint8_t Pad_0xC24[0x8]; // 0xC24(0x8)
	bool bIsGameTerminator; // 0xC2C(0x1)
	uint8_t Pad_0xC2D[0x3]; // 0xC2D(0x3)
	int GamePlayingTime; // 0xC30(0x4)
	int ObserverTime; // 0xC34(0x4)
	int TouchDownAreaID; // 0xC38(0x4)
	int TouchDownLocTypeID; // 0xC3C(0x4)
	struct TArray<int> TouchDownAreaList; // 0xC40(0x10)
	bool bHasTouchDownAreaList; // 0xC50(0x1)
	uint8_t Pad_0xC51[0x3]; // 0xC51(0x3)
	float ReportTouchDownHeight; // 0xC54(0x4)
	struct TArray<struct FGameModePlayerTaskData> CompletedTaskList; // 0xC58(0x10)
	struct TArray<struct FReportCollection> SpecialCollectionList; // 0xC68(0x10)
	struct TArray<struct FWeaponDamageRecord> WeaponDamageRecordList; // 0xC78(0x10)
	struct TArray<int> SecretAreaIDList; // 0xC88(0x10)
	struct TArray<struct FSpecialPickItemState> CollectItemRecord; // 0xC98(0x10)
	float DrivingHelicopterTime; // 0xCA8(0x4)
	float InHelicopterTime; // 0xCAC(0x4)
	int RevivalNum; // 0xCB0(0x4)
	int BeRevivedNum; // 0xCB4(0x4)
	int KillNumInVehicle; // 0xCB8(0x4)
	float MaxVehicleToLandHeight; // 0xCBC(0x4)
	float MaxVehicleInAirInterval; // 0xCC0(0x4)
	int KillPlayerNum; // 0xCC4(0x4)
	int KillAINum; // 0xCC8(0x4)
	float TotalSprintDistance; // 0xCCC(0x4)
	float TotalBeenDamageAmount; // 0xCD0(0x4)
	float DestroyVehicleWheelNum; // 0xCD4(0x4)
	struct TArray<struct FDestroyVehicleWheelFlow> DestroyVehicleWheelFlow; // 0xCD8(0x10)
	int ProneTimes; // 0xCE8(0x4)
	int CrouchTimes; // 0xCEC(0x4)
	int JumpTimes; // 0xCF0(0x4)
	int KillMonsterNum; // 0xCF4(0x4)
	struct TMap<int, int> MonsterID2KillNum; // 0xCF8(0x50)
	float TotalDamageAmountToMonsters; // 0xD48(0x4)
	float TotalDamageAmountFromMonsters; // 0xD4C(0x4)
	struct TMap<int, float> DamageAmountToMonsters; // 0xD50(0x50)
	struct TMap<int, float> DamageAmountFromMonsters; // 0xDA0(0x50)
	int MonsterHeadShotKilledTimes; // 0xDF0(0x4)
	int BeMonsterDownTimes; // 0xDF4(0x4)
	int LightCandleNum; // 0xDF8(0x4)
	uint8_t Pad_0xDFC[0x4]; // 0xDFC(0x4)
	struct TMap<int, int> ActivityButtonCount; // 0xE00(0x50)
	struct TArray<struct FActivityEventReportData> ActivityEventRecordList; // 0xE50(0x10)
	float BattleStateTime; // 0xE60(0x4)
	bool bIsKickedFromGame; // 0xE64(0x1)
	uint8_t Pad_0xE65[0x3]; // 0xE65(0x3)
	float DriveWithTeammateDistance; // 0xE68(0x4)
	int FistKillingCount; // 0xE6C(0x4)
	int OpenedAirDropBoxNum; // 0xE70(0x4)
	uint8_t Pad_0xE74[0x4]; // 0xE74(0x4)
	struct TMap<uint32_t, uint32_t> VehicleUsedMap; // 0xE78(0x50)
	struct TArray<struct FString> DestroyVehicleFlow; // 0xEC8(0x10)
	int UseHelicoperNum; // 0xED8(0x4)
	uint8_t Pad_0xEDC[0x4]; // 0xEDC(0x4)
	struct TArray<struct FTLog_KillInfo> PlayerKillAIInfo; // 0xEE0(0x10)
	struct TArray<struct FTLog_KillInfo> PlayerNearDeathDuoToAI; // 0xEF0(0x10)
	struct FTLog_KillInfo AIKillPlayerInfo; // 0xF00(0x28)
	float UseHelicoperDistance; // 0xF28(0x4)
	uint8_t CharmRankIndex; // 0xF2C(0x1)
	uint8_t Pad_0xF2D[0x3]; // 0xF2D(0x3)
	struct TSet<uint32_t> UseHelicoperRecord; // 0xF30(0x50)
	int FollowState; // 0xF80(0x4)
	int SnowBoardJumpActionCount; // 0xF84(0x4)
	int EmoteOnTelpherCount; // 0xF88(0x4)
	int KillMagicWalkAI; // 0xF8C(0x4)
	int SendMagicWalkAI; // 0xF90(0x4)
	uint8_t Pad_0xF94[0x4]; // 0xF94(0x4)
	struct TArray<int> FindBlackMonsterIDs; // 0xF98(0x10)
	int KillSnowManCount; // 0xFA8(0x4)
	uint8_t Pad_0xFAC[0x4]; // 0xFAC(0x4)
	uint64_t LuckmateUID; // 0xFB0(0x8)
	struct TMap<uint8_t, int> EventCounterMap; // 0xFB8(0x50)
	struct TMap<int, int> GeneralCounterMap; // 0x1008(0x50)
	uint8_t Pad_0x1058[0x8]; // 0x1058(0x8)
	DelegateProperty AllowToAddGeneralCount; // 0x1060(0x10)
	struct FScriptMulticastDelegate OnGenerelCountChanged; // 0x1070(0x10)
	int VeteranRecruitIndex; // 0x1080(0x4)
	uint8_t Pad_0x1084[0x4]; // 0x1084(0x4)
	struct FScriptMulticastDelegate PlayerStateTeamChanged; // 0x1088(0x10)
	struct TArray<struct FPlayEmoteData> FPlayEmoteDataArray; // 0x1098(0x10)
	struct FGameModePlayerAliasInfo AliasInfo; // 0x10A8(0x48)
	int MemberIdInVoiceRoom; // 0x10F0(0x4)
	bool PlayerVoiceEnable; // 0x10F4(0x1)
	uint8_t Pad_0x10F5[0x3]; // 0x10F5(0x3)
	struct FGameModePlayerUpassInfo UpassInfo; // 0x10F8(0x38)
	int UpassShow; // 0x1130(0x4)
	int upassKeepBuy; // 0x1134(0x4)
	int upassCurValue; // 0x1138(0x4)
	int pass_type; // 0x113C(0x4)
	bool UpassIsBuy; // 0x1140(0x1)
	uint8_t Pad_0x1141[0x3]; // 0x1141(0x3)
	struct FTLog_Micphone MicphoneTlog; // 0x1144(0x18)
	float TeammateMicrophoneTime; // 0x115C(0x4)
	float TeammateSpeakerTime; // 0x1160(0x4)
	float EnemyMicrophoneTime; // 0x1164(0x4)
	float EnemySpeakerTime; // 0x1168(0x4)
	float TeammateInterphoneTime; // 0x116C(0x4)
	float EnemyInterphoneTime; // 0x1170(0x4)
	float MicrophoneUseTimeStamp; // 0x1174(0x4)
	float SpeakerUseTimeStamp; // 0x1178(0x4)
	uint8_t Pad_0x117C[0x24]; // 0x117C(0x24)
	struct FDamageInfo LuaNearDeathDamageInfo; // 0x11A0(0xB8)
	struct FDamageInfo LuaDeathDamageInfo; // 0x1258(0xB8)
	struct FName RepPropertyCategory; // 0x1310(0x8)
	uint8_t Pad_0x1318[0x10]; // 0x1318(0x10)
	bool IsOnline; // 0x1328(0x1)
	uint8_t Pad_0x1329[0x1F]; // 0x1329(0x1F)
	struct FGameBaseInfo GameBaseInfo; // 0x1348(0x90)
	uint8_t Pad_0x13D8[0x8]; // 0x13D8(0x8)
	struct FString RealPlayerName; // 0x13E0(0x10)


	// Object: Function Gameplay.UAEPlayerState.SetRankAndPersonalRank
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467a354
	// Params: [ Num(2) Size(0x8) ]
	void SetRankAndPersonalRank(int TempRank, int TempPersonalRank);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045DD9F0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.UAEPlayerState.SetGVMemberIDServerCall
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10467a2d0
	// Params: [ Num(1) Size(0x4) ]
	void SetGVMemberIDServerCall(int memberID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045DD9F0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEPlayerState.SetGVMemberID
	// Flags: [Final|Native|Public]
	// Offset: 0x10467a254
	// Params: [ Num(1) Size(0x4) ]
	void SetGVMemberID(int memberID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1CD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045DD9F0
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Gameplay.UAEPlayerState.SetDeliveryResult
	// Flags: [Final|Native|Public]
	// Offset: 0x10467a150
	// Params: [ Num(3) Size(0xC) ]
	void SetDeliveryResult(uint32_t InDeliverPlayerKey, bool bInSuccess, int EventTypeId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E25E8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E1CD8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10467a06c
	// Params: [ Num(2) Size(0x18) ]
	void SendLuaDSToClient(int ID, struct TArray<uint8_t>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E2C44
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E25E8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1045E1CD8

	// Object: Function Gameplay.UAEPlayerState.RPC_ServerAddGeneralCount
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x104679f6c
	// Params: [ Num(3) Size(0x9) ]
	void RPC_ServerAddGeneralCount(int ID, int InCount, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E2C44
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104679e90
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaDSToClient(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.RPC_ChangeOnlyTeamChat
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x104679e0c
	// Params: [ Num(1) Size(0x4) ]
	void RPC_ChangeOnlyTeamChat(int NewPreTeamChatState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.ReportTaskExtInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104679ce8
	// Params: [ Num(2) Size(0x18) ]
	void ReportTaskExtInfo(int TaskID, struct FString ExtInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045E120C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.ReportTaskData
	// Flags: [Final|Native|Public]
	// Offset: 0x104679c34
	// Params: [ Num(2) Size(0x8) ]
	void ReportTaskData(int TaskID, int process);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E10F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x1045E120C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.ReportSpecialCollection
	// Flags: [Final|Native|Public]
	// Offset: 0x104679b80
	// Params: [ Num(2) Size(0x8) ]
	void ReportSpecialCollection(int ItemId, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E1420
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E10F0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x1045E120C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerState.ReportSecretAreaID
	// Flags: [Final|Native|Public]
	// Offset: 0x104679b04
	// Params: [ Num(1) Size(0x4) ]
	void ReportSecretAreaID(int SecretAreaID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1364
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E1420
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045E10F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.ReportLikeTeammate
	// Flags: [Final|Native|Public]
	// Offset: 0x104679a4c
	// Params: [ Num(2) Size(0xC) ]
	void ReportLikeTeammate(int64_t BeLikeUID, int LikeType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E1648
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E1364
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045E1420
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.ReportLikeSwitch
	// Flags: [Final|Native|Public]
	// Offset: 0x1046799d0
	// Params: [ Num(1) Size(0x4) ]
	void ReportLikeSwitch(int SwitchSetting);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E17E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E1648
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1364
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045E1420

	// Object: Function Gameplay.UAEPlayerState.ReportLikeSelf
	// Flags: [Final|Native|Public]
	// Offset: 0x104679954
	// Params: [ Num(1) Size(0x4) ]
	void ReportLikeSelf(int LikeType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E176C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E17E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1648
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E1364

	// Object: Function Gameplay.UAEPlayerState.ReportLandLocType
	// Flags: [Final|Native|Public]
	// Offset: 0x1046798d8
	// Params: [ Num(1) Size(0x4) ]
	void ReportLandLocType(int TouchDownLocType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1890
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E176C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045E17E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E1648

	// Object: Function Gameplay.UAEPlayerState.ReportLandAreaList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104679830
	// Params: [ Num(1) Size(0x10) ]
	void ReportLandAreaList(struct TArray<int>& TouchDownAreaIDs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1A00
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045E1890
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045E176C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E17E0
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.ReportLandArea
	// Flags: [Final|Native|Public]
	// Offset: 0x1046797b4
	// Params: [ Num(1) Size(0x4) ]
	void ReportLandArea(int TouchDownArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1948
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E1A00
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045E1890
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E176C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.ReportLabelCheck
	// Flags: [Final|Native|Public]
	// Offset: 0x104679700
	// Params: [ Num(2) Size(0x8) ]
	void ReportLabelCheck(int TeammateUID, int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E17E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E1948
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1A00
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045E1890

	// Object: Function Gameplay.UAEPlayerState.RecordUseHelicoper
	// Flags: [Final|Native|Public]
	// Offset: 0x104679684
	// Params: [ Num(1) Size(0x4) ]
	void RecordUseHelicoper(uint32_t UseHelicoperId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E1A00
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerState.OnRepCampIDBP
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRepCampIDBP();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEPlayerState.OnRep_VeteranRecruitIndex
	// Flags: [Final|Native|Public]
	// Offset: 0x104679670
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_VeteranRecruitIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E1A00
	// [Call #15] RVA: 0x101F8BA44

	// Object: Function Gameplay.UAEPlayerState.OnRep_UpdateKillMonsterNum
	// Flags: [Native|Public]
	// Offset: 0x104679654
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UpdateKillMonsterNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E1A00

	// Object: Function Gameplay.UAEPlayerState.OnRep_UID
	// Flags: [Native|Public]
	// Offset: 0x104679638
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.OnRep_TeamID
	// Flags: [Final|Native|Public]
	// Offset: 0x104679624
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_TeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.OnRep_RescueTimesChange
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104679608
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_RescueTimesChange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948

	// Object: Function Gameplay.UAEPlayerState.OnRep_PreTeamID
	// Flags: [Final|Native|Public]
	// Offset: 0x1046795f4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PreTeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948

	// Object: Function Gameplay.UAEPlayerState.OnRep_PlayerKillsChange
	// Flags: [Native|Public]
	// Offset: 0x1046795d8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerKillsChange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E1948

	// Object: Function Gameplay.UAEPlayerState.OnRep_PlayerKey
	// Flags: [Native|Public]
	// Offset: 0x1046795bc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerKey();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.OnRep_MLAIDisplayUID
	// Flags: [Final|Native|Public]
	// Offset: 0x1046795a8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_MLAIDisplayUID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.OnRep_MatchLabel
	// Flags: [Final|Native|Public]
	// Offset: 0x104679594
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_MatchLabel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8
	// [Call #9] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.OnRep_CollectItemRecord
	// Flags: [Final|Native|Public]
	// Offset: 0x104679580
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CollectItemRecord();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8

	// Object: Function Gameplay.UAEPlayerState.OnRep_CampID
	// Flags: [Final|Native|Public]
	// Offset: 0x10467956c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CampID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8

	// Object: Function Gameplay.UAEPlayerState.OnRep_bOnlyPreTeamChat
	// Flags: [Final|Native|Public]
	// Offset: 0x104679558
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_bOnlyPreTeamChat();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E17E8

	// Object: Function Gameplay.UAEPlayerState.OnRep_AliasInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104679544
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_AliasInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.OnClientVeteranRecruitIndexUpdated
	// Flags: [Native|Public]
	// Offset: 0x104679528
	// Params: [ Num(0) Size(0x0) ]
	void OnClientVeteranRecruitIndexUpdated();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E2538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.IsSpecialPickItemCollectionCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x10467949c
	// Params: [ Num(2) Size(0x5) ]
	bool IsSpecialPickItemCollectionCompleted(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E1C8C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E2538

	// Object: Function Gameplay.UAEPlayerState.IsSpecialPickItem
	// Flags: [Final|Native|Public]
	// Offset: 0x104679410
	// Params: [ Num(2) Size(0x5) ]
	bool IsSpecialPickItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E13E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E1C8C

	// Object: Function Gameplay.UAEPlayerState.IsNearDeathDamageInfoValid
	// Flags: [Final|Native|Public]
	// Offset: 0x1046793dc
	// Params: [ Num(1) Size(0x1) ]
	bool IsNearDeathDamageInfoValid();
	// [Call #1] RVA: 0x1045DD9E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045E13E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E1C8C

	// Object: Function Gameplay.UAEPlayerState.IsItemForbidMerge
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104679348
	// Params: [ Num(2) Size(0x5) ]
	bool IsItemForbidMerge(int ItemResId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045DD9E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045E13E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045E1C8C

	// Object: Function Gameplay.UAEPlayerState.IsDeathDamageInfoValid
	// Flags: [Final|Native|Public]
	// Offset: 0x104679314
	// Params: [ Num(1) Size(0x1) ]
	bool IsDeathDamageInfoValid();
	// [Call #1] RVA: 0x1045DD954
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045DD9E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E13E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E1C8C

	// Object: Function Gameplay.UAEPlayerState.GetWeaponReportByWeaponRecord
	// Flags: [Event|Public|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x20) ]
	struct FOnePlayerWeapon GetWeaponReportByWeaponRecord();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEPlayerState.GetWeaponRecordData
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x104679260
	// Params: [ Num(1) Size(0x20) ]
	void GetWeaponRecordData(struct FOnePlayerWeapon& OutWeaponInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10355B2D0
	// [Call #4] RVA: 0x10355B2D0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045DD954
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045DD9E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045E13E0

	// Object: Function Gameplay.UAEPlayerState.GetVeteranPlayerLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104679224
	// Params: [ Num(1) Size(0x4) ]
	int GetVeteranPlayerLevel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10355B2D0
	// [Call #4] RVA: 0x10355B2D0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045DD954
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045DD9E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetUserIDByMemberID
	// Flags: [Native|Public]
	// Offset: 0x104679190
	// Params: [ Num(2) Size(0x8) ]
	uint32_t GetUserIDByMemberID(int memberID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10355B2D0
	// [Call #6] RVA: 0x10355B2D0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045DD954
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetUIDString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10467912c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUIDString();
	// [Call #1] RVA: 0x1045E10C4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10355B2D0
	// [Call #11] RVA: 0x10355B2D0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1045DD954
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.GetTeammateBattleResultData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1046790c0
	// Params: [ Num(1) Size(0x1C8) ]
	struct FGameModeTeammateBattleResultData GetTeammateBattleResultData();
	// [Call #1] RVA: 0x10467D3AC
	// [Call #2] RVA: 0x10351D8DC
	// [Call #3] RVA: 0x10351D8DC
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1045E10C4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10355B2D0
	// [Call #15] RVA: 0x10355B2D0
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerState.GetTeamID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046790a4
	// Params: [ Num(1) Size(0x4) ]
	int GetTeamID();
	// [Call #1] RVA: 0x10467D3AC
	// [Call #2] RVA: 0x10351D8DC
	// [Call #3] RVA: 0x10351D8DC
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1045E10C4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10355B2D0

	// Object: Function Gameplay.UAEPlayerState.GetRank
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104679070
	// Params: [ Num(1) Size(0x4) ]
	int GetRank();
	// [Call #1] RVA: 0x1045E2530
	// [Call #2] RVA: 0x10467D3AC
	// [Call #3] RVA: 0x10351D8DC
	// [Call #4] RVA: 0x10351D8DC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045E10C4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetPlayerTotalShootNum
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x104679034
	// Params: [ Num(1) Size(0x4) ]
	int GetPlayerTotalShootNum();
	// [Call #1] RVA: 0x1045E2530
	// [Call #2] RVA: 0x10467D3AC
	// [Call #3] RVA: 0x10351D8DC
	// [Call #4] RVA: 0x10351D8DC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045E10C4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetPlayerKey
	// Flags: [Final|Native|Public]
	// Offset: 0x104679000
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetPlayerKey();
	// [Call #1] RVA: 0x1045E1F24
	// [Call #2] RVA: 0x1045E2530
	// [Call #3] RVA: 0x10467D3AC
	// [Call #4] RVA: 0x10351D8DC
	// [Call #5] RVA: 0x10351D8DC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045E10C4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetPlayerBattleResultData_SuperCold
	// Flags: [Native|Public|Const]
	// Offset: 0x104678f90
	// Params: [ Num(1) Size(0x38) ]
	struct FGameModePlayerBattleResultData_SuperCold GetPlayerBattleResultData_SuperCold();
	// [Call #1] RVA: 0x10467D320
	// [Call #2] RVA: 0x1046127EC
	// [Call #3] RVA: 0x1046127EC
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1045E1F24
	// [Call #6] RVA: 0x1045E2530
	// [Call #7] RVA: 0x10467D3AC
	// [Call #8] RVA: 0x10351D8DC
	// [Call #9] RVA: 0x10351D8DC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1045E10C4
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerState.GetPlayerBattleResultData
	// Flags: [Native|Public|Const]
	// Offset: 0x104678f24
	// Params: [ Num(1) Size(0x618) ]
	struct FGameModePlayerBattleResultData GetPlayerBattleResultData();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530
	// [Call #11] RVA: 0x10467D3AC
	// [Call #12] RVA: 0x10351D8DC
	// [Call #13] RVA: 0x10351D8DC
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1045E10C4
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerState.GetMentorPlayerType
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104678ee8
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetMentorPlayerType();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530
	// [Call #11] RVA: 0x10467D3AC
	// [Call #12] RVA: 0x10351D8DC
	// [Call #13] RVA: 0x10351D8DC
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerState.ForceUpdateCampCharacterList
	// Flags: [Native|Public]
	// Offset: 0x104678ecc
	// Params: [ Num(0) Size(0x0) ]
	void ForceUpdateCampCharacterList();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530
	// [Call #11] RVA: 0x10467D3AC
	// [Call #12] RVA: 0x10351D8DC
	// [Call #13] RVA: 0x10351D8DC

	// Object: Function Gameplay.UAEPlayerState.CopyNearDeathDamageInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104678eb8
	// Params: [ Num(0) Size(0x0) ]
	void CopyNearDeathDamageInfo();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530
	// [Call #11] RVA: 0x10467D3AC
	// [Call #12] RVA: 0x10351D8DC

	// Object: Function Gameplay.UAEPlayerState.CopyDeathDamageInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104678ea4
	// Params: [ Num(0) Size(0x0) ]
	void CopyDeathDamageInfo();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530

	// Object: Function Gameplay.UAEPlayerState.ClearTlogData
	// Flags: [Native|Public]
	// Offset: 0x104678e88
	// Params: [ Num(0) Size(0x0) ]
	void ClearTlogData();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530

	// Object: Function Gameplay.UAEPlayerState.ClearKillNum
	// Flags: [Final|Native|Public]
	// Offset: 0x104678e64
	// Params: [ Num(0) Size(0x0) ]
	void ClearKillNum();
	// [Call #1] RVA: 0x10467C6CC
	// [Call #2] RVA: 0x10351D670
	// [Call #3] RVA: 0x10351D670
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10467D320
	// [Call #6] RVA: 0x1046127EC
	// [Call #7] RVA: 0x1046127EC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1045E1F24
	// [Call #10] RVA: 0x1045E2530

	// Object: Function Gameplay.UAEPlayerState.ChangeCollectItemRecord
	// Flags: [Final|Native|Public]
	// Offset: 0x104678da8
	// Params: [ Num(2) Size(0x5) ]
	void ChangeCollectItemRecord(int InItemID, bool InNewState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E1530
	// [Call #6] RVA: 0x10467C6CC
	// [Call #7] RVA: 0x10351D670
	// [Call #8] RVA: 0x10351D670
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10467D320
	// [Call #11] RVA: 0x1046127EC
	// [Call #12] RVA: 0x1046127EC
	// [Call #13] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerState.AddGeneralTLogJustForDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104678cb8
	// Params: [ Num(3) Size(0xC) ]
	void AddGeneralTLogJustForDelegate(int ID, int DeltaCnt, int CurrValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E22C0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045E1530

	// Object: Function Gameplay.UAEPlayerState.AddGeneralCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104678bc0
	// Params: [ Num(3) Size(0x9) ]
	void AddGeneralCount(int ID, int InCount, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E2154
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E22C0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerState.AddEventCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104678ac8
	// Params: [ Num(3) Size(0x9) ]
	void AddEventCount(uint8_t EventID, int InCount, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E20C4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E2154
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class Gameplay.BackpackComponent
// Size: 0x5F0 (Inherited: 0x238)
struct UBackpackComponent : ULuaActorComponent
{
	uint8_t Pad_0x238[0x10]; // 0x238(0x10)
	struct FScriptMulticastDelegate ItemListUpdatedDelegate; // 0x248(0x10)
	struct FScriptMulticastDelegate SingleItemUpdatedDelegate; // 0x258(0x10)
	struct FScriptMulticastDelegate SingleItemDeleteDelegate; // 0x268(0x10)
	struct FScriptMulticastDelegate BatchItemUpdateDelegate; // 0x278(0x10)
	struct FScriptMulticastDelegate BatchItemDeleteDelegate; // 0x288(0x10)
	struct FScriptMulticastDelegate AvatarItemUpdatedDelegate; // 0x298(0x10)
	struct FScriptMulticastDelegate CapacityUpdatedDelegate; // 0x2A8(0x10)
	struct FScriptMulticastDelegate ItemOperationDelegate; // 0x2B8(0x10)
	struct FScriptMulticastDelegate ItemOperationInfoDelegate; // 0x2C8(0x10)
	struct FScriptMulticastDelegate AssociationOperationDelegate; // 0x2D8(0x10)
	struct FScriptMulticastDelegate ItemOperCountDelegate; // 0x2E8(0x10)
	struct FScriptMulticastDelegate ItemOperationFailedDelegate; // 0x2F8(0x10)
	struct FScriptMulticastDelegate BackPackTipsToPlayerDelegate; // 0x308(0x10)
	struct FScriptMulticastDelegate ItemHandleAddDelegate; // 0x318(0x10)
	struct FScriptMulticastDelegate AIStateItemListUpdatedDelegate; // 0x328(0x10)
	struct FScriptMulticastDelegate ItemUpdatedDelegate; // 0x338(0x10)
	struct FScriptMulticastDelegate ItemRemovedDelegate; // 0x348(0x10)
	struct TArray<struct FCustomAccessoriesData> CustomAccessoriesData; // 0x358(0x10)
	struct TArray<struct FBattleItemPickupAfterLand> BattleItemPickupAfterLandList; // 0x368(0x10)
	struct TArray<struct FSpecialPickInfo> specialCountLimit; // 0x378(0x10)
	int CoinsNum; // 0x388(0x4)
	bool AllowPickToSafeBox; // 0x38C(0x1)
	bool AllowPickForceToBackPack; // 0x38D(0x1)
	uint8_t Pad_0x38E[0x2]; // 0x38E(0x2)
	struct FScriptMulticastDelegate CoinsChangedDelegate; // 0x390(0x10)
	uint8_t Pad_0x3A0[0x28]; // 0x3A0(0x28)
	struct FIncNetArray ItemListNet; // 0x3C8(0x20)
	struct FIncNetArray ItemListNetCache; // 0x3E8(0x20)
	struct TMap<int, struct FBattleItemData> CacheBattleItemMap; // 0x408(0x50)
	struct TArray<struct FItemDefineID> BroadcastInsertItemList; // 0x458(0x10)
	struct TArray<struct FItemDefineID> BroadcastUpdateItemList; // 0x468(0x10)
	struct TArray<struct FItemDefineID> BroadcastDeleteItemList; // 0x478(0x10)
	bool AutoEquipAim; // 0x488(0x1)
	bool bForceAutoEquipAim; // 0x489(0x1)
	uint8_t Pad_0x48A[0x6]; // 0x48A(0x6)
	struct TArray<struct UItemHandleBase*> ItemHandleList; // 0x490(0x10)
	struct TMap<struct FItemDefineID, struct UItemHandleBase*> ItemHandleMap; // 0x4A0(0x50)
	int CapacityThreshold; // 0x4F0(0x4)
	float Capacity; // 0x4F4(0x4)
	float OccupiedCapacity; // 0x4F8(0x4)
	float SafetyBoxCapacity; // 0x4FC(0x4)
	float SafetyBoxOccupiedCapacity; // 0x500(0x4)
	uint8_t Pad_0x504[0x18]; // 0x504(0x18)
	int virtualitemid; // 0x51C(0x4)
	uint8_t Pad_0x520[0x8]; // 0x520(0x8)
	bool IsForbidAutoEquipAttachments; // 0x528(0x1)
	uint8_t Pad_0x529[0x7]; // 0x529(0x7)
	struct TArray<int> NeedToShowTypeList; // 0x530(0x10)
	bool bVerifyWeaponPackageData; // 0x540(0x1)
	bool bEnableBackpackRepActor; // 0x541(0x1)
	uint8_t Pad_0x542[0x6]; // 0x542(0x6)
	struct TArray<int> ForceInBackpackMeelWeaponList; // 0x548(0x10)
	bool bShowBounty; // 0x558(0x1)
	uint8_t Pad_0x559[0x7]; // 0x559(0x7)
	struct FScriptMulticastDelegate BackpackShowBountyDelegate; // 0x560(0x10)
	uint8_t Pad_0x570[0x8]; // 0x570(0x8)
	struct FScriptMulticastDelegate ItemChangeAreaDelegate; // 0x578(0x10)
	struct FScriptMulticastDelegate JumpConsumeItemDelegate; // 0x588(0x10)
	struct TMap<struct FString, struct UObject*> ProxyMap; // 0x598(0x50)
	bool bEnableWeaponAttachmentBindToWeapon; // 0x5E8(0x1)
	uint8_t Pad_0x5E9[0x7]; // 0x5E9(0x7)


	// Object: Function Gameplay.BackpackComponent.UseItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fc51c
	// Params: [ Num(4) Size(0x42) ]
	bool UseItem(struct FItemDefineID DefineID, struct FBattleItemUseTarget Target, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10240685C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041E5664
	// [Call #10] RVA: 0x10282C31C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.BackpackComponent.UpdateStoreAreaOccupiedCapacity
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x1045fc43c
	// Params: [ Num(3) Size(0xC) ]
	float UpdateStoreAreaOccupiedCapacity(float& StoreAreaOccupiedCapacity, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10240685C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x10282C31C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Gameplay.BackpackComponent.UpdateOccupiedCapacity
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1045fc420
	// Params: [ Num(0) Size(0x0) ]
	void UpdateOccupiedCapacity();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10240685C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x10282C31C

	// Object: Function Gameplay.BackpackComponent.UpdateCapacity
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1045fc3e4
	// Params: [ Num(1) Size(0x4) ]
	float UpdateCapacity();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10240685C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x10282C31C

	// Object: Function Gameplay.BackpackComponent.UnlockUpdateItemListReceive
	// Flags: [Final|Native|Public]
	// Offset: 0x1045fc3d0
	// Params: [ Num(0) Size(0x0) ]
	void UnlockUpdateItemListReceive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10240685C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x10282C31C

	// Object: Function Gameplay.BackpackComponent.TryMergeItemHandles
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1045fc2fc
	// Params: [ Num(2) Size(0x19) ]
	void TryMergeItemHandles(struct FItemDefineID& DefineID, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045582FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.TakeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fc1dc
	// Params: [ Num(4) Size(0x24) ]
	int TakeItem(struct FItemDefineID DefineID, int Count, bool bCallHandleDrop);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x10455CDC4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045582FC

	// Object: Function Gameplay.BackpackComponent.SwapItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fc0ec
	// Params: [ Num(3) Size(0x31) ]
	bool SwapItem(struct FItemDefineID DefineID1, struct FItemDefineID DefineID2);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E5664
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664
	// [Call #17] RVA: 0x10455CDC4
	// [Call #18] RVA: 0x1041EFFBC
	// [Call #19] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.SetForceAutoEquipAim
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fc068
	// Params: [ Num(1) Size(0x1) ]
	void SetForceAutoEquipAim(bool bInAutoEquipAim);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455EF10
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041E5664
	// [Call #11] RVA: 0x1041E5664
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.SetChangeWeaponSchemeState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fbfe4
	// Params: [ Num(1) Size(0x1) ]
	void SetChangeWeaponSchemeState(bool bInIsChangeWeaponScheme);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455FCC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455EF10
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x1041E5664
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ServerSetShowBounty
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045fbf58
	// Params: [ Num(1) Size(0x1) ]
	void ServerSetShowBounty(bool bInShowBounty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455FCC8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455EF10
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041E5664
	// [Call #16] RVA: 0x1041E5664

	// Object: Function Gameplay.BackpackComponent.ServerSetDropMeelWeapon
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045fbecc
	// Params: [ Num(1) Size(0x1) ]
	void ServerSetDropMeelWeapon(bool NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455FCC8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455EF10
	// [Call #11] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.ServerSetCustomAccessories
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045fbd94
	// Params: [ Num(4) Size(0xD) ]
	void ServerSetCustomAccessories(int WeaponItemId, int Index, int ItemId, bool bIsSetOrRemove);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ServerEnableItem
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045fbcb0
	// Params: [ Num(2) Size(0x19) ]
	void ServerEnableItem(struct FItemDefineID DefineID, bool bUse);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.RPC_Multicast_AllItem
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable]
	// Offset: 0x1045fbbe8
	// Params: [ Num(1) Size(0x20) ]
	void RPC_Multicast_AllItem(struct FIncNetArray Items);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104600138
	// [Call #4] RVA: 0x1023C5308
	// [Call #5] RVA: 0x1023C5308
	// [Call #6] RVA: 0x1023C5308
	// [Call #7] RVA: 0x1023C5308
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041E5664
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.ReturnItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fbac8
	// Params: [ Num(4) Size(0x24) ]
	int ReturnItem(struct FItemDefineID DefineID, int Count, bool bCallHandlePickup);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x10455D08C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104600138
	// [Call #13] RVA: 0x1023C5308
	// [Call #14] RVA: 0x1023C5308
	// [Call #15] RVA: 0x1023C5308
	// [Call #16] RVA: 0x1023C5308
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x1041EFFBC
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.RemoveItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045fba20
	// Params: [ Num(2) Size(0x19) ]
	bool RemoveItemHandle(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041E5664
	// [Call #12] RVA: 0x10455D08C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104600138
	// [Call #16] RVA: 0x1023C5308

	// Object: Function Gameplay.BackpackComponent.ReceiveItemList
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1045fba04
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveItemList();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041E5664
	// [Call #12] RVA: 0x10455D08C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104600138

	// Object: Function Gameplay.BackpackComponent.ReceiveCapacity
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1045fb9e8
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveCapacity();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041E5664
	// [Call #12] RVA: 0x10455D08C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.PreCheckCanPickupBagAvatar
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1045fb8e0
	// Params: [ Num(4) Size(0x18) ]
	int PreCheckCanPickupBagAvatar(struct UBattleItemHandleBase* NewHandle, struct UBattleItemHandleBase* OldHandle, uint8_t reson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.PostItemHandleEquippingState
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1045fb804
	// Params: [ Num(2) Size(0x19) ]
	void PostItemHandleEquippingState(struct FItemDefineID& DefineID, bool bEquipping);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455B838
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.PickupItemFromWrapperDetail
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fb658
	// Params: [ Num(5) Size(0x73) ]
	bool PickupItemFromWrapperDetail(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason, uint8_t BattleItemClientPickupType);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.PickUpItem_Default
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fb4ec
	// Params: [ Num(4) Size(0x72) ]
	bool PickUpItem_Default(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.PickupItem
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fb340
	// Params: [ Num(5) Size(0x73) ]
	bool PickupItem(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason, uint8_t BattleItemClientPickupType);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102406800
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.PickupBattleItemOnPlane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fb32c
	// Params: [ Num(0) Size(0x0) ]
	void PickupBattleItemOnPlane();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102406800
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.PickItem_IntoSafetyBox
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fb1c0
	// Params: [ Num(4) Size(0x72) ]
	bool PickItem_IntoSafetyBox(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.PickItem_IntoBackpack
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045fb054
	// Params: [ Num(4) Size(0x72) ]
	bool PickItem_IntoBackpack(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.OnRep_specialCountLimit
	// Flags: [Final|Native|Public]
	// Offset: 0x1045fb040
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_specialCountLimit();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.OnRep_ItemListNet
	// Flags: [Final|Native|Public]
	// Offset: 0x1045fb02c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ItemListNet();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.OnRep_CoinsNum
	// Flags: [Final|Native|Public]
	// Offset: 0x1045fb018
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CoinsNum();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.OnRep_Capacity
	// Flags: [Final|Native|Protected]
	// Offset: 0x1045fb004
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Capacity();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.NotifyItemUpdated
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045faf6c
	// Params: [ Num(1) Size(0x18) ]
	void NotifyItemUpdated(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102406800
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x1023C52B8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.BackpackComponent.NotifyItemRemoved
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045faed4
	// Params: [ Num(1) Size(0x18) ]
	void NotifyItemRemoved(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102406800
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.NotifyItemListUpdated
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1045faeb8
	// Params: [ Num(0) Size(0x0) ]
	void NotifyItemListUpdated();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102406800
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.NotifyCapacityUpdated
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1045fae9c
	// Params: [ Num(0) Size(0x0) ]
	void NotifyCapacityUpdated();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102406800
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.NewItemHandle
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x1045fadf4
	// Params: [ Num(2) Size(0x20) ]
	struct UBattleItemHandleBase* NewItemHandle(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.NewItemDefineID
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x1045fad3c
	// Params: [ Num(2) Size(0x30) ]
	struct FItemDefineID NewItemDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.ModifyItemHandleEquippingState
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1045fac7c
	// Params: [ Num(2) Size(0x9) ]
	void ModifyItemHandleEquippingState(struct UItemHandleBase* ItemHandle, bool bEquipping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455DC08
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ModifyItemHandleCount
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1045fabc4
	// Params: [ Num(2) Size(0xC) ]
	void ModifyItemHandleCount(struct UItemHandleBase* ItemHandle, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455CD4C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455DC08
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.ModifyAutoPickClipType
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045fab40
	// Params: [ Num(1) Size(0x4) ]
	void ModifyAutoPickClipType(int InAutoPickClipType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455CD4C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455DC08
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.ModifyAimNotAutoUse
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x1045faab4
	// Params: [ Num(1) Size(0x1) ]
	void ModifyAimNotAutoUse(bool bAdd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455CD4C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.LockUpdateItemListReceive
	// Flags: [Final|Native|Public]
	// Offset: 0x1045faaa0
	// Params: [ Num(0) Size(0x0) ]
	void LockUpdateItemListReceive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455CD4C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.ItemNet2Data
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045fa9bc
	// Params: [ Num(2) Size(0x110) ]
	struct FBattleItemData ItemNet2Data(struct FNetArrayUnit& NetItem);
	// [Call #1] RVA: 0x10457534C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455D328
	// [Call #5] RVA: 0x102E460E4
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x1023C5258
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x1023C5258
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.IsNeedToShowInBackpack
	// Flags: [Final|Native|Public]
	// Offset: 0x1045fa930
	// Params: [ Num(2) Size(0x5) ]
	bool IsNeedToShowInBackpack(int TypeDefineID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455FCE0
	// [Call #4] RVA: 0x10457534C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455D328
	// [Call #8] RVA: 0x102E460E4
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x1023C5258
	// [Call #11] RVA: 0x1041E56B0
	// [Call #12] RVA: 0x1023C5258
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItemTypes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa878
	// Params: [ Num(2) Size(0x11) ]
	bool IsItemListUpdatedHasSomeItemTypes(struct TArray<int>& ItemTypes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E158
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455FCE0
	// [Call #10] RVA: 0x10457534C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455D328
	// [Call #14] RVA: 0x102E460E4
	// [Call #15] RVA: 0x1041E56B0
	// [Call #16] RVA: 0x1023C5258
	// [Call #17] RVA: 0x1041E56B0
	// [Call #18] RVA: 0x1023C5258
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItemSubTypes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa7c0
	// Params: [ Num(2) Size(0x11) ]
	bool IsItemListUpdatedHasSomeItemSubTypes(struct TArray<int>& ItemSubTypes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E218
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455E158
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455FCE0
	// [Call #16] RVA: 0x10457534C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa708
	// Params: [ Num(2) Size(0x11) ]
	bool IsItemListUpdatedHasSomeItems(struct TArray<int>& ItemTypeSpecificIDs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E098
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455E218
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E158
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItemType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa67c
	// Params: [ Num(2) Size(0x5) ]
	bool IsItemListUpdatedHasOneItemType(int itemType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455DE54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455E098
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455E218
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItemSubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa5f0
	// Params: [ Num(2) Size(0x5) ]
	bool IsItemListUpdatedHasOneItemSubType(int ItemSubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455DEE0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455DE54
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455E098
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E218

	// Object: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1045fa564
	// Params: [ Num(2) Size(0x5) ]
	bool IsItemListUpdatedHasOneItem(int ItemTypeSpecificID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455DDC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455DEE0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455DE54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455E098
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44

	// Object: Function Gameplay.BackpackComponent.IsItemExist
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1045fa4bc
	// Params: [ Num(2) Size(0x19) ]
	bool IsItemExist(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455DDC4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455DEE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455DE54

	// Object: Function Gameplay.BackpackComponent.IsEnableWeaponAttachmentBindToWeapon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045fa488
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnableWeaponAttachmentBindToWeapon();
	// [Call #1] RVA: 0x10455AD6C
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455DDC4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455DEE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.IsEnableBackpackRepActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045fa454
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnableBackpackRepActor();
	// [Call #1] RVA: 0x104556BC8
	// [Call #2] RVA: 0x10455AD6C
	// [Call #3] RVA: 0x1041EFFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455DDC4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455DEE0

	// Object: Function Gameplay.BackpackComponent.IsCustomIgnoreAccessories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fa390
	// Params: [ Num(3) Size(0x9) ]
	bool IsCustomIgnoreAccessories(int WeaponId, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455A234
	// [Call #6] RVA: 0x104556BC8
	// [Call #7] RVA: 0x10455AD6C
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455DDC4

	// Object: Function Gameplay.BackpackComponent.IsCustomAccessories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fa2cc
	// Params: [ Num(3) Size(0x9) ]
	bool IsCustomAccessories(int WeaponId, int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455A10C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455A234
	// [Call #11] RVA: 0x104556BC8
	// [Call #12] RVA: 0x10455AD6C
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.IsChangeWeaponScheme
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045fa298
	// Params: [ Num(1) Size(0x1) ]
	bool IsChangeWeaponScheme();
	// [Call #1] RVA: 0x10455FCD0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455A10C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455A234
	// [Call #12] RVA: 0x104556BC8
	// [Call #13] RVA: 0x10455AD6C
	// [Call #14] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.IsBackPackContainItemId
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1045fa20c
	// Params: [ Num(2) Size(0x5) ]
	bool IsBackPackContainItemId(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E804
	// [Call #4] RVA: 0x10455FCD0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455A10C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10455A234

	// Object: Function Gameplay.BackpackComponent.IsAutoUse
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x5) ]
	bool IsAutoUse(int ItemId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.BackpackComponent.HasUnEquipItemByDefindIdRange
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1045fa148
	// Params: [ Num(3) Size(0x9) ]
	bool HasUnEquipItemByDefindIdRange(int LowValue, int HighValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455E76C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455E804
	// [Call #9] RVA: 0x10455FCD0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10455A10C

	// Object: Function Gameplay.BackpackComponent.HasTagSub
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	bool HasTagSub(int ItemId, struct FName& TagName);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.BackpackComponent.HasItemBySubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045fa0bc
	// Params: [ Num(2) Size(0x5) ]
	bool HasItemBySubType(int SubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E5DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455E76C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455E804
	// [Call #12] RVA: 0x10455FCD0
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.HasItemBySpecificID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045fa030
	// Params: [ Num(2) Size(0x5) ]
	bool HasItemBySpecificID(int SpecificID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E5A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455E5DC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455E76C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10455E804

	// Object: Function Gameplay.BackpackComponent.HasItemByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9f90
	// Params: [ Num(2) Size(0x19) ]
	bool HasItemByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455E560
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455E5A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455E5DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.HasItemByDefindIdRange
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9ecc
	// Params: [ Num(3) Size(0x9) ]
	bool HasItemByDefindIdRange(int LowValue, int HighValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455E72C
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455E560
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455E5A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.HasAllItem
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f9da0
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<int> HasAllItem(struct TArray<struct FBattleItemData>& ItemDataArray, bool bExcludeEquippingItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455E9F8
	// [Call #6] RVA: 0x101FA6168
	// [Call #7] RVA: 0x101F8BA44
	// [Call #8] RVA: 0x10282D084
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x10282D084
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10455E72C
	// [Call #17] RVA: 0x1041EFFBC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.HandleDropInDisuse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f9c4c
	// Params: [ Num(4) Size(0x28) ]
	void HandleDropInDisuse(struct FItemDefineID& DefineID, struct UBattleItemHandleBase* ItemHandle, uint8_t Reason, float OccupiedCapacityBeforeDisuse);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10455E9F8
	// [Call #15] RVA: 0x101FA6168
	// [Call #16] RVA: 0x101F8BA44
	// [Call #17] RVA: 0x10282D084

	// Object: Function Gameplay.BackpackComponent.GetWorld_BP
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9c18
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetWorld_BP();
	// [Call #1] RVA: 0x104556C08
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E9F8

	// Object: Function Gameplay.BackpackComponent.GetUnEquipItemNumByItemId
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1045f9b8c
	// Params: [ Num(2) Size(0x8) ]
	int GetUnEquipItemNumByItemId(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E7B4
	// [Call #4] RVA: 0x104556C08
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.GetSpecialItemNow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9aec
	// Params: [ Num(2) Size(0x24) ]
	struct FSpecialPickInfo GetSpecialItemNow(struct FItemDefineID DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x104557B4C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455E7B4
	// [Call #9] RVA: 0x104556C08
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.GetSpecialItemBefore
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9a5c
	// Params: [ Num(2) Size(0x10) ]
	struct FSpecialPickInfo GetSpecialItemBefore(int ItemResId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104557AE8
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E5664
	// [Call #8] RVA: 0x104557B4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455E7B4
	// [Call #12] RVA: 0x104556C08
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.GetSafetyBoxCapacity
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f9a20
	// Params: [ Num(1) Size(0x4) ]
	float GetSafetyBoxCapacity();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104557AE8
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041E5664
	// [Call #8] RVA: 0x104557B4C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455E7B4
	// [Call #12] RVA: 0x104556C08
	// [Call #13] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.GetLeastElectrictyBattleItemData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045f9920
	// Params: [ Num(3) Size(0xE0) ]
	struct FBattleItemData GetLeastElectrictyBattleItemData(struct FItemDefineID DefineID, uint8_t AdditionalDataNameType);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x10455FBB0
	// [Call #8] RVA: 0x102E460E4
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x1041E56B0
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104557AE8
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041E5664
	// [Call #19] RVA: 0x104557B4C

	// Object: Function Gameplay.BackpackComponent.GetItemSubType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x8) ]
	int GetItemSubType(int ItemId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.BackpackComponent.GetItemListBySpecialID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f97ac
	// Params: [ Num(4) Size(0x28) ]
	struct TArray<struct FBattleItemData> GetItemListBySpecialID(struct TArray<int>& SpecialIDArray, bool bIgnoreEquipping, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455E920
	// [Call #8] RVA: 0x102E43A3C
	// [Call #9] RVA: 0x10282D084
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x10282D084
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1041EFFBC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1041E5664
	// [Call #20] RVA: 0x10455FBB0
	// [Call #21] RVA: 0x102E460E4
	// [Call #22] RVA: 0x1041E56B0

	// Object: Function Gameplay.BackpackComponent.GetItemListByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f96e4
	// Params: [ Num(2) Size(0x28) ]
	struct TArray<struct FBattleItemData> GetItemListByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455E840
	// [Call #5] RVA: 0x102E43A3C
	// [Call #6] RVA: 0x10282D084
	// [Call #7] RVA: 0x10282D084
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E920
	// [Call #16] RVA: 0x102E43A3C
	// [Call #17] RVA: 0x10282D084
	// [Call #18] RVA: 0x101F8BA44
	// [Call #19] RVA: 0x10282D084
	// [Call #20] RVA: 0x101F8BA44
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Gameplay.BackpackComponent.GetItemHandleMap
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x1045f96a4
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FItemDefineID, struct UItemHandleBase*> GetItemHandleMap();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455E840
	// [Call #5] RVA: 0x102E43A3C
	// [Call #6] RVA: 0x10282D084
	// [Call #7] RVA: 0x10282D084
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E920
	// [Call #16] RVA: 0x102E43A3C
	// [Call #17] RVA: 0x10282D084
	// [Call #18] RVA: 0x101F8BA44
	// [Call #19] RVA: 0x10282D084

	// Object: Function Gameplay.BackpackComponent.GetItemHandleList
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x1045f9664
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UItemHandleBase*> GetItemHandleList();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455E840
	// [Call #5] RVA: 0x102E43A3C
	// [Call #6] RVA: 0x10282D084
	// [Call #7] RVA: 0x10282D084
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455E920

	// Object: Function Gameplay.BackpackComponent.GetItemCountByType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f95d8
	// Params: [ Num(2) Size(0x8) ]
	int GetItemCountByType(int InItemType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E518
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455E840
	// [Call #8] RVA: 0x102E43A3C
	// [Call #9] RVA: 0x10282D084
	// [Call #10] RVA: 0x10282D084
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.GetItemCountByItemSpecialID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f954c
	// Params: [ Num(2) Size(0x8) ]
	int GetItemCountByItemSpecialID(int InItemSpecialID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455D030
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455E518
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10455E840
	// [Call #11] RVA: 0x102E43A3C
	// [Call #12] RVA: 0x10282D084
	// [Call #13] RVA: 0x10282D084

	// Object: Function Gameplay.BackpackComponent.GetItemByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9484
	// Params: [ Num(2) Size(0xD8) ]
	struct FBattleItemData GetItemByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455E4D0
	// [Call #5] RVA: 0x102E460E4
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455D030
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10455E518

	// Object: Function Gameplay.BackpackComponent.GetItemAttrsFlag
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1045f93f0
	// Params: [ Num(2) Size(0x8) ]
	int GetItemAttrsFlag(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041EFFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10455E4D0
	// [Call #7] RVA: 0x102E460E4
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x1041E56B0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455D030
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.GetItemAssociateWeights
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f9334
	// Params: [ Num(2) Size(0xC4) ]
	float GetItemAssociateWeights(struct FBattleItemData& InItemData);
	// [Call #1] RVA: 0x1041E55E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455FD80
	// [Call #5] RVA: 0x1041E56B0
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455E4D0
	// [Call #14] RVA: 0x102E460E4
	// [Call #15] RVA: 0x1041E56B0
	// [Call #16] RVA: 0x1041E56B0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.GetFirstItemBySubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f9280
	// Params: [ Num(2) Size(0xC8) ]
	struct FBattleItemData GetFirstItemBySubType(int SubType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455EBBC
	// [Call #4] RVA: 0x102E460E4
	// [Call #5] RVA: 0x1041E56B0
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1041E55E0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455FD80
	// [Call #12] RVA: 0x1041E56B0
	// [Call #13] RVA: 0x1041E56B0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1041EFFBC
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.GetFirstItemByDefineIDIgnoreInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f91b8
	// Params: [ Num(2) Size(0xD8) ]
	struct FBattleItemData GetFirstItemByDefineIDIgnoreInstance(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455EB74
	// [Call #5] RVA: 0x102E460E4
	// [Call #6] RVA: 0x1041E56B0
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455EBBC
	// [Call #12] RVA: 0x102E460E4
	// [Call #13] RVA: 0x1041E56B0
	// [Call #14] RVA: 0x1041E56B0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1041E55E0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10455FD80
	// [Call #20] RVA: 0x1041E56B0
	// [Call #21] RVA: 0x1041E56B0
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Gameplay.BackpackComponent.GetCurrentPickupItemDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f916c
	// Params: [ Num(1) Size(0x18) ]
	struct FItemDefineID GetCurrentPickupItemDefineID();
	// [Call #1] RVA: 0x10455C4C4
	// [Call #2] RVA: 0x1041EFFBC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455EB74
	// [Call #6] RVA: 0x102E460E4
	// [Call #7] RVA: 0x1041E56B0
	// [Call #8] RVA: 0x1041E56B0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455EBBC
	// [Call #13] RVA: 0x102E460E4
	// [Call #14] RVA: 0x1041E56B0
	// [Call #15] RVA: 0x1041E56B0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1041E55E0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10455FD80

	// Object: Function Gameplay.BackpackComponent.GetBattleItemFeatureDataByDefineID
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x1045f90b0
	// Params: [ Num(2) Size(0x48) ]
	struct FBattleItemFeatureData GetBattleItemFeatureDataByDefineID(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10455C4C4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10455EB74
	// [Call #9] RVA: 0x102E460E4
	// [Call #10] RVA: 0x1041E56B0
	// [Call #11] RVA: 0x1041E56B0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455EBBC
	// [Call #16] RVA: 0x102E460E4

	// Object: Function Gameplay.BackpackComponent.GetAllItemList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f8ffc
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FBattleItemData> GetAllItemList(uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455E3DC
	// [Call #4] RVA: 0x102E43A3C
	// [Call #5] RVA: 0x10282D084
	// [Call #6] RVA: 0x10282D084
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455C4C4
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10455EB74
	// [Call #16] RVA: 0x102E460E4

	// Object: Function Gameplay.BackpackComponent.GetAIPickupType
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1045f8f68
	// Params: [ Num(2) Size(0x5) ]
	uint8_t GetAIPickupType(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455E3DC
	// [Call #6] RVA: 0x102E43A3C
	// [Call #7] RVA: 0x10282D084
	// [Call #8] RVA: 0x10282D084
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455C4C4

	// Object: Function Gameplay.BackpackComponent.ForceNetUpdate
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1045f8f4c
	// Params: [ Num(0) Size(0x0) ]
	void ForceNetUpdate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10455E3DC
	// [Call #6] RVA: 0x102E43A3C
	// [Call #7] RVA: 0x10282D084
	// [Call #8] RVA: 0x10282D084
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455C4C4

	// Object: Function Gameplay.BackpackComponent.DropItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f8e30
	// Params: [ Num(4) Size(0x1E) ]
	bool DropItem(struct FItemDefineID DefineID, int Count, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10455E3DC
	// [Call #14] RVA: 0x102E43A3C
	// [Call #15] RVA: 0x10282D084

	// Object: Function Gameplay.BackpackComponent.DisuseItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f8d50
	// Params: [ Num(3) Size(0x1A) ]
	bool DisuseItem(struct FItemDefineID DefineID, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041E5664
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.CreateItemHandleInternal
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x1045f8ca8
	// Params: [ Num(2) Size(0x20) ]
	struct UBattleItemHandleBase* CreateItemHandleInternal(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041E5664
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.CreateItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1045f8c00
	// Params: [ Num(2) Size(0x20) ]
	struct UItemHandleBase* CreateItemHandle(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041E5664
	// [Call #13] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.ConsumeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045f8b28
	// Params: [ Num(3) Size(0x20) ]
	int ConsumeItem(struct FItemDefineID DefineID, int Count);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x10455CAE0
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.ClientBroadcastItemOperationFailedDelegate
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x1045f8a28
	// Params: [ Num(3) Size(0x1A) ]
	void ClientBroadcastItemOperationFailedDelegate(struct FItemDefineID DefineID, uint8_t OperationType, uint8_t FailedReason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x10455CAE0
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ClientBroadcastItemOperationDelegate
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x1045f8928
	// Params: [ Num(3) Size(0x1A) ]
	void ClientBroadcastItemOperationDelegate(struct FItemDefineID DefineID, uint8_t OperationType, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.ClientBroadcastItemChangeAreaDelegate
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1045f87ec
	// Params: [ Num(4) Size(0xD) ]
	void ClientBroadcastItemChangeAreaDelegate(int TypeSpecificID, uint8_t OperationType, int Num, bool bToSafeBox);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.CheckSpecialMaxCountForItem
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f8710
	// Params: [ Num(3) Size(0x20) ]
	int CheckSpecialMaxCountForItem(struct FItemDefineID& DefineID, int Count);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104558230
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.CheckSkillPropItemCanBePickup
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1045f862c
	// Params: [ Num(3) Size(0x21) ]
	bool CheckSkillPropItemCanBePickup(struct UBackpackComponent* BackpackComp, struct FItemDefineID DefineID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1041EFFBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104558230
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.CheckPickUpItemDefaultSuccess
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f84f4
	// Params: [ Num(4) Size(0x1B) ]
	bool CheckPickUpItemDefaultSuccess(struct FItemDefineID& DefineID, bool bPickupSucc, bool bAutoEquip);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1041E5664
	// [Call #14] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.CheckLeftLimitCountForItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f8428
	// Params: [ Num(3) Size(0xC) ]
	int CheckLeftLimitCountForItem(int InItemID, int InCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.CheckItemEmptyInBackpack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045f83ac
	// Params: [ Num(1) Size(0x4) ]
	void CheckItemEmptyInBackpack(int InItemID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10455AE70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.CheckItemAttrsFlag
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1045f82dc
	// Params: [ Num(3) Size(0x6) ]
	bool CheckItemAttrsFlag(int ItemId, uint8_t ItemAttrEnum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10455AE70
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041EFFBC

	// Object: Function Gameplay.BackpackComponent.CheckCapacityForItem
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x1045f81bc
	// Params: [ Num(4) Size(0x24) ]
	int CheckCapacityForItem(struct FItemDefineID& DefineID, int Count, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ChangeItemStoreAreaNew
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1045f80a0
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreAreaNew(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.ChangeItemStoreArea
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1045f7f84
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreArea(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664

	// Object: Function Gameplay.BackpackComponent.CantDrop
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1045f7f48
	// Params: [ Num(1) Size(0x1) ]
	bool CantDrop();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664

	// Object: Function Gameplay.BackpackComponent.CanDisuseToBackpack
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f7ea4
	// Params: [ Num(2) Size(0x19) ]
	bool CanDisuseToBackpack(struct FItemDefineID DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041E5664
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.CacheItemAssociationBeforeDisuse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f7dc4
	// Params: [ Num(3) Size(0x1A) ]
	bool CacheItemAssociationBeforeDisuse(struct FItemDefineID DefineID, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041E5664
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1041E5664
	// [Call #11] RVA: 0x1041EFFBC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.BroadcastItemOperCountDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f7cb4
	// Params: [ Num(3) Size(0x20) ]
	void BroadcastItemOperCountDelegate(struct FItemDefineID& DefineID, uint8_t OperationType, int Count);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104557788
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1041E5664
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.BroadcastItemOperationInfoDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f7c24
	// Params: [ Num(1) Size(0x20) ]
	void BroadcastItemOperationInfoDelegate(struct FItemOperationInfo& ItemOperationInfo);
	// [Call #1] RVA: 0x1040033F0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104557720
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104557788
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1041E5664

	// Object: Function Gameplay.BackpackComponent.BroadcastItemOperationFailedDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f7b14
	// Params: [ Num(3) Size(0x1A) ]
	void BroadcastItemOperationFailedDelegate(struct FItemDefineID& DefineID, uint8_t OperationType, uint8_t FailedReason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045579A4
	// [Call #9] RVA: 0x1040033F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104557720
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.BroadcastItemOperationDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f7a04
	// Params: [ Num(3) Size(0x1A) ]
	void BroadcastItemOperationDelegate(struct FItemDefineID& DefineID, uint8_t OperationType, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104557840
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045579A4
	// [Call #17] RVA: 0x1040033F0

	// Object: Function Gameplay.BackpackComponent.BroadcastItemChangeAreaDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045f78d0
	// Params: [ Num(4) Size(0xD) ]
	void BroadcastItemChangeAreaDelegate(int TypeSpecificID, uint8_t OperationType, int Num, bool bToSafeBox);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10455FE30
	// [Call #10] RVA: 0x1041EFFBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104557840

	// Object: Function Gameplay.BackpackComponent.AlternativePickupItem
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1045f7828
	// Params: [ Num(2) Size(0x19) ]
	bool AlternativePickupItem(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10455FE30
	// [Call #13] RVA: 0x1041EFFBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.BackpackComponent.AddItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f7744
	// Params: [ Num(3) Size(0x21) ]
	bool AddItemHandle(struct FItemDefineID& DefineID, struct UItemHandleBase* ItemHandle);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1041EFFBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.BackpackComponent.AddBattleItemPickupOnPlane
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1045f75b0
	// Params: [ Num(4) Size(0x72) ]
	void AddBattleItemPickupOnPlane(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason, uint8_t BattleItemClientPickupType);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10455C8C8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x1023C52B8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class Gameplay.UAECharacter
// Size: 0xAE0 (Inherited: 0x8F0)
struct AUAECharacter : ACharacter
{
	uint8_t Pad_0x8F0[0x58]; // 0x8F0(0x58)
	int iRegionCharacter; // 0x948(0x4)
	uint8_t Pad_0x94C[0x4]; // 0x94C(0x4)
	struct FName RepPropertyCategory; // 0x950(0x8)
	struct FName PlayerType; // 0x958(0x8)
	struct FString PlayerName; // 0x960(0x10)
	struct FString Nation; // 0x970(0x10)
	uint32_t PlayerKey; // 0x980(0x4)
	uint8_t Pad_0x984[0x4]; // 0x984(0x4)
	struct FString PlayerUID; // 0x988(0x10)
	int TeamID; // 0x998(0x4)
	uint8_t Pad_0x99C[0x4]; // 0x99C(0x4)
	struct FScriptMulticastDelegate OnTeamIDChange; // 0x9A0(0x10)
	bool bTeamLeader; // 0x9B0(0x1)
	uint8_t Pad_0x9B1[0x3]; // 0x9B1(0x3)
	int Campid; // 0x9B4(0x4)
	int resID; // 0x9B8(0x4)
	uint8_t DefaultCharacterGender; // 0x9BC(0x1)
	uint8_t Pad_0x9BD[0x3]; // 0x9BD(0x3)
	struct TArray<struct FGameModePlayerItem> InitialItemList; // 0x9C0(0x10)
	struct FGameModePlayerUpassInfo UpassInfo; // 0x9D0(0x38)
	struct FGameModePlayerPetInfo PetInfo; // 0xA08(0x20)
	int planeAvatarId; // 0xA28(0x4)
	int DyeDebugFlag; // 0xA2C(0x4)
	struct TArray<struct FGameModePlayerTaskData> InitialTaskDataList; // 0xA30(0x10)
	bool bIsAI; // 0xA40(0x1)
	bool bIsMLAI; // 0xA41(0x1)
	bool bIsAIWithPet; // 0xA42(0x1)
	bool bAINeedCheckBullets; // 0xA43(0x1)
	float DestinyValue; // 0xA44(0x4)
	uint8_t Pad_0xA48[0xC]; // 0xA48(0xC)
	float RatingScore; // 0xA54(0x4)
	bool UseWholeBodyModel; // 0xA58(0x1)
	bool bEnsure; // 0xA59(0x1)
	bool bMEnsure; // 0xA5A(0x1)
	bool bRepEnsure; // 0xA5B(0x1)
	bool bRepMEnsure; // 0xA5C(0x1)
	bool DefaultIsUseWholeBodyModel; // 0xA5D(0x1)
	uint8_t Pad_0xA5E[0x12]; // 0xA5E(0x12)
	struct FString LuaFilePath; // 0xA70(0x10)
	struct FLuaNetSerialization LuaNetSerialization; // 0xA80(0x50)
	uint8_t Pad_0xAD0[0x10]; // 0xAD0(0x10)


	// Object: Function Gameplay.UAECharacter.SetNetCullDistanceSquared
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104651974
	// Params: [ Num(1) Size(0x4) ]
	void SetNetCullDistanceSquared(float fNetCullDistanceSquared);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10459B5D8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAECharacter.SetMEnsure
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1046518e8
	// Params: [ Num(1) Size(0x1) ]
	void SetMEnsure(bool bMValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10459B5D8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.UAECharacter.SetEnsure
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10465185c
	// Params: [ Num(1) Size(0x1) ]
	void SetEnsure(bool bValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10459B5D8
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.UAECharacter.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104651778
	// Params: [ Num(2) Size(0x18) ]
	void SendLuaDSToClient(int ID, struct TArray<uint8_t>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10459B918
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x10465169c
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaDSToClient(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.PostRep_PlayerUID
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104651680
	// Params: [ Num(0) Size(0x0) ]
	void PostRep_PlayerUID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.OnRep_UseWholeModel
	// Flags: [Final|Native|Public]
	// Offset: 0x10465166c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UseWholeModel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.OnRep_TeamID
	// Flags: [Final|Native|Public]
	// Offset: 0x104651658
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_TeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.OnRep_ResId
	// Flags: [Native|Public]
	// Offset: 0x10465163c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_ResId();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAECharacter.OnRep_PlayerUID
	// Flags: [Final|Native|Public]
	// Offset: 0x104651628
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerUID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.OnRep_PlayerKey
	// Flags: [Native|Public]
	// Offset: 0x10465160c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerKey();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.OnRep_CampID
	// Flags: [Final|Native|Public]
	// Offset: 0x1046515f8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CampID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10459B918
	// [Call #13] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAECharacter.IsDefaultCharType
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046515bc
	// Params: [ Num(1) Size(0x1) ]
	bool IsDefaultCharType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.GetTeamID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1046515a0
	// Params: [ Num(1) Size(0x4) ]
	int GetTeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAECharacter.GetRepMEnsure
	// Flags: [Final|Native|Public]
	// Offset: 0x10465156c
	// Params: [ Num(1) Size(0x1) ]
	bool GetRepMEnsure();
	// [Call #1] RVA: 0x10459AE74
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168

	// Object: Function Gameplay.UAECharacter.GetRepEnsure
	// Flags: [Final|Native|Public]
	// Offset: 0x104651538
	// Params: [ Num(1) Size(0x1) ]
	bool GetRepEnsure();
	// [Call #1] RVA: 0x10459AE6C
	// [Call #2] RVA: 0x10459AE74
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.GetPlayerKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1046514d4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetPlayerKey();
	// [Call #1] RVA: 0x10459AD6C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10459AE6C
	// [Call #7] RVA: 0x10459AE74
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.GetPhysicsType
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x104651498
	// Params: [ Num(1) Size(0x4) ]
	int GetPhysicsType();
	// [Call #1] RVA: 0x10459AD6C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10459AE6C
	// [Call #7] RVA: 0x10459AE74
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAECharacter.GetNonSimulatedComponents_OnFighting
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10465142c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents_OnFighting();
	// [Call #1] RVA: 0x1023A7458
	// [Call #2] RVA: 0x101F80ED4
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10459AD6C
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10459AE6C
	// [Call #11] RVA: 0x10459AE74

	// Object: Function Gameplay.UAECharacter.GetNonSimulatedComponents_NonTeammates
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1046513c0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents_NonTeammates();
	// [Call #1] RVA: 0x1023A7458
	// [Call #2] RVA: 0x101F80ED4
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1023A7458
	// [Call #6] RVA: 0x101F80ED4
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10459AD6C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10459AE6C
	// [Call #15] RVA: 0x10459AE74

	// Object: Function Gameplay.UAECharacter.GetNonSimulatedComponents
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x104651354
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents();
	// [Call #1] RVA: 0x1023A7458
	// [Call #2] RVA: 0x101F80ED4
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1023A7458
	// [Call #6] RVA: 0x101F80ED4
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1023A7458
	// [Call #10] RVA: 0x101F80ED4
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10459AD6C
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10459AE6C
	// [Call #19] RVA: 0x10459AE74

	// Object: Function Gameplay.UAECharacter.GetNonDedicatedComponents
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1046512e8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UActorComponent*> GetNonDedicatedComponents();
	// [Call #1] RVA: 0x1023A7458
	// [Call #2] RVA: 0x101F80ED4
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1023A7458
	// [Call #6] RVA: 0x101F80ED4
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1023A7458
	// [Call #10] RVA: 0x101F80ED4
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1023A7458
	// [Call #14] RVA: 0x101F80ED4
	// [Call #15] RVA: 0x101F80ED4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10459AD6C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.GetMovementBaseComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046512b4
	// Params: [ Num(1) Size(0x8) ]
	struct UPrimitiveComponent* GetMovementBaseComponent();
	// [Call #1] RVA: 0x10459BB5C
	// [Call #2] RVA: 0x1023A7458
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x101F80ED4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1023A7458
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x101F80ED4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1023A7458
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x101F80ED4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1023A7458
	// [Call #15] RVA: 0x101F80ED4
	// [Call #16] RVA: 0x101F80ED4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10459AD6C
	// [Call #19] RVA: 0x101F8156C

	// Object: Function Gameplay.UAECharacter.GetMEnsure
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104651278
	// Params: [ Num(1) Size(0x1) ]
	bool GetMEnsure();
	// [Call #1] RVA: 0x10459BB5C
	// [Call #2] RVA: 0x1023A7458
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x101F80ED4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1023A7458
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x101F80ED4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1023A7458
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x101F80ED4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1023A7458
	// [Call #15] RVA: 0x101F80ED4
	// [Call #16] RVA: 0x101F80ED4
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.GetEnsure
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10465123c
	// Params: [ Num(1) Size(0x1) ]
	bool GetEnsure();
	// [Call #1] RVA: 0x10459BB5C
	// [Call #2] RVA: 0x1023A7458
	// [Call #3] RVA: 0x101F80ED4
	// [Call #4] RVA: 0x101F80ED4
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1023A7458
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x101F80ED4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1023A7458
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x101F80ED4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1023A7458
	// [Call #15] RVA: 0x101F80ED4
	// [Call #16] RVA: 0x101F80ED4

	// Object: Function Gameplay.UAECharacter.GetCampID
	// Flags: [Final|Native|Public]
	// Offset: 0x104651208
	// Params: [ Num(1) Size(0x4) ]
	int GetCampID();
	// [Call #1] RVA: 0x10459A6F8
	// [Call #2] RVA: 0x10459BB5C
	// [Call #3] RVA: 0x1023A7458
	// [Call #4] RVA: 0x101F80ED4
	// [Call #5] RVA: 0x101F80ED4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1023A7458
	// [Call #8] RVA: 0x101F80ED4
	// [Call #9] RVA: 0x101F80ED4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1023A7458
	// [Call #12] RVA: 0x101F80ED4
	// [Call #13] RVA: 0x101F80ED4
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacter.ClientAcknowledgeReconnection_2
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104651184
	// Params: [ Num(1) Size(0x4) ]
	void ClientAcknowledgeReconnection_2(uint32_t Token);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10459A6F8
	// [Call #4] RVA: 0x10459BB5C
	// [Call #5] RVA: 0x1023A7458
	// [Call #6] RVA: 0x101F80ED4
	// [Call #7] RVA: 0x101F80ED4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1023A7458
	// [Call #10] RVA: 0x101F80ED4
	// [Call #11] RVA: 0x101F80ED4
	// [Call #12] RVA: 0x106C8459C
};

// Object: Class Gameplay.ItemSceneComponent
// Size: 0x3A0 (Inherited: 0x3A0)
struct UItemSceneComponent : USceneComponent
{
};

// Object: Class Gameplay.GroupSpotSceneComponent
// Size: 0x3B0 (Inherited: 0x3A0)
struct UGroupSpotSceneComponent : UItemSceneComponent
{
	enum class ESpotGroupType GroupType; // 0x399(0x1)
	bool bNearItem; // 0x39A(0x1)
	int WorldCompositionID; // 0x39C(0x4)
	float LastGenerateItemTime; // 0x3A0(0x4)
	float GenerateItemTimeCD; // 0x3A4(0x4)
	bool bPickup; // 0x3A8(0x1)
	bool bRepeatGenerateItem; // 0x3A9(0x1)
	bool bIsValidGroup; // 0x3AA(0x1)


	// Object: Function Gameplay.GroupSpotSceneComponent.SetGroupValid
	// Flags: [Native|Public]
	// Offset: 0x10462e2bc
	// Params: [ Num(1) Size(0x1) ]
	void SetGroupValid(bool Valid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.GroupSpotSceneComponent.IsValidGroup
	// Flags: [Native|Public]
	// Offset: 0x10462e280
	// Params: [ Num(1) Size(0x1) ]
	bool IsValidGroup();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.GroupSpotSceneComponent.FindWorldCompositionID
	// Flags: [Final|Native|Public]
	// Offset: 0x10462e24c
	// Params: [ Num(1) Size(0x4) ]
	int FindWorldCompositionID();
	// [Call #1] RVA: 0x104563218
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.GroupSpotSceneComponent.DoPickUp
	// Flags: [Final|Native|Public]
	// Offset: 0x10462e238
	// Params: [ Num(0) Size(0x0) ]
	void DoPickUp();
	// [Call #1] RVA: 0x104563218
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Gameplay.ItemGroupSpotSceneComponent
// Size: 0x3F0 (Inherited: 0x3B0)
struct UItemGroupSpotSceneComponent : UGroupSpotSceneComponent
{
	uint8_t Pad_0x3B0[0x8]; // 0x3B0(0x8)
	uint8_t RegionSize; // 0x3B8(0x1)
	uint8_t Pad_0x3B9[0x7]; // 0x3B9(0x7)
	struct UItemGeneratorComponent* ItemGenerator; // 0x3C0(0x8)
	struct TArray<struct UItemSpotSceneComponent*> SpotsCacheCur; // 0x3C8(0x10)
	struct TArray<struct UItemSpotSceneComponent*> SpotsCacheAll; // 0x3D8(0x10)
	uint8_t Pad_0x3E8[0x8]; // 0x3E8(0x8)


	// Object: Function Gameplay.ItemGroupSpotSceneComponent.SetGroupProperty
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046382b8
	// Params: [ Num(2) Size(0x30) ]
	void SetGroupProperty(struct UItemGeneratorComponent* Generator, struct FSpotGroupProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104570074
	// [Call #6] RVA: 0x10236BA78
	// [Call #7] RVA: 0x10236BA78
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupSpotSceneComponent.RepeatSpots
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046382a4
	// Params: [ Num(0) Size(0x0) ]
	void RepeatSpots();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104570074
	// [Call #6] RVA: 0x10236BA78
	// [Call #7] RVA: 0x10236BA78
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupSpotSceneComponent.RepeatSingleSpot
	// Flags: [Final|Native|Protected]
	// Offset: 0x104638228
	// Params: [ Num(1) Size(0x8) ]
	void RepeatSingleSpot(struct UItemSpotSceneComponent* Spot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104572998
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104570074
	// [Call #9] RVA: 0x10236BA78
	// [Call #10] RVA: 0x10236BA78
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupSpotSceneComponent.RandomSpotByType
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1046380c4
	// Params: [ Num(3) Size(0x50) ]
	void RandomSpotByType(enum class ESpotType SpotType, struct TArray<struct UItemSpotSceneComponent*>& AllSpots, struct FSpotTypeProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10457253C
	// [Call #8] RVA: 0x102362AFC
	// [Call #9] RVA: 0x10355CC4C
	// [Call #10] RVA: 0x102362AFC
	// [Call #11] RVA: 0x10355CC4C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104572998
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemGroupSpotSceneComponent.RandomSingleSpot
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104637fa8
	// Params: [ Num(2) Size(0x48) ]
	void RandomSingleSpot(struct TArray<struct UItemSpotSceneComponent*>& Spots, struct FSpotTypeProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045726CC
	// [Call #6] RVA: 0x102362AFC
	// [Call #7] RVA: 0x10355CC4C
	// [Call #8] RVA: 0x102362AFC
	// [Call #9] RVA: 0x10355CC4C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10457253C
	// [Call #18] RVA: 0x102362AFC
	// [Call #19] RVA: 0x10355CC4C

	// Object: Function Gameplay.ItemGroupSpotSceneComponent.RandomRepeatGenerateItemCD
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104637ee4
	// Params: [ Num(2) Size(0x2C) ]
	float RandomRepeatGenerateItemCD(struct FSpotGroupProperty& GroupProperty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104572500
	// [Call #4] RVA: 0x10236BA78
	// [Call #5] RVA: 0x10236BA78
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045726CC
	// [Call #12] RVA: 0x102362AFC
	// [Call #13] RVA: 0x10355CC4C
	// [Call #14] RVA: 0x102362AFC
	// [Call #15] RVA: 0x10355CC4C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class Gameplay.SpotSceneComponent
// Size: 0x3C0 (Inherited: 0x3A0)
struct USpotSceneComponent : UItemSceneComponent
{
	enum class ESpotType SpotType; // 0x399(0x1)
	int ID; // 0x39C(0x4)
	int WorldCompositionID; // 0x3A0(0x4)
	float HalfHeight; // 0x3A4(0x4)
	int SpotProbability; // 0x3A8(0x4)
	float LineOffsetZ; // 0x3AC(0x4)
	bool bRepeatGenerateItem; // 0x3B0(0x1)
	bool bIsSpotValid; // 0x3B1(0x1)
	uint8_t Pad_0x3B7[0x9]; // 0x3B7(0x9)


	// Object: Function Gameplay.SpotSceneComponent.SetSpotValid
	// Flags: [Native|Public]
	// Offset: 0x10464e884
	// Params: [ Num(1) Size(0x1) ]
	void SetSpotValid(bool Valid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.SpotSceneComponent.LineTraceSingle
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10464e608
	// Params: [ Num(8) Size(0xC2) ]
	bool LineTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, struct FHitResult& OutHit, bool bIgnoreSelf);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F811FC

	// Object: Function Gameplay.SpotSceneComponent.IsSpotValid
	// Flags: [Native|Public]
	// Offset: 0x10464e5cc
	// Params: [ Num(1) Size(0x1) ]
	bool IsSpotValid();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.SpotSceneComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	// Offset: 0x10464e4e4
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.SpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	// Offset: 0x10464e4a8
	// Params: [ Num(1) Size(0x1) ]
	bool GenerateSpot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.SpotSceneComponent.GenerateActor
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10464e340
	// Params: [ Num(5) Size(0x30) ]
	struct AActor* GenerateActor(struct UObject* ActorClass, struct FVector& ActorLocation, struct FRotator& ActorRotator, uint8_t SpawnActorCollisionHandlingMethod);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102362AB0
};

// Object: Class Gameplay.ItemSpotSceneComponent
// Size: 0x440 (Inherited: 0x3C0)
struct UItemSpotSceneComponent : USpotSceneComponent
{
	int AIGroupID; // 0x3B4(0x4)
	bool bForceSpawn; // 0x3B8(0x1)
	enum class ESpotGroupType SpotGroupType; // 0x3BA(0x1)
	float RepeatGenerateItemCD; // 0x3BC(0x4)
	struct UItemGeneratorComponent* ItemGenerator; // 0x3C0(0x8)
	struct TArray<struct FItemGenerateSpawnClass> AllItems; // 0x3C8(0x10)
	struct UGroupSpotSceneComponent* GroupSpotSceneComponent; // 0x3D8(0x8)
	struct TMap<struct FString, int> CacheItemValeCategory; // 0x3E0(0x50)
	struct TArray<struct TWeakObjectPtr<struct AActor>> CacheItems; // 0x430(0x10)


	// Object: Function Gameplay.ItemSpotSceneComponent.SetSpotProperty
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104638ab4
	// Params: [ Num(6) Size(0x51) ]
	void SetSpotProperty(int CompositionID, enum class ESpotGroupType GroupType, struct UItemGeneratorComponent* Generator, struct FSpotTypeProperty& Property, struct UGroupSpotSceneComponent* Component, bool RepeatGenerateItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104571D2C
	// [Call #14] RVA: 0x102362AFC
	// [Call #15] RVA: 0x102362AFC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C

	// Object: Function Gameplay.ItemSpotSceneComponent.RepeatSpotProperty
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104638a08
	// Params: [ Num(1) Size(0x38) ]
	void RepeatSpotProperty(struct FSpotTypeProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104572A30
	// [Call #4] RVA: 0x102362AFC
	// [Call #5] RVA: 0x102362AFC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemSpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	// Offset: 0x1046389cc
	// Params: [ Num(1) Size(0x1) ]
	bool GenerateSpot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104572A30
	// [Call #4] RVA: 0x102362AFC
	// [Call #5] RVA: 0x102362AFC
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.ItemSpotSceneComponent.GenerateItems
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104638924
	// Params: [ Num(1) Size(0x10) ]
	void GenerateItems(struct TArray<struct FItemGenerateSpawnClass>& AllItemClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10457345C
	// [Call #4] RVA: 0x10236AEE8
	// [Call #5] RVA: 0x10236AEE8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104572A30
	// [Call #10] RVA: 0x102362AFC
	// [Call #11] RVA: 0x102362AFC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemSpotSceneComponent.DoPickUp
	// Flags: [Final|Native|Public]
	// Offset: 0x1046387a8
	// Params: [ Num(2) Size(0x20) ]
	void DoPickUp(struct FString ItemValue, struct FString ItemCategory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x104573BE4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10457345C
	// [Call #24] RVA: 0x10236AEE8
	// [Call #25] RVA: 0x10236AEE8
	// [Call #26] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemSpotSceneComponent.CountCacheItemValeCategory
	// Flags: [Final|Native|Public]
	// Offset: 0x104638774
	// Params: [ Num(1) Size(0x4) ]
	int CountCacheItemValeCategory();
	// [Call #1] RVA: 0x104571BEC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x104573BE4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10457345C
	// [Call #25] RVA: 0x10236AEE8
	// [Call #26] RVA: 0x10236AEE8
	// [Call #27] RVA: 0x106C8459C

	// Object: Function Gameplay.ItemSpotSceneComponent.ClearCacheItems
	// Flags: [Final|Native|Public]
	// Offset: 0x104638760
	// Params: [ Num(0) Size(0x0) ]
	void ClearCacheItems();
	// [Call #1] RVA: 0x104571BEC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x104573BE4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10457345C
	// [Call #25] RVA: 0x10236AEE8
};

// Object: Class Gameplay.UAEHouseActor
// Size: 0x678 (Inherited: 0x580)
struct AUAEHouseActor : AUAENetActor
{
	int iRegionHouse; // 0x580(0x4)
	float WindowHideDistanceSquared; // 0x584(0x4)
	float WindowLoadDistanceSquared; // 0x588(0x4)
	float WindowLoadDistanceSquaredOnVeryLowDevice; // 0x58C(0x4)
	float WindowLoadDistanceSquaredOnServer; // 0x590(0x4)
	uint8_t Pad_0x594[0x4]; // 0x594(0x4)
	struct TArray<struct FUAEWindowRepData> WindowList; // 0x598(0x10)
	struct TMap<int, struct UUAEWindowComponent*> WindowComponents; // 0x5A8(0x50)
	bool bEnableWindow; // 0x5F8(0x1)
	bool bShouldConsiderDistance; // 0x5F9(0x1)
	uint8_t Pad_0x5FA[0x66]; // 0x5FA(0x66)
	bool SerializeDataUse; // 0x660(0x1)
	bool IsStickToTheGround; // 0x661(0x1)
	uint8_t Pad_0x662[0x6]; // 0x662(0x6)
	struct TArray<uint8_t> SerializeData; // 0x668(0x10)


	// Object: Function Gameplay.UAEHouseActor.RecordBreakWindowTlog
	// Flags: [Final|Native|Public]
	// Offset: 0x104666ab4
	// Params: [ Num(1) Size(0x8) ]
	void RecordBreakWindowTlog(struct APlayerController* EventInstigator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B1594
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEHouseActor.ProcessWindowCreateList
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104666aa0
	// Params: [ Num(0) Size(0x0) ]
	void ProcessWindowCreateList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B1594
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEHouseActor.OnRep_WindowList
	// Flags: [Final|Native|Private]
	// Offset: 0x104666a8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_WindowList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B1594
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEHouseActor.ClearWindowList
	// Flags: [Final|Native|Public]
	// Offset: 0x104666a78
	// Params: [ Num(0) Size(0x0) ]
	void ClearWindowList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B1594
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEHouseActor.BroadcastWindowRepDataUpdated
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x104666978
	// Params: [ Num(1) Size(0x50) ]
	void BroadcastWindowRepDataUpdated(struct FUAEWindowRepData InRepData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1034BED54
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B1594
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class Gameplay.UAEGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UUAEGameplayStatics : UGameplayStatics
{

	// Object: Function Gameplay.UAEGameplayStatics.GetGameBridge
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104665fa8
	// Params: [ Num(2) Size(0x10) ]
	struct UGameplayDelegates* GetGameBridge(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045ABBA0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x101FF8D60
	// [Call #8] RVA: 0x10516EACC
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104666678
};

// Object: Class Gameplay.UAEProjectile
// Size: 0x5B0 (Inherited: 0x570)
struct AUAEProjectile : ALuaActor
{
	uint8_t bNetUseDistanceRelevancy : 1; // 0x569(0x1), Mask(0x1)
	int GrenadeItemID; // 0x56C(0x4)
	bool IsServerAlreadyExplodedCpp; // 0x570(0x1)
	struct FVector ProjInitialRelativeOffset; // 0x574(0xC)
	struct FVector ProjStandOffset; // 0x580(0xC)
	struct FVector ProjCrouchOffset; // 0x58C(0xC)
	struct FVector ProjProneOffset; // 0x598(0xC)
	enum class ECharacterPoseType ProjPrevoisOwnerPose; // 0x5A4(0x1)
	uint8_t BitPad_0x5A6_1 : 7; // 0x5A6(0x1)
	uint8_t Pad_0x5A7[0x1]; // 0x5A7(0x1)
	float SpawnSeconds; // 0x5A8(0x4)
	bool bShowGrenadeWarningFlag; // 0x5AC(0x1)
	bool bIsGroundedOnServerCpp; // 0x5AD(0x1)
	uint8_t Pad_0x5AE[0x2]; // 0x5AE(0x2)


	// Object: Function Gameplay.UAEProjectile.WorkAsBuffApplierEvent
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10467bce0
	// Params: [ Num(2) Size(0x18) ]
	void WorkAsBuffApplierEvent(struct FString& BuffName, struct APawn* BuffTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Gameplay.UAEProjectile.TimeoutExplodeMulticast_CPP
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable|NetValidate]
	// Offset: 0x10467bcc4
	// Params: [ Num(0) Size(0x0) ]
	void TimeoutExplodeMulticast_CPP();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEProjectile.TimeoutExplodeMulticast_BPEvent
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467bca8
	// Params: [ Num(0) Size(0x0) ]
	void TimeoutExplodeMulticast_BPEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEProjectile.SetActorInitialRelativeOffset
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x10467bb2c
	// Params: [ Num(5) Size(0x31) ]
	void SetActorInitialRelativeOffset(struct FVector Offset, struct FVector StandOffset, struct FVector CrouchOffset, struct FVector ProneOffset, enum class ECharacterPoseType PrevoisOwnerPose);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEProjectile.ServerNotifyGroundEventOnClient
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ServerNotifyGroundEventOnClient();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEProjectile.OnRep_IsServerAlreadyExplodedCpp
	// Flags: [Final|Native|Public]
	// Offset: 0x10467bb18
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsServerAlreadyExplodedCpp();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEProjectile.OnRep_IsGroundedOnServerCpp
	// Flags: [Final|Native|Public]
	// Offset: 0x10467bb04
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsGroundedOnServerCpp();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEProjectile.OnProjectileStopOnServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467baf0
	// Params: [ Num(0) Size(0x0) ]
	void OnProjectileStopOnServer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEProjectile.OnProjectileStopOnClient
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467badc
	// Params: [ Num(0) Size(0x0) ]
	void OnProjectileStopOnClient();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.UAEProjectile.IsServerAlreadyExplodedCppNotify
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467bac0
	// Params: [ Num(0) Size(0x0) ]
	void IsServerAlreadyExplodedCppNotify();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E38A8

	// Object: Function Gameplay.UAEProjectile.IsOwnerAutomous
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467ba8c
	// Params: [ Num(1) Size(0x1) ]
	bool IsOwnerAutomous();
	// [Call #1] RVA: 0x1045E38FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045E38A8

	// Object: Function Gameplay.UAEProjectile.GlassDetect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10467b9b4
	// Params: [ Num(2) Size(0x18) ]
	void GlassDetect(struct FVector& Start, struct FVector& End);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E3558
	// [Call #6] RVA: 0x1045E38FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Gameplay.UAEProjectile.GetRemainingEffectTime
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10467b978
	// Params: [ Num(1) Size(0x4) ]
	float GetRemainingEffectTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E3558
	// [Call #6] RVA: 0x1045E38FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEProjectile.ChangeGrenadeMarkerState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467b8f4
	// Params: [ Num(1) Size(0x1) ]
	void ChangeGrenadeMarkerState(bool bNewState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E3A38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E3558
	// [Call #9] RVA: 0x1045E38FC

	// Object: Function Gameplay.UAEProjectile.CallExplode
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467b8d8
	// Params: [ Num(0) Size(0x0) ]
	void CallExplode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E3A38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E3558
	// [Call #9] RVA: 0x1045E38FC

	// Object: Function Gameplay.UAEProjectile.BroadcastClientExplode
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable|NetValidate]
	// Offset: 0x10467b8bc
	// Params: [ Num(0) Size(0x0) ]
	void BroadcastClientExplode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E3A38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045E3558
	// [Call #9] RVA: 0x1045E38FC
};

// Object: Class Gameplay.UAEOBState
// Size: 0x540 (Inherited: 0x540)
struct AUAEOBState : APlayerState
{
};

// Object: Class Gameplay.UAEPlayerController
// Size: 0x1530 (Inherited: 0x8E0)
struct AUAEPlayerController : ALuaPlayerController
{
	struct FScriptMulticastDelegate OnPlayerKeyRepDelegate; // 0x8E0(0x10)
	struct FString DSVersion; // 0x8F0(0x10)
	struct FName RepPropertyCategory; // 0x900(0x8)
	struct FName PlayerType; // 0x908(0x8)
	struct FString PlayerName; // 0x910(0x10)
	uint32_t PlayerKey; // 0x920(0x4)
	uint8_t Pad_0x924[0x4]; // 0x924(0x4)
	uint64_t UID; // 0x928(0x8)
	struct FString PlayerOpenID; // 0x930(0x10)
	int TeamID; // 0x940(0x4)
	uint8_t Pad_0x944[0x4]; // 0x944(0x4)
	int64_t IdxInTeam; // 0x948(0x8)
	int Campid; // 0x950(0x4)
	struct FVector CharacterLocation; // 0x954(0xC)
	int RoomMode; // 0x960(0x4)
	uint8_t Pad_0x964[0x4]; // 0x964(0x4)
	struct FWeatherInfo WeatherInfo; // 0x968(0x18)
	int planeAvatarId; // 0x980(0x4)
	int DyeDebugFlag; // 0x984(0x4)
	int PlayerStartID; // 0x988(0x4)
	bool bUsedSimulation; // 0x98C(0x1)
	uint8_t Pad_0x98D[0x3]; // 0x98D(0x3)
	struct FPlayerNetStats NetStats; // 0x990(0x40)
	bool bEnablePlaneBanner; // 0x9D0(0x1)
	uint8_t Pad_0x9D1[0x7]; // 0x9D1(0x7)
	struct FString PlanetailResLink; // 0x9D8(0x10)
	int InPacketLossRate; // 0x9E8(0x4)
	int OutPacketLossRate; // 0x9EC(0x4)
	int ClientNetworkType; // 0x9F0(0x4)
	uint8_t Pad_0x9F4[0x4]; // 0x9F4(0x4)
	struct TArray<struct TWeakObjectPtr<struct AActor>> LastReplicatedActors; // 0x9F8(0x10)
	uint8_t Pad_0xA08[0x10]; // 0xA08(0x10)
	bool bIsForReplay; // 0xA18(0x1)
	bool bIsGlobalObserverForReplay; // 0xA19(0x1)
	uint8_t Pad_0xA1A[0x2]; // 0xA1A(0x2)
	int GameReplayType; // 0xA1C(0x4)
	bool bDisableProcessPlayerInput; // 0xA20(0x1)
	bool bNoAttenuationGlobalVoice; // 0xA21(0x1)
	uint8_t Pad_0xA22[0x6]; // 0xA22(0x6)
	struct FGameModePlayerUpassInfo InitialUpassInfo; // 0xA28(0x38)
	struct TArray<struct FGameModePlayerUpassInfo> InitialUpassInfoList; // 0xA60(0x10)
	struct TArray<struct FPlayerOBInfo> PlayerOBInfoList; // 0xA70(0x10)
	int LobbyShowWeaponID; // 0xA80(0x4)
	bool bIsGM; // 0xA84(0x1)
	uint8_t Pad_0xA85[0x3]; // 0xA85(0x3)
	struct FString Nation; // 0xA88(0x10)
	bool bIsTeammateEscaped; // 0xA98(0x1)
	uint8_t Pad_0xA99[0x7]; // 0xA99(0x7)
	uint8_t DefaultCharacterGender; // 0xAA0(0x1)
	uint8_t Pad_0xAA1[0x3]; // 0xAA1(0x3)
	int DefaultCharacterHeadID; // 0xAA4(0x4)
	struct TArray<struct FGameModePlayerItem> InitialItemList; // 0xAA8(0x10)
	struct TArray<struct FGameModePlayerRolewearInfo> InitialAllWear; // 0xAB8(0x10)
	int RolewearIndex; // 0xAC8(0x4)
	uint8_t Pad_0xACC[0x4]; // 0xACC(0x4)
	struct TArray<int> equip_plating_list; // 0xAD0(0x10)
	struct TArray<struct FGameModePlayerItem> InitialSharedSkin; // 0xAE0(0x10)
	struct FGameModePlayerKnapsackSingleInfo InitialSharedKnapsack; // 0xAF0(0x88)
	bool bSharedSkinOpened; // 0xB78(0x1)
	bool bUsingSharedSkin; // 0xB79(0x1)
	bool bSubscribeBagOpened; // 0xB7A(0x1)
	uint8_t Pad_0xB7B[0x1]; // 0xB7B(0x1)
	int FashionBagStartIndex; // 0xB7C(0x4)
	int VehicleSkinInReady; // 0xB80(0x4)
	bool bSpwanInVehiclePlayerStart; // 0xB84(0x1)
	uint8_t Pad_0xB85[0x3]; // 0xB85(0x3)
	struct TArray<struct FGameModePlayerItem> InitialWeaponAvatarList; // 0xB88(0x10)
	struct FGameModePlayerPetInfo InitialPetInfo; // 0xB98(0x20)
	struct TArray<struct FGameModePlayerPetInfo> AdditionalPetInfo; // 0xBB8(0x10)
	int UsingAdditionalPetIndex; // 0xBC8(0x4)
	uint8_t Pad_0xBCC[0x4]; // 0xBCC(0x4)
	struct TArray<struct FGameModePlayerKnapsackExtInfo> InitialKnapsackExtInfo; // 0xBD0(0x10)
	struct TArray<struct FGameModePlayeWeaponSchemeInfo> InitialWeaponSchemeInfo; // 0xBE0(0x10)
	struct TArray<struct FPlayerEffectItemInfo> InitialEffectItemInfo; // 0xBF0(0x10)
	struct FScriptMulticastDelegate OnInitialWeaponScheme; // 0xC00(0x10)
	struct FScriptMulticastDelegate OnInitialEffectItem; // 0xC10(0x10)
	struct FScriptMulticastDelegate OnLongTimeNoReceived; // 0xC20(0x10)
	int CurWeaponSchemeIndex; // 0xC30(0x4)
	int PveLevel; // 0xC34(0x4)
	struct TArray<int> InitialCharSkillList; // 0xC38(0x10)
	struct TArray<struct FGameModePlayerItem> InitialVehicleAvatarList; // 0xC48(0x10)
	struct TArray<struct FGameModePlayerItems> InitialVehicleAvatarSkinList; // 0xC58(0x10)
	int nVehicleSwitchEffectId; // 0xC68(0x4)
	int ShowVehicleSkin; // 0xC6C(0x4)
	struct TArray<struct FGameModePlayerItem> InitialBackPackPendantList; // 0xC70(0x10)
	struct TArray<struct FVehicleAvatarData> InitialVehicleAdvanceAvatarList; // 0xC80(0x10)
	struct TArray<struct FGameModePlayerItem> InitialVehicleMusicList; // 0xC90(0x10)
	struct FGameModePlayerConsumableAvatar InitialConsumableAvatar; // 0xCA0(0x10)
	struct FGameModePlayerEquipmentAvatar InitialEquipmentAvatar; // 0xCB0(0x30)
	struct TMap<int, int> WeaponAvatarItemList; // 0xCE0(0x50)
	uint8_t Pad_0xD30[0xA0]; // 0xD30(0xA0)
	struct TMap<int, int> GrenadeAvatarItemList; // 0xDD0(0x50)
	struct TArray<struct FGameModeWeaponAvatarData> WeaponAvatarDataList; // 0xE20(0x10)
	struct TMap<int, int> VehicleAvatarList; // 0xE30(0x50)
	struct TMap<int, struct FVehicleAvatarData> VehicleAdvanceAvatarList; // 0xE80(0x50)
	struct TMap<int, struct FVehicleAvatarSkinList> VehicleAvatarSkinList; // 0xED0(0x50)
	struct TArray<int> VehicleMusicList; // 0xF20(0x10)
	struct TArray<int> DefaultVehicleMusic; // 0xF30(0x10)
	struct TArray<struct FGameModePlayerExpressionItem> InitialExpressionItemList; // 0xF40(0x10)
	struct TArray<struct FGameModeWeaponDIYPlanData> InitialWeaponDIYPlanData; // 0xF50(0x10)
	struct TMap<int, int> WeaponDIYPlanDataMap; // 0xF60(0x50)
	struct TMap<int, int> InitialWeaponPendantList; // 0xFB0(0x50)
	struct TArray<struct FGameModePlayerTaskData> InitialTaskDataList; // 0x1000(0x10)
	struct TArray<struct FSpecialPickItem> InitialSpecialPickItemList; // 0x1010(0x10)
	struct TArray<struct FDailyTaskStoreInfo> DailyTaskStoreList; // 0x1020(0x10)
	uint32_t TaskSyncToDsTs; // 0x1030(0x4)
	uint8_t Pad_0x1034[0x4]; // 0x1034(0x4)
	struct FScriptMulticastDelegate OnPlayerGotoSpectatingDelegate; // 0x1038(0x10)
	uint8_t Pad_0x1048[0x10]; // 0x1048(0x10)
	struct FScriptMulticastDelegate OnReceiveUIMessage; // 0x1058(0x10)
	int64_t LastGameResultTime; // 0x1068(0x8)
	bool bRoomCanKickPlayer; // 0x1070(0x1)
	bool bCanDownloadInBattle; // 0x1071(0x1)
	uint8_t Pad_0x1072[0x6]; // 0x1072(0x6)
	struct FString IpCountryStr; // 0x1078(0x10)
	bool bRoomOwner; // 0x1088(0x1)
	bool bOpenChangeWearing; // 0x1089(0x1)
	uint8_t Pad_0x108A[0x2]; // 0x108A(0x2)
	uint32_t ObserverFlags; // 0x108C(0x4)
	bool bIsSpectating; // 0x1090(0x1)
	uint8_t Pad_0x1091[0x3]; // 0x1091(0x3)
	struct FLobbyWatchInfo LobbyWatchInfo; // 0x1094(0x8)
	int HawkEyeSpectateMaxMatchCount; // 0x109C(0x4)
	int HawkEyeSpectateUsedMatchCount; // 0x10A0(0x4)
	bool bIsWatchEnd; // 0x10A4(0x1)
	uint8_t Pad_0x10A5[0x3]; // 0x10A5(0x3)
	float UpdateOBCircleCounter; // 0x10A8(0x4)
	float UpdateOBCircleInterval; // 0x10AC(0x4)
	bool bAllowAutoSelectTeamMate; // 0x10B0(0x1)
	bool bWaitRetryGotoSpectating; // 0x10B1(0x1)
	uint8_t Pad_0x10B2[0x6]; // 0x10B2(0x6)
	struct TArray<struct FString> FriendObservers; // 0x10B8(0x10)
	uint8_t Pad_0x10C8[0x1]; // 0x10C8(0x1)
	bool bCanLedgeGrab; // 0x10C9(0x1)
	uint8_t Pad_0x10CA[0x6]; // 0x10CA(0x6)
	bool bIsSpectatingEnemy; // 0x10D0(0x1)
	uint8_t Pad_0x10D1[0x5F]; // 0x10D1(0x5F)
	struct TWeakObjectPtr<struct UUAEUserWidget> InGameUIRoot; // 0x1130(0x8)
	struct TArray<struct FSoftClassPath> LevelUpdateNetActorClassPaths; // 0x1138(0x10)
	struct TArray<struct AActor*> LevelUpdateNetActorClassList; // 0x1148(0x10)
	uint8_t Pad_0x1158[0x53]; // 0x1158(0x53)
	bool bExited; // 0x11AB(0x1)
	bool bReconnected; // 0x11AC(0x1)
	bool bReconnecting; // 0x11AD(0x1)
	uint8_t Pad_0x11AE[0x2]; // 0x11AE(0x2)
	float ReconnectTimestamp; // 0x11B0(0x4)
	uint8_t Pad_0x11B4[0xC]; // 0x11B4(0xC)
	struct FScriptMulticastDelegate PlayerControllerLostDelegate; // 0x11C0(0x10)
	struct FScriptMulticastDelegate SyncDailyTaskInfoDelegate; // 0x11D0(0x10)
	struct FScriptMulticastDelegate PlayerControllerRecoveredDelegate; // 0x11E0(0x10)
	struct FScriptMulticastDelegate OnPlayerControllerReconnectStarted; // 0x11F0(0x10)
	struct FScriptMulticastDelegate PlayerControllerReconnectedDelegate; // 0x1200(0x10)
	struct FScriptMulticastDelegate PlayerControllerAboutToRespawnDelegate; // 0x1210(0x10)
	struct FScriptMulticastDelegate PlayerControllerRespawnedDelegate; // 0x1220(0x10)
	struct FScriptMulticastDelegate PlayerControllerAboutToExitDelegate; // 0x1230(0x10)
	struct FScriptMulticastDelegate OnPlayerQuitSpectatingForClient; // 0x1240(0x10)
	struct FScriptMulticastDelegate OnPlayerControllerBattleBeginPlay; // 0x1250(0x10)
	struct FScriptMulticastDelegate OnInitGameUI; // 0x1260(0x10)
	uint8_t Pad_0x1270[0x10]; // 0x1270(0x10)
	bool bCanWatchEnemyInRoomMode; // 0x1280(0x1)
	uint8_t Pad_0x1281[0x107]; // 0x1281(0x107)
	struct TArray<struct UObject*> SecurityObjs; // 0x1388(0x10)
	bool IsDelayNotifyEnterBattleUntilLevelLoad; // 0x1398(0x1)
	uint8_t Pad_0x1399[0x3]; // 0x1399(0x3)
	float NotifyTimeOut; // 0x139C(0x4)
	float DelayCloseLoadingTime; // 0x13A0(0x4)
	uint8_t Pad_0x13A4[0x4]; // 0x13A4(0x4)
	struct FString NeedLoadLevelName; // 0x13A8(0x10)
	struct FString NeedLoadedLevelFullName; // 0x13B8(0x10)
	bool IsTickHouse; // 0x13C8(0x1)
	uint8_t Pad_0x13C9[0xF]; // 0x13C9(0xF)
	int AntiDataCD; // 0x13D8(0x4)
	int ModeID; // 0x13DC(0x4)
	bool bOpenReconnectUseCharViewPoint; // 0x13E0(0x1)
	uint8_t Pad_0x13E1[0xCF]; // 0x13E1(0xCF)
	float ClientToDSFlowLimitTime; // 0x14B0(0x4)
	float ClientToDSFlowLimit; // 0x14B4(0x4)
	uint8_t Pad_0x14B8[0x20]; // 0x14B8(0x20)
	struct FString UsingNetObjectPathNameMappingCSV; // 0x14D8(0x10)
	struct FString UsingOodleNetworkDicPath; // 0x14E8(0x10)
	uint8_t Pad_0x14F8[0x20]; // 0x14F8(0x20)
	struct ANetworkReportActor* NetworkReportActor; // 0x1518(0x8)
	uint8_t Pad_0x1520[0x10]; // 0x1520(0x10)


	// Object: Function Gameplay.UAEPlayerController.UseingWeaponScheme
	// Flags: [Final|Native|Public]
	// Offset: 0x104675164
	// Params: [ Num(1) Size(0x1) ]
	bool UseingWeaponScheme();
	// [Call #1] RVA: 0x1045BEAB0
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEPlayerController.TestShowLongTimeNoOperation
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104675124
	// Params: [ Num(0) Size(0x0) ]
	void TestShowLongTimeNoOperation();
	// [Call #1] RVA: 0x1045BEAB0
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.UAEPlayerController.TestCastUIMsgWithPara
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104674ff8
	// Params: [ Num(3) Size(0x24) ]
	void TestCastUIMsgWithPara(struct FString strMsg, struct FString module, int TestID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045BEF50
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1045BEAB0
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Gameplay.UAEPlayerController.SyncDailyTaskStoreInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104674f14
	// Params: [ Num(1) Size(0x10) ]
	void SyncDailyTaskStoreInfo(struct TArray<struct FDailyTaskStoreInfo> NewDailyTaskStoreList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1031DF9B4
	// [Call #4] RVA: 0x1045BEDA8
	// [Call #5] RVA: 0x1025A217C
	// [Call #6] RVA: 0x1025A217C
	// [Call #7] RVA: 0x1025A217C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x1025A217C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1045BEF50
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.SetUsedSimulationCVar
	// Flags: [Final|Native|Public]
	// Offset: 0x104674e90
	// Params: [ Num(1) Size(0x1) ]
	void SetUsedSimulationCVar(bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C48A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1031DF9B4
	// [Call #7] RVA: 0x1045BEDA8
	// [Call #8] RVA: 0x1025A217C
	// [Call #9] RVA: 0x1025A217C
	// [Call #10] RVA: 0x1025A217C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x1025A217C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1045BEF50
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.SetTargetMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104674dcc
	// Params: [ Num(2) Size(0x18) ]
	void SetTargetMsgReceiveDelegate(struct UGameInstance* InGameInstance, DelegateProperty InDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C4D2C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045C48A8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1031DF9B4
	// [Call #13] RVA: 0x1045BEDA8
	// [Call #14] RVA: 0x1025A217C
	// [Call #15] RVA: 0x1025A217C
	// [Call #16] RVA: 0x1025A217C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x1025A217C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.SetPanels
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104674d1c
	// Params: [ Num(1) Size(0x10) ]
	void SetPanels(struct TArray<struct UUAEUserWidget*>& panels);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103307444
	// [Call #4] RVA: 0x103307444
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD9E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045C4D2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C48A8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.SetIsInPetSpectator
	// Flags: [Final|Native|Public]
	// Offset: 0x104674c98
	// Params: [ Num(1) Size(0x1) ]
	void SetIsInPetSpectator(bool inIsInPetSpectator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045BE8E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x103307444
	// [Call #7] RVA: 0x103307444
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD9E48
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C4D2C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.SetDSMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104674c10
	// Params: [ Num(1) Size(0x10) ]
	void SetDSMsgReceiveDelegate(DelegateProperty InDelegate);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045C4D10
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045BE8E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x103307444
	// [Call #11] RVA: 0x103307444
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FD9E48
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.SetClientMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104674b4c
	// Params: [ Num(2) Size(0x18) ]
	void SetClientMsgReceiveDelegate(struct UGameInstance* InGameInstance, DelegateProperty InDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C4C94
	// [Call #7] RVA: 0x101FD9E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045C4D10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BE8E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ServerUpdateLevelVisibility
	// Flags: [Final|Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104674a8c
	// Params: [ Num(2) Size(0x9) ]
	void ServerUpdateLevelVisibility(struct FName PackageName, bool bIsVisible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C5BE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD9E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045C4C94
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045C4D10
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ServerSetVoiceId
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	// Offset: 0x104674a08
	// Params: [ Num(1) Size(0x4) ]
	void ServerSetVoiceId(int VoiceID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C5BE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD9E48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C4C94
	// [Call #14] RVA: 0x101FD9E48
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ServerRepListDispatch
	// Flags: [Final|Native|Public]
	// Offset: 0x10467498c
	// Params: [ Num(1) Size(0x8) ]
	void ServerRepListDispatch(struct UObject* InObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C6D58
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045C5BE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ServerRepComponentsDispatch
	// Flags: [Final|Native|Public]
	// Offset: 0x104674910
	// Params: [ Num(1) Size(0x8) ]
	void ServerRepComponentsDispatch(struct UObject* InObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C7ED0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C6D58
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C5BE0

	// Object: Function Gameplay.UAEPlayerController.ServerKickSelf
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1046748f4
	// Params: [ Num(0) Size(0x0) ]
	void ServerKickSelf();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C7ED0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C6D58
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C5BE0

	// Object: Function Gameplay.UAEPlayerController.ServerGotoSpectating
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104674870
	// Params: [ Num(1) Size(0x8) ]
	void ServerGotoSpectating(struct APawn* ViewTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C7ED0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C6D58
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ServerExitGame
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104674854
	// Params: [ Num(0) Size(0x0) ]
	void ServerExitGame();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C7ED0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C6D58
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ServerAcknowledgeReconnection_1
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1046747d0
	// Params: [ Num(1) Size(0x4) ]
	void ServerAcknowledgeReconnection_1(uint32_t Token);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C7ED0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045C6D58

	// Object: Function Gameplay.UAEPlayerController.SendNetObjectPathNameMappingHashToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10467474c
	// Params: [ Num(1) Size(0x4) ]
	void SendNetObjectPathNameMappingHashToServer(uint32_t VersionHash);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045C7ED0

	// Object: Function Gameplay.UAEPlayerController.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104674614
	// Params: [ Num(3) Size(0x19) ]
	void SendLuaDSToClient(int ID, struct TArray<uint8_t>& Content, bool IsUnreliable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C5260
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.SendLuaClientToDS
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046744dc
	// Params: [ Num(3) Size(0x19) ]
	void SendLuaClientToDS(int ID, struct TArray<uint8_t>& Content, bool IsUnreliable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C4F58
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045C5260
	// [Call #18] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAEPlayerController.RPC_Server_SyncClientNetInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1046743e4
	// Params: [ Num(3) Size(0xC) ]
	void RPC_Server_SyncClientNetInfo(int InLoss, int OutLoss, int InNetworkType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C4F58
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.RPC_Server_ReportClientNetInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10467418c
	// Params: [ Num(9) Size(0x24) ]
	void RPC_Server_ReportClientNetInfo(int AvgPing, int MaxPing, int MinPing, int LostPackRate, int AvgNoOutlier, int StdNoOutlier, int NumNoOutlier, int InLoss, int OutLoss);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.RPC_LuaDSToClient_NR
	// Flags: [Net|Native|Event|Public|NetClient|NetValidate]
	// Offset: 0x1046740b0
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaDSToClient_NR(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104673fd4
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaDSToClient(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.RPC_LuaClientToDS_NR
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	// Offset: 0x104673ef8
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaClientToDS_NR(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.RPC_LuaClientToDS
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104673e1c
	// Params: [ Num(2) Size(0x18) ]
	void RPC_LuaClientToDS(int ID, struct TArray<uint8_t> Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.Respawn
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104673e00
	// Params: [ Num(0) Size(0x0) ]
	void Respawn();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ResetUsedSimulationCVar
	// Flags: [Final|Native|Public]
	// Offset: 0x104673dec
	// Params: [ Num(0) Size(0x0) ]
	void ResetUsedSimulationCVar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ReleaseInGameUI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104673dd0
	// Params: [ Num(0) Size(0x0) ]
	void ReleaseInGameUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ReceivePostLoginInit
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceivePostLoginInit();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEPlayerController.PrintStatistics
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104673dbc
	// Params: [ Num(0) Size(0x0) ]
	void PrintStatistics();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.PlayerStartIDReceived
	// Flags: [Final|Native|Protected]
	// Offset: 0x104673da8
	// Params: [ Num(0) Size(0x0) ]
	void PlayerStartIDReceived();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.OnRep_WeaponAvatarDataList
	// Flags: [Native|Public]
	// Offset: 0x104673d8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_WeaponAvatarDataList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.OnRep_UsingOodleNetworkDicPath
	// Flags: [Final|Native|Public]
	// Offset: 0x104673d78
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UsingOodleNetworkDicPath();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAEPlayerController.OnRep_UsingNetObjectPathNameMappingCSV
	// Flags: [Final|Native|Public]
	// Offset: 0x104673d64
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UsingNetObjectPathNameMappingCSV();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAEPlayerController.OnRep_UsedSimulation
	// Flags: [Native|Public]
	// Offset: 0x104673d48
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_UsedSimulation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_PveLevel
	// Flags: [Native|Public]
	// Offset: 0x104673d2c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PveLevel();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_PlayerOBInfoList
	// Flags: [Final|Native|Public]
	// Offset: 0x104673d18
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerOBInfoList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.OnRep_PlayerKey
	// Flags: [Final|Native|Public]
	// Offset: 0x104673d04
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerKey();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_LobbyWatchInfo
	// Flags: [Native|Public]
	// Offset: 0x104673ce8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LobbyWatchInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.OnRep_LastGameResultTime
	// Flags: [Native|Public]
	// Offset: 0x104673ccc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LastGameResultTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.OnRep_IsSpectatingEnemy
	// Flags: [Native|Protected]
	// Offset: 0x104673cb0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsSpectatingEnemy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.OnRep_IsSpectating
	// Flags: [Native|Public]
	// Offset: 0x104673c94
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsSpectating();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAEPlayerController.OnRep_IsObserver
	// Flags: [Native|Public]
	// Offset: 0x104673c78
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsObserver();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_InitialWeaponSchemeInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104673c64
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_InitialWeaponSchemeInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_InitialEquipmentAvatar
	// Flags: [Native|Public]
	// Offset: 0x104673c48
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_InitialEquipmentAvatar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.OnRep_InitialEffectItemInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x104673c34
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_InitialEffectItemInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.OnRep_InitialConsumableAvatar
	// Flags: [Native|Public]
	// Offset: 0x104673c18
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_InitialConsumableAvatar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.OnRep_FriendObservers
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104673bfc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_FriendObservers();
	// [Call #1] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.OnRep_CurWeaponSchemeIndex
	// Flags: [Final|Native|Public]
	// Offset: 0x104673be8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CurWeaponSchemeIndex();

	// Object: Function Gameplay.UAEPlayerController.OnRep_bRoomOwner
	// Flags: [Native|Public]
	// Offset: 0x104673bcc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_bRoomOwner();

	// Object: DelegateFunction Gameplay.UAEPlayerController.OnPlayerKeyRepDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnPlayerKeyRepDelegate__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEPlayerController.OnNetObjectPathNameMappingTableAsyncLoad
	// Flags: [Final|Native|Public]
	// Offset: 0x104673bb8
	// Params: [ Num(0) Size(0x0) ]
	void OnNetObjectPathNameMappingTableAsyncLoad();

	// Object: Function Gameplay.UAEPlayerController.OnMemberVoice
	// Flags: [Native|Public]
	// Offset: 0x104673aa0
	// Params: [ Num(3) Size(0x18) ]
	void OnMemberVoice(int Member, int status, struct FString UserInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.NotifyEnterBattle
	// Flags: [Native|Public]
	// Offset: 0x104673a84
	// Params: [ Num(0) Size(0x0) ]
	void NotifyEnterBattle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.LuaDSToClient_Implementation
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046739a0
	// Params: [ Num(2) Size(0x18) ]
	void LuaDSToClient_Implementation(int ID, struct TArray<uint8_t>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C5278
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.LuaClientToDS_Implementation
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046738bc
	// Params: [ Num(2) Size(0x18) ]
	void LuaClientToDS_Implementation(int ID, struct TArray<uint8_t>& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C5048
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C5278
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.KickSelf
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x1046738a8
	// Params: [ Num(0) Size(0x0) ]
	void KickSelf();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C5048
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045C5278
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.IsTeammateSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673874
	// Params: [ Num(1) Size(0x1) ]
	bool IsTeammateSpectator();
	// [Call #1] RVA: 0x1045BE8A4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C5048
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C5278
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.IsSpectatorOrDemoPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673840
	// Params: [ Num(1) Size(0x1) ]
	bool IsSpectatorOrDemoPlayer();
	// [Call #1] RVA: 0x1045B1648
	// [Call #2] RVA: 0x1045BE8A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C5048
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045C5278
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.IsSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10467380c
	// Params: [ Num(1) Size(0x1) ]
	bool IsSpectator();
	// [Call #1] RVA: 0x1045B210C
	// [Call #2] RVA: 0x1045B1648
	// [Call #3] RVA: 0x1045BE8A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C5048
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045C5278
	// [Call #17] RVA: 0x101F8BA74

	// Object: Function Gameplay.UAEPlayerController.IsRoomMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1046737e8
	// Params: [ Num(1) Size(0x1) ]
	bool IsRoomMode();
	// [Call #1] RVA: 0x1045B210C
	// [Call #2] RVA: 0x1045B1648
	// [Call #3] RVA: 0x1045BE8A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C5048
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.IsPureSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046737b4
	// Params: [ Num(1) Size(0x1) ]
	bool IsPureSpectator();
	// [Call #1] RVA: 0x1045AABFC
	// [Call #2] RVA: 0x1045B210C
	// [Call #3] RVA: 0x1045B1648
	// [Call #4] RVA: 0x1045BE8A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045C5048
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.IsObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673780
	// Params: [ Num(1) Size(0x1) ]
	bool IsObserver();
	// [Call #1] RVA: 0x10459A554
	// [Call #2] RVA: 0x1045AABFC
	// [Call #3] RVA: 0x1045B210C
	// [Call #4] RVA: 0x1045B1648
	// [Call #5] RVA: 0x1045BE8A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045C5048
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.IsInSpectatingEnemy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10467374c
	// Params: [ Num(1) Size(0x1) ]
	bool IsInSpectatingEnemy();
	// [Call #1] RVA: 0x1045BE910
	// [Call #2] RVA: 0x10459A554
	// [Call #3] RVA: 0x1045AABFC
	// [Call #4] RVA: 0x1045B210C
	// [Call #5] RVA: 0x1045B1648
	// [Call #6] RVA: 0x1045BE8A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045C5048
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.IsInSpectating
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673718
	// Params: [ Num(1) Size(0x1) ]
	bool IsInSpectating();
	// [Call #1] RVA: 0x1045BBDE0
	// [Call #2] RVA: 0x1045BE910
	// [Call #3] RVA: 0x10459A554
	// [Call #4] RVA: 0x1045AABFC
	// [Call #5] RVA: 0x1045B210C
	// [Call #6] RVA: 0x1045B1648
	// [Call #7] RVA: 0x1045BE8A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.IsInPetSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1046736e4
	// Params: [ Num(1) Size(0x1) ]
	bool IsInPetSpectator();
	// [Call #1] RVA: 0x1045BE8D4
	// [Call #2] RVA: 0x1045BBDE0
	// [Call #3] RVA: 0x1045BE910
	// [Call #4] RVA: 0x10459A554
	// [Call #5] RVA: 0x1045AABFC
	// [Call #6] RVA: 0x1045B210C
	// [Call #7] RVA: 0x1045B1648
	// [Call #8] RVA: 0x1045BE8A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.IsHawkEyeSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046736b0
	// Params: [ Num(1) Size(0x1) ]
	bool IsHawkEyeSpectator();
	// [Call #1] RVA: 0x1045BE7BC
	// [Call #2] RVA: 0x1045BE8D4
	// [Call #3] RVA: 0x1045BBDE0
	// [Call #4] RVA: 0x1045BE910
	// [Call #5] RVA: 0x10459A554
	// [Call #6] RVA: 0x1045AABFC
	// [Call #7] RVA: 0x1045B210C
	// [Call #8] RVA: 0x1045B1648
	// [Call #9] RVA: 0x1045BE8A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.IsFriendOrEnemySpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10467367c
	// Params: [ Num(1) Size(0x1) ]
	bool IsFriendOrEnemySpectator();
	// [Call #1] RVA: 0x1045BE8EC
	// [Call #2] RVA: 0x1045BE7BC
	// [Call #3] RVA: 0x1045BE8D4
	// [Call #4] RVA: 0x1045BBDE0
	// [Call #5] RVA: 0x1045BE910
	// [Call #6] RVA: 0x10459A554
	// [Call #7] RVA: 0x1045AABFC
	// [Call #8] RVA: 0x1045B210C
	// [Call #9] RVA: 0x1045B1648
	// [Call #10] RVA: 0x1045BE8A4

	// Object: Function Gameplay.UAEPlayerController.IsFriendObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673648
	// Params: [ Num(1) Size(0x1) ]
	bool IsFriendObserver();
	// [Call #1] RVA: 0x10459A564
	// [Call #2] RVA: 0x1045BE8EC
	// [Call #3] RVA: 0x1045BE7BC
	// [Call #4] RVA: 0x1045BE8D4
	// [Call #5] RVA: 0x1045BBDE0
	// [Call #6] RVA: 0x1045BE910
	// [Call #7] RVA: 0x10459A554
	// [Call #8] RVA: 0x1045AABFC
	// [Call #9] RVA: 0x1045B210C
	// [Call #10] RVA: 0x1045B1648
	// [Call #11] RVA: 0x1045BE8A4

	// Object: Function Gameplay.UAEPlayerController.IsFriendNotHawkEyeObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673614
	// Params: [ Num(1) Size(0x1) ]
	bool IsFriendNotHawkEyeObserver();
	// [Call #1] RVA: 0x1045BE9B8
	// [Call #2] RVA: 0x10459A564
	// [Call #3] RVA: 0x1045BE8EC
	// [Call #4] RVA: 0x1045BE7BC
	// [Call #5] RVA: 0x1045BE8D4
	// [Call #6] RVA: 0x1045BBDE0
	// [Call #7] RVA: 0x1045BE910
	// [Call #8] RVA: 0x10459A554
	// [Call #9] RVA: 0x1045AABFC
	// [Call #10] RVA: 0x1045B210C
	// [Call #11] RVA: 0x1045B1648

	// Object: Function Gameplay.UAEPlayerController.IsExited
	// Flags: [Final|Native|Public]
	// Offset: 0x1046735e0
	// Params: [ Num(1) Size(0x1) ]
	bool IsExited();
	// [Call #1] RVA: 0x1045C4A48
	// [Call #2] RVA: 0x1045BE9B8
	// [Call #3] RVA: 0x10459A564
	// [Call #4] RVA: 0x1045BE8EC
	// [Call #5] RVA: 0x1045BE7BC
	// [Call #6] RVA: 0x1045BE8D4
	// [Call #7] RVA: 0x1045BBDE0
	// [Call #8] RVA: 0x1045BE910
	// [Call #9] RVA: 0x10459A554
	// [Call #10] RVA: 0x1045AABFC
	// [Call #11] RVA: 0x1045B210C

	// Object: Function Gameplay.UAEPlayerController.IsDemoRecSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1046735ac
	// Params: [ Num(1) Size(0x1) ]
	bool IsDemoRecSpectator();
	// [Call #1] RVA: 0x1045BE91C
	// [Call #2] RVA: 0x1045C4A48
	// [Call #3] RVA: 0x1045BE9B8
	// [Call #4] RVA: 0x10459A564
	// [Call #5] RVA: 0x1045BE8EC
	// [Call #6] RVA: 0x1045BE7BC
	// [Call #7] RVA: 0x1045BE8D4
	// [Call #8] RVA: 0x1045BBDE0
	// [Call #9] RVA: 0x1045BE910
	// [Call #10] RVA: 0x10459A554
	// [Call #11] RVA: 0x1045AABFC

	// Object: Function Gameplay.UAEPlayerController.IsDemoPlaySpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673578
	// Params: [ Num(1) Size(0x1) ]
	bool IsDemoPlaySpectator();
	// [Call #1] RVA: 0x1045BE92C
	// [Call #2] RVA: 0x1045BE91C
	// [Call #3] RVA: 0x1045C4A48
	// [Call #4] RVA: 0x1045BE9B8
	// [Call #5] RVA: 0x10459A564
	// [Call #6] RVA: 0x1045BE8EC
	// [Call #7] RVA: 0x1045BE7BC
	// [Call #8] RVA: 0x1045BE8D4
	// [Call #9] RVA: 0x1045BBDE0
	// [Call #10] RVA: 0x1045BE910
	// [Call #11] RVA: 0x10459A554

	// Object: Function Gameplay.UAEPlayerController.IsDemoPlayGlobalObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673544
	// Params: [ Num(1) Size(0x1) ]
	bool IsDemoPlayGlobalObserver();
	// [Call #1] RVA: 0x1045BE934
	// [Call #2] RVA: 0x1045BE92C
	// [Call #3] RVA: 0x1045BE91C
	// [Call #4] RVA: 0x1045C4A48
	// [Call #5] RVA: 0x1045BE9B8
	// [Call #6] RVA: 0x10459A564
	// [Call #7] RVA: 0x1045BE8EC
	// [Call #8] RVA: 0x1045BE7BC
	// [Call #9] RVA: 0x1045BE8D4
	// [Call #10] RVA: 0x1045BBDE0
	// [Call #11] RVA: 0x1045BE910

	// Object: Function Gameplay.UAEPlayerController.IsDeathSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673510
	// Params: [ Num(1) Size(0x1) ]
	bool IsDeathSpectator();
	// [Call #1] RVA: 0x1045BE78C
	// [Call #2] RVA: 0x1045BE934
	// [Call #3] RVA: 0x1045BE92C
	// [Call #4] RVA: 0x1045BE91C
	// [Call #5] RVA: 0x1045C4A48
	// [Call #6] RVA: 0x1045BE9B8
	// [Call #7] RVA: 0x10459A564
	// [Call #8] RVA: 0x1045BE8EC
	// [Call #9] RVA: 0x1045BE7BC
	// [Call #10] RVA: 0x1045BE8D4
	// [Call #11] RVA: 0x1045BBDE0

	// Object: Function Gameplay.UAEPlayerController.InitWithPlayerParams
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10467345c
	// Params: [ Num(1) Size(0x3F8) ]
	void InitWithPlayerParams(struct FGameModePlayerParams& Params);
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48
	// [Call #13] RVA: 0x1045BE9B8
	// [Call #14] RVA: 0x10459A564
	// [Call #15] RVA: 0x1045BE8EC

	// Object: Function Gameplay.UAEPlayerController.InitWeaponAvatarItems
	// Flags: [Native|Public]
	// Offset: 0x104673440
	// Params: [ Num(0) Size(0x0) ]
	void InitWeaponAvatarItems();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48
	// [Call #13] RVA: 0x1045BE9B8
	// [Call #14] RVA: 0x10459A564

	// Object: Function Gameplay.UAEPlayerController.InitVehicleMusicList
	// Flags: [Native|Public]
	// Offset: 0x104673424
	// Params: [ Num(0) Size(0x0) ]
	void InitVehicleMusicList();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48
	// [Call #13] RVA: 0x1045BE9B8
	// [Call #14] RVA: 0x10459A564

	// Object: Function Gameplay.UAEPlayerController.InitVehicleAvatarSkinList
	// Flags: [Native|Public]
	// Offset: 0x104673408
	// Params: [ Num(0) Size(0x0) ]
	void InitVehicleAvatarSkinList();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48
	// [Call #13] RVA: 0x1045BE9B8

	// Object: Function Gameplay.UAEPlayerController.InitVehicleAvatarList
	// Flags: [Native|Public]
	// Offset: 0x1046733ec
	// Params: [ Num(0) Size(0x0) ]
	void InitVehicleAvatarList();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48
	// [Call #13] RVA: 0x1045BE9B8

	// Object: Function Gameplay.UAEPlayerController.InitVehicleAdvanceAvatarList
	// Flags: [Native|Public]
	// Offset: 0x1046733d0
	// Params: [ Num(0) Size(0x0) ]
	void InitVehicleAdvanceAvatarList();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48

	// Object: Function Gameplay.UAEPlayerController.InitIngameUI
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1046733b4
	// Params: [ Num(0) Size(0x0) ]
	void InitIngameUI();
	// [Call #1] RVA: 0x103221724
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BDC5C
	// [Call #5] RVA: 0x1025A2064
	// [Call #6] RVA: 0x1025A2064
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045BE78C
	// [Call #9] RVA: 0x1045BE934
	// [Call #10] RVA: 0x1045BE92C
	// [Call #11] RVA: 0x1045BE91C
	// [Call #12] RVA: 0x1045C4A48

	// Object: Function Gameplay.UAEPlayerController.InitGrenadeAvatarList
	// Flags: [Native|Public]
	// Offset: 0x104673328
	// Params: [ Num(1) Size(0x1) ]
	void InitGrenadeAvatarList(bool ReInitial);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103221724
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045BDC5C
	// [Call #7] RVA: 0x1025A2064
	// [Call #8] RVA: 0x1025A2064
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x1045BE78C
	// [Call #11] RVA: 0x1045BE934

	// Object: Function Gameplay.UAEPlayerController.HasAnySpectatorReplayFlag
	// Flags: [Native|Public|Const]
	// Offset: 0x104673294
	// Params: [ Num(2) Size(0x5) ]
	bool HasAnySpectatorReplayFlag(uint32_t InFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x103221724
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045BDC5C
	// [Call #9] RVA: 0x1025A2064

	// Object: Function Gameplay.UAEPlayerController.GotoSpectating
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104673200
	// Params: [ Num(2) Size(0x8) ]
	int GotoSpectating(int PlayerID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.GetWeaponPandentReflect
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104673128
	// Params: [ Num(3) Size(0x9) ]
	bool GetWeaponPandentReflect(int wraponID, int& pendantID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045BE954
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.GetWeaponAvatarItemId
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104673094
	// Params: [ Num(2) Size(0x8) ]
	int GetWeaponAvatarItemId(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045BE954
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.GetVisibleLevelsLoadedName
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104672fec
	// Params: [ Num(1) Size(0x10) ]
	void GetVisibleLevelsLoadedName(struct TArray<struct FString>& VisibleLevels);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C00B8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BE954
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.GetLobbyWatchedPlayerKeyAsString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104672f88
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLobbyWatchedPlayerKeyAsString();
	// [Call #1] RVA: 0x1045BE7C8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C00B8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.GetEffectItemBySlot
	// Flags: [Final|Native|Public]
	// Offset: 0x104672ef8
	// Params: [ Num(2) Size(0x10) ]
	struct FPlayerEffectItemInfo GetEffectItemBySlot(uint8_t SlotIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045BEB5C
	// [Call #4] RVA: 0x1045BE7C8
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045C00B8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.GetDailyTaskStoreInfoByTaskId
	// Flags: [Final|Native|Public]
	// Offset: 0x104672e68
	// Params: [ Num(2) Size(0x10) ]
	struct FDailyTaskStoreInfo GetDailyTaskStoreInfoByTaskId(int TaskID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045BEE4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045BEB5C
	// [Call #7] RVA: 0x1045BE7C8
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C00B8
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.GetCurrentWeaponSchemeMainSlotItemId
	// Flags: [Final|Native|Public]
	// Offset: 0x104672e34
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentWeaponSchemeMainSlotItemId();
	// [Call #1] RVA: 0x1045BEAD8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045BEE4C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045BEB5C
	// [Call #8] RVA: 0x1045BE7C8
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045C00B8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x101F8B9F8

	// Object: Function Gameplay.UAEPlayerController.GetCurrentPetInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104672dcc
	// Params: [ Num(1) Size(0x20) ]
	struct FGameModePlayerPetInfo GetCurrentPetInfo();
	// [Call #1] RVA: 0x1045C5A78
	// [Call #2] RVA: 0x103222048
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045BEAD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045BEE4C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045BEB5C
	// [Call #13] RVA: 0x1045BE7C8
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.GetCurrentOBPlayerKey
	// Flags: [Native|Public|Const]
	// Offset: 0x104672d90
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetCurrentOBPlayerKey();
	// [Call #1] RVA: 0x1045C5A78
	// [Call #2] RVA: 0x103222048
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045BEAD8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045BEE4C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045BEB5C
	// [Call #13] RVA: 0x1045BE7C8
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.GetCurrentOBPlayerInfoIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104672d5c
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentOBPlayerInfoIndex();
	// [Call #1] RVA: 0x1045BE574
	// [Call #2] RVA: 0x1045C5A78
	// [Call #3] RVA: 0x103222048
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045BEAD8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045BEE4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BEB5C
	// [Call #14] RVA: 0x1045BE7C8

	// Object: Function Gameplay.UAEPlayerController.GenerateKillBroadcastItemID
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0xC) ]
	int GenerateKillBroadcastItemID(int ClothAvatarID, int PlayerUID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEPlayerController.ForceNetReady
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672d48
	// Params: [ Num(0) Size(0x0) ]
	void ForceNetReady();
	// [Call #1] RVA: 0x1045BE574
	// [Call #2] RVA: 0x1045C5A78
	// [Call #3] RVA: 0x103222048
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045BEAD8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045BEE4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BEB5C

	// Object: Function Gameplay.UAEPlayerController.ExitGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104672d34
	// Params: [ Num(0) Size(0x0) ]
	void ExitGame();
	// [Call #1] RVA: 0x1045BE574
	// [Call #2] RVA: 0x1045C5A78
	// [Call #3] RVA: 0x103222048
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045BEAD8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045BEE4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BEB5C

	// Object: Function Gameplay.UAEPlayerController.ExhaustCPU
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672d20
	// Params: [ Num(0) Size(0x0) ]
	void ExhaustCPU();
	// [Call #1] RVA: 0x1045BE574
	// [Call #2] RVA: 0x1045C5A78
	// [Call #3] RVA: 0x103222048
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045BEAD8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045BEE4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045BEB5C

	// Object: Function Gameplay.UAEPlayerController.ExecDSCommand
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672c80
	// Params: [ Num(1) Size(0x10) ]
	void ExecDSCommand(struct FString DSCommand);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045BE574
	// [Call #7] RVA: 0x1045C5A78
	// [Call #8] RVA: 0x103222048
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1045BEAD8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ExcuteIntRecord
	// Flags: [Final|Native|Public]
	// Offset: 0x104672b5c
	// Params: [ Num(2) Size(0x14) ]
	void ExcuteIntRecord(struct FString Key, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C27EC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x1045BE574

	// Object: Function Gameplay.UAEPlayerController.ExcuteIntCounterRecord
	// Flags: [Final|Native|Public]
	// Offset: 0x104672a38
	// Params: [ Num(2) Size(0x14) ]
	void ExcuteIntCounterRecord(struct FString Key, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.EnableInGameUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672a24
	// Params: [ Num(0) Size(0x0) ]
	void EnableInGameUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.DumpUAENetActors
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x104672a10
	// Params: [ Num(0) Size(0x0) ]
	void DumpUAENetActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0

	// Object: Function Gameplay.UAEPlayerController.DumpRegions
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x1046729fc
	// Params: [ Num(0) Size(0x0) ]
	void DumpRegions();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.DumpNetActors
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x1046729e8
	// Params: [ Num(0) Size(0x0) ]
	void DumpNetActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.DumpCharacters
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x1046729d4
	// Params: [ Num(0) Size(0x0) ]
	void DumpCharacters();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x1045C27EC
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.DumpAllUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x1046729c0
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C

	// Object: Function Gameplay.UAEPlayerController.DumpAllObjects
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x1046729ac
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllObjects();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.DumpAllActors
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672998
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.DoCrash
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672984
	// Params: [ Num(0) Size(0x0) ]
	void DoCrash();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.DisableInGameUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x104672970
	// Params: [ Num(0) Size(0x0) ]
	void DisableInGameUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.DelayEnterBattleCheck
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104672954
	// Params: [ Num(0) Size(0x0) ]
	void DelayEnterBattleCheck();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045C2524
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.DealWithPickUpFailed
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1046728c0
	// Params: [ Num(1) Size(0x18) ]
	void DealWithPickUpFailed(struct FItemDefineID DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1045C2524
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEPlayerController.ClientShowTeammateEscapeNotice
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1046728a4
	// Params: [ Num(0) Size(0x0) ]
	void ClientShowTeammateEscapeNotice();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1045C2524

	// Object: Function Gameplay.UAEPlayerController.ClientSendOodleNetworkAckToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104672888
	// Params: [ Num(0) Size(0x0) ]
	void ClientSendOodleNetworkAckToServer();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsgWithStrings
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1046726ac
	// Params: [ Num(5) Size(0x48) ]
	void ClientRPC_CastUIMsgWithStrings(struct FString strMsg, struct FString module, int TipsID, struct FString Param1, struct FString Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x1041EFFBC
	// [Call #21] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsgParams
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672578
	// Params: [ Num(3) Size(0x24) ]
	void ClientRPC_CastUIMsgParams(struct FString strMsg, struct FString module, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsg
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672484
	// Params: [ Num(2) Size(0x20) ]
	void ClientRPC_CastUIMsg(struct FString strMsg, struct FString module);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.ClientRepListReq
	// Flags: [Final|Native|Public]
	// Offset: 0x104672408
	// Params: [ Num(1) Size(0x8) ]
	void ClientRepListReq(struct UObject* InObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C64B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ClientRepComponentsReq
	// Flags: [Final|Native|Public]
	// Offset: 0x10467238c
	// Params: [ Num(1) Size(0x8) ]
	void ClientRepComponentsReq(struct UObject* InObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C79B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C64B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ClientInitPlayerOBInfoButton
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672370
	// Params: [ Num(0) Size(0x0) ]
	void ClientInitPlayerOBInfoButton();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C79B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C64B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.ClientBroadcastRespawnComplete
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672354
	// Params: [ Num(0) Size(0x0) ]
	void ClientBroadcastRespawnComplete();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C79B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C64B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.ClientBroadcastReconnectionSuccessful
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x104672338
	// Params: [ Num(0) Size(0x0) ]
	void ClientBroadcastReconnectionSuccessful();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045C79B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045C64B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Gameplay.UAEPlayerController.ClientAcknowledgeReconnection_3
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x1046722b4
	// Params: [ Num(1) Size(0x4) ]
	void ClientAcknowledgeReconnection_3(uint32_t Token);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C79B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C64B8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.CheckPlayerOBInfoButtonInit
	// Flags: [Native|Public]
	// Offset: 0x104672298
	// Params: [ Num(0) Size(0x0) ]
	void CheckPlayerOBInfoButtonInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045C79B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045C64B8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.CheckAcknowledgedPawn
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104672204
	// Params: [ Num(2) Size(0x9) ]
	bool CheckAcknowledgedPawn(struct APawn* InPawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C79B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.CastUIMsg
	// Flags: [Exec|Native|Public|BlueprintCallable]
	// Offset: 0x104672110
	// Params: [ Num(2) Size(0x20) ]
	void CastUIMsg(struct FString strMsg, struct FString module);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.CanPickUpItem
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467206c
	// Params: [ Num(2) Size(0x19) ]
	uint8_t CanPickUpItem(struct FItemDefineID DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041E5664
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEPlayerController.BroadcastUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104671eec
	// Params: [ Num(4) Size(0x38) ]
	void BroadcastUIMessage(struct FString MessageName, int TipsIDOrType, struct FString Param1, struct FString Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045BEC78
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1041EFFBC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1041E5664
	// [Call #21] RVA: 0x10516D168

	// Object: Function Gameplay.UAEPlayerController.BroadcastRespawnComplete
	// Flags: [Final|Native|Public]
	// Offset: 0x104671ed8
	// Params: [ Num(0) Size(0x0) ]
	void BroadcastRespawnComplete();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045BEC78
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1041EFFBC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1041E5664
};

// Object: Class Gameplay.ActorGridGeneratorInterface
// Size: 0x28 (Inherited: 0x28)
struct IActorGridGeneratorInterface : IInterface
{
};

// Object: Class Gameplay.AutoRotationComponent
// Size: 0x3D0 (Inherited: 0x3A0)
struct UAutoRotationComponent : USceneComponent
{
	uint8_t RotationMode; // 0x399(0x1)
	bool bTickOnDedicatedServer; // 0x39A(0x1)
	float RotationRate; // 0x39C(0x4)
	float PendulumAngle; // 0x3A0(0x4)
	struct UCurveVector* CurveData; // 0x3A8(0x8)
	uint8_t Pad_0x3B2[0x1E]; // 0x3B2(0x1E)
};

// Object: Class Gameplay.ConfigInterface
// Size: 0x28 (Inherited: 0x28)
struct IConfigInterface : IInterface
{
};

// Object: Class Gameplay.DynamicSpotContainerComponent
// Size: 0x248 (Inherited: 0x238)
struct UDynamicSpotContainerComponent : ULuaActorComponent
{
	bool SerializeDataUse; // 0x231(0x1)
	struct TArray<uint8_t> SerializeData; // 0x238(0x10)


	// Object: Function Gameplay.DynamicSpotContainerComponent.UseSerializeData
	// Flags: [Final|Native|Public]
	// Offset: 0x104602cdc
	// Params: [ Num(0) Size(0x0) ]
	void UseSerializeData();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class Gameplay.FoliageFakeCollision
// Size: 0x4B8 (Inherited: 0x4B0)
struct AFoliageFakeCollision : AActor
{
	struct UCapsuleComponent* CollisionComponent; // 0x4B0(0x8)
};

// Object: Class Gameplay.GameModeConfigComponent
// Size: 0x190 (Inherited: 0x178)
struct UGameModeConfigComponent : UActorComponent
{
	int appleGrenadeID; // 0x178(0x4)
	int appleGrenadeCount; // 0x17C(0x4)
	struct TArray<int> forbitPickItemTypeList; // 0x180(0x10)
};

// Object: Class Gameplay.PatchTableUtils
// Size: 0x28 (Inherited: 0x28)
struct UPatchTableUtils : UBlueprintFunctionLibrary
{
};

// Object: Class Gameplay.GameModeStatisticsComponent
// Size: 0x178 (Inherited: 0x178)
struct UGameModeStatisticsComponent : UActorComponent
{
};

// Object: Class Gameplay.GameplayDelegates
// Size: 0x3B8 (Inherited: 0x30)
struct UGameplayDelegates : UGameInstanceSubsystem
{
	struct FScriptMulticastDelegate GameModeStateChangeEvent; // 0x30(0x10)
	struct FScriptMulticastDelegate ActorOverlapEvent; // 0x40(0x10)
	struct FScriptMulticastDelegate ActorDieEvent; // 0x50(0x10)
	struct FScriptMulticastDelegate PawnDieEvent; // 0x60(0x10)
	struct FScriptMulticastDelegate CharacterDieEvent; // 0x70(0x10)
	struct FScriptMulticastDelegate EnterAreaTriggerEvent; // 0x80(0x10)
	struct FScriptMulticastDelegate ExitAreaTriggerEvent; // 0x90(0x10)
	struct FScriptMulticastDelegate PawnPickupItemEvent; // 0xA0(0x10)
	struct FScriptMulticastDelegate VehicleOverlapEvent; // 0xB0(0x10)
	struct FScriptMulticastDelegate InteractiveActorBeginEvent; // 0xC0(0x10)
	struct FScriptMulticastDelegate InteractiveActorDoneEvent; // 0xD0(0x10)
	struct FScriptMulticastDelegate CharacterStartSkill; // 0xE0(0x10)
	struct FScriptMulticastDelegate CharacterStopSkill; // 0xF0(0x10)
	struct FScriptMulticastDelegate CharacterStartSkillPhase; // 0x100(0x10)
	struct FScriptMulticastDelegate CharacterStopSkillPhase; // 0x110(0x10)
	struct FScriptMulticastDelegate CharacterStartSkillCooldown; // 0x120(0x10)
	struct FScriptMulticastDelegate CharacterStopSkillCooldown; // 0x130(0x10)
	struct FScriptMulticastDelegate CharacterAddSkill; // 0x140(0x10)
	struct FScriptMulticastDelegate CharacterRemoveSkill; // 0x150(0x10)
	struct FScriptMulticastDelegate PlayerJoinEvent; // 0x160(0x10)
	struct FScriptMulticastDelegate PlayerExitEvent; // 0x170(0x10)
	struct FScriptMulticastDelegate PlayerRealExitEvent; // 0x180(0x10)
	struct FScriptMulticastDelegate ProjectileStopEvent; // 0x190(0x10)
	struct FScriptMulticastDelegate ProjectileBounceEvent; // 0x1A0(0x10)
	struct FScriptMulticastDelegate DecoraterActorSpawnEvent; // 0x1B0(0x10)
	struct FScriptMulticastDelegate RemoteEvent; // 0x1C0(0x10)
	struct FScriptMulticastDelegate PlayerDamageQueryEvent; // 0x1D0(0x10)
	struct FScriptMulticastDelegate PawnNearDeathEvent; // 0x1E0(0x10)
	struct FScriptMulticastDelegate PawnNearDeathOrRescuedEvent; // 0x1F0(0x10)
	struct FScriptMulticastDelegate OnAIPawnSpawnEvent; // 0x200(0x10)
	struct FScriptMulticastDelegate OnCharacterRespawnEvent; // 0x210(0x10)
	struct FScriptMulticastDelegate ChooseEnemyLoseTargetEvent; // 0x220(0x10)
	struct FScriptMulticastDelegate FindEnemyWarningEvent; // 0x230(0x10)
	struct FScriptMulticastDelegate ModFindEnemyWarningEvent; // 0x240(0x10)
	struct FScriptMulticastDelegate TaskInterActiveActorBeginEvent; // 0x250(0x10)
	struct FScriptMulticastDelegate TaskInterActiveActorDoneEvent; // 0x260(0x10)
	struct FScriptMulticastDelegate LevelAddedEvent; // 0x270(0x10)
	struct FScriptMulticastDelegate DSLuaGMEvent; // 0x280(0x10)
	struct FScriptMulticastDelegate OnWeaponFireEvent; // 0x290(0x10)
	struct FScriptMulticastDelegate PlayerPickUpItemEvent; // 0x2A0(0x10)
	struct FScriptMulticastDelegate PlayerDropItemEvent; // 0x2B0(0x10)
	struct FScriptMulticastDelegate PlayerUseItemEvent; // 0x2C0(0x10)
	struct FScriptMulticastDelegate PlayerDisUseItemEvent; // 0x2D0(0x10)
	struct FScriptMulticastDelegate PlayerSwapItemEvent; // 0x2E0(0x10)
	struct FScriptMulticastDelegate PlayerEquipItemEvent; // 0x2F0(0x10)
	struct FScriptMulticastDelegate PlayerUnEquipItemEvent; // 0x300(0x10)
	struct FScriptMulticastDelegate PlayerConsumeEvent; // 0x310(0x10)
	struct FScriptMulticastDelegate PawnChangeTeamEvent; // 0x320(0x10)
	struct FScriptMulticastDelegate OnPlayReplayBegin; // 0x330(0x10)
	struct FScriptMulticastDelegate OnPlayReplayEnd; // 0x340(0x10)
	struct FScriptMulticastDelegate PlayerEventForReplay; // 0x350(0x10)
	uint8_t Pad_0x360[0x58]; // 0x360(0x58)
};

// Object: Class Gameplay.GeneratorActorAIInterface
// Size: 0x28 (Inherited: 0x28)
struct IGeneratorActorAIInterface : IInterface
{

	// Object: Function Gameplay.GeneratorActorAIInterface.RegisterAIPickupPoint
	// Flags: [Native|Public|HasDefaults]
	// Offset: 0x10462cf80
	// Params: [ Num(3) Size(0x20) ]
	void RegisterAIPickupPoint(struct FVector BuildingLoc, struct FVector SpotLoc, struct AActor* PickUpActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x10462DA2C
};

// Object: Class Gameplay.GeneratorActorInterface
// Size: 0x28 (Inherited: 0x28)
struct IGeneratorActorInterface : IInterface
{

	// Object: Function Gameplay.GeneratorActorInterface.SetExtendData
	// Flags: [Native|Public]
	// Offset: 0x10462d74c
	// Params: [ Num(2) Size(0x14) ]
	void SetExtendData(struct FString Key, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.GeneratorActorInterface.SetAttachedActor
	// Flags: [Native|Public]
	// Offset: 0x10462d6c8
	// Params: [ Num(1) Size(0x8) ]
	void SetAttachedActor(struct AActor* AttachedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Gameplay.GeneratorActorInterface.InitDataNew
	// Flags: [Native|Public]
	// Offset: 0x10462d474
	// Params: [ Num(5) Size(0x30) ]
	void InitDataNew(int ItemCount, struct FString Value, struct FString Category, bool RepeatGenerateItem, int SpotDataIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function Gameplay.GeneratorActorInterface.InitData
	// Flags: [Native|Public]
	// Offset: 0x10462d220
	// Params: [ Num(5) Size(0x31) ]
	void InitData(struct UItemSpotSceneComponent* ItemSpotSceneComponent, int ItemCount, struct FString Value, struct FString Category, bool RepeatGenerateItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function Gameplay.GeneratorActorInterface.GetItemId
	// Flags: [Native|Public]
	// Offset: 0x10462d1e4
	// Params: [ Num(1) Size(0x4) ]
	int GetItemId();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
};

// Object: Class Gameplay.GeneratorVehicleInterface
// Size: 0x28 (Inherited: 0x28)
struct IGeneratorVehicleInterface : IInterface
{

	// Object: Function Gameplay.GeneratorVehicleInterface.SetSafeSpawn
	// Flags: [Native|Public]
	// Offset: 0x10462ddb4
	// Params: [ Num(1) Size(0x1) ]
	void SetSafeSpawn(bool ab_IsSafeSpawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.GeneratorVehicleInterface.ServerDetachAllPlayerFromSeatByGenerator
	// Flags: [Native|Public]
	// Offset: 0x10462dcdc
	// Params: [ Num(2) Size(0x2) ]
	void ServerDetachAllPlayerFromSeatByGenerator(bool bMustExit, bool bApplyVehicleVelocity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.GeneratorVehicleInterface.InitVehicle
	// Flags: [Native|Public]
	// Offset: 0x10462dbc8
	// Params: [ Num(3) Size(0x6) ]
	void InitVehicle(int FuelPercent, bool bEngineOn, bool bInHouse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.GeneratorVehicleInterface.CheckSpawnLocation
	// Flags: [Native|Public|HasDefaults]
	// Offset: 0x10462db08
	// Params: [ Num(2) Size(0x10) ]
	void CheckSpawnLocation(struct FVector SpawnLocation, float MaxSpawnDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
};

// Object: Class Gameplay.GlobalConfigActor
// Size: 0x4C0 (Inherited: 0x4B0)
struct AGlobalConfigActor : AActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	bool bInitComponents; // 0x4B8(0x1)
	uint8_t Pad_0x4B9[0x7]; // 0x4B9(0x7)


	// Object: Function Gameplay.GlobalConfigActor.Init
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10462e0b0
	// Params: [ Num(0) Size(0x0) ]
	void Init();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10462E4E8
	// [Call #5] RVA: 0x104563218
	// [Call #6] RVA: 0x10516D168
};

// Object: Class Gameplay.ImplItemRegionInterface
// Size: 0x28 (Inherited: 0x28)
struct IImplItemRegionInterface : IInterface
{

	// Object: Function Gameplay.ImplItemRegionInterface.GetRegion
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10462e998
	// Params: [ Num(2) Size(0x48) ]
	struct FItemRegionCircle GetRegion(struct FString Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10462ECB4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x10516EABC
};

// Object: Class Gameplay.ItemBandSpotSceneComponent
// Size: 0x400 (Inherited: 0x3C0)
struct UItemBandSpotSceneComponent : USpotSceneComponent
{
	struct FString SpotItemValue; // 0x3B8(0x10)
	struct FString SpotItemCategory; // 0x3C8(0x10)
	struct FString ConditionItemValue; // 0x3D8(0x10)
	struct FString ConditionItemCategory; // 0x3E8(0x10)
};

// Object: Class Gameplay.ItemConfigActorComponent
// Size: 0x1D8 (Inherited: 0x178)
struct UItemConfigActorComponent : UActorComponent
{
	struct TArray<struct FItemSpawnData> ItemSpawnDatas; // 0x178(0x10)
	struct TMap<int, struct FGroupTypeSceneComponents> AllSpotGroups; // 0x188(0x50)


	// Object: Function Gameplay.ItemConfigActorComponent.RegisterGroupSceneComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10462f6e8
	// Params: [ Num(2) Size(0x10) ]
	void RegisterGroupSceneComponent(int GroupType, struct USceneComponent* GroupSceneComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045637A8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.ItemConfigActorComponent.RandomItemSpawnClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10462f538
	// Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FItemSpawnClass> RandomItemSpawnClass(struct FString ItemValue, struct FString ItemCategory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x104563A58
	// [Call #8] RVA: 0x104634EFC
	// [Call #9] RVA: 0x10458AF70
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x10458AF70
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4
	// [Call #26] RVA: 0x10516D168
	// [Call #27] RVA: 0x10516D1A4
	// [Call #28] RVA: 0x1045637A8

	// Object: Function Gameplay.ItemConfigActorComponent.RandomGroupSceneComponents
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10462f44c
	// Params: [ Num(3) Size(0x18) ]
	struct TArray<struct USceneComponent*> RandomGroupSceneComponents(int GroupType, int Persent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10456388C
	// [Call #6] RVA: 0x104634F4C
	// [Call #7] RVA: 0x101F8C374
	// [Call #8] RVA: 0x101F8C374
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x104563A58
	// [Call #17] RVA: 0x104634EFC
	// [Call #18] RVA: 0x10458AF70
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x10458AF70
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x104EEF504
	// [Call #26] RVA: 0x101F8130C

	// Object: Function Gameplay.ItemConfigActorComponent.RandomGroupSceneComponent
	// Flags: [Final|Native|Public]
	// Offset: 0x10462f358
	// Params: [ Num(2) Size(0x18) ]
	struct USceneComponent* RandomGroupSceneComponent(struct TArray<struct USceneComponent*> AllGroups);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8FD30
	// [Call #4] RVA: 0x1045639E8
	// [Call #5] RVA: 0x101F8C374
	// [Call #6] RVA: 0x101F8C374
	// [Call #7] RVA: 0x101F8C374
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8C374
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10456388C
	// [Call #17] RVA: 0x104634F4C
	// [Call #18] RVA: 0x101F8C374
	// [Call #19] RVA: 0x101F8C374
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168

	// Object: Function Gameplay.ItemConfigActorComponent.LoadActorClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10462f264
	// Params: [ Num(2) Size(0x18) ]
	struct UObject* LoadActorClass(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10456377C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8FD30
	// [Call #15] RVA: 0x1045639E8
	// [Call #16] RVA: 0x101F8C374
	// [Call #17] RVA: 0x101F8C374
	// [Call #18] RVA: 0x101F8C374
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8C374
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Gameplay.ItemConfigActorComponent.GetItemSpawnClass
	// Flags: [Final|Native|Public]
	// Offset: 0x10462f160
	// Params: [ Num(2) Size(0x80) ]
	struct TArray<struct FItemSpawnClass> GetItemSpawnClass(struct FItemSpawnData Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10457DA68
	// [Call #4] RVA: 0x104563C68
	// [Call #5] RVA: 0x104634EFC
	// [Call #6] RVA: 0x10458AF70
	// [Call #7] RVA: 0x10457DBC8
	// [Call #8] RVA: 0x10457DBC8
	// [Call #9] RVA: 0x10458AF70
	// [Call #10] RVA: 0x10457DBC8
	// [Call #11] RVA: 0x10457DBC8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10456377C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4
};

// Object: Class Gameplay.ItemCountArea
// Size: 0x4B8 (Inherited: 0x4B0)
struct AItemCountArea : AActor
{
	struct UBoxComponent* Area; // 0x4B0(0x8)


	// Object: Function Gameplay.ItemCountArea.IsInArea
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10462fa54
	// Params: [ Num(2) Size(0xD) ]
	bool IsInArea(struct FVector& Position);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class Gameplay.ItemGenerateInterface
// Size: 0x28 (Inherited: 0x28)
struct IItemGenerateInterface : IInterface
{
};

// Object: Class Gameplay.ItemGroupRepeatSpotComponent
// Size: 0x470 (Inherited: 0x3B0)
struct UItemGroupRepeatSpotComponent : UGroupSpotSceneComponent
{
	int GenerateNumPerFrame; // 0x3AC(0x4)
	float RepeatGenerateItemTimer; // 0x3B0(0x4)
	int GroupID; // 0x3B4(0x4)
	struct FString GroupTag; // 0x3B8(0x10)
	struct TArray<struct UItemSpotSceneComponent*> Spots; // 0x3C8(0x10)
	struct TArray<struct UItemSpotSceneComponent*> PendingGenerateSpots; // 0x3D8(0x10)
	struct UItemGeneratorComponent* ItemGenerator; // 0x3E8(0x8)
	struct FSpotGroupProperty SpotGroupProperty; // 0x3F0(0x28)
	struct TMap<enum class ESpotType, struct FSpotTypeProperty> SpotTypePropertys; // 0x418(0x50)
	bool bInitialize; // 0x468(0x1)
	bool bEnable; // 0x469(0x1)
	uint8_t Pad_0x46E[0x2]; // 0x46E(0x2)


	// Object: Function Gameplay.ItemGroupRepeatSpotComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104637b80
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupRepeatSpotComponent.SetPropertySpotAll
	// Flags: [Final|Native|Public]
	// Offset: 0x104637b6c
	// Params: [ Num(0) Size(0x0) ]
	void SetPropertySpotAll();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupRepeatSpotComponent.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104637b38
	// Params: [ Num(1) Size(0x8) ]
	struct AUAEGameMode* GetGameMode();
	// [Call #1] RVA: 0x1045723A4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupRepeatSpotComponent.GenerateSpotAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104637b24
	// Params: [ Num(0) Size(0x0) ]
	void GenerateSpotAll();
	// [Call #1] RVA: 0x1045723A4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.ItemGroupRepeatSpotComponent.ClearAllSpotItems
	// Flags: [Final|Native|Public]
	// Offset: 0x104637b10
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllSpotItems();
	// [Call #1] RVA: 0x1045723A4
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
};

// Object: Class Gameplay.LuaBTDecoratorBase
// Size: 0x1A8 (Inherited: 0x60)
struct ULuaBTDecoratorBase : UBTDecorator
{
	uint8_t Pad_0x60[0x60]; // 0x60(0x60)
	struct AAIController* ActorOwner; // 0xC0(0x8)
	struct TArray<struct FName> ObservedKeyNames; // 0xC8(0x10)
	uint8_t Pad_0xD8[0x10]; // 0xD8(0x10)
	uint8_t bShowPropertyDetails : 1; // 0xE8(0x1), Mask(0x1)
	uint8_t bCheckConditionOnlyBlackBoardChanges : 1; // 0xE8(0x1), Mask(0x2)
	uint8_t bIsObservingBB : 1; // 0xE8(0x1), Mask(0x4)
	uint8_t BitPad_0xE8_3 : 5; // 0xE8(0x1)
	uint8_t Pad_0xE9[0x7]; // 0xE9(0x7)
	struct TMap<struct FString, struct FString> LuaNodeParams; // 0xF0(0x50)
	struct TMap<struct FName, struct FBlackboardKeySelector> LuaBlackboardParams; // 0x140(0x50)
	float TickInterval; // 0x190(0x4)
	float TickIntervalRandomDeviation; // 0x194(0x4)
	struct FString LuaFilePath; // 0x198(0x10)


	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveObserverDeactivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveObserverDeactivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverDeactivated(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveObserverActivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveObserverActivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverActivated(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveExecutionStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveExecutionStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveExecutionStart(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveExecutionFinishAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	void ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult NodeResult);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.ReceiveExecutionFinish
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.PerformConditionCheckAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.PerformConditionCheck
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	bool PerformConditionCheck(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTDecoratorBase.IsDecoratorObserverActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104639000
	// Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorObserverActive();
	// [Call #1] RVA: 0x104553920
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTDecoratorBase.IsDecoratorExecutionActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104638fcc
	// Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorExecutionActive();
	// [Call #1] RVA: 0x1045538CC
	// [Call #2] RVA: 0x104553920
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class Gameplay.LuaBTNodeInterface
// Size: 0x28 (Inherited: 0x28)
struct ILuaBTNodeInterface : IInterface
{

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10463a548
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10463a404
	// Params: [ Num(2) Size(0x18) ]
	void SetValueAsString(struct FName& KeyName, struct FString StringValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10463a32c
	// Params: [ Num(2) Size(0x14) ]
	void SetValueAsRotator(struct FName& KeyName, struct FRotator RotatorValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10463a254
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10463a17c
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsName(struct FName& KeyName, struct FName NameValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10463a0a4
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsInt(struct FName& KeyName, int IntValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639fcc
	// Params: [ Num(2) Size(0xC) ]
	void SetValueAsFloat(struct FName& KeyName, float FloatValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639ef4
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsEnum(struct FName& KeyName, uint8_t EnumValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639e1c
	// Params: [ Num(2) Size(0x10) ]
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639d3c
	// Params: [ Num(2) Size(0x9) ]
	void SetValueAsBool(struct FName& KeyName, bool BoolValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.IsVectorValueSet
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639c98
	// Params: [ Num(2) Size(0x9) ]
	bool IsVectorValueSet(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104639bf0
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetValueAsVector(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639b24
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetValueAsString(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104639a7c
	// Params: [ Num(2) Size(0x14) ]
	struct FRotator GetValueAsRotator(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1046399d8
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsObject(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639934
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetValueAsName(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639890
	// Params: [ Num(2) Size(0xC) ]
	int GetValueAsInt(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1046397ec
	// Params: [ Num(2) Size(0xC) ]
	float GetValueAsFloat(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639748
	// Params: [ Num(2) Size(0x9) ]
	uint8_t GetValueAsEnum(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1046396a4
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsClass(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.GetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104639600
	// Params: [ Num(2) Size(0x9) ]
	bool GetValueAsBool(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function Gameplay.LuaBTNodeInterface.ClearValue
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10463956c
	// Params: [ Num(1) Size(0x8) ]
	void ClearValue(struct FName& KeyName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
};

// Object: Class Gameplay.LuaBTServiceBase
// Size: 0x198 (Inherited: 0x68)
struct ULuaBTServiceBase : UBTService
{
	uint8_t Pad_0x68[0x60]; // 0x68(0x60)
	struct AAIController* ActorOwner; // 0xC8(0x8)
	uint8_t Pad_0xD0[0x10]; // 0xD0(0x10)
	uint8_t bShowPropertyDetails : 1; // 0xE0(0x1), Mask(0x1)
	uint8_t bShowEventDetails : 1; // 0xE0(0x1), Mask(0x2)
	uint8_t BitPad_0xE0_2 : 6; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
	struct TMap<struct FString, struct FString> LuaNodeParams; // 0xE8(0x50)
	struct TMap<struct FName, struct FBlackboardKeySelector> LuaBlackboardParams; // 0x138(0x50)
	struct FString LuaFilePath; // 0x188(0x10)


	// Object: Function Gameplay.LuaBTServiceBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveSearchStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveSearchStart(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveDeactivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveDeactivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveDeactivation(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.ReceiveActivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveActivation(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTServiceBase.IsServiceActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10463ad3c
	// Params: [ Num(1) Size(0x1) ]
	bool IsServiceActive();
	// [Call #1] RVA: 0x10455534C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class Gameplay.LuaBTTaskBase
// Size: 0x1B8 (Inherited: 0x70)
struct ULuaBTTaskBase : UBTTaskNode
{
	uint8_t Pad_0x70[0x60]; // 0x70(0x60)
	struct AAIController* ActorOwner; // 0xD0(0x8)
	uint8_t Pad_0xD8[0x18]; // 0xD8(0x18)
	uint8_t bShowPropertyDetails : 1; // 0xF0(0x1), Mask(0x1)
	uint8_t BitPad_0xF0_1 : 7; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x7]; // 0xF1(0x7)
	struct TMap<struct FString, struct FString> LuaNodeParams; // 0xF8(0x50)
	struct TMap<struct FName, struct FBlackboardKeySelector> LuaBlackboardParams; // 0x148(0x50)
	float TickInterval; // 0x198(0x4)
	float TickIntervalRandomDeviation; // 0x19C(0x4)
	uint8_t Pad_0x1A0[0x8]; // 0x1A0(0x8)
	struct FString LuaFilePath; // 0x1A8(0x10)


	// Object: Function Gameplay.LuaBTTaskBase.SetFinishOnMessageWithId
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10463b298
	// Params: [ Num(2) Size(0xC) ]
	void SetFinishOnMessageWithId(struct FName MessageName, int RequestID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104555F8C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTTaskBase.SetFinishOnMessage
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10463b21c
	// Params: [ Num(1) Size(0x8) ]
	void SetFinishOnMessage(struct FName MessageName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104555F34
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104555F8C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0xC) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveExecute(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveAbortAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x10) ]
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void ReceiveAbort(struct AActor* OwnerActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.LuaBTTaskBase.IsTaskExecuting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10463b1e8
	// Params: [ Num(1) Size(0x1) ]
	bool IsTaskExecuting();
	// [Call #1] RVA: 0x104555EDC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104555F34
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104555F8C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTTaskBase.IsTaskAborting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10463b1b4
	// Params: [ Num(1) Size(0x1) ]
	bool IsTaskAborting();
	// [Call #1] RVA: 0x104555F28
	// [Call #2] RVA: 0x104555EDC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104555F34
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104555F8C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTTaskBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10463b130
	// Params: [ Num(1) Size(0x1) ]
	void FinishExecute(bool bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104555E04
	// [Call #4] RVA: 0x104555F28
	// [Call #5] RVA: 0x104555EDC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104555F34
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104555F8C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.LuaBTTaskBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10463b11c
	// Params: [ Num(0) Size(0x0) ]
	void FinishAbort();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104555E04
	// [Call #4] RVA: 0x104555F28
	// [Call #5] RVA: 0x104555EDC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104555F34
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104555F8C
};

// Object: Class Gameplay.MissionBoardComponent
// Size: 0x1D8 (Inherited: 0x178)
struct UMissionBoardComponent : UActorComponent
{
	struct FMissionBoardConfig Config; // 0x178(0x50)
	struct FScriptMulticastDelegate OnRepConfigDelegate; // 0x1C8(0x10)


	// Object: Function Gameplay.MissionBoardComponent.OnRep_Config
	// Flags: [Final|Native|Public]
	// Offset: 0x10463b84c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Config();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function Gameplay.MissionBoardComponent.GetUtcLeftSecondsByConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10463b818
	// Params: [ Num(1) Size(0x4) ]
	int GetUtcLeftSecondsByConfig();
	// [Call #1] RVA: 0x104574040
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class Gameplay.NetworkExceptionHandleSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UNetworkExceptionHandleSubsystem : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0x10]; // 0x30(0x10)
};

// Object: Class Gameplay.NetworkReportActor
// Size: 0x500 (Inherited: 0x4B0)
struct ANetworkReportActor : AActor
{
	int LossRateArrayNum; // 0x4AC(0x4)
	int MaxCacheLossRateArrayNum; // 0x4B0(0x4)
	struct FString InPacketLossRateArrayStr; // 0x4B8(0x10)
	struct FString OutPacketLossRateArrayStr; // 0x4C8(0x10)
	uint8_t Pad_0x4D8[0x28]; // 0x4D8(0x28)


	// Object: Function Gameplay.NetworkReportActor.RPC_Server_SyncClientPkgLossArrayInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10463bbac
	// Params: [ Num(2) Size(0x20) ]
	void RPC_Server_SyncClientPkgLossArrayInfo(struct TArray<uint8_t> InLoss, struct TArray<uint8_t> OutLoss);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Gameplay.NetworkReportActor.ResetAllNetworkData
	// Flags: [Final|Native|Public]
	// Offset: 0x10463bb98
	// Params: [ Num(0) Size(0x0) ]
	void ResetAllNetworkData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
};

// Object: Class Gameplay.NewWeatherComponent
// Size: 0x240 (Inherited: 0x238)
struct UNewWeatherComponent : ULuaActorComponent
{
	uint8_t Pad_0x238[0x8]; // 0x238(0x8)


	// Object: Function Gameplay.NewWeatherComponent.LuaInit
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void LuaInit();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class Gameplay.UAEAdvertisementActor
// Size: 0x5A8 (Inherited: 0x4C0)
struct AUAEAdvertisementActor : AStaticMeshActor
{
	uint8_t Pad_0x4C0[0x58]; // 0x4C0(0x58)
	struct FString LuaFilePath; // 0x518(0x10)
	bool bMultiAdvertisement; // 0x528(0x1)
	uint8_t Pad_0x529[0x7]; // 0x529(0x7)
	struct TMap<uint8_t, struct UTexture2D*> IdTextureMap; // 0x530(0x50)
	struct UStaticMesh* StaticMesh; // 0x580(0x8)
	struct FString StaticMeshPath; // 0x588(0x10)
	struct UFrontendHUD* FrontendHUD; // 0x598(0x8)
	int ID; // 0x5A0(0x4)
	float NetCullDistance; // 0x5A4(0x4)


	// Object: Function Gameplay.UAEAdvertisementActor.SetStaticMeshPath
	// Flags: [Native|Public]
	// Offset: 0x10464f2b4
	// Params: [ Num(1) Size(0x10) ]
	void SetStaticMeshPath(struct FString InMeshPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEAdvertisementActor.SetStaticMesh
	// Flags: [Native|Public]
	// Offset: 0x10464f230
	// Params: [ Num(1) Size(0x8) ]
	void SetStaticMesh(struct UStaticMesh* InStaticMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEAdvertisementActor.SetScale
	// Flags: [Native|Public|HasDefaults]
	// Offset: 0x10464f1ac
	// Params: [ Num(1) Size(0xC) ]
	void SetScale(struct FVector InScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Gameplay.UAEAdvertisementActor.SetId
	// Flags: [Final|Native|Public]
	// Offset: 0x10464f130
	// Params: [ Num(1) Size(0x4) ]
	void SetId(int InputID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104593EA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.UAEAdvertisementActor.SetCulDistance
	// Flags: [Native|Public]
	// Offset: 0x10464f0ac
	// Params: [ Num(1) Size(0x4) ]
	void SetCulDistance(float CulDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104593EA8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEAdvertisementActor.RequestHttpImageByUrl
	// Flags: [Final|Native|Public]
	// Offset: 0x10464f014
	// Params: [ Num(1) Size(0x10) ]
	void RequestHttpImageByUrl(struct FString PicUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104593F74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104593EA8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAEAdvertisementActor.ReplaceTexture
	// Flags: [Final|Native|Protected]
	// Offset: 0x10464ef98
	// Params: [ Num(1) Size(0x8) ]
	void ReplaceTexture(struct UTexture2D* Texture);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104593FA4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104593F74
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104593EA8
	// [Call #15] RVA: 0x10516D168

	// Object: Function Gameplay.UAEAdvertisementActor.OnRequestImgSuccess
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10464eebc
	// Params: [ Num(2) Size(0x18) ]
	void OnRequestImgSuccess(struct UTexture2D* Texture, struct FString RequestedURL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104593FA4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104593F74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEAdvertisementActor.OnRep_MeshPath
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_MeshPath();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEAdvertisementActor.OnRep_Id
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Id();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEAdvertisementActor.OnClientLoadMesh
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnClientLoadMesh();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEAdvertisementActor.InitImageDownloadUtil
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10464eea8
	// Params: [ Num(0) Size(0x0) ]
	void InitImageDownloadUtil();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104593FA4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104593F74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class Gameplay.RegionableAdvertisementActor
// Size: 0x5B8 (Inherited: 0x5A8)
struct ARegionableAdvertisementActor : AUAEAdvertisementActor
{
	uint8_t Pad_0x5A8[0x8]; // 0x5A8(0x8)
	uint8_t RegionSize; // 0x5B0(0x1)
	bool bRegionStatic; // 0x5B1(0x1)
	uint8_t Pad_0x5B2[0x6]; // 0x5B2(0x6)


	// Object: Function Gameplay.RegionableAdvertisementActor.ReceivedPlayerActiveRegionsChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void ReceivedPlayerActiveRegionsChanged(bool bEnter);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class Gameplay.SpotGeneratorStruct
// Size: 0x28 (Inherited: 0x28)
struct USpotGeneratorStruct : UObject
{
};

// Object: Class Gameplay.TriggerActionSpawnItemInterface
// Size: 0x28 (Inherited: 0x28)
struct ITriggerActionSpawnItemInterface : IInterface
{
};

// Object: Class Gameplay.UAEActorMap
// Size: 0x500 (Inherited: 0x4B0)
struct AUAEActorMap : AInfo
{
	struct TMap<struct FVector, struct AActor*> ActorsMap; // 0x4B0(0x50)
};

// Object: Class Gameplay.UAEBuffApplierActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct AUAEBuffApplierActor : AActor
{
	struct AController* InstigatorController; // 0x4B0(0x8)


	// Object: Function Gameplay.UAEBuffApplierActor.GetTheInstigatorController
	// Flags: [Native|Public|Const]
	// Offset: 0x10464f7b4
	// Params: [ Num(1) Size(0x8) ]
	struct AController* GetTheInstigatorController();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10462CE90
	// [Call #5] RVA: 0x105184F34
	// [Call #6] RVA: 0x105190648
	// [Call #7] RVA: 0x1036A6C08
	// [Call #8] RVA: 0x10462CE90
};

// Object: Class Gameplay.AnimInstanceCacheCustomAnimInterface
// Size: 0x28 (Inherited: 0x28)
struct IAnimInstanceCacheCustomAnimInterface : IInterface
{
};

// Object: Class Gameplay.UAECharAnimListCompBase
// Size: 0x2D8 (Inherited: 0x2C8)
struct UUAECharAnimListCompBase : UUAEAnimListComponentBase
{
	struct TArray<struct FCharacterAsynLoadedTypeAnim> CharacterAsynLoadedAnims; // 0x2C8(0x10)
};

// Object: Class Gameplay.UAEChaCustomAnimListComponent
// Size: 0x3C0 (Inherited: 0x2D8)
struct UUAEChaCustomAnimListComponent : UUAECharAnimListCompBase
{
	uint8_t Pad_0x2D8[0x8]; // 0x2D8(0x8)
	bool bLoadAnimOnBeginPlay; // 0x2E0(0x1)
	uint8_t Pad_0x2E1[0x3]; // 0x2E1(0x3)
	int CharacterAnimOverrideType; // 0x2E4(0x4)
	struct TMap<struct FString, struct FName> CharAnimEnumName; // 0x2E8(0x50)
	struct TArray<struct FCharCustomAnimData> CharCustomAnimDataList; // 0x338(0x10)
	struct TMap<struct FString, struct FName> CharFeatureAnimInstanceEnumName; // 0x348(0x50)
	struct TArray<struct FCharCustomAnimInstacneData> CharCustomAnimInstanceDataList; // 0x398(0x10)
	uint8_t Pad_0x3A8[0x18]; // 0x3A8(0x18)


	// Object: Function Gameplay.UAEChaCustomAnimListComponent.SetCharacterAnimOverrideType
	// Flags: [Final|Native|Public]
	// Offset: 0x104650144
	// Params: [ Num(1) Size(0x4) ]
	void SetCharacterAnimOverrideType(int AnimOverrideType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.ReleaseCustomAnimAssets
	// Flags: [Final|Native|Public]
	// Offset: 0x104650130
	// Params: [ Num(0) Size(0x0) ]
	void ReleaseCustomAnimAssets();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.HasAnimAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x1046500fc
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnimAsyncLoadingFinished();
	// [Call #1] RVA: 0x1045969A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetOwnerName
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104650090
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetOwnerName();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x1045969A0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetCharacterCustomAnimInstance
	// Flags: [Final|Native|Public]
	// Offset: 0x10464ffe4
	// Params: [ Num(2) Size(0x18) ]
	struct UAnimInstance* GetCharacterCustomAnimInstance(struct FString AnimName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045968B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1045969A0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetCharacterCustomAnim
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10464ff3c
	// Params: [ Num(2) Size(0x18) ]
	struct UAnimationAsset* GetCharacterCustomAnim(struct FString AnimName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10459645C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045968B0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1045969A0
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetBlendSpace1D
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10464fe94
	// Params: [ Num(2) Size(0x18) ]
	struct UBlendSpace1D* GetBlendSpace1D(struct FString AnimAssetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045975C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10459645C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045968B0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetBlendSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10464fdec
	// Params: [ Num(2) Size(0x18) ]
	struct UBlendSpace* GetBlendSpace(struct FString AnimAssetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104596FD4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045975C4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10459645C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetAnimSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10464fd44
	// Params: [ Num(2) Size(0x18) ]
	struct UAnimSequence* GetAnimSequence(struct FString AnimAssetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104596CDC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104596FD4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045975C4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetAnimMontage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10464fc9c
	// Params: [ Num(2) Size(0x18) ]
	struct UAnimMontage* GetAnimMontage(struct FString AnimAssetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045972CC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104596CDC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104596FD4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.GetAimOffsetBlendSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10464fbf4
	// Params: [ Num(2) Size(0x18) ]
	struct UAimOffsetBlendSpace* GetAimOffsetBlendSpace(struct FString AnimAssetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045978BC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045972CC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104596CDC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAEChaCustomAnimListComponent.CallRequestLoadAnimAssets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10464fbe0
	// Params: [ Num(0) Size(0x0) ]
	void CallRequestLoadAnimAssets();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045978BC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045972CC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104596CDC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
};

// Object: Class Gameplay.AnimInstanceCacheParachuteAnimInterface
// Size: 0x28 (Inherited: 0x28)
struct IAnimInstanceCacheParachuteAnimInterface : IInterface
{
};

// Object: Class Gameplay.UAEChaParachuteAnimListComponent
// Size: 0x310 (Inherited: 0x2D8)
struct UUAEChaParachuteAnimListComponent : UUAECharAnimListCompBase
{
	struct TArray<struct FCharParachuteAnimData> CharParachuteAnimDataList; // 0x2D8(0x10)
	uint8_t Pad_0x2E8[0x28]; // 0x2E8(0x28)


	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.ReleaseParachuteAnimAssets
	// Flags: [Final|Native|Public]
	// Offset: 0x104650aac
	// Params: [ Num(0) Size(0x0) ]
	void ReleaseParachuteAnimAssets();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.OnParachuteAnimAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x1046509c8
	// Params: [ Num(1) Size(0x10) ]
	void OnParachuteAnimAsyncLoadingFinished(struct FString AnimLoaded);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x104598E50
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.OnAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x1046509b4
	// Params: [ Num(0) Size(0x0) ]
	void OnAnimListAsyncLoadingFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x104598E50
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.HasAnimAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x104650980
	// Params: [ Num(1) Size(0x1) ]
	bool HasAnimAsyncLoadingFinished();
	// [Call #1] RVA: 0x104599320
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x104598E50
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.HandleAsyncLoadingFinishedEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10465096c
	// Params: [ Num(0) Size(0x0) ]
	void HandleAsyncLoadingFinishedEvent();
	// [Call #1] RVA: 0x104599320
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x104598E50
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.GetOwnerName
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104650900
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetOwnerName();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x104599320
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x104598E50
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function Gameplay.UAEChaParachuteAnimListComponent.GetCharacterParachuteAnim
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104650838
	// Params: [ Num(3) Size(0x10) ]
	struct UAnimationAsset* GetCharacterParachuteAnim(enum class ECharacterParachuteAnimType AnimType, int AnimOverrideType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104598F30
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x104599320
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x104598E50
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
};

// Object: Class Gameplay.UAECharacterAnimListComponent
// Size: 0x3A0 (Inherited: 0x2D8)
struct UUAECharacterAnimListComponent : UUAECharAnimListCompBase
{
	struct TArray<struct FCharacterMovementAnimData> CharacterMovementAnimEditList; // 0x2D8(0x10)
	struct TArray<struct FCharacterMovementAnimData> CharacterFPPAnimEditList; // 0x2E8(0x10)
	struct TArray<struct FCharacterJumpAnimData> CharacterJumpEditList; // 0x2F8(0x10)
	struct TArray<struct FCharacterJumpAnimData> CharacterJumpEditListFPP; // 0x308(0x10)
	struct UCurveFloat* FallingIKCurve; // 0x318(0x8)
	struct TArray<struct FCharacterShovelAnimData> CharacterShovelEditList; // 0x320(0x10)
	struct TArray<struct FCharacterShovelAnimData> CharacterShovelEditListFPP; // 0x330(0x10)
	struct TArray<struct FCharAnimModifyData> CharAnimModifyList; // 0x340(0x10)
	struct TArray<struct FCharacterVehAnimModifyData> CharVehAnimModifyList; // 0x350(0x10)
	bool IsInitByBeginPlay; // 0x360(0x1)
	bool EnablePreLoadingFinish; // 0x361(0x1)
	bool CurrentIsTPP; // 0x362(0x1)
	bool CurrentHoldShield; // 0x363(0x1)
	bool bRandomIdleAnimSections; // 0x364(0x1)
	uint8_t Pad_0x365[0x3]; // 0x365(0x3)
	struct TArray<struct FName> RandomAnimMontageSections; // 0x368(0x10)
	uint8_t Pad_0x378[0x8]; // 0x378(0x8)
	struct FGetAnimUtil GetAnimUtil; // 0x380(0x20)


	// Object: Function Gameplay.UAECharacterAnimListComponent.SetAnimListMapValueData
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10465a368
	// Params: [ Num(2) Size(0x38) ]
	void SetAnimListMapValueData(struct UAnimationAsset*& AnimPtr, struct FAnimListMapValueData& AnimListValue);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045A3A98
	// [Call #7] RVA: 0x102CE5F08
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102CE5F08
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190648

	// Object: Function Gameplay.UAECharacterAnimListComponent.OnPreLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x10465a28c
	// Params: [ Num(2) Size(0x29) ]
	bool OnPreLoadingFinished(struct FAsyncLoadCharAnimParams LoadingParam);
	// [Call #1] RVA: 0x104661DB4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045C957C
	// [Call #5] RVA: 0x10459D7C8
	// [Call #6] RVA: 0x101F91BDC
	// [Call #7] RVA: 0x101F91BDC
	// [Call #8] RVA: 0x101F91BDC
	// [Call #9] RVA: 0x101F91BDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x101FE9F3C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045A3A98
	// [Call #17] RVA: 0x102CE5F08
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x102CE5F08
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Gameplay.UAECharacterAnimListComponent.OnAsyncLoadingFinishedNew2
	// Flags: [Final|Native|Public]
	// Offset: 0x10465a1c0
	// Params: [ Num(1) Size(0x28) ]
	void OnAsyncLoadingFinishedNew2(struct FAsyncLoadCharAnimParams LoadingParam);
	// [Call #1] RVA: 0x104661DB4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045C957C
	// [Call #5] RVA: 0x1045A2408
	// [Call #6] RVA: 0x101F91BDC
	// [Call #7] RVA: 0x101F91BDC
	// [Call #8] RVA: 0x101F91BDC
	// [Call #9] RVA: 0x101F91BDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104661DB4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C957C
	// [Call #15] RVA: 0x10459D7C8
	// [Call #16] RVA: 0x101F91BDC
	// [Call #17] RVA: 0x101F91BDC
	// [Call #18] RVA: 0x101F91BDC
	// [Call #19] RVA: 0x101F91BDC
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x101FE9F3C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168

	// Object: Function Gameplay.UAECharacterAnimListComponent.OnAsyncLoadingFinishedNew
	// Flags: [Final|Native|Public]
	// Offset: 0x10465a0f4
	// Params: [ Num(1) Size(0x28) ]
	void OnAsyncLoadingFinishedNew(struct FAsyncLoadCharAnimParams LoadingParam);
	// [Call #1] RVA: 0x104661DB4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045C957C
	// [Call #5] RVA: 0x1045A02B4
	// [Call #6] RVA: 0x101F91BDC
	// [Call #7] RVA: 0x101F91BDC
	// [Call #8] RVA: 0x101F91BDC
	// [Call #9] RVA: 0x101F91BDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104661DB4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045C957C
	// [Call #15] RVA: 0x1045A2408
	// [Call #16] RVA: 0x101F91BDC
	// [Call #17] RVA: 0x101F91BDC
	// [Call #18] RVA: 0x101F91BDC
	// [Call #19] RVA: 0x101F91BDC
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x104661DB4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x1045C957C
	// [Call #25] RVA: 0x10459D7C8
	// [Call #26] RVA: 0x101F91BDC
	// [Call #27] RVA: 0x101F91BDC
	// [Call #28] RVA: 0x101F91BDC

	// Object: Function Gameplay.UAECharacterAnimListComponent.InitAnimListMap
	// Flags: [Final|Native|Public]
	// Offset: 0x10465a070
	// Params: [ Num(1) Size(0x1) ]
	void InitAnimListMap(bool IsFPP);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A3B14
	// [Call #4] RVA: 0x104661DB4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045C957C
	// [Call #8] RVA: 0x1045A02B4
	// [Call #9] RVA: 0x101F91BDC
	// [Call #10] RVA: 0x101F91BDC
	// [Call #11] RVA: 0x101F91BDC
	// [Call #12] RVA: 0x101F91BDC
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104661DB4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045C957C
	// [Call #18] RVA: 0x1045A2408
	// [Call #19] RVA: 0x101F91BDC
	// [Call #20] RVA: 0x101F91BDC
	// [Call #21] RVA: 0x101F91BDC
	// [Call #22] RVA: 0x101F91BDC
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x104661DB4

	// Object: Function Gameplay.UAECharacterAnimListComponent.GetCharacterShovelAnim
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10465a00c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FPlayerAnimData> GetCharacterShovelAnim();
	// [Call #1] RVA: 0x1045A3040
	// [Call #2] RVA: 0x102FC6F24
	// [Call #3] RVA: 0x102CEAAC0
	// [Call #4] RVA: 0x102CEAAC0
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045A3B14
	// [Call #9] RVA: 0x104661DB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045C957C
	// [Call #13] RVA: 0x1045A02B4
	// [Call #14] RVA: 0x101F91BDC
	// [Call #15] RVA: 0x101F91BDC
	// [Call #16] RVA: 0x101F91BDC
	// [Call #17] RVA: 0x101F91BDC
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x104661DB4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1045C957C
	// [Call #23] RVA: 0x1045A2408
	// [Call #24] RVA: 0x101F91BDC
	// [Call #25] RVA: 0x101F91BDC

	// Object: Function Gameplay.UAECharacterAnimListComponent.GetCharacterJumpAnim
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104659f58
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FPlayerAnimData> GetCharacterJumpAnim(enum class ECharacterJumpType JumpType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A2FB0
	// [Call #4] RVA: 0x102FC6F24
	// [Call #5] RVA: 0x102CEAAC0
	// [Call #6] RVA: 0x102CEAAC0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045A3040
	// [Call #9] RVA: 0x102FC6F24
	// [Call #10] RVA: 0x102CEAAC0
	// [Call #11] RVA: 0x102CEAAC0
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045A3B14
	// [Call #16] RVA: 0x104661DB4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1045C957C
	// [Call #20] RVA: 0x1045A02B4
	// [Call #21] RVA: 0x101F91BDC
	// [Call #22] RVA: 0x101F91BDC
	// [Call #23] RVA: 0x101F91BDC

	// Object: Function Gameplay.UAECharacterAnimListComponent.GetAnimationAsset
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104659e6c
	// Params: [ Num(2) Size(0x30) ]
	struct UAnimationAsset* GetAnimationAsset(struct UAnimationAsset*& AnimPtr);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045A0130
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045A2FB0
	// [Call #11] RVA: 0x102FC6F24
	// [Call #12] RVA: 0x102CEAAC0
	// [Call #13] RVA: 0x102CEAAC0
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1045A3040
	// [Call #16] RVA: 0x102FC6F24
	// [Call #17] RVA: 0x102CEAAC0
	// [Call #18] RVA: 0x102CEAAC0
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
};

// Object: Class Gameplay.UAECharacterAnimListSubSystem
// Size: 0x80 (Inherited: 0x30)
struct UUAECharacterAnimListSubSystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x50]; // 0x30(0x50)
};

// Object: Class Gameplay.UAEChaVehAnimListComponent
// Size: 0x308 (Inherited: 0x2D8)
struct UUAEChaVehAnimListComponent : UUAECharAnimListCompBase
{
	bool DefaultLoadAllAnim; // 0x2D8(0x1)
	uint8_t Pad_0x2D9[0x7]; // 0x2D9(0x7)
	struct TArray<struct FVehCharAnimData> VehCharAnimDataList; // 0x2E0(0x10)
	uint8_t Pad_0x2F0[0x18]; // 0x2F0(0x18)


	// Object: Function Gameplay.UAEChaVehAnimListComponent.SetVehCharAnimDataList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10465bb24
	// Params: [ Num(1) Size(0x10) ]
	void SetVehCharAnimDataList(struct TArray<struct FVehCharAnimData> InVehCharAnimDataList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103BEC82C
	// [Call #4] RVA: 0x1045A56E8
	// [Call #5] RVA: 0x102E64C30
	// [Call #6] RVA: 0x102E64C30
	// [Call #7] RVA: 0x102E64C30
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x102E64C30
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaVehAnimListComponent.OnIdleAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x10465bb10
	// Params: [ Num(0) Size(0x0) ]
	void OnIdleAnimListAsyncLoadingFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103BEC82C
	// [Call #4] RVA: 0x1045A56E8
	// [Call #5] RVA: 0x102E64C30
	// [Call #6] RVA: 0x102E64C30
	// [Call #7] RVA: 0x102E64C30
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x102E64C30
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Gameplay.UAEChaVehAnimListComponent.OnAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x10465ba38
	// Params: [ Num(1) Size(0x18) ]
	void OnAnimListAsyncLoadingFinished(struct FAsyncLoadCharVehAnimParams LoadingParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045CA2D0
	// [Call #4] RVA: 0x1045A4FFC
	// [Call #5] RVA: 0x101F91BDC
	// [Call #6] RVA: 0x101F91BDC
	// [Call #7] RVA: 0x101F91BDC
	// [Call #8] RVA: 0x101F91BDC
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x103BEC82C
	// [Call #13] RVA: 0x1045A56E8
	// [Call #14] RVA: 0x102E64C30
	// [Call #15] RVA: 0x102E64C30
	// [Call #16] RVA: 0x102E64C30
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x102E64C30
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C
	// [Call #22] RVA: 0x105190870

	// Object: Function Gameplay.UAEChaVehAnimListComponent.ChangeAnimData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10465b990
	// Params: [ Num(1) Size(0x10) ]
	void ChangeAnimData(struct TArray<struct FVehCharAnimData>& InAnimData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045A5628
	// [Call #4] RVA: 0x102E64C30
	// [Call #5] RVA: 0x102E64C30
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045CA2D0
	// [Call #10] RVA: 0x1045A4FFC
	// [Call #11] RVA: 0x101F91BDC
	// [Call #12] RVA: 0x101F91BDC
	// [Call #13] RVA: 0x101F91BDC
	// [Call #14] RVA: 0x101F91BDC
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x103BEC82C
	// [Call #19] RVA: 0x1045A56E8
	// [Call #20] RVA: 0x102E64C30
	// [Call #21] RVA: 0x102E64C30
	// [Call #22] RVA: 0x102E64C30
};

// Object: Class Gameplay.UAEIndependentSpot
// Size: 0x4B0 (Inherited: 0x4B0)
struct AUAEIndependentSpot : AActor
{
	bool bIsEditorOnly; // 0x4A9(0x1)
	uint8_t SpotType; // 0x4AA(0x1)
};

// Object: Class Gameplay.UAELevelSequenceActor
// Size: 0x780 (Inherited: 0x550)
struct AUAELevelSequenceActor : ALevelSequenceActor
{
	uint8_t Pad_0x550[0x58]; // 0x550(0x58)
	bool bPlayOnServer; // 0x5A8(0x1)
	uint8_t Pad_0x5A9[0x3]; // 0x5A9(0x3)
	float ClientSyncTime; // 0x5AC(0x4)
	bool bUseSelfTransformOrigin; // 0x5B0(0x1)
	bool bAutoDestroy; // 0x5B1(0x1)
	uint8_t Pad_0x5B2[0x2]; // 0x5B2(0x2)
	float DestroySelfDelayTime; // 0x5B4(0x4)
	bool bInitPlayerBeforeBeginPlay; // 0x5B8(0x1)
	uint8_t RelevantType; // 0x5B9(0x1)
	bool bCameraOnlyOwnerUse; // 0x5BA(0x1)
	enum class ELevelSequenceStartPlayType LevelSequenceStartPlayType; // 0x5BB(0x1)
	uint8_t Pad_0x5BC[0x4]; // 0x5BC(0x4)
	struct TArray<struct FMovieSceneBindingOverrideData> NetSyncBindingData; // 0x5C0(0x10)
	float AuthorityStartPlayTime; // 0x5D0(0x4)
	uint8_t Pad_0x5D4[0x4]; // 0x5D4(0x4)
	struct FString LevelSequenceAssetPath; // 0x5D8(0x10)
	struct TMap<struct FString, struct FString> GreenSequenceMap; // 0x5E8(0x50)
	uint8_t Pad_0x638[0x8]; // 0x638(0x8)
	struct TArray<struct FSeqActorBindingData> TrackBindingData; // 0x640(0x10)
	struct TArray<struct FString> DisabledTrackNames; // 0x650(0x10)
	uint8_t Pad_0x660[0x50]; // 0x660(0x50)
	struct FString LuaFilePath; // 0x6B0(0x10)
	struct FLuaNetSerialization LuaNetSerialization; // 0x6C0(0x50)
	uint8_t Pad_0x710[0x18]; // 0x710(0x18)
	bool bIsCheckOwnerPassWall; // 0x728(0x1)
	uint8_t Pad_0x729[0x7]; // 0x729(0x7)
	struct TArray<struct AActor*> OwnerPassWallIgnoreActors; // 0x730(0x10)
	struct TArray<enum class ECollisionChannel> PasswallIgnoreChannels; // 0x740(0x10)
	struct FVector OwnerStartLoc; // 0x750(0xC)
	struct FVector LastValidLoc; // 0x75C(0xC)
	uint8_t Pad_0x768[0x1]; // 0x768(0x1)
	bool bIsCheckOwnerSnapToFloor; // 0x769(0x1)
	uint8_t Pad_0x76A[0x2]; // 0x76A(0x2)
	float OwnerSnapToFloorMaxDist; // 0x76C(0x4)
	uint8_t Pad_0x770[0x10]; // 0x770(0x10)


	// Object: Function Gameplay.UAELevelSequenceActor.UpdateTrackBindingData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104668538
	// Params: [ Num(0) Size(0x0) ]
	void UpdateTrackBindingData();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.UAELevelSequenceActor.UpdateSequence
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104668498
	// Params: [ Num(1) Size(0x10) ]
	void UpdateSequence(struct FString LevelSequencePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Gameplay.UAELevelSequenceActor.UpdatePlayback
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104668330
	// Params: [ Num(4) Size(0x4) ]
	void UpdatePlayback(bool bRestoreState, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.UAELevelSequenceActor.UpdateInstanceData
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104668250
	// Params: [ Num(2) Size(0x18) ]
	void UpdateInstanceData(struct FVector& OffsetVector, struct FRotator& OffsetRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.StopMontageParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046681d4
	// Params: [ Num(1) Size(0x8) ]
	void StopMontageParticle(struct FName SlotName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B4890
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Gameplay.UAELevelSequenceActor.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046681c0
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B4890
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.SetUseSelfTransformOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10466813c
	// Params: [ Num(1) Size(0x1) ]
	void SetUseSelfTransformOrigin(bool bInUse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B3B48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045B4890
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.SetTrackBindingInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x50) ]
	void SetTrackBindingInfo(struct TMap<struct FString, struct FString>& TrackBindingInfo);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.SetTrackBindingData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104668094
	// Params: [ Num(1) Size(0x10) ]
	void SetTrackBindingData(struct TArray<struct FSeqActorBindingData>& InTrackBindingData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B3CB0
	// [Call #4] RVA: 0x103F9DFD8
	// [Call #5] RVA: 0x103F9DFD8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B3B48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045B4890
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.SetNetSyncBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104667f38
	// Params: [ Num(3) Size(0x29) ]
	void SetNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B56F8
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045B3CB0
	// [Call #14] RVA: 0x103F9DFD8
	// [Call #15] RVA: 0x103F9DFD8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.SetLevelSequenceAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667ea0
	// Params: [ Num(1) Size(0x10) ]
	void SetLevelSequenceAssetPath(struct FString InLevelSequenceAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B3A80
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045B56F8
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.SetDisabledTrackNames
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104667df8
	// Params: [ Num(1) Size(0x10) ]
	void SetDisabledTrackNames(struct TArray<struct FString>& InDisabledTrackNames);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B4030
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B3A80
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.ResetNetSyncBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667de4
	// Params: [ Num(0) Size(0x0) ]
	void ResetNetSyncBindings();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B4030
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B3A80
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.ResetNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667d44
	// Params: [ Num(1) Size(0x18) ]
	void ResetNetSyncBinding(struct FMovieSceneObjectBindingID Binding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B5B84
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045B4030
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045B3A80
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.UAELevelSequenceActor.RemoveNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667c68
	// Params: [ Num(2) Size(0x20) ]
	void RemoveNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045B59DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5B84
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B4030
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAELevelSequenceActor.ReleaseCameraCutTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667c54
	// Params: [ Num(0) Size(0x0) ]
	void ReleaseCameraCutTrack();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045B59DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5B84
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B4030
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnStop
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnStop();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnPreStop
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnPreStop();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnPlayReverse
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnPlayReverse();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnPlay();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnPause
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnPause();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnObjectSpawned
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x18) ]
	void ReceiveOnObjectSpawned(struct UObject* InObject, struct FGuid& InBindingID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.ReceiveOnFinished
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveOnFinished();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAELevelSequenceActor.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667bd8
	// Params: [ Num(1) Size(0x4) ]
	void Play(float InPlaytime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B5B84
	// [Call #12] RVA: 0x10516D168

	// Object: Function Gameplay.UAELevelSequenceActor.OnSequenceFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x104667bc4
	// Params: [ Num(0) Size(0x0) ]
	void OnSequenceFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B5B84

	// Object: Function Gameplay.UAELevelSequenceActor.OnRep_NetSyncBindingData
	// Flags: [Final|Native|Public]
	// Offset: 0x104667bb0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_NetSyncBindingData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B5B84

	// Object: Function Gameplay.UAELevelSequenceActor.OnRep_LevelSequenceAssetPath
	// Flags: [Final|Native|Protected]
	// Offset: 0x104667b9c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LevelSequenceAssetPath();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B5B84

	// Object: Function Gameplay.UAELevelSequenceActor.OnRep_DisabledTrackNames
	// Flags: [Final|Native|Protected]
	// Offset: 0x104667b88
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_DisabledTrackNames();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B5B84

	// Object: Function Gameplay.UAELevelSequenceActor.OnRep_bUseSelfTransformOrigin
	// Flags: [Final|Native|Protected]
	// Offset: 0x104667b74
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_bUseSelfTransformOrigin();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.OnRep_AuthorityStartPlayTime
	// Flags: [Final|Native|Protected]
	// Offset: 0x104667b60
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_AuthorityStartPlayTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B41F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B59DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.OnObjectSpawnedEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x104667a50
	// Params: [ Num(3) Size(0x1C) ]
	void OnObjectSpawnedEvent(struct UObject* InObject, struct FGuid& InBindingID, struct FMovieSceneSequenceID InSequenceID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B5084
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045B41F8

	// Object: Function Gameplay.UAELevelSequenceActor.HasActiveSequenceActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104667a1c
	// Params: [ Num(1) Size(0x1) ]
	bool HasActiveSequenceActor();
	// [Call #1] RVA: 0x1045B1CD4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5084
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B41F8

	// Object: Function Gameplay.UAELevelSequenceActor.HandleOwnerReady
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x104667a00
	// Params: [ Num(0) Size(0x0) ]
	void HandleOwnerReady();
	// [Call #1] RVA: 0x1045B1CD4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5084
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B41F8

	// Object: Function Gameplay.UAELevelSequenceActor.GoToEndAndStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046679ec
	// Params: [ Num(0) Size(0x0) ]
	void GoToEndAndStop();
	// [Call #1] RVA: 0x1045B1CD4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5084
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045B41F8

	// Object: Function Gameplay.UAELevelSequenceActor.GetPossessableOrSpawnableByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667930
	// Params: [ Num(2) Size(0x28) ]
	struct FMovieSceneObjectBindingID GetPossessableOrSpawnableByName(struct FString NameKeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B3D94
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045B1CD4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045B5084

	// Object: Function Gameplay.UAELevelSequenceActor.GetFirstPossessableTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046678e4
	// Params: [ Num(1) Size(0x18) ]
	struct FMovieSceneObjectBindingID GetFirstPossessableTrack();
	// [Call #1] RVA: 0x1045B5FC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045B3D94
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045B1CD4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104667774
	// Params: [ Num(5) Size(0x48) ]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* InLevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct AUAELevelSequenceActor*& OutActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B2924
	// [Call #10] RVA: 0x1045B5FC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045B3D94
	// [Call #14] RVA: 0x101F8130C

	// Object: Function Gameplay.UAELevelSequenceActor.CheckStartPlayValid
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104667738
	// Params: [ Num(1) Size(0x1) ]
	bool CheckStartPlayValid();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B2924
	// [Call #10] RVA: 0x1045B5FC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Gameplay.UAELevelSequenceActor.AddNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104667618
	// Params: [ Num(3) Size(0x21) ]
	void AddNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B3ED4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
};

// Object: Class Gameplay.AELobbyCharAnimListComp
// Size: 0x338 (Inherited: 0x2D8)
struct UAELobbyCharAnimListComp : UUAECharAnimListCompBase
{
	struct TArray<struct FLobbyCharacterWeaponAnimData> CharacterWeaponAnimEditList; // 0x2D8(0x10)
	struct TArray<struct FLobbyCharacterWeaponAnimData> AvatarSceneCharacterWeaponAnimEditList; // 0x2E8(0x10)
	struct TArray<struct FLobbyCharacterWeaponAnimData> LobbyWithCarCharacterWeaponAnimEditList; // 0x2F8(0x10)
	struct TArray<struct FLobbyCharacterWeaponAnimData> LobbySystemCharacterWeaponAnimEditList; // 0x308(0x10)
	struct UAnimationAsset* SwitchPoseAnimAdd; // 0x318(0x8)
	int resultAvatarPoseIndex; // 0x320(0x4)
	uint8_t Pad_0x324[0x14]; // 0x324(0x14)


	// Object: Function Gameplay.AELobbyCharAnimListComp.OnAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x1046698bc
	// Params: [ Num(1) Size(0x20) ]
	void OnAsyncLoadingFinished(struct FLobbyAsyncLoadCharAnimParams LoadingParam);
	// [Call #1] RVA: 0x1045CD210
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1045CD24C
	// [Call #5] RVA: 0x1045B7984
	// [Call #6] RVA: 0x101F91BDC
	// [Call #7] RVA: 0x101F91BDC
	// [Call #8] RVA: 0x101F91BDC
	// [Call #9] RVA: 0x101F91BDC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function Gameplay.AELobbyCharAnimListComp.InitPendingList
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046697a4
	// Params: [ Num(2) Size(0x20) ]
	void InitPendingList(struct TArray<struct FLobbyCharacterWeaponAnimData>& animEditList, struct TArray<struct FSoftObjectPath>& PendingList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045B76C4
	// [Call #6] RVA: 0x102102810
	// [Call #7] RVA: 0x1033F7C94
	// [Call #8] RVA: 0x102102810
	// [Call #9] RVA: 0x1033F7C94
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1045CD210
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045CD24C
	// [Call #15] RVA: 0x1045B7984
	// [Call #16] RVA: 0x101F91BDC
	// [Call #17] RVA: 0x101F91BDC
	// [Call #18] RVA: 0x101F91BDC
	// [Call #19] RVA: 0x101F91BDC
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C

	// Object: Function Gameplay.AELobbyCharAnimListComp.GetCharacterAnim
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104669664
	// Params: [ Num(5) Size(0x18) ]
	struct UAnimationAsset* GetCharacterAnim(enum class ELobbyCharacterPosIndex PosIdx, enum class ELobbyCharacterAnimType GenderType, int WeaponAnimType, enum class ECharacterShowSceneType sceneType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045B7AE0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045B76C4
	// [Call #15] RVA: 0x102102810
	// [Call #16] RVA: 0x1033F7C94
	// [Call #17] RVA: 0x102102810
	// [Call #18] RVA: 0x1033F7C94
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Gameplay.AELobbyCharAnimListComp.BuildAnimMap
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104669570
	// Params: [ Num(2) Size(0x11) ]
	void BuildAnimMap(struct TArray<struct FLobbyCharacterWeaponAnimData>& AnimList, enum class ECharacterShowSceneType sceneType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045B7BF8
	// [Call #6] RVA: 0x1033F7C94
	// [Call #7] RVA: 0x1033F7C94
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045B7AE0
};

// Object: Class Gameplay.UAESimpleSceneActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct AUAESimpleSceneActor : AActor
{
};

// Object: Class Gameplay.UAESpawnActorComponent
// Size: 0x178 (Inherited: 0x178)
struct UUAESpawnActorComponent : UActorComponent
{

	// Object: Function Gameplay.UAESpawnActorComponent.UAESpawnActor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10467e22c
	// Params: [ Num(2) Size(0x98) ]
	struct AActor* UAESpawnActor(struct FUAESpawnActorParam Param);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104683800
	// [Call #4] RVA: 0x103832010
	// [Call #5] RVA: 0x103832010
	// [Call #6] RVA: 0x103832010
	// [Call #7] RVA: 0x103832010
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Gameplay.UAESpawnActorComponent.PrepareSpawnData
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467e198
	// Params: [ Num(2) Size(0x10) ]
	struct UObject* PrepareSpawnData(int TemplateID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104683800
	// [Call #6] RVA: 0x103832010
	// [Call #7] RVA: 0x103832010
	// [Call #8] RVA: 0x103832010
	// [Call #9] RVA: 0x103832010
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Gameplay.UAESpawnActorComponent.InitializeActor
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10467e0d8
	// Params: [ Num(2) Size(0xC) ]
	void InitializeActor(struct AActor* InActor, int TemplateID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104683800
	// [Call #10] RVA: 0x103832010
	// [Call #11] RVA: 0x103832010
	// [Call #12] RVA: 0x103832010
};

// Object: Class Gameplay.UAESpotGroupObject
// Size: 0x90 (Inherited: 0x28)
struct UUAESpotGroupObject : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct UObject* Host; // 0x80(0x8)
	uint8_t Pad_0x88[0x8]; // 0x88(0x8)
};

// Object: Class Gameplay.UAEWindowComponent
// Size: 0xC40 (Inherited: 0xBD0)
struct UUAEWindowComponent : UStaticMeshComponent
{
	int ID; // 0xBC8(0x4)
	bool bBroken; // 0xBCC(0x1)
	struct APawn* LastInstigatorPawn; // 0xBD0(0x8)
	struct UStaticMesh* BrokenMesh; // 0xBD8(0x8)
	struct UParticleSystem* BrokenEffect; // 0xBE0(0x8)
	uint8_t Pad_0xBED[0x53]; // 0xBED(0x53)


	// Object: Function Gameplay.UAEWindowComponent.NotifyServerBroken
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void NotifyServerBroken(struct APlayerController* Instigator);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEWindowComponent.NotifyRepDataUpdated
	// Flags: [Final|Native|Protected]
	// Offset: 0x10467eb18
	// Params: [ Num(2) Size(0x2) ]
	void NotifyRepDataUpdated(bool bInitial, bool bLocal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E5D8C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Gameplay.UAEWindowComponent.LocalHandleWindowBrokenBP
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x2) ]
	void LocalHandleWindowBrokenBP(bool bInitial, bool bLocal);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.UAEWindowComponent.LocalHandleWindowBroken
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10467ea48
	// Params: [ Num(2) Size(0x2) ]
	void LocalHandleWindowBroken(bool bInitial, bool bLocal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E5DCC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E5D8C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Gameplay.UAEWindowComponent.HandleBroken
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467e988
	// Params: [ Num(2) Size(0x9) ]
	void HandleBroken(struct APlayerController* Instigator, bool bLocal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E36C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E5DCC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E5D8C

	// Object: Function Gameplay.UAEWindowComponent.GetRepData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467e920
	// Params: [ Num(1) Size(0x50) ]
	struct FUAEWindowRepData GetRepData();
	// [Call #1] RVA: 0x1045E5DA0
	// [Call #2] RVA: 0x104686208
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045E36C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E5DCC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class Gameplay.VehicleConfigActorComponent
// Size: 0x178 (Inherited: 0x178)
struct UVehicleConfigActorComponent : UActorComponent
{

	// Object: Function Gameplay.VehicleConfigActorComponent.LoadActorClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467ef00
	// Params: [ Num(2) Size(0x18) ]
	struct UObject* LoadActorClass(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1045E5EBC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
};

// Object: Class Gameplay.VehicleAndTreasureBoxGeneratorComponent
// Size: 0x650 (Inherited: 0x338)
struct UVehicleAndTreasureBoxGeneratorComponent : UBaseGeneratorComponent
{
	bool bUseLocalSpotFile; // 0x338(0x1)
	bool bCanBackupVehicleSpotDatas; // 0x339(0x1)
	uint8_t Pad_0x33A[0x6]; // 0x33A(0x6)
	struct TArray<struct UVehicleSpotSceneComponent*> VehicleSpotSceneComponentList; // 0x340(0x10)
	enum class ERegionType RegionType; // 0x350(0x1)
	uint8_t Pad_0x351[0x7]; // 0x351(0x7)
	struct TArray<struct FBackupVehicleSpotData> BackupVehicleSpotDatas; // 0x358(0x10)
	struct TArray<struct FVehicleSpotProperty> VehicleSpotPropertys; // 0x368(0x10)
	struct TArray<struct FTreasureBoxSpotProperty> TreasureBoxSpotPropertys; // 0x378(0x10)
	bool bStatisticsValid; // 0x388(0x1)
	bool bIsRandom; // 0x389(0x1)
	uint8_t Pad_0x38A[0x6]; // 0x38A(0x6)
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllVehicleSpots; // 0x390(0x50)
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllTreasureBoxSpots; // 0x3E0(0x50)
	struct TMap<struct FString, struct FVehicleGenerateSpawnDataArray> VehicleGenerateSpawnDatas; // 0x430(0x50)
	struct FVehicleGenerateStatisticsData VehicleStatisticsData; // 0x480(0x60)
	struct UUAEDataTable* VehicleDataTable; // 0x4E0(0x8)
	struct TArray<struct FBackupVehicleSpotData> AllDynamicVehicleSpot; // 0x4E8(0x10)
	bool bRemovableMode; // 0x4F8(0x1)
	uint8_t Pad_0x4F9[0x7]; // 0x4F9(0x7)
	struct TSet<struct TWeakObjectPtr<struct UVehicleSpotObject>> PauseVehicleSpotObjectSet; // 0x500(0x50)
	struct TArray<struct TWeakObjectPtr<struct AActor>> GeneratedActorArray; // 0x550(0x10)
	uint8_t Pad_0x560[0x18]; // 0x560(0x18)
	struct FScriptMulticastDelegate OnVehicleGeneratedDelegate; // 0x578(0x10)
	struct FScriptMulticastDelegate OnVehicleGenerateEndDelegate; // 0x588(0x10)
	DelegateProperty CanGenerateVehicleDelegate; // 0x598(0x10)
	struct TSet<struct FString> IgnoreClassPathSet; // 0x5A8(0x50)
	bool bEnableLevelIndex; // 0x5F8(0x1)
	uint8_t Pad_0x5F9[0x57]; // 0x5F9(0x57)


	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsFromSpotFile
	// Flags: [Final|Native|Public]
	// Offset: 0x104680c64
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleSpotStatisticsFromSpotFile();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	// Offset: 0x104680c50
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleSpotStatisticsDatas_V15();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104680c3c
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleSpotStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleClassStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	// Offset: 0x104680c28
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleClassStatisticsDatas_V15();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x104680c14
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleClassStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatasToLog
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104680c00
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllVehicleStatisticsDatasToLog();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatas_V15
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104680bec
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllVehicleStatisticsDatas_V15();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatas
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104680bd8
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllVehicleStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.SetAllVehicleNumRate
	// Flags: [Final|Native|Public]
	// Offset: 0x104680b18
	// Params: [ Num(1) Size(0x50) ]
	void SetAllVehicleNumRate(struct TMap<struct FString, float> Rates);
	// [Call #1] RVA: 0x101F865E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F86BAC
	// [Call #5] RVA: 0x1045E6AC8
	// [Call #6] RVA: 0x101F87D90
	// [Call #7] RVA: 0x101F87D90
	// [Call #8] RVA: 0x101F87D90
	// [Call #9] RVA: 0x101F87D90
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.ResumeGenerate
	// Flags: [Final|Native|Public]
	// Offset: 0x104680b04
	// Params: [ Num(0) Size(0x0) ]
	void ResumeGenerate();
	// [Call #1] RVA: 0x101F865E4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F86BAC
	// [Call #5] RVA: 0x1045E6AC8
	// [Call #6] RVA: 0x101F87D90
	// [Call #7] RVA: 0x101F87D90
	// [Call #8] RVA: 0x101F87D90
	// [Call #9] RVA: 0x101F87D90
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RegisterVehicleGenerateSpawnData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104680a54
	// Params: [ Num(1) Size(0x30) ]
	void RegisterVehicleGenerateSpawnData(struct FVehicleGenerateSpawnData& Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E65D8
	// [Call #4] RVA: 0x1045EEE64
	// [Call #5] RVA: 0x1045EEE64
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F865E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F86BAC
	// [Call #11] RVA: 0x1045E6AC8
	// [Call #12] RVA: 0x101F87D90
	// [Call #13] RVA: 0x101F87D90
	// [Call #14] RVA: 0x101F87D90
	// [Call #15] RVA: 0x101F87D90
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RegisterSpotFromSingleFile
	// Flags: [Final|Native|Public]
	// Offset: 0x104680970
	// Params: [ Num(1) Size(0x10) ]
	void RegisterSpotFromSingleFile(struct FString SpotFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1045E7EA4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E65D8
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x1045EEE64
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x101F865E4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F86BAC
	// [Call #22] RVA: 0x1045E6AC8
	// [Call #23] RVA: 0x101F87D90
	// [Call #24] RVA: 0x101F87D90
	// [Call #25] RVA: 0x101F87D90

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1046808ec
	// Params: [ Num(1) Size(0x8) ]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045E7EA4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045E65D8
	// [Call #17] RVA: 0x1045EEE64
	// [Call #18] RVA: 0x1045EEE64
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x101F865E4

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomTreasureBoxSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1046807c4
	// Params: [ Num(2) Size(0x38) ]
	void RandomTreasureBoxSpotsByType(struct FTreasureBoxSpotProperty& Property, struct FVehicleSpotComponentArray& Spots);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E8DBC
	// [Call #6] RVA: 0x1045EF240
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x1045EF240
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x1045E7EA4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomTreasureBoxSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1046806a8
	// Params: [ Num(2) Size(0x30) ]
	void RandomTreasureBoxSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FTreasureBoxSpotProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E9900
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E8DBC
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104680580
	// Params: [ Num(2) Size(0x50) ]
	void RandomSpotsByType(struct FVehicleSpotProperty& Property, struct FVehicleSpotComponentArray& Spots);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E8C88
	// [Call #6] RVA: 0x1045EF240
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x1045EF240
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E9900
	// [Call #16] RVA: 0x102362AB0
	// [Call #17] RVA: 0x1045EF240
	// [Call #18] RVA: 0x102362AB0
	// [Call #19] RVA: 0x1045EF240
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104680464
	// Params: [ Num(2) Size(0x48) ]
	void RandomSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FVehicleSpotProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E94E0
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E8C88
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomGroups
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104680448
	// Params: [ Num(0) Size(0x0) ]
	void RandomGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E94E0
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E8C88
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.PauseGenerate
	// Flags: [Final|Native|Public]
	// Offset: 0x104680434
	// Params: [ Num(0) Size(0x0) ]
	void PauseGenerate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E94E0
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045E8C88
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.LoadVehicleGenerateTable
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void LoadVehicleGenerateTable();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GMGenerateAllVehicleSpot
	// Flags: [Final|Native|Public]
	// Offset: 0x104680340
	// Params: [ Num(2) Size(0x11) ]
	bool GMGenerateAllVehicleSpot(struct FString VehiclePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1045EA8F0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1045E94E0
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0
	// [Call #20] RVA: 0x1045EF240
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfoWithCategory
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1046801b4
	// Params: [ Num(3) Size(0x70) ]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoWithCategory(struct FVehicleSpotProperty& SpotProperty, struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045E86AC
	// [Call #7] RVA: 0x1045E8668
	// [Call #8] RVA: 0x103110404
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102362AB0
	// [Call #12] RVA: 0x103110404
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F8122C
	// [Call #22] RVA: 0x1045EA8F0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfoBySpotType
	// Flags: [Final|Native|Public]
	// Offset: 0x1046800a0
	// Params: [ Num(3) Size(0x40) ]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoBySpotType(enum class ESpotType SpotType, struct FString InCategory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E93BC
	// [Call #6] RVA: 0x1045E8668
	// [Call #7] RVA: 0x103110404
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x103110404
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x1045E86AC
	// [Call #18] RVA: 0x1045E8668
	// [Call #19] RVA: 0x103110404
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x102362AB0
	// [Call #23] RVA: 0x103110404

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10467ff5c
	// Params: [ Num(3) Size(0x70) ]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfo(struct FVehicleSpotProperty& SpotProperty, struct FString InCategory);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045E8508
	// [Call #6] RVA: 0x1045E8668
	// [Call #7] RVA: 0x103110404
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x103110404
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102362AB0
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1045E93BC
	// [Call #19] RVA: 0x1045E8668
	// [Call #20] RVA: 0x103110404
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x103110404
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetTreasureBoxSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10467fe78
	// Params: [ Num(2) Size(0x48) ]
	struct FVehicleGenerateRandomInfo GetTreasureBoxSpotRandomInfo(struct FTreasureBoxSpotProperty& SpotProperty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E9404
	// [Call #4] RVA: 0x1045E8668
	// [Call #5] RVA: 0x103110404
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x103110404
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E8508
	// [Call #15] RVA: 0x1045E8668
	// [Call #16] RVA: 0x103110404
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x102362AB0
	// [Call #19] RVA: 0x103110404
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x102362AB0
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetTraceLevelName
	// Flags: [Final|Native|Public]
	// Offset: 0x10467fd68
	// Params: [ Num(3) Size(0x28) ]
	struct FString GetTraceLevelName(struct FString SpotFileName, int16_t LevelIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EA3C4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045E9404
	// [Call #15] RVA: 0x1045E8668
	// [Call #16] RVA: 0x103110404
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x103110404
	// [Call #19] RVA: 0x102362AB0
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetRandomVehicleClass
	// Flags: [Final|Native|Public]
	// Offset: 0x10467fc98
	// Params: [ Num(2) Size(0x40) ]
	struct FVehicleGenerateSpawnData GetRandomVehicleClass(struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E9288
	// [Call #4] RVA: 0x1046868E4
	// [Call #5] RVA: 0x1045EEE64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x1045EEE64
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045EA3C4
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	// Offset: 0x10467fbb0
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E9288
	// [Call #12] RVA: 0x1046868E4
	// [Call #13] RVA: 0x1045EEE64
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetAlreadyGeneratedVehicleNum
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10467fb94
	// Params: [ Num(1) Size(0x4) ]
	int GetAlreadyGeneratedVehicleNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045E9288
	// [Call #12] RVA: 0x1046868E4
	// [Call #13] RVA: 0x1045EEE64
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Protected]
	// Offset: 0x10467fb10
	// Params: [ Num(1) Size(0x4) ]
	void GenerateSpotOnTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045E9288
	// [Call #14] RVA: 0x1046868E4
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x1045EEE64
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.EndGenerate
	// Flags: [Final|Native|Public]
	// Offset: 0x10467fafc
	// Params: [ Num(0) Size(0x0) ]
	void EndGenerate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045E9288
	// [Call #14] RVA: 0x1046868E4
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x1045EEE64

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.EnableRemovableMode
	// Flags: [Final|Native|Public]
	// Offset: 0x10467fae8
	// Params: [ Num(0) Size(0x0) ]
	void EnableRemovableMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045E9288
	// [Call #14] RVA: 0x1046868E4
	// [Call #15] RVA: 0x1045EEE64
	// [Call #16] RVA: 0x101F8130C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.DynamicSpawnVehicleBySpotId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10467f9b4
	// Params: [ Num(3) Size(0x19) ]
	bool DynamicSpawnVehicleBySpotId(int ID, struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045E813C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.DeleteGroups
	// Flags: [Final|Native|Protected]
	// Offset: 0x10467f9a0
	// Params: [ Num(0) Size(0x0) ]
	void DeleteGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1045E813C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.CanDynamicSpawnVehicle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10467f894
	// Params: [ Num(4) Size(0x25) ]
	bool CanDynamicSpawnVehicle(struct FVector SpawnLocation, struct FVector TestLocationOffset, struct FVector TestBoxSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045E8798
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x1045E813C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.AddVehicleSpotCount
	// Flags: [Final|Native|Protected]
	// Offset: 0x10467f6b0
	// Params: [ Num(5) Size(0x24) ]
	void AddVehicleSpotCount(enum class ESpotType SpotType, struct FString Path, float LocationX, float LocationY, float LocationZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1045EA744
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.AddVehicleClassCount
	// Flags: [Final|Native|Protected]
	// Offset: 0x10467f53c
	// Params: [ Num(3) Size(0x18) ]
	void AddVehicleClassCount(struct FString Path, bool IsValid, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1045EA748
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.AddIgnoreClassPath
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10467f494
	// Params: [ Num(1) Size(0x10) ]
	void AddIgnoreClassPath(struct TArray<struct FString>& IgnoreItemClassList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045EA768
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x1045EA748
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
};

// Object: Class Gameplay.VehicleGeneratorComponent
// Size: 0x450 (Inherited: 0x338)
struct UVehicleGeneratorComponent : UBaseGeneratorComponent
{
	struct TArray<struct FVehicleSpotProperty> VehicleSpotPropertys; // 0x338(0x10)
	bool bStatisticsValid; // 0x348(0x1)
	bool bIsRandom; // 0x349(0x1)
	uint8_t Pad_0x34A[0x6]; // 0x34A(0x6)
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllVehicleSpots; // 0x350(0x50)
	struct TMap<struct FString, struct FVehicleGenerateSpawnDataArray> VehicleGenerateSpawnDatas; // 0x3A0(0x50)
	struct FVehicleGenerateStatisticsData VehicleStatisticsData; // 0x3F0(0x60)


	// Object: Function Gameplay.VehicleGeneratorComponent.WriteVehicleSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046823e4
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleSpotStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleGeneratorComponent.WriteVehicleClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046823d0
	// Params: [ Num(0) Size(0x0) ]
	void WriteVehicleClassStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleGeneratorComponent.WriteAllVehicleStatisticsDatas
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1046823bc
	// Params: [ Num(0) Size(0x0) ]
	void WriteAllVehicleStatisticsDatas();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleGeneratorComponent.RegisterVehicleGenerateSpawnData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1046822f8
	// Params: [ Num(1) Size(0x30) ]
	void RegisterVehicleGenerateSpawnData(struct FVehicleGenerateSpawnData Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045EEF08
	// [Call #4] RVA: 0x1045EB218
	// [Call #5] RVA: 0x1045EEE64
	// [Call #6] RVA: 0x1045EEE64
	// [Call #7] RVA: 0x1045EEE64
	// [Call #8] RVA: 0x1045EEE64
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104682274
	// Params: [ Num(1) Size(0x8) ]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EEF08
	// [Call #6] RVA: 0x1045EB218
	// [Call #7] RVA: 0x1045EEE64
	// [Call #8] RVA: 0x1045EEE64
	// [Call #9] RVA: 0x1045EEE64
	// [Call #10] RVA: 0x1045EEE64
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function Gameplay.VehicleGeneratorComponent.RandomSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10468214c
	// Params: [ Num(2) Size(0x50) ]
	void RandomSpotsByType(struct FVehicleSpotProperty& Property, struct FVehicleSpotComponentArray& Spots);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EAEEC
	// [Call #6] RVA: 0x1045EF240
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x1045EF240
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045EEF08
	// [Call #16] RVA: 0x1045EB218
	// [Call #17] RVA: 0x1045EEE64
	// [Call #18] RVA: 0x1045EEE64
	// [Call #19] RVA: 0x1045EEE64

	// Object: Function Gameplay.VehicleGeneratorComponent.RandomSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104682030
	// Params: [ Num(2) Size(0x48) ]
	void RandomSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FVehicleSpotProperty& Property);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EB72C
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045EAEEC
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Gameplay.VehicleGeneratorComponent.RandomGroups
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104682014
	// Params: [ Num(0) Size(0x0) ]
	void RandomGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EB72C
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045EAEEC
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0
	// [Call #18] RVA: 0x1045EF240
	// [Call #19] RVA: 0x102362AB0

	// Object: Function Gameplay.VehicleGeneratorComponent.LoadVehicleGenerateTable
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x104681ff8
	// Params: [ Num(0) Size(0x0) ]
	void LoadVehicleGenerateTable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045EB72C
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x1045EF240
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x1045EF240
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045EAEEC
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x102362AB0

	// Object: Function Gameplay.VehicleGeneratorComponent.GetVehicleSpotRandomInfoBySpotType
	// Flags: [Final|Native|Public]
	// Offset: 0x104681f3c
	// Params: [ Num(2) Size(0x30) ]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoBySpotType(enum class ESpotType SpotType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045EB588
	// [Call #4] RVA: 0x1045E8668
	// [Call #5] RVA: 0x103110404
	// [Call #6] RVA: 0x103110404
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045EB72C
	// [Call #13] RVA: 0x102362AB0
	// [Call #14] RVA: 0x1045EF240
	// [Call #15] RVA: 0x102362AB0
	// [Call #16] RVA: 0x1045EF240
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleGeneratorComponent.GetVehicleSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104681e58
	// Params: [ Num(2) Size(0x60) ]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfo(struct FVehicleSpotProperty& SpotProperty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045EB5D0
	// [Call #4] RVA: 0x1045E8668
	// [Call #5] RVA: 0x103110404
	// [Call #6] RVA: 0x102362AB0
	// [Call #7] RVA: 0x103110404
	// [Call #8] RVA: 0x102362AB0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1045EB588
	// [Call #13] RVA: 0x1045E8668
	// [Call #14] RVA: 0x103110404
	// [Call #15] RVA: 0x103110404
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleGeneratorComponent.GetRandomVehicleClass
	// Flags: [Final|Native|Public]
	// Offset: 0x104681d40
	// Params: [ Num(2) Size(0x40) ]
	struct FVehicleGenerateSpawnData GetRandomVehicleClass(struct FString Category);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1045EB454
	// [Call #5] RVA: 0x1046868E4
	// [Call #6] RVA: 0x1045EEE64
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x1045EEE64
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045EB5D0
	// [Call #18] RVA: 0x1045E8668
	// [Call #19] RVA: 0x103110404
	// [Call #20] RVA: 0x102362AB0
	// [Call #21] RVA: 0x103110404
	// [Call #22] RVA: 0x102362AB0
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleGeneratorComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	// Offset: 0x104681c58
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x102362AB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1045EB454
	// [Call #13] RVA: 0x1046868E4
	// [Call #14] RVA: 0x1045EEE64
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x1045EEE64
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function Gameplay.VehicleGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Protected]
	// Offset: 0x104681bd4
	// Params: [ Num(1) Size(0x4) ]
	void GenerateSpotOnTick(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x1045EB454
	// [Call #15] RVA: 0x1046868E4
	// [Call #16] RVA: 0x1045EEE64
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x1045EEE64
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Gameplay.VehicleGeneratorComponent.DeleteGroups
	// Flags: [Final|Native|Protected]
	// Offset: 0x104681bc0
	// Params: [ Num(0) Size(0x0) ]
	void DeleteGroups();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x102362AB0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102362AB0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x1045EB454
	// [Call #15] RVA: 0x1046868E4
	// [Call #16] RVA: 0x1045EEE64
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x1045EEE64

	// Object: Function Gameplay.VehicleGeneratorComponent.AddVehicleSpotCount
	// Flags: [Final|Native|Protected]
	// Offset: 0x1046819dc
	// Params: [ Num(5) Size(0x24) ]
	void AddVehicleSpotCount(enum class ESpotType SpotType, struct FString Path, float LocationX, float LocationY, float LocationZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1045EB830
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleGeneratorComponent.AddVehicleClassCount
	// Flags: [Final|Native|Protected]
	// Offset: 0x104681868
	// Params: [ Num(3) Size(0x18) ]
	void AddVehicleClassCount(struct FString Path, bool IsValid, int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1045EB834
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
};

// Object: Class Gameplay.VehicleGroupSpotSceneComponent
// Size: 0x3B0 (Inherited: 0x3B0)
struct UVehicleGroupSpotSceneComponent : UGroupSpotSceneComponent
{
};

// Object: Class Gameplay.VehicleSpotObject
// Size: 0xC0 (Inherited: 0x28)
struct UVehicleSpotObject : UObject
{
	uint8_t Pad_0x28[0x48]; // 0x28(0x48)
	struct FVehicleGenerateRandomInfo SpotRandomInfo; // 0x70(0x28)
	struct UVehicleAndTreasureBoxGeneratorComponent* VehicleGenerator; // 0x98(0x8)
	uint8_t Pad_0xA0[0x20]; // 0xA0(0x20)


	// Object: Function Gameplay.VehicleSpotObject.OnVehicleGenerateEnd
	// Flags: [Final|Native|Public]
	// Offset: 0x104682ad0
	// Params: [ Num(0) Size(0x0) ]
	void OnVehicleGenerateEnd();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x104682E68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Gameplay.VehicleSpotObject.OnTraceLevelShown
	// Flags: [Final|Native|Public]
	// Offset: 0x104682abc
	// Params: [ Num(0) Size(0x0) ]
	void OnTraceLevelShown();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x104682E68
	// [Call #6] RVA: 0x10516D168
};

// Object: Class Gameplay.VehicleSpotSceneComponent
// Size: 0x420 (Inherited: 0x3C0)
struct UVehicleSpotSceneComponent : USpotSceneComponent
{
	enum class ESpotGroupType SpotGroupType; // 0x3C0(0x1)
	enum class ERegionType RegionType; // 0x3C1(0x1)
	bool bHasGenerateSpot; // 0x3C2(0x1)
	bool bRandomRotation; // 0x3C3(0x1)
	float RandomRotationMin; // 0x3C4(0x4)
	float RandomRotationMax; // 0x3C8(0x4)
	uint8_t Pad_0x3CC[0x4]; // 0x3CC(0x4)
	struct FVehicleGenerateRandomInfo SpotRandomInfo; // 0x3D0(0x28)
	bool IsEnableVehicleSpawnRestore; // 0x3F8(0x1)
	uint8_t Pad_0x3F9[0x3]; // 0x3F9(0x3)
	float VehicleSpawnRestoreOffset; // 0x3FC(0x4)
	uint8_t Pad_0x400[0x20]; // 0x400(0x20)


	// Object: Function Gameplay.VehicleSpotSceneComponent.SetSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104682cc0
	// Params: [ Num(1) Size(0x28) ]
	void SetSpotRandomInfo(struct FVehicleGenerateRandomInfo& RandomInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E8790
	// [Call #4] RVA: 0x103110404
	// [Call #5] RVA: 0x103110404
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function Gameplay.VehicleSpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	// Offset: 0x104682c84
	// Params: [ Num(1) Size(0x1) ]
	bool GenerateSpot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045E8790
	// [Call #4] RVA: 0x103110404
	// [Call #5] RVA: 0x103110404
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
};

// Object: Class Gameplay.WeatherConfigComponent
// Size: 0x180 (Inherited: 0x178)
struct UWeatherConfigComponent : UActorComponent
{
	uint8_t Pad_0x178[0x8]; // 0x178(0x8)
};

