#pragma once

#include <cstdint>

// Object: Enum BuildSystem.EBuildingActionType
enum class EBuildingActionType : uint8_t
{
	EBA_PreBuild = 0,
	EBA_BuildAtScreenPos = 1,
	EBA_DoubleClickBuild = 2,
	EBA_CustomEventBuild = 3,
	EBA_INTERNAL_SERVER_CHECK_TYPE = 99,
	EBA_Max = 100
};

// Object: Enum BuildSystem.EBuildingActorConstructingMode
enum class EBuildingActorConstructingMode : uint8_t
{
	EBCM_SNAP_TO_GROUND = 0,
	EBCM_SNAP_EVERYWHERE = 1,
	EBCM_SNAP_MAX = 2
};

// Object: Enum BuildSystem.EBuildingViewType
enum class EBuildingViewType : uint8_t
{
	EBVT_Invalid = 0,
	EBVT_UseController = 1,
	EBVT_UseCamera = 2,
	EBVT_UseCharacter = 3,
	EBVT_Max = 4
};

// Object: Enum BuildSystem.EBuildingType
enum class EBuildingType : uint8_t
{
	EBuilding_Wall = 0,
	EBuilding_Stairs = 1,
	EBuilding_Prop = 2,
	EBuilding_Max = 3
};

// Object: ScriptStruct BuildSystem.BuildingActorDSBuildCheck
// Size: 0x18 (Inherited: 0x0)
struct FBuildingActorDSBuildCheck
{
	struct TArray<struct FBuildingActorDSBuildCheckData> DSCheckCfg; // 0x0(0x10)
	enum class ECollisionChannel CheckChannel; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct BuildSystem.BuildingActorDSBuildCheckData
// Size: 0x18 (Inherited: 0x0)
struct FBuildingActorDSBuildCheckData
{
	struct FVector BuilderOffset; // 0x0(0xC)
	struct FVector BuildingActorOffset; // 0xC(0xC)
};

// Object: ScriptStruct BuildSystem.BuildingActorWorldSnapSetup
// Size: 0x24 (Inherited: 0x0)
struct FBuildingActorWorldSnapSetup
{
	struct FVector GridSizeScale; // 0x0(0xC)
	struct FVector Pivot; // 0xC(0xC)
	struct FRotator SnapRotation; // 0x18(0xC)
};

// Object: ScriptStruct BuildSystem.BuildingActorDensityCheck
// Size: 0x20 (Inherited: 0x0)
struct FBuildingActorDensityCheck
{
	bool bDoCheck; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	struct FVector Location; // 0x4(0xC)
	struct FString LuaModPath; // 0x10(0x10)
};

// Object: ScriptStruct BuildSystem.SnapGridData
// Size: 0x50 (Inherited: 0x0)
struct FSnapGridData
{
	struct FTransform GridTransform; // 0x0(0x30)
	struct FVector Extent; // 0x30(0xC)
	uint8_t Pad_0x3C[0x14]; // 0x3C(0x14)
};

// Object: ScriptStruct BuildSystem.BuildingActorInfo
// Size: 0x18 (Inherited: 0x0)
struct FBuildingActorInfo
{
	struct TWeakObjectPtr<struct ABuildingActorBase> BuildingActor; // 0x0(0x8)
	struct TWeakObjectPtr<struct AActor> OwnerActor; // 0x8(0x8)
	int BuildID; // 0x10(0x4)
	float SpawnedTime; // 0x14(0x4)
};

// Object: ScriptStruct BuildSystem.BuildingData
// Size: 0x48 (Inherited: 0x0)
struct FBuildingData
{
	int BuildingID; // 0x0(0x4)
	enum class EBuildingType BuildingType; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	struct FSoftObjectPath BuildingActorClassPath; // 0x8(0x18)
	struct TArray<enum class ECollisionChannel> BlockingChannels; // 0x20(0x10)
	float MaxBuildDist; // 0x30(0x4)
	float CDInterval; // 0x34(0x4)
	int MaxBuildCount; // 0x38(0x4)
	bool bAutoRefreshCD; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
	int GroupBuildingIdForMaxBuild; // 0x40(0x4)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
};

// Object: ScriptStruct BuildSystem.BSRotatedBox
// Size: 0xA0 (Inherited: 0x0)
struct FBSRotatedBox
{
	uint8_t Pad_0x0[0xA0]; // 0x0(0xA0)
};

// Object: ScriptStruct BuildSystem.BuildingTouchInfo
// Size: 0x10 (Inherited: 0x0)
struct FBuildingTouchInfo
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct BuildSystem.QuadTracingData
// Size: 0x18 (Inherited: 0x0)
struct FQuadTracingData
{
	uint8_t Pad_0x0[0x18]; // 0x0(0x18)
};

// Object: ScriptStruct BuildSystem.WorldGridData
// Size: 0xC (Inherited: 0x0)
struct FWorldGridData
{
	struct FVector GridSize; // 0x0(0xC)
};

// Object: Class BuildSystem.BuildingActorBase
// Size: 0x770 (Inherited: 0x570)
struct ABuildingActorBase : ALuaActor
{
	uint8_t Pad_0x570[0x1C]; // 0x570(0x1C)
	float LastQuadTraceDeviation; // 0x58C(0x4)
	struct FScriptMulticastDelegate LastQuadTraceDeviationDelegate; // 0x590(0x10)
	bool bCustomBlockingChannels; // 0x5A0(0x1)
	uint8_t Pad_0x5A1[0x7]; // 0x5A1(0x7)
	struct TArray<enum class ECollisionChannel> CustomBlockingChannels; // 0x5A8(0x10)
	bool bCheckVisibilitySkipTypes; // 0x5B8(0x1)
	bool bSkipCheckOwnerCollision; // 0x5B9(0x1)
	uint8_t Pad_0x5BA[0x6]; // 0x5BA(0x6)
	struct TArray<struct UObject*> VisibilitySkipTypes; // 0x5C0(0x10)
	struct FBuildingActorWorldSnapSetup WorldSnapSetup; // 0x5D0(0x24)
	float DebugHealthDistance; // 0x5F4(0x4)
	struct FVector DebugHealthOffset; // 0x5F8(0xC)
	uint8_t Pad_0x604[0x4]; // 0x604(0x4)
	struct TArray<struct UObject*> ProhibitedActorTemplateList; // 0x608(0x10)
	struct TArray<struct UObject*> EnableBuildingList; // 0x618(0x10)
	struct FSoftObjectPath PreBuildingEffectPath; // 0x628(0x18)
	struct FVector PreBuildingEffectScale; // 0x640(0xC)
	struct FVector PreBuildingEffectOffset; // 0x64C(0xC)
	struct FRotator PreBuildingEffectRotation; // 0x658(0xC)
	bool CanBuildUnderWater; // 0x664(0x1)
	bool bShouldSnapToWorldGrid; // 0x665(0x1)
	uint8_t Pad_0x666[0x2]; // 0x666(0x2)
	float UnderWaterMaxBuildDepth; // 0x668(0x4)
	uint8_t Pad_0x66C[0x4]; // 0x66C(0x4)
	struct FTransform DestroyedParticleTransformOffset; // 0x670(0x30)
	struct FSoftObjectPath DestroyBuildingEffectPath; // 0x6A0(0x18)
	bool bUseExtraCenterOffset; // 0x6B8(0x1)
	bool bUseExtraCenterRotation; // 0x6B9(0x1)
	uint8_t Pad_0x6BA[0x2]; // 0x6BA(0x2)
	struct FVector ActorCollisionBoxExtern; // 0x6BC(0xC)
	struct FVector ActorCollisionBoxCenter; // 0x6C8(0xC)
	struct FRotator ActorCollisionBoxRotator; // 0x6D4(0xC)
	struct FVector ViewLocationOffset; // 0x6E0(0xC)
	float Health; // 0x6EC(0x4)
	bool bDestroyWhenZeroHealth; // 0x6F0(0x1)
	uint8_t Pad_0x6F1[0x7]; // 0x6F1(0x7)
	struct FScriptMulticastDelegate OnHealthChangeNotify; // 0x6F8(0x10)
	float MaxDeviation; // 0x708(0x4)
	float MaxTraceDepth; // 0x70C(0x4)
	bool bDoQuadTrace; // 0x710(0x1)
	bool bUseQuadTraceDeviationForSpawnOffset; // 0x711(0x1)
	enum class EBuildingActorConstructingMode ConstructingMode; // 0x712(0x1)
	bool bEnableOverlayPlace; // 0x713(0x1)
	bool bEnablePitchRotatePlace; // 0x714(0x1)
	bool bAutoPickValidPlace; // 0x715(0x1)
	uint8_t Pad_0x716[0x2]; // 0x716(0x2)
	float OverlayPlaceHeight; // 0x718(0x4)
	float OverlayMaxHeightFromGround; // 0x71C(0x4)
	float DetectDeath; // 0x720(0x4)
	float MaxOffectHight; // 0x724(0x4)
	bool bUseCachedBuildLocation; // 0x728(0x1)
	bool bBuildOnlyOnLandscape; // 0x729(0x1)
	bool bBuildOnEdge; // 0x72A(0x1)
	uint8_t Pad_0x72B[0x1]; // 0x72B(0x1)
	float BuildOnEdgeUpLength; // 0x72C(0x4)
	float BuildOnEdgeFrontLength; // 0x730(0x4)
	uint8_t Pad_0x734[0x4]; // 0x734(0x4)
	struct FBuildingActorDSBuildCheck DSBuildCheckCfg; // 0x738(0x18)
	int MaxCountLimit; // 0x750(0x4)
	bool bDoDensityCheck; // 0x754(0x1)
	uint8_t Pad_0x755[0x3]; // 0x755(0x3)
	struct FString LuaModPath; // 0x758(0x10)
	uint8_t Pad_0x768[0x8]; // 0x768(0x8)


	// Object: Function BuildSystem.BuildingActorBase.SpawnDestroyParticle
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x102749e44
	// Params: [ Num(4) Size(0x60) ]
	void SpawnDestroyParticle(bool bSpawnParticle, struct FTransform& Loc, struct FSoftObjectPath& DestroyBuildingEffectPath, struct UWorld* World);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027380EC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function BuildSystem.BuildingActorBase.SetLastQuadTraceDeviation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102749dc8
	// Params: [ Num(1) Size(0x4) ]
	void SetLastQuadTraceDeviation(float InDeviation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102738B08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1027380EC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorBase.PlayDestroyAnimation
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102749d3c
	// Params: [ Num(1) Size(0x1) ]
	void PlayDestroyAnimation(bool bUseParticle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102738B08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorBase.OnTakeDamageFromVehicle
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x20) ]
	void OnTakeDamageFromVehicle(struct UPrimitiveComponent* MyPrimitiveComp, float ForwardSpeed, float DamageAmount, struct AActor* DamageCauser, struct AController* EventInstigator);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildingActorBase.OnRep_Health
	// Flags: [Final|Native|Protected]
	// Offset: 0x102749d28
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Health();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102738B08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorBase.OnPlayDestroyAnimation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnPlayDestroyAnimation(bool bUseParticle);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildingActorBase.OnBuildingActorDamaged
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x102749ca4
	// Params: [ Num(1) Size(0x4) ]
	void OnBuildingActorDamaged(float Health);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102738B08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorBase.OnBornAnimationPlayEndInClient
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnBornAnimationPlayEndInClient();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildingActorBase.GetLastQuadTraceDeviation
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102749c88
	// Params: [ Num(1) Size(0x4) ]
	float GetLastQuadTraceDeviation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102738B08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorBase.GetBuildID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102749c6c
	// Params: [ Num(1) Size(0x4) ]
	int GetBuildID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102738B08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorBase.BPOnOwnerChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void BPOnOwnerChanged();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class BuildSystem.BuildingActorInterface
// Size: 0x28 (Inherited: 0x28)
struct IBuildingActorInterface : IInterface
{

	// Object: Function BuildSystem.BuildingActorInterface.UseQuadTraceDeviationForSpawnOffset
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10274bc1c
	// Params: [ Num(4) Size(0x1D) ]
	bool UseQuadTraceDeviationForSpawnOffset(struct FVector BuildLocation, float QuadTraceDeviation, struct FVector& OutLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorInterface.UseFixedLocation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274bbe0
	// Params: [ Num(1) Size(0x1) ]
	bool UseFixedLocation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorInterface.UseCachedBuildLocation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274bba4
	// Params: [ Num(1) Size(0x1) ]
	bool UseCachedBuildLocation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorInterface.ShouldUseExtraRotation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274bb68
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldUseExtraRotation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870

	// Object: Function BuildSystem.BuildingActorInterface.ShouldUseExtraOffset
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274bb2c
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldUseExtraOffset();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorInterface.ShouldSnapToGrid
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274baf0
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldSnapToGrid();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.ShouldSkipCheckOwnerCollision
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274bab4
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldSkipCheckOwnerCollision();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.ShouldCustomBlockingChannels
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274ba78
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldCustomBlockingChannels();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorInterface.ShouldCheckVisibilityTypes
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274ba3c
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldCheckVisibilityTypes();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorInterface.ShouldAttachToMovementPlatform
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274ba00
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldAttachToMovementPlatform();
	// [Call #1] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorInterface.SetBuildingActorID
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10274b97c
	// Params: [ Num(1) Size(0x4) ]
	void SetBuildingActorID(int BuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.PrebuildCDOBodyInstance
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10274b894
	// Params: [ Num(2) Size(0x40) ]
	void PrebuildCDOBodyInstance(struct UWorld* World, struct FTransform& tranx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.NonCullingBeginPlay
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10274b878
	// Params: [ Num(0) Size(0x0) ]
	void NonCullingBeginPlay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.MaxUnderWaterBuildDepth
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b83c
	// Params: [ Num(1) Size(0x4) ]
	float MaxUnderWaterBuildDepth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.IsEnablePitchRotatePlace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b800
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnablePitchRotatePlace();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.IsEnableOverlayPlace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b7c4
	// Params: [ Num(1) Size(0x1) ]
	bool IsEnableOverlayPlace();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.IsBuildOnlyOnLandscape
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b788
	// Params: [ Num(1) Size(0x1) ]
	bool IsBuildOnlyOnLandscape();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.IsBuildOnEdge
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b74c
	// Params: [ Num(1) Size(0x1) ]
	bool IsBuildOnEdge();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.IsAutoPickValidPlace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b710
	// Params: [ Num(1) Size(0x1) ]
	bool IsAutoPickValidPlace();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.HandleBuildingDestroyed
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10274b68c
	// Params: [ Num(1) Size(0x8) ]
	void HandleBuildingDestroyed(struct AController* InstigatedBy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.HandleBuildingConstructed
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10274b608
	// Params: [ Num(1) Size(0x8) ]
	void HandleBuildingConstructed(struct AController* InstigatedBy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetWorldSnapSetup
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b5b0
	// Params: [ Num(1) Size(0x24) ]
	struct FBuildingActorWorldSnapSetup GetWorldSnapSetup();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetVisibilitySkipTypes
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b544
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UObject*> GetVisibilitySkipTypes();
	// [Call #1] RVA: 0x10274DF78
	// [Call #2] RVA: 0x10228936C
	// [Call #3] RVA: 0x10228936C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetViewLocationOffset
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b504
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetViewLocationOffset();
	// [Call #1] RVA: 0x10274DF78
	// [Call #2] RVA: 0x10228936C
	// [Call #3] RVA: 0x10228936C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetProhibitedActorTemplateList
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b498
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UObject*> GetProhibitedActorTemplateList();
	// [Call #1] RVA: 0x10274DF78
	// [Call #2] RVA: 0x10228936C
	// [Call #3] RVA: 0x10228936C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectScale
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b458
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetPreBuildingEffectScale();
	// [Call #1] RVA: 0x10274DF78
	// [Call #2] RVA: 0x10228936C
	// [Call #3] RVA: 0x10228936C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectRotation
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b418
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetPreBuildingEffectRotation();
	// [Call #1] RVA: 0x10274DF78
	// [Call #2] RVA: 0x10228936C
	// [Call #3] RVA: 0x10228936C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectPath
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b3a8
	// Params: [ Num(1) Size(0x18) ]
	struct FSoftObjectPath GetPreBuildingEffectPath();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10274DF78
	// [Call #10] RVA: 0x10228936C
	// [Call #11] RVA: 0x10228936C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetPreBuildingEffectOffset
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b368
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetPreBuildingEffectOffset();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10274DF78
	// [Call #10] RVA: 0x10228936C
	// [Call #11] RVA: 0x10228936C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetOverlayPlaceHeight
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b32c
	// Params: [ Num(1) Size(0x4) ]
	float GetOverlayPlaceHeight();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10274DF78

	// Object: Function BuildSystem.BuildingActorInterface.GetOverlayMaxHeightFromGround
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b2f0
	// Params: [ Num(1) Size(0x4) ]
	float GetOverlayMaxHeightFromGround();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetMaxTraceDepth
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b2b4
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxTraceDepth();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10274DF78
	// [Call #6] RVA: 0x10228936C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetMaxOffectHight
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b278
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxOffectHight();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetMaxDeviation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b23c
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxDeviation();
	// [Call #1] RVA: 0x10517CE3C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetDSBuildCheckConfig
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b1d0
	// Params: [ Num(1) Size(0x18) ]
	struct FBuildingActorDSBuildCheck GetDSBuildCheckConfig();
	// [Call #1] RVA: 0x10274D9A0
	// [Call #2] RVA: 0x102746D08
	// [Call #3] RVA: 0x102746D08
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10517CE3C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetDetectDeath
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b194
	// Params: [ Num(1) Size(0x4) ]
	float GetDetectDeath();
	// [Call #1] RVA: 0x10274D9A0
	// [Call #2] RVA: 0x102746D08
	// [Call #3] RVA: 0x102746D08
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10517CE3C

	// Object: Function BuildSystem.BuildingActorInterface.GetDestroyedParticleTransformOffset
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b140
	// Params: [ Num(1) Size(0x30) ]
	struct FTransform GetDestroyedParticleTransformOffset();
	// [Call #1] RVA: 0x10274D9A0
	// [Call #2] RVA: 0x102746D08
	// [Call #3] RVA: 0x102746D08
	// [Call #4] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetDensityParams
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274b074
	// Params: [ Num(2) Size(0x30) ]
	struct FBuildingActorDensityCheck GetDensityParams(struct FVector& Location);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10274D758
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10274D9A0
	// [Call #8] RVA: 0x102746D08
	// [Call #9] RVA: 0x102746D08
	// [Call #10] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetCustomBlockingChannels
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274b008
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<enum class ECollisionChannel> GetCustomBlockingChannels();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10274D9A0
	// [Call #12] RVA: 0x102746D08
	// [Call #13] RVA: 0x102746D08
	// [Call #14] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetConstructingMode
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274afcc
	// Params: [ Num(1) Size(0x1) ]
	enum class EBuildingActorConstructingMode GetConstructingMode();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10274D9A0
	// [Call #12] RVA: 0x102746D08

	// Object: Function BuildSystem.BuildingActorInterface.GetBuildOnEdgeUpLength
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274af90
	// Params: [ Num(1) Size(0x4) ]
	float GetBuildOnEdgeUpLength();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetBuildOnEdgeFrontLength
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274af54
	// Params: [ Num(1) Size(0x4) ]
	float GetBuildOnEdgeFrontLength();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetBuildingActorID
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274af18
	// Params: [ Num(1) Size(0x4) ]
	int GetBuildingActorID();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxRotator
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274aed8
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator GetActorCollisionBoxRotator();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274D758
	// [Call #8] RVA: 0x101F8130C

	// Object: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxExtern
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274ae98
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetActorCollisionBoxExtern();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.GetActorCollisionBoxCenter
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274ae58
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetActorCollisionBoxCenter();
	// [Call #1] RVA: 0x10273D5F4
	// [Call #2] RVA: 0x1023635C4
	// [Call #3] RVA: 0x1023635C4
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildingActorInterface.CustomizeLocationAndRotation
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10274aca4
	// Params: [ Num(5) Size(0x38) ]
	void CustomizeLocationAndRotation(struct AActor* Builder, struct FVector& InLocation, struct FRotator& InRotation, struct FVector& OutLocation, struct FRotator& OutRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.CanDoQuadTrace
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274ac68
	// Params: [ Num(1) Size(0x1) ]
	bool CanDoQuadTrace();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.CanCustomizeLocationAndRotation
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274ac2c
	// Params: [ Num(1) Size(0x1) ]
	bool CanCustomizeLocationAndRotation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.CanBuildUnderWater
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10274abf0
	// Params: [ Num(1) Size(0x1) ]
	bool CanBuildUnderWater();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.BPCheckPlacement
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274aa48
	// Params: [ Num(6) Size(0x51) ]
	bool BPCheckPlacement(struct UWorld* World, struct FTransform& tranx, int checkType, int CurrentAvatarID, struct AActor* Builder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildingActorInterface.BP_DSFinalCheckPlacement
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10274a950
	// Params: [ Num(3) Size(0x39) ]
	bool BP_DSFinalCheckPlacement(struct FTransform& Transform, struct AActor* Builder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class BuildSystem.BuildingActorMgr
// Size: 0x4C0 (Inherited: 0x4B0)
struct ABuildingActorMgr : AActor
{
	struct TArray<struct FBuildingActorInfo> BuildingActorList; // 0x4B0(0x10)


	// Object: Function BuildSystem.BuildingActorMgr.OnBuildingActorSpawned
	// Flags: [Final|Native|Public]
	// Offset: 0x10274ee84
	// Params: [ Num(2) Size(0x10) ]
	void OnBuildingActorSpawned(struct AActor* InOwnerActor, struct ABuildingActorBase* InBuildingActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027374D0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorMgr.OnBuildingActorDestroyed
	// Flags: [Final|Native|Public]
	// Offset: 0x10274ee08
	// Params: [ Num(1) Size(0x8) ]
	void OnBuildingActorDestroyed(struct ABuildingActorBase* InBuildingActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027375F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1027374D0
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildingActorMgr.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10274ed8c
	// Params: [ Num(2) Size(0x10) ]
	struct ABuildingActorMgr* GetInstance(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102737364
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1027375F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1027374D0
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class BuildSystem.BuildingGridComponent
// Size: 0xA10 (Inherited: 0x9F0)
struct UBuildingGridComponent : UBoxComponent
{
	struct FName CollisionProfileName; // 0x9F0(0x8)
	struct FVector BuildCenterOffset; // 0x9F8(0xC)
	uint8_t Pad_0xA04[0xC]; // 0xA04(0xC)
};

// Object: Class BuildSystem.BuildSystemComponent
// Size: 0x500 (Inherited: 0x238)
struct UBuildSystemComponent : ULuaActorComponent
{
	bool UseFixedDistanceBuild; // 0x231(0x1)
	struct FScriptMulticastDelegate OnConstructionComplete; // 0x238(0x10)
	struct FScriptMulticastDelegate OnDoubleClickMode2Event; // 0x248(0x10)
	struct FScriptMulticastDelegate OnDoubleClickMode2PercentEvent; // 0x258(0x10)
	float MaxmumConstructingDistance; // 0x268(0x4)
	int CurrentAvatarID; // 0x26C(0x4)
	bool bMLAIBuildResult; // 0x270(0x1)
	uint8_t Pad_0x272[0x2]; // 0x272(0x2)
	float LastQuadTraceDeviation; // 0x274(0x4)
	uint8_t Pad_0x278[0x80]; // 0x278(0x80)
	struct ASelectBuildActor* BuildingSelectorClass; // 0x2F8(0x8)
	struct ASelectBuildActor* SelectBuildMeshClass; // 0x300(0x8)
	float UpdateBuildEnableTimer; // 0x308(0x4)
	float MinBuildDist; // 0x30C(0x4)
	float GridGroundThreshold; // 0x310(0x4)
	bool AIIsOpenAdsorb; // 0x314(0x1)
	bool AIIsOpenLeftAndRightTry; // 0x315(0x1)
	uint8_t Pad_0x316[0x2]; // 0x316(0x2)
	float GridGroundCheckDepth; // 0x318(0x4)
	struct FWorldGridData WorldGridData; // 0x31C(0xC)
	bool bCanPlaceOnConstructableActor; // 0x328(0x1)
	uint8_t Pad_0x329[0x3]; // 0x329(0x3)
	int bIsFastPlacementMode; // 0x32C(0x4)
	int Mode2PressTouchBuildIndex; // 0x330(0x4)
	bool bIsStartPreBuildMode2; // 0x334(0x1)
	uint8_t Pad_0x335[0x3]; // 0x335(0x3)
	struct FVector2D Mode2PreBuildPos; // 0x338(0x8)
	float CurrentDoubleClickDuration; // 0x340(0x4)
	float ValidDoubleClickDuration; // 0x344(0x4)
	float ValidDoubleClickInterval; // 0x348(0x4)
	float ValidDoubleClickDistance; // 0x34C(0x4)
	bool bSouldSkipOwningPlayer; // 0x350(0x1)
	bool bNativeTouchActorBuildEnabled; // 0x351(0x1)
	bool bNativeDoubleCkickBuildEnabled; // 0x352(0x1)
	uint8_t Pad_0x353[0x5]; // 0x353(0x5)
	struct TMap<int, struct UClass*> ActorSelectorMap; // 0x358(0x50)
	struct TArray<struct UObject*> SkippingObjects; // 0x3A8(0x10)
	bool bDebugDraw; // 0x3B8(0x1)
	bool bPickLocationDebugDraw; // 0x3B9(0x1)
	uint8_t Pad_0x3BA[0x6]; // 0x3BA(0x6)
	struct TArray<struct UObject*> FilterTemplates; // 0x3C0(0x10)
	struct TArray<struct UObject*> ActorsShouldSkipVisiblityCheck; // 0x3D0(0x10)
	enum class ECollisionChannel BuildingGridChannel; // 0x3E0(0x1)
	uint8_t Pad_0x3E1[0x3]; // 0x3E1(0x3)
	float MaxCanAdsorbAngle; // 0x3E4(0x4)
	float SnappingDistance; // 0x3E8(0x4)
	float SnappingDetectRadius; // 0x3EC(0x4)
	float AIMaxCanRotateAngle; // 0x3F0(0x4)
	bool bCheckPlaceActorPosSwitch; // 0x3F4(0x1)
	uint8_t Pad_0x3F5[0x3]; // 0x3F5(0x3)
	float FloatErrorTolerance; // 0x3F8(0x4)
	bool bDSTraceCheck; // 0x3FC(0x1)
	uint8_t Pad_0x3FD[0x3]; // 0x3FD(0x3)
	struct ASelectBuildActor* SelectBuildActor; // 0x400(0x8)
	uint8_t CurrentBuildViewType; // 0x408(0x1)
	uint8_t Pad_0x409[0xB]; // 0x409(0xB)
	bool bIsBuildOnEdge; // 0x414(0x1)
	uint8_t Pad_0x415[0x3]; // 0x415(0x3)
	float EdgeUpLength; // 0x418(0x4)
	float EdgeFrontLength; // 0x41C(0x4)
	uint8_t Pad_0x420[0x14]; // 0x420(0x14)
	int CachedCDOIndex; // 0x434(0x4)
	struct AActor* CachedCDOActor; // 0x438(0x8)
	uint8_t Pad_0x440[0xC0]; // 0x440(0xC0)


	// Object: Function BuildSystem.BuildSystemComponent.TryAttachToMoveablePlatform
	// Flags: [Event|Protected|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x14) ]
	void TryAttachToMoveablePlatform(struct AActor* SpawnedBuilding, struct FVector BuildLocation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.ToggleDebugDraw
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10275240c
	// Params: [ Num(0) Size(0x0) ]
	void ToggleDebugDraw();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildSystemComponent.StopPlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1027523f0
	// Params: [ Num(0) Size(0x0) ]
	void StopPlaceBuilding();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildSystemComponent.StartPrePlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1027522f8
	// Params: [ Num(3) Size(0x9) ]
	void StartPrePlaceBuilding(int InBuildID, int AvatarID, uint8_t viewType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildSystemComponent.SkipCDTimeByBuildID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102752240
	// Params: [ Num(2) Size(0x8) ]
	void SkipCDTimeByBuildID(int InBuildID, float IncreaseRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102739408
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function BuildSystem.BuildSystemComponent.ShouldEnableDoubleTouchMode
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102752204
	// Params: [ Num(1) Size(0x1) ]
	bool ShouldEnableDoubleTouchMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102739408
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10519022C

	// Object: Function BuildSystem.BuildSystemComponent.SetPrebuildEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102752134
	// Params: [ Num(2) Size(0x2) ]
	void SetPrebuildEnabled(bool CanBePlaced, bool IsVisible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027413F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102739408
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.SetBuildingDataModeID
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x1027520b8
	// Params: [ Num(1) Size(0x4) ]
	void SetBuildingDataModeID(int ModeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1027413F0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102739408

	// Object: Function BuildSystem.BuildSystemComponent.SetBuildingData
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102751fb0
	// Params: [ Num(2) Size(0x50) ]
	void SetBuildingData(int Index, struct FBuildingData InData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102746DC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10274726C
	// [Call #7] RVA: 0x102746F60
	// [Call #8] RVA: 0x102746F60
	// [Call #9] RVA: 0x102746F60
	// [Call #10] RVA: 0x102746F60
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1027413F0

	// Object: Function BuildSystem.BuildSystemComponent.ServerLineTraceCheck
	// Flags: [Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x102751e8c
	// Params: [ Num(4) Size(0x21) ]
	bool ServerLineTraceCheck(struct UObject* BuildingClass, struct FVector& CheckLocation, struct FRotator& CheckRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102746DC8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10274726C
	// [Call #13] RVA: 0x102746F60
	// [Call #14] RVA: 0x102746F60
	// [Call #15] RVA: 0x102746F60
	// [Call #16] RVA: 0x102746F60
	// [Call #17] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildSystemComponent.ResetBuildngCDByBuildID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102751dd4
	// Params: [ Num(2) Size(0x8) ]
	void ResetBuildngCDByBuildID(int InBuildID, float InNewCDTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102739164
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102746DC8
	// [Call #15] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.ResetBuildList
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102751db8
	// Params: [ Num(0) Size(0x0) ]
	void ResetBuildList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102739164
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102746DC8

	// Object: Function BuildSystem.BuildSystemComponent.ProccessNothingHitTraceOverlap
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(7) Size(0x39) ]
	bool ProccessNothingHitTraceOverlap(struct FVector& DestLocation, struct FRotator& DestRotation, float MaxBuildDist, struct FVector& OutLocation, int buildIndex, struct FVector& ViewLocation);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.PlaceBuildingWithIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102751cb8
	// Params: [ Num(3) Size(0x9) ]
	void PlaceBuildingWithIndex(int buildIndex, int AvatarID, bool bRelative);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102739164
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.PlaceBuildingAtLocation
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102751b9c
	// Params: [ Num(3) Size(0x1C) ]
	void PlaceBuildingAtLocation(int buildIndex, struct FVector& Loc, struct FRotator& Rot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.PlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102751ad8
	// Params: [ Num(2) Size(0x5) ]
	void PlaceBuilding(int AvatarID, bool bRelative);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.PickLocationByBuildID
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1027519bc
	// Params: [ Num(4) Size(0x1D) ]
	bool PickLocationByBuildID(int InBuildID, struct FVector& OutLocation, struct FRotator& OutRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273C000
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.OverriveDeploymentTransform
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x102751844
	// Params: [ Num(4) Size(0x30) ]
	void OverriveDeploymentTransform(struct FRotator& rotIn, struct FVector& locIn, struct FRotator& rotOut, struct FVector& locOut);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.OverrideBuildingMaxBuildDistance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102751740
	// Params: [ Num(3) Size(0xC) ]
	void OverrideBuildingMaxBuildDistance(float BuildingMaxDistance, bool SetAll, int BuildingID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10274131C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBoxEnded
	// Flags: [Native|Public]
	// Offset: 0x102751680
	// Params: [ Num(2) Size(0x10) ]
	void OnTouchedConstructableBoxEnded(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10274131C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.OnTouchedConstructableBox
	// Flags: [Native|Public]
	// Offset: 0x1027515c0
	// Params: [ Num(2) Size(0x10) ]
	void OnTouchedConstructableBox(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.OnTouchActorBuild
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1027514ec
	// Params: [ Num(2) Size(0x10) ]
	void OnTouchActorBuild(struct FVector2D& ScreenPosition, struct APlayerController* Controller);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.OnAsyncLoadingMeshFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x1027513ac
	// Params: [ Num(2) Size(0x2C) ]
	void OnAsyncLoadingMeshFinished(struct UStaticMesh* MeshPtr, int buildIndex);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10240671C
	// [Call #7] RVA: 0x10273B950
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.OnAsyncLoadingEffectFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x10275126c
	// Params: [ Num(2) Size(0x2C) ]
	void OnAsyncLoadingEffectFinished(struct UParticleSystem* EffectPtr, int buildIndex);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102747308
	// [Call #7] RVA: 0x10273B61C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101FE9F3C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10240671C
	// [Call #19] RVA: 0x10273B950
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BuildSystem.BuildSystemComponent.OnAsyncLoadingBuildingFinished
	// Flags: [Final|Native|Public]
	// Offset: 0x10275112c
	// Params: [ Num(2) Size(0x2C) ]
	void OnAsyncLoadingBuildingFinished(struct UClass* AcotrPtr, int buildIndex);
	// [Call #1] RVA: 0x101FE9F3C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10270DC50
	// [Call #7] RVA: 0x10273BB24
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x101FE9F3C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102747308
	// [Call #19] RVA: 0x10273B61C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function BuildSystem.BuildSystemComponent.IsValidAvatar
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102751098
	// Params: [ Num(2) Size(0x5) ]
	bool IsValidAvatar(int AvatarID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FE9F3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10270DC50
	// [Call #9] RVA: 0x10273BB24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101FE9F3C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.IsParticlePreBuildingEffect
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102751004
	// Params: [ Num(2) Size(0x5) ]
	bool IsParticlePreBuildingEffect(int InBuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FE9F3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10270DC50
	// [Call #11] RVA: 0x10273BB24
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C

	// Object: Function BuildSystem.BuildSystemComponent.IsOverlayBuildHeightValid
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x11) ]
	bool IsOverlayBuildHeightValid(struct FVector BuildLocation, float OverlayMaxHeightFromGround);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.IsInPreBuildingMode
	// Flags: [Final|Native|Public]
	// Offset: 0x102750fe0
	// Params: [ Num(1) Size(0x1) ]
	bool IsInPreBuildingMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FE9F3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10270DC50
	// [Call #11] RVA: 0x10273BB24
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C

	// Object: Function BuildSystem.BuildSystemComponent.IsCanPlaceBuildingBP
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102750f4c
	// Params: [ Num(2) Size(0x5) ]
	bool IsCanPlaceBuildingBP(int InBuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FE9F3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.IsCanPlaceBuilding
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102750e7c
	// Params: [ Num(3) Size(0x6) ]
	bool IsCanPlaceBuilding(int InBuildID, enum class EBuildingActionType _TYPE);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.IsActorProhibited
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102750df0
	// Params: [ Num(2) Size(0x9) ]
	bool IsActorProhibited(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10273DD64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectRotation
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x102750d58
	// Params: [ Num(2) Size(0x10) ]
	struct FRotator GetPreBuildingEffectRotation(int InBuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10273DD64
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectPath
	// Flags: [Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x20) ]
	struct FSoftObjectPath GetPreBuildingEffectPath(int InBuildID, int AvatarID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.GetPreBuildingEffectOffset
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x102750cc0
	// Params: [ Num(2) Size(0x10) ]
	struct FVector GetPreBuildingEffectOffset(int InBuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273DD64
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetOwnerPlayerController
	// Flags: [Native|Protected]
	// Offset: 0x102750c84
	// Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetOwnerPlayerController();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273DD64
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetMaxDistance
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102750c48
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxDistance();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273DD64

	// Object: Function BuildSystem.BuildSystemComponent.GetLastQuadTraceDeviation
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102750c2c
	// Params: [ Num(1) Size(0x4) ]
	float GetLastQuadTraceDeviation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273DD64

	// Object: Function BuildSystem.BuildSystemComponent.GetIsHasInitData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102750bf0
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsHasInitData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetIndexByBuildingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102750b64
	// Params: [ Num(2) Size(0x8) ]
	int GetIndexByBuildingID(int BuildID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102739F3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetCurrentBuildType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102750b30
	// Params: [ Num(1) Size(0x1) ]
	enum class EBuildingType GetCurrentBuildType();
	// [Call #1] RVA: 0x10273BFCC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102739F3C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.GetCDOByIndex
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	// Offset: 0x102750aa4
	// Params: [ Num(2) Size(0x10) ]
	struct AActor* GetCDOByIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102739010
	// [Call #4] RVA: 0x10273BFCC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102739F3C
	// [Call #8] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.GetBuildingList
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102750a38
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FBuildingData> GetBuildingList();
	// [Call #1] RVA: 0x102754CD4
	// [Call #2] RVA: 0x102748254
	// [Call #3] RVA: 0x102748254
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102739010
	// [Call #8] RVA: 0x10273BFCC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102739F3C

	// Object: Function BuildSystem.BuildSystemComponent.GetBuildingDataModeID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102750a14
	// Params: [ Num(1) Size(0x4) ]
	int GetBuildingDataModeID();
	// [Call #1] RVA: 0x102754CD4
	// [Call #2] RVA: 0x102748254
	// [Call #3] RVA: 0x102748254
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102739010
	// [Call #8] RVA: 0x10273BFCC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102739F3C

	// Object: Function BuildSystem.BuildSystemComponent.EnableBuildingByID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102750958
	// Params: [ Num(2) Size(0x5) ]
	void EnableBuildingByID(int BuildID, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102739F80
	// [Call #6] RVA: 0x102754CD4
	// [Call #7] RVA: 0x102748254
	// [Call #8] RVA: 0x102748254
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102739010
	// [Call #13] RVA: 0x10273BFCC
	// [Call #14] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.DoSceenTouchBuild
	// Flags: [Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10275078c
	// Params: [ Num(6) Size(0x13) ]
	void DoSceenTouchBuild(int buildIndex, struct FVector2D& ScreenPostion, int PointerIndex, enum class EBuildingActionType _TYPE, bool IsBegin, enum class EBuildingActionType CustomBuildEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.DensityCheck
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x1027506b8
	// Params: [ Num(2) Size(0x21) ]
	bool DensityCheck(struct FBuildingActorDensityCheck& DensityCheckParmas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.CheckShouldSkipByVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027505f0
	// Params: [ Num(3) Size(0xD) ]
	bool CheckShouldSkipByVisibility(struct UPrimitiveComponent* _comp, int buildIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10273DBE8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function BuildSystem.BuildSystemComponent.CheckPlacementWithPitch
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(6) Size(0xF9) ]
	bool CheckPlacementWithPitch(struct FHitResult& Hit, struct FVector& OutLocation, struct FRotator& OutRotation, struct FVector& BoxExtent, struct FBuildingData& CurBuildData);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.CheckPlacementOverlap
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(9) Size(0x96) ]
	bool CheckPlacementOverlap(struct TArray<struct FHitResult>& HitArray, struct FVector& OutLocation, struct FVector& BoxExtent, struct FBuildingData& CurBuildData, struct FRotator& BuildRotation, struct FRotator& ControlRot, struct FVector& ViewLocation, bool& HasForbiddenObject);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function BuildSystem.BuildSystemComponent.CheckPlaceBuildingWithIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10275055c
	// Params: [ Num(2) Size(0x5) ]
	bool CheckPlaceBuildingWithIndex(int buildIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273DBE8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function BuildSystem.BuildSystemComponent.CheckObjectIsOneOfTheTemplate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102750428
	// Params: [ Num(3) Size(0x19) ]
	bool CheckObjectIsOneOfTheTemplate(struct UObject* Obj, struct TArray<struct UObject*> _ActorFilterTemplates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102747824
	// [Call #6] RVA: 0x10273EE8C
	// [Call #7] RVA: 0x10228936C
	// [Call #8] RVA: 0x10228936C
	// [Call #9] RVA: 0x10228936C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x10228936C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.CheckCollisionNeedSkipOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10275039c
	// Params: [ Num(2) Size(0x5) ]
	bool CheckCollisionNeedSkipOwner(int buildIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10273EF94
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102747824
	// [Call #9] RVA: 0x10273EE8C
	// [Call #10] RVA: 0x10228936C
	// [Call #11] RVA: 0x10228936C
	// [Call #12] RVA: 0x10228936C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x10228936C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function BuildSystem.BuildSystemComponent.BuildAtWorldLoc
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1027501e0
	// Params: [ Num(6) Size(0x4F) ]
	bool BuildAtWorldLoc(int buildIndex, struct FTransform& tranx, struct FVector EndLocation, bool bUseTrace, enum class EBuildingActionType BuildType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10273EF94

	// Object: Function BuildSystem.BuildSystemComponent.AddBuildingData
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102750118
	// Params: [ Num(1) Size(0x48) ]
	void AddBuildingData(struct FBuildingData InData);
	// [Call #1] RVA: 0x102746DC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10274726C
	// [Call #5] RVA: 0x102746F60
	// [Call #6] RVA: 0x102746F60
	// [Call #7] RVA: 0x102746F60
	// [Call #8] RVA: 0x102746F60
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class BuildSystem.SelectBuildActor
// Size: 0x588 (Inherited: 0x570)
struct ASelectBuildActor : ALuaActor
{
	struct UParticleSystemComponent* SelectBuildEffect; // 0x570(0x8)
	struct UStaticMeshComponent* SelectEffectMesh; // 0x578(0x8)
	uint8_t Pad_0x580[0x8]; // 0x580(0x8)


	// Object: Function BuildSystem.SelectBuildActor.SetSelectActorTemplateScale
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1027560bc
	// Params: [ Num(1) Size(0xC) ]
	void SetSelectActorTemplateScale(struct FVector& InScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10273B200
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function BuildSystem.SelectBuildActor.SetSelectActorTemplateOffsetAndRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102755fe4
	// Params: [ Num(2) Size(0x18) ]
	void SetSelectActorTemplateOffsetAndRotation(struct FVector& InOffset, struct FRotator& InRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10273B260
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10273B200
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function BuildSystem.SelectBuildActor.SetSelectActorTemplate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102755f68
	// Params: [ Num(1) Size(0x8) ]
	void SetSelectActorTemplate(struct UParticleSystem* Template);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10273B7F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10273B260
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10273B200
	// [Call #12] RVA: 0x10519022C

	// Object: Function BuildSystem.SelectBuildActor.SetSelectActorPlacementEnable
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102755e90
	// Params: [ Num(2) Size(0x2) ]
	void SetSelectActorPlacementEnable(bool PlacementEnable, bool IsVisible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10273B7F0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10273B260

	// Object: Function BuildSystem.SelectBuildActor.SetSelectActorMesh
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102755e0c
	// Params: [ Num(1) Size(0x8) ]
	void SetSelectActorMesh(struct UStaticMesh* InMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10273B7F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function BuildSystem.SelectBuildActor.SetIsPlacementEnable
	// Flags: [Final|Native|Public]
	// Offset: 0x102755d8c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsPlacementEnable(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10273B7F0

	// Object: Function BuildSystem.SelectBuildActor.OnParticleLoaded
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102755d70
	// Params: [ Num(0) Size(0x0) ]
	void OnParticleLoaded();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function BuildSystem.SelectBuildActor.IsCurrentPlacementEnable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102755d54
	// Params: [ Num(1) Size(0x1) ]
	bool IsCurrentPlacementEnable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function BuildSystem.SelectBuildActor.GetIsPlacementEnable
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102755d38
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsPlacementEnable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function BuildSystem.SelectBuildActor.GetIsParticleEffect
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102755d1c
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsParticleEffect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
};

