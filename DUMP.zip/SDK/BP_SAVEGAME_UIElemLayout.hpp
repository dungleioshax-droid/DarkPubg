#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass BP_SAVEGAME_UIElemLayout.BP_SAVEGAME_UIElemLayout_C
// Size: 0x1A0 (Inherited: 0x28)
struct UBP_SAVEGAME_UIElemLayout_C : USaveGame
{
	struct TMap<int, struct FBP_STRUCT_UIElemLayoutDetail> LayoutDetailDict1; // 0x28(0x50)
	struct TMap<int, struct FBP_STRUCT_UIElemLayoutDetail> LayoutDetailDict2; // 0x78(0x50)
	struct TMap<int, struct FBP_STRUCT_UIElemLayoutDetail> LayoutDetailDict3; // 0xC8(0x50)
	bool IsDataValid1; // 0x118(0x1)
	bool IsDataValid2; // 0x119(0x1)
	bool IsDataValid3; // 0x11A(0x1)
	uint8_t Pad_0x11B[0x1]; // 0x11B(0x1)
	float RushTriggerLength1; // 0x11C(0x4)
	float RushTriggerLength2; // 0x120(0x4)
	float RushTriggerLength3; // 0x124(0x4)
	struct FString SaveSlotName; // 0x128(0x10)
	struct FString LayoutName1; // 0x138(0x10)
	struct FString LayoutName2; // 0x148(0x10)
	struct FString LayoutName3; // 0x158(0x10)
	int TimeTag; // 0x168(0x4)
	uint8_t Pad_0x16C[0x4]; // 0x16C(0x4)
	struct TArray<int> InvalidArray1; // 0x170(0x10)
	struct TArray<int> InvalidArray2; // 0x180(0x10)
	struct TArray<int> InvalidArray3; // 0x190(0x10)
};

