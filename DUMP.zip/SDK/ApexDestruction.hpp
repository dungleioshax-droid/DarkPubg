#pragma once

#include <cstdint>

// Object: Enum ApexDestruction.EImpactDamageOverride
enum class EImpactDamageOverride : uint8_t
{
	IDO_None = 0,
	IDO_On = 1,
	IDO_Off = 2,
	IDO_MAX = 3
};

// Object: ScriptStruct ApexDestruction.DestructibleChunkParameters
// Size: 0x4 (Inherited: 0x0)
struct FDestructibleChunkParameters
{
	bool bIsSupportChunk; // 0x0(0x1)
	bool bDoNotFracture; // 0x1(0x1)
	bool bDoNotDamage; // 0x2(0x1)
	bool bDoNotCrumble; // 0x3(0x1)
};

// Object: ScriptStruct ApexDestruction.FractureMaterial
// Size: 0x24 (Inherited: 0x0)
struct FFractureMaterial
{
	struct FVector2D UVScale; // 0x0(0x8)
	struct FVector2D UVOffset; // 0x8(0x8)
	struct FVector Tangent; // 0x10(0xC)
	float UAngle; // 0x1C(0x4)
	int InteriorElementIndex; // 0x20(0x4)
};

// Object: ScriptStruct ApexDestruction.DestructibleParameters
// Size: 0x88 (Inherited: 0x0)
struct FDestructibleParameters
{
	struct FDestructibleDamageParameters DamageParameters; // 0x0(0x1C)
	struct FDestructibleDebrisParameters DebrisParameters; // 0x1C(0x2C)
	struct FDestructibleAdvancedParameters AdvancedParameters; // 0x48(0x10)
	struct FDestructibleSpecialHierarchyDepths SpecialHierarchyDepths; // 0x58(0x14)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct TArray<struct FDestructibleDepthParameters> DepthParameters; // 0x70(0x10)
	struct FDestructibleParametersFlag Flags; // 0x80(0x4)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
};

// Object: ScriptStruct ApexDestruction.DestructibleParametersFlag
// Size: 0x4 (Inherited: 0x0)
struct FDestructibleParametersFlag
{
	uint8_t bAccumulateDamage : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bAssetDefinedSupport : 1; // 0x0(0x1), Mask(0x2)
	uint8_t bWorldSupport : 1; // 0x0(0x1), Mask(0x4)
	uint8_t bDebrisTimeout : 1; // 0x0(0x1), Mask(0x8)
	uint8_t bDebrisMaxSeparation : 1; // 0x0(0x1), Mask(0x10)
	uint8_t bCrumbleSmallestChunks : 1; // 0x0(0x1), Mask(0x20)
	uint8_t bAccurateRaycasts : 1; // 0x0(0x1), Mask(0x40)
	uint8_t bUseValidBounds : 1; // 0x0(0x1), Mask(0x80)
	uint8_t bFormExtendedStructures : 1; // 0x1(0x1), Mask(0x1)
	uint8_t BitPad_0x1_1 : 7; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
};

// Object: ScriptStruct ApexDestruction.DestructibleDepthParameters
// Size: 0x1 (Inherited: 0x0)
struct FDestructibleDepthParameters
{
	enum class EImpactDamageOverride ImpactDamageOverride; // 0x0(0x1)
};

// Object: ScriptStruct ApexDestruction.DestructibleSpecialHierarchyDepths
// Size: 0x14 (Inherited: 0x0)
struct FDestructibleSpecialHierarchyDepths
{
	int SupportDepth; // 0x0(0x4)
	int MinimumFractureDepth; // 0x4(0x4)
	bool bEnableDebris; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	int DebrisDepth; // 0xC(0x4)
	int EssentialDepth; // 0x10(0x4)
};

// Object: ScriptStruct ApexDestruction.DestructibleAdvancedParameters
// Size: 0x10 (Inherited: 0x0)
struct FDestructibleAdvancedParameters
{
	float DamageCap; // 0x0(0x4)
	float ImpactVelocityThreshold; // 0x4(0x4)
	float MaxChunkSpeed; // 0x8(0x4)
	float FractureImpulseScale; // 0xC(0x4)
};

// Object: ScriptStruct ApexDestruction.DestructibleDebrisParameters
// Size: 0x2C (Inherited: 0x0)
struct FDestructibleDebrisParameters
{
	float DebrisLifetimeMin; // 0x0(0x4)
	float DebrisLifetimeMax; // 0x4(0x4)
	float DebrisMaxSeparationMin; // 0x8(0x4)
	float DebrisMaxSeparationMax; // 0xC(0x4)
	struct FBox ValidBounds; // 0x10(0x1C)
};

// Object: ScriptStruct ApexDestruction.DestructibleDamageParameters
// Size: 0x1C (Inherited: 0x0)
struct FDestructibleDamageParameters
{
	float DamageThreshold; // 0x0(0x4)
	float DamageSpread; // 0x4(0x4)
	bool bEnableImpactDamage; // 0x8(0x1)
	uint8_t Pad_0x9[0x3]; // 0x9(0x3)
	float ImpactDamage; // 0xC(0x4)
	int DefaultImpactDamageDepth; // 0x10(0x4)
	bool bCustomImpactResistance; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	float ImpactResistance; // 0x18(0x4)
};

// Object: Class ApexDestruction.DestructibleActor
// Size: 0x4D0 (Inherited: 0x4B0)
struct ADestructibleActor : AActor
{
	struct UDestructibleComponent* DestructibleComponent; // 0x4B0(0x8)
	uint8_t bAffectNavigation : 1; // 0x4B8(0x1), Mask(0x1)
	uint8_t BitPad_0x4B8_1 : 7; // 0x4B8(0x1)
	uint8_t Pad_0x4B9[0x7]; // 0x4B9(0x7)
	struct FScriptMulticastDelegate OnActorFracture; // 0x4C0(0x10)
};

// Object: Class ApexDestruction.DestructibleComponent
// Size: 0xD10 (Inherited: 0xC40)
struct UDestructibleComponent : USkinnedMeshComponent
{
	uint8_t bFractureEffectOverride : 1; // 0xC40(0x1), Mask(0x1)
	uint8_t BitPad_0xC40_1 : 7; // 0xC40(0x1)
	uint8_t Pad_0xC41[0x7]; // 0xC41(0x7)
	struct TArray<struct FFractureEffect> FractureEffects; // 0xC48(0x10)
	bool bEnableHardSleeping; // 0xC58(0x1)
	uint8_t Pad_0xC59[0x3]; // 0xC59(0x3)
	float LargeChunkThreshold; // 0xC5C(0x4)
	uint8_t Pad_0xC60[0x10]; // 0xC60(0x10)
	struct FScriptMulticastDelegate OnComponentFracture; // 0xC70(0x10)
	uint8_t Pad_0xC80[0x90]; // 0xC80(0x90)


	// Object: Function ApexDestruction.DestructibleComponent.SetDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c6608
	// Params: [ Num(1) Size(0x8) ]
	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069C477C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function ApexDestruction.DestructibleComponent.GetDestructibleMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069c65d4
	// Params: [ Num(1) Size(0x8) ]
	struct UDestructibleMesh* GetDestructibleMesh();
	// [Call #1] RVA: 0x1069C4604
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1069C477C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1069c6448
	// Params: [ Num(5) Size(0x19) ]
	void ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1069C4604
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1069C477C

	// Object: Function ApexDestruction.DestructibleComponent.ApplyDamage
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1069c62f0
	// Params: [ Num(4) Size(0x20) ]
	void ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class ApexDestruction.DestructibleFractureSettings
// Size: 0x90 (Inherited: 0x28)
struct UDestructibleFractureSettings : UObject
{
	int CellSiteCount; // 0x28(0x4)
	struct FFractureMaterial FractureMaterialDesc; // 0x2C(0x24)
	int RandomSeed; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct TArray<struct FVector> VoronoiSites; // 0x58(0x10)
	int OriginalSubmeshCount; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct TArray<struct UMaterialInterface*> Materials; // 0x70(0x10)
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters; // 0x80(0x10)
};

// Object: Class ApexDestruction.DestructibleMesh
// Size: 0x4A0 (Inherited: 0x408)
struct UDestructibleMesh : USkeletalMesh
{
	struct FDestructibleParameters DefaultDestructibleParameters; // 0x408(0x88)
	struct TArray<struct FFractureEffect> FractureEffects; // 0x490(0x10)
};

