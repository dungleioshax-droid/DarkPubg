#pragma once

#include <cstdint>

// Object: Enum MeshDescription.EComputeNTBsOptions
enum class EComputeNTBsOptions : uint8_t
{
	None = 0,
	Normals = 1,
	Tangents = 2,
	WeightedNTBs = 4,
	EComputeNTBsOptions_MAX = 5
};

// Object: ScriptStruct MeshDescription.MeshTriangle
// Size: 0xC (Inherited: 0x0)
struct FMeshTriangle
{
	struct FVertexInstanceID VertexInstanceID0; // 0x0(0x4)
	struct FVertexInstanceID VertexInstanceID1; // 0x4(0x4)
	struct FVertexInstanceID VertexInstanceID2; // 0x8(0x4)
};

// Object: ScriptStruct MeshDescription.ElementID
// Size: 0x4 (Inherited: 0x0)
struct FElementID
{
	int IDValue; // 0x0(0x4)
};

// Object: ScriptStruct MeshDescription.VertexInstanceID
// Size: 0x4 (Inherited: 0x4)
struct FVertexInstanceID : FElementID
{
};

// Object: ScriptStruct MeshDescription.PolygonID
// Size: 0x4 (Inherited: 0x4)
struct FPolygonID : FElementID
{
};

// Object: ScriptStruct MeshDescription.PolygonGroupID
// Size: 0x4 (Inherited: 0x4)
struct FPolygonGroupID : FElementID
{
};

// Object: ScriptStruct MeshDescription.EdgeID
// Size: 0x4 (Inherited: 0x4)
struct FEdgeID : FElementID
{
};

// Object: ScriptStruct MeshDescription.VertexID
// Size: 0x4 (Inherited: 0x4)
struct FVertexID : FElementID
{
};

// Object: Class MeshDescription.MeshDescription
// Size: 0x28 (Inherited: 0x28)
struct UMeshDescription : UObject
{
};

