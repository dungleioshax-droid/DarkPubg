#pragma once

#include <cstdint>

// Object: Enum Paper2D.EFlipbookCollisionMode
enum class EFlipbookCollisionMode : uint8_t
{
	NoCollision = 0,
	FirstFrameCollision = 1,
	EachFrameCollision = 2,
	EFlipbookCollisionMode_MAX = 3
};

// Object: Enum Paper2D.EPaperSpriteAtlasPadding
enum class EPaperSpriteAtlasPadding : uint8_t
{
	DilateBorder = 0,
	PadWithZero = 1,
	EPaperSpriteAtlasPadding_MAX = 2
};

// Object: Enum Paper2D.ETileMapProjectionMode
enum class ETileMapProjectionMode : uint8_t
{
	Orthogonal = 0,
	IsometricDiamond = 1,
	IsometricStaggered = 2,
	HexagonalStaggered = 3,
	ETileMapProjectionMode_MAX = 4
};

// Object: Enum Paper2D.ESpritePivotMode
enum class ESpritePivotMode : uint8_t
{
	Top_Left = 0,
	Top_Center = 1,
	Top_Right = 2,
	Center_Left = 3,
	Center_Center = 4,
	Center_Right = 5,
	Bottom_Left = 6,
	Bottom_Center = 7,
	Bottom_Right = 8,
	Custom = 9,
	ESpritePivotMode_MAX = 10
};

// Object: Enum Paper2D.ESpritePolygonMode
enum class ESpritePolygonMode : uint8_t
{
	SourceBoundingBox = 0,
	TightBoundingBox = 1,
	ShrinkWrapped = 2,
	FullyCustom = 3,
	Diced = 4,
	ESpritePolygonMode_MAX = 5
};

// Object: Enum Paper2D.ESpriteShapeType
enum class ESpriteShapeType : uint8_t
{
	Box = 0,
	Circle = 1,
	Polygon = 2,
	ESpriteShapeType_MAX = 3
};

// Object: Enum Paper2D.ESpriteCollisionMode
enum class ESpriteCollisionMode : uint8_t
{
	None = 0,
	Use2DPhysics = 1,
	Use3DPhysics = 2,
	ESpriteCollisionMode_MAX = 3
};

// Object: ScriptStruct Paper2D.IntMargin
// Size: 0x10 (Inherited: 0x0)
struct FIntMargin
{
	int Left; // 0x0(0x4)
	int Top; // 0x4(0x4)
	int Right; // 0x8(0x4)
	int Bottom; // 0xC(0x4)
};

// Object: ScriptStruct Paper2D.PaperFlipbookKeyFrame
// Size: 0x10 (Inherited: 0x0)
struct FPaperFlipbookKeyFrame
{
	struct UPaperSprite* Sprite; // 0x0(0x8)
	int FrameRun; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Paper2D.SpriteInstanceData
// Size: 0x50 (Inherited: 0x0)
struct FSpriteInstanceData
{
	struct FMatrix Transform; // 0x0(0x40)
	struct UPaperSprite* SourceSprite; // 0x40(0x8)
	struct FColor VertexColor; // 0x48(0x4)
	int MaterialIndex; // 0x4C(0x4)
};

// Object: ScriptStruct Paper2D.PaperSpriteSocket
// Size: 0x40 (Inherited: 0x0)
struct FPaperSpriteSocket
{
	struct FTransform LocalTransform; // 0x0(0x30)
	struct FName SocketName; // 0x30(0x8)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
};

// Object: ScriptStruct Paper2D.PaperSpriteAtlasSlot
// Size: 0x40 (Inherited: 0x0)
struct FPaperSpriteAtlasSlot
{
	struct UPaperSprite* SpriteRef; // 0x0(0x28)
	int AtlasIndex; // 0x28(0x4)
	int X; // 0x2C(0x4)
	int Y; // 0x30(0x4)
	int Width; // 0x34(0x4)
	int Height; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct Paper2D.PaperTerrainMaterialRule
// Size: 0x38 (Inherited: 0x0)
struct FPaperTerrainMaterialRule
{
	struct UPaperSprite* StartCap; // 0x0(0x8)
	struct TArray<struct UPaperSprite*> Body; // 0x8(0x10)
	struct UPaperSprite* EndCap; // 0x18(0x8)
	float MinimumAngle; // 0x20(0x4)
	float MaximumAngle; // 0x24(0x4)
	bool bEnableCollision; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float CollisionOffset; // 0x2C(0x4)
	int DrawOrder; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct Paper2D.PaperTileInfo
// Size: 0x10 (Inherited: 0x0)
struct FPaperTileInfo
{
	struct UPaperTileSet* TileSet; // 0x0(0x8)
	int PackedTileIndex; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct Paper2D.PaperTileSetTerrain
// Size: 0x18 (Inherited: 0x0)
struct FPaperTileSetTerrain
{
	struct FString TerrainName; // 0x0(0x10)
	int CenterTileIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct Paper2D.PaperTileMetadata
// Size: 0x40 (Inherited: 0x0)
struct FPaperTileMetadata
{
	struct FName UserDataName; // 0x0(0x8)
	struct FSpriteGeometryCollection CollisionData; // 0x8(0x30)
	uint8_t TerrainMembership[0x4]; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: ScriptStruct Paper2D.SpriteGeometryCollection
// Size: 0x30 (Inherited: 0x0)
struct FSpriteGeometryCollection
{
	struct TArray<struct FSpriteGeometryShape> Shapes; // 0x0(0x10)
	enum class ESpritePolygonMode GeometryType; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	int PixelsPerSubdivisionX; // 0x14(0x4)
	int PixelsPerSubdivisionY; // 0x18(0x4)
	bool bAvoidVertexMerging; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
	float AlphaThreshold; // 0x20(0x4)
	float DetailAmount; // 0x24(0x4)
	float SimplifyEpsilon; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct Paper2D.SpriteGeometryShape
// Size: 0x30 (Inherited: 0x0)
struct FSpriteGeometryShape
{
	uint8_t ShapeType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TArray<struct FVector2D> Vertices; // 0x8(0x10)
	struct FVector2D BoxSize; // 0x18(0x8)
	struct FVector2D BoxPosition; // 0x20(0x8)
	float Rotation; // 0x28(0x4)
	bool bNegativeWinding; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
};

// Object: ScriptStruct Paper2D.SpriteDrawCallRecord
// Size: 0xD0 (Inherited: 0x0)
struct FSpriteDrawCallRecord
{
	struct FVector Destination; // 0x0(0xC)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct UTexture* BaseTexture; // 0x10(0x8)
	uint8_t Pad_0x18[0x30]; // 0x18(0x30)
	struct FColor Color; // 0x48(0x4)
	uint8_t Pad_0x4C[0x84]; // 0x4C(0x84)
};

// Object: ScriptStruct Paper2D.SpriteAssetInitParameters
// Size: 0x40 (Inherited: 0x0)
struct FSpriteAssetInitParameters
{
	uint8_t Pad_0x0[0x40]; // 0x0(0x40)
};

// Object: Class Paper2D.MaterialExpressionSpriteTextureSampler
// Size: 0x1D8 (Inherited: 0x1B8)
struct UMaterialExpressionSpriteTextureSampler : UMaterialExpressionTextureSampleParameter2D
{
	bool bSampleAdditionalTextures; // 0x1B8(0x1)
	uint8_t Pad_0x1B9[0x3]; // 0x1B9(0x3)
	int AdditionalSlotIndex; // 0x1BC(0x4)
	struct FText SlotDisplayName; // 0x1C0(0x18)
};

// Object: Class Paper2D.PaperCharacter
// Size: 0x8F0 (Inherited: 0x8F0)
struct APaperCharacter : ACharacter
{
	struct UPaperFlipbookComponent* Sprite; // 0x8E8(0x8)
};

// Object: Class Paper2D.PaperFlipbook
// Size: 0x50 (Inherited: 0x28)
struct UPaperFlipbook : UObject
{
	float FramesPerSecond; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
	struct TArray<struct FPaperFlipbookKeyFrame> KeyFrames; // 0x30(0x10)
	struct UMaterialInterface* DefaultMaterial; // 0x40(0x8)
	enum class EFlipbookCollisionMode CollisionSource; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)


	// Object: Function Paper2D.PaperFlipbook.IsValidKeyFrameIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571114
	// Params: [ Num(2) Size(0x5) ]
	bool IsValidKeyFrameIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Paper2D.PaperFlipbook.GetTotalDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025710e0
	// Params: [ Num(1) Size(0x4) ]
	float GetTotalDuration();
	// [Call #1] RVA: 0x102557B08
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Paper2D.PaperFlipbook.GetSpriteAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571010
	// Params: [ Num(3) Size(0x10) ]
	struct UPaperSprite* GetSpriteAtTime(float Time, bool bClampToEnds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102557BBC
	// [Call #6] RVA: 0x102557B08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function Paper2D.PaperFlipbook.GetSpriteAtFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102570f84
	// Params: [ Num(2) Size(0x10) ]
	struct UPaperSprite* GetSpriteAtFrame(int FrameIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102557C00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102557BBC
	// [Call #9] RVA: 0x102557B08
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbook.GetNumKeyFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102570f68
	// Params: [ Num(1) Size(0x4) ]
	int GetNumKeyFrames();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102557C00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102557BBC
	// [Call #9] RVA: 0x102557B08
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbook.GetNumFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102570f34
	// Params: [ Num(1) Size(0x4) ]
	int GetNumFrames();
	// [Call #1] RVA: 0x102557AD4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102557C00
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102557BBC
	// [Call #10] RVA: 0x102557B08
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbook.GetKeyFrameIndexAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102570e64
	// Params: [ Num(3) Size(0xC) ]
	int GetKeyFrameIndexAtTime(float Time, bool bClampToEnds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102557B40
	// [Call #6] RVA: 0x102557AD4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102557C00
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class Paper2D.PaperFlipbookActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct APaperFlipbookActor : AActor
{
	struct UPaperFlipbookComponent* RenderComponent; // 0x4B0(0x8)
};

// Object: Class Paper2D.PaperFlipbookComponent
// Size: 0xA70 (Inherited: 0xA20)
struct UPaperFlipbookComponent : UMeshComponent
{
	struct UPaperFlipbook* SourceFlipbook; // 0xA20(0x8)
	struct UMaterialInterface* Material; // 0xA28(0x8)
	float PlayRate; // 0xA30(0x4)
	uint8_t bLooping : 1; // 0xA34(0x1), Mask(0x1)
	uint8_t bReversePlayback : 1; // 0xA34(0x1), Mask(0x2)
	uint8_t bPlayIng : 1; // 0xA34(0x1), Mask(0x4)
	uint8_t BitPad_0xA34_3 : 5; // 0xA34(0x1)
	uint8_t Pad_0xA35[0x3]; // 0xA35(0x3)
	float AccumulatedTime; // 0xA38(0x4)
	int CachedFrameIndex; // 0xA3C(0x4)
	struct FLinearColor SpriteColor; // 0xA40(0x10)
	struct UBodySetup* CachedBodySetup; // 0xA50(0x8)
	struct FScriptMulticastDelegate OnFinishedPlaying; // 0xA58(0x10)
	uint8_t Pad_0xA68[0x8]; // 0xA68(0x8)


	// Object: Function Paper2D.PaperFlipbookComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571cac
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Paper2D.PaperFlipbookComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102571c30
	// Params: [ Num(1) Size(0x10) ]
	void SetSpriteColor(struct FLinearColor NewColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102559194
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571bb4
	// Params: [ Num(1) Size(0x4) ]
	void SetPlayRate(float NewRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10255942C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102559194
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571af8
	// Params: [ Num(2) Size(0x5) ]
	void SetPlaybackPositionInFrames(int NewFramePosition, bool bFireEvents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102559340
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255942C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102559194
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571a38
	// Params: [ Num(2) Size(0x5) ]
	void SetPlaybackPosition(float NewPosition, bool bFireEvents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102558D2C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102559340
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10255942C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.SetNewTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025719bc
	// Params: [ Num(1) Size(0x4) ]
	void SetNewTime(float NewTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10255943C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102558D2C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102559340
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571938
	// Params: [ Num(1) Size(0x1) ]
	void SetLooping(bool bNewLooping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10255940C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10255943C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102558D2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.SetFlipbook
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025718a4
	// Params: [ Num(2) Size(0x9) ]
	bool SetFlipbook(struct UPaperFlipbook* NewFlipbook);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255940C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255943C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102558D2C

	// Object: Function Paper2D.PaperFlipbookComponent.ReverseFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571890
	// Params: [ Num(0) Size(0x0) ]
	void ReverseFromEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255940C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255943C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102558D2C

	// Object: Function Paper2D.PaperFlipbookComponent.Reverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10257187c
	// Params: [ Num(0) Size(0x0) ]
	void Reverse();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255940C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255943C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571868
	// Params: [ Num(0) Size(0x0) ]
	void PlayFromStart();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255940C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255943C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102571854
	// Params: [ Num(0) Size(0x0) ]
	void Play();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255940C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255943C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Paper2D.PaperFlipbookComponent.OnRep_SourceFlipbook
	// Flags: [Final|Native|Protected]
	// Offset: 0x1025717d8
	// Params: [ Num(1) Size(0x8) ]
	void OnRep_SourceFlipbook(struct UPaperFlipbook* OldFlipbook);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102558E48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255940C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10255943C

	// Object: Function Paper2D.PaperFlipbookComponent.IsReversing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025717a4
	// Params: [ Num(1) Size(0x1) ]
	bool IsReversing();
	// [Call #1] RVA: 0x10255932C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102558E48
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10255940C
	// [Call #10] RVA: 0x10516D168

	// Object: Function Paper2D.PaperFlipbookComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571770
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
	// [Call #1] RVA: 0x102559320
	// [Call #2] RVA: 0x10255932C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102558E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10255940C

	// Object: Function Paper2D.PaperFlipbookComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10257173c
	// Params: [ Num(1) Size(0x1) ]
	bool IsLooping();
	// [Call #1] RVA: 0x102559420
	// [Call #2] RVA: 0x102559320
	// [Call #3] RVA: 0x10255932C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102558E48
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571708
	// Params: [ Num(1) Size(0x4) ]
	float GetPlayRate();
	// [Call #1] RVA: 0x102559434
	// [Call #2] RVA: 0x102559420
	// [Call #3] RVA: 0x102559320
	// [Call #4] RVA: 0x10255932C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102558E48
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025716d4
	// Params: [ Num(1) Size(0x4) ]
	int GetPlaybackPositionInFrames();
	// [Call #1] RVA: 0x102559388
	// [Call #2] RVA: 0x102559434
	// [Call #3] RVA: 0x102559420
	// [Call #4] RVA: 0x102559320
	// [Call #5] RVA: 0x10255932C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102558E48
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025716a0
	// Params: [ Num(1) Size(0x4) ]
	float GetPlaybackPosition();
	// [Call #1] RVA: 0x102559404
	// [Call #2] RVA: 0x102559388
	// [Call #3] RVA: 0x102559434
	// [Call #4] RVA: 0x102559420
	// [Call #5] RVA: 0x102559320
	// [Call #6] RVA: 0x10255932C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102558E48
	// [Call #10] RVA: 0x10516D168

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookLengthInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10257166c
	// Params: [ Num(1) Size(0x4) ]
	int GetFlipbookLengthInFrames();
	// [Call #1] RVA: 0x1025593F4
	// [Call #2] RVA: 0x102559404
	// [Call #3] RVA: 0x102559388
	// [Call #4] RVA: 0x102559434
	// [Call #5] RVA: 0x102559420
	// [Call #6] RVA: 0x102559320
	// [Call #7] RVA: 0x10255932C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102558E48

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571638
	// Params: [ Num(1) Size(0x4) ]
	float GetFlipbookLength();
	// [Call #1] RVA: 0x102558D18
	// [Call #2] RVA: 0x1025593F4
	// [Call #3] RVA: 0x102559404
	// [Call #4] RVA: 0x102559388
	// [Call #5] RVA: 0x102559434
	// [Call #6] RVA: 0x102559420
	// [Call #7] RVA: 0x102559320
	// [Call #8] RVA: 0x10255932C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102558E48

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookFramerate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102571604
	// Params: [ Num(1) Size(0x4) ]
	float GetFlipbookFramerate();
	// [Call #1] RVA: 0x102559370
	// [Call #2] RVA: 0x102558D18
	// [Call #3] RVA: 0x1025593F4
	// [Call #4] RVA: 0x102559404
	// [Call #5] RVA: 0x102559388
	// [Call #6] RVA: 0x102559434
	// [Call #7] RVA: 0x102559420
	// [Call #8] RVA: 0x102559320
	// [Call #9] RVA: 0x10255932C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102558E48

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbook
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1025715c8
	// Params: [ Num(1) Size(0x8) ]
	struct UPaperFlipbook* GetFlipbook();
	// [Call #1] RVA: 0x102559370
	// [Call #2] RVA: 0x102558D18
	// [Call #3] RVA: 0x1025593F4
	// [Call #4] RVA: 0x102559404
	// [Call #5] RVA: 0x102559388
	// [Call #6] RVA: 0x102559434
	// [Call #7] RVA: 0x102559420
	// [Call #8] RVA: 0x102559320
	// [Call #9] RVA: 0x10255932C
	// [Call #10] RVA: 0x10516D168
};

// Object: Class Paper2D.PaperGroupedSpriteActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct APaperGroupedSpriteActor : AActor
{
	struct UPaperGroupedSpriteComponent* RenderComponent; // 0x4B0(0x8)
};

// Object: Class Paper2D.PaperGroupedSpriteComponent
// Size: 0xA50 (Inherited: 0xA20)
struct UPaperGroupedSpriteComponent : UMeshComponent
{
	struct TArray<struct UMaterialInterface*> InstanceMaterials; // 0xA20(0x10)
	struct TArray<struct FSpriteInstanceData> PerInstanceSpriteData; // 0xA30(0x10)
	uint8_t Pad_0xA40[0x10]; // 0xA40(0x10)


	// Object: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceTransform
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102572b64
	// Params: [ Num(6) Size(0x44) ]
	bool UpdateInstanceTransform(int InstanceIndex, struct FTransform& NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102572a50
	// Params: [ Num(4) Size(0x16) ]
	bool UpdateInstanceColor(int InstanceIndex, struct FLinearColor NewInstanceColor, bool bMarkRenderStateDirty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperGroupedSpriteComponent.SortInstancesAlongAxis
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1025729d4
	// Params: [ Num(1) Size(0xC) ]
	void SortInstancesAlongAxis(struct FVector WorldSpaceSortAxis);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10255E948
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperGroupedSpriteComponent.RemoveInstance
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102572940
	// Params: [ Num(2) Size(0x5) ]
	bool RemoveInstance(int InstanceIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10255E948
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10257280c
	// Params: [ Num(4) Size(0x42) ]
	bool GetInstanceTransform(int InstanceIndex, struct FTransform& OutInstanceTransform, bool bWorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10255C124
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10255E948

	// Object: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025727d8
	// Params: [ Num(1) Size(0x4) ]
	int GetInstanceCount();
	// [Call #1] RVA: 0x10255D4E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255C124
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperGroupedSpriteComponent.ClearInstances
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025727bc
	// Params: [ Num(0) Size(0x0) ]
	void ClearInstances();
	// [Call #1] RVA: 0x10255D4E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10255C124
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Paper2D.PaperGroupedSpriteComponent.AddInstance
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102572644
	// Params: [ Num(5) Size(0x50) ]
	int AddInstance(struct FTransform& Transform, struct UPaperSprite* Sprite, bool bWorldSpace, struct FLinearColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10255BDEC
	// [Call #10] RVA: 0x10255D4E0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
};

// Object: Class Paper2D.PaperRuntimeSettings
// Size: 0x30 (Inherited: 0x28)
struct UPaperRuntimeSettings : UObject
{
	bool bEnableSpriteAtlasGroups; // 0x28(0x1)
	bool bEnableTerrainSplineEditing; // 0x29(0x1)
	bool bResizeSpriteDataToMatchTextures; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x5]; // 0x2B(0x5)
};

// Object: Class Paper2D.PaperSprite
// Size: 0xC0 (Inherited: 0x28)
struct UPaperSprite : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
	struct FVector2D SourceUV; // 0x38(0x8)
	struct FVector2D SourceDimension; // 0x40(0x8)
	struct UTexture2D* SourceTexture; // 0x48(0x8)
	struct TArray<struct UTexture*> AdditionalSourceTextures; // 0x50(0x10)
	struct FVector2D BakedSourceUV; // 0x60(0x8)
	struct FVector2D BakedSourceDimension; // 0x68(0x8)
	struct UTexture2D* BakedSourceTexture; // 0x70(0x8)
	struct UMaterialInterface* DefaultMaterial; // 0x78(0x8)
	struct UMaterialInterface* AlternateMaterial; // 0x80(0x8)
	struct TArray<struct FPaperSpriteSocket> Sockets; // 0x88(0x10)
	enum class ESpriteCollisionMode SpriteCollisionDomain; // 0x98(0x1)
	uint8_t Pad_0x99[0x3]; // 0x99(0x3)
	float PixelsPerUnrealUnit; // 0x9C(0x4)
	struct UBodySetup* BodySetup; // 0xA0(0x8)
	int AlternateMaterialSplitIndex; // 0xA8(0x4)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
	struct TArray<struct FVector4> BakedRenderData; // 0xB0(0x10)
};

// Object: Class Paper2D.PaperSpriteActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct APaperSpriteActor : AActor
{
	struct UPaperSpriteComponent* RenderComponent; // 0x4B0(0x8)
};

// Object: Class Paper2D.PaperSpriteAtlas
// Size: 0x28 (Inherited: 0x28)
struct UPaperSpriteAtlas : UObject
{
};

// Object: Class Paper2D.PaperSpriteBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPaperSpriteBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Paper2D.PaperSpriteBlueprintLibrary.MakeBrushFromSprite
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102573708
	// Params: [ Num(4) Size(0xC8) ]
	struct FSlateBrush MakeBrushFromSprite(struct UPaperSprite* Sprite, int Width, int Height);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1025610F0
	// [Call #8] RVA: 0x101FE5E98
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x101FEA144
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10508F76C
};

// Object: Class Paper2D.PaperSpriteComponent
// Size: 0xA40 (Inherited: 0xA20)
struct UPaperSpriteComponent : UMeshComponent
{
	struct UPaperSprite* SourceSprite; // 0xA20(0x8)
	struct UMaterialInterface* MaterialOverride; // 0xA28(0x8)
	struct FLinearColor SpriteColor; // 0xA30(0x10)


	// Object: Function Paper2D.PaperSpriteComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102573a50
	// Params: [ Num(1) Size(0x10) ]
	void SetSpriteColor(struct FLinearColor NewColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102562628
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function Paper2D.PaperSpriteComponent.SetSprite
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025739bc
	// Params: [ Num(2) Size(0x9) ]
	bool SetSprite(struct UPaperSprite* NewSprite);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102562628
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Paper2D.PaperSpriteComponent.GetSprite
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102573980
	// Params: [ Num(1) Size(0x8) ]
	struct UPaperSprite* GetSprite();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102562628
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class Paper2D.PaperTerrainActor
// Size: 0x4C8 (Inherited: 0x4B0)
struct APaperTerrainActor : AActor
{
	struct USceneComponent* DummyRoot; // 0x4B0(0x8)
	struct UPaperTerrainSplineComponent* SplineComponent; // 0x4B8(0x8)
	struct UPaperTerrainComponent* RenderComponent; // 0x4C0(0x8)
};

// Object: Class Paper2D.PaperTerrainComponent
// Size: 0xA20 (Inherited: 0x9D0)
struct UPaperTerrainComponent : UPrimitiveComponent
{
	struct UPaperTerrainMaterial* TerrainMaterial; // 0x9C8(0x8)
	bool bClosedSpline; // 0x9D0(0x1)
	bool bFilledSpline; // 0x9D1(0x1)
	struct UPaperTerrainSplineComponent* AssociatedSpline; // 0x9D8(0x8)
	int RandomSeed; // 0x9E0(0x4)
	float SegmentOverlapAmount; // 0x9E4(0x4)
	struct FLinearColor TerrainColor; // 0x9E8(0x10)
	int ReparamStepsPerSegment; // 0x9F8(0x4)
	enum class ESpriteCollisionMode SpriteCollisionDomain; // 0x9FC(0x1)
	uint8_t Pad_0x9FF[0x1]; // 0x9FF(0x1)
	float CollisionThickness; // 0xA00(0x4)
	uint8_t Pad_0xA04[0x4]; // 0xA04(0x4)
	struct UBodySetup* CachedBodySetup; // 0xA08(0x8)
	uint8_t Pad_0xA10[0x10]; // 0xA10(0x10)


	// Object: Function Paper2D.PaperTerrainComponent.SetTerrainColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102573dc8
	// Params: [ Num(1) Size(0x10) ]
	void SetTerrainColor(struct FLinearColor NewColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10256A334
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102570A24
	// [Call #8] RVA: 0x105184F34
};

// Object: Class Paper2D.PaperTerrainMaterial
// Size: 0x48 (Inherited: 0x30)
struct UPaperTerrainMaterial : UDataAsset
{
	struct TArray<struct FPaperTerrainMaterialRule> Rules; // 0x30(0x10)
	struct UPaperSprite* InteriorFill; // 0x40(0x8)
};

// Object: Class Paper2D.PaperTerrainSplineComponent
// Size: 0xAC0 (Inherited: 0xAB0)
struct UPaperTerrainSplineComponent : USplineComponent
{
	uint8_t Pad_0xAB0[0x10]; // 0xAB0(0x10)
};

// Object: Class Paper2D.PaperTileLayer
// Size: 0x98 (Inherited: 0x28)
struct UPaperTileLayer : UObject
{
	struct FText LayerName; // 0x28(0x18)
	int LayerWidth; // 0x40(0x4)
	int LayerHeight; // 0x44(0x4)
	uint8_t bHiddenInGame : 1; // 0x48(0x1), Mask(0x1)
	uint8_t bLayerCollides : 1; // 0x48(0x1), Mask(0x2)
	uint8_t bOverrideCollisionThickness : 1; // 0x48(0x1), Mask(0x4)
	uint8_t bOverrideCollisionOffset : 1; // 0x48(0x1), Mask(0x8)
	uint8_t BitPad_0x48_4 : 4; // 0x48(0x1)
	uint8_t Pad_0x49[0x3]; // 0x49(0x3)
	float CollisionThicknessOverride; // 0x4C(0x4)
	float CollisionOffsetOverride; // 0x50(0x4)
	struct FLinearColor LayerColor; // 0x54(0x10)
	int AllocatedWidth; // 0x64(0x4)
	int AllocatedHeight; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct TArray<struct FPaperTileInfo> AllocatedCells; // 0x70(0x10)
	struct UPaperTileSet* TileSet; // 0x80(0x8)
	struct TArray<int> AllocatedGrid; // 0x88(0x10)
};

// Object: Class Paper2D.PaperTileMap
// Size: 0xA8 (Inherited: 0x28)
struct UPaperTileMap : UObject
{
	int MapWidth; // 0x28(0x4)
	int MapHeight; // 0x2C(0x4)
	int TileWidth; // 0x30(0x4)
	int TileHeight; // 0x34(0x4)
	float PixelsPerUnrealUnit; // 0x38(0x4)
	float SeparationPerTileX; // 0x3C(0x4)
	float SeparationPerTileY; // 0x40(0x4)
	float SeparationPerLayer; // 0x44(0x4)
	struct UPaperTileSet* SelectedTileSet; // 0x48(0x28)
	struct UMaterialInterface* Material; // 0x70(0x8)
	struct TArray<struct UPaperTileLayer*> TileLayers; // 0x78(0x10)
	float CollisionThickness; // 0x88(0x4)
	enum class ESpriteCollisionMode SpriteCollisionDomain; // 0x8C(0x1)
	enum class ETileMapProjectionMode ProjectionMode; // 0x8D(0x1)
	uint8_t Pad_0x8E[0x2]; // 0x8E(0x2)
	int HexSideLength; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
	struct UBodySetup* BodySetup; // 0x98(0x8)
	int LayerNameIndex; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
};

// Object: Class Paper2D.PaperTileMapActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct APaperTileMapActor : AActor
{
	struct UPaperTileMapComponent* RenderComponent; // 0x4B0(0x8)
};

// Object: Class Paper2D.PaperTileMapComponent
// Size: 0xA70 (Inherited: 0xA20)
struct UPaperTileMapComponent : UMeshComponent
{
	int MapWidth; // 0xA20(0x4)
	int MapHeight; // 0xA24(0x4)
	int TileWidth; // 0xA28(0x4)
	int TileHeight; // 0xA2C(0x4)
	struct UPaperTileSet* DefaultLayerTileSet; // 0xA30(0x8)
	struct UMaterialInterface* Material; // 0xA38(0x8)
	struct TArray<struct UPaperTileLayer*> TileLayers; // 0xA40(0x10)
	struct FLinearColor TileMapColor; // 0xA50(0x10)
	int UseSingleLayerIndex; // 0xA60(0x4)
	bool bUseSingleLayer; // 0xA64(0x1)
	uint8_t Pad_0xA65[0x3]; // 0xA65(0x3)
	struct UPaperTileMap* TileMap; // 0xA68(0x8)


	// Object: Function Paper2D.PaperTileMapComponent.SetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102575690
	// Params: [ Num(1) Size(0x10) ]
	void SetTileMapColor(struct FLinearColor NewColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025658A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Paper2D.PaperTileMapComponent.SetTileMap
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025755fc
	// Params: [ Num(2) Size(0x9) ]
	bool SetTileMap(struct UPaperTileMap* NewTileMap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025658A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Paper2D.PaperTileMapComponent.SetTile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025754c8
	// Params: [ Num(4) Size(0x20) ]
	void SetTile(int X, int Y, int Layer, struct FPaperTileInfo NewValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025656C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1025658A4

	// Object: Function Paper2D.PaperTileMapComponent.SetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102575410
	// Params: [ Num(2) Size(0x14) ]
	void SetLayerColor(struct FLinearColor NewColor, int Layer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102565900
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1025656C0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.SetLayerCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025751fc
	// Params: [ Num(7) Size(0x15) ]
	void SetLayerCollision(int Layer, bool bHasCollision, bool bOverrideThickness, float CustomThickness, bool bOverrideOffset, float CustomOffset, bool bRebuildCollision);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102565D24
	// [Call #16] RVA: 0x10516D168

	// Object: Function Paper2D.PaperTileMapComponent.SetDefaultCollisionThickness
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10257513c
	// Params: [ Num(2) Size(0x5) ]
	void SetDefaultCollisionThickness(float Thickness, bool bRebuildCollision);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102565CB0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Paper2D.PaperTileMapComponent.ResizeMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102575088
	// Params: [ Num(2) Size(0x8) ]
	void ResizeMap(int NewWidthInTiles, int NewHeightInTiles);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025657C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102565CB0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.RebuildCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102575074
	// Params: [ Num(0) Size(0x0) ]
	void RebuildCollision();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025657C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102565CB0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.OwnsTileMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102575040
	// Params: [ Num(1) Size(0x1) ]
	bool OwnsTileMap();
	// [Call #1] RVA: 0x1025655A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025657C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102565CB0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.MakeTileMapEditable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10257502c
	// Params: [ Num(0) Size(0x0) ]
	void MakeTileMapEditable();
	// [Call #1] RVA: 0x1025655A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025657C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102565CB0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Paper2D.PaperTileMapComponent.GetTilePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574e80
	// Params: [ Num(5) Size(0x1D) ]
	void GetTilePolygon(int TileX, int TileY, struct TArray<struct FVector>& Points, int LayerIndex, bool bWorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102565B80
	// [Call #12] RVA: 0x101F8C3A4
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1025655A0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.GetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574e48
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetTileMapColor();
	// [Call #1] RVA: 0x102565890
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102565B80
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x101F8C3A4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1025655A0

	// Object: Function Paper2D.PaperTileMapComponent.GetTileCornerPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574d04
	// Params: [ Num(5) Size(0x1C) ]
	struct FVector GetTileCornerPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102565990
	// [Call #10] RVA: 0x102565890
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.GetTileCenterPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574bc0
	// Params: [ Num(5) Size(0x1C) ]
	struct FVector GetTileCenterPosition(int TileX, int TileY, int LayerIndex, bool bWorldSpace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102565A88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.GetTile
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574abc
	// Params: [ Num(4) Size(0x20) ]
	struct FPaperTileInfo GetTile(int X, int Y, int Layer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10256567C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102565A88

	// Object: Function Paper2D.PaperTileMapComponent.GetMapSize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102574990
	// Params: [ Num(3) Size(0xC) ]
	void GetMapSize(int& MapWidth, int& MapHeight, int& NumLayers);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102565648
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10256567C

	// Object: Function Paper2D.PaperTileMapComponent.GetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102574900
	// Params: [ Num(2) Size(0x14) ]
	struct FLinearColor GetLayerColor(int Layer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025658B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102565648
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Paper2D.PaperTileMapComponent.CreateNewTileMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102574754
	// Params: [ Num(6) Size(0x15) ]
	void CreateNewTileMap(int MapWidth, int MapHeight, int TileWidth, int TileHeight, float PixelsPerUnrealUnit, bool bCreateLayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025654F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025658B8

	// Object: Function Paper2D.PaperTileMapComponent.AddNewLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102574720
	// Params: [ Num(1) Size(0x8) ]
	struct UPaperTileLayer* AddNewLayer();
	// [Call #1] RVA: 0x102565828
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1025654F0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1025658B8
};

// Object: Class Paper2D.PaperTileSet
// Size: 0xA8 (Inherited: 0x28)
struct UPaperTileSet : UObject
{
	struct FIntPoint TileSize; // 0x28(0x8)
	struct UTexture2D* TileSheet; // 0x30(0x8)
	struct TArray<struct UTexture*> AdditionalSourceTextures; // 0x38(0x10)
	struct FIntMargin BorderMargin; // 0x48(0x10)
	struct FIntPoint PerTileSpacing; // 0x58(0x8)
	struct FIntPoint DrawingOffset; // 0x60(0x8)
	int WidthInTiles; // 0x68(0x4)
	int HeightInTiles; // 0x6C(0x4)
	int AllocatedWidth; // 0x70(0x4)
	int AllocatedHeight; // 0x74(0x4)
	struct TArray<struct FPaperTileMetadata> PerTileData; // 0x78(0x10)
	struct TArray<struct FPaperTileSetTerrain> Terrains; // 0x88(0x10)
	int TileWidth; // 0x98(0x4)
	int TileHeight; // 0x9C(0x4)
	int Margin; // 0xA0(0x4)
	int Spacing; // 0xA4(0x4)
};

// Object: Class Paper2D.TileMapBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UTileMapBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Paper2D.TileMapBlueprintLibrary.MakeTile
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102578e00
	// Params: [ Num(6) Size(0x28) ]
	struct FPaperTileInfo MakeTile(int TileIndex, struct UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10256A5A8
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function Paper2D.TileMapBlueprintLibrary.GetTileUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102578d7c
	// Params: [ Num(2) Size(0x18) ]
	struct FName GetTileUserData(struct FPaperTileInfo Tile);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10256A544
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10256A5A8
	// [Call #15] RVA: 0x10519022C

	// Object: Function Paper2D.TileMapBlueprintLibrary.GetTileTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102578ce8
	// Params: [ Num(2) Size(0x40) ]
	struct FTransform GetTileTransform(struct FPaperTileInfo Tile);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10256A554
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10256A544
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Paper2D.TileMapBlueprintLibrary.BreakTile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102578ae0
	// Params: [ Num(6) Size(0x23) ]
	void BreakTile(struct FPaperTileInfo Tile, int& TileIndex, struct UPaperTileSet*& TileSet, bool& bFlipH, bool& bFlipV, bool& bFlipD);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10256A580
	// [Call #14] RVA: 0x10516D168
};

