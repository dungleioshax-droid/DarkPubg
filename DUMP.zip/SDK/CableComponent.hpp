#pragma once

#include <cstdint>

// Object: Class CableComponent.CableActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct ACableActor : AActor
{
	struct UCableComponent* CableComponent; // 0x4B0(0x8)
};

// Object: Class CableComponent.CableComponent
// Size: 0xAA0 (Inherited: 0xA20)
struct UCableComponent : UMeshComponent
{
	bool bAttachStart; // 0xA1D(0x1)
	bool bAttachEnd; // 0xA1E(0x1)
	struct FComponentReference AttachEndTo; // 0xA20(0x18)
	struct FName AttachEndToSocketName; // 0xA38(0x8)
	struct FVector EndLocation; // 0xA40(0xC)
	float CableLength; // 0xA4C(0x4)
	int NumSegments; // 0xA50(0x4)
	float SubstepTime; // 0xA54(0x4)
	int SolverIterations; // 0xA58(0x4)
	bool bEnableStiffness; // 0xA5C(0x1)
	bool bEnableCollision; // 0xA5D(0x1)
	float CollisionFriction; // 0xA60(0x4)
	struct FVector CableForce; // 0xA64(0xC)
	float CableGravityScale; // 0xA70(0x4)
	float CableWidth; // 0xA74(0x4)
	int NumSides; // 0xA78(0x4)
	float TileMaterial; // 0xA7C(0x4)
	uint8_t Pad_0xA80[0x20]; // 0xA80(0x20)


	// Object: Function CableComponent.CableComponent.SetAttachEndTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c52198
	// Params: [ Num(3) Size(0x18) ]
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102C4F850
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function CableComponent.CableComponent.GetCableParticleLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c520f0
	// Params: [ Num(1) Size(0x10) ]
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C4F874
	// [Call #4] RVA: 0x101F8C3A4
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102C4F850
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function CableComponent.CableComponent.GetAttachedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c520bc
	// Params: [ Num(1) Size(0x8) ]
	struct USceneComponent* GetAttachedComponent();
	// [Call #1] RVA: 0x102C4F868
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C4F874
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102C4F850
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function CableComponent.CableComponent.GetAttachedActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c52088
	// Params: [ Num(1) Size(0x8) ]
	struct AActor* GetAttachedActor();
	// [Call #1] RVA: 0x102C4F860
	// [Call #2] RVA: 0x102C4F868
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102C4F874
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102C4F850
	// [Call #16] RVA: 0x10519022C
};

