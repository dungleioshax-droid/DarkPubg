#pragma once

#include <cstdint>

// Object: Class ImgMediaFactory.ImgMediaSettings
// Size: 0x50 (Inherited: 0x28)
struct UImgMediaSettings : UObject
{
	float DefaultFps; // 0x28(0x4)
	float CacheBehindPercentage; // 0x2C(0x4)
	float CacheSizeGB; // 0x30(0x4)
	uint32_t ExrDecoderThreads; // 0x34(0x4)
	struct FString DefaultProxy; // 0x38(0x10)
	bool UseDefaultProxy; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

