#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_InFillingBPTable_type.BP_STRUCT_InFillingBPTable_type
// Size: 0x38 (Inherited: 0x0)
struct FBP_STRUCT_InFillingBPTable_type
{
	struct FString CName_0_0FEB140031B746EE57576036054ADAB5; // 0x0(0x10)
	int ID_1_2AA3C640595906337FE75E5E09E85434; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString Path_2_484966400B8C53E31A22A3DB08558148; // 0x18(0x10)
	struct FString Wrapper_3_467E5B40009CAA6B663AE8D80016F392; // 0x28(0x10)
};

