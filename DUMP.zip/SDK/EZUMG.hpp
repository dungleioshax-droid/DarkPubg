#pragma once

#include <cstdint>

// Object: Enum EZUMG.EEzItemState
enum class EEzItemState : uint8_t
{
	Normal = 0,
	Selected = 1,
	Disabled = 2,
	EEzItemState_MAX = 3
};

// Object: Enum EZUMG.ESectorSizeRule
enum class ESectorSizeRule : uint8_t
{
	Fixed = 0,
	Fill = 1,
	ESectorSizeRule_MAX = 2
};

// Object: Enum EZUMG.ERadialArrangement
enum class ERadialArrangement : uint8_t
{
	Default = 0,
	AlignFirst = 1,
	AlignCenter = 2,
	ERadialArrangement_MAX = 3
};

// Object: ScriptStruct EZUMG.InputActionEvent
// Size: 0x18 (Inherited: 0x0)
struct FInputActionEvent
{
	int PointerIndex; // 0x0(0x4)
	float HeldDuration; // 0x4(0x4)
	struct FVector2D Position; // 0x8(0x8)
	struct FVector2D Delta; // 0x10(0x8)
};

// Object: ScriptStruct EZUMG.EnhancedButtonConfig
// Size: 0x10 (Inherited: 0x0)
struct FEnhancedButtonConfig
{
	float TapThreshold; // 0x0(0x4)
	float LongPressThreshold; // 0x4(0x4)
	float DragThreshold; // 0x8(0x4)
	float SwipeMinDistance; // 0xC(0x4)
};

// Object: Class EZUMG.EnhancedButton
// Size: 0x208 (Inherited: 0x118)
struct UEnhancedButton : UContentWidget
{
	struct FEnhancedButtonConfig Config; // 0x114(0x10)
	struct FScriptMulticastDelegate OnPressed; // 0x128(0x10)
	struct FScriptMulticastDelegate OnReleased; // 0x138(0x10)
	struct FScriptMulticastDelegate OnCancelled; // 0x148(0x10)
	struct FScriptMulticastDelegate OnDragStarted; // 0x158(0x10)
	struct FScriptMulticastDelegate OnDragMoved; // 0x168(0x10)
	struct FScriptMulticastDelegate OnDragEnded; // 0x178(0x10)
	struct FScriptMulticastDelegate OnSwipedUp; // 0x188(0x10)
	struct FScriptMulticastDelegate OnSwipedDown; // 0x198(0x10)
	struct FScriptMulticastDelegate OnSwipedLeft; // 0x1A8(0x10)
	struct FScriptMulticastDelegate OnSwipedRight; // 0x1B8(0x10)
	struct FScriptMulticastDelegate OnTapped; // 0x1C8(0x10)
	struct FScriptMulticastDelegate OnLongPressed; // 0x1D8(0x10)
	struct FScriptMulticastDelegate OnLongReleased; // 0x1E8(0x10)
	uint8_t Pad_0x1F8[0x10]; // 0x1F8(0x10)


	// Object: Function EZUMG.EnhancedButton.GetCurrentHeldDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102782428
	// Params: [ Num(1) Size(0x4) ]
	float GetCurrentHeldDuration();
	// [Call #1] RVA: 0x102773538
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519077C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648

	// Object: Function EZUMG.EnhancedButton.ForceCancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102782414
	// Params: [ Num(0) Size(0x0) ]
	void ForceCancel();
	// [Call #1] RVA: 0x102773538
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519077C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648

	// Object: Function EZUMG.EnhancedButton.ApplyConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102782400
	// Params: [ Num(0) Size(0x0) ]
	void ApplyConfig();
	// [Call #1] RVA: 0x102773538
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519077C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190648
};

// Object: Class EZUMG.EnhancedSlider
// Size: 0x4C0 (Inherited: 0x498)
struct UEnhancedSlider : USlider
{
	bool bEnableSteppedSliding; // 0x498(0x1)
	bool bOnlyRespondToThumb; // 0x499(0x1)
	uint8_t Pad_0x49A[0x2]; // 0x49A(0x2)
	struct FLinearColor FilledBarColor; // 0x49C(0x10)
	struct FLinearColor UnfilledBarColor; // 0x4AC(0x10)
	uint8_t Pad_0x4BC[0x4]; // 0x4BC(0x4)


	// Object: Function EZUMG.EnhancedSlider.SetUnfilledBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102782940
	// Params: [ Num(1) Size(0x10) ]
	void SetUnfilledBarColor(struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102773D78
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function EZUMG.EnhancedSlider.SetOnlyRespondToThumb
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027828bc
	// Params: [ Num(1) Size(0x1) ]
	void SetOnlyRespondToThumb(bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102773CA0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102773D78
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function EZUMG.EnhancedSlider.SetFilledBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102782840
	// Params: [ Num(1) Size(0x10) ]
	void SetFilledBarColor(struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102773CF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102773CA0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102773D78
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function EZUMG.EnhancedSlider.SetEnableSteppedSliding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027827bc
	// Params: [ Num(1) Size(0x1) ]
	void SetEnableSteppedSliding(bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102773C48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102773CF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102773CA0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102773D78
	// [Call #13] RVA: 0x10519022C

	// Object: Function EZUMG.EnhancedSlider.GetUnfilledBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102782784
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetUnfilledBarColor();
	// [Call #1] RVA: 0x102785C94
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102773C48
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102773CF8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102773CA0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102773D78

	// Object: Function EZUMG.EnhancedSlider.GetOnlyRespondToThumb
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102782768
	// Params: [ Num(1) Size(0x1) ]
	bool GetOnlyRespondToThumb();
	// [Call #1] RVA: 0x102785C94
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102773C48
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102773CF8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102773CA0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102773D78

	// Object: Function EZUMG.EnhancedSlider.GetFilledBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102782730
	// Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetFilledBarColor();
	// [Call #1] RVA: 0x102785C80
	// [Call #2] RVA: 0x102785C94
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102773C48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102773CF8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102773CA0
	// [Call #12] RVA: 0x10516D168

	// Object: Function EZUMG.EnhancedSlider.GetEnableSteppedSliding
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102782714
	// Params: [ Num(1) Size(0x1) ]
	bool GetEnableSteppedSliding();
	// [Call #1] RVA: 0x102785C80
	// [Call #2] RVA: 0x102785C94
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102773C48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102773CF8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102773CA0
};

// Object: Class EZUMG.EzAnimationLibrary
// Size: 0x28 (Inherited: 0x28)
struct UEzAnimationLibrary : UBlueprintFunctionLibrary
{

	// Object: Function EZUMG.EzAnimationLibrary.DuplicateAnimWithRemap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102782f5c
	// Params: [ Num(4) Size(0x68) ]
	struct UWidgetAnimation* DuplicateAnimWithRemap(struct UUserWidget* OwningWidget, struct UWidgetAnimation* Template, struct TMap<struct UWidget*, struct UWidget*>& RemapTable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102785CA8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102772F08
	// [Call #9] RVA: 0x102785D78
	// [Call #10] RVA: 0x102785D78
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function EZUMG.EzAnimationLibrary.DuplicateAnimRebindTrack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102782e34
	// Params: [ Num(5) Size(0x28) ]
	struct UWidgetAnimation* DuplicateAnimRebindTrack(struct UUserWidget* OwningWidget, struct UWidgetAnimation* Template, struct UWidget* SourceWidget, struct UWidget* TargetWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102772E64
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102785CA8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102772F08
	// [Call #18] RVA: 0x102785D78
	// [Call #19] RVA: 0x102785D78
	// [Call #20] RVA: 0x106C8459C

	// Object: Function EZUMG.EzAnimationLibrary.DuplicateAnimForWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102782d44
	// Params: [ Num(4) Size(0x20) ]
	struct UWidgetAnimation* DuplicateAnimForWidget(struct UUserWidget* OwningWidget, struct UWidgetAnimation* Template, struct UWidget* TargetWidget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102772DE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102772E64
	// [Call #17] RVA: 0x10516D168
};

// Object: Class EZUMG.EzFactory
// Size: 0x28 (Inherited: 0x28)
struct IEzFactory : IInterface
{

	// Object: Function EZUMG.EzFactory.SetNum
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102783318
	// Params: [ Num(1) Size(0x4) ]
	void SetNum(int NumItems);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function EZUMG.EzFactory.RemoveLastItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1027832dc
	// Params: [ Num(1) Size(0x1) ]
	bool RemoveLastItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function EZUMG.EzFactory.GetFactoryItemCount
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027832a0
	// Params: [ Num(1) Size(0x4) ]
	int GetFactoryItemCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function EZUMG.EzFactory.AddItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102783264
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* AddItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

// Object: Class EZUMG.EzSelectable
// Size: 0x28 (Inherited: 0x28)
struct IEzSelectable : IInterface
{

	// Object: Function EZUMG.EzSelectable.OnStateRefresh
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnStateRefresh(uint8_t NewState);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class EZUMG.EzSelectorSlot
// Size: 0x28 (Inherited: 0x28)
struct IEzSelectorSlot : IInterface
{
};

// Object: Class EZUMG.EzSelector
// Size: 0x28 (Inherited: 0x28)
struct IEzSelector : IInterface
{

	// Object: Function EZUMG.EzSelector.SetSelectedIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102783cfc
	// Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int NewIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function EZUMG.EzSelector.SetItemState
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102783c3c
	// Params: [ Num(2) Size(0x5) ]
	void SetItemState(int ItemIndex, uint8_t NewState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function EZUMG.EzSelector.SetItemEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102783b78
	// Params: [ Num(2) Size(0x5) ]
	void SetItemEnabled(int ItemIndex, bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function EZUMG.EzSelector.IsItemEnabled
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102783ae4
	// Params: [ Num(2) Size(0x5) ]
	bool IsItemEnabled(int ItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function EZUMG.EzSelector.GetSelectedIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102783aa8
	// Params: [ Num(1) Size(0x4) ]
	int GetSelectedIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function EZUMG.EzSelector.GetItemState
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102783a14
	// Params: [ Num(2) Size(0x5) ]
	uint8_t GetItemState(int ItemIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function EZUMG.EzSelector.GetHoveredIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027839d8
	// Params: [ Num(1) Size(0x4) ]
	int GetHoveredIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function EZUMG.EzSelector.GetFocusedIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10278399c
	// Params: [ Num(1) Size(0x4) ]
	int GetFocusedIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
};

// Object: Class EZUMG.HorizontalSelectorSlot
// Size: 0x78 (Inherited: 0x68)
struct UHorizontalSelectorSlot : UHorizontalBoxSlot
{
	uint8_t Pad_0x68[0x10]; // 0x68(0x10)
};

// Object: Class EZUMG.HorizontalSelector
// Size: 0x188 (Inherited: 0x128)
struct UHorizontalSelector : UHorizontalBox
{
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
	struct UWidget* itemType; // 0x138(0x8)
	struct UHorizontalSelectorSlot* DefaultSlotTemplate; // 0x140(0x8)
	struct TArray<struct TWeakObjectPtr<struct UWidget>> FactoryCreatedItems; // 0x148(0x10)
	DelegateProperty OnItemSelected; // 0x158(0x10)
	struct FScriptMulticastDelegate OnItemStateChanged; // 0x168(0x10)
	uint8_t Pad_0x178[0x10]; // 0x178(0x10)


	// Object: Function EZUMG.HorizontalSelector.GetChildIndexAtPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1027842f4
	// Params: [ Num(2) Size(0xC) ]
	int GetChildIndexAtPosition(struct FVector2D& LocalPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10277433C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190648
	// [Call #8] RVA: 0x10278256C
};

// Object: Class EZUMG.RadialPanel
// Size: 0x130 (Inherited: 0x118)
struct URadialPanel : UPanelWidget
{
	float AngleOffset; // 0x114(0x4)
	float SectorPadding; // 0x118(0x4)
	uint8_t Arrangement; // 0x11C(0x1)
	uint8_t Pad_0x121[0xF]; // 0x121(0xF)


	// Object: Function EZUMG.RadialPanel.SetStartAngleOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027847b4
	// Params: [ Num(1) Size(0x4) ]
	void SetStartAngleOffset(float InStartAngleOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102774FF8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function EZUMG.RadialPanel.SetSectorPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102784738
	// Params: [ Num(1) Size(0x4) ]
	void SetSectorPadding(float InSectorPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775038
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102774FF8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function EZUMG.RadialPanel.SetArrangement
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027846bc
	// Params: [ Num(1) Size(0x1) ]
	void SetArrangement(uint8_t InArrangement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775024
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775038
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102774FF8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function EZUMG.RadialPanel.GetAngleAtPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784634
	// Params: [ Num(2) Size(0xC) ]
	float GetAngleAtPosition(struct FVector2D LocalPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102774FC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775024
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102775038
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102774FF8
	// [Call #13] RVA: 0x10519022C
};

// Object: Class EZUMG.RadialSlot
// Size: 0x128 (Inherited: 0x40)
struct URadialSlot : UPanelSlot
{
	enum class ESectorSizeRule SectorSizeRule; // 0x40(0x1)
	uint8_t Pad_0x41[0x3]; // 0x41(0x3)
	float SectorSizeValue; // 0x44(0x4)
	float InnerRadiusRatio; // 0x48(0x4)
	float OuterRadiusRatio; // 0x4C(0x4)
	bool bAutoSize; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	struct FSlateBrush SectorBrush; // 0x58(0xB8)
	struct FLinearColor SectorColorAndOpacity; // 0x110(0x10)
	uint8_t Pad_0x120[0x8]; // 0x120(0x8)


	// Object: Function EZUMG.RadialSlot.SlotAsRadialSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1027853cc
	// Params: [ Num(2) Size(0x10) ]
	struct URadialSlot* SlotAsRadialSlot(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775BA8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSlot.SetSectorSizeValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102785350
	// Params: [ Num(1) Size(0x4) ]
	void SetSectorSizeValue(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027759A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775BA8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSlot.SetSectorSizeRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027852d4
	// Params: [ Num(1) Size(0x1) ]
	void SetSectorSizeRule(enum class ESectorSizeRule InRule);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10277598C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1027759A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102775BA8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSlot.SetSectorColorAndOpacity
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10278524c
	// Params: [ Num(1) Size(0x10) ]
	void SetSectorColorAndOpacity(struct FLinearColor& InTint);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775B90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10277598C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027759A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102775BA8
	// [Call #13] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSlot.SetSectorBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027851a0
	// Params: [ Num(1) Size(0xB8) ]
	void SetSectorBrush(struct FSlateBrush& InBrush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102775B54
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102775B90
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10277598C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1027759A4

	// Object: Function EZUMG.RadialSlot.SetOuterRadiusRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102785124
	// Params: [ Num(1) Size(0x4) ]
	void SetOuterRadiusRatio(float InOuterRadiusRatio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775AC0
	// [Call #4] RVA: 0x101FE9E54
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102775B54
	// [Call #8] RVA: 0x101FEA144
	// [Call #9] RVA: 0x101FEA144
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102775B90
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10277598C

	// Object: Function EZUMG.RadialSlot.SetInnerRadiusRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027850a8
	// Params: [ Num(1) Size(0x4) ]
	void SetInnerRadiusRatio(float InInnerRadiusRatio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775A3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775AC0
	// [Call #7] RVA: 0x101FE9E54
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102775B54
	// [Call #11] RVA: 0x101FEA144
	// [Call #12] RVA: 0x101FEA144
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102775B90

	// Object: Function EZUMG.RadialSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102785024
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(bool bInAutoSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775B40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775A3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102775AC0
	// [Call #10] RVA: 0x101FE9E54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102775B54
	// [Call #14] RVA: 0x101FEA144
	// [Call #15] RVA: 0x101FEA144
	// [Call #16] RVA: 0x106C8459C

	// Object: Function EZUMG.RadialSlot.GetCenterRadiusRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784ff0
	// Params: [ Num(1) Size(0x4) ]
	float GetCenterRadiusRatio();
	// [Call #1] RVA: 0x102775978
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102775B40
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102775A3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102775AC0
	// [Call #11] RVA: 0x101FE9E54
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102775B54
	// [Call #15] RVA: 0x101FEA144
	// [Call #16] RVA: 0x101FEA144

	// Object: Function EZUMG.RadialSlot.GetCenterAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784fbc
	// Params: [ Num(1) Size(0x4) ]
	float GetCenterAngle();
	// [Call #1] RVA: 0x102775954
	// [Call #2] RVA: 0x102775978
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102775B40
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102775A3C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102775AC0
	// [Call #12] RVA: 0x101FE9E54
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function EZUMG.RadialSlot.GetArcSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784f88
	// Params: [ Num(1) Size(0x4) ]
	float GetArcSize();
	// [Call #1] RVA: 0x10277592C
	// [Call #2] RVA: 0x102775954
	// [Call #3] RVA: 0x102775978
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775B40
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102775A3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102775AC0
	// [Call #13] RVA: 0x101FE9E54
	// [Call #14] RVA: 0x10516D168
};

// Object: Class EZUMG.RadialSelectorSlot
// Size: 0x138 (Inherited: 0x128)
struct URadialSelectorSlot : URadialSlot
{
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
};

// Object: Class EZUMG.RadialSelector
// Size: 0x180 (Inherited: 0x130)
struct URadialSelector : URadialPanel
{
	uint8_t Pad_0x130[0x10]; // 0x130(0x10)
	struct UWidget* itemType; // 0x140(0x8)
	struct URadialSelectorSlot* DefaultSlotTemplate; // 0x148(0x8)
	struct TArray<struct TWeakObjectPtr<struct UWidget>> FactoryCreatedItems; // 0x150(0x10)
	DelegateProperty OnItemSelected; // 0x160(0x10)
	struct FScriptMulticastDelegate OnItemStateChanged; // 0x170(0x10)


	// Object: Function EZUMG.RadialSelector.GetChildIndexByVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784cd0
	// Params: [ Num(3) Size(0x10) ]
	int GetChildIndexByVector(struct FVector2D& CenterOffset, float DeadzoneLength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102775338
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSelector.GetChildIndexByAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784c44
	// Params: [ Num(2) Size(0x8) ]
	int GetChildIndexByAngle(float Angle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775324
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102775338
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function EZUMG.RadialSelector.GetChildIndexAtPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102784bac
	// Params: [ Num(2) Size(0xC) ]
	int GetChildIndexAtPosition(struct FVector2D& LocalPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102775310
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102775324
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102775338
	// [Call #12] RVA: 0x10519022C
};

// Object: Class EZUMG.VerticalSelectorSlot
// Size: 0x78 (Inherited: 0x68)
struct UVerticalSelectorSlot : UVerticalBoxSlot
{
	uint8_t Pad_0x68[0x10]; // 0x68(0x10)
};

// Object: Class EZUMG.VerticalSelector
// Size: 0x188 (Inherited: 0x128)
struct UVerticalSelector : UVerticalBox
{
	uint8_t Pad_0x128[0x10]; // 0x128(0x10)
	struct UWidget* itemType; // 0x138(0x8)
	struct UVerticalSelectorSlot* DefaultSlotTemplate; // 0x140(0x8)
	struct TArray<struct TWeakObjectPtr<struct UWidget>> FactoryCreatedItems; // 0x148(0x10)
	DelegateProperty OnItemSelected; // 0x158(0x10)
	struct FScriptMulticastDelegate OnItemStateChanged; // 0x168(0x10)
	uint8_t Pad_0x178[0x10]; // 0x178(0x10)


	// Object: Function EZUMG.VerticalSelector.GetChildIndexAtPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102785934
	// Params: [ Num(2) Size(0xC) ]
	int GetChildIndexAtPosition(struct FVector2D& LocalPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10277606C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10518366C
	// [Call #8] RVA: 0x10518366C
	// [Call #9] RVA: 0x10518366C
	// [Call #10] RVA: 0x10518366C
	// [Call #11] RVA: 0x10518366C
};

