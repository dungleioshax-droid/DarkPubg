#pragma once

#include <cstdint>

// Object: Enum ActorSequence.EActorSequenceObjectReferenceType
enum class EActorSequenceObjectReferenceType : uint8_t
{
	ContextActor = 0,
	ExternalActor = 1,
	Component = 2,
	EActorSequenceObjectReferenceType_MAX = 3
};

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReferenceMap
// Size: 0x20 (Inherited: 0x0)
struct FActorSequenceObjectReferenceMap
{
	struct TArray<struct FGuid> BindingIds; // 0x0(0x10)
	struct TArray<struct FActorSequenceObjectReferences> References; // 0x10(0x10)
};

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReferences
// Size: 0x10 (Inherited: 0x0)
struct FActorSequenceObjectReferences
{
	struct TArray<struct FActorSequenceObjectReference> Array; // 0x0(0x10)
};

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReference
// Size: 0x28 (Inherited: 0x0)
struct FActorSequenceObjectReference
{
	uint8_t Type; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	struct FGuid ActorId; // 0x4(0x10)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString PathToComponent; // 0x18(0x10)
};

// Object: Class ActorSequence.ActorSequence
// Size: 0x310 (Inherited: 0x2E8)
struct UActorSequence : UMovieSceneSequence
{
	struct UMovieScene* MovieScene; // 0x2E8(0x8)
	struct FActorSequenceObjectReferenceMap ObjectReferences; // 0x2F0(0x20)
};

// Object: Class ActorSequence.ActorSequenceComponent
// Size: 0x1B8 (Inherited: 0x178)
struct UActorSequenceComponent : UActorComponent
{
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x178(0x28)
	struct UActorSequence* Sequence; // 0x1A0(0x8)
	struct UActorSequencePlayer* SequencePlayer; // 0x1A8(0x8)
	bool bAutoPlay; // 0x1B0(0x1)
	bool bRunOnServer; // 0x1B1(0x1)
	bool bEnableOptimize; // 0x1B2(0x1)
	uint8_t Pad_0x1B3[0x5]; // 0x1B3(0x5)


	// Object: Function ActorSequence.ActorSequenceComponent.StopPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c30274
	// Params: [ Num(0) Size(0x0) ]
	void StopPlay();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function ActorSequence.ActorSequenceComponent.StartPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c301f8
	// Params: [ Num(1) Size(0x4) ]
	void StartPlay(float StartTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C2EB38
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function ActorSequence.ActorSequenceComponent.OnStopOrFinsh
	// Flags: [Final|Native|Private]
	// Offset: 0x102c301e4
	// Params: [ Num(0) Size(0x0) ]
	void OnStopOrFinsh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C2EB38
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function ActorSequence.ActorSequenceComponent.GetLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c301b0
	// Params: [ Num(1) Size(0x4) ]
	float GetLength();
	// [Call #1] RVA: 0x102C2EEB4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102C2EB38
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class ActorSequence.ActorSequencePlayer
// Size: 0x7B8 (Inherited: 0x7B8)
struct UActorSequencePlayer : UMovieSceneSequencePlayer
{
};

