#pragma once

#include <cstdint>

// Object: Enum OceanPlugin.EFollowMethod
enum class EFollowMethod : uint8_t
{
	LookAtLocation = 0,
	FollowCamera = 1,
	FollowPawn = 2,
	Stationary = 3,
	EFollowMethod_MAX = 4
};

// Object: ScriptStruct OceanPlugin.StructBoneOverride
// Size: 0x10 (Inherited: 0x0)
struct FStructBoneOverride
{
	struct FName BoneName; // 0x0(0x8)
	float Density; // 0x8(0x4)
	float TestRadius; // 0xC(0x4)
};

// Object: ScriptStruct OceanPlugin.ForceTriangle
// Size: 0x6C (Inherited: 0x0)
struct FForceTriangle
{
	uint8_t Pad_0x0[0x6C]; // 0x0(0x6C)
};

// Object: ScriptStruct OceanPlugin.BuoyancyVertex
// Size: 0x10 (Inherited: 0x0)
struct FBuoyancyVertex
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct OceanPlugin.WaveSetParameters
// Size: 0xA0 (Inherited: 0x0)
struct FWaveSetParameters
{
	struct FWaveParameter Wave01; // 0x0(0x14)
	struct FWaveParameter Wave02; // 0x14(0x14)
	struct FWaveParameter Wave03; // 0x28(0x14)
	struct FWaveParameter Wave04; // 0x3C(0x14)
	struct FWaveParameter Wave05; // 0x50(0x14)
	struct FWaveParameter Wave06; // 0x64(0x14)
	struct FWaveParameter Wave07; // 0x78(0x14)
	struct FWaveParameter Wave08; // 0x8C(0x14)
};

// Object: ScriptStruct OceanPlugin.WaveParameter
// Size: 0x14 (Inherited: 0x0)
struct FWaveParameter
{
	float Rotation; // 0x0(0x4)
	float Length; // 0x4(0x4)
	float Amplitude; // 0x8(0x4)
	float Steepness; // 0xC(0x4)
	float TimeScale; // 0x10(0x4)
};

// Object: ScriptStruct OceanPlugin.SegmentWaterBox
// Size: 0x90 (Inherited: 0x0)
struct FSegmentWaterBox
{
	struct FBox WaterBox; // 0x0(0x1C)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FTransform WaterTransform; // 0x20(0x30)
	struct FVector WaterBoxExtend; // 0x50(0xC)
	float WaterBoxAcceptZValue; // 0x5C(0x4)
	struct FVector2D Direction; // 0x60(0x8)
	float SpeedValue; // 0x68(0x4)
	bool UseSplineZ; // 0x6C(0x1)
	uint8_t Pad_0x6D[0x3]; // 0x6D(0x3)
	float WaveForceMultiplier; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct TArray<struct FTrippleWaveParameter> WaveClusters; // 0x78(0x10)
	struct USplineComponent* DirectionSpline; // 0x88(0x8)
};

// Object: ScriptStruct OceanPlugin.TrippleWaveParameter
// Size: 0x54 (Inherited: 0x0)
struct FTrippleWaveParameter
{
	struct FWaveParameter WaveCluster0; // 0x0(0x14)
	struct FWaveAdjust WaveAdjust0; // 0x14(0x8)
	struct FWaveParameter WaveCluster1; // 0x1C(0x14)
	struct FWaveAdjust WaveAdjust1; // 0x30(0x8)
	struct FWaveParameter WaveCluster2; // 0x38(0x14)
	struct FWaveAdjust WaveAdjust2; // 0x4C(0x8)
};

// Object: ScriptStruct OceanPlugin.WaveAdjust
// Size: 0x8 (Inherited: 0x0)
struct FWaveAdjust
{
	float TimeScaleOffset; // 0x0(0x4)
	float Offset; // 0x4(0x4)
};

// Object: ScriptStruct OceanPlugin.TimeDate
// Size: 0x1C (Inherited: 0x0)
struct FTimeDate
{
	int Millisecond; // 0x0(0x4)
	int Second; // 0x4(0x4)
	int Minute; // 0x8(0x4)
	int Hour; // 0xC(0x4)
	int Day; // 0x10(0x4)
	int Month; // 0x14(0x4)
	int Year; // 0x18(0x4)
};

// Object: ScriptStruct OceanPlugin.WaterBoxCell
// Size: 0x20 (Inherited: 0x0)
struct FWaterBoxCell
{
	struct FVector WaveDirection; // 0x0(0xC)
	float WaveZ; // 0xC(0x4)
	struct FVector PushForceDirection; // 0x10(0xC)
	float Speed; // 0x1C(0x4)
};

// Object: Class OceanPlugin.AdvancedBuoyancyComponent
// Size: 0x4B0 (Inherited: 0x3A0)
struct UAdvancedBuoyancyComponent : USceneComponent
{
	bool bUseDrag; // 0x399(0x1)
	bool bDebugOn; // 0x39A(0x1)
	struct AOceanManager* TheOcean; // 0x3A0(0x8)
	float WaterDensity; // 0x3A8(0x4)
	float Gravity; // 0x3AC(0x4)
	float MeshDensity; // 0x3B0(0x4)
	uint8_t Pad_0x3B6[0x12]; // 0x3B6(0x12)
	struct UStaticMeshComponent* BuoyantMesh; // 0x3C8(0x8)
	struct FTransform MeshTransform; // 0x3D0(0x30)
	float FalseVolume; // 0x400(0x4)
	float BuoyancyReductionCoefficient; // 0x404(0x4)
	float BuoyancyPitchReductionCoefficient; // 0x408(0x4)
	float DensityCorrection; // 0x40C(0x4)
	float DensityCorrectionModifier; // 0x410(0x4)
	float SubmergedVolume; // 0x414(0x4)
	float ImpactCoefficient; // 0x418(0x4)
	struct FVector DragCoefficient; // 0x41C(0xC)
	struct FVector SuctionCoefficient; // 0x428(0xC)
	float ViscousDragCoefficient; // 0x434(0x4)
	float MaxSlamAcceleration; // 0x438(0x4)
	uint8_t Pad_0x43C[0x4]; // 0x43C(0x4)
	struct TArray<struct FVector> AdvancedGridHeight; // 0x440(0x10)
	struct TArray<struct FForceTriangle> SubmergedTris; // 0x450(0x10)
	struct TArray<float> TriSizes; // 0x460(0x10)
	struct TArray<float> TriSubmergedArea; // 0x470(0x10)
	uint8_t Pad_0x480[0x30]; // 0x480(0x30)


	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.TriangleArea
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdbea4
	// Params: [ Num(4) Size(0x28) ]
	float TriangleArea(struct FVector A, struct FVector B, struct FVector C);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FCB1D0
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.SplitTriangle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdbcf0
	// Params: [ Num(5) Size(0x50) ]
	struct TArray<struct FForceTriangle> SplitTriangle(struct FBuoyancyVertex H, struct FBuoyancyVertex M, struct FBuoyancyVertex L, struct FVector InArrow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FCA528
	// [Call #10] RVA: 0x101FCB374
	// [Call #11] RVA: 0x101FD86B4
	// [Call #12] RVA: 0x101FD86B4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.SetMeshDensity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdbc3c
	// Params: [ Num(2) Size(0x8) ]
	void SetMeshDensity(float NewDensity, float NewWaterDensity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCB3C4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FCA528
	// [Call #15] RVA: 0x101FCB374
	// [Call #16] RVA: 0x101FD86B4

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.GetOceanDepthFromGrid
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdbb6c
	// Params: [ Num(3) Size(0x14) ]
	float GetOceanDepthFromGrid(struct FVector Position, bool bJustGetHeightAtLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCA8AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FCB3C4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.GetOcean
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdbb58
	// Params: [ Num(0) Size(0x0) ]
	void GetOcean();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCA8AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FCB3C4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.DrawDebugStuff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdba5c
	// Params: [ Num(2) Size(0x70) ]
	void DrawDebugStuff(struct FForceTriangle TriForce, struct FColor DebugColor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C8DCEC
	// [Call #6] RVA: 0x101FCAF24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FCA8AC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.ApplySlamForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdb9a4
	// Params: [ Num(2) Size(0x18) ]
	void ApplySlamForce(struct FVector SlamForce, struct FVector TriCenter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCB2FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C8DCEC
	// [Call #11] RVA: 0x101FCAF24
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.AdvancedBuoyancyComponent.ApplyForce
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdb8dc
	// Params: [ Num(1) Size(0x6C) ]
	void ApplyForce(struct FForceTriangle TriForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8DCEC
	// [Call #4] RVA: 0x101FCAA90
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FCB2FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C8DCEC
};

// Object: Class OceanPlugin.BuoyancyComponent
// Size: 0x248 (Inherited: 0x1B8)
struct UBuoyancyComponent : UMovementComponent
{
	struct AOceanManager* OceanManager; // 0x1B8(0x8)
	float MeshDensity; // 0x1C0(0x4)
	float FluidDensity; // 0x1C4(0x4)
	float FluidLinearDamping; // 0x1C8(0x4)
	float FluidAngularDamping; // 0x1CC(0x4)
	struct FVector VelocityDamper; // 0x1D0(0xC)
	bool ClampMaxVelocity; // 0x1DC(0x1)
	uint8_t Pad_0x1DD[0x3]; // 0x1DD(0x3)
	float MaxUnderwaterVelocity; // 0x1E0(0x4)
	float TestPointRadius; // 0x1E4(0x4)
	struct TArray<struct FVector> TestPoints; // 0x1E8(0x10)
	struct TArray<float> PointDensityOverride; // 0x1F8(0x10)
	bool DrawDebugPoints; // 0x208(0x1)
	bool EnableStayUprightConstraint; // 0x209(0x1)
	uint8_t Pad_0x20A[0x2]; // 0x20A(0x2)
	float StayUprightStiffness; // 0x20C(0x4)
	float StayUprightDamping; // 0x210(0x4)
	struct FRotator StayUprightDesiredRotation; // 0x214(0xC)
	bool EnableWaveForces; // 0x220(0x1)
	uint8_t Pad_0x221[0x3]; // 0x221(0x3)
	float WaveForceMultiplier; // 0x224(0x4)
	uint8_t Pad_0x228[0x20]; // 0x228(0x20)
};

// Object: Class OceanPlugin.BuoyancyForceComponent
// Size: 0x660 (Inherited: 0x3A0)
struct UBuoyancyForceComponent : USceneComponent
{
	struct FScriptMulticastDelegate OnContactWater; // 0x3A0(0x10)
	struct FScriptMulticastDelegate OnEnterWater; // 0x3B0(0x10)
	bool bUseBuoyancyEvent; // 0x3C0(0x1)
	uint8_t Pad_0x3C1[0x7]; // 0x3C1(0x7)
	struct AOceanManager* OceanManager; // 0x3C8(0x8)
	float MeshDensity; // 0x3D0(0x4)
	float FluidDensity; // 0x3D4(0x4)
	float FluidLinearDamping; // 0x3D8(0x4)
	float FluidAngularDamping; // 0x3DC(0x4)
	struct FVector VelocityDamper; // 0x3E0(0xC)
	bool ClampMaxVelocity; // 0x3EC(0x1)
	uint8_t Pad_0x3ED[0x3]; // 0x3ED(0x3)
	float MaxUnderwaterVelocity; // 0x3F0(0x4)
	float TestPointRadius; // 0x3F4(0x4)
	struct TArray<struct FVector> TestPoints; // 0x3F8(0x10)
	bool ApplyForceToBones; // 0x408(0x1)
	bool SnapToSurfaceIfNoPhysics; // 0x409(0x1)
	bool SnapToSeaLevel; // 0x40A(0x1)
	bool bEnableGerstnerWaves; // 0x40B(0x1)
	bool TwoGerstnerIterations; // 0x40C(0x1)
	uint8_t Pad_0x40D[0x3]; // 0x40D(0x3)
	struct TArray<float> PointDensityOverride; // 0x410(0x10)
	struct TArray<struct FStructBoneOverride> BoneOverride; // 0x420(0x10)
	bool bEnableZOptimize; // 0x430(0x1)
	bool DrawDebugPoints; // 0x431(0x1)
	bool DrawDebugSeaLevel; // 0x432(0x1)
	bool EnableStayUprightConstraint; // 0x433(0x1)
	float StayUprightStiffness; // 0x434(0x4)
	float StayUprightDamping; // 0x438(0x4)
	struct FRotator StayUprightDesiredRotation; // 0x43C(0xC)
	bool EnableWaveForces; // 0x448(0x1)
	uint8_t Pad_0x449[0x3]; // 0x449(0x3)
	float WaveForceMultiplier; // 0x44C(0x4)
	struct USceneComponent* UpdatedComponent; // 0x450(0x8)
	enum class ETickingGroup TickGroup; // 0x458(0x1)
	bool EnableCustomWaveForce; // 0x459(0x1)
	uint8_t Pad_0x45A[0x2]; // 0x45A(0x2)
	struct FVector CustomWaveForceTestPointOffset; // 0x45C(0xC)
	struct TArray<struct UWaterBoxComponent*> CandidateWaterBoxes; // 0x468(0x10)
	uint8_t Pad_0x478[0x1B8]; // 0x478(0x1B8)
	struct UPhysicsConstraintComponent* UprightConstraintComp; // 0x630(0x8)
	uint8_t Pad_0x638[0x10]; // 0x638(0x10)
	struct UWorld* World; // 0x648(0x8)
	uint8_t Pad_0x650[0x10]; // 0x650(0x10)


	// Object: Function OceanPlugin.BuoyancyForceComponent.SetUpdatedComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdc8f8
	// Params: [ Num(1) Size(0x8) ]
	void SetUpdatedComponent(struct USceneComponent* NewUpdatedComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FCD6CC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: DelegateFunction OceanPlugin.BuoyancyForceComponent.OnEnterWaterDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnEnterWaterDelegate__DelegateSignature(bool IsUnderWater);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: DelegateFunction OceanPlugin.BuoyancyForceComponent.OnContactWaterDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void OnContactWaterDelegate__DelegateSignature(bool IsContactingWater);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function OceanPlugin.BuoyancyForceComponent.NativeSetEnableCustomWaveForce
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdc874
	// Params: [ Num(1) Size(0x1) ]
	void NativeSetEnableCustomWaveForce(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FCD5D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FCD6CC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.IsGerstnerWaveEnabled
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x101fdc840
	// Params: [ Num(1) Size(0x1) ]
	bool IsGerstnerWaveEnabled();
	// [Call #1] RVA: 0x101FCD46C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FCD5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FCD6CC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.IsFloatingOnWater
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101fdc81c
	// Params: [ Num(1) Size(0x1) ]
	bool IsFloatingOnWater();
	// [Call #1] RVA: 0x101FCD46C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FCD5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FCD6CC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.IsEntirelyUnderWater
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101fdc7e4
	// Params: [ Num(1) Size(0x1) ]
	bool IsEntirelyUnderWater();
	// [Call #1] RVA: 0x101FCD46C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FCD5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FCD6CC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.IsContactedWater
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101fdc7c0
	// Params: [ Num(1) Size(0x1) ]
	bool IsContactedWater();
	// [Call #1] RVA: 0x101FCD46C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FCD5D4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FCD6CC
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.GetSeaLevel
	// Flags: [Final|Native|Public]
	// Offset: 0x101fdc78c
	// Params: [ Num(1) Size(0x4) ]
	float GetSeaLevel();
	// [Call #1] RVA: 0x101FCD484
	// [Call #2] RVA: 0x101FCD46C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCD5D4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FCD6CC
	// [Call #9] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.GetOceanManager
	// Flags: [Final|Native|Public]
	// Offset: 0x101fdc758
	// Params: [ Num(1) Size(0x8) ]
	struct AOceanManager* GetOceanManager();
	// [Call #1] RVA: 0x101FCC16C
	// [Call #2] RVA: 0x101FCD484
	// [Call #3] RVA: 0x101FCD46C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FCD5D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FCD6CC
	// [Call #10] RVA: 0x10519022C

	// Object: Function OceanPlugin.BuoyancyForceComponent.EndableUprightConstraint
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdc6d4
	// Params: [ Num(1) Size(0x1) ]
	void EndableUprightConstraint(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FCD704
	// [Call #4] RVA: 0x101FCC16C
	// [Call #5] RVA: 0x101FCD484
	// [Call #6] RVA: 0x101FCD46C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FCD5D4
	// [Call #10] RVA: 0x10516D168

	// Object: Function OceanPlugin.BuoyancyForceComponent.CheckPointInWater
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fdc604
	// Params: [ Num(3) Size(0xE) ]
	bool CheckPointInWater(struct FVector Point, bool isWorldPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCD850
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FCD704
	// [Call #9] RVA: 0x101FCC16C
	// [Call #10] RVA: 0x101FCD484

	// Object: Function OceanPlugin.BuoyancyForceComponent.CacheDampingProperties
	// Flags: [Final|Native|Public]
	// Offset: 0x101fdc5f0
	// Params: [ Num(0) Size(0x0) ]
	void CacheDampingProperties();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FCD850
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FCD704
	// [Call #9] RVA: 0x101FCC16C
	// [Call #10] RVA: 0x101FCD484
};

// Object: Class OceanPlugin.BuoyantMeshComponent
// Size: 0xC30 (Inherited: 0xBD0)
struct UBuoyantMeshComponent : UStaticMeshComponent
{
	bool bVerticalForcesOnly; // 0xBD0(0x1)
	bool bUseWaterPatch; // 0xBD1(0x1)
	bool bUseStaticForces; // 0xBD2(0x1)
	bool bUseDynamicForces; // 0xBD3(0x1)
	uint8_t Pad_0xBD4[0x4]; // 0xBD4(0x4)
	struct AOceanManager* OceanManager; // 0xBD8(0x8)
	bool bDrawForceArrows; // 0xBE0(0x1)
	bool bDrawWaterline; // 0xBE1(0x1)
	bool bDrawVertices; // 0xBE2(0x1)
	bool bDrawTriangles; // 0xBE3(0x1)
	bool bDrawSubtriangles; // 0xBE4(0x1)
	uint8_t Pad_0xBE5[0x3]; // 0xBE5(0x3)
	float ForceArrowSize; // 0xBE8(0x4)
	bool bOverrideMeshDensity; // 0xBEC(0x1)
	uint8_t Pad_0xBED[0x3]; // 0xBED(0x3)
	float MeshDensity; // 0xBF0(0x4)
	bool bOverrideMass; // 0xBF4(0x1)
	uint8_t Pad_0xBF5[0x3]; // 0xBF5(0x3)
	float Mass; // 0xBF8(0x4)
	float WaterDensity; // 0xBFC(0x4)
	uint8_t Pad_0xC00[0x28]; // 0xC00(0x28)
	struct UWaterHeightmapComponent* WaterHeightmap; // 0xC28(0x8)
};

// Object: Class OceanPlugin.FishManager
// Size: 0x508 (Inherited: 0x4B0)
struct AFishManager : AActor
{
	struct TArray<struct UObject*> flockTypes; // 0x4B0(0x10)
	struct TArray<float> numInFlock; // 0x4C0(0x10)
	float minZ; // 0x4D0(0x4)
	float maxZ; // 0x4D4(0x4)
	float underwaterBoxLength; // 0x4D8(0x4)
	bool attachToPlayer; // 0x4DC(0x1)
	bool DebugMode; // 0x4DD(0x1)
	uint8_t Pad_0x4DE[0x2]; // 0x4DE(0x2)
	struct UObject* PlayerType; // 0x4E0(0x8)
	struct AActor* Player; // 0x4E8(0x8)
	uint8_t Pad_0x4F0[0x18]; // 0x4F0(0x18)
};

// Object: Class OceanPlugin.FlockFish
// Size: 0x690 (Inherited: 0x510)
struct AFlockFish : APawn
{
	uint8_t Pad_0x510[0x10]; // 0x510(0x10)
	struct USphereComponent* FishInteractionSphere; // 0x520(0x8)
	bool IsLeader; // 0x528(0x1)
	uint8_t Pad_0x529[0x7]; // 0x529(0x7)
	struct TArray<struct UObject*> enemyTypes; // 0x530(0x10)
	struct TArray<struct UObject*> preyTypes; // 0x540(0x10)
	struct UObject* neighborType; // 0x550(0x8)
	float followDist; // 0x558(0x4)
	float Speed; // 0x55C(0x4)
	float MaxSpeed; // 0x560(0x4)
	float turnSpeed; // 0x564(0x4)
	float turnFrequency; // 0x568(0x4)
	float hungerResetTime; // 0x56C(0x4)
	float distBehindSpeedUpRange; // 0x570(0x4)
	float SeperationDistanceMultiplier; // 0x574(0x4)
	float FleeDistanceMultiplier; // 0x578(0x4)
	float FleeAccelerationMultiplier; // 0x57C(0x4)
	float ChaseAccelerationMultiplier; // 0x580(0x4)
	float SeekDecelerationMultiplier; // 0x584(0x4)
	float AvoidForceMultiplier; // 0x588(0x4)
	float AvoidanceForce; // 0x58C(0x4)
	struct UObject* PlayerType; // 0x590(0x8)
	struct FVector underwaterMin; // 0x598(0xC)
	struct FVector underwaterMax; // 0x5A4(0xC)
	float CustomZSeekMin; // 0x5B0(0x4)
	float CustomZSeekMax; // 0x5B4(0x4)
	float NumNeighborsToEvaluate; // 0x5B8(0x4)
	float UpdateEveryTick; // 0x5BC(0x4)
	uint8_t Pad_0x5C0[0x10]; // 0x5C0(0x10)
	bool DebugMode; // 0x5D0(0x1)
	uint8_t Pad_0x5D1[0xF]; // 0x5D1(0xF)
	struct AActor* Leader; // 0x5E0(0x8)
	struct TArray<struct AActor*> neighbors; // 0x5E8(0x10)
	struct TArray<struct AActor*> nearbyEnemies; // 0x5F8(0x10)
	struct TArray<struct AActor*> nearbyPrey; // 0x608(0x10)
	struct TArray<struct AActor*> nearbyFriends; // 0x618(0x10)
	struct AActor* fleeTarget; // 0x628(0x8)
	struct AActor* preyTarget; // 0x630(0x8)
	uint8_t Pad_0x638[0x50]; // 0x638(0x50)
	struct AActor* FishManager; // 0x688(0x8)


	// Object: Function OceanPlugin.FlockFish.OnEndOverlap
	// Flags: [Final|Native|Protected]
	// Offset: 0x101fdd2b0
	// Params: [ Num(4) Size(0x1C) ]
	void OnEndOverlap(struct UPrimitiveComponent* activatedComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD2190
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function OceanPlugin.FlockFish.OnBeginOverlap
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101fdd0dc
	// Params: [ Num(6) Size(0xA8) ]
	void OnBeginOverlap(struct UPrimitiveComponent* activatedComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FD1FC4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
};

// Object: Class OceanPlugin.InfiniteSystemComponent
// Size: 0x3C0 (Inherited: 0x3A0)
struct UInfiniteSystemComponent : USceneComponent
{
	bool UpdateInEditor; // 0x399(0x1)
	enum class EFollowMethod FollowMethod; // 0x39A(0x1)
	float GridSnapSize; // 0x39C(0x4)
	float MaxLookAtDistance; // 0x3A0(0x4)
	bool ScaleByDistance; // 0x3A4(0x1)
	float ScaleDistanceFactor; // 0x3A8(0x4)
	float ScaleStartDistance; // 0x3AC(0x4)
	float ScaleMin; // 0x3B0(0x4)
	float ScaleMax; // 0x3B4(0x4)
	uint8_t Pad_0x3BB[0x5]; // 0x3BB(0x5)
};

// Object: Class OceanPlugin.OceanManager
// Size: 0x578 (Inherited: 0x4B0)
struct AOceanManager : AActor
{
	bool EnableGerstnerWaves; // 0x4A9(0x1)
	struct FVector GlobalWaveDirection; // 0x4AC(0xC)
	float GlobalWaveSpeed; // 0x4B8(0x4)
	float GlobalWaveAmplitude; // 0x4BC(0x4)
	float DistanceCheckAbove; // 0x4C0(0x4)
	float DistanceCheckBelow; // 0x4C4(0x4)
	struct TArray<struct FWaveParameter> WaveClusters; // 0x4C8(0x10)
	struct TArray<struct FWaveSetParameters> WaveSetOffsetsOverride; // 0x4D8(0x10)
	float NetWorkTimeOffset; // 0x4E8(0x4)
	bool bEnableLandscapeModulation; // 0x4EC(0x1)
	float ModulationStartHeight; // 0x4F0(0x4)
	float ModulationMaxHeight; // 0x4F4(0x4)
	float ModulationPower; // 0x4F8(0x4)
	uint8_t Pad_0x4FE[0x2]; // 0x4FE(0x2)
	struct ALandscape* Landscape; // 0x500(0x8)
	struct UTexture2D* HeightmapTexture; // 0x508(0x8)
	uint8_t Pad_0x510[0x28]; // 0x510(0x28)
	bool bShouldCorrectTime; // 0x538(0x1)
	bool bEnableWaterBoxModulation; // 0x539(0x1)
	uint8_t Pad_0x53A[0x6]; // 0x53A(0x6)
	struct TArray<struct FBox> WaterBoxes; // 0x540(0x10)
	uint8_t Pad_0x550[0x4]; // 0x550(0x4)
	bool bEnableWaterTransformModulation; // 0x554(0x1)
	uint8_t Pad_0x555[0x3]; // 0x555(0x3)
	struct TArray<struct FTransform> WaterTransforms; // 0x558(0x10)
	struct TArray<struct FVector> WaterBoxExtends; // 0x568(0x10)


	// Object: Function OceanPlugin.OceanManager.LoadLandscapeHeightmap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdd9dc
	// Params: [ Num(1) Size(0x8) ]
	void LoadLandscapeHeightmap(struct UTexture2D* Tex2D);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD31C8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x101FDB780

	// Object: Function OceanPlugin.OceanManager.GetHeightmapPixel
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101fdd914
	// Params: [ Num(3) Size(0x18) ]
	struct FLinearColor GetHeightmapPixel(float U, float V);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD3F4C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD31C8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class OceanPlugin.SegmentOceanManager
// Size: 0x660 (Inherited: 0x578)
struct ASegmentOceanManager : AOceanManager
{
	struct TArray<struct UWaterBoxComponent*> CandidateWaterBoxes; // 0x578(0x10)
	struct TMap<struct UWaterBoxComponent*, struct FSegmentWaterBox> SegmentdWaterBoxes; // 0x588(0x50)
	uint8_t Pad_0x5D8[0x7C]; // 0x5D8(0x7C)
	float FrequencyScale; // 0x654(0x4)
	uint8_t Pad_0x658[0x8]; // 0x658(0x8)


	// Object: Function OceanPlugin.SegmentOceanManager.RemoveBoxComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fddf44
	// Params: [ Num(1) Size(0x8) ]
	void RemoveBoxComponent(struct UWaterBoxComponent* InBoxComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD5AA8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x101FDB780
	// [Call #9] RVA: 0x105184F34

	// Object: Function OceanPlugin.SegmentOceanManager.AddBoxComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fdde90
	// Params: [ Num(2) Size(0x10) ]
	void AddBoxComponent(struct UWaterBoxComponent* InBoxComponent, struct USplineComponent* InDirectionSpline);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD58DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD5AA8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
};

// Object: Class OceanPlugin.TimeManager
// Size: 0x570 (Inherited: 0x4B0)
struct ATimeManager : AActor
{
	struct FTimeDate CurrentLocalTime; // 0x4AC(0x1C)
	float latitude; // 0x4C8(0x4)
	float longitude; // 0x4CC(0x4)
	int OffsetUTC; // 0x4D0(0x4)
	int OffsetDST; // 0x4D4(0x4)
	bool bAllowDaylightSavings; // 0x4D8(0x1)
	bool bDaylightSavingsActive; // 0x4D9(0x1)
	float TimeScaleMultiplier; // 0x4DC(0x4)
	float SolarTime; // 0x4E0(0x4)
	float LocalClockTime; // 0x4E4(0x4)
	float TimeCorrection; // 0x4E8(0x4)
	int LSTM; // 0x4EC(0x4)
	int DayOfYear; // 0x4F0(0x4)
	float EoT; // 0x4F4(0x4)
	float SolarAltAngle; // 0x4F8(0x4)
	float SolarDeclination; // 0x4FC(0x4)
	float SolarAzimuth; // 0x500(0x4)
	float SolarHRA; // 0x504(0x4)
	float SiderealTime; // 0x508(0x4)
	float LunarAltAngle; // 0x50C(0x4)
	float LunarHRA; // 0x510(0x4)
	float LunarDeclination; // 0x514(0x4)
	float LunarAzimuth; // 0x518(0x4)
	float LunarRightAsc; // 0x51C(0x4)
	float LunarElapsedDays; // 0x520(0x4)
	float EcLongitude; // 0x524(0x4)
	float EcLatitude; // 0x528(0x4)
	float EcDistance; // 0x52C(0x4)
	float PartL; // 0x530(0x4)
	float PartM; // 0x534(0x4)
	float PartF; // 0x538(0x4)
	uint8_t Pad_0x53E[0x32]; // 0x53E(0x32)


	// Object: Function OceanPlugin.TimeManager.SetCurrentLocalTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde6e0
	// Params: [ Num(1) Size(0x4) ]
	void SetCurrentLocalTime(float Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD60A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function OceanPlugin.TimeManager.IsLeapYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde654
	// Params: [ Num(2) Size(0x5) ]
	bool IsLeapYear(int Year);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD5E50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD60A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function OceanPlugin.TimeManager.InitializeCalendar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde5cc
	// Params: [ Num(1) Size(0x1C) ]
	void InitializeCalendar(struct FTimeDate Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD5BF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD5E50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD60A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function OceanPlugin.TimeManager.IncrementTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde550
	// Params: [ Num(1) Size(0x4) ]
	void IncrementTime(float DeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD5F9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD5BF0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD5E50
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD60A4
	// [Call #13] RVA: 0x10519022C

	// Object: Function OceanPlugin.TimeManager.GetYearPhase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101fde51c
	// Params: [ Num(1) Size(0x4) ]
	float GetYearPhase();
	// [Call #1] RVA: 0x101FD61F4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FD5F9C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101FD5BF0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD5E50
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD60A4

	// Object: Function OceanPlugin.TimeManager.GetElapsedDayInMinutes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde4e8
	// Params: [ Num(1) Size(0x4) ]
	float GetElapsedDayInMinutes();
	// [Call #1] RVA: 0x101FD5F5C
	// [Call #2] RVA: 0x101FD61F4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD5F9C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD5BF0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD5E50
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.TimeManager.GetDaysInYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde45c
	// Params: [ Num(2) Size(0x8) ]
	int GetDaysInYear(int Year);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD6164
	// [Call #4] RVA: 0x101FD5F5C
	// [Call #5] RVA: 0x101FD61F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD5F9C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD5BF0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.TimeManager.GetDaysInMonth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde398
	// Params: [ Num(3) Size(0xC) ]
	int GetDaysInMonth(int Year, int Month);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD5E90
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101FD6164
	// [Call #9] RVA: 0x101FD5F5C
	// [Call #10] RVA: 0x101FD61F4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD5F9C

	// Object: Function OceanPlugin.TimeManager.GetDayPhase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101fde364
	// Params: [ Num(1) Size(0x4) ]
	float GetDayPhase();
	// [Call #1] RVA: 0x101FD61A8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD5E90
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD6164
	// [Call #10] RVA: 0x101FD5F5C
	// [Call #11] RVA: 0x101FD61F4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FD5F9C

	// Object: Function OceanPlugin.TimeManager.GetDayOfYear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde2cc
	// Params: [ Num(2) Size(0x20) ]
	int GetDayOfYear(struct FTimeDate Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD616C
	// [Call #4] RVA: 0x101FD61A8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD5E90
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD6164
	// [Call #13] RVA: 0x101FD5F5C

	// Object: Function OceanPlugin.TimeManager.CalculateSunAngle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fde294
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator CalculateSunAngle();
	// [Call #1] RVA: 0x101FD6298
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101FD616C
	// [Call #5] RVA: 0x101FD61A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD5E90
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD6164

	// Object: Function OceanPlugin.TimeManager.CalculateMoonPhase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fde260
	// Params: [ Num(1) Size(0x4) ]
	float CalculateMoonPhase();
	// [Call #1] RVA: 0x101FD6840
	// [Call #2] RVA: 0x101FD6298
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD616C
	// [Call #6] RVA: 0x101FD61A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101FD5E90
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function OceanPlugin.TimeManager.CalculateMoonAngle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fde228
	// Params: [ Num(1) Size(0xC) ]
	struct FRotator CalculateMoonAngle();
	// [Call #1] RVA: 0x101FD64E4
	// [Call #2] RVA: 0x101FD6840
	// [Call #3] RVA: 0x101FD6298
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD616C
	// [Call #7] RVA: 0x101FD61A8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD5E90
};

// Object: Class OceanPlugin.WaterBoxComponent
// Size: 0xAB0 (Inherited: 0x9F0)
struct UWaterBoxComponent : UBoxComponent
{
	float AcceptHigherZ; // 0x9EC(0x4)
	struct FVector Direction; // 0x9F0(0xC)
	float SpeedValue; // 0x9FC(0x4)
	float WaveForceMultiplier; // 0xA00(0x4)
	struct TArray<struct FTrippleWaveParameter> TrippleWaveClusters; // 0xA08(0x10)
	float TimeScaleOffset; // 0xA18(0x4)
	float Offset; // 0xA1C(0x4)
	bool UseSplineDirection; // 0xA20(0x1)
	uint8_t Pad_0xA21[0x3]; // 0xA21(0x3)
	float SpeedAttenuationFromSpline; // 0xA24(0x4)
	bool UseSplineZ; // 0xA28(0x1)
	uint8_t Pad_0xA29[0x3]; // 0xA29(0x3)
	float ZOffset; // 0xA2C(0x4)
	float CellSizeX; // 0xA30(0x4)
	float CellSizeY; // 0xA34(0x4)
	struct TMap<float, struct FWaterBoxCell> Cells; // 0xA38(0x50)
	int KeyFactor; // 0xA88(0x4)
	uint8_t Pad_0xA8C[0x24]; // 0xA8C(0x24)
};

// Object: Class OceanPlugin.WaterHeightmapComponent
// Size: 0x1F0 (Inherited: 0x178)
struct UWaterHeightmapComponent : UActorComponent
{
	float DesiredCellSize; // 0x178(0x4)
	bool bOnlyCollidingComponents; // 0x17C(0x1)
	uint8_t Pad_0x17D[0x3]; // 0x17D(0x3)
	float GridSizeMultiplier; // 0x180(0x4)
	bool bDrawUsedTriangles; // 0x184(0x1)
	bool bDrawHeightmap; // 0x185(0x1)
	uint8_t Pad_0x186[0x62]; // 0x186(0x62)
	struct AOceanManager* OceanManager; // 0x1E8(0x8)
};

