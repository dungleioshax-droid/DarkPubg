#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass NewLogin_UIBP.NewLogin_UIBP_C
// Size: 0x578 (Inherited: 0x260)
struct UNewLogin_UIBP_C : UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x8)
	struct UWidgetAnimation* FadeIn; // 0x268(0x8)
	struct UImage* age18; // 0x270(0x8)
	struct UWidgetSwitcher* AuthTypeSwitcher; // 0x278(0x8)
	struct UButton* btnHelpLogin; // 0x280(0x8)
	struct UButton* Button_0; // 0x288(0x8)
	struct UButton* Button_1; // 0x290(0x8)
	struct UButton* Button_Agreement; // 0x298(0x8)
	struct UButton* Button_BackToSelect; // 0x2A0(0x8)
	struct UButton* Button_Bulletin; // 0x2A8(0x8)
	struct UButton* Button_Clause; // 0x2B0(0x8)
	struct UButton* Button_CloseFBWebLogin; // 0x2B8(0x8)
	struct UButton* Button_Language; // 0x2C0(0x8)
	struct UButton* Button_LoginByChannel; // 0x2C8(0x8)
	struct UButton* Button_LoginByPassword; // 0x2D0(0x8)
	struct UButton* Button_MORE; // 0x2D8(0x8)
	struct UButton* Button_NoAuthLogin; // 0x2E0(0x8)
	struct UButton* Button_OfflineServer; // 0x2E8(0x8)
	struct UButton* Button_Privacy; // 0x2F0(0x8)
	struct UButton* Button_QRCode; // 0x2F8(0x8)
	struct UButton* Button_Repair; // 0x300(0x8)
	struct UButton* Button_Service_Agreement; // 0x308(0x8)
	struct UButton* Button_Service_Privacy; // 0x310(0x8)
	struct UCanvasPanel* CanvasPanel_10; // 0x318(0x8)
	struct UCanvasPanel* CanvasPanel_12; // 0x320(0x8)
	struct UCanvasPanel* CanvasPanel_AgeLimited; // 0x328(0x8)
	struct UCanvasPanel* CanvasPanel_Bulletin; // 0x330(0x8)
	struct UCanvasPanel* CanvasPanel_Content; // 0x338(0x8)
	struct UCanvasPanel* CanvasPanel_HelpLogin; // 0x340(0x8)
	struct UCanvasPanel* CanvasPanel_Language; // 0x348(0x8)
	struct UCanvasPanel* CanvasPanel_Privacy; // 0x350(0x8)
	struct UCanvasPanel* CanvasPanel_QRCode; // 0x358(0x8)
	struct UCanvasPanel* CanvasPanel_Repair; // 0x360(0x8)
	struct UCanvasPanel* CanvasPanel_Tips; // 0x368(0x8)
	struct UCheckBox* CheckBox_0; // 0x370(0x8)
	struct UCheckBox* CheckBox_AgreementAgree; // 0x378(0x8)
	struct UCheckBox* CheckBox_PrivacyAgree; // 0x380(0x8)
	struct UWINSDKFBWebLogin* FBWebLoginBrowser; // 0x388(0x8)
	struct UGridPanel* GridPanel_IPX; // 0x390(0x8)
	struct UHorizontalBox* HorizontalBox_1; // 0x398(0x8)
	struct UHorizontalBox* HorizontalBox_6; // 0x3A0(0x8)
	struct UHorizontalBox* HorizontalBox_9; // 0x3A8(0x8)
	struct UHorizontalBox* HorizontalBox_autoHide_2; // 0x3B0(0x8)
	struct UCanvasPanel* HorizontalBox_autoHide_3; // 0x3B8(0x8)
	struct UImage* Image_1; // 0x3C0(0x8)
	struct UImage* Image_4; // 0x3C8(0x8)
	struct UImage* Image_16; // 0x3D0(0x8)
	struct UImage* Image_17; // 0x3D8(0x8)
	struct UImage* Image_18; // 0x3E0(0x8)
	struct UImage* Image_19; // 0x3E8(0x8)
	struct UImage* Image_25; // 0x3F0(0x8)
	struct UImage* Image_33; // 0x3F8(0x8)
	struct UImage* Image_39; // 0x400(0x8)
	struct UImage* Image_40; // 0x408(0x8)
	struct UImage* Image_41; // 0x410(0x8)
	struct UImage* Image_43; // 0x418(0x8)
	struct UImage* Image_44; // 0x420(0x8)
	struct UImage* Image_Logo; // 0x428(0x8)
	struct UImage* Image_Logo_India; // 0x430(0x8)
	struct UImage* Image_weigouxuan; // 0x438(0x8)
	struct UImage* Image_yigouxuan; // 0x440(0x8)
	struct ULogin_InputOfflineLoginItem_UIBP_C* Login_InputOfflineLoginItem_UIBP_Password; // 0x448(0x8)
	struct ULogin_InputOfflineLoginItem_UIBP_C* Login_InputOfflineLoginItem_UIBP_Username; // 0x450(0x8)
	struct ULoopScrollBox* LoopScrollBox_Channel; // 0x458(0x8)
	struct UCanvasPanel* Panel_LoginBtn; // 0x460(0x8)
	struct UCanvasPanel* Panel_LoginNoAuth; // 0x468(0x8)
	struct UCanvasPanel* Panel_LoginSelect; // 0x470(0x8)
	struct UCanvasPanel* Panel_Repair; // 0x478(0x8)
	struct UGridPanel* PanelRoot; // 0x480(0x8)
	struct UUTRichTextBlock* RichText_PrivacyPolicy; // 0x488(0x8)
	struct UMultiLineEditableTextBox* Text_Account; // 0x490(0x8)
	struct UMultiLineEditableTextBox* Text_Password; // 0x498(0x8)
	struct UTextBlock* TextBlock_2; // 0x4A0(0x8)
	struct UTextBlock* TextBlock_3; // 0x4A8(0x8)
	struct UTextBlock* TextBlock_13; // 0x4B0(0x8)
	struct UTextBlock* TextBlock_16; // 0x4B8(0x8)
	struct UTextBlock* TextBlock_20; // 0x4C0(0x8)
	struct UTextBlock* TextBlock_24; // 0x4C8(0x8)
	struct UTextBlock* TextBlock_Account; // 0x4D0(0x8)
	struct UTextBlock* TextBlock_AgeLimited; // 0x4D8(0x8)
	struct UTextBlock* TextBlock_Bulletin; // 0x4E0(0x8)
	struct UTextBlock* TextBlock_LANServer; // 0x4E8(0x8)
	struct UTextBlock* TextBlock_Pwd; // 0x4F0(0x8)
	struct UTextBlock* TextBlock_QRCode; // 0x4F8(0x8)
	struct UTextBlock* TextBlock_UserAgreement; // 0x500(0x8)
	struct UTextBlock* TextBlock_Version; // 0x508(0x8)
	struct UTextBlock* TextGuestTips; // 0x510(0x8)
	struct UImage* TURBO; // 0x518(0x8)
	struct UVerticalBox* VerticalBox_autoHide_3; // 0x520(0x8)
	struct UVerticalBox* VerticalBox_FuncButtons; // 0x528(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_0; // 0x530(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_1; // 0x538(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_AgreementCheckBox; // 0x540(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_LoginMode; // 0x548(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Logo; // 0x550(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_OfflineServer; // 0x558(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_PrivacyCheckBox; // 0x560(0x8)
	struct UCanvasPanel* WINSDKFacebookLoginContainer; // 0x568(0x8)
	struct UAkAudioBank* LoginAudioBank; // 0x570(0x8)


	// Object: Function NewLogin_UIBP.NewLogin_UIBP_C.SetRenderTransformWheniPhone
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void SetRenderTransformWheniPhone();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function NewLogin_UIBP.NewLogin_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function NewLogin_UIBP.NewLogin_UIBP_C.ExecuteUbergraph_NewLogin_UIBP
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_NewLogin_UIBP(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

