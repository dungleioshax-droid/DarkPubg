#pragma once

#include <cstdint>

// Object: Enum PixUI.EPxKeyboardTypes
enum class EPxKeyboardTypes : uint8_t
{
	Default = 0,
	Number = 1,
	Password = 2,
	MultiLine = 3,
	EPxKeyboardTypes_MAX = 4
};

// Object: Enum PixUI.EPxWidgetTransformType
enum class EPxWidgetTransformType : uint8_t
{
	MoveBy = 0,
	MoveTo = 1,
	ResizeBy = 2,
	ResizeTo = 3,
	ScrollBy = 4,
	ScrollTo = 5,
	Count = 6,
	EPxWidgetTransformType_MAX = 7
};

// Object: Enum PixUI.EPxTickMode
enum class EPxTickMode : uint8_t
{
	JS = 0,
	Layout = 1,
	All = 2,
	EPxTickMode_MAX = 3
};

// Object: Enum PixUI.EPxFontFaceType
enum class EPxFontFaceType : uint8_t
{
	FaceType100 = 0,
	FaceType200 = 1,
	FaceType300 = 2,
	FaceType350 = 3,
	FaceType400 = 4,
	FaceType500 = 5,
	FaceType600 = 6,
	FaceType700 = 7,
	FaceType800 = 8,
	FaceType900 = 9,
	FaceType950 = 10,
	EPxFontFaceType_MAX = 11
};

// Object: Enum PixUI.EPxDynamicTextureUpdateMode
enum class EPxDynamicTextureUpdateMode : uint8_t
{
	UpdateRegion = 0,
	UpdateBulkData = 1,
	EPxDynamicTextureUpdateMode_MAX = 2
};

// Object: Enum PixUI.EPxKeyEventType
enum class EPxKeyEventType : uint8_t
{
	KeyDown = 0,
	KeyUp = 1,
	EPxKeyEventType_MAX = 2
};

// Object: Enum PixUI.EPxMouseType
enum class EPxMouseType : uint8_t
{
	MouseLeft = 0,
	MouseRight = 1,
	MouseMiddle = 2,
	MouseThumb = 3,
	MouseThumb2 = 4,
	MouseUnknown = 5,
	EPxMouseType_MAX = 6
};

// Object: Enum PixUI.EPxTouchType
enum class EPxTouchType : uint8_t
{
	TouchStart = 0,
	TouchMoved = 1,
	TouchEnd = 2,
	TouchCanceled = 3,
	EPxTouchType_MAX = 4
};

// Object: Enum PixUI.EPxPublicCapability
enum class EPxPublicCapability : uint8_t
{
	HookCoreLibProfiler = 0,
	AsyncModeUseSemaphore = 1,
	DelayFreePxImgBrush = 2,
	AllowBigFontSize = 3,
	ImageBlendsInLinearSpace = 4,
	ForceShapeMeasureText = 5,
	Count = 6,
	EPxPublicCapability_MAX = 7
};

// Object: Enum PixUI.EPxDebugInfo
enum class EPxDebugInfo : uint8_t
{
	ShowMouse = 0,
	Count = 1,
	EPxDebugInfo_MAX = 2
};

// Object: Enum PixUI.EPxWidgetBatchType
enum class EPxWidgetBatchType : uint8_t
{
	Default = 0,
	Auto = 1,
	NoBatch = 2,
	EPxWidgetBatchType_MAX = 3
};

// Object: Class PixUI.PixUIBrushWrapper
// Size: 0x38 (Inherited: 0x28)
struct UPixUIBrushWrapper : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
};

// Object: Class PixUI.PixUIBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPixUIBPLibrary : UBlueprintFunctionLibrary
{

	// Object: Function PixUI.PixUIBPLibrary.PixUI_Version
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931f84
	// Params: [ Num(1) Size(0x10) ]
	struct FString PixUI_Version();
	// [Call #1] RVA: 0x10285A0C4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_Tick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931f10
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_Tick(float fDeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102859820
	// [Call #4] RVA: 0x10285A0C4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_StartupEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931e30
	// Params: [ Num(3) Size(0x12) ]
	bool PixUI_StartupEx(struct FString strCachePathForWrite, bool bSupportAsyncModel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102859AD8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102859820
	// [Call #12] RVA: 0x10285A0C4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function PixUI.PixUIBPLibrary.PixUI_Startup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931d98
	// Params: [ Num(2) Size(0x11) ]
	bool PixUI_Startup(struct FString strCachePathForWrite);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102859ACC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102859AD8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102859820
	// [Call #18] RVA: 0x10285A0C4
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_Shutdown
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931d64
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_Shutdown();
	// [Call #1] RVA: 0x102859738
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102859ACC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102859AD8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102859820
	// [Call #19] RVA: 0x10285A0C4
	// [Call #20] RVA: 0x101F8156C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetTickIntervalSec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931cf0
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetTickIntervalSec(float fTickIntervalSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C2F4
	// [Call #4] RVA: 0x102859738
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102859ACC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102859AD8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetSupportTextShape
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931c74
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetSupportTextShape(bool beSupportTextShape);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C1C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C2F4
	// [Call #7] RVA: 0x102859738
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102859ACC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetSupportEngineFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931bf8
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetSupportEngineFont(bool bSupportEngineFont);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285AEC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C1C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C2F4
	// [Call #10] RVA: 0x102859738
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102859ACC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetSpecialCapability
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931b68
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetSpecialCapability(struct FString strCapability);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C4CC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285AEC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C1C8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C2F4
	// [Call #16] RVA: 0x102859738

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetSecretKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931ad8
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetSecretKey(struct FString strSecretKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C33C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C4CC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285AEC0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C1C8
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetPxLibDefaultVersionTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931a64
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetPxLibDefaultVersionTag(int nNewPxLibVersionTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A70C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C33C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C4CC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285AEC0
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetPixUIMaxLayerId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029319f0
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetPixUIMaxLayerId(int nMaxLayerId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C240
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285A70C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C33C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C4CC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetPixUIMaxDynamicTextureTotalSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293197c
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetPixUIMaxDynamicTextureTotalSize(int nMaxDynamicTextureTotalSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C258
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C240
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285A70C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C33C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C4CC
	// [Call #19] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetPixUIMaxDynamicTextureGCSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931908
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetPixUIMaxDynamicTextureGCSize(int nMaxDynamicTextureGCSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C2B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C258
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C240
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285A70C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C33C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetPixUIMaxDynamicTextureGCRate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931894
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetPixUIMaxDynamicTextureGCRate(float fMaxGCRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C270
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C2B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C258
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C240
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285A70C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetMobileUseTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931818
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetMobileUseTouchEvent(bool bUseTouchEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C0CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C270
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C2B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C258
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C240

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetMatRootPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931788
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetMatRootPath(struct FString strMatRootPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285BCFC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C0CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C270
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C2B4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C258

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetMatBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029316f8
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetMatBasePath(struct FString strMatBasePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285BF24
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285BCFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C0CC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C270
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetMatAsyncLoad
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293167c
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetMatAsyncLoad(bool bMatAsyncLoad);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C204
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285BF24
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285BCFC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C0CC
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetJsGCThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931608
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetJsGCThreshold(int nGCThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C47C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C204
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285BF24
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285BCFC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetGradientBrushCallFlushCommands
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293158c
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetGradientBrushCallFlushCommands(bool beGradientBrushCallFlushCommands);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C494
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C47C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C204
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285BF24
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetFontTypeFaceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931468
	// Params: [ Num(3) Size(0x28) ]
	void PixUI_SetFontTypeFaceName(struct FString strFontName, uint8_t ePxFontTypeFace, struct FString strFontTypeFaceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285AD04
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C494
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C47C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetExternalInterface
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029313e4
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetExternalInterface(struct TScriptInterface<Class> scriptInterfaceExternal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A808
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285AD04
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C494
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetExtBpCallSupportThrowException
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931368
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetExtBpCallSupportThrowException(bool bSupportThrowException);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C3F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285A808
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285AD04
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDynamicTextureUpdateMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029312f4
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetDynamicTextureUpdateMode(uint8_t eUpdateMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C2C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C3F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285A808
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285AD04
	// [Call #17] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDynamicTextureFilter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102931280
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetDynamicTextureFilter(enum class ETextureFilter eTextureFilter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C2DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C2C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C3F4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285A808
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDynamicLibraryPath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1029311d8
	// Params: [ Num(2) Size(0x11) ]
	bool PixUI_SetDynamicLibraryPath(struct FString& strDynamicLibraryPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A24C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C2DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C2C4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C3F4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDynamicFixFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293115c
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetDynamicFixFontSize(bool bOpenDynamicFix);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B92C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285A24C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C2DC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C2C4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDrawEffectNoPixelSnapping
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029310e0
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetDrawEffectNoPixelSnapping(bool bNoPixelSnapping);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C1EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285B92C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285A24C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C2DC
	// [Call #16] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDefaultFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293106c
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetDefaultFontSize(int nFontSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285AAB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C1EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285B92C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285A24C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetDefaultFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930fdc
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_SetDefaultFont(struct FString strFontName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285AA38
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285AAB8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C1EC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285B92C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetCoreTickDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930f68
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetCoreTickDuration(int nDurationCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C1D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285AA38
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285AAB8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C1EC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetCoreLibValidByTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930eac
	// Params: [ Num(3) Size(0x6) ]
	bool PixUI_SetCoreLibValidByTag(int nVersionTag, bool bValid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285C478
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285C1D4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285AA38
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285AAB8

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetAutoTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930e30
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetAutoTick(bool bAutoTick);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C21C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285C478
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285C1D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285AA38
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetAsyncMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930db4
	// Params: [ Num(1) Size(0x1) ]
	void PixUI_SetAsyncMode(bool beRunAsyncMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C36C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C21C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285C478
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285C1D4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetAsyncBpCallWaitOutTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930d40
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_SetAsyncBpCallWaitOutTime(float fTimeOutSecond);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C3D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C36C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C21C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285C478
	// [Call #15] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_SetAndroidDyLibSearchEnvPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930ca8
	// Params: [ Num(2) Size(0x11) ]
	bool PixUI_SetAndroidDyLibSearchEnvPath(struct FString strDyLibSearchEnvPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A288
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C3D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C36C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C21C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_RHIShaderPlatform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930c74
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_RHIShaderPlatform();
	// [Call #1] RVA: 0x10285A0A4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285A288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285C3D4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285C36C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285C21C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_RHIShaderLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930c40
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_RHIShaderLevel();
	// [Call #1] RVA: 0x10285A0B4
	// [Call #2] RVA: 0x10285A0A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285A288
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285C3D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285C36C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_RemoveSystemFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930bb0
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_RemoveSystemFont(struct FString strFontName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A978
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285A0B4
	// [Call #8] RVA: 0x10285A0A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285A288
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285C3D4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_RemoveDynamicLibraryPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930b18
	// Params: [ Num(2) Size(0x11) ]
	bool PixUI_RemoveDynamicLibraryPath(struct FString strDynamicLibraryPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A3D4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285A978
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10285A0B4
	// [Call #14] RVA: 0x10285A0A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285A288
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_PublicCapabilitySwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930a60
	// Params: [ Num(2) Size(0x2) ]
	void PixUI_PublicCapabilitySwitch(uint8_t EPxDebugInfo, bool bOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285C4AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285A3D4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285A978
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10285A0B4
	// [Call #19] RVA: 0x10285A0A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_PrintProfilerInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930a4c
	// Params: [ Num(0) Size(0x0) ]
	void PixUI_PrintProfilerInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285C4AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285A3D4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285A978
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10285A0B4
	// [Call #19] RVA: 0x10285A0A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_PlatformOSVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930a18
	// Params: [ Num(1) Size(0x4) ]
	float PixUI_PlatformOSVersionCode();
	// [Call #1] RVA: 0x10285A0A0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C4AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285A3D4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285A978
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10285A0B4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_PlatformOSVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029309b4
	// Params: [ Num(1) Size(0x10) ]
	struct FString PixUI_PlatformOSVersion();
	// [Call #1] RVA: 0x10285A09C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10285A0A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285C4AC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285A3D4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_PlatformCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930980
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_PlatformCode();
	// [Call #1] RVA: 0x10285A094
	// [Call #2] RVA: 0x10285A09C
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285A0A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C4AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285A3D4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_Platform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293091c
	// Params: [ Num(1) Size(0x10) ]
	struct FString PixUI_Platform();
	// [Call #1] RVA: 0x10285A004
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10285A094
	// [Call #7] RVA: 0x10285A09C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285A0A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285C4AC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsSupportTextShape
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029308e8
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsSupportTextShape();
	// [Call #1] RVA: 0x10285C1BC
	// [Call #2] RVA: 0x10285A004
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285A094
	// [Call #8] RVA: 0x10285A09C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10285A0A0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285C4AC

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsStartUp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029308b4
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsStartUp();
	// [Call #1] RVA: 0x10285A794
	// [Call #2] RVA: 0x10285C1BC
	// [Call #3] RVA: 0x10285A004
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10285A094
	// [Call #9] RVA: 0x10285A09C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10285A0A0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285C4AC

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930880
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsRHIShaderVulkan();
	// [Call #1] RVA: 0x10285C128
	// [Call #2] RVA: 0x10285A794
	// [Call #3] RVA: 0x10285C1BC
	// [Call #4] RVA: 0x10285A004
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10285A094
	// [Call #10] RVA: 0x10285A09C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10285A0A0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderOpenGLES2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293084c
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsRHIShaderOpenGLES2();
	// [Call #1] RVA: 0x10285C170
	// [Call #2] RVA: 0x10285C128
	// [Call #3] RVA: 0x10285A794
	// [Call #4] RVA: 0x10285C1BC
	// [Call #5] RVA: 0x10285A004
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10285A094
	// [Call #11] RVA: 0x10285A09C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10285A0A0
	// [Call #17] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderOpenGL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930818
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsRHIShaderOpenGL();
	// [Call #1] RVA: 0x10285C0D8
	// [Call #2] RVA: 0x10285C170
	// [Call #3] RVA: 0x10285C128
	// [Call #4] RVA: 0x10285A794
	// [Call #5] RVA: 0x10285C1BC
	// [Call #6] RVA: 0x10285A004
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10285A094
	// [Call #12] RVA: 0x10285A09C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10285A0A0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderMetal
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029307e4
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsRHIShaderMetal();
	// [Call #1] RVA: 0x10285C100
	// [Call #2] RVA: 0x10285C0D8
	// [Call #3] RVA: 0x10285C170
	// [Call #4] RVA: 0x10285C128
	// [Call #5] RVA: 0x10285A794
	// [Call #6] RVA: 0x10285C1BC
	// [Call #7] RVA: 0x10285A004
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285A094
	// [Call #13] RVA: 0x10285A09C
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10285A0A0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderDX
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029307b0
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsRHIShaderDX();
	// [Call #1] RVA: 0x10285C14C
	// [Call #2] RVA: 0x10285C100
	// [Call #3] RVA: 0x10285C0D8
	// [Call #4] RVA: 0x10285C170
	// [Call #5] RVA: 0x10285C128
	// [Call #6] RVA: 0x10285A794
	// [Call #7] RVA: 0x10285C1BC
	// [Call #8] RVA: 0x10285A004
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10285A094
	// [Call #14] RVA: 0x10285A09C
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsOsBit64
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293077c
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsOsBit64();
	// [Call #1] RVA: 0x10285C1AC
	// [Call #2] RVA: 0x10285C14C
	// [Call #3] RVA: 0x10285C100
	// [Call #4] RVA: 0x10285C0D8
	// [Call #5] RVA: 0x10285C170
	// [Call #6] RVA: 0x10285C128
	// [Call #7] RVA: 0x10285A794
	// [Call #8] RVA: 0x10285C1BC
	// [Call #9] RVA: 0x10285A004
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10285A094

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsOsBit32
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930748
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsOsBit32();
	// [Call #1] RVA: 0x10285C1B4
	// [Call #2] RVA: 0x10285C1AC
	// [Call #3] RVA: 0x10285C14C
	// [Call #4] RVA: 0x10285C100
	// [Call #5] RVA: 0x10285C0D8
	// [Call #6] RVA: 0x10285C170
	// [Call #7] RVA: 0x10285C128
	// [Call #8] RVA: 0x10285A794
	// [Call #9] RVA: 0x10285C1BC
	// [Call #10] RVA: 0x10285A004
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsMobileUseTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930714
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsMobileUseTouchEvent();
	// [Call #1] RVA: 0x10285C0C0
	// [Call #2] RVA: 0x10285C1B4
	// [Call #3] RVA: 0x10285C1AC
	// [Call #4] RVA: 0x10285C14C
	// [Call #5] RVA: 0x10285C100
	// [Call #6] RVA: 0x10285C0D8
	// [Call #7] RVA: 0x10285C170
	// [Call #8] RVA: 0x10285C128
	// [Call #9] RVA: 0x10285A794
	// [Call #10] RVA: 0x10285C1BC
	// [Call #11] RVA: 0x10285A004
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsDynamicFixFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029306e0
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsDynamicFixFontSize();
	// [Call #1] RVA: 0x10285B9B0
	// [Call #2] RVA: 0x10285C0C0
	// [Call #3] RVA: 0x10285C1B4
	// [Call #4] RVA: 0x10285C1AC
	// [Call #5] RVA: 0x10285C14C
	// [Call #6] RVA: 0x10285C100
	// [Call #7] RVA: 0x10285C0D8
	// [Call #8] RVA: 0x10285C170
	// [Call #9] RVA: 0x10285C128
	// [Call #10] RVA: 0x10285A794
	// [Call #11] RVA: 0x10285C1BC

	// Object: Function PixUI.PixUIBPLibrary.PixUI_IsAutoTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029306ac
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_IsAutoTick();
	// [Call #1] RVA: 0x10285C228
	// [Call #2] RVA: 0x10285B9B0
	// [Call #3] RVA: 0x10285C0C0
	// [Call #4] RVA: 0x10285C1B4
	// [Call #5] RVA: 0x10285C1AC
	// [Call #6] RVA: 0x10285C14C
	// [Call #7] RVA: 0x10285C100
	// [Call #8] RVA: 0x10285C0D8
	// [Call #9] RVA: 0x10285C170
	// [Call #10] RVA: 0x10285C128
	// [Call #11] RVA: 0x10285A794

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetWindowSlotObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029305d8
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* PixUI_GetWindowSlotObject(int nWindowID, struct FString strTagId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285B6A8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10285C228
	// [Call #10] RVA: 0x10285B9B0
	// [Call #11] RVA: 0x10285C0C0
	// [Call #12] RVA: 0x10285C1B4
	// [Call #13] RVA: 0x10285C1AC
	// [Call #14] RVA: 0x10285C14C
	// [Call #15] RVA: 0x10285C100

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetTotalFontCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029305a4
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetTotalFontCount();
	// [Call #1] RVA: 0x10285AF44
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285B6A8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10285C228
	// [Call #11] RVA: 0x10285B9B0
	// [Call #12] RVA: 0x10285C0C0
	// [Call #13] RVA: 0x10285C1B4
	// [Call #14] RVA: 0x10285C1AC
	// [Call #15] RVA: 0x10285C14C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetTickIntervalSec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930570
	// Params: [ Num(1) Size(0x4) ]
	float PixUI_GetTickIntervalSec();
	// [Call #1] RVA: 0x102859824
	// [Call #2] RVA: 0x10285AF44
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B6A8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10285C228
	// [Call #12] RVA: 0x10285B9B0
	// [Call #13] RVA: 0x10285C0C0
	// [Call #14] RVA: 0x10285C1B4
	// [Call #15] RVA: 0x10285C1AC

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetSupportPxLibVersionTagArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1029304d0
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_GetSupportPxLibVersionTagArray(struct TArray<int>& arraySupportPxLibVersionTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A790
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102859824
	// [Call #8] RVA: 0x10285AF44
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285B6A8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10285C228
	// [Call #18] RVA: 0x10285B9B0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetSupportEngineFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293049c
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetSupportEngineFont();
	// [Call #1] RVA: 0x10285AE44
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285A790
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x102859824
	// [Call #9] RVA: 0x10285AF44
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285B6A8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10285C228

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetScriptVMByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930420
	// Params: [ Num(2) Size(0x10) ]
	struct UPixUIScriptVM* PixUI_GetScriptVMByID(int nScriptVmId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B864
	// [Call #4] RVA: 0x10285AE44
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285A790
	// [Call #8] RVA: 0x101F8BA44
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102859824
	// [Call #12] RVA: 0x10285AF44
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPxLibDefaultVersionTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029303ec
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetPxLibDefaultVersionTag();
	// [Call #1] RVA: 0x10285A694
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285B864
	// [Call #5] RVA: 0x10285AE44
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285A790
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x102859824
	// [Call #13] RVA: 0x10285AF44
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIWidgetSlotObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930318
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* PixUI_GetPixUIWidgetSlotObject(int nPxWidgetID, struct FString strSlotTagId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285B6F8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10285A694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285B864
	// [Call #13] RVA: 0x10285AE44
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285A790
	// [Call #17] RVA: 0x101F8BA44
	// [Call #18] RVA: 0x101F8BA44
	// [Call #19] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIWidgetByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293029c
	// Params: [ Num(2) Size(0x10) ]
	struct UPixUIWidget* PixUI_GetPixUIWidgetByID(int nPxWidgetID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B5E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285B6F8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285A694
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285B864
	// [Call #16] RVA: 0x10285AE44

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIMaxLayerId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930268
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetPixUIMaxLayerId();
	// [Call #1] RVA: 0x10285C234
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285B5E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285B6F8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10285A694
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285B864
	// [Call #17] RVA: 0x10285AE44

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIMaxDynamicTextureTotalSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930234
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetPixUIMaxDynamicTextureTotalSize();
	// [Call #1] RVA: 0x10285C24C
	// [Call #2] RVA: 0x10285C234
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285B5E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B6F8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10285A694
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285B864

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIMaxDynamicTextureGCSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930200
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetPixUIMaxDynamicTextureGCSize();
	// [Call #1] RVA: 0x10285C2A8
	// [Call #2] RVA: 0x10285C24C
	// [Call #3] RVA: 0x10285C234
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285B5E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285B6F8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10285A694
	// [Call #16] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetPixUIMaxDynamicTextureGCRate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029301cc
	// Params: [ Num(1) Size(0x4) ]
	float PixUI_GetPixUIMaxDynamicTextureGCRate();
	// [Call #1] RVA: 0x10285C264
	// [Call #2] RVA: 0x10285C2A8
	// [Call #3] RVA: 0x10285C24C
	// [Call #4] RVA: 0x10285C234
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B5E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285B6F8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10285A694

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetMatRootPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930168
	// Params: [ Num(1) Size(0x10) ]
	struct FString PixUI_GetMatRootPath();
	// [Call #1] RVA: 0x10285BA2C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10285C264
	// [Call #7] RVA: 0x10285C2A8
	// [Call #8] RVA: 0x10285C24C
	// [Call #9] RVA: 0x10285C234
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285B5E0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285B6F8

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetMatBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930104
	// Params: [ Num(1) Size(0x10) ]
	struct FString PixUI_GetMatBasePath();
	// [Call #1] RVA: 0x10285BC3C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10285BA2C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10285C264
	// [Call #12] RVA: 0x10285C2A8
	// [Call #13] RVA: 0x10285C24C
	// [Call #14] RVA: 0x10285C234
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285B5E0
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetMatAsyncLoad
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029300d0
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetMatAsyncLoad();
	// [Call #1] RVA: 0x10285C210
	// [Call #2] RVA: 0x10285BC3C
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285BA2C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285C264
	// [Call #13] RVA: 0x10285C2A8
	// [Call #14] RVA: 0x10285C24C
	// [Call #15] RVA: 0x10285C234
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10285B5E0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetJsGCThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293009c
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetJsGCThreshold();
	// [Call #1] RVA: 0x10285C488
	// [Call #2] RVA: 0x10285C210
	// [Call #3] RVA: 0x10285BC3C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10285BA2C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10285C264
	// [Call #14] RVA: 0x10285C2A8
	// [Call #15] RVA: 0x10285C24C
	// [Call #16] RVA: 0x10285C234
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetGradientBrushCallFlushCommands
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102930068
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetGradientBrushCallFlushCommands();
	// [Call #1] RVA: 0x10285C4A0
	// [Call #2] RVA: 0x10285C488
	// [Call #3] RVA: 0x10285C210
	// [Call #4] RVA: 0x10285BC3C
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10285BA2C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10285C264
	// [Call #15] RVA: 0x10285C2A8
	// [Call #16] RVA: 0x10285C24C
	// [Call #17] RVA: 0x10285C234

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetFontTypeFaceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292ff68
	// Params: [ Num(3) Size(0x28) ]
	struct FString PixUI_GetFontTypeFaceName(struct FString strFontName, uint8_t ePxFontTypeFace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285ADA0
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285C4A0
	// [Call #13] RVA: 0x10285C488
	// [Call #14] RVA: 0x10285C210
	// [Call #15] RVA: 0x10285BC3C
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10285BA2C
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetFontPathByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fec4
	// Params: [ Num(2) Size(0x18) ]
	struct FString PixUI_GetFontPathByIndex(int nIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B0B8
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285ADA0
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10285C4A0
	// [Call #20] RVA: 0x10285C488
	// [Call #21] RVA: 0x10285C210

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetFontPath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292fdc8
	// Params: [ Num(3) Size(0x21) ]
	bool PixUI_GetFontPath(struct FString strFontName, struct FString& strOutFontPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285AC74
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285B0B8
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10285ADA0
	// [Call #23] RVA: 0x101F8156C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetFontNameByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fd24
	// Params: [ Num(2) Size(0x18) ]
	struct FString PixUI_GetFontNameByIndex(int nIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285AFB8
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285AC74
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10285B0B8
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetExtBpCallSupportThrowException
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fcf0
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetExtBpCallSupportThrowException();
	// [Call #1] RVA: 0x10285C400
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285AFB8
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285AC74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10285B0B8
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDynamicTextureUpdateMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fcbc
	// Params: [ Num(1) Size(0x1) ]
	uint8_t PixUI_GetDynamicTextureUpdateMode();
	// [Call #1] RVA: 0x10285C2D0
	// [Call #2] RVA: 0x10285C400
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285AFB8
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285AC74
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDynamicTextureFilter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fc88
	// Params: [ Num(1) Size(0x1) ]
	enum class ETextureFilter PixUI_GetDynamicTextureFilter();
	// [Call #1] RVA: 0x10285C2E8
	// [Call #2] RVA: 0x10285C2D0
	// [Call #3] RVA: 0x10285C400
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285AFB8
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285AC74
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDynamicLibraryPaths
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292fbe8
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_GetDynamicLibraryPaths(struct TArray<struct FString>& arrayOutPaths);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A490
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285C2E8
	// [Call #8] RVA: 0x10285C2D0
	// [Call #9] RVA: 0x10285C400
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285AFB8
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDrawEffectNoPixelSnapping
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fbb4
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetDrawEffectNoPixelSnapping();
	// [Call #1] RVA: 0x10285C1F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285A490
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10285C2E8
	// [Call #9] RVA: 0x10285C2D0
	// [Call #10] RVA: 0x10285C400
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285AFB8
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDefaultFontSize
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292fb30
	// Params: [ Num(1) Size(0x4) ]
	void PixUI_GetDefaultFontSize(int& nOutFontSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285ABF0
	// [Call #4] RVA: 0x10285C1F8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285A490
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10285C2E8
	// [Call #12] RVA: 0x10285C2D0
	// [Call #13] RVA: 0x10285C400
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetDefaultFont
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292fa90
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_GetDefaultFont(struct FString& strFontName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285AB38
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285ABF0
	// [Call #10] RVA: 0x10285C1F8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285A490
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10285C2E8
	// [Call #18] RVA: 0x10285C2D0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetCoreTickDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292fa5c
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetCoreTickDuration();
	// [Call #1] RVA: 0x10285C1E0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285AB38
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285ABF0
	// [Call #11] RVA: 0x10285C1F8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285A490
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x101F8B9F8
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10285C2E8

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetCoreLibVersionTagByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f9e0
	// Params: [ Num(2) Size(0x8) ]
	int PixUI_GetCoreLibVersionTagByIndex(int nIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C410
	// [Call #4] RVA: 0x10285C1E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285AB38
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285ABF0
	// [Call #14] RVA: 0x10285C1F8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetCoreLibCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f9ac
	// Params: [ Num(1) Size(0x4) ]
	int PixUI_GetCoreLibCount();
	// [Call #1] RVA: 0x10285C40C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285C410
	// [Call #5] RVA: 0x10285C1E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285AB38
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285ABF0
	// [Call #15] RVA: 0x10285C1F8

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetCachePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292f90c
	// Params: [ Num(1) Size(0x10) ]
	void PixUI_GetCachePath(struct FString& strOutCachePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A184
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10285C40C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285C410
	// [Call #11] RVA: 0x10285C1E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285AB38
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetAsyncMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f8d8
	// Params: [ Num(1) Size(0x1) ]
	bool PixUI_GetAsyncMode();
	// [Call #1] RVA: 0x10285C3C8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10285A184
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10285C40C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285C410
	// [Call #12] RVA: 0x10285C1E0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285AB38
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_GetAsyncBpCallWaitOutTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f8a4
	// Params: [ Num(1) Size(0x4) ]
	float PixUI_GetAsyncBpCallWaitOutTime();
	// [Call #1] RVA: 0x10285C3E4
	// [Call #2] RVA: 0x10285C3C8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285A184
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10285C40C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10285C410
	// [Call #13] RVA: 0x10285C1E0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_FindByWindowID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f828
	// Params: [ Num(2) Size(0x10) ]
	struct UPixUIWidget* PixUI_FindByWindowID(int nWindowID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B598
	// [Call #4] RVA: 0x10285C3E4
	// [Call #5] RVA: 0x10285C3C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285A184
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10285C40C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285C410
	// [Call #16] RVA: 0x10285C1E0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_DebugInfoSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f770
	// Params: [ Num(2) Size(0x2) ]
	void PixUI_DebugInfoSwitch(uint8_t EPxDebugInfo, bool bOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285C31C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285B598
	// [Call #9] RVA: 0x10285C3E4
	// [Call #10] RVA: 0x10285C3C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285A184
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f73c
	// Params: [ Num(1) Size(0x8) ]
	struct UPixUIWidget* PixUI_CreateWidget();
	// [Call #1] RVA: 0x10285B3C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C31C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285B598
	// [Call #10] RVA: 0x10285C3E4
	// [Call #11] RVA: 0x10285C3C8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285A184
	// [Call #15] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f708
	// Params: [ Num(1) Size(0x8) ]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortWidget();
	// [Call #1] RVA: 0x10285B1B8
	// [Call #2] RVA: 0x10285B3C0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285C31C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B598
	// [Call #11] RVA: 0x10285C3E4
	// [Call #12] RVA: 0x10285C3C8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortAddToCanvasEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f68c
	// Params: [ Num(2) Size(0x10) ]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvasEx(struct UCanvasPanel* pParentCanvas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B2BC
	// [Call #4] RVA: 0x10285B1B8
	// [Call #5] RVA: 0x10285B3C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285C31C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285B598
	// [Call #14] RVA: 0x10285C3E4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortAddToCanvas
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292f570
	// Params: [ Num(4) Size(0x30) ]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvas(struct UCanvasPanel* pParentCanvas, struct FAnchors& Anchors, struct FMargin& Margin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B2F0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B2BC
	// [Call #11] RVA: 0x10285B1B8
	// [Call #12] RVA: 0x10285B3C0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateScriptVM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f53c
	// Params: [ Num(1) Size(0x8) ]
	struct UPixUIScriptVM* PixUI_CreateScriptVM();
	// [Call #1] RVA: 0x10285B790
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10285B2F0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285B2BC
	// [Call #12] RVA: 0x10285B1B8
	// [Call #13] RVA: 0x10285B3C0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateAddToCanvasEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f4c0
	// Params: [ Num(2) Size(0x10) ]
	struct UPixUIWidget* PixUI_CreateAddToCanvasEx(struct UCanvasPanel* pParentCanvas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285B494
	// [Call #4] RVA: 0x10285B790
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285B2F0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285B2BC

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CreateAddToCanvas
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10292f3a4
	// Params: [ Num(4) Size(0x30) ]
	struct UPixUIWidget* PixUI_CreateAddToCanvas(struct UCanvasPanel* p_ParentCanvas, struct FAnchors& Anchors, struct FMargin& Margin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B4C8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B494
	// [Call #11] RVA: 0x10285B790
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_ClearDynamicLibraryPaths
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f390
	// Params: [ Num(0) Size(0x0) ]
	void PixUI_ClearDynamicLibraryPaths();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B4C8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B494
	// [Call #11] RVA: 0x10285B790
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_ClearCacheFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f37c
	// Params: [ Num(0) Size(0x0) ]
	void PixUI_ClearCacheFile();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285B4C8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B494
	// [Call #11] RVA: 0x10285B790
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIBPLibrary.PixUI_CallPixUIAssetGC
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f300
	// Params: [ Num(2) Size(0x5) ]
	bool PixUI_CallPixUIAssetGC(int nViewId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C2C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285B4C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285B494

	// Object: Function PixUI.PixUIBPLibrary.PixUI_BePublicCapabilityOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f284
	// Params: [ Num(2) Size(0x2) ]
	bool PixUI_BePublicCapabilityOpen(uint8_t EPxDebugInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C4BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C2C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285B4C8

	// Object: Function PixUI.PixUIBPLibrary.PixUI_BeDebugInfoOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f208
	// Params: [ Num(2) Size(0x2) ]
	bool PixUI_BeDebugInfoOpen(uint8_t EPxDebugInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285C32C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285C4BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285C2C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function PixUI.PixUIBPLibrary.PixUI_AddSystemFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f124
	// Params: [ Num(2) Size(0x20) ]
	void PixUI_AddSystemFont(struct FString strFontName, struct FString strFontPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285A8F0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285C32C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285C4BC
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285C2C0

	// Object: Function PixUI.PixUIBPLibrary.PixUI_AddDynamicLibraryPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10292f08c
	// Params: [ Num(2) Size(0x11) ]
	bool PixUI_AddDynamicLibraryPath(struct FString strDynamicLibraryPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285A290
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285A8F0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285C32C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
};

// Object: Class PixUI.PixUIExternalInterface
// Size: 0x28 (Inherited: 0x28)
struct IPixUIExternalInterface : IInterface
{

	// Object: Function PixUI.PixUIExternalInterface.OnWidgetUnload
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x9) ]
	bool OnWidgetUnload(struct UWidget* pWidget);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PixUI.PixUIExternalInterface.OnWidgetLoad
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x28) ]
	struct UWidget* OnWidgetLoad(struct FString strWidgetPath, struct FString strWidgetTag);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PixUI.PixUIExternalInterface.OnSlateBrushLoad
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x18) ]
	struct UPixUIBrushWrapper* OnSlateBrushLoad(struct FString strBrushPath);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PixUI.PixUIExternalInterface.OnFileLoad
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x21) ]
	bool OnFileLoad(struct FString StrFilePath, DelegateProperty& callDelegate);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PixUI.PixUIExternalInterface.OnFileCanLoad
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x11) ]
	bool OnFileCanLoad(struct FString StrFilePath);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class PixUI.PixUIInput
// Size: 0x60 (Inherited: 0x28)
struct UPixUIInput : UObject
{
	DelegateProperty DelegateActivateInput; // 0x28(0x10)
	DelegateProperty DelegateDeactivateInput; // 0x38(0x10)
	uint8_t Pad_0x48[0x18]; // 0x48(0x18)


	// Object: Function PixUI.PixUIInput.OnInputText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102934700
	// Params: [ Num(4) Size(0x13) ]
	void OnInputText(struct FString strInsert, bool bEndInput, bool bLostFocus, bool bReplace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D0C44
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C

	// Object: Function PixUI.PixUIInput.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029346cc
	// Params: [ Num(1) Size(0x8) ]
	struct UPixUIInput* Get();
	// [Call #1] RVA: 0x1028D0EF4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D0C44
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
};

// Object: Class PixUI.PixUIRenderTarget
// Size: 0x168 (Inherited: 0x28)
struct UPixUIRenderTarget : UObject
{
	struct FScriptMulticastDelegate DelegateOnCreate; // 0x28(0x10)
	struct FScriptMulticastDelegate DelegateOnClose; // 0x38(0x10)
	struct FScriptMulticastDelegate DelegateOnDestroy; // 0x48(0x10)
	struct FScriptMulticastDelegate DelegateOnLoaded; // 0x58(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateInit; // 0x68(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateDone; // 0x78(0x10)
	struct FScriptMulticastDelegate DelegateOnInternalError; // 0x88(0x10)
	DelegateProperty DelegateOnExternalOpen; // 0x98(0x10)
	struct FScriptMulticastDelegate DelegateOnExternalClose; // 0xA8(0x10)
	struct FScriptMulticastDelegate DelegateOnMessage; // 0xB8(0x10)
	struct FScriptMulticastDelegate DelegateOnAlert; // 0xC8(0x10)
	DelegateProperty DelegateOnConfirm; // 0xD8(0x10)
	DelegateProperty DelegateOnPrompt; // 0xE8(0x10)
	struct FScriptMulticastDelegate DelegateOnAppForeground; // 0xF8(0x10)
	struct FScriptMulticastDelegate DelegateOnAppBackground; // 0x108(0x10)
	int pxLibVersionTag; // 0x118(0x4)
	uint8_t Pad_0x11C[0x4C]; // 0x11C(0x4C)


	// Object: Function PixUI.PixUIRenderTarget.SetTickIntervalSec
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935ba8
	// Params: [ Num(1) Size(0x4) ]
	void SetTickIntervalSec(float fTickIntervalSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2C4C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PixUI.PixUIRenderTarget.SetExternalRenderTarget2D
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935b2c
	// Params: [ Num(1) Size(0x8) ]
	void SetExternalRenderTarget2D(struct UTextureRenderTarget2D* pTextureRenderTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2A48
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D2C4C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PixUI.PixUIRenderTarget.SetBeSupportEventCallNested
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935aa8
	// Params: [ Num(1) Size(0x1) ]
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2B98
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D2A48
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D2C4C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function PixUI.PixUIRenderTarget.SetBeDelayCallMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935a24
	// Params: [ Num(1) Size(0x1) ]
	void SetBeDelayCallMessage(bool bDelayMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2B54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D2B98
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D2A48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D2C4C
	// [Call #13] RVA: 0x10519022C

	// Object: Function PixUI.PixUIRenderTarget.SendPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935954
	// Params: [ Num(2) Size(0x20) ]
	struct FString SendPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D22E8
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D2B54
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D2B98
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D2A48

	// Object: Function PixUI.PixUIRenderTarget.ReSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029358a0
	// Params: [ Num(2) Size(0x8) ]
	void ReSize(int nNewWidth, int nNewHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D2524
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1028D22E8
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D2B54
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.ReScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102935824
	// Params: [ Num(1) Size(0x4) ]
	void ReScale(float fScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2634
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1028D2524
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D22E8
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293577c
	// Params: [ Num(2) Size(0x14) ]
	int PostPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2364
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D2634
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D2524
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D22E8

	// Object: Function PixUI.PixUIRenderTarget.OnExternalTouchEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102935674
	// Params: [ Num(3) Size(0xD) ]
	void OnExternalTouchEvent(struct FVector2D& v2dPosTouch, int nPointerIndex, uint8_t ETouchType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D2800
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D2364
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1028D2634

	// Object: Function PixUI.PixUIRenderTarget.OnExternalTextInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029354fc
	// Params: [ Num(4) Size(0x13) ]
	void OnExternalTextInput(struct FString strNewInput, bool beEndInput, bool beLostFocus, bool beReplace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D29B8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.OnExternalMouseEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1029353ac
	// Params: [ Num(4) Size(0x12) ]
	void OnExternalMouseEvent(struct FVector2D& v2dPosMouse, struct FVector2D& v2dOffsetWheel, uint8_t eMouseType, uint8_t uEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D2724
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.OnExternalKeyBoardEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102935294
	// Params: [ Num(2) Size(0x41) ]
	void OnExternalKeyBoardEvent(struct FKeyEvent& KeyEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D285C
	// [Call #6] RVA: 0x102593DD4
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D2724

	// Object: Function PixUI.PixUIRenderTarget.OnExternalGamepadEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293517c
	// Params: [ Num(2) Size(0x41) ]
	void OnExternalGamepadEvent(struct FKeyEvent& KeyEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D28D0
	// [Call #6] RVA: 0x102593DD4
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D285C
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIRenderTarget.OnExternalGamepadAnalogEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102935084
	// Params: [ Num(2) Size(0x49) ]
	void OnExternalGamepadAnalogEvent(struct FAnalogInputEvent& AnalogInputEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x1028E7F94
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D2944
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x102593DD4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D28D0
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x102593DD4
	// [Call #17] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIRenderTarget.LoadPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934fdc
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromUrl(struct FString strUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D20D0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1028E7F94
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D2944
	// [Call #13] RVA: 0x102593DD4
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIRenderTarget.LoadPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934f34
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromGameAssetPath(struct FString strAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D2238
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D20D0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1028E7F94
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D2944
	// [Call #19] RVA: 0x102593DD4
	// [Call #20] RVA: 0x102593DD4
	// [Call #21] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIRenderTarget.LoadPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102934e24
	// Params: [ Num(3) Size(0x24) ]
	int LoadPageFromData(struct TArray<uint8_t>& arrayData, struct FString strBasePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D2164
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D2238
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D20D0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIRenderTarget.IsPxViewValid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934df0
	// Params: [ Num(1) Size(0x1) ]
	bool IsPxViewValid();
	// [Call #1] RVA: 0x1028D1F18
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D2164
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D2238
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.HistoryGo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934d74
	// Params: [ Num(1) Size(0x4) ]
	void HistoryGo(int nStep);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D24C4
	// [Call #4] RVA: 0x1028D1F18
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D2164
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D2238
	// [Call #18] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIRenderTarget.GetRenderTarget2DWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934d40
	// Params: [ Num(1) Size(0x4) ]
	int GetRenderTarget2DWidth();
	// [Call #1] RVA: 0x1028D2B44
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1028D24C4
	// [Call #5] RVA: 0x1028D1F18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D2164
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.GetRenderTarget2DHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934d0c
	// Params: [ Num(1) Size(0x4) ]
	int GetRenderTarget2DHeight();
	// [Call #1] RVA: 0x1028D2B4C
	// [Call #2] RVA: 0x1028D2B44
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D24C4
	// [Call #6] RVA: 0x1028D1F18
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D2164
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIRenderTarget.GetRenderTarget2D
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934cd8
	// Params: [ Num(1) Size(0x8) ]
	struct UTextureRenderTarget2D* GetRenderTarget2D();
	// [Call #1] RVA: 0x1028D2B10
	// [Call #2] RVA: 0x1028D2B4C
	// [Call #3] RVA: 0x1028D2B44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D24C4
	// [Call #7] RVA: 0x1028D1F18
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D2164
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8BA74

	// Object: Function PixUI.PixUIRenderTarget.GetCoreLibVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934c74
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCoreLibVersion();
	// [Call #1] RVA: 0x1028D2BDC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1028D2B10
	// [Call #7] RVA: 0x1028D2B4C
	// [Call #8] RVA: 0x1028D2B44
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D24C4
	// [Call #12] RVA: 0x1028D1F18
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIRenderTarget.DestroyPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934c60
	// Params: [ Num(0) Size(0x0) ]
	void DestroyPage();
	// [Call #1] RVA: 0x1028D2BDC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1028D2B10
	// [Call #7] RVA: 0x1028D2B4C
	// [Call #8] RVA: 0x1028D2B44
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D24C4
	// [Call #12] RVA: 0x1028D1F18
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PixUI.PixUIRenderTarget.Create
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934a48
	// Params: [ Num(8) Size(0x14) ]
	int Create(int nWidth, int nHeight, float fScale, bool bAsyncModel, bool bCoreLibAsyncModel, bool bGammaSpace, bool bAntiAliasing);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D1D04
	// [Call #16] RVA: 0x1028D2BDC

	// Object: Function PixUI.PixUIRenderTarget.ClosePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102934a34
	// Params: [ Num(0) Size(0x0) ]
	void ClosePage();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D1D04
};

// Object: Class PixUI.PixUIScriptVM
// Size: 0x110 (Inherited: 0x28)
struct UPixUIScriptVM : UObject
{
	struct FScriptMulticastDelegate DelegateOnCreate; // 0x28(0x10)
	struct FScriptMulticastDelegate DelegateOnClose; // 0x38(0x10)
	struct FScriptMulticastDelegate DelegateOnDestroy; // 0x48(0x10)
	struct FScriptMulticastDelegate DelegateOnLoaded; // 0x58(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateInit; // 0x68(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateDone; // 0x78(0x10)
	struct FScriptMulticastDelegate DelegateOnInternalError; // 0x88(0x10)
	DelegateProperty DelegateOnExternalOpen; // 0x98(0x10)
	struct FScriptMulticastDelegate DelegateOnExternalClose; // 0xA8(0x10)
	struct FScriptMulticastDelegate DelegateOnMessage; // 0xB8(0x10)
	struct FScriptMulticastDelegate DelegateOnAppForeground; // 0xC8(0x10)
	struct FScriptMulticastDelegate DelegateOnAppBackground; // 0xD8(0x10)
	int pxLibVersionTag; // 0xE8(0x4)
	uint8_t Pad_0xEC[0x24]; // 0xEC(0x24)


	// Object: Function PixUI.PixUIScriptVM.SetTickIntervalSec
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937f88
	// Params: [ Num(1) Size(0x4) ]
	void SetTickIntervalSec(float fTickIntervalSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D47E8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PixUI.PixUIScriptVM.SetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937e48
	// Params: [ Num(3) Size(0x30) ]
	void SetScriptGlobalString(struct FString StrName, struct FString strKey, struct FString strValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D441C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D47E8
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function PixUI.PixUIScriptVM.SetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937d1c
	// Params: [ Num(3) Size(0x24) ]
	void SetScriptGlobalNumber(struct FString StrName, struct FString strKey, float fValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D4394
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D441C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.SetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937be8
	// Params: [ Num(3) Size(0x21) ]
	void SetScriptGlobalBoolean(struct FString StrName, struct FString strKey, bool bValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D4498
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D4394
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.SetJsGCThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937b6c
	// Params: [ Num(1) Size(0x4) ]
	void SetJsGCThreshold(int nGCThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D4690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D4498
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function PixUI.PixUIScriptVM.SetBeSupportEventCallNested
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937ae8
	// Params: [ Num(1) Size(0x1) ]
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D4738
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D4690
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D4498
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIScriptVM.SetBeDelayCallMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937a64
	// Params: [ Num(1) Size(0x1) ]
	void SetBeDelayCallMessage(bool bDelayMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D46F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D4738
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D4690
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIScriptVM.SendPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937954
	// Params: [ Num(3) Size(0x28) ]
	struct FString SendPxMessage(struct FString strMessage, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D41DC
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D46F8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D4738
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIScriptVM.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293786c
	// Params: [ Num(3) Size(0x18) ]
	int PostPxMessage(struct FString strMessage, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D4238
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D41DC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIScriptVM.LoadUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937784
	// Params: [ Num(3) Size(0x18) ]
	int LoadUrl(struct FString strUrl, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D3FF8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D4238
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function PixUI.PixUIScriptVM.IsValid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937750
	// Params: [ Num(1) Size(0x1) ]
	bool IsValid();
	// [Call #1] RVA: 0x1028D42EC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D3FF8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D4238
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIScriptVM.IsPxVmValid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293771c
	// Params: [ Num(1) Size(0x1) ]
	bool IsPxVmValid();
	// [Call #1] RVA: 0x1028D404C
	// [Call #2] RVA: 0x1028D42EC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D3FF8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D4238
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIScriptVM.GetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029375f8
	// Params: [ Num(3) Size(0x30) ]
	struct FString GetScriptGlobalString(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D4590
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1028D404C
	// [Call #15] RVA: 0x1028D42EC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1028D3FF8
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.GetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029374fc
	// Params: [ Num(3) Size(0x24) ]
	float GetScriptGlobalNumber(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D4514
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D4590
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x1028D404C

	// Object: Function PixUI.PixUIScriptVM.GetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937400
	// Params: [ Num(3) Size(0x21) ]
	bool GetScriptGlobalBoolean(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D4614
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D4514
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIScriptVM.GetPxVMId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029373cc
	// Params: [ Num(1) Size(0x4) ]
	int GetPxVMId();
	// [Call #1] RVA: 0x1028D02B8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D4614
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1028D4514
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIScriptVM.GetCoreLibVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937368
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCoreLibVersion();
	// [Call #1] RVA: 0x1028D4778
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1028D02B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D4614
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1028D4514
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.DoFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102937280
	// Params: [ Num(3) Size(0x18) ]
	int DoFile(struct FString StrFilePath, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D405C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x1028D4778
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1028D02B8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D4614
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.DoBufferByAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029370f0
	// Params: [ Num(5) Size(0x38) ]
	int DoBufferByAssetPath(struct FString strAssetPath, struct FString StrName, struct FString strModuleName, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D4128
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1028D405C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIScriptVM.DoBuffer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102936ef8
	// Params: [ Num(6) Size(0x48) ]
	int DoBuffer(struct TArray<uint8_t>& arrayData, struct FString strBasePath, struct FString StrName, struct FString strModuleName, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1028D40B0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIScriptVM.DestroyVM
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102936e6c
	// Params: [ Num(2) Size(0x8) ]
	int DestroyVM(int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D42E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D40B0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8BA74

	// Object: Function PixUI.PixUIScriptVM.CreateScriptGlobal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102936dd4
	// Params: [ Num(1) Size(0x10) ]
	void CreateScriptGlobal(struct FString StrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D4334
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D42E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIScriptVM.CreateEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102936cb8
	// Params: [ Num(4) Size(0xC) ]
	int CreateEx(bool bAsyncMode, bool bCoreLibAsyncMode, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D3A9C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D4334
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1028D42E4

	// Object: Function PixUI.PixUIScriptVM.Create
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102936be8
	// Params: [ Num(3) Size(0xC) ]
	int Create(bool bAsyncMode, int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D3A90
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D3A9C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D4334

	// Object: Function PixUI.PixUIScriptVM.CloseVM
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102936b5c
	// Params: [ Num(2) Size(0x8) ]
	int CloseVM(int nWaitMS);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D428C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1028D3A90
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class PixUI.PixUIViewPortWidget
// Size: 0x298 (Inherited: 0x260)
struct UPixUIViewPortWidget : UUserWidget
{
	DelegateProperty PixUIWidgetOpenDelegate; // 0x260(0x10)
	DelegateProperty PixUIWidgetConfirmDelegate; // 0x270(0x10)
	DelegateProperty PixUIWidgetPromptDelegate; // 0x280(0x10)
	uint8_t Pad_0x290[0x8]; // 0x290(0x8)


	// Object: Function PixUI.PixUIViewPortWidget.SendPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939c2c
	// Params: [ Num(2) Size(0x20) ]
	struct FString SendPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D41C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function PixUI.PixUIViewPortWidget.PostPxViewMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939b94
	// Params: [ Num(1) Size(0x10) ]
	void PostPxViewMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D5A8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285D41C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C

	// Object: Function PixUI.PixUIViewPortWidget.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939aec
	// Params: [ Num(2) Size(0x14) ]
	int PostPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D3AC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285D5A8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285D41C
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10519022C

	// Object: Function PixUI.PixUIViewPortWidget.OnPixUITransformDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1029399fc
	// Params: [ Num(3) Size(0xC) ]
	void OnPixUITransformDelegate(uint8_t EPxWidgetTransformType, int nParam1, int nParam2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10285D08C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10285D3AC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10285D5A8
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIViewPortWidget.OnPixUIPromptDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1029398d8
	// Params: [ Num(3) Size(0x30) ]
	struct FString OnPixUIPromptDelegate(struct FString strTip, struct FString strDefault);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285CF14
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10285D08C
	// [Call #21] RVA: 0x10516D168

	// Object: Function PixUI.PixUIViewPortWidget.OnPixUIOpenDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x102939740
	// Params: [ Num(5) Size(0x38) ]
	int OnPixUIOpenDelegate(struct FString strUrl, struct FString StrName, struct FString strFeatures, bool bReplace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285CD2C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10285CF14
	// [Call #22] RVA: 0x101F8156C

	// Object: Function PixUI.PixUIViewPortWidget.OnPixUIConfirmDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x102939698
	// Params: [ Num(2) Size(0x11) ]
	bool OnPixUIConfirmDelegate(struct FString strConfirmMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285CE38
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285CD2C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIViewPortWidget.LoadPxViewFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029395f0
	// Params: [ Num(2) Size(0x14) ]
	int LoadPxViewFromUrl(struct FString strUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D4A0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285CE38
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIViewPortWidget.LoadPxViewFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939548
	// Params: [ Num(2) Size(0x14) ]
	int LoadPxViewFromGameAssetPath(struct FString strAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D550
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285D4A0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10285CE38
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIViewPortWidget.LoadPxViewFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102939438
	// Params: [ Num(3) Size(0x24) ]
	int LoadPxViewFromData(struct TArray<uint8_t>& arrayData, struct FString strRootPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285D4F0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285D550
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285D4A0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIViewPortWidget.LoadPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939390
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromUrl(struct FString strUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D24C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10285D4F0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285D550
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIViewPortWidget.LoadPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029392e8
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromGameAssetPath(struct FString strAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10285D340
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10285D24C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10285D4F0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8BA74

	// Object: Function PixUI.PixUIViewPortWidget.LoadPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1029391d8
	// Params: [ Num(3) Size(0x24) ]
	int LoadPageFromData(struct TArray<uint8_t>& arrayData, struct FString strRootPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10285D2BC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10285D340
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10285D24C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIViewPortWidget.GetPixUIWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1029391a4
	// Params: [ Num(1) Size(0x8) ]
	struct UPixUIWidget* GetPixUIWidget();
	// [Call #1] RVA: 0x10285D210
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285D2BC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285D340
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIViewPortWidget.ClosePxView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102939190
	// Params: [ Num(0) Size(0x0) ]
	void ClosePxView();
	// [Call #1] RVA: 0x10285D210
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285D2BC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285D340
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIViewPortWidget.ClosePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293917c
	// Params: [ Num(0) Size(0x0) ]
	void ClosePage();
	// [Call #1] RVA: 0x10285D210
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10285D2BC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10285D340
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
};

// Object: Class PixUI.PixUIWidget
// Size: 0x358 (Inherited: 0x130)
struct UPixUIWidget : UCanvasPanel
{
	uint8_t Pad_0x130[0x8]; // 0x130(0x8)
	struct FScriptMulticastDelegate DelegateOnCreate; // 0x138(0x10)
	struct FScriptMulticastDelegate DelegateOnClose; // 0x148(0x10)
	struct FScriptMulticastDelegate DelegateOnDestroy; // 0x158(0x10)
	struct FScriptMulticastDelegate DelegateOnLoaded; // 0x168(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateInit; // 0x178(0x10)
	struct FScriptMulticastDelegate DelegateOnScriptStateDone; // 0x188(0x10)
	struct FScriptMulticastDelegate DelegateOnInternalError; // 0x198(0x10)
	DelegateProperty DelegateOnExternalOpen; // 0x1A8(0x10)
	struct FScriptMulticastDelegate DelegateOnExternalClose; // 0x1B8(0x10)
	struct FScriptMulticastDelegate DelegateOnMessage; // 0x1C8(0x10)
	struct FScriptMulticastDelegate DelegateOnAlert; // 0x1D8(0x10)
	DelegateProperty DelegateOnConfirm; // 0x1E8(0x10)
	DelegateProperty DelegateOnPrompt; // 0x1F8(0x10)
	struct FScriptMulticastDelegate DelegateOnTransform; // 0x208(0x10)
	struct FScriptMulticastDelegate DelegateOnAppForeground; // 0x218(0x10)
	struct FScriptMulticastDelegate DelegateOnAppBackground; // 0x228(0x10)
	DelegateProperty DelegateHookKeyEvent; // 0x238(0x10)
	int pxLibVersionTag; // 0x248(0x4)
	bool bIsAsync; // 0x24C(0x1)
	bool bIsCoreLibAsync; // 0x24D(0x1)
	bool bIsForcePaint; // 0x24E(0x1)
	bool bIsLazyReleaseMode; // 0x24F(0x1)
	uint8_t BatchType; // 0x250(0x1)
	uint8_t Pad_0x251[0x7]; // 0x251(0x7)
	struct FText TextDefaultUrl; // 0x258(0x18)
	bool bIsStateNodeMode; // 0x270(0x1)
	bool bIsRHIRender; // 0x271(0x1)
	bool bIsRHIRenderAntiAliasing; // 0x272(0x1)
	bool bPxSlotTopHit; // 0x273(0x1)
	bool bIsRetainMode; // 0x274(0x1)
	bool bNoPixelSnapping; // 0x275(0x1)
	uint8_t Pad_0x276[0xE2]; // 0x276(0xE2)


	// Object: Function PixUI.PixUIWidget.ShowNextDrawItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bd00
	// Params: [ Num(0) Size(0x0) ]
	void ShowNextDrawItem();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.ShowNextDrawBatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bcec
	// Params: [ Num(0) Size(0x0) ]
	void ShowNextDrawBatch();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.ShowAllDrawItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bcd8
	// Params: [ Num(0) Size(0x0) ]
	void ShowAllDrawItem();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.ShowAllDrawBatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bcc4
	// Params: [ Num(0) Size(0x0) ]
	void ShowAllDrawBatch();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.SetTickMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bc48
	// Params: [ Num(1) Size(0x1) ]
	void SetTickMode(uint8_t eTickMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D6570
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.SetTickIntervalSec
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293bbcc
	// Params: [ Num(1) Size(0x4) ]
	void SetTickIntervalSec(float fTickIntervalSec);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D66C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D6570
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PixUI.PixUIWidget.SetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293ba8c
	// Params: [ Num(3) Size(0x30) ]
	void SetScriptGlobalString(struct FString StrName, struct FString strKey, struct FString strValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D629C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D66C8
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1028D6570

	// Object: Function PixUI.PixUIWidget.SetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b960
	// Params: [ Num(3) Size(0x24) ]
	void SetScriptGlobalNumber(struct FString StrName, struct FString strKey, float fValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D6214
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D629C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.SetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b82c
	// Params: [ Num(3) Size(0x21) ]
	void SetScriptGlobalBoolean(struct FString StrName, struct FString strKey, bool bValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D6318
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D6214
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.SetJsGCThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b7b0
	// Params: [ Num(1) Size(0x4) ]
	void SetJsGCThreshold(int nGCThreshold);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D6510
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D6318
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function PixUI.PixUIWidget.SetBeSupportEventCallNested
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b72c
	// Params: [ Num(1) Size(0x1) ]
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D6614
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D6510
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D6318
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.SetBeDelayCallMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b6a8
	// Params: [ Num(1) Size(0x1) ]
	void SetBeDelayCallMessage(bool bDelayMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D65D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D6614
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D6510
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.SetBackgroundBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b62c
	// Params: [ Num(1) Size(0x4) ]
	void SetBackgroundBlur(float fBlurStrength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D66D8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D65D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D6614
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D6510
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.SetAutoTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b5a8
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoTransform(bool bAutoTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5E28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D66D8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D65D0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D6614
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.SendPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b4d8
	// Params: [ Num(2) Size(0x20) ]
	struct FString SendPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5BF4
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D5E28
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D66D8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D65D0

	// Object: Function PixUI.PixUIWidget.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b430
	// Params: [ Num(2) Size(0x14) ]
	int PostPxMessage(struct FString strMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5C88
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5BF4
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D5E28
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.OpenPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b388
	// Params: [ Num(2) Size(0x14) ]
	int OpenPageFromUrl(struct FString strUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5AF4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5C88
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D5BF4
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168

	// Object: Function PixUI.PixUIWidget.OpenPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293b2e0
	// Params: [ Num(2) Size(0x14) ]
	int OpenPageFromGameAssetPath(struct FString strAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5BA4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5AF4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D5C88
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.OpenPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293b1d0
	// Params: [ Num(3) Size(0x24) ]
	int OpenPageFromData(struct TArray<uint8_t>& arrayData, struct FString strBasePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D5B44
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D5BA4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D5AF4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.OnExternalTouchEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10293b0c8
	// Params: [ Num(3) Size(0xD) ]
	void OnExternalTouchEvent(struct FVector2D& v2dPosTouch, int nPointerIndex, uint8_t ETouchType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D5F5C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D5B44
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIWidget.OnExternalTextInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293af50
	// Params: [ Num(4) Size(0x13) ]
	void OnExternalTextInput(struct FString strNewInput, bool beEndInput, bool beLostFocus, bool beReplace);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D60A8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.OnExternalMouseEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10293ae00
	// Params: [ Num(4) Size(0x12) ]
	void OnExternalMouseEvent(struct FVector2D& v2dPosMouse, struct FVector2D& v2dOffsetWheel, uint8_t eMouseType, uint8_t uEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5EBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.OnExternalKeyBoardEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293ace8
	// Params: [ Num(2) Size(0x41) ]
	void OnExternalKeyBoardEvent(struct FKeyEvent& KeyEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D5FB8
	// [Call #6] RVA: 0x102593DD4
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D5EBC

	// Object: Function PixUI.PixUIWidget.OnExternalGamepadEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293abd0
	// Params: [ Num(2) Size(0x41) ]
	void OnExternalGamepadEvent(struct FKeyEvent& KeyEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D6008
	// [Call #6] RVA: 0x102593DD4
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D5FB8
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.OnExternalGamepadAnalogEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293aad8
	// Params: [ Num(2) Size(0x49) ]
	void OnExternalGamepadAnalogEvent(struct FAnalogInputEvent& AnalogInputEvent, uint8_t eEventType);
	// [Call #1] RVA: 0x1028E7F94
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D6058
	// [Call #7] RVA: 0x102593DD4
	// [Call #8] RVA: 0x102593DD4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D6008
	// [Call #15] RVA: 0x102593DD4
	// [Call #16] RVA: 0x102593DD4
	// [Call #17] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.LoadPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293aa30
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromUrl(struct FString strUrl);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5548
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1028E7F94
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D6058
	// [Call #13] RVA: 0x102593DD4
	// [Call #14] RVA: 0x102593DD4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function PixUI.PixUIWidget.LoadPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a988
	// Params: [ Num(2) Size(0x14) ]
	int LoadPageFromGameAssetPath(struct FString strAssetPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5894
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5548
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x1028E7F94
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D6058
	// [Call #19] RVA: 0x102593DD4
	// [Call #20] RVA: 0x102593DD4
	// [Call #21] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.LoadPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10293a878
	// Params: [ Num(3) Size(0x24) ]
	int LoadPageFromData(struct TArray<uint8_t>& arrayData, struct FString strBasePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D5730
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1028D5894
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1028D5548
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.IsPxViewValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10293a844
	// Params: [ Num(1) Size(0x1) ]
	bool IsPxViewValid();
	// [Call #1] RVA: 0x1028D567C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D5730
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1028D5894
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.HistoryGo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a7c8
	// Params: [ Num(1) Size(0x4) ]
	void HistoryGo(int nStep);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5DB0
	// [Call #4] RVA: 0x1028D567C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5730
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D5894
	// [Call #18] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.GetSlotObjectByTagId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a720
	// Params: [ Num(2) Size(0x18) ]
	struct UObject* GetSlotObjectByTagId(struct FString strSlotTagId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D5E30
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1028D5DB0
	// [Call #10] RVA: 0x1028D567C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D5730
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.GetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a5fc
	// Params: [ Num(3) Size(0x30) ]
	struct FString GetScriptGlobalString(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D6410
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1028D5E30
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1028D5DB0

	// Object: Function PixUI.PixUIWidget.GetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a500
	// Params: [ Num(3) Size(0x24) ]
	float GetScriptGlobalNumber(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D6394
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D6410
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.GetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a404
	// Params: [ Num(3) Size(0x21) ]
	bool GetScriptGlobalBoolean(struct FString StrName, struct FString strKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D6494
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1028D6394
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.GetPxWinId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a3d0
	// Params: [ Num(1) Size(0x4) ]
	int GetPxWinId();
	// [Call #1] RVA: 0x1028CFF14
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1028D6494
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1028D6394
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function PixUI.PixUIWidget.GetCtrlWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a39c
	// Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetCtrlWidget();
	// [Call #1] RVA: 0x1028D5EB4
	// [Call #2] RVA: 0x1028CFF14
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1028D6494
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1028D6394
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.GetCoreLibVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a338
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCoreLibVersion();
	// [Call #1] RVA: 0x1028D6658
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1028D5EB4
	// [Call #7] RVA: 0x1028CFF14
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D6494
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function PixUI.PixUIWidget.DestroyPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a324
	// Params: [ Num(0) Size(0x0) ]
	void DestroyPage();
	// [Call #1] RVA: 0x1028D6658
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1028D5EB4
	// [Call #7] RVA: 0x1028CFF14
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028D6494
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function PixUI.PixUIWidget.CreateScriptGlobal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a28c
	// Params: [ Num(1) Size(0x10) ]
	void CreateScriptGlobal(struct FString StrName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D61B4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1028D6658
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1028D5EB4
	// [Call #13] RVA: 0x1028CFF14
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D6494
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function PixUI.PixUIWidget.ClosePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10293a278
	// Params: [ Num(0) Size(0x0) ]
	void ClosePage();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D61B4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1028D6658
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1028D5EB4
	// [Call #13] RVA: 0x1028CFF14
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1028D6494
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
};

// Object: Class PixUI.PxCustomDelegate
// Size: 0x88 (Inherited: 0x28)
struct UPxCustomDelegate : UObject
{
	uint8_t Pad_0x28[0x60]; // 0x28(0x60)


	// Object: Function PixUI.PxCustomDelegate.OnPxCustomDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x10293ca4c
	// Params: [ Num(0) Size(0x0) ]
	void OnPxCustomDelegate();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10293CD64
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1028D949C

	// Object: Function PixUI.PxCustomDelegate.MakeCustomDelegate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293c9b4
	// Params: [ Num(2) Size(0x18) ]
	struct UPxCustomDelegate* MakeCustomDelegate(struct FString strCustomDelegateName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1028D9188
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x10293CD64
};

// Object: Class PixUI.PxCustomInterfaceDyImp
// Size: 0xE0 (Inherited: 0x28)
struct UPxCustomInterfaceDyImp : UObject
{
	uint8_t Pad_0x28[0xB8]; // 0x28(0xB8)


	// Object: Function PixUI.PxCustomInterfaceDyImp.MakeCustomInterface
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293cc00
	// Params: [ Num(3) Size(0x20) ]
	struct UPxCustomInterfaceDyImp* MakeCustomInterface(struct FString strCustomInterfaceName, struct UObject* pOverrideBaseClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028D949C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x10293CF64
};

// Object: Class PixUI.PxFileLoad
// Size: 0xA0 (Inherited: 0x28)
struct UPxFileLoad : UObject
{
	uint8_t Pad_0x28[0x78]; // 0x28(0x78)


	// Object: Function PixUI.PxFileLoad.OnFileLoad
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10293ce34
	// Params: [ Num(1) Size(0x10) ]
	void OnFileLoad(struct TArray<uint8_t>& arrayFileData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10290BF64
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105190870
};

// Object: Class PixUI.PxSubLayerWidget
// Size: 0x4A0 (Inherited: 0x100)
struct UPxSubLayerWidget : UWidget
{
	uint8_t Pad_0x100[0x3A0]; // 0x100(0x3A0)
};

// Object: Class PixUI.PxSubCtrlWidget
// Size: 0x4B0 (Inherited: 0x4A0)
struct UPxSubCtrlWidget : UPxSubLayerWidget
{
	uint8_t Pad_0x4A0[0x10]; // 0x4A0(0x10)
};

// Object: Class PixUI.PxSubNodeWidget
// Size: 0x4A0 (Inherited: 0x100)
struct UPxSubNodeWidget : UWidget
{
	uint8_t Pad_0x100[0x3A0]; // 0x100(0x3A0)
};

