#pragma once

#include <cstdint>

// Object: Class PacketHandler.HandlerComponentFactory
// Size: 0x28 (Inherited: 0x28)
struct UHandlerComponentFactory : UObject
{
};

