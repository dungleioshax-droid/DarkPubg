#pragma once

#include <cstdint>

// Object: ScriptStruct AssetRegistry.ARFilter
// Size: 0xE8 (Inherited: 0x0)
struct FARFilter
{
	struct TArray<struct FName> PackageNames; // 0x0(0x10)
	struct TArray<struct FName> PackagePaths; // 0x10(0x10)
	struct TArray<struct FName> ObjectPaths; // 0x20(0x10)
	struct TArray<struct FName> ClassNames; // 0x30(0x10)
	uint8_t Pad_0x40[0x50]; // 0x40(0x50)
	struct TSet<struct FName> RecursiveClassesExclusionSet; // 0x90(0x50)
	bool bRecursivePaths; // 0xE0(0x1)
	bool bRecursiveClasses; // 0xE1(0x1)
	bool bIncludeOnlyOnDiskAssets; // 0xE2(0x1)
	uint8_t Pad_0xE3[0x5]; // 0xE3(0x5)
};

// Object: ScriptStruct AssetRegistry.AssetBundleData
// Size: 0x10 (Inherited: 0x0)
struct FAssetBundleData
{
	struct TArray<struct FAssetBundleEntry> Bundles; // 0x0(0x10)
};

// Object: ScriptStruct AssetRegistry.AssetBundleEntry
// Size: 0x28 (Inherited: 0x0)
struct FAssetBundleEntry
{
	struct FPrimaryAssetId BundleScope; // 0x0(0x10)
	struct FName BundleName; // 0x10(0x8)
	struct TArray<struct FSoftObjectPath> BundleAssets; // 0x18(0x10)
};

// Object: ScriptStruct AssetRegistry.AssetData
// Size: 0x50 (Inherited: 0x0)
struct FAssetData
{
	struct FName ObjectPath; // 0x0(0x8)
	struct FName PackageName; // 0x8(0x8)
	struct FName PackagePath; // 0x10(0x8)
	struct FName AssetName; // 0x18(0x8)
	struct FName AssetClass; // 0x20(0x8)
	uint8_t Pad_0x28[0x28]; // 0x28(0x28)
};

// Object: ScriptStruct AssetRegistry.TagAndValue
// Size: 0x18 (Inherited: 0x0)
struct FTagAndValue
{
	struct FName Tag; // 0x0(0x8)
	struct FString Value; // 0x8(0x10)
};

// Object: Class AssetRegistry.AssetRegistryImpl
// Size: 0x6F8 (Inherited: 0x28)
struct UAssetRegistryImpl : UObject
{
	uint8_t Pad_0x28[0x6D0]; // 0x28(0x6D0)
};

// Object: Class AssetRegistry.AssetRegistryHelpers
// Size: 0x28 (Inherited: 0x28)
struct UAssetRegistryHelpers : UObject
{

	// Object: Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e379a4
	// Params: [ Num(2) Size(0x68) ]
	struct FSoftObjectPath ToSoftObjectPath(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22BD4
	// [Call #4] RVA: 0x10517CE3C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x102108F2C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x102108F2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37860
	// Params: [ Num(3) Size(0x1E0) ]
	struct FARFilter SetFilterTagsAndValues(struct FARFilter& InFilter, struct TArray<struct FTagAndValue>& InTagsAndValues);
	// [Call #1] RVA: 0x103806238
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E22DE4
	// [Call #7] RVA: 0x105E39BC0
	// [Call #8] RVA: 0x103806304
	// [Call #9] RVA: 0x105E39C9C
	// [Call #10] RVA: 0x103806304
	// [Call #11] RVA: 0x103806304
	// [Call #12] RVA: 0x105E39C9C
	// [Call #13] RVA: 0x103806304
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E22BD4
	// [Call #18] RVA: 0x10517CE3C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x102108F2C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x102108F2C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10519022C

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsValid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e377ac
	// Params: [ Num(2) Size(0x51) ]
	bool IsValid(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22AEC
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x103806238
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E22DE4
	// [Call #13] RVA: 0x105E39BC0
	// [Call #14] RVA: 0x103806304
	// [Call #15] RVA: 0x105E39C9C
	// [Call #16] RVA: 0x103806304
	// [Call #17] RVA: 0x103806304
	// [Call #18] RVA: 0x105E39C9C
	// [Call #19] RVA: 0x103806304
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsUAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e376f8
	// Params: [ Num(2) Size(0x51) ]
	bool IsUAsset(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22AFC
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E22AEC
	// [Call #10] RVA: 0x102108F2C
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x103806238
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E22DE4
	// [Call #19] RVA: 0x105E39BC0
	// [Call #20] RVA: 0x103806304
	// [Call #21] RVA: 0x105E39C9C

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsRedirector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37644
	// Params: [ Num(2) Size(0x51) ]
	bool IsRedirector(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22BD0
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E22AFC
	// [Call #10] RVA: 0x102108F2C
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E22AEC
	// [Call #16] RVA: 0x102108F2C
	// [Call #17] RVA: 0x102108F2C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x103806238

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37590
	// Params: [ Num(2) Size(0x51) ]
	bool IsAssetLoaded(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22D14
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E22BD0
	// [Call #10] RVA: 0x102108F2C
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E22AFC
	// [Call #16] RVA: 0x102108F2C
	// [Call #17] RVA: 0x102108F2C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetTagValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37418
	// Params: [ Num(4) Size(0x69) ]
	bool GetTagValue(struct FAssetData& InAssetData, struct FName& InTagName, struct FString& OutTagValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E22DDC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x102108F2C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E22D14
	// [Call #16] RVA: 0x102108F2C
	// [Call #17] RVA: 0x102108F2C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e3733c
	// Params: [ Num(2) Size(0x60) ]
	struct FString GetFullName(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22BCC
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x102108F2C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x102108F2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E22DDC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x102108F2C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x102108F2C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37260
	// Params: [ Num(2) Size(0x60) ]
	struct FString GetExportTextName(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22D9C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x102108F2C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x102108F2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E22BCC
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102108F2C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x102108F2C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e371ac
	// Params: [ Num(2) Size(0x58) ]
	struct UObject* GetClass(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22C2C
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E22D9C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x102108F2C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x102108F2C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E22BCC
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x102108F2C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e37168
	// Params: [ Num(1) Size(0x10) ]
	struct TScriptInterface<Class> GetAssetRegistry();
	// [Call #1] RVA: 0x105E22A58
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E22C2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x102108F2C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E22D9C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x102108F2C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x102108F2C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e370b4
	// Params: [ Num(2) Size(0x58) ]
	struct UObject* GetAsset(struct FAssetData& InAssetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E22D10
	// [Call #4] RVA: 0x102108F2C
	// [Call #5] RVA: 0x102108F2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x105E22A58
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E22C2C
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x102108F2C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E22D9C
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x102108F2C

	// Object: Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e36fcc
	// Params: [ Num(3) Size(0x60) ]
	struct FAssetData CreateAssetData(struct UObject* InAsset, bool bAllowBlueprintClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E22A80
	// [Call #6] RVA: 0x105E196C8
	// [Call #7] RVA: 0x102108F2C
	// [Call #8] RVA: 0x102108F2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E22D10
	// [Call #13] RVA: 0x102108F2C
	// [Call #14] RVA: 0x102108F2C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x105E22A58
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class AssetRegistry.AssetRegistry
// Size: 0x28 (Inherited: 0x28)
struct IAssetRegistry : IInterface
{

	// Object: Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e389dc
	// Params: [ Num(2) Size(0xF8) ]
	void RunAssetsThroughFilter(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& filter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103806238
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x103806304
	// [Call #7] RVA: 0x102108EE0
	// [Call #8] RVA: 0x103806304
	// [Call #9] RVA: 0x102108EE0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AssetRegistry.AssetRegistry.IsLoadingAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e389a0
	// Params: [ Num(1) Size(0x1) ]
	bool IsLoadingAssets();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103806238
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x103806304
	// [Call #7] RVA: 0x102108EE0
	// [Call #8] RVA: 0x103806304
	// [Call #9] RVA: 0x102108EE0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AssetRegistry.AssetRegistry.HasAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e388c8
	// Params: [ Num(3) Size(0xA) ]
	bool HasAssets(struct FName PackagePath, bool bRecursive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x103806238
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x103806304
	// [Call #11] RVA: 0x102108EE0
	// [Call #12] RVA: 0x103806304
	// [Call #13] RVA: 0x102108EE0
	// [Call #14] RVA: 0x106C8459C

	// Object: Function AssetRegistry.AssetRegistry.GetSubPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38770
	// Params: [ Num(3) Size(0x21) ]
	void GetSubPaths(struct FString InBasePath, struct TArray<struct FString>& OutPathList, bool bInRecurse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByPath
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e385d8
	// Params: [ Num(5) Size(0x1B) ]
	bool GetAssetsByPath(struct FName PackagePath, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102108EE0
	// [Call #10] RVA: 0x102108EE0
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38490
	// Params: [ Num(4) Size(0x1A) ]
	bool GetAssetsByPackageName(struct FName PackageName, struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102108EE0
	// [Call #8] RVA: 0x102108EE0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38348
	// Params: [ Num(4) Size(0x1A) ]
	bool GetAssetsByClass(struct FName ClassName, struct TArray<struct FAssetData>& OutAssetData, bool bSearchSubClasses);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102108EE0
	// [Call #8] RVA: 0x102108EE0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AssetRegistry.AssetRegistry.GetAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38214
	// Params: [ Num(3) Size(0xF9) ]
	bool GetAssets(struct FARFilter& filter, struct TArray<struct FAssetData>& OutAssetData);
	// [Call #1] RVA: 0x103806238
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102108EE0
	// [Call #7] RVA: 0x103806304
	// [Call #8] RVA: 0x102108EE0
	// [Call #9] RVA: 0x103806304
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102108EE0

	// Object: Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38114
	// Params: [ Num(3) Size(0x60) ]
	struct FAssetData GetAssetByObjectPath(struct FName ObjectPath, bool bIncludeOnlyOnDiskAssets);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E196C8
	// [Call #6] RVA: 0x102108F2C
	// [Call #7] RVA: 0x102108F2C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x103806238
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102108EE0
	// [Call #15] RVA: 0x103806304
	// [Call #16] RVA: 0x102108EE0
	// [Call #17] RVA: 0x103806304
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AssetRegistry.AssetRegistry.GetAllCachedPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e38064
	// Params: [ Num(1) Size(0x10) ]
	void GetAllCachedPaths(struct TArray<struct FString>& OutPathList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E196C8
	// [Call #11] RVA: 0x102108F2C
	// [Call #12] RVA: 0x102108F2C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x103806238
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AssetRegistry.AssetRegistry.GetAllAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e37f58
	// Params: [ Num(3) Size(0x12) ]
	bool GetAllAssets(struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102108EE0
	// [Call #6] RVA: 0x102108EE0
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

