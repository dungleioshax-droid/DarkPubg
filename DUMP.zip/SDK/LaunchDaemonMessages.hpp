#pragma once

#include <cstdint>

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonLaunchApp
// Size: 0x20 (Inherited: 0x0)
struct FIOSLaunchDaemonLaunchApp
{
	struct FString AppID; // 0x0(0x10)
	struct FString Parameters; // 0x10(0x10)
};

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPong
// Size: 0x48 (Inherited: 0x0)
struct FIOSLaunchDaemonPong
{
	struct FString DeviceID; // 0x0(0x10)
	struct FString DeviceName; // 0x10(0x10)
	struct FString DeviceStatus; // 0x20(0x10)
	struct FString DeviceType; // 0x30(0x10)
	bool bCanPowerOff; // 0x40(0x1)
	bool bCanPowerOn; // 0x41(0x1)
	bool bCanReboot; // 0x42(0x1)
	uint8_t Pad_0x43[0x5]; // 0x43(0x5)
};

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPing
// Size: 0x1 (Inherited: 0x0)
struct FIOSLaunchDaemonPing
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

