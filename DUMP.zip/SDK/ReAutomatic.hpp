#pragma once

#include <cstdint>

// Object: Enum ReAutomatic.EUIType
enum class EUIType : uint8_t
{
	Any = 0,
	Clickable = 1,
	TextInput = 2,
	Scrollable = 3,
	Text = 4,
	Checkable = 5,
	EUIType_MAX = 6
};

// Object: Enum ReAutomatic.ERouteProtoID
enum class ERouteProtoID : uint8_t
{
	Regist = 0,
	NormalMessage = 1,
	Close = 2,
	HeartBeat = 3,
	Log = 4,
	ListDevice = 5,
	Max = 6
};

// Object: Enum ReAutomatic.ERouteType
enum class ERouteType : uint8_t
{
	RouteServer = 0,
	LocalController = 1,
	MobileDevice = 2,
	UnrealEngine = 3,
	WebService = 4,
	Max = 5
};

// Object: ScriptStruct ReAutomatic.FindUICondition
// Size: 0x28 (Inherited: 0x0)
struct FFindUICondition
{
	uint8_t UIType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString UINameRegex; // 0x8(0x10)
	struct FString ContainTextRegex; // 0x18(0x10)
};

// Object: ScriptStruct ReAutomatic.LuaScriptMessage
// Size: 0x18 (Inherited: 0x0)
struct FLuaScriptMessage
{
	int Index; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString LuaScript; // 0x8(0x10)
};

// Object: ScriptStruct ReAutomatic.CmdTypes
// Size: 0x1 (Inherited: 0x0)
struct FCmdTypes
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct ReAutomatic.RemoteControllerInfo
// Size: 0x18 (Inherited: 0x0)
struct FRemoteControllerInfo
{
	struct FString ControllerName; // 0x0(0x10)
	uint8_t ControllerType; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct ReAutomatic.RouteSendMessage
// Size: 0x50 (Inherited: 0x0)
struct FRouteSendMessage
{
	uint8_t FromRouteType; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FString FromRouteName; // 0x8(0x10)
	uint8_t TargetRouteType; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
	struct FString TargetRouteName; // 0x20(0x10)
	uint8_t Pad_0x30[0x20]; // 0x30(0x20)
};

// Object: ScriptStruct ReAutomatic.RawCommandMessage
// Size: 0x20 (Inherited: 0x0)
struct FRawCommandMessage
{
	struct FString CmdId; // 0x0(0x10)
	uint8_t Pad_0x10[0x10]; // 0x10(0x10)
};

// Object: ScriptStruct ReAutomatic.RouteCloseMessage
// Size: 0x18 (Inherited: 0x0)
struct FRouteCloseMessage
{
	struct FString RegistName; // 0x0(0x10)
	uint8_t RegistType; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: ScriptStruct ReAutomatic.RouteRegistMessage
// Size: 0x18 (Inherited: 0x0)
struct FRouteRegistMessage
{
	struct FString RegistName; // 0x0(0x10)
	uint8_t RegistType; // 0x10(0x1)
	uint8_t Pad_0x11[0x7]; // 0x11(0x7)
};

// Object: Class ReAutomatic.AutomaticCommonHelper
// Size: 0x28 (Inherited: 0x28)
struct UAutomaticCommonHelper : UBlueprintFunctionLibrary
{

	// Object: Function ReAutomatic.AutomaticCommonHelper.IsClassOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025b0c10
	// Params: [ Num(3) Size(0x11) ]
	bool IsClassOf(struct UObject* Object, struct UObject* Class);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AE364
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519077C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x1025B0F60
};

// Object: Class ReAutomatic.AutomaticPlatformHelper
// Size: 0x28 (Inherited: 0x28)
struct UAutomaticPlatformHelper : UBlueprintFunctionLibrary
{

	// Object: Function ReAutomatic.AutomaticPlatformHelper.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025b0e74
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceName();
	// [Call #1] RVA: 0x1025AE38C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x1025B0D58
	// [Call #10] RVA: 0x105185230
	// [Call #11] RVA: 0x1051903D0
	// [Call #12] RVA: 0x1025B0D58
};

// Object: Class ReAutomatic.AutomaticUIHelper
// Size: 0x28 (Inherited: 0x28)
struct UAutomaticUIHelper : UBlueprintFunctionLibrary
{

	// Object: Function ReAutomatic.AutomaticUIHelper.IsWidgetVisibleWithUICondition
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x1025b155c
	// Params: [ Num(3) Size(0x2D) ]
	bool IsWidgetVisibleWithUICondition(struct FFindUICondition& Condition, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AF538
	// [Call #6] RVA: 0x1025AF82C
	// [Call #7] RVA: 0x1025AF82C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function ReAutomatic.AutomaticUIHelper.IsWidgetVisible
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1025b14e0
	// Params: [ Num(2) Size(0x9) ]
	bool IsWidgetVisible(struct UWidget* Widget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025AE714
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025AF538
	// [Call #9] RVA: 0x1025AF82C
	// [Call #10] RVA: 0x1025AF82C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function ReAutomatic.AutomaticUIHelper.IsWidgetTextMatchRegex
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1025b140c
	// Params: [ Num(3) Size(0x19) ]
	bool IsWidgetTextMatchRegex(struct UWidget* Widget, struct FString Text);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AEFA4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025AE714
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025AF538
	// [Call #17] RVA: 0x1025AF82C
	// [Call #18] RVA: 0x1025AF82C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function ReAutomatic.AutomaticUIHelper.IsWidgetMatchType
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1025b1354
	// Params: [ Num(3) Size(0xA) ]
	bool IsWidgetMatchType(struct UWidget* Widget, uint8_t Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AEE78
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025AEFA4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025AE714
	// [Call #17] RVA: 0x10516D168

	// Object: Function ReAutomatic.AutomaticUIHelper.FindWidgetObjectWithUICondition
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x1025b125c
	// Params: [ Num(3) Size(0x38) ]
	struct UWidget* FindWidgetObjectWithUICondition(struct FFindUICondition& Condition, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AF44C
	// [Call #6] RVA: 0x1025AF82C
	// [Call #7] RVA: 0x1025AF82C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025AEE78
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1025AEFA4

	// Object: Function ReAutomatic.AutomaticUIHelper.FindUWidgetObject
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1025b1184
	// Params: [ Num(3) Size(0x20) ]
	struct UWidget* FindUWidgetObject(struct FString Name, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025AF2FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025AF44C
	// [Call #14] RVA: 0x1025AF82C
	// [Call #15] RVA: 0x1025AF82C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

