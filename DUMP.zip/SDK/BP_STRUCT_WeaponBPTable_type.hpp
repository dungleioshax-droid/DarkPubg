#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_WeaponBPTable_type.BP_STRUCT_WeaponBPTable_type
// Size: 0x58 (Inherited: 0x0)
struct FBP_STRUCT_WeaponBPTable_type
{
	struct FString CName_0_CD600C314161E84152102388BAC2C6E5; // 0x0(0x10)
	struct FString Path_1_4B3A115440CA4D3ED6BB1CAE5312F1D0; // 0x10(0x10)
	int ID_2_CE3ED80D47C51A8880AD2CBC79F2E6D0; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString Wrapper_3_1417B6C029873FAD0DDBA26505064332; // 0x28(0x10)
	struct FString LobbyPath_4_4623DFC03FE9DCA3544D323C06AB9278; // 0x38(0x10)
	struct FString WeaponClass_6_06A7B680656FDD4E11BFC0FA01E01EC3; // 0x48(0x10)
};

