#pragma once

#include <cstdint>

// Object: Enum CinematicCamera.ECameraFocusMethod
enum class ECameraFocusMethod : uint8_t
{
	None = 0,
	Manual = 1,
	Tracking = 2,
	ECameraFocusMethod_MAX = 3
};

// Object: ScriptStruct CinematicCamera.CameraLookatTrackingSettings
// Size: 0x30 (Inherited: 0x0)
struct FCameraLookatTrackingSettings
{
	uint8_t bEnableLookAtTracking : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bDrawDebugLookAtTrackingPosition : 1; // 0x0(0x1), Mask(0x2)
	uint8_t BitPad_0x0_2 : 6; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float LookAtTrackingInterpSpeed; // 0x4(0x4)
	uint8_t Pad_0x8[0x10]; // 0x8(0x10)
	struct AActor* ActorToTrack; // 0x18(0x8)
	struct FVector RelativeOffset; // 0x20(0xC)
	uint8_t bAllowRoll : 1; // 0x2C(0x1), Mask(0x1)
	uint8_t BitPad_0x2C_1 : 7; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
};

// Object: ScriptStruct CinematicCamera.CameraFocusSettings
// Size: 0x38 (Inherited: 0x0)
struct FCameraFocusSettings
{
	uint8_t FocusMethod; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float ManualFocusDistance; // 0x4(0x4)
	struct FCameraTrackingFocusSettings TrackingFocusSettings; // 0x8(0x18)
	uint8_t bDrawDebugFocusPlane : 1; // 0x20(0x1), Mask(0x1)
	uint8_t BitPad_0x20_1 : 7; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	struct FColor DebugFocusPlaneColor; // 0x24(0x4)
	uint8_t bSmoothFocusChanges : 1; // 0x28(0x1), Mask(0x1)
	uint8_t BitPad_0x28_1 : 7; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	float FocusSmoothingInterpSpeed; // 0x2C(0x4)
	float FocusOffset; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: ScriptStruct CinematicCamera.CameraTrackingFocusSettings
// Size: 0x18 (Inherited: 0x0)
struct FCameraTrackingFocusSettings
{
	struct AActor* ActorToTrack; // 0x0(0x8)
	struct FVector RelativeOffset; // 0x8(0xC)
	uint8_t bDrawDebugTrackingFocusPoint : 1; // 0x14(0x1), Mask(0x1)
	uint8_t BitPad_0x14_1 : 7; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
};

// Object: ScriptStruct CinematicCamera.NamedLensPreset
// Size: 0x28 (Inherited: 0x0)
struct FNamedLensPreset
{
	struct FString Name; // 0x0(0x10)
	struct FCameraLensSettings LensSettings; // 0x10(0x14)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct CinematicCamera.CameraLensSettings
// Size: 0x14 (Inherited: 0x0)
struct FCameraLensSettings
{
	float MinFocalLength; // 0x0(0x4)
	float MaxFocalLength; // 0x4(0x4)
	float MinFStop; // 0x8(0x4)
	float MaxFStop; // 0xC(0x4)
	float MinimumFocusDistance; // 0x10(0x4)
};

// Object: ScriptStruct CinematicCamera.NamedFilmbackPreset
// Size: 0x20 (Inherited: 0x0)
struct FNamedFilmbackPreset
{
	struct FString Name; // 0x0(0x10)
	struct FCameraFilmbackSettings FilmbackSettings; // 0x10(0xC)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct CinematicCamera.CameraFilmbackSettings
// Size: 0xC (Inherited: 0x0)
struct FCameraFilmbackSettings
{
	float SensorWidth; // 0x0(0x4)
	float SensorHeight; // 0x4(0x4)
	float SensorAspectRatio; // 0x8(0x4)
};

// Object: Class CinematicCamera.CameraRig_Crane
// Size: 0x4E0 (Inherited: 0x4B0)
struct ACameraRig_Crane : AActor
{
	float CranePitch; // 0x4AC(0x4)
	float CraneYaw; // 0x4B0(0x4)
	float CraneArmLength; // 0x4B4(0x4)
	bool bLockMountPitch; // 0x4B8(0x1)
	bool bLockMountYaw; // 0x4B9(0x1)
	uint8_t Pad_0x4BE[0x2]; // 0x4BE(0x2)
	struct USceneComponent* TransformComponent; // 0x4C0(0x8)
	struct USceneComponent* CraneYawControl; // 0x4C8(0x8)
	struct USceneComponent* CranePitchControl; // 0x4D0(0x8)
	struct USceneComponent* CraneCameraMount; // 0x4D8(0x8)
};

// Object: Class CinematicCamera.CameraRig_Rail
// Size: 0x4C8 (Inherited: 0x4B0)
struct ACameraRig_Rail : AActor
{
	float CurrentPositionOnRail; // 0x4AC(0x4)
	struct USceneComponent* TransformComponent; // 0x4B0(0x8)
	struct USplineComponent* RailSplineComponent; // 0x4B8(0x8)
	struct USceneComponent* RailCameraMount; // 0x4C0(0x8)
};

// Object: Class CinematicCamera.CineCameraActor
// Size: 0xA80 (Inherited: 0xA40)
struct ACineCameraActor : ACameraActor
{
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0xA40(0x30)
	uint8_t Pad_0xA70[0x10]; // 0xA70(0x10)


	// Object: Function CinematicCamera.CineCameraActor.GetCineCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc7de4
	// Params: [ Num(1) Size(0x8) ]
	struct UCineCameraComponent* GetCineCameraComponent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105DC7ABC
	// [Call #5] RVA: 0x105185230
	// [Call #6] RVA: 0x1051903D0
	// [Call #7] RVA: 0x105DC7ABC
	// [Call #8] RVA: 0x105184F34
};

// Object: Class CinematicCamera.CineCameraComponent
// Size: 0xA50 (Inherited: 0x9A0)
struct UCineCameraComponent : UCameraComponent
{
	struct FCameraFilmbackSettings FilmbackSettings; // 0x994(0xC)
	struct FCameraLensSettings LensSettings; // 0x9A0(0x14)
	struct FCameraFocusSettings FocusSettings; // 0x9B8(0x38)
	float CurrentFocalLength; // 0x9F0(0x4)
	float CurrentAperture; // 0x9F4(0x4)
	float CurrentFocusDistance; // 0x9F8(0x4)
	uint8_t Pad_0xA04[0x4]; // 0xA04(0x4)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xA08(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xA18(0x10)
	struct FString DefaultFilmbackPresetName; // 0xA28(0x10)
	struct FString DefaultLensPresetName; // 0xA38(0x10)
	float DefaultLensFocalLength; // 0xA48(0x4)
	float DefaultLensFStop; // 0xA4C(0x4)


	// Object: Function CinematicCamera.CineCameraComponent.SetLensPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc867c
	// Params: [ Num(1) Size(0x10) ]
	void SetLensPresetByName(struct FString InPresetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105DC6EE4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105dc85e4
	// Params: [ Num(1) Size(0x10) ]
	void SetFilmbackPresetByName(struct FString InPresetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105DC6D18
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105DC6EE4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc85b0
	// Params: [ Num(1) Size(0x4) ]
	float GetVerticalFieldOfView();
	// [Call #1] RVA: 0x105DC6C28
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105DC6D18
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105DC6EE4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function CinematicCamera.CineCameraComponent.GetLensPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc854c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLensPresetName();
	// [Call #1] RVA: 0x105DC6DCC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105DC6C28
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105DC6D18
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105DC6EE4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc8518
	// Params: [ Num(1) Size(0x4) ]
	float GetHorizontalFieldOfView();
	// [Call #1] RVA: 0x105DC6BE8
	// [Call #2] RVA: 0x105DC6DCC
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x105DC6C28
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105DC6D18
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105DC6EE4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C

	// Object: Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105dc84b4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFilmbackPresetName();
	// [Call #1] RVA: 0x105DC6C68
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x105DC6BE8
	// [Call #7] RVA: 0x105DC6DCC
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x105DC6C28
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105DC6D18
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x105DC6EE4
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
};

