#pragma once

#include <cstdint>

// Object: Enum GameplayTags.EGameplayTagQueryExprType
enum class EGameplayTagQueryExprType : uint8_t
{
	Undefined = 0,
	AnyTagsMatch = 1,
	AllTagsMatch = 2,
	NoTagsMatch = 3,
	AnyExprMatch = 4,
	AllExprMatch = 5,
	NoExprMatch = 6,
	EGameplayTagQueryExprType_MAX = 7
};

// Object: Enum GameplayTags.EGameplayContainerMatchType
enum class EGameplayContainerMatchType : uint8_t
{
	Any = 0,
	All = 1,
	EGameplayContainerMatchType_MAX = 2
};

// Object: Enum GameplayTags.EGameplayTagMatchType
enum class EGameplayTagMatchType : uint8_t
{
	Explicit = 0,
	IncludeParentTags = 1,
	EGameplayTagMatchType_MAX = 2
};

// Object: Enum GameplayTags.EGameplayTagSourceType
enum class EGameplayTagSourceType : uint8_t
{
	Native = 0,
	DefaultTagList = 1,
	TagList = 2,
	DataTable = 3,
	Invalid = 4,
	EGameplayTagSourceType_MAX = 5
};

// Object: ScriptStruct GameplayTags.GameplayTagContainer
// Size: 0x20 (Inherited: 0x0)
struct FGameplayTagContainer
{
	struct TArray<struct FGameplayTag> GameplayTags; // 0x0(0x10)
	struct TArray<struct FGameplayTag> ParentTags; // 0x10(0x10)
};

// Object: ScriptStruct GameplayTags.GameplayTag
// Size: 0x8 (Inherited: 0x0)
struct FGameplayTag
{
	struct FName TagName; // 0x0(0x8)
};

// Object: ScriptStruct GameplayTags.GameplayTagQuery
// Size: 0x48 (Inherited: 0x0)
struct FGameplayTagQuery
{
	int TokenStreamVersion; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct FGameplayTag> TagDictionary; // 0x8(0x10)
	struct TArray<uint8_t> QueryTokenStream; // 0x18(0x10)
	struct FString UserDescription; // 0x28(0x10)
	struct FString AutoDescription; // 0x38(0x10)
};

// Object: ScriptStruct GameplayTags.GameplayTagCreationWidgetHelper
// Size: 0x1 (Inherited: 0x0)
struct FGameplayTagCreationWidgetHelper
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct GameplayTags.GameplayTagReferenceHelper
// Size: 0x10 (Inherited: 0x0)
struct FGameplayTagReferenceHelper
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct GameplayTags.GameplayTagNode
// Size: 0x50 (Inherited: 0x0)
struct FGameplayTagNode
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct GameplayTags.GameplayTagSource
// Size: 0x18 (Inherited: 0x0)
struct FGameplayTagSource
{
	struct FName SourceName; // 0x0(0x8)
	uint8_t SourceType; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
	struct UGameplayTagsList* SourceTagList; // 0x10(0x8)
};

// Object: ScriptStruct GameplayTags.GameplayTagTableRow
// Size: 0x20 (Inherited: 0x8)
struct FGameplayTagTableRow : FTableRowBase
{
	struct FName Tag; // 0x8(0x8)
	struct FString DevComment; // 0x10(0x10)
};

// Object: ScriptStruct GameplayTags.GameplayTagCategoryRemap
// Size: 0x20 (Inherited: 0x0)
struct FGameplayTagCategoryRemap
{
	struct FString BaseCategory; // 0x0(0x10)
	struct TArray<struct FString> RemapCategories; // 0x10(0x10)
};

// Object: ScriptStruct GameplayTags.GameplayTagRedirect
// Size: 0x10 (Inherited: 0x0)
struct FGameplayTagRedirect
{
	struct FName OldTagName; // 0x0(0x8)
	struct FName NewTagName; // 0x8(0x8)
};

// Object: Class GameplayTags.BlueprintGameplayTagLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintGameplayTagLibrary : UBlueprintFunctionLibrary
{

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.RemoveGameplayTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e4c9b4
	// Params: [ Num(3) Size(0x29) ]
	bool RemoveGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E4090C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190648
	// [Call #11] RVA: 0x105190648
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c890
	// Params: [ Num(3) Size(0x19) ]
	bool NotEqual_TagTag(struct FGameplayTag A, struct FString B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x105E4095C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E4090C
	// [Call #19] RVA: 0x1020C4E8C
	// [Call #20] RVA: 0x1020C4E8C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10519022C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagContainerTagContainer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c738
	// Params: [ Num(3) Size(0x31) ]
	bool NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020C5138
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x105E409E0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F8122C
	// [Call #24] RVA: 0x105E4095C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c618
	// Params: [ Num(3) Size(0x41) ]
	bool NotEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E40560
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020C5138
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x105E409E0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x1020C4E8C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x1020C4E8C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x100036FE0

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c564
	// Params: [ Num(3) Size(0x11) ]
	bool NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E3FFEC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E40560
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MatchesTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c46c
	// Params: [ Num(4) Size(0x12) ]
	bool MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E3FD74
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E3FFEC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MatchesAnyTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c330
	// Params: [ Num(4) Size(0x2A) ]
	bool MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E3FE90
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x105E3FD74

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTagContainer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c248
	// Params: [ Num(2) Size(0x40) ]
	struct FGameplayTagContainer MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x105E4057C
	// [Call #5] RVA: 0x105E421EC
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105E3FE90
	// [Call #20] RVA: 0x1020C4E8C
	// [Call #21] RVA: 0x1020C4E8C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c1cc
	// Params: [ Num(2) Size(0x10) ]
	struct FGameplayTag MakeLiteralGameplayTag(struct FGameplayTag Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E4000C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C5138
	// [Call #7] RVA: 0x105E4057C
	// [Call #8] RVA: 0x105E421EC
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c0dc
	// Params: [ Num(2) Size(0x90) ]
	struct FGameplayTagQuery MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery);
	// [Call #1] RVA: 0x105E41A18
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x105E43F54
	// [Call #5] RVA: 0x105E405C4
	// [Call #6] RVA: 0x105E43FC8
	// [Call #7] RVA: 0x1020C4EB4
	// [Call #8] RVA: 0x1020C4EB4
	// [Call #9] RVA: 0x1020C4EB4
	// [Call #10] RVA: 0x1020C4EB4
	// [Call #11] RVA: 0x1020C4EB4
	// [Call #12] RVA: 0x1020C4EB4
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E4000C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1020C5138
	// [Call #20] RVA: 0x105E4057C
	// [Call #21] RVA: 0x105E421EC
	// [Call #22] RVA: 0x1020C4E8C
	// [Call #23] RVA: 0x1020C4E8C
	// [Call #24] RVA: 0x1020C4E8C
	// [Call #25] RVA: 0x1020C4E8C
	// [Call #26] RVA: 0x1020C4E8C
	// [Call #27] RVA: 0x1020C4E8C
	// [Call #28] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4c038
	// Params: [ Num(2) Size(0x28) ]
	struct FGameplayTagContainer MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E4058C
	// [Call #4] RVA: 0x105E421EC
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x105E41A18
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E43F54
	// [Call #12] RVA: 0x105E405C4
	// [Call #13] RVA: 0x105E43FC8
	// [Call #14] RVA: 0x1020C4EB4
	// [Call #15] RVA: 0x1020C4EB4
	// [Call #16] RVA: 0x1020C4EB4
	// [Call #17] RVA: 0x1020C4EB4
	// [Call #18] RVA: 0x1020C4EB4
	// [Call #19] RVA: 0x1020C4EB4
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x105E4000C
	// [Call #24] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4bf68
	// Params: [ Num(2) Size(0x30) ]
	struct FGameplayTagContainer MakeGameplayTagContainerFromArray(struct TArray<struct FGameplayTag>& GameplayTags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E40588
	// [Call #4] RVA: 0x105E421EC
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E3C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E3C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E4058C
	// [Call #13] RVA: 0x105E421EC
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x105E41A18
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x105E43F54
	// [Call #21] RVA: 0x105E405C4
	// [Call #22] RVA: 0x105E43FC8
	// [Call #23] RVA: 0x1020C4EB4
	// [Call #24] RVA: 0x1020C4EB4
	// [Call #25] RVA: 0x1020C4EB4
	// [Call #26] RVA: 0x1020C4EB4
	// [Call #27] RVA: 0x1020C4EB4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.IsGameplayTagValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4beec
	// Params: [ Num(2) Size(0x9) ]
	bool IsGameplayTagValid(struct FGameplayTag GameplayTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E3FFF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E40588
	// [Call #7] RVA: 0x105E421EC
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E3C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E3C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E4058C
	// [Call #16] RVA: 0x105E421EC
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x105E41A18
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4bdac
	// Params: [ Num(4) Size(0x2A) ]
	bool HasTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E40018
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E3FFF8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E40588
	// [Call #17] RVA: 0x105E421EC
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x1020C4E3C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAnyTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4bc40
	// Params: [ Num(4) Size(0x42) ]
	bool HasAnyTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E40080
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAllTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4bad4
	// Params: [ Num(4) Size(0x42) ]
	bool HasAllTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E4012C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAllMatchingGameplayTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b9dc
	// Params: [ Num(3) Size(0x31) ]
	bool HasAllMatchingGameplayTags(struct TScriptInterface<Class> TagContainerInterface, struct FGameplayTagContainer& OtherContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E405D0
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E4012C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x1020C4E8C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetTagName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b950
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetTagName(struct FGameplayTag& GameplayTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E40004
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x105E405D0
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetNumGameplayTagsInContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b8a4
	// Params: [ Num(2) Size(0x24) ]
	int GetNumGameplayTagsInContainer(struct FGameplayTagContainer& TagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E40010
	// [Call #4] RVA: 0x1020C4E8C
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E40004
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105E405D0
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b7d0
	// Params: [ Num(2) Size(0x30) ]
	struct FString GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer& TagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E4155C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105E40010
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E40004
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b72c
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E417D0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E4155C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x105E40010
	// [Call #20] RVA: 0x1020C4E8C
	// [Call #21] RVA: 0x1020C4E8C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetAllActorsOfClassMatchingTagQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e4b5ac
	// Params: [ Num(4) Size(0x68) ]
	void GetAllActorsOfClassMatchingTagQuery(struct UObject* WorldContextObject, struct AActor* ActorClass, struct FGameplayTagQuery& GameplayTagQuery, struct TArray<struct AActor*>& OutActors);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E41A18
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E40210
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x1020C4EB4
	// [Call #13] RVA: 0x101F811FC
	// [Call #14] RVA: 0x1020C4EB4
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x105E417D0
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b48c
	// Params: [ Num(3) Size(0x41) ]
	bool EqualEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E404FC
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E41A18
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b3d8
	// Params: [ Num(3) Size(0x11) ]
	bool EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E3FFE0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E404FC
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x1020C4E8C
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.DoesTagAssetInterfaceHaveTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b310
	// Params: [ Num(3) Size(0x19) ]
	bool DoesTagAssetInterfaceHaveTag(struct TScriptInterface<Class> TagContainerInterface, struct FGameplayTag Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E406A8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105E3FFE0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E404FC

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.DoesContainerMatchTagQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b1ec
	// Params: [ Num(3) Size(0x69) ]
	bool DoesContainerMatchTagQuery(struct FGameplayTagContainer& TagContainer, struct FGameplayTagQuery& TagQuery);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E41A18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105E401D8
	// [Call #7] RVA: 0x1020C4EB4
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4EB4
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E406A8
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.BreakGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105e4b0e0
	// Params: [ Num(2) Size(0x30) ]
	void BreakGameplayTagContainer(struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct FGameplayTag>& GameplayTags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E405B4
	// [Call #6] RVA: 0x1020C4E3C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E3C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E41A18
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E401D8
	// [Call #17] RVA: 0x1020C4EB4
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x1020C4EB4
	// [Call #20] RVA: 0x1020C4E8C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.AppendGameplayTagContainers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e4afd0
	// Params: [ Num(2) Size(0x40) ]
	void AppendGameplayTagContainers(struct FGameplayTagContainer& InOutTagContainer, struct FGameplayTagContainer& InTagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E40750
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E405B4
	// [Call #16] RVA: 0x1020C4E3C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x1020C4E3C
	// [Call #19] RVA: 0x1020C4E8C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.AddGameplayTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e4aee8
	// Params: [ Num(2) Size(0x28) ]
	void AddGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105E40804
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105E40750
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x1020C4E8C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class GameplayTags.GameplayTagAssetInterface
// Size: 0x28 (Inherited: 0x28)
struct IGameplayTagAssetInterface : IInterface
{

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasMatchingGameplayTag
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e4d7c8
	// Params: [ Num(2) Size(0x9) ]
	bool HasMatchingGameplayTag(struct FGameplayTag TagToCheck);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasAnyMatchingGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e4d704
	// Params: [ Num(2) Size(0x21) ]
	bool HasAnyMatchingGameplayTags(struct FGameplayTagContainer& TagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C4E8C
	// [Call #4] RVA: 0x1020C4E8C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasAllMatchingGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e4d640
	// Params: [ Num(2) Size(0x21) ]
	bool HasAllMatchingGameplayTags(struct FGameplayTagContainer& TagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C4E8C
	// [Call #4] RVA: 0x1020C4E8C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10519022C

	// Object: Function GameplayTags.GameplayTagAssetInterface.GetOwnedGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e4d58c
	// Params: [ Num(1) Size(0x20) ]
	void GetOwnedGameplayTags(struct FGameplayTagContainer& TagContainer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C4E8C
	// [Call #4] RVA: 0x1020C4E8C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x106C8459C
};

// Object: Class GameplayTags.EditableGameplayTagQuery
// Size: 0x98 (Inherited: 0x28)
struct UEditableGameplayTagQuery : UObject
{
	struct FString UserDescription; // 0x28(0x10)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
	struct UEditableGameplayTagQueryExpression* RootExpression; // 0x48(0x8)
	struct FGameplayTagQuery TagQueryExportText_Helper; // 0x50(0x48)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression
// Size: 0x28 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression : UObject
{
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AnyTagsMatch
// Size: 0x48 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_AnyTagsMatch : UEditableGameplayTagQueryExpression
{
	struct FGameplayTagContainer Tags; // 0x28(0x20)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AllTagsMatch
// Size: 0x48 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_AllTagsMatch : UEditableGameplayTagQueryExpression
{
	struct FGameplayTagContainer Tags; // 0x28(0x20)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_NoTagsMatch
// Size: 0x48 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_NoTagsMatch : UEditableGameplayTagQueryExpression
{
	struct FGameplayTagContainer Tags; // 0x28(0x20)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AnyExprMatch
// Size: 0x38 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_AnyExprMatch : UEditableGameplayTagQueryExpression
{
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x28(0x10)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AllExprMatch
// Size: 0x38 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_AllExprMatch : UEditableGameplayTagQueryExpression
{
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x28(0x10)
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_NoExprMatch
// Size: 0x38 (Inherited: 0x28)
struct UEditableGameplayTagQueryExpression_NoExprMatch : UEditableGameplayTagQueryExpression
{
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // 0x28(0x10)
};

// Object: Class GameplayTags.GameplayTagsManager
// Size: 0x180 (Inherited: 0x28)
struct UGameplayTagsManager : UObject
{
	uint8_t Pad_0x28[0x80]; // 0x28(0x80)
	struct TArray<struct FGameplayTagSource> TagSources; // 0xA8(0x10)
	uint8_t Pad_0xB8[0x68]; // 0xB8(0x68)
	struct TArray<struct UDataTable*> GameplayTagTables; // 0x120(0x10)
	uint8_t Pad_0x130[0x50]; // 0x130(0x50)
};

// Object: Class GameplayTags.GameplayTagsList
// Size: 0x48 (Inherited: 0x28)
struct UGameplayTagsList : UObject
{
	struct FString ConfigFileName; // 0x28(0x10)
	struct TArray<struct FGameplayTagTableRow> GameplayTagList; // 0x38(0x10)
};

// Object: Class GameplayTags.GameplayTagsSettings
// Size: 0xA0 (Inherited: 0x48)
struct UGameplayTagsSettings : UGameplayTagsList
{
	bool ImportTagsFromConfig; // 0x48(0x1)
	bool WarnOnInvalidTags; // 0x49(0x1)
	uint8_t Pad_0x4A[0x6]; // 0x4A(0x6)
	struct TArray<struct FGameplayTagCategoryRemap> CategoryRemapping; // 0x50(0x10)
	bool FastReplication; // 0x60(0x1)
	uint8_t Pad_0x61[0x7]; // 0x61(0x7)
	struct TArray<struct FSoftObjectPath> GameplayTagTableList; // 0x68(0x10)
	struct TArray<struct FGameplayTagRedirect> GameplayTagRedirects; // 0x78(0x10)
	struct TArray<struct FName> CommonlyReplicatedTags; // 0x88(0x10)
	int NumBitsForContainerSize; // 0x98(0x4)
	int NetIndexFirstBitSegment; // 0x9C(0x4)
};

// Object: Class GameplayTags.GameplayTagsDeveloperSettings
// Size: 0x38 (Inherited: 0x28)
struct UGameplayTagsDeveloperSettings : UObject
{
	struct FString DeveloperConfigName; // 0x28(0x10)
};

