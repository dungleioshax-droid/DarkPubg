#pragma once

#include <cstdint>

// Object: Enum GameplayTasks.ETaskResourceOverlapPolicy
enum class ETaskResourceOverlapPolicy : uint8_t
{
	StartOnTop = 0,
	StartAtEnd = 1,
	ETaskResourceOverlapPolicy_MAX = 2
};

// Object: Enum GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8_t
{
	Error = 0,
	Failed = 1,
	Success_Paused = 2,
	Success_Active = 3,
	Success_Finished = 4,
	EGameplayTaskRunResult_MAX = 5
};

// Object: Enum GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8_t
{
	Uninitialized = 0,
	AwaitingActivation = 1,
	Paused = 2,
	Active = 3,
	Finished = 4,
	EGameplayTaskState_MAX = 5
};

// Object: ScriptStruct GameplayTasks.GameplayResourceSet
// Size: 0x2 (Inherited: 0x0)
struct FGameplayResourceSet
{
	uint8_t Pad_0x0[0x2]; // 0x0(0x2)
};

// Object: Class GameplayTasks.GameplayTasksComponent
// Size: 0x1F0 (Inherited: 0x178)
struct UGameplayTasksComponent : UActorComponent
{
	uint8_t Pad_0x178[0x8]; // 0x178(0x8)
	struct TArray<struct UGameplayTask*> SimulatedTasks; // 0x180(0x10)
	struct TArray<struct UGameplayTask*> TaskPriorityQueue; // 0x190(0x10)
	uint8_t Pad_0x1A0[0x10]; // 0x1A0(0x10)
	struct TArray<struct UGameplayTask*> TickingTasks; // 0x1B0(0x10)
	struct TArray<struct UGameplayTask*> KnownTasks; // 0x1C0(0x10)
	uint8_t Pad_0x1D0[0x8]; // 0x1D0(0x8)
	struct FScriptMulticastDelegate OnClaimedResourcesChange; // 0x1D8(0x10)
	uint8_t Pad_0x1E8[0x8]; // 0x1E8(0x8)


	// Object: Function GameplayTasks.GameplayTasksComponent.OnRep_SimulatedTasks
	// Flags: [Final|Native|Public]
	// Offset: 0x105e569f8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SimulatedTasks();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10518366C
	// [Call #6] RVA: 0x104FD0740
	// [Call #7] RVA: 0x1036A6C08
	// [Call #8] RVA: 0x105093FD0

	// Object: Function GameplayTasks.GameplayTasksComponent.K2_RunGameplayTask
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105e567a8
	// Params: [ Num(6) Size(0x41) ]
	uint8_t K2_RunGameplayTask(struct TScriptInterface<Class> TaskOwner, struct UGameplayTask* Task, uint8_t Priority, struct TArray<struct UGameplayTaskResource*> AdditionalRequiredResources, struct TArray<struct UGameplayTaskResource*> AdditionalClaimedResources);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E56D44
	// [Call #12] RVA: 0x105E56D44
	// [Call #13] RVA: 0x105E53054
	// [Call #14] RVA: 0x105E56E24
	// [Call #15] RVA: 0x105E56E24
	// [Call #16] RVA: 0x105E56E24
	// [Call #17] RVA: 0x105E56E24
	// [Call #18] RVA: 0x105E56E24
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x105E56E24
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x105E56E24
	// [Call #25] RVA: 0x105E56E24
	// [Call #26] RVA: 0x106C8459C
};

// Object: Class GameplayTasks.GameplayTask
// Size: 0x60 (Inherited: 0x28)
struct UGameplayTask : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FName InstanceName; // 0x30(0x8)
	uint8_t Pad_0x38[0x2]; // 0x38(0x2)
	uint8_t ResourceOverlapPolicy; // 0x3A(0x1)
	uint8_t Pad_0x3B[0x1D]; // 0x3B(0x1D)
	struct UGameplayTask* ChildTask; // 0x58(0x8)


	// Object: Function GameplayTasks.GameplayTask.ReadyForActivation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e55554
	// Params: [ Num(0) Size(0x0) ]
	void ReadyForActivation();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105E55A90
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: DelegateFunction GameplayTasks.GameplayTask.GenericGameplayTaskDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void GenericGameplayTaskDelegate__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GameplayTasks.GameplayTask.EndTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e55540
	// Params: [ Num(0) Size(0x0) ]
	void EndTask();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105E55A90
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class GameplayTasks.GameplayTask_ClaimResource
// Size: 0x60 (Inherited: 0x60)
struct UGameplayTask_ClaimResource : UGameplayTask
{

	// Object: Function GameplayTasks.GameplayTask_ClaimResource.ClaimResources
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105e5580c
	// Params: [ Num(5) Size(0x38) ]
	struct UGameplayTask_ClaimResource* ClaimResources(struct TScriptInterface<Class> InTaskOwner, struct TArray<struct UGameplayTaskResource*> ResourceClasses, uint8_t Priority, struct FName TaskInstanceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E56D44
	// [Call #10] RVA: 0x105E536D4
	// [Call #11] RVA: 0x105E56E24
	// [Call #12] RVA: 0x105E56E24
	// [Call #13] RVA: 0x105E56E24
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x105E56E24
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function GameplayTasks.GameplayTask_ClaimResource.ClaimResource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105e556cc
	// Params: [ Num(5) Size(0x30) ]
	struct UGameplayTask_ClaimResource* ClaimResource(struct TScriptInterface<Class> InTaskOwner, struct UGameplayTaskResource* ResourceClass, uint8_t Priority, struct FName TaskInstanceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105E5362C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
};

// Object: Class GameplayTasks.GameplayTask_SpawnActor
// Size: 0xA0 (Inherited: 0x60)
struct UGameplayTask_SpawnActor : UGameplayTask
{
	struct FScriptMulticastDelegate Success; // 0x60(0x10)
	struct FScriptMulticastDelegate DidNotSpawn; // 0x70(0x10)
	uint8_t Pad_0x80[0x18]; // 0x80(0x18)
	struct AActor* ClassToSpawn; // 0x98(0x8)


	// Object: Function GameplayTasks.GameplayTask_SpawnActor.SpawnActor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105e55d4c
	// Params: [ Num(6) Size(0x40) ]
	struct UGameplayTask_SpawnActor* SpawnActor(struct TScriptInterface<Class> TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct AActor* Class, bool bSpawnOnlyOnAuthority);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E53784
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function GameplayTasks.GameplayTask_SpawnActor.FinishSpawningActor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105e55c90
	// Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105E53784

	// Object: Function GameplayTasks.GameplayTask_SpawnActor.BeginSpawningActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e55bb0
	// Params: [ Num(3) Size(0x11) ]
	bool BeginSpawningActor(struct UObject* WorldContextObject, struct AActor*& SpawnedActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class GameplayTasks.GameplayTask_TimeLimitedExecution
// Size: 0x90 (Inherited: 0x60)
struct UGameplayTask_TimeLimitedExecution : UGameplayTask
{
	struct FScriptMulticastDelegate OnFinished; // 0x60(0x10)
	struct FScriptMulticastDelegate OnTimeExpired; // 0x70(0x10)
	uint8_t Pad_0x80[0x10]; // 0x80(0x10)
};

// Object: Class GameplayTasks.GameplayTask_WaitDelay
// Size: 0x78 (Inherited: 0x60)
struct UGameplayTask_WaitDelay : UGameplayTask
{
	struct FScriptMulticastDelegate OnFinish; // 0x60(0x10)
	uint8_t Pad_0x70[0x8]; // 0x70(0x8)


	// Object: Function GameplayTasks.GameplayTask_WaitDelay.TaskWaitDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105e562a8
	// Params: [ Num(4) Size(0x20) ]
	struct UGameplayTask_WaitDelay* TaskWaitDelay(struct TScriptInterface<Class> TaskOwner, float Time, uint8_t Priority);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x105E53DC8
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x105190870

	// Object: DelegateFunction GameplayTasks.GameplayTask_WaitDelay.TaskDelayDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void TaskDelayDelegate__DelegateSignature();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class GameplayTasks.GameplayTaskOwnerInterface
// Size: 0x28 (Inherited: 0x28)
struct IGameplayTaskOwnerInterface : IInterface
{
};

// Object: Class GameplayTasks.GameplayTaskResource
// Size: 0x30 (Inherited: 0x28)
struct UGameplayTaskResource : UObject
{
	int ManualResourceID; // 0x28(0x4)
	uint8_t AutoResourceID; // 0x2C(0x1)
	uint8_t bManuallySetID : 1; // 0x2D(0x1), Mask(0x1)
	uint8_t BitPad_0x2D_1 : 7; // 0x2D(0x1)
	uint8_t Pad_0x2E[0x2]; // 0x2E(0x2)
};

