#pragma once

#include <cstdint>

// Object: ScriptStruct LevelSequence.BoundActorProxy
// Size: 0x1 (Inherited: 0x0)
struct FBoundActorProxy
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReferences
// Size: 0x50 (Inherited: 0x0)
struct FLevelSequenceBindingReferences
{
	struct TMap<struct FGuid, struct FLevelSequenceBindingReferenceArray> BindingIdToReferences; // 0x0(0x50)
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReferenceArray
// Size: 0x10 (Inherited: 0x0)
struct FLevelSequenceBindingReferenceArray
{
	struct TArray<struct FLevelSequenceBindingReference> References; // 0x0(0x10)
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReference
// Size: 0x38 (Inherited: 0x0)
struct FLevelSequenceBindingReference
{
	struct FString PackageName; // 0x0(0x10)
	struct FSoftObjectPath ExternalObjectPath; // 0x10(0x18)
	struct FString ObjectPath; // 0x28(0x10)
};

// Object: ScriptStruct LevelSequence.LevelSequenceObjectReferenceMap
// Size: 0x50 (Inherited: 0x0)
struct FLevelSequenceObjectReferenceMap
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct LevelSequence.LevelSequenceLegacyObjectReference
// Size: 0x20 (Inherited: 0x0)
struct FLevelSequenceLegacyObjectReference
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: ScriptStruct LevelSequence.LevelSequenceObject
// Size: 0x38 (Inherited: 0x0)
struct FLevelSequenceObject
{
	struct TLazyObjectPtr<struct UObject> ObjectOrOwner; // 0x0(0x1C)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString ComponentName; // 0x20(0x10)
	struct TWeakObjectPtr<struct UObject> CachedComponent; // 0x30(0x8)
};

// Object: ScriptStruct LevelSequence.LevelSequencePlayerSnapshot
// Size: 0x58 (Inherited: 0x0)
struct FLevelSequencePlayerSnapshot
{
	struct FText MasterName; // 0x0(0x18)
	float MasterTime; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FText CurrentShotName; // 0x20(0x18)
	float CurrentShotLocalTime; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct UCameraComponent* CameraComponent; // 0x40(0x8)
	struct FLevelSequenceSnapshotSettings Settings; // 0x48(0x8)
	struct FMovieSceneSequenceID ShotID; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
};

// Object: ScriptStruct LevelSequence.LevelSequenceSnapshotSettings
// Size: 0x8 (Inherited: 0x0)
struct FLevelSequenceSnapshotSettings
{
	uint8_t ZeroPadAmount; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float FrameRate; // 0x4(0x4)
};

// Object: Class LevelSequence.LevelSequenceActor
// Size: 0x550 (Inherited: 0x4B0)
struct ALevelSequenceActor : AActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	bool bAutoPlay; // 0x4B8(0x1)
	uint8_t Pad_0x4B9[0x7]; // 0x4B9(0x7)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x4C0(0x28)
	struct ULevelSequencePlayer* SequencePlayer; // 0x4E8(0x8)
	struct FSoftObjectPath LevelSequence; // 0x4F0(0x18)
	struct TArray<struct AActor*> AdditionalEventReceivers; // 0x508(0x10)
	struct ULevelSequenceBurnInOptions* BurnInOptions; // 0x518(0x8)
	struct UMovieSceneBindingOverrides* BindingOverrides; // 0x520(0x8)
	bool bReduceFrequency; // 0x528(0x1)
	uint8_t Pad_0x529[0x3]; // 0x529(0x3)
	int ReduceFrameCount; // 0x52C(0x4)
	float IgnoreFrameTolerance; // 0x530(0x4)
	uint8_t bOverrideInstanceData : 1; // 0x534(0x1), Mask(0x1)
	uint8_t BitPad_0x534_1 : 7; // 0x534(0x1)
	uint8_t Pad_0x535[0x3]; // 0x535(0x3)
	struct UObject* DefaultInstanceData; // 0x538(0x8)
	bool bForceAsync; // 0x540(0x1)
	uint8_t Pad_0x541[0x7]; // 0x541(0x7)
	struct ULevelSequenceBurnIn* BurnInInstance; // 0x548(0x8)


	// Object: Function LevelSequence.LevelSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae7f4
	// Params: [ Num(1) Size(0x8) ]
	void SetSequence(struct ULevelSequence* InSequence);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA50F4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequenceActor.SetEventReceivers
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae710
	// Params: [ Num(1) Size(0x10) ]
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101FD9CA0
	// [Call #4] RVA: 0x105FA517C
	// [Call #5] RVA: 0x101F811FC
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x105FA50F4
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequenceActor.SetBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105fae5b4
	// Params: [ Num(3) Size(0x29) ]
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B5910
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9CA0
	// [Call #14] RVA: 0x105FA517C
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F811FC
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F811FC
	// [Call #21] RVA: 0x106C8459C

	// Object: Function LevelSequence.LevelSequenceActor.SetAllMovieSceneSectionsToKeepState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae5a0
	// Params: [ Num(0) Size(0x0) ]
	void SetAllMovieSceneSectionsToKeepState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B5910
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9CA0
	// [Call #14] RVA: 0x105FA517C
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F811FC
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F811FC
	// [Call #21] RVA: 0x106C8459C

	// Object: Function LevelSequence.LevelSequenceActor.ResetBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae58c
	// Params: [ Num(0) Size(0x0) ]
	void ResetBindings();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B5910
	// [Call #8] RVA: 0x101F811FC
	// [Call #9] RVA: 0x101F811FC
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9CA0
	// [Call #14] RVA: 0x105FA517C
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F811FC
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0

	// Object: Function LevelSequence.LevelSequenceActor.ResetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae4ec
	// Params: [ Num(1) Size(0x18) ]
	void ResetBinding(struct FMovieSceneObjectBindingID Binding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045B5CC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045B5910
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x101F811FC
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function LevelSequence.LevelSequenceActor.RemoveBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae410
	// Params: [ Num(2) Size(0x20) ]
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045B5B20
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045B5CC4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function LevelSequence.LevelSequenceActor.ReceiveInitailizePlayer
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveInitailizePlayer();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LevelSequence.LevelSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105fae338
	// Params: [ Num(3) Size(0x10) ]
	struct ULevelSequence* GetSequence(bool bLoad, bool bInitializePlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105FA4F5C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1045B5B20
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045B5CC4

	// Object: Function LevelSequence.LevelSequenceActor.GetPossessableByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae27c
	// Params: [ Num(2) Size(0x28) ]
	struct FMovieSceneObjectBindingID GetPossessableByName(struct FString NameKeyString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA5278
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105FA4F5C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function LevelSequence.LevelSequenceActor.AddBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105fae15c
	// Params: [ Num(3) Size(0x21) ]
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045B3FC8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105FA5278
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
};

// Object: Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0x70 (Inherited: 0x28)
struct UDefaultLevelSequenceInstanceData : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct AActor* TransformOriginActor; // 0x30(0x8)
	uint8_t Pad_0x38[0x8]; // 0x38(0x8)
	struct FTransform TransformOrigin; // 0x40(0x30)
};

// Object: Class LevelSequence.LevelSequence
// Size: 0x3E0 (Inherited: 0x2E8)
struct ULevelSequence : UMovieSceneSequence
{
	struct UMovieScene* MovieScene; // 0x2E8(0x8)
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // 0x2F0(0x50)
	struct FLevelSequenceBindingReferences BindingReferences; // 0x340(0x50)
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // 0x390(0x50)
};

// Object: Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x28 (Inherited: 0x28)
struct ULevelSequenceBurnInInitSettings : UObject
{
};

// Object: Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x50 (Inherited: 0x28)
struct ULevelSequenceBurnInOptions : UObject
{
	bool bUseBurnIn; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FSoftClassPath BurnInClass; // 0x30(0x18)
	struct ULevelSequenceBurnInInitSettings* Settings; // 0x48(0x8)
};

// Object: Class LevelSequence.LevelSequenceBurnIn
// Size: 0x2C0 (Inherited: 0x260)
struct ULevelSequenceBurnIn : UUserWidget
{
	struct FLevelSequencePlayerSnapshot FrameInformation; // 0x260(0x58)
	struct ALevelSequenceActor* LevelSequenceActor; // 0x2B8(0x8)


	// Object: Function LevelSequence.LevelSequenceBurnIn.SetSettings
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetSettings(struct UObject* InSettings);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x105faef8c
	// Params: [ Num(1) Size(0x8) ]
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190648
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105FADAF4
	// [Call #7] RVA: 0x105184F34
	// [Call #8] RVA: 0x1036A6C08
};

// Object: Class LevelSequence.LevelSequencePlayer
// Size: 0x8B0 (Inherited: 0x7B8)
struct ULevelSequencePlayer : UMovieSceneSequencePlayer
{
	struct FScriptMulticastDelegate OnCameraCut; // 0x7B8(0x10)
	struct FScriptMulticastDelegate OnTrackEvent; // 0x7C8(0x10)
	uint8_t Pad_0x7D8[0x30]; // 0x7D8(0x30)
	struct TArray<struct UObject*> AdditionalEventReceivers; // 0x808(0x10)
	uint8_t Pad_0x818[0x98]; // 0x818(0x98)


	// Object: Function LevelSequence.LevelSequencePlayer.SetCanUpdateCameraCut
	// Flags: [Final|Native|Public]
	// Offset: 0x105faf6b8
	// Params: [ Num(1) Size(0x1) ]
	void SetCanUpdateCameraCut(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA828C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequencePlayer.IsActorBoundToSequence
	// Flags: [Final|Native|Protected|Const]
	// Offset: 0x105faf62c
	// Params: [ Num(2) Size(0x9) ]
	bool IsActorBoundToSequence(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA8B9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105FA828C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequencePlayer.EnablePrimitiveComponentTracking
	// Flags: [Final|Native|Public]
	// Offset: 0x105faf618
	// Params: [ Num(0) Size(0x0) ]
	void EnablePrimitiveComponentTracking();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA8B9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105FA828C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequencePlayer.DisablePrimitiveComponentTracking
	// Flags: [Final|Native|Public]
	// Offset: 0x105faf604
	// Params: [ Num(0) Size(0x0) ]
	void DisablePrimitiveComponentTracking();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105FA8B9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x105FA828C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105faf494
	// Params: [ Num(5) Size(0x48) ]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x105FA7750
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x105FA8B9C
	// [Call #13] RVA: 0x10516D168
};

