#pragma once

#include <cstdint>

// Object: Enum AIGCKit.EAIGCAnimVersion
enum class EAIGCAnimVersion : uint8_t
{
	EAIGCAnimVersion_InValid = 0,
	EAIGCAnimVersion_UnCompress = 1,
	EAIGCAnimVersion_Compress = 2,
	EAIGCAnimVersion_MAX = 3
};

// Object: ScriptStruct AIGCKit.AIBonesTransfroms
// Size: 0x90 (Inherited: 0x0)
struct FAIBonesTransfroms
{
	struct TArray<struct FName> BonesName; // 0x0(0x10)
	struct TArray<struct FVector> BonesTranslation; // 0x10(0x10)
	struct TArray<struct FVector> BonesScale; // 0x20(0x10)
	struct TArray<struct FRotator> BonesRotation; // 0x30(0x10)
	struct TMap<struct FName, int> BonesIdxs; // 0x40(0x50)
};

// Object: ScriptStruct AIGCKit.SkeletonNodeInfo
// Size: 0x60 (Inherited: 0x0)
struct FSkeletonNodeInfo
{
	struct TArray<struct FName> SkeletonNodes; // 0x0(0x10)
	struct FSkeletonAnimCompressInfo CompressInfo; // 0x10(0x50)
};

// Object: ScriptStruct AIGCKit.SkeletonAnimCompressInfo
// Size: 0x50 (Inherited: 0x0)
struct FSkeletonAnimCompressInfo
{
	struct TMap<struct FName, int> NodeToTrackMap; // 0x0(0x50)
};

// Object: ScriptStruct AIGCKit.SkeletonModifyRule
// Size: 0x6 (Inherited: 0x0)
struct FSkeletonModifyRule
{
	enum class EBoneModificationMode TranslationMode; // 0x0(0x1)
	enum class EBoneModificationMode RotationMode; // 0x1(0x1)
	enum class EBoneModificationMode ScaleMode; // 0x2(0x1)
	enum class EBoneControlSpace TranslationSpace; // 0x3(0x1)
	enum class EBoneControlSpace RotationSpace; // 0x4(0x1)
	enum class EBoneControlSpace ScaleSpace; // 0x5(0x1)
};

// Object: Class AIGCKit.AIGCAnimData
// Size: 0x48 (Inherited: 0x28)
struct UAIGCAnimData : UObject
{
	struct TArray<struct FAIBonesTransfroms> BonesTransfroms; // 0x28(0x10)
	int FrameRate; // 0x38(0x4)
	bool bUseCustomSpace; // 0x3C(0x1)
	struct FSkeletonModifyRule CustomRule; // 0x3D(0x6)
	uint8_t Pad_0x43[0x5]; // 0x43(0x5)
};

// Object: Class AIGCKit.AIGCAnimInstance
// Size: 0x420 (Inherited: 0x3F0)
struct UAIGCAnimInstance : UAnimInstance
{
	struct TArray<struct FAIBonesTransfroms> BonesTransfroms; // 0x3E8(0x10)
	bool bUseAIGCAnimation; // 0x3F8(0x1)
	float CurrentAIGCAnimFrameIndex; // 0x3FC(0x4)
	enum class EBoneModificationMode TranslationMode; // 0x400(0x1)
	enum class EBoneModificationMode RotationMode; // 0x401(0x1)
	enum class EBoneModificationMode ScaleMode; // 0x402(0x1)
	enum class EBoneControlSpace TranslationSpace; // 0x403(0x1)
	enum class EBoneControlSpace RotationSpace; // 0x404(0x1)
	enum class EBoneControlSpace ScaleSpace; // 0x405(0x1)
	float AIGCAnimFrameRate; // 0x408(0x4)
	struct FSkeletonModifyRule DefaultSkeletonModifyRule; // 0x40C(0x6)
	uint8_t Pad_0x415[0xB]; // 0x415(0xB)


	// Object: Function AIGCKit.AIGCAnimInstance.GetCurrentFrameIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10272cce0
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentFrameIndex();
	// [Call #1] RVA: 0x10272A6DC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10272D53C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class AIGCKit.AIGCKitFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAIGCKitFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AIGCKit.AIGCKitFunctionLibrary.GetAnimData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10272d234
	// Params: [ Num(5) Size(0x80) ]
	struct UAIGCAnimData* GetAnimData(struct TArray<uint8_t>& CompressData, int FrameRate, int FrameNum, struct FSkeletonNodeInfo& SkeletonNodeInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10272ACE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10272A700
	// [Call #11] RVA: 0x10272AE84
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x10272AE84
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190648

	// Object: Function AIGCKit.AIGCKitFunctionLibrary.DecompressBone
	// Flags: [Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10272d060
	// Params: [ Num(6) Size(0x59) ]
	bool DecompressBone(int TrackIndex, struct FTransform& OutAtom, struct TArray<uint8_t>& RawAnimData, float Time, float RelativePos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10272AB38
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AIGCKit.AIGCKitFunctionLibrary.DecompressAnimData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10272ce84
	// Params: [ Num(6) Size(0x81) ]
	bool DecompressAnimData(struct UAIGCAnimData* OutAnimData, struct TArray<uint8_t>& RawAnimData, int FrameNum, float TargetFramerate, struct FSkeletonNodeInfo& SkeletonNodeInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10272ACE4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10272A7D4
	// [Call #13] RVA: 0x10272AE84
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x10272AE84
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
};

// Object: Class AIGCKit.AIGCKitSettings
// Size: 0xD8 (Inherited: 0x28)
struct UAIGCKitSettings : UObject
{
	struct TMap<struct FString, struct FSkeletonNodeInfo> FaceSkeletons; // 0x28(0x50)
	struct TMap<struct FString, struct FSkeletonNodeInfo> BodySkeletons; // 0x78(0x50)
	struct FSkeletonModifyRule DefaultFaceRule; // 0xC8(0x6)
	struct FSkeletonModifyRule DefaultBodyRule; // 0xCE(0x6)
	uint8_t Pad_0xD4[0x4]; // 0xD4(0x4)
};

