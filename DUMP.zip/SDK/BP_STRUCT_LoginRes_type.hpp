#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LoginRes_type.BP_STRUCT_LoginRes_type
// Size: 0x78 (Inherited: 0x0)
struct FBP_STRUCT_LoginRes_type
{
	struct FString BeginTime_0_61E8AB401E0B8B054798D4B700EA1325; // 0x0(0x10)
	struct FString EndTime_1_75DE77C05915E9FF6F6F79DB0FE48785; // 0x10(0x10)
	int ID_2_500551805D3D3EB8005C1DB60AD29B84; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString ResPath_3_6DF67C00770BC06671BECC720D654108; // 0x28(0x10)
	struct FString BGMPath_4_459C2700734E2FA214B5EDF7032F4118; // 0x38(0x10)
	struct FString TexPath_5_02397DC0325EB369387098470F604108; // 0x48(0x10)
	struct FString VideoPath_6_2D0C0F403824D91B0A97369A07ADC1F8; // 0x58(0x10)
	struct FString ResLodPath_7_0D8043C04EAF4CDF7F2130C901C3BE18; // 0x68(0x10)
};

