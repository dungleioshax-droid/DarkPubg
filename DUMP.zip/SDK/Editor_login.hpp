#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass Editor_login.Editor_login_C
// Size: 0x4B8 (Inherited: 0x4B0)
struct AEditor_login_C : ALevelScriptActor
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4B0(0x8)


	// Object: Function Editor_login.Editor_login_C.SetFpsByIndex
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void SetFpsByIndex(int idx);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_11
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_Android_Back_K2Node_InputKeyEvent_11(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_E_K2Node_InputKeyEvent_10
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_E_K2Node_InputKeyEvent_10(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_9
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_BackSpace_K2Node_InputKeyEvent_9(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_B_K2Node_InputKeyEvent_8
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_B_K2Node_InputKeyEvent_8(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_G_K2Node_InputKeyEvent_7
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_G_K2Node_InputKeyEvent_7(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.InpActEvt_N_K2Node_InputKeyEvent_6
	// Flags: [BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void InpActEvt_N_K2Node_InputKeyEvent_6(struct FKey Key);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login
	// Flags: [HasDefaults]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Editor_login(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

