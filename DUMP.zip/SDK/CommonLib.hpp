#pragma once

#include <cstdint>

// Object: Enum CommonLib.DownloadResult
enum class EDownloadResult : uint8_t
{
	SuccessDownloading = 0,
	DownloadFailed = 1,
	SaveFailed = 2,
	DirectoryCreationFailed = 3,
	DownloadResult_MAX = 4
};

// Object: ScriptStruct CommonLib.ServiceCollection
// Size: 0x50 (Inherited: 0x0)
struct FServiceCollection
{
	struct TMap<struct FString, struct UObject*> ServiceMap; // 0x0(0x50)
};

// Object: Class CommonLib.TextWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct ITextWidgetInterface : IInterface
{

	// Object: Function CommonLib.TextWidgetInterface.GetTextContent
	// Flags: [Native|Public|Const]
	// Offset: 0x1069dde50
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetTextContent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
};

// Object: Class CommonLib.LuaService
// Size: 0x28 (Inherited: 0x28)
struct ILuaService : IInterface
{
};

// Object: Class CommonLib.CommonLuaLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCommonLuaLibrary : UBlueprintFunctionLibrary
{

	// Object: Function CommonLib.CommonLuaLibrary.IsMatch
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069de2dc
	// Params: [ Num(3) Size(0x21) ]
	bool IsMatch(struct FString Source, struct FString regex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069DB7B8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function CommonLib.CommonLuaLibrary.GetName
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069de238
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetName(struct UObject* Obj);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069DB600
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1069DB7B8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870
	// [Call #20] RVA: 0x10519022C

	// Object: Function CommonLib.CommonLuaLibrary.GetModNames
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069de1d4
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetModNames();
	// [Call #1] RVA: 0x1069DB630
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1069DB600
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1069DB7B8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C

	// Object: Function CommonLib.CommonLuaLibrary.GetGWorld
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069de1a0
	// Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetGWorld();
	// [Call #1] RVA: 0x1069DB5F4
	// [Call #2] RVA: 0x1069DB630
	// [Call #3] RVA: 0x101FA5F38
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1069DB600
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1069DB7B8
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function CommonLib.CommonLuaLibrary.GetFullName
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x1069de0fc
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetFullName(struct UObject* Obj);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1069DB628
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1069DB5F4
	// [Call #9] RVA: 0x1069DB630
	// [Call #10] RVA: 0x101FA5F38
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1069DB600
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
};

// Object: Class CommonLib.RuntimeFilesDownloaderLibrary
// Size: 0x98 (Inherited: 0x28)
struct URuntimeFilesDownloaderLibrary : UObject
{
	struct FScriptMulticastDelegate OnProgress; // 0x28(0x10)
	uint8_t Pad_0x38[0x18]; // 0x38(0x18)
	struct FScriptMulticastDelegate OnResult; // 0x50(0x10)
	uint8_t Pad_0x60[0x18]; // 0x60(0x18)
	struct FString FileURL; // 0x78(0x10)
	struct FString FileSavePath; // 0x88(0x10)


	// Object: Function CommonLib.RuntimeFilesDownloaderLibrary.DownloadFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1069de700
	// Params: [ Num(3) Size(0x28) ]
	struct URuntimeFilesDownloaderLibrary* DownloadFile(struct FString URL, struct FString SavePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x1069DBC34
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C

	// Object: Function CommonLib.RuntimeFilesDownloaderLibrary.CreateDownloader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1069de6cc
	// Params: [ Num(1) Size(0x8) ]
	struct URuntimeFilesDownloaderLibrary* CreateDownloader();
	// [Call #1] RVA: 0x1069DBBC4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x1069DBC34
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C
};

// Object: Class CommonLib.ServiceManager
// Size: 0x78 (Inherited: 0x28)
struct UServiceManager : UObject
{
	struct TMap<struct FName, struct FServiceCollection> Services; // 0x28(0x50)


	// Object: Function CommonLib.ServiceManager.UnregisterService
	// Flags: [Final|Native|Public]
	// Offset: 0x1069dec9c
	// Params: [ Num(2) Size(0x18) ]
	void UnregisterService(struct UObject* ServiceType, struct FString serviceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069DC640
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function CommonLib.ServiceManager.RegisterService
	// Flags: [Final|Native|Public]
	// Offset: 0x1069deb90
	// Params: [ Num(3) Size(0x20) ]
	void RegisterService(struct UObject* Service, struct UObject* ServiceType, struct FString serviceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1069DC3C8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069DC640
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function CommonLib.ServiceManager.GetService
	// Flags: [Final|Native|Public]
	// Offset: 0x1069deaac
	// Params: [ Num(3) Size(0x20) ]
	struct UObject* GetService(struct UObject* ServiceType, struct FString serviceName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1069DC770
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1069DC3C8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

