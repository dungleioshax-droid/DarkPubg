#pragma once

#include <cstdint>

// Object: Enum HiggsBoson.EGymOpType
enum class EGymOpType : uint8_t
{
	None = 0,
	La = 1,
	Sm = 2,
	El = 3,
	No = 4,
	EGymOpType_MAX = 5
};

// Object: Enum HiggsBoson.EGaraType
enum class EGaraType : uint8_t
{
	Invalid = 0,
	Alpha = 1,
	Whale = 2,
	EGaraType_MAX = 3
};

// Object: Enum HiggsBoson.EUpdateParamsType
enum class EUpdateParamsType : uint8_t
{
	RotateLockShooting = 5,
	WeaponFastReload = 7,
	Parachute = 8,
	SetGameModeMoveSpeedBase = 10,
	SetGameModeMoveSpeedModifier = 11,
	MoveUtils = 12,
	MoveUtilsSkipSkillID = 14,
	ClientShootReviewSystem = 16,
	ClientGlueHiaSystem = 24,
	RecoilOnWeaponShoot = 30,
	RecoilOnKickBack = 31,
	AvatarSkipSlotTypes = 40,
	FingerTouchFlow = 41,
	EUpdateParamsType_MAX = 42
};

// Object: Enum HiggsBoson.ECharacterFitnessType
enum class ECharacterFitnessType : uint8_t
{
	None = 0,
	DistanceXY = 1,
	DistanceZ = 2,
	Distance3D = 3,
	ABS = 4,
	ContinuousID = 5,
	ContinuousInterval = 6,
	SourceSpeedZ = 7,
	SourceSpeedZBS = 8,
	SourceSpeedXY = 9,
	SourceSpeed3D = 10,
	TargetSpeedZ = 11,
	TargetSpeedZBS = 12,
	TargetSpeedXY = 13,
	TargetSpeed3D = 14,
	BeAttachedToParentTime = 15,
	SourcePawnState = 16,
	TargetPawnState = 17,
	Weapon = 18,
	BBAngle = 19,
	RelativeSpeedZ = 20,
	RelativeSpeedZBS = 21,
	RelativeSpeedXY = 22,
	RelativeSpeed3D = 23,
	SourceMovementMode = 24,
	TargetMovementMode = 25,
	SourceMovementBase = 26,
	TargetMovementBase = 27,
	Half = 30,
	Alpha = 31,
	HealthStatus = 32,
	HiPart = 33,
	Accuse = 35,
	BullySpeed = 36,
	EGameModeType = 37,
	EParachuteState = 38,
	RelativeTangentSpeed = 39,
	RelativeAngleSpeed = 40,
	SinceLastProne = 41,
	Full = 42,
	FFAngle = 43,
	CHAngle = 44,
	CVAngle = 45,
	SACount = 46,
	MaxDev = 47,
	RandDev = 49,
	WeedType = 50,
	Dura1 = 51,
	Dura2 = 52,
	AccEv = 53,
	AccAd = 54,
	ShooterLocationZ = 55,
	ShooterAreaID = 56,
	ShooterBaseIsMovable = 57,
	ECharacterFitnessType_MAX = 58
};

// Object: Enum HiggsBoson.ECoronaClientData
enum class ECoronaClientData : uint8_t
{
	Invalid = 0,
	BulletFireSpeed = 1,
	CurrentWeaponID = 2,
	GravityZ = 3,
	MinUndilatedFrameTime = 4,
	ActorTimeDilation = 5,
	ShootInterval = 6,
	ExtraHitPerformScale = 7,
	SwitchWeaponSpeedScale = 8,
	AnimationKick = 9,
	RecoilKickADS = 10,
	AccessoriesVRecoilFactor = 11,
	AccessoriesHRecoilFactor = 12,
	AccessoriesRecoveryFactor = 13,
	JumpMaxCount = 14,
	JumpZVelocity = 15,
	TimeDilation = 16,
	FireTimeID = 17,
	MaxAcceleration = 19,
	ConfigCollisionDistSqAngle = 21,
	WalkableFloorAngle = 22,
	MaxStepHeight = 23,
	ECoronaClientData_MAX = 24
};

// Object: ScriptStruct HiggsBoson.PendingJudgeStruct
// Size: 0x50 (Inherited: 0x0)
struct FPendingJudgeStruct
{
	struct TSet<struct UFullCoverMarginIntervalCharacterTickerInterval*> IntervalSet; // 0x0(0x50)
};

// Object: ScriptStruct HiggsBoson.PatchPoint
// Size: 0xC (Inherited: 0x0)
struct FPatchPoint
{
	int Offset; // 0x0(0x4)
	uint32_t Old; // 0x4(0x4)
	uint32_t New; // 0x8(0x4)
};

// Object: ScriptStruct HiggsBoson.MoveInput
// Size: 0x20 (Inherited: 0x0)
struct FMoveInput
{
	float TimeSeconds; // 0x0(0x4)
	float ForwardInputRate; // 0x4(0x4)
	float RightInputRate; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	uint64_t CurrentStates; // 0x10(0x8)
	int ZeroMoveInputCount; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: Class HiggsBoson.BaziState
// Size: 0x190 (Inherited: 0x28)
struct UBaziState : UObject
{
	uint8_t Pad_0x28[0x168]; // 0x28(0x168)


	// Object: Function HiggsBoson.BaziState.OnControllerReconnected
	// Flags: [Final|Native|Private]
	// Offset: 0x104844d60
	// Params: [ Num(0) Size(0x0) ]
	void OnControllerReconnected();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x104844AF8
	// [Call #7] RVA: 0x105185230
	// [Call #8] RVA: 0x1051903D0

	// Object: Function HiggsBoson.BaziState.AddChori
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104844ca4
	// Params: [ Num(1) Size(0x18) ]
	void AddChori(struct FChori& Element);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F0FCC
	// [Call #4] RVA: 0x103D2ACC4
	// [Call #5] RVA: 0x103D2ACC4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function HiggsBoson.BaziState.AddBazi
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104844be8
	// Params: [ Num(1) Size(0x18) ]
	void AddBazi(struct FBazi& Element);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F0F3C
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1047F0FCC
	// [Call #10] RVA: 0x103D2ACC4
	// [Call #11] RVA: 0x103D2ACC4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
};

// Object: Class HiggsBoson.ClientGlueHiaSystem
// Size: 0x560 (Inherited: 0x30)
struct UClientGlueHiaSystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x64]; // 0x30(0x64)
	bool bEnglish; // 0x94(0x1)
	uint8_t Pad_0x95[0x3]; // 0x95(0x3)
	struct UBaziState* BaziState; // 0x98(0x8)
	struct UMakeWoe* MakeWoe; // 0xA0(0x8)
	uint8_t Pad_0xA8[0x4B8]; // 0xA8(0x4B8)


	// Object: Function HiggsBoson.ClientGlueHiaSystem.Vulou
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104846960
	// Params: [ Num(1) Size(0x4) ]
	float Vulou();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc9
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(1) Size(0x4) ]
	void LuaFunc9(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc8
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x5) ]
	bool LuaFunc8(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc7
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x5) ]
	bool LuaFunc7(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc6
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x5) ]
	bool LuaFunc6(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc5
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x5) ]
	bool LuaFunc5(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc4
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x5) ]
	bool LuaFunc4(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc3
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(1) Size(0x4) ]
	void LuaFunc3(int Param1);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc2
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(0) Size(0x0) ]
	void LuaFunc2();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.LuaFunc1
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1021a893c
	// Params: [ Num(2) Size(0x9) ]
	bool LuaFunc1(struct AActor* PtrActor);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x105099E5C
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x1021C79D8
	// [Call #7] RVA: 0x1021A92E0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func9
	// Flags: [Final|Native|Private]
	// Offset: 0x104846490
	// Params: [ Num(1) Size(0x8) ]
	void Func9(struct AActor* PtrWeapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F36D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1047F30A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1047F30B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047F30B8

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func8
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104846324
	// Params: [ Num(4) Size(0x13C) ]
	int Func8(struct AActor* PtrWeapon, struct FBulletHitInfoUploadData& UploadData, struct FLocalShootHitData& LocalHitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1047F347C
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1047F36D0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func7
	// Flags: [Final|Native|Private]
	// Offset: 0x1048462f0
	// Params: [ Num(1) Size(0x1) ]
	bool Func7();
	// [Call #1] RVA: 0x1047F33FC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106C8CD38
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1047F347C
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x101F8BA44
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047F36D0
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func6
	// Flags: [Final|Native|Private]
	// Offset: 0x104846264
	// Params: [ Num(2) Size(0xC) ]
	float Func6(struct AActor* Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F335C
	// [Call #4] RVA: 0x1047F33FC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C8CD38
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047F347C
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x106C8459C

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func3
	// Flags: [Final|Native|Private]
	// Offset: 0x104846230
	// Params: [ Num(1) Size(0x4) ]
	float Func3();
	// [Call #1] RVA: 0x1047F32A8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1047F335C
	// [Call #5] RVA: 0x1047F33FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C8CD38
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F347C
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x101F8BA44

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func29
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x10484603c
	// Params: [ Num(5) Size(0x289) ]
	void Func29(struct UWorld* World, struct FBulletHitInfoUploadDataInReplay& HitData, float DrawRadius, float DisplayTime, bool bDrawVictimBound);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x103ABE600
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047F3E0C
	// [Call #13] RVA: 0x1039B1E48
	// [Call #14] RVA: 0x106C8CAC8
	// [Call #15] RVA: 0x1039B1E48
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1047F32A8

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func28
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104845ed8
	// Params: [ Num(3) Size(0x138) ]
	void Func28(struct AActor* Weapon, struct FBulletHitInfoUploadData& BulletHitInfoUploadData, struct FLocalShootHitData& LocalShootHitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1047F3D54
	// [Call #9] RVA: 0x101F8BA44
	// [Call #10] RVA: 0x101F8BA44
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x103ABE600
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func27
	// Flags: [Final|Native|Private]
	// Offset: 0x104845e5c
	// Params: [ Num(1) Size(0x4) ]
	void Func27(uint32_t ShootID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F396C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C8CD38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047F3D54
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x103ABE600

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func26
	// Flags: [Final|Native|Private]
	// Offset: 0x104845da8
	// Params: [ Num(2) Size(0x10) ]
	void Func26(struct AActor* Param4, struct AActor* Param5);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047F3CEC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1047F396C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C8CD38
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func25
	// Flags: [Final|Native|Private]
	// Offset: 0x104845c44
	// Params: [ Num(5) Size(0x20) ]
	void Func25(int Param1, float Param2, float Param3, struct AActor* Param4, struct AActor* Param5);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047F3C84
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1047F3CEC
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func24
	// Flags: [Final|Native|Private]
	// Offset: 0x104845aa4
	// Params: [ Num(6) Size(0x20) ]
	void Func24(int Param1, float Param2, float Param3, float Param4, struct AActor* Param5, struct AActor* Param6);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F3C1C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func23
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x10484597c
	// Params: [ Num(3) Size(0x98) ]
	void Func23(uint32_t Param1, struct FVector& Param2, struct FHitResult& Param3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1047F3BB4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func22
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x104845868
	// Params: [ Num(3) Size(0x1C) ]
	void Func22(uint32_t Param1, struct FVector& Param2, struct FVector& Param3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047F3B4C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C8CD38
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047F3BB4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func21
	// Flags: [Final|Native|Private]
	// Offset: 0x1048457ec
	// Params: [ Num(1) Size(0x8) ]
	void Func21(struct AActor* Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F5D20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047F3B4C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C8CD38
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func20
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	// Offset: 0x104845728
	// Params: [ Num(2) Size(0x14) ]
	void Func20(struct AActor* Param1, struct FVector& Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047F5D1C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1047F5D20
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047F3B4C

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func2
	// Flags: [Final|Native|Private]
	// Offset: 0x104845658
	// Params: [ Num(3) Size(0xA) ]
	bool Func2(struct AActor* CharacterPtr, bool bParam1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047F3140
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047F5D1C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F5D20
	// [Call #14] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func19
	// Flags: [Final|Native|Private]
	// Offset: 0x104845568
	// Params: [ Num(3) Size(0xC) ]
	void Func19(uint32_t Param1, float Param2, float Param3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047F3AE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047F3140
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func18
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104845450
	// Params: [ Num(2) Size(0x20) ]
	void Func18(struct TArray<struct FBazi>& Bazi, struct TArray<struct FChori>& Chori);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047F3A68
	// [Call #6] RVA: 0x10480E868
	// [Call #7] RVA: 0x10484E3E8
	// [Call #8] RVA: 0x10480E868
	// [Call #9] RVA: 0x10484E3E8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1047F3AE4
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func17
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104845378
	// Params: [ Num(1) Size(0xC0) ]
	void Func17(struct FFatalDamageParameter& Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F5CC4
	// [Call #4] RVA: 0x103E34144
	// [Call #5] RVA: 0x103E34144
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047F3A68
	// [Call #12] RVA: 0x10480E868
	// [Call #13] RVA: 0x10484E3E8
	// [Call #14] RVA: 0x10480E868
	// [Call #15] RVA: 0x10484E3E8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func16
	// Flags: [Final|Native|Private]
	// Offset: 0x104845364
	// Params: [ Num(0) Size(0x0) ]
	void Func16();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F5CC4
	// [Call #4] RVA: 0x103E34144
	// [Call #5] RVA: 0x103E34144
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1047F3A68
	// [Call #12] RVA: 0x10480E868
	// [Call #13] RVA: 0x10484E3E8
	// [Call #14] RVA: 0x10480E868
	// [Call #15] RVA: 0x10484E3E8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func15
	// Flags: [Final|Native|Private]
	// Offset: 0x1048452e8
	// Params: [ Num(1) Size(0x8) ]
	void Func15(struct AActor* Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F5CC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1047F5CC4
	// [Call #7] RVA: 0x103E34144
	// [Call #8] RVA: 0x103E34144
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1047F3A68
	// [Call #15] RVA: 0x10480E868
	// [Call #16] RVA: 0x10484E3E8

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func14
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x1048451e8
	// Params: [ Num(2) Size(0xA8) ]
	void Func14(struct FShootTimeData& InData, struct AActor* PtrWeapon);
	// [Call #1] RVA: 0x103A21C6C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1047F3830
	// [Call #7] RVA: 0x106C8CAC8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047F5CC0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F5CC4
	// [Call #14] RVA: 0x103E34144

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func11
	// Flags: [Final|Native|Private]
	// Offset: 0x10484515c
	// Params: [ Num(2) Size(0xC) ]
	float Func11(struct AActor* Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F331C
	// [Call #4] RVA: 0x103A21C6C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1047F3830
	// [Call #10] RVA: 0x106C8CAC8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F5CC0

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func10
	// Flags: [Final|Native|Private]
	// Offset: 0x1048450e0
	// Params: [ Num(1) Size(0x8) ]
	void Func10(struct AActor* Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1047F3774
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1047F331C
	// [Call #7] RVA: 0x103A21C6C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1047F3830
	// [Call #13] RVA: 0x106C8CAC8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.ClientGlueHiaSystem.Func1
	// Flags: [Final|Native|Private|Const]
	// Offset: 0x104844fe0
	// Params: [ Num(4) Size(0x11) ]
	bool Func1(struct AActor* CharacterPtr, float TimeInSeconds, float MarginInSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1047F30E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047F3774
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1047F331C
	// [Call #14] RVA: 0x103A21C6C
	// [Call #15] RVA: 0x10516D168
};

// Object: Class HiggsBoson.FuzzyObject
// Size: 0x350 (Inherited: 0x28)
struct UFuzzyObject : UObject
{
	uint8_t Pad_0x28[0x320]; // 0x28(0x320)
	int Param1; // 0x348(0x4)
	uint8_t Pad_0x34C[0x4]; // 0x34C(0x4)


	// Object: Function HiggsBoson.FuzzyObject.SetUInt8ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848cbc
	// Params: [ Num(3) Size(0x6) ]
	bool SetUInt8ValueByName(int Name, uint8_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FBC90
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function HiggsBoson.FuzzyObject.SetUInt64ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848bf4
	// Params: [ Num(3) Size(0x11) ]
	bool SetUInt64ValueByName(int Name, uint64_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC798
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FBC90
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function HiggsBoson.FuzzyObject.SetUInt32ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848b30
	// Params: [ Num(3) Size(0x9) ]
	bool SetUInt32ValueByName(int Name, uint32_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC3EC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC798
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FBC90

	// Object: Function HiggsBoson.FuzzyObject.SetUInt16ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848a68
	// Params: [ Num(3) Size(0x7) ]
	bool SetUInt16ValueByName(int Name, uint16_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC040
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC3EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FC798

	// Object: Function HiggsBoson.FuzzyObject.SetInt8ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x1048489a0
	// Params: [ Num(3) Size(0x6) ]
	bool SetInt8ValueByName(int Name, uint8_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FBAB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC040
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FC3EC

	// Object: Function HiggsBoson.FuzzyObject.SetInt64ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x1048488d8
	// Params: [ Num(3) Size(0x11) ]
	bool SetInt64ValueByName(int Name, int64_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC5C0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FBAB8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FC040

	// Object: Function HiggsBoson.FuzzyObject.SetInt32ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848814
	// Params: [ Num(3) Size(0x9) ]
	bool SetInt32ValueByName(int Name, int Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC218
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC5C0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FBAB8

	// Object: Function HiggsBoson.FuzzyObject.SetInt16ValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x10484874c
	// Params: [ Num(3) Size(0x7) ]
	bool SetInt16ValueByName(int Name, int16_t Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FBE68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC218
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FC5C0

	// Object: Function HiggsBoson.FuzzyObject.SetFloatValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x104848684
	// Params: [ Num(3) Size(0x9) ]
	bool SetFloatValueByName(int Name, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FCB48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FBE68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FC218

	// Object: Function HiggsBoson.FuzzyObject.SetBoolValueByName
	// Flags: [Final|Native|Public]
	// Offset: 0x1048485b8
	// Params: [ Num(3) Size(0x6) ]
	bool SetBoolValueByName(int Name, bool Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FC970
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FCB48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FBE68

	// Object: Function HiggsBoson.FuzzyObject.GetUInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x1048484e0
	// Params: [ Num(3) Size(0x6) ]
	bool GetUInt8ValueByName(int Name, uint8_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB72C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FC970
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1047FCB48

	// Object: Function HiggsBoson.FuzzyObject.GetUInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104848408
	// Params: [ Num(3) Size(0x11) ]
	bool GetUInt64ValueByName(int Name, uint64_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB988
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB72C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetUInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104848330
	// Params: [ Num(3) Size(0x9) ]
	bool GetUInt32ValueByName(int Name, uint32_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB8BC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB988
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetUInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104848258
	// Params: [ Num(3) Size(0x7) ]
	bool GetUInt16ValueByName(int Name, uint16_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB7F4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB8BC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104848180
	// Params: [ Num(3) Size(0x6) ]
	bool GetInt8ValueByName(int Name, uint8_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB6C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB7F4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x1048480a8
	// Params: [ Num(3) Size(0x11) ]
	bool GetInt64ValueByName(int Name, int64_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB920
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB6C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104847fd0
	// Params: [ Num(3) Size(0x9) ]
	bool GetInt32ValueByName(int Name, int& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB858
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB920
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104847ef8
	// Params: [ Num(3) Size(0x7) ]
	bool GetInt16ValueByName(int Name, int16_t& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB790
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB858
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetFloatValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104847e20
	// Params: [ Num(3) Size(0x9) ]
	bool GetFloatValueByName(int Name, float& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FBA54
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FB790
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.FuzzyObject.GetBoolValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x104847d48
	// Params: [ Num(3) Size(0x6) ]
	bool GetBoolValueByName(int Name, bool& OutValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1047FB9F0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1047FBA54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class HiggsBoson.SCoronaClientData
// Size: 0x350 (Inherited: 0x350)
struct USCoronaClientData : UFuzzyObject
{
};

// Object: Class HiggsBoson.ClientAmaUbaSubsystem
// Size: 0x90 (Inherited: 0x30)
struct UClientAmaUbaSubsystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x60]; // 0x30(0x60)


	// Object: Function HiggsBoson.ClientAmaUbaSubsystem.Func1
	// Flags: [Final|Native|Private]
	// Offset: 0x1048476d4
	// Params: [ Num(4) Size(0xD) ]
	void Func1(int IntType, float InTimestamp, int IncreaseCount, bool bAlertUploadFrequency);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1047F8FB0
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class HiggsBoson.MakeWoe
// Size: 0x30 (Inherited: 0x28)
struct UMakeWoe : UObject
{
	bool bEnable01; // 0x28(0x1)
	bool bEnable02; // 0x29(0x1)
	bool bEnable03; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x5]; // 0x2B(0x5)
};

// Object: Class HiggsBoson.FullCoverMarginIntervalCharacterTickerInterval
// Size: 0x80 (Inherited: 0x28)
struct UFullCoverMarginIntervalCharacterTickerInterval : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
};

// Object: Class HiggsBoson.FullCoverMarginIntervalCharacterTicker
// Size: 0x148 (Inherited: 0x28)
struct UFullCoverMarginIntervalCharacterTicker : UObject
{
	float ConfigIntervalTime; // 0x28(0x4)
	float ConfigMarginTime; // 0x2C(0x4)
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
	uint8_t SkipPawnState64; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct TMap<uint32_t, struct UFullCoverMarginIntervalCharacterTickerInterval*> CurrentIntervalMap; // 0x40(0x50)
	struct TMap<uint32_t, struct FPendingJudgeStruct> PendingJudgeMap; // 0x90(0x50)
	struct TArray<struct UFullCoverMarginIntervalCharacterTickerInterval*> InfoObjectPool; // 0xE0(0x10)
	uint8_t Pad_0xF0[0x58]; // 0xF0(0x58)
};

// Object: Class HiggsBoson.CamoyoHelper
// Size: 0x28 (Inherited: 0x28)
struct UCamoyoHelper : UObject
{

	// Object: Function HiggsBoson.CamoyoHelper.MakeRectTu
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1048496b0
	// Params: [ Num(4) Size(0x25) ]
	void MakeRectTu(DelegateProperty CamoyoRetDelegate, struct FString Filename, int Quality, bool bShowUI);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x104802C58
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C
	// [Call #20] RVA: 0x105190870

	// Object: Function HiggsBoson.CamoyoHelper.MakeMemPerform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10484963c
	// Params: [ Num(1) Size(0x4) ]
	void MakeMemPerform(int InbOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1048032DC
	// [Call #4] RVA: 0x101FD9E48
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x104802C58
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function HiggsBoson.CamoyoHelper.MakeFitRectTu
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1048494f0
	// Params: [ Num(4) Size(0x25) ]
	void MakeFitRectTu(DelegateProperty CamoyoRetDelegate, struct FVector4 InCutParam, int InTuType, bool isShowUI);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104802DDC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1048032DC
	// [Call #14] RVA: 0x101FD9E48
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class HiggsBoson.HiggsBosonComponent
// Size: 0x11E8 (Inherited: 0x238)
struct UHiggsBosonComponent : ULuaActorComponent
{
	uint8_t Pad_0x238[0x1F]; // 0x238(0x1F)
	bool bOpenActorChannelErrorReport; // 0x257(0x1)
	uint8_t Pad_0x258[0xF8]; // 0x258(0xF8)
	struct FString TraceData; // 0x350(0x10)
	struct FString GameTraceData; // 0x360(0x10)
	uint32_t HeartBreaks; // 0x370(0x4)
	uint8_t Pad_0x374[0x4]; // 0x374(0x4)
	struct FString HeartInfo; // 0x378(0x10)
	struct FScriptMulticastDelegate OnSwiftHawkDelegate; // 0x388(0x10)
	struct FScriptMulticastDelegate OnEzioDelegate; // 0x398(0x10)
	struct ASTExtraBaseCharacter* CharacterOwner; // 0x3A8(0x8)
	struct ASTExtraPlayerController* PlayerController; // 0x3B0(0x8)
	bool bClientInfoReceived; // 0x3B8(0x1)
	uint8_t Pad_0x3B9[0x7]; // 0x3B9(0x7)
	struct TArray<uint32_t> ClientInfoAsUInt32Array; // 0x3C0(0x10)
	struct TArray<uint8_t> IntegrityItemCheckResultAsBytes; // 0x3D0(0x10)
	uint8_t Pad_0x3E0[0x40]; // 0x3E0(0x40)
	bool bRoofTouchActive; // 0x420(0x1)
	bool bPalmRestActive; // 0x421(0x1)
	uint8_t Pad_0x422[0x12]; // 0x422(0x12)
	int RoofTouchStatus; // 0x434(0x4)
	struct TArray<struct FString> PalmRestSampleKeys; // 0x438(0x10)
	int PalmRestSampleCount; // 0x448(0x4)
	uint8_t Pad_0x44C[0x9C4]; // 0x44C(0x9C4)
	struct USCoronaClientData* SecurityCoronaLabClientDataPointer; // 0xE10(0x8)
	uint8_t Pad_0xE18[0x68]; // 0xE18(0x68)
	bool bMHActive; // 0xE80(0x1)
	uint8_t Pad_0xE81[0xAF]; // 0xE81(0xAF)
	struct TMap<int, int> FFItemIDMap; // 0xF30(0x50)
	struct TMap<int, int> FFWeaponItemIDMap; // 0xF80(0x50)
	uint8_t Pad_0xFD0[0x1C]; // 0xFD0(0x1C)
	int ReceivedRotationModifiedCount; // 0xFEC(0x4)
	int ReceivedTranslationModifiedCount; // 0xFF0(0x4)
	int ReceivedScale3DModifiedCount; // 0xFF4(0x4)
	struct TArray<int> LastInvalidIndexListInPakLite; // 0xFF8(0x10)
	uint8_t Pad_0x1008[0x8]; // 0x1008(0x8)
	struct FScriptMulticastDelegate OnServerReceiveInvalidFilesInPakLiteDelegate; // 0x1010(0x10)
	uint8_t Pad_0x1020[0xE8]; // 0x1020(0xE8)
	float TouchScreenActiveTimeRatioThreshold; // 0x1108(0x4)
	uint8_t Pad_0x110C[0x4]; // 0x110C(0x4)
	float MouTa; // 0x1110(0x4)
	int BandaCountThreshold; // 0x1114(0x4)
	bool bEnableBandCount; // 0x1118(0x1)
	uint8_t Pad_0x1119[0x3]; // 0x1119(0x3)
	float IntervalThreshold1; // 0x111C(0x4)
	int HongThreshold; // 0x1120(0x4)
	float NovoThreshold; // 0x1124(0x4)
	uint8_t Pad_0x1128[0x40]; // 0x1128(0x40)
	int MaxCountOfPlayerHistoryLocationToDetectCamouflage; // 0x1168(0x4)
	uint8_t Pad_0x116C[0xC]; // 0x116C(0xC)
	float MinDistanceToDetectCamouflage; // 0x1178(0x4)
	uint8_t Pad_0x117C[0x30]; // 0x117C(0x30)
	float OfflineMoveThreshold; // 0x11AC(0x4)
	float OfflineMoveValidScale; // 0x11B0(0x4)
	float LongTimeNoReceiveScale; // 0x11B4(0x4)
	int MinOfflineCount; // 0x11B8(0x4)
	int MaxOfflineCount; // 0x11BC(0x4)
	bool bOfflineMoveReady; // 0x11C0(0x1)
	uint8_t Pad_0x11C1[0x27]; // 0x11C1(0x27)


	// Object: Function HiggsBoson.HiggsBosonComponent.Zanwu
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484c958
	// Params: [ Num(1) Size(0x10) ]
	void Zanwu(struct FString Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function HiggsBoson.HiggsBosonComponent.SyncServerParam
	// Flags: [Final|Native|Public]
	// Offset: 0x10484c8d4
	// Params: [ Num(1) Size(0x1) ]
	void SyncServerParam(bool Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C7C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function HiggsBoson.HiggsBosonComponent.SwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484c7f4
	// Params: [ Num(2) Size(0x14) ]
	void SwiftHawk(struct TArray<uint8_t> Hawks, uint32_t Magic);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10482C7C8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C

	// Object: Function HiggsBoson.HiggsBosonComponent.ShowABCD
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x11) ]
	void ShowABCD(struct FString Message, bool bIsClientShowWindow);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10484c5f4
	// Params: [ Num(4) Size(0x28) ]
	void SetSchemeForInitialize(int Index, uint32_t VerifyLen, struct TArray<uint8_t> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FFC894
	// [Call #10] RVA: 0x104835C00
	// [Call #11] RVA: 0x10482A2C4
	// [Call #12] RVA: 0x104835BD0
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x104835BD0
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x104835BD0
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104835BD0
	// [Call #23] RVA: 0x101F8BA74
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet
	// Flags: [Final|Native|Public]
	// Offset: 0x10484c3f4
	// Params: [ Num(4) Size(0x28) ]
	void SetSchemeForGet(int Index, uint32_t VerifyLen, struct TArray<uint8_t> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FFC894
	// [Call #10] RVA: 0x104835C00
	// [Call #11] RVA: 0x10482A340
	// [Call #12] RVA: 0x104835BD0
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x104835BD0
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x104835BD0
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104835BD0
	// [Call #23] RVA: 0x101F8BA74
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.ServerPoPo
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x10484c34c
	// Params: [ Num(1) Size(0x10) ]
	void ServerPoPo(struct TArray<uint8_t>& Array);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482D6A8
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101FFC894
	// [Call #16] RVA: 0x104835C00
	// [Call #17] RVA: 0x10482A340
	// [Call #18] RVA: 0x104835BD0
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x104835BD0
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x104835BD0

	// Object: Function HiggsBoson.HiggsBosonComponent.SendMoveStatusToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484c2c8
	// Params: [ Num(1) Size(0x1) ]
	void SendMoveStatusToServer(uint8_t State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10482D6A8
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101FFC894

	// Object: Function HiggsBoson.HiggsBosonComponent.S2CNuoro
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484c244
	// Params: [ Num(1) Size(0x4) ]
	void S2CNuoro(int Lotion);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10482D6A8
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484c040
	// Params: [ Num(6) Size(0x44) ]
	void RPC_ServerGlueHiaPark(uint8_t HiaType, struct TArray<uint8_t> GlueHiaParkArr, uint32_t HiaStatus, struct TArray<uint8_t> GlueArg, struct TArray<uint8_t> GlueHiaParkArr2, uint32_t HiaStatus2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484bf28
	// Params: [ Num(3) Size(0x18) ]
	void RPC_ServerCapbo(uint8_t BoCapC, uint8_t InBoType, struct TArray<uint8_t> BoDataArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.RPC_ServerAddInvalidFilesInPakLite
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484be88
	// Params: [ Num(1) Size(0x10) ]
	void RPC_ServerAddInvalidFilesInPakLite(struct TArray<int> InvalidIndexList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x10484bd6c
	// Params: [ Num(3) Size(0x1C) ]
	void RPC_ClientCoronaLab(uint8_t bAllSwitch, struct TArray<uint8_t> CoronaLab, uint32_t CoronaState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA44
	// [Call #13] RVA: 0x101F8BA44
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput
	// Flags: [Final|Native|Public]
	// Offset: 0x10484bc44
	// Params: [ Num(4) Size(0x10) ]
	void OnWeaponAimInput(float InDistToEnemy, float InYaw, float InPitch, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1048292D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x101F8BA74
	// [Call #18] RVA: 0x106C8459C

	// Object: Function HiggsBoson.HiggsBosonComponent.OnTouchInput
	// Flags: [Final|Native|Public]
	// Offset: 0x10484bb54
	// Params: [ Num(3) Size(0xC) ]
	void OnTouchInput(float InYaw, float InPitch, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1048293E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1048292D4
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10484bb40
	// Params: [ Num(0) Size(0x0) ]
	void OnStopFireEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1048293E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1048292D4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10484bb2c
	// Params: [ Num(0) Size(0x0) ]
	void OnStartFireEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1048293E4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1048292D4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual
	// Flags: [Final|Native|Public]
	// Offset: 0x10484ba78
	// Params: [ Num(2) Size(0x10) ]
	void OnSkillInteruptVisual(struct AActor* InTarget, struct AActor* InCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1048296FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1048293E4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b9c4
	// Params: [ Num(2) Size(0x10) ]
	void OnSkillEndVisual(struct AActor* InTarget, struct AActor* InCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10482957C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1048296FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b910
	// Params: [ Num(2) Size(0x10) ]
	void OnSkillEndTrans(struct AActor* InTarget, struct AActor* InCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10482989C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10482957C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1048296FC

	// Object: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b85c
	// Params: [ Num(2) Size(0x10) ]
	void OnSkillBeginVisual(struct AActor* InTarget, struct AActor* InCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1048293FC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10482989C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10482957C
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b7a8
	// Params: [ Num(2) Size(0x10) ]
	void OnSkillBeginTrans(struct AActor* InTarget, struct AActor* InCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104829864
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1048293FC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10482989C
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnRecoilCurveCheckFailed
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b72c
	// Params: [ Num(1) Size(0x8) ]
	void OnRecoilCurveCheckFailed(struct AActor* Weapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C5C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104829864
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1048293FC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b6a8
	// Params: [ Num(1) Size(0x1) ]
	void OnPlayerScopeOut(bool bBegan);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104828C24
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482C5C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104829864
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1048293FC

	// Object: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b624
	// Params: [ Num(1) Size(0x1) ]
	void OnPlayerScopeIn(bool bBegan);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104828BBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104828C24
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10482C5C4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104829864

	// Object: Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b5a8
	// Params: [ Num(1) Size(0x8) ]
	void OnMyPawnRespawn(struct AUAEPlayerController* InPlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104828C38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104828BBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104828C24
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10482C5C4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b52c
	// Params: [ Num(1) Size(0x8) ]
	void OnKillSomeOneEvent(struct AActor* InSomeOne);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1048292B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104828C38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104828BBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104828C24
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnGyroInput
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b43c
	// Params: [ Num(3) Size(0xC) ]
	void OnGyroInput(float InYaw, float InPitch, float InRoll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1048293F0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1048292B4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104828C38
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x10484b384
	// Params: [ Num(2) Size(0xD) ]
	void OnClientAdjustPosition(struct FVector NewLoc, uint8_t Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104829CB4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1048293F0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1048292B4
	// [Call #16] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnCapboReturn
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10484b264
	// Params: [ Num(3) Size(0x18) ]
	void OnCapboReturn(int BoCapC, int InBoType, struct TArray<uint8_t>& RetData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10482A0D8
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104829CB4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10484b18c
	// Params: [ Num(2) Size(0x90) ]
	void OnBulletImpactEvent(struct AActor* InCauser, struct FHitResult& InImpactResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482A0D8
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerWerewolf
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10484b150
	// Params: [ Num(1) Size(0x1) ]
	bool IsCharacterOwnerWerewolf();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482A0D8
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x106C8459C

	// Object: Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerButcher
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10484b114
	// Params: [ Num(1) Size(0x1) ]
	bool IsCharacterOwnerButcher();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482A0D8
	// [Call #14] RVA: 0x101F8BA74

	// Object: Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b100
	// Params: [ Num(0) Size(0x0) ]
	void HandleClientReconnect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482A0D8

	// Object: Function HiggsBoson.HiggsBosonComponent.GetBandaCountOffset
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10484b0c4
	// Params: [ Num(1) Size(0x4) ]
	int GetBandaCountOffset();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.FlushGameEnd
	// Flags: [Final|Native|Public]
	// Offset: 0x10484b0b0
	// Params: [ Num(0) Size(0x0) ]
	void FlushGameEnd();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C8CD38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482923C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.Ezio
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate]
	// Offset: 0x10484af80
	// Params: [ Num(4) Size(0x10) ]
	void Ezio(int Param1, int Param2, int Param3, int Param4);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.EnableTickEncrypt
	// Flags: [Final|Native|Public]
	// Offset: 0x10484af4c
	// Params: [ Num(1) Size(0x4) ]
	int EnableTickEncrypt();
	// [Call #1] RVA: 0x10482AA00
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.EnablePeekShootVerify
	// Flags: [Final|Native|Public]
	// Offset: 0x10484af18
	// Params: [ Num(1) Size(0x4) ]
	int EnablePeekShootVerify();
	// [Call #1] RVA: 0x10482AA20
	// [Call #2] RVA: 0x10482AA00
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors
	// Flags: [Final|Native|Public]
	// Offset: 0x10484ae9c
	// Params: [ Num(1) Size(0x4) ]
	void EnableEnhancedDynamicActors(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482A378
	// [Call #4] RVA: 0x10482AA20
	// [Call #5] RVA: 0x10482AA00
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.EnableCheckFilesInPakLite
	// Flags: [Final|Native|Public]
	// Offset: 0x10484ad68
	// Params: [ Num(3) Size(0x18) ]
	int EnableCheckFilesInPakLite(struct TArray<struct FString> InFiles, int InVerifyCountSinglePass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F86A94
	// [Call #6] RVA: 0x10482AAD0
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10482A378
	// [Call #17] RVA: 0x10482AA20
	// [Call #18] RVA: 0x10482AA00
	// [Call #19] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem
	// Flags: [Final|Native|Public]
	// Offset: 0x10484ab90
	// Params: [ Num(7) Size(0x1C) ]
	void DispatchIntegrityCheckItem(uint32_t PlatID, uint32_t AreaID, uint32_t GameBits, uint32_t Index, int Offset, uint32_t Len, uint32_t Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10482A208
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocationC2S
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|HasDefaults|NetValidate]
	// Offset: 0x10484a9e8
	// Params: [ Num(6) Size(0x39) ]
	void DevPVSCheckClientLocationC2S(struct ASTExtraBaseCharacter* PtrOtherCharacter, struct FVector D, struct FVector A, struct FVector V, struct FVector C, bool b1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocation
	// Flags: [Net|NetReliableNative|Event|Public|HasDefaults|NetClient|NetValidate]
	// Offset: 0x10484a92c
	// Params: [ Num(2) Size(0x14) ]
	void DevPVSCheckClientLocation(struct AActor* PtrSimulatedProxy, struct FVector D);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.DevPrintMouke
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10484a7f8
	// Params: [ Num(3) Size(0x28) ]
	void DevPrintMouke(struct FString Param0, float Param1, struct FString Param3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a77c
	// Params: [ Num(1) Size(0x4) ]
	void ControlRoofTouch(int Switch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C7CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.ControlPalmRest
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a700
	// Params: [ Num(1) Size(0x4) ]
	void ControlPalmRest(int Switch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C7D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482C7CC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C

	// Object: Function HiggsBoson.HiggsBosonComponent.ControlMoveInputRecord
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a560
	// Params: [ Num(6) Size(0x18) ]
	void ControlMoveInputRecord(int Switch, float RecordCooldown, int BitmapSize, int MinValidSampleCount, uint32_t InAngleSampleMaxCount, uint32_t InAngleDistributionNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482C7D4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10482C7D0
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.ControlMHActive
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a4e4
	// Params: [ Num(1) Size(0x4) ]
	void ControlMHActive(int Switch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C91C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10482C7D4
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.Cofew
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a468
	// Params: [ Num(1) Size(0x4) ]
	void Cofew(uint32_t InIter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482E480
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10482C91C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10484a3c8
	// Params: [ Num(1) Size(0x10) ]
	void ClientSwiftHawkWithParams(struct TArray<uint8_t> Hawks);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10482E480
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10482C91C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10484a308
	// Params: [ Num(2) Size(0x8) ]
	void ClientSwiftHawk(uint8_t Type, int SequenceID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10482E480
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10482C91C

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx
	// Flags: [Final|Net|Native|Event|Private|NetClient|NetValidate]
	// Offset: 0x10484a268
	// Params: [ Num(1) Size(0x10) ]
	void ClientReceiveEx(struct TArray<uint8_t> RPCConstArray);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8BA74
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x101F8BA74
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientDoJT
	// Flags: [Final|Native|Public]
	// Offset: 0x10484a1e4
	// Params: [ Num(1) Size(0x1) ]
	void ClientDoJT(bool bDelayUntilShot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482C6E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8BA74
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientCloseBaziUI
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10484a0f0
	// Params: [ Num(2) Size(0x20) ]
	void ClientCloseBaziUI(struct TArray<struct FBazi> Bazi, struct TArray<struct FChori> Chori);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10480E868
	// [Call #6] RVA: 0x10484E3E8
	// [Call #7] RVA: 0x10480E868
	// [Call #8] RVA: 0x10484E3E8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10482C6E0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function HiggsBoson.HiggsBosonComponent.ClientAccom
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10484a06c
	// Params: [ Num(1) Size(0x2) ]
	void ClientAccom(uint16_t Owea);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10480E868
	// [Call #8] RVA: 0x10484E3E8
	// [Call #9] RVA: 0x10480E868
	// [Call #10] RVA: 0x10484E3E8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10482C6E0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function HiggsBoson.HiggsBosonComponent.C2SSendAlert
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate]
	// Offset: 0x104849fcc
	// Params: [ Num(1) Size(0x10) ]
	void C2SSendAlert(struct FString Param1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10480E868
	// [Call #13] RVA: 0x10484E3E8
	// [Call #14] RVA: 0x10480E868
	// [Call #15] RVA: 0x10484E3E8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
};

// Object: Class HiggsBoson.HiggsBosonDataSubsystem
// Size: 0x140 (Inherited: 0x30)
struct UHiggsBosonDataSubsystem : UGameInstanceSubsystem
{
	bool bFingerTouchFlowServerEnabled; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct FFingerTouchFlow FingerTouchFlow; // 0x38(0x98)
	int FingerTouchFlow_MinSampleCount; // 0xD0(0x4)
	int FingerTouchFlow_MaxClusterCount; // 0xD4(0x4)
	float FingerTouchFlow_SamplingDuration; // 0xD8(0x4)
	float FingerTouchFlow_CoolDown; // 0xDC(0x4)
	int FingerTouchFlow_MaxSamplePerCluster; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
	struct TSet<int> FingerTouchFlow_ModeFilter; // 0xE8(0x50)
	int FingerTouchFlow_AuxResult; // 0x138(0x4)
	uint8_t Pad_0x13C[0x4]; // 0x13C(0x4)
};

// Object: Class HiggsBoson.HiggsBosonScriptHelper
// Size: 0x28 (Inherited: 0x28)
struct UHiggsBosonScriptHelper : UObject
{

	// Object: Function HiggsBoson.HiggsBosonScriptHelper.FileCRCGuard_UnregisterFile
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104850914
	// Params: [ Num(1) Size(0x10) ]
	void FileCRCGuard_UnregisterFile(struct FString InFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10482EEDC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x105190870

	// Object: Function HiggsBoson.HiggsBosonScriptHelper.FileCRCGuard_RegisterFile
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104850828
	// Params: [ Num(3) Size(0x21) ]
	bool FileCRCGuard_RegisterFile(struct FString InFilePath, struct FString InTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10482EED8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10482EEDC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C
};

// Object: Class HiggsBoson.MarginIntervalCharacterTickerPlayerInfo
// Size: 0x38 (Inherited: 0x28)
struct UMarginIntervalCharacterTickerPlayerInfo : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
};

// Object: Class HiggsBoson.MarginIntervalCharacterTicker
// Size: 0x88 (Inherited: 0x28)
struct UMarginIntervalCharacterTicker : UObject
{
	float IntervalTime; // 0x28(0x4)
	float MarginTime; // 0x2C(0x4)
	uint8_t SkipPawnState64; // 0x30(0x1)
	uint8_t Pad_0x31[0x7]; // 0x31(0x7)
	struct TMap<uint32_t, struct UMarginIntervalCharacterTickerPlayerInfo*> PlayerKey2Info; // 0x38(0x50)


	// Object: Function HiggsBoson.MarginIntervalCharacterTicker.Reset
	// Flags: [Final|Native|Private]
	// Offset: 0x104850c48
	// Params: [ Num(0) Size(0x0) ]
	void Reset();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10485109C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041EFFBC
};

// Object: Class HiggsBoson.SecurityAvatarSystem
// Size: 0x90 (Inherited: 0x30)
struct USecurityAvatarSystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x60]; // 0x30(0x60)


	// Object: Function HiggsBoson.SecurityAvatarSystem.OnAvatarRectifyDataChange
	// Flags: [Final|Native|Public]
	// Offset: 0x104850f18
	// Params: [ Num(2) Size(0xC) ]
	void OnAvatarRectifyDataChange(struct AUAECharacter* CharacterOwner, int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10482F764
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x104844AF8

	// Object: Function HiggsBoson.SecurityAvatarSystem.OnAvatarEquipped
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x104850db8
	// Params: [ Num(4) Size(0x40) ]
	void OnAvatarEquipped(struct AUAECharacter* CharacterOwner, int SlotID, struct FItemDefineID& NewItemID, struct FItemDefineID& OldItemID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1041EFFBC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041EFFBC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10482F5D0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10482F764
	// [Call #17] RVA: 0x10519022C
};

// Object: Class HiggsBoson.SecurityImprisonComp
// Size: 0x1A8 (Inherited: 0x178)
struct USecurityImprisonComp : UActorComponent
{
	struct ASTExtraPlayerController* OwnerPC; // 0x178(0x8)
	struct ASTExtraBaseCharacter* CharacterWaitForOp; // 0x180(0x8)
	struct TArray<uint64_t> TeammateKillerUID; // 0x188(0x10)
	struct TArray<uint8_t> TeammateKillType; // 0x198(0x10)


	// Object: Function HiggsBoson.SecurityImprisonComp.ReleaseTeammate
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x104851558
	// Params: [ Num(1) Size(0x8) ]
	void ReleaseTeammate(uint64_t PlayerUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function HiggsBoson.SecurityImprisonComp.ImprisonmentUIUpdate
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104851490
	// Params: [ Num(2) Size(0x9) ]
	void ImprisonmentUIUpdate(uint64_t PlayerUID, bool bIsImprison);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function HiggsBoson.SecurityImprisonComp.ImprisonmentTeammate
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1048513c8
	// Params: [ Num(2) Size(0x9) ]
	void ImprisonmentTeammate(uint64_t PlayerUID, bool bIscomplaint);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C

	// Object: Function HiggsBoson.SecurityImprisonComp.ImprisonmentReport
	// Flags: [Final|Native|Public]
	// Offset: 0x10485134c
	// Params: [ Num(1) Size(0x8) ]
	void ImprisonmentReport(uint64_t PlayerUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104830240
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
};

// Object: Class HiggsBoson.TickAsTimer
// Size: 0x28 (Inherited: 0x28)
struct UTickAsTimer : UObject
{
};

// Object: Class HiggsBoson.TimeIntervalPawnStateHistorySystem
// Size: 0xF8 (Inherited: 0x28)
struct UTimeIntervalPawnStateHistorySystem : UObject
{
	uint8_t Pad_0x28[0x50]; // 0x28(0x50)
	int HistoryArraySize; // 0x78(0x4)
	uint8_t Pad_0x7C[0x7C]; // 0x7C(0x7C)


	// Object: Function HiggsBoson.TimeIntervalPawnStateHistorySystem.UpdateParams
	// Flags: [Final|Native|Private]
	// Offset: 0x104851ab4
	// Params: [ Num(0) Size(0x0) ]
	void UpdateParams();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10518366C
	// [Call #6] RVA: 0x10518366C
	// [Call #7] RVA: 0x1048526D0
	// [Call #8] RVA: 0x104851CB0
	// [Call #9] RVA: 0x101F8305C
	// [Call #10] RVA: 0x101F832EC
	// [Call #11] RVA: 0x106C8459C

	// Object: Function HiggsBoson.TimeIntervalPawnStateHistorySystem.QueryHistoryMaxVelocity
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x10485191c
	// Params: [ Num(6) Size(0x19) ]
	bool QueryHistoryMaxVelocity(uint64_t UID, float CenterTime, float MarginTime, float& OutMaxZVelocity, float& OutMaxXYVelocity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1048339E8
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

