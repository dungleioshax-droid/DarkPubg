#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LevelUnLockAnimConfig_type.BP_STRUCT_LevelUnLockAnimConfig_type
// Size: 0x3C (Inherited: 0x0)
struct FBP_STRUCT_LevelUnLockAnimConfig_type
{
	struct FString AnimTargetOffset_0_6979A2002475EDFE470D79C20FBB2FC4; // 0x0(0x10)
	struct FString AnimTargetUIConfig_1_32F425406D740B4F300BF26C0A744387; // 0x10(0x10)
	struct FString AnimTargetWidget_2_68CBE1407FA7EC076639EF3F0F385BC4; // 0x20(0x10)
	int ID_3_5305B08075A4B66E4665B91D0F444FC4; // 0x30(0x4)
	int LobbyType_4_0B3E13C013D720F14799826F0CDBC4C5; // 0x34(0x4)
	int SystemID_5_101131C01C105D75320550F40FEF0F14; // 0x38(0x4)
};

