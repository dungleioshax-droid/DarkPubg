#pragma once

#include <cstdint>

// Object: Class HelpshiftUE4.HelpshiftUE4Settings
// Size: 0x70 (Inherited: 0x28)
struct UHelpshiftUE4Settings : UObject
{
	struct FString APIKey; // 0x28(0x10)
	struct FString DomainName; // 0x38(0x10)
	struct FString AppID_iOS; // 0x48(0x10)
	struct FString AppID_Android; // 0x58(0x10)
	bool FirebaseIntegration; // 0x68(0x1)
	bool EnableLogging; // 0x69(0x1)
	uint8_t Pad_0x6A[0x6]; // 0x6A(0x6)
};

