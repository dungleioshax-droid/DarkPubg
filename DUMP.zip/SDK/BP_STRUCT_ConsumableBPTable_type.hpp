#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_ConsumableBPTable_type.BP_STRUCT_ConsumableBPTable_type
// Size: 0x48 (Inherited: 0x0)
struct FBP_STRUCT_ConsumableBPTable_type
{
	struct FString CName_0_3A46A7E346B57C4E5F45619DF5906006; // 0x0(0x10)
	struct FString Path_1_81463AA644426E53AF3240A311C1D4E0; // 0x10(0x10)
	int ID_2_AD337FD040A1235FE67F55BBA677262B; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString Wrapper_3_66935E806EA99C4E6B9844A505FF3052; // 0x28(0x10)
	struct FString LobbyPath_4_60DFC780056E426A3B985A350FD8F288; // 0x38(0x10)
};

