#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// Size: 0x10 (Inherited: 0x0)
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString TextValue_0_4D37165A410D67320AF278A1C1028E4F; // 0x0(0x10)
};

