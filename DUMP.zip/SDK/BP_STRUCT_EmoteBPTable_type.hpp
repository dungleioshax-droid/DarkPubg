#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_EmoteBPTable_type.BP_STRUCT_EmoteBPTable_type
// Size: 0x88 (Inherited: 0x0)
struct FBP_STRUCT_EmoteBPTable_type
{
	struct FString Path_0_247605C000C1809320361CC70BC26958; // 0x0(0x10)
	struct FString CName_1_20BFF38058E1993E3181765E0C385985; // 0x10(0x10)
	int ID_2_6D1FE5C03D4B9B6365DA363A01FBC3D4; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FString LobbyPath_3_17CBE3C0186812E1377BBB6D07222BE8; // 0x28(0x10)
	struct FString LobbyEmoteAdapt_4_6274998039C4B44E5D4A1AFE0DB5A954; // 0x38(0x10)
	struct FString BattleLowPath_5_4F3B89400282AC756B607A450BF84618; // 0x48(0x10)
	struct FString PathHigh_6_050CC5C0133BD80B2E9B638909572DB8; // 0x58(0x10)
	struct FString EmoteCollisionBox_7_694DF6406325C17B04D93B540C600578; // 0x68(0x10)
	struct FString EmoteCollisionCenterOffset_8_1BBE3E0042190C225D66B4B007074504; // 0x78(0x10)
};

