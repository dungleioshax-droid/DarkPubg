#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_ReddotArgs_type.BP_STRUCT_ReddotArgs_type
// Size: 0x2C (Inherited: 0x0)
struct FBP_STRUCT_ReddotArgs_type
{
	struct FString Desc_0_439D61002282DEAA74C02F5C063A5C03; // 0x0(0x10)
	int ID_1_55BC6480323F81A02F5ECCBD00963A24; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString Type_2_5449C9C01D6C435B74D8C98C063B50F5; // 0x18(0x10)
	int Value_3_4C03008036F08F166DD7613003B38AD5; // 0x28(0x4)
};

