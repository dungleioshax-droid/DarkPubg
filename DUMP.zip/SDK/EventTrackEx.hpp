#pragma once

#include <cstdint>

// Object: Enum EventTrackEx.EXTQTEOperationArea
enum class EXTQTEOperationArea : uint8_t
{
	Random = 1,
	Left = 2,
	Right = 3,
	EXTQTEOperationArea_MAX = 4
};

// Object: ScriptStruct EventTrackEx.MovieSceneXTEventSectionData
// Size: 0x20 (Inherited: 0x0)
struct FMovieSceneXTEventSectionData
{
	struct TArray<float> KeyTimes; // 0x0(0x10)
	struct TArray<struct FXTEventPayload> KeyValues; // 0x10(0x10)
};

// Object: ScriptStruct EventTrackEx.XTEventPayload
// Size: 0x78 (Inherited: 0x0)
struct FXTEventPayload
{
	struct FName EventName; // 0x0(0x8)
	struct FString MsgName; // 0x8(0x10)
	struct FString Param1; // 0x18(0x10)
	struct FString Param2; // 0x28(0x10)
	struct FString Param3; // 0x38(0x10)
	struct FString Param4; // 0x48(0x10)
	struct FString Param5; // 0x58(0x10)
	struct FString Param6; // 0x68(0x10)
};

// Object: ScriptStruct EventTrackEx.MovieSceneXTEventSectionTemplate
// Size: 0x50 (Inherited: 0x18)
struct FMovieSceneXTEventSectionTemplate : FMovieSceneEvalTemplate
{
	struct FMovieSceneXTEventSectionData EventData; // 0x18(0x20)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x38(0x10)
	uint8_t bFireEventsWhenForwards : 1; // 0x48(0x1), Mask(0x1)
	uint8_t bFireEventsWhenBackwards : 1; // 0x48(0x1), Mask(0x2)
	uint8_t BitPad_0x48_2 : 6; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: ScriptStruct EventTrackEx.MovieSceneXTQTETemplate
// Size: 0x20 (Inherited: 0x18)
struct FMovieSceneXTQTETemplate : FMovieSceneEvalTemplate
{
	struct UMovieSceneXTQTESection* Section; // 0x18(0x8)
};

// Object: Class EventTrackEx.MovieSceneXTEventSection
// Size: 0x1C0 (Inherited: 0xB0)
struct UMovieSceneXTEventSection : UMovieSceneSection
{
	struct FNameCurve Events; // 0xB0(0x68)
	struct FMovieSceneXTEventSectionData EventData; // 0x118(0x20)
	uint8_t Pad_0x138[0x88]; // 0x138(0x88)
};

// Object: Class EventTrackEx.MovieSceneXTEventTrack
// Size: 0x78 (Inherited: 0x58)
struct UMovieSceneXTEventTrack : UMovieSceneNameableTrack
{
	uint8_t bFireEventsWhenForwards : 1; // 0x55(0x1), Mask(0x1)
	uint8_t bFireEventsWhenBackwards : 1; // 0x55(0x1), Mask(0x2)
	uint8_t EventPosition; // 0x56(0x1)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x58(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x68(0x10)
};

// Object: Class EventTrackEx.MovieSceneXTQTESection
// Size: 0xD8 (Inherited: 0xB0)
struct UMovieSceneXTQTESection : UMovieSceneSection
{
	struct FString MsgName; // 0xB0(0x10)
	struct TArray<float> Times; // 0xC0(0x10)
	uint8_t OperationArea; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
};

// Object: Class EventTrackEx.MovieSceneXTQTETrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneXTQTETrack : UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

