#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_UIElemLayoutDetail.BP_STRUCT_UIElemLayoutDetail
// Size: 0x30 (Inherited: 0x0)
struct FBP_STRUCT_UIElemLayoutDetail
{
	int Type_23_55DBE0E544DAFBECC9EFB6BB17ABA028; // 0x0(0x4)
	struct FVector2D Scale_17_041C81B04F88C44906CC9C9124ED2CF5; // 0x4(0x8)
	float Opacity_7_DA1E8BC343F74DC18A9B0FBB6DA17CCB; // 0xC(0x4)
	struct FAnchors AnchorType_16_8C6A88824F5B4009F1532EBCA05CA534; // 0x10(0x10)
	struct FVector2D RelativePos_19_41E2D4F647EC741044D6AC9C8DD94ED4; // 0x20(0x8)
	struct FVector2D OriginSize_22_61D9CB8A48FFB415806311A1771BDF74; // 0x28(0x8)
};

