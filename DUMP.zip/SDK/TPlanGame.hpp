#pragma once

#include <cstdint>

// Object: ScriptStruct TPlanGame.PreciousItem
// Size: 0xC (Inherited: 0x0)
struct FPreciousItem
{
	int TypeSpecificID; // 0x0(0x4)
	int Count; // 0x4(0x4)
	int SellPrice; // 0x8(0x4)
};

// Object: ScriptStruct TPlanGame.XTBetrayInfo
// Size: 0x8 (Inherited: 0x0)
struct FXTBetrayInfo
{
	bool IsInBetray; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int BetrayTime; // 0x4(0x4)
};

// Object: ScriptStruct TPlanGame.SyncRelevantPlayerTask
// Size: 0x18 (Inherited: 0x0)
struct FSyncRelevantPlayerTask
{
	int TaskID; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<struct AActor*> TaskTargets; // 0x8(0x10)
};

// Object: Class TPlanGame.BackpackComponentTPlan
// Size: 0x5F0 (Inherited: 0x5F0)
struct UBackpackComponentTPlan : UBackpackComponent
{
	bool bForbidSafeBox; // 0x5E9(0x1)


	// Object: Function TPlanGame.BackpackComponentTPlan.PickupItemFromWrapperDetail
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102831164
	// Params: [ Num(5) Size(0x73) ]
	bool PickupItemFromWrapperDetail(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason, uint8_t BattleItemClientPickupType);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1023C52B8
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function TPlanGame.BackpackComponentTPlan.PickItem_IntoSafetyBox
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102830ff8
	// Params: [ Num(4) Size(0x72) ]
	bool PickItem_IntoSafetyBox(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, uint8_t Reason);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102406800
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1023C52B8
	// [Call #10] RVA: 0x1023C52B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102406800
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function TPlanGame.BackpackComponentTPlan.NotifyItemUpdated
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102830f60
	// Params: [ Num(1) Size(0x18) ]
	void NotifyItemUpdated(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102406800
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1023C52B8
	// [Call #13] RVA: 0x1023C52B8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x1041EFFBC
	// [Call #16] RVA: 0x10516D168

	// Object: Function TPlanGame.BackpackComponentTPlan.NotifyItemRemoved
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102830ec8
	// Params: [ Num(1) Size(0x18) ]
	void NotifyItemRemoved(struct FItemDefineID& DefineID);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102406800
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function TPlanGame.BackpackComponentTPlan.NotifyItemListUpdated
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102830eac
	// Params: [ Num(0) Size(0x0) ]
	void NotifyItemListUpdated();
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1041EFFBC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1041EFFBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102406800
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function TPlanGame.BackpackComponentTPlan.ChangeItemStoreAreaNewInner
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102830d90
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreAreaNewInner(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1041EFFBC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function TPlanGame.BackpackComponentTPlan.ChangeItemStoreAreaNew
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102830c74
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreAreaNew(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664

	// Object: Function TPlanGame.BackpackComponentTPlan.ChangeItemStoreAreaInner
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102830b58
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreAreaInner(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664

	// Object: Function TPlanGame.BackpackComponentTPlan.ChangeItemStoreArea
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102830a3c
	// Params: [ Num(4) Size(0x1E) ]
	bool ChangeItemStoreArea(struct FItemDefineID DefineID, int InItemNum, uint8_t InItemStoreArea);
	// [Call #1] RVA: 0x1041EFFBC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1041E5664
	// [Call #9] RVA: 0x1041EFFBC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1041E5664
};

// Object: Class TPlanGame.BackpackTPlanUtils
// Size: 0x28 (Inherited: 0x28)
struct UBackpackTPlanUtils : UBlueprintFunctionLibrary
{

	// Object: Function TPlanGame.BackpackTPlanUtils.UnRegisterInvokeClass
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102831774
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterInvokeClass();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function TPlanGame.BackpackTPlanUtils.RegisterInvokeClass
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102831760
	// Params: [ Num(0) Size(0x0) ]
	void RegisterInvokeClass();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function TPlanGame.BackpackTPlanUtils.RealGetBPUtils
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10283172c
	// Params: [ Num(1) Size(0x8) ]
	struct UBackpackBlueprintTPlanUtils* RealGetBPUtils();
	// [Call #1] RVA: 0x1028263EC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class TPlanGame.BackpackBlueprintTPlanUtils
// Size: 0xBA0 (Inherited: 0xBA0)
struct UBackpackBlueprintTPlanUtils : UBackpackBlueprintUtils
{
};

// Object: Class TPlanGame.MetroStoreComponent
// Size: 0x280 (Inherited: 0x238)
struct UMetroStoreComponent : ULuaActorComponent
{
	int StoreID; // 0x234(0x4)
	int status; // 0x238(0x4)
	float BuyFrequence; // 0x23C(0x4)
	struct TArray<struct FCurrencyInfo> CurrencyList; // 0x240(0x10)
	struct TArray<struct FGoodsInfo> GoodsList; // 0x250(0x10)
	struct TArray<int> GoodsListNum; // 0x260(0x10)
	struct TArray<int> GoodsNum; // 0x270(0x10)


	// Object: Function TPlanGame.MetroStoreComponent.OnRep_StoreID
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831b24
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_StoreID();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_Status
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831b08
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Status();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_GoodsNum
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831aec
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_GoodsNum();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_GoodsListNum
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831ad0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_GoodsListNum();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_GoodsList
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831ab4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_GoodsList();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_CurrencyList
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831a98
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CurrencyList();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function TPlanGame.MetroStoreComponent.OnRep_BuyFrequence
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102831a7c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_BuyFrequence();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

// Object: Class TPlanGame.TPlanPickupItemUsefulProxy
// Size: 0x378 (Inherited: 0x378)
struct UTPlanPickupItemUsefulProxy : UPickupItemUsefulProxy
{
};

// Object: Class TPlanGame.XTGameMode
// Size: 0x2440 (Inherited: 0x23E8)
struct AXTGameMode : ABattleRoyaleGameModeTeam
{
	struct TArray<struct AActor*> OccupiedPlayerStartGroupList; // 0x23E8(0x10)
	struct TArray<struct ASTExtraPlayerStartGroup*> UnOccupiedPlayerStartGroupList; // 0x23F8(0x10)
	bool IsResetPlayerStart; // 0x2408(0x1)
	uint8_t Pad_0x2409[0x3]; // 0x2409(0x3)
	float LastCheckAITime; // 0x240C(0x4)
	float CheckAIActiveInterval; // 0x2410(0x4)
	float CheckAIActiveRange; // 0x2414(0x4)
	int DogTagID; // 0x2418(0x4)
	int BetrayAIDropID; // 0x241C(0x4)
	int BetrayAIDropDot; // 0x2420(0x4)
	bool bPreSpawnPlayers; // 0x2424(0x1)
	bool bEnableEcapedPlayerInTeam; // 0x2425(0x1)
	bool bZombiePVEMode; // 0x2426(0x1)
	bool bMapLoaded; // 0x2427(0x1)
	int iRandomPolicestationIndex; // 0x2428(0x4)
	uint8_t Pad_0x242C[0x4]; // 0x242C(0x4)
	struct TArray<struct FName> LoadingPlayerState; // 0x2430(0x10)


	// Object: Function TPlanGame.XTGameMode.SetStateLeftTime
	// Flags: [Native|Public]
	// Offset: 0x1028327a0
	// Params: [ Num(1) Size(0x4) ]
	void SetStateLeftTime(int LeftTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameMode.SetPlayerStartOccupied
	// Flags: [Final|Native|Public]
	// Offset: 0x102832724
	// Params: [ Num(1) Size(0x8) ]
	void SetPlayerStartOccupied(struct AActor* PlayerStart);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102826BD8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameMode.RevisePlayerTombBoxDropWrapperList
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x1028325ac
	// Params: [ Num(4) Size(0x24) ]
	void RevisePlayerTombBoxDropWrapperList(struct ASTExtraBaseCharacter* Character, struct TArray<struct FPickUpItemData>& OutItemDataList, struct ASTExtraBaseCharacter* DamageCauser, int InstanceIDCnt);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102834108
	// [Call #10] RVA: 0x102834108
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102826BD8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function TPlanGame.XTGameMode.NotifyPlayerExitWhenNotStarted
	// Flags: [Native|Public]
	// Offset: 0x102832494
	// Params: [ Num(3) Size(0x20) ]
	void NotifyPlayerExitWhenNotStarted(uint32_t PlayerKey, struct FName PlayerType, struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function TPlanGame.XTGameMode.NotifyPlayerExit
	// Flags: [Native|Public]
	// Offset: 0x102832164
	// Params: [ Num(8) Size(0x40) ]
	void NotifyPlayerExit(uint32_t PlayerKey, struct FName PlayerType, bool bDestroyPlayerController, bool bDestroyCharacter, bool bSendFailure, struct FString FailureMessage, struct FName ParamState, struct FString ParamReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x101F8122C

	// Object: Function TPlanGame.XTGameMode.NotifyGameModeInit
	// Flags: [Native|Public]
	// Offset: 0x102832148
	// Params: [ Num(0) Size(0x0) ]
	void NotifyGameModeInit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C

	// Object: Function TPlanGame.XTGameMode.LoadMapFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102832134
	// Params: [ Num(0) Size(0x0) ]
	void LoadMapFinished();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C

	// Object: Function TPlanGame.XTGameMode.IsNeedRestPlayerStart
	// Flags: [Final|Native|Public]
	// Offset: 0x1028320a8
	// Params: [ Num(2) Size(0x9) ]
	bool IsNeedRestPlayerStart(struct AController* Player);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102826B50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function TPlanGame.XTGameMode.GMShowSpawner
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x102832094
	// Params: [ Num(0) Size(0x0) ]
	void GMShowSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102826B50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function TPlanGame.XTGameMode.GMShowEnterExit
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x102832080
	// Params: [ Num(0) Size(0x0) ]
	void GMShowEnterExit();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102826B50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function TPlanGame.XTGameMode.GMShowAssetBox
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x10283206c
	// Params: [ Num(0) Size(0x0) ]
	void GMShowAssetBox();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102826B50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function TPlanGame.XTGameMode.GMSetPVEAIMax
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x102831ff0
	// Params: [ Num(1) Size(0x4) ]
	void GMSetPVEAIMax(int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102827308
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102826B50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function TPlanGame.XTGameMode.GetOccupiedPlayerStartGroupList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102831f8c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetOccupiedPlayerStartGroupList();
	// [Call #1] RVA: 0x1028340B4
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102827308
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102826B50
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function TPlanGame.XTGameMode.CheckNoHumanExist
	// Flags: [Native|Public]
	// Offset: 0x102831f50
	// Params: [ Num(1) Size(0x1) ]
	bool CheckNoHumanExist();
	// [Call #1] RVA: 0x1028340B4
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102827308
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102826B50
	// [Call #12] RVA: 0x10516D168

	// Object: Function TPlanGame.XTGameMode.CheckAIActive
	// Flags: [Final|Native|Public]
	// Offset: 0x102831f3c
	// Params: [ Num(0) Size(0x0) ]
	void CheckAIActive();
	// [Call #1] RVA: 0x1028340B4
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102827308
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102826B50
};

// Object: Class TPlanGame.XTGameModeStateFightingTeam
// Size: 0xD8 (Inherited: 0xD8)
struct UXTGameModeStateFightingTeam : UGameModeStateFightingTeam
{
};

// Object: Class TPlanGame.XTGameModeStateFinished
// Size: 0xC0 (Inherited: 0xC0)
struct UXTGameModeStateFinished : UGameModeStateFinishedTeam
{
};

// Object: Class TPlanGame.XTGameModeStateReady
// Size: 0x118 (Inherited: 0x118)
struct UXTGameModeStateReady : UGameModeStateReady
{
};

// Object: Class TPlanGame.XTGameState
// Size: 0x1678 (Inherited: 0x1620)
struct AXTGameState : ASTExtraGameStateBase
{
	float LastLeaveTime; // 0x1620(0x4)
	uint8_t Pad_0x1624[0x4]; // 0x1624(0x4)
	struct TMap<int, int> PreciousItemMap; // 0x1628(0x50)


	// Object: Function TPlanGame.XTGameState.ResetLeftTime
	// Flags: [Final|Native|Public]
	// Offset: 0x1028332d0
	// Params: [ Num(0) Size(0x0) ]
	void ResetLeftTime();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameState.PreLoadPreciousItemsMap
	// Flags: [Final|Native|Public]
	// Offset: 0x1028332bc
	// Params: [ Num(0) Size(0x0) ]
	void PreLoadPreciousItemsMap();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameState.OnRep_LastLeaveTime
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1028332a0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LastLeaveTime();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameState.GetPlayerMilitartyOnClient
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102833264
	// Params: [ Num(1) Size(0x4) ]
	int GetPlayerMilitartyOnClient();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameState.CheckPreciousItemPrice
	// Flags: [Final|Native|Public]
	// Offset: 0x1028331d8
	// Params: [ Num(2) Size(0x8) ]
	int CheckPreciousItemPrice(int TypeSpecificID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102829A44
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.XTGameState.BroadcastClimbHelicopter
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|NetValidate]
	// Offset: 0x10283311c
	// Params: [ Num(2) Size(0x10) ]
	void BroadcastClimbHelicopter(struct ASTExtraPlayerCharacter* Character, struct AActor* ExitActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102829A44
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
};

// Object: Class TPlanGame.XTPlayerState
// Size: 0x1D28 (Inherited: 0x1CD8)
struct AXTPlayerState : ASTExtraPlayerState
{
	struct TArray<struct FSyncRelevantPlayerTask> SyncRelevantPlayerTask; // 0x1CD8(0x10)
	struct TArray<struct FVector> EscapePosi; // 0x1CE8(0x10)
	int BetrayDefaultTime; // 0x1CF8(0x4)
	uint8_t Pad_0x1CFC[0x4]; // 0x1CFC(0x4)
	uint64_t Gold; // 0x1D00(0x8)
	bool bIsEscaped; // 0x1D08(0x1)
	bool bIsRunAway; // 0x1D09(0x1)
	uint8_t Pad_0x1D0A[0x6]; // 0x1D0A(0x6)
	struct TArray<int> AssetPointsCheckedByTeammate; // 0x1D10(0x10)
	struct FXTBetrayInfo BetrayInfo; // 0x1D20(0x8)


	// Object: Function TPlanGame.XTPlayerState.OnRepXTBetrayInfo
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRepXTBetrayInfo();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function TPlanGame.XTPlayerState.OnRepRelevantPlayerTaskNotifyBP
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRepRelevantPlayerTaskNotifyBP();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function TPlanGame.XTPlayerState.OnRepEscapePosition
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRepEscapePosition();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function TPlanGame.XTPlayerState.OnRepAssetPointsCheckedByTeammate
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRepAssetPointsCheckedByTeammate();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function TPlanGame.XTPlayerState.OnRep_RelevantPlayerTaskNotify
	// Flags: [Final|Native|Public]
	// Offset: 0x102833a8c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_RelevantPlayerTaskNotify();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_IsRunAway
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102833a70
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsRunAway();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_IsEscaped
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102833a54
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_IsEscaped();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_Gold
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102833a38
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_Gold();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_EscapePosiNotify
	// Flags: [Final|Native|Public]
	// Offset: 0x102833a24
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_EscapePosiNotify();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_BetrayInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x102833a10
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_BetrayInfo();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnRep_AssetPointsCheckedByTeammate
	// Flags: [Final|Native|Public]
	// Offset: 0x1028339fc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_AssetPointsCheckedByTeammate();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.OnPlayerEscaped
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnPlayerEscaped();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function TPlanGame.XTPlayerState.IsInGame
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1028339c0
	// Params: [ Num(1) Size(0x1) ]
	bool IsInGame();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.IsInBetrayState
	// Flags: [Native|Public]
	// Offset: 0x102833984
	// Params: [ Num(1) Size(0x1) ]
	bool IsInBetrayState();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C

	// Object: Function TPlanGame.XTPlayerState.GetAllPreciousItemsList
	// Flags: [Final|Native|Public]
	// Offset: 0x102833920
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FPreciousItem> GetAllPreciousItemsList();
	// [Call #1] RVA: 0x10282A4A8
	// [Call #2] RVA: 0x1028346B0
	// [Call #3] RVA: 0x10282D160
	// [Call #4] RVA: 0x10282D160
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
};

