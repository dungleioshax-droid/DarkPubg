#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_TransSupportConfig_VNG_type.BP_STRUCT_TransSupportConfig_VNG_type
// Size: 0x40 (Inherited: 0x0)
struct FBP_STRUCT_TransSupportConfig_VNG_type
{
	struct FString languageCode_0_304AFE8018A810121E76A0640E962C35; // 0x0(0x10)
	int languageID_1_5EE4C3007F0B28564BBEEDDA099E9654; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString abbreviation_2_165B2C4025E15717066345A104E9F1BE; // 0x18(0x10)
	bool isSupported_3_764957401C185393258AE03A06008C04; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FString displayName_4_47ECCC80441140EA6B09913A0001D215; // 0x30(0x10)
};

