#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehicleRefitPatternTable_type.BP_STRUCT_VehicleRefitPatternTable_type
// Size: 0x58 (Inherited: 0x0)
struct FBP_STRUCT_VehicleRefitPatternTable_type
{
	int IconScale2_0_46572E4071F9B3293BE305FF087656B2; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString IconPath2_1_024EF7804CE8216627C3CAFF038879F2; // 0x8(0x10)
	int IconScale1_2_46562E0071F9B3283BE305F8087656B1; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString IconPath1_3_024DF7404CE8216527C3CAFC038879F1; // 0x20(0x10)
	int ID_4_3B4768C07AEB475737EB9B560A7BEF14; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FString IconOffset_5_59F5A18037D665B02424026A0AB3EDF4; // 0x38(0x10)
	struct FString PatternBPPath_6_4B5944C06FBA413D7EB727A808597AD8; // 0x48(0x10)
};

