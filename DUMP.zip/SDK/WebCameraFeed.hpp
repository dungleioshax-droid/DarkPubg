#pragma once

#include <cstdint>

// Object: Enum WebCameraFeed.EVideoPixelFormat
enum class EVideoPixelFormat : uint8_t
{
	GrayScale = 0,
	Rgb = 1,
	Rgba = 2,
	EVideoPixelFormat_MAX = 3
};

// Object: ScriptStruct WebCameraFeed.WebCameraDeviceId
// Size: 0x4 (Inherited: 0x0)
struct FWebCameraDeviceId
{
	int selectedDevice; // 0x0(0x4)
};

// Object: ScriptStruct WebCameraFeed.VideoDevice
// Size: 0x50 (Inherited: 0x0)
struct FVideoDevice
{
	uint8_t Pad_0x0[0x50]; // 0x0(0x50)
};

// Object: ScriptStruct WebCameraFeed.VideoFormat
// Size: 0x20 (Inherited: 0x0)
struct FVideoFormat
{
	uint8_t Pad_0x0[0x20]; // 0x0(0x20)
};

// Object: Class WebCameraFeed.WebCameraWidget
// Size: 0x200 (Inherited: 0x100)
struct UWebCameraWidget : UWidget
{
	struct FWebCameraDeviceId DeviceID; // 0x100(0x4)
	int requestedWidth; // 0x104(0x4)
	int requestedHeight; // 0x108(0x4)
	bool ScanningQRCode; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	DelegateProperty OnScanningSuccess; // 0x110(0x10)
	uint8_t Pad_0x120[0xE0]; // 0x120(0xE0)


	// Object: Function WebCameraFeed.WebCameraWidget.UnLockScreenOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd7ac
	// Params: [ Num(0) Size(0x0) ]
	void UnLockScreenOrientation();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.SwitchFrontAndBackCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd778
	// Params: [ Num(1) Size(0x1) ]
	bool SwitchFrontAndBackCamera();
	// [Call #1] RVA: 0x102BFB130
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.SetDeviceId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd6fc
	// Params: [ Num(1) Size(0x4) ]
	void SetDeviceId(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB178
	// [Call #4] RVA: 0x102BFB130
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102bfd680
	// Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB1DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102BFB178
	// [Call #7] RVA: 0x102BFB130
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.SaveAsImage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd5d8
	// Params: [ Num(2) Size(0x11) ]
	bool SaveAsImage(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB1EC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BFB1DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BFB178
	// [Call #13] RVA: 0x102BFB130
	// [Call #14] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.ReleaseVideoGrabber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd5c4
	// Params: [ Num(0) Size(0x0) ]
	void ReleaseVideoGrabber();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB1EC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BFB1DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BFB178
	// [Call #13] RVA: 0x102BFB130
	// [Call #14] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.LockScreenOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd5b0
	// Params: [ Num(0) Size(0x0) ]
	void LockScreenOrientation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB1EC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BFB1DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BFB178
	// [Call #13] RVA: 0x102BFB130
	// [Call #14] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.InitVideoGrabber
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd59c
	// Params: [ Num(0) Size(0x0) ]
	void InitVideoGrabber();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102BFB1EC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102BFB1DC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102BFB178
	// [Call #13] RVA: 0x102BFB130
	// [Call #14] RVA: 0x10519022C

	// Object: Function WebCameraFeed.WebCameraWidget.GetFrontCameraId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd568
	// Params: [ Num(1) Size(0x4) ]
	int GetFrontCameraId();
	// [Call #1] RVA: 0x102BFB148
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102BFB1EC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102BFB1DC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102BFB178
	// [Call #14] RVA: 0x102BFB130

	// Object: Function WebCameraFeed.WebCameraWidget.GetBackCameraId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bfd534
	// Params: [ Num(1) Size(0x4) ]
	int GetBackCameraId();
	// [Call #1] RVA: 0x102BFB160
	// [Call #2] RVA: 0x102BFB148
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102BFB1EC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102BFB1DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102BFB178
};

