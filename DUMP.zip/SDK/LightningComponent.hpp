#pragma once

#include <cstdint>

// Object: Class LightningComponent.LightningActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct ALightningActor : AActor
{
	struct ULightningComponent* LightningComponent; // 0x4B0(0x8)
};

// Object: Class LightningComponent.LightningComponent
// Size: 0xAE0 (Inherited: 0xA20)
struct ULightningComponent : UMeshComponent
{
	int MaxFractalTime; // 0xA20(0x4)
	int PatternMask; // 0xA24(0x4)
	float LightningWidth; // 0xA28(0x4)
	float WidthDecay; // 0xA2C(0x4)
	float BrightnessDecay; // 0xA30(0x4)
	bool bShrinkWidth; // 0xA34(0x1)
	uint8_t Pad_0xA35[0x3]; // 0xA35(0x3)
	int AtlasNum; // 0xA38(0x4)
	struct FVector SeedStart; // 0xA3C(0xC)
	struct FVector SeedEnd; // 0xA48(0xC)
	struct FVector2D ZigZagFraction; // 0xA54(0x8)
	struct FVector2D ZigZagDeviationRight; // 0xA5C(0x8)
	struct FVector2D ZigZagDeviationUp; // 0xA64(0x8)
	float ZigZagDeviationDecay; // 0xA6C(0x4)
	struct FVector2D ForkFraction; // 0xA70(0x8)
	struct FVector2D ForkZigZagDeviationRight; // 0xA78(0x8)
	struct FVector2D ForkZigZagDeviationUp; // 0xA80(0x8)
	float ForkZigZagDeviationDecay; // 0xA88(0x4)
	struct FVector2D ForkDeviationRight; // 0xA8C(0x8)
	struct FVector2D ForkDeviationUp; // 0xA94(0x8)
	struct FVector2D ForkDeviationForward; // 0xA9C(0x8)
	float ForkDeviationDecay; // 0xAA4(0x4)
	struct FVector2D ForkLength; // 0xAA8(0x8)
	float ForkLengthDecay; // 0xAB0(0x4)
	uint8_t Pad_0xAB4[0x2C]; // 0xAB4(0x2C)


	// Object: Function LightningComponent.LightningComponent.SetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c8136c
	// Params: [ Num(1) Size(0x4) ]
	void SetWidthDecay(float InDecay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6A4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function LightningComponent.LightningComponent.SetShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c812e8
	// Params: [ Num(1) Size(0x1) ]
	void SetShrinkWidth(bool InBool);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function LightningComponent.LightningComponent.SetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c8126c
	// Params: [ Num(1) Size(0x4) ]
	void SetPatternMask(int InPatternMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E684
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E6A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function LightningComponent.LightningComponent.SetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c811f0
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxFractalTime(int InMaxFractalTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E660
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E684
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E6EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E6A4
	// [Call #13] RVA: 0x10519022C

	// Object: Function LightningComponent.LightningComponent.SetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c81174
	// Params: [ Num(1) Size(0x4) ]
	void SetLightningWidth(float InWidth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E694
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E660
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E684
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E6EC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function LightningComponent.LightningComponent.SetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c810f8
	// Params: [ Num(1) Size(0x4) ]
	void SetBrightnessDecay(float InDecay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E694
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E660
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E684
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function LightningComponent.LightningComponent.SetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c8107c
	// Params: [ Num(1) Size(0x4) ]
	void SetAtlasNum(int InVal);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E660
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function LightningComponent.LightningComponent.RefreshLightningMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c81068
	// Params: [ Num(0) Size(0x0) ]
	void RefreshLightningMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E660
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function LightningComponent.LightningComponent.IsShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c8104c
	// Params: [ Num(1) Size(0x1) ]
	bool IsShrinkWidth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E660
	// [Call #13] RVA: 0x10516D168

	// Object: Function LightningComponent.LightningComponent.GetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c81030
	// Params: [ Num(1) Size(0x4) ]
	float GetWidthDecay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E660

	// Object: Function LightningComponent.LightningComponent.GetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c81014
	// Params: [ Num(1) Size(0x4) ]
	int GetPatternMask();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102C7E660

	// Object: Function LightningComponent.LightningComponent.GetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c80ff8
	// Params: [ Num(1) Size(0x4) ]
	int GetMaxFractalTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function LightningComponent.LightningComponent.GetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c80fdc
	// Params: [ Num(1) Size(0x4) ]
	float GetLightningWidth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
	// [Call #10] RVA: 0x10516D168

	// Object: Function LightningComponent.LightningComponent.GetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c80fc0
	// Params: [ Num(1) Size(0x4) ]
	float GetBrightnessDecay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694

	// Object: Function LightningComponent.LightningComponent.GetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102c80fa0
	// Params: [ Num(1) Size(0x4) ]
	float GetAtlasNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102C7E6FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102C7E6C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102C7E694
};

