#pragma once

#include <cstdint>

// Object: Enum MoviePlayer.EMoviePlaybackType
enum class EMoviePlaybackType : uint8_t
{
	MT_Normal = 0,
	MT_Looped = 1,
	MT_LoadingLoop = 2,
	MT_MAX = 3
};

// Object: Class MoviePlayer.MoviePlayerSettings
// Size: 0x50 (Inherited: 0x28)
struct UMoviePlayerSettings : UObject
{
	bool bWaitForMoviesToComplete; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct TArray<struct FString> bMoviesAreSkippable; // 0x30(0x10)
	struct TArray<struct FString> StartupMovies; // 0x40(0x10)
};

