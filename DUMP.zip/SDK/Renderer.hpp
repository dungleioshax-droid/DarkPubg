#pragma once

#include <cstdint>

// Object: Enum Renderer.ESparseVolumeTexturePreviewAttribute
enum class ESparseVolumeTexturePreviewAttribute : uint8_t
{
	ESVTPA_AttributesA_R = 0,
	ESVTPA_AttributesA_G = 1,
	ESVTPA_AttributesA_B = 2,
	ESVTPA_AttributesA_A = 3,
	ESVTPA_AttributesB_R = 4,
	ESVTPA_AttributesB_G = 5,
	ESVTPA_AttributesB_B = 6,
	ESVTPA_AttributesB_A = 7,
	ESVTPA_MAX = 8
};

// Object: ScriptStruct Renderer.LightPropagationVolumeSettings
// Size: 0x40 (Inherited: 0x0)
struct FLightPropagationVolumeSettings
{
	uint8_t bOverride_LPVIntensity : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bOverride_LPVDirectionalOcclusionIntensity : 1; // 0x0(0x1), Mask(0x2)
	uint8_t bOverride_LPVDirectionalOcclusionRadius : 1; // 0x0(0x1), Mask(0x4)
	uint8_t bOverride_LPVDiffuseOcclusionExponent : 1; // 0x0(0x1), Mask(0x8)
	uint8_t bOverride_LPVSpecularOcclusionExponent : 1; // 0x0(0x1), Mask(0x10)
	uint8_t bOverride_LPVDiffuseOcclusionIntensity : 1; // 0x0(0x1), Mask(0x20)
	uint8_t bOverride_LPVSpecularOcclusionIntensity : 1; // 0x0(0x1), Mask(0x40)
	uint8_t bOverride_LPVSize : 1; // 0x0(0x1), Mask(0x80)
	uint8_t bOverride_LPVSecondaryOcclusionIntensity : 1; // 0x1(0x1), Mask(0x1)
	uint8_t bOverride_LPVSecondaryBounceIntensity : 1; // 0x1(0x1), Mask(0x2)
	uint8_t bOverride_LPVGeometryVolumeBias : 1; // 0x1(0x1), Mask(0x4)
	uint8_t bOverride_LPVVplInjectionBias : 1; // 0x1(0x1), Mask(0x8)
	uint8_t bOverride_LPVEmissiveInjectionIntensity : 1; // 0x1(0x1), Mask(0x10)
	uint8_t BitPad_0x1_5 : 3; // 0x1(0x1)
	uint8_t Pad_0x2[0x2]; // 0x2(0x2)
	float LPVIntensity; // 0x4(0x4)
	float LPVVplInjectionBias; // 0x8(0x4)
	float LPVSize; // 0xC(0x4)
	float LPVSecondaryOcclusionIntensity; // 0x10(0x4)
	float LPVSecondaryBounceIntensity; // 0x14(0x4)
	float LPVGeometryVolumeBias; // 0x18(0x4)
	float LPVEmissiveInjectionIntensity; // 0x1C(0x4)
	float LPVDirectionalOcclusionIntensity; // 0x20(0x4)
	float LPVDirectionalOcclusionRadius; // 0x24(0x4)
	float LPVDiffuseOcclusionExponent; // 0x28(0x4)
	float LPVSpecularOcclusionExponent; // 0x2C(0x4)
	float LPVDiffuseOcclusionIntensity; // 0x30(0x4)
	float LPVSpecularOcclusionIntensity; // 0x34(0x4)
	float LPVFadeRange; // 0x38(0x4)
	float LPVDirectionalOcclusionFadeRange; // 0x3C(0x4)
};

// Object: Class Renderer.SparseVolumeTextureViewerComponent
// Size: 0xA00 (Inherited: 0x9D0)
struct USparseVolumeTextureViewerComponent : UPrimitiveComponent
{
	struct USparseVolumeTexture* SparseVolumeTexturePreview; // 0x9C8(0x8)
	float Frame; // 0x9D0(0x4)
	float FrameRate; // 0x9D4(0x4)
	uint8_t bPlayIng : 1; // 0x9D8(0x1), Mask(0x1)
	uint8_t bLooping : 1; // 0x9D8(0x1), Mask(0x2)
	uint8_t bReversePlayback : 1; // 0x9D8(0x1), Mask(0x4)
	uint8_t bBlockingStreamingRequests : 1; // 0x9D8(0x1), Mask(0x8)
	uint8_t bApplyPerFrameTransforms : 1; // 0x9D8(0x1), Mask(0x10)
	uint8_t bPivotAtCentroid : 1; // 0x9D8(0x1), Mask(0x20)
	float VoxelSize; // 0x9DC(0x4)
	uint8_t PreviewAttribute; // 0x9E0(0x1)
	int MipLevel; // 0x9E4(0x4)
	float Extinction; // 0x9E8(0x4)
	uint8_t BitPad_0x9ED_6 : 2; // 0x9ED(0x1)
	uint8_t Pad_0x9EE[0x12]; // 0x9EE(0x12)
};

// Object: Class Renderer.SparseVolumeTextureViewer
// Size: 0x4B8 (Inherited: 0x4B0)
struct ASparseVolumeTextureViewer : AInfo
{
	struct USparseVolumeTextureViewerComponent* SparseVolumeTextureViewerComponent; // 0x4B0(0x8)
};

