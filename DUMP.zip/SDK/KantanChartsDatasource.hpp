#pragma once

#include <cstdint>

// Object: ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// Size: 0x8 (Inherited: 0x0)
struct FKantanCartesianDatapoint
{
	struct FVector2D Coords; // 0x0(0x8)
};

// Object: Class KantanChartsDatasource.KantanCartesianDatasourceInterface
// Size: 0x28 (Inherited: 0x28)
struct IKantanCartesianDatasourceInterface : IInterface
{

	// Object: Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesName
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205c48c
	// Params: [ Num(2) Size(0x20) ]
	struct FText GetSeriesName(int SeriesIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F4CC
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesId
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205c3f8
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetSeriesId(int CatIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104F0F4CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesDatapoints
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205c33c
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FKantanCartesianDatapoint> GetSeriesDatapoints(int SeriesIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10205C8E8
	// [Call #4] RVA: 0x10205AC3C
	// [Call #5] RVA: 0x10205AC3C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104F0F4CC
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetNumSeries
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205c300
	// Params: [ Num(1) Size(0x4) ]
	int GetNumSeries();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10205C8E8
	// [Call #4] RVA: 0x10205AC3C
	// [Call #5] RVA: 0x10205AC3C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104F0F4CC
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
};

// Object: Class KantanChartsDatasource.KantanCategoryDatasourceInterface
// Size: 0x28 (Inherited: 0x28)
struct IKantanCategoryDatasourceInterface : IInterface
{

	// Object: Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetNumCategories
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205ccb8
	// Params: [ Num(1) Size(0x4) ]
	int GetNumCategories();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryValue
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205cc24
	// Params: [ Num(2) Size(0x8) ]
	float GetCategoryValue(int CatIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryName
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205cb68
	// Params: [ Num(2) Size(0x20) ]
	struct FText GetCategoryName(int CatIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F4CC
	// [Call #4] RVA: 0x101FBDBE8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryId
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10205cad4
	// Params: [ Num(2) Size(0x10) ]
	struct FName GetCategoryId(int CatIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104F0F4CC
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10519022C
};

// Object: Class KantanChartsDatasource.KantanSimpleCartesianDatasource
// Size: 0x40 (Inherited: 0x28)
struct UKantanSimpleCartesianDatasource : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)


	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.NewSimpleCartesianDatasource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10205d618
	// Params: [ Num(1) Size(0x8) ]
	struct UKantanSimpleCartesianDatasource* NewSimpleCartesianDatasource();
	// [Call #1] RVA: 0x10205A32C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_RemoveSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205d550
	// Params: [ Num(2) Size(0x9) ]
	void BP_RemoveSeries(struct FName ID, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10205A538
	// [Call #6] RVA: 0x10205A32C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_RemoveAllSeries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10205d53c
	// Params: [ Num(0) Size(0x0) ]
	void BP_RemoveAllSeries();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10205A538
	// [Call #6] RVA: 0x10205A32C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddSeriesWithId
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205d3e4
	// Params: [ Num(3) Size(0x21) ]
	void BP_AddSeriesWithId(struct FName ID, struct FText Name, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104F0F458
	// [Call #9] RVA: 0x10205A3CC
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10205A538
	// [Call #20] RVA: 0x10205A32C

	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205d2cc
	// Params: [ Num(2) Size(0x20) ]
	void BP_AddSeries(struct FText Name, struct FName& SeriesId);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104F0F458
	// [Call #7] RVA: 0x10205A4C4
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104F0F380
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x10205A3CC
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8

	// Object: Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddDatapoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10205d1b4
	// Params: [ Num(3) Size(0x11) ]
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10205A578
	// [Call #8] RVA: 0x104F0F380
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104F0F458
	// [Call #14] RVA: 0x10205A4C4
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x106C8459C
};

// Object: Class KantanChartsDatasource.KantanSimpleCategoryDatasource
// Size: 0x40 (Inherited: 0x28)
struct UKantanSimpleCategoryDatasource : UObject
{
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)


	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.NewSimpleCategoryDatasource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10205dd70
	// Params: [ Num(1) Size(0x8) ]
	struct UKantanSimpleCategoryDatasource* NewSimpleCategoryDatasource();
	// [Call #1] RVA: 0x10205A6D8
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_UpdateCategoryValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205dc6c
	// Params: [ Num(3) Size(0xD) ]
	void BP_UpdateCategoryValue(struct FName ID, float Value, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10205A924
	// [Call #8] RVA: 0x10205A6D8
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_RemoveCategory
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205dba4
	// Params: [ Num(2) Size(0x9) ]
	void BP_RemoveCategory(struct FName ID, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10205A8E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10205A924
	// [Call #13] RVA: 0x10205A6D8
	// [Call #14] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_RemoveAllCategories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10205db90
	// Params: [ Num(0) Size(0x0) ]
	void BP_RemoveAllCategories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10205A8E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10205A924
	// [Call #13] RVA: 0x10205A6D8
	// [Call #14] RVA: 0x10519022C

	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_AddCategoryWithId
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205da38
	// Params: [ Num(3) Size(0x21) ]
	void BP_AddCategoryWithId(struct FName ID, struct FText Name, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104F0F458
	// [Call #9] RVA: 0x10205A778
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10205A8E4

	// Object: Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_AddCategory
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205d920
	// Params: [ Num(2) Size(0x20) ]
	void BP_AddCategory(struct FText Name, struct FName& CatId);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104F0F458
	// [Call #7] RVA: 0x10205A870
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104F0F380
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x10205A778
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
};

