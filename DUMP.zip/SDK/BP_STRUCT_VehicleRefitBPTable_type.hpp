#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehicleRefitBPTable_type.BP_STRUCT_VehicleRefitBPTable_type
// Size: 0x30 (Inherited: 0x0)
struct FBP_STRUCT_VehicleRefitBPTable_type
{
	struct FString Path_0_367735C04445450711936E2507D65338; // 0x0(0x10)
	int SkinID_1_178D3B00586DF4A03398AF2E06BA7504; // 0x10(0x4)
	int TemplateID_2_188844C035CA84B912116AE102FE3804; // 0x14(0x4)
	int ID_3_7E5115C05AFA7931402A62180B97D7E4; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString LobbyPath_6_1DD513C07D99921F4DE3874A01E3EA48; // 0x20(0x10)
};

