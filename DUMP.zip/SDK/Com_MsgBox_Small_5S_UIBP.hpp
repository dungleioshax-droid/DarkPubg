#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Com_MsgBox_Small_5S_UIBP.Com_MsgBox_Small_5S_UIBP_C
// Size: 0x358 (Inherited: 0x260)
struct UCom_MsgBox_Small_5S_UIBP_C : UUserWidget
{
	struct UWidgetAnimation* Anim_Enter; // 0x260(0x8)
	struct UButton* Button_Cancel; // 0x268(0x8)
	struct UButton* Button_Close; // 0x270(0x8)
	struct UButton* Button_Help; // 0x278(0x8)
	struct UButton* Button_OK; // 0x280(0x8)
	struct UButton* Button_Select; // 0x288(0x8)
	struct UCanvasPanel* CanvasPanel_CD; // 0x290(0x8)
	struct UCanvasPanel* CanvasPanel_Money; // 0x298(0x8)
	struct UCheckBox* CheckBox_Option; // 0x2A0(0x8)
	struct UTextBlock* CheckBox_OptionText; // 0x2A8(0x8)
	struct UCheckBox* CheckBox_Release; // 0x2B0(0x8)
	struct UCommon_BackgroundBlur_5S_C* Common_BackgroundBlur_5S; // 0x2B8(0x8)
	struct UCommon_UIPopupBG_5S_C* Common_UIPopupBG_5S; // 0x2C0(0x8)
	struct UHorizontalBox* dingyue_tips; // 0x2C8(0x8)
	struct UHorizontalBox* HBox_Button; // 0x2D0(0x8)
	struct UCanvasPanel* HorizontalBox_URL; // 0x2D8(0x8)
	struct UImage* Image_2; // 0x2E0(0x8)
	struct UImage* Image_5; // 0x2E8(0x8)
	struct UUTRichTextBlock* RichText_Content; // 0x2F0(0x8)
	struct UUTRichTextBlock* RichText_ContentCentauri; // 0x2F8(0x8)
	struct UUTRichTextBlock* RichText_UrlTips; // 0x300(0x8)
	struct UScrollBox* ScrollBox_0; // 0x308(0x8)
	struct UScrollBox* ScrollBox_Msg; // 0x310(0x8)
	struct UTextBlock* Text_cancel; // 0x318(0x8)
	struct UTextBlock* Text_ok; // 0x320(0x8)
	struct UTextBlock* Text_Title; // 0x328(0x8)
	struct UTextBlock* TextBlock_CD; // 0x330(0x8)
	struct UTextBlock* TextBlock_Money; // 0x338(0x8)
	struct UTextBlock* TextBlock_Name; // 0x340(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Font; // 0x348(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Status; // 0x350(0x8)


	// Object: Function Com_MsgBox_Small_5S_UIBP.Com_MsgBox_Small_5S_UIBP_C.SetButtonOkState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void SetButtonOkState(bool bInIsEnabled);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

