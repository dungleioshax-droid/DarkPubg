#pragma once

#include <cstdint>

// Object: Enum SpawnSystem.ESpeciesOrganization
enum class ESpeciesOrganization : uint8_t
{
	Org_Group = 0,
	Org_Squad = 1,
	Org_Unit = 2,
	Org_MAX = 3
};

// Object: Enum SpawnSystem.ESTSpawnerVolume
enum class ESTSpawnerVolume : uint8_t
{
	ESTSpawnerVolume_None = 0,
	ESTSpawnerVolume_Box = 1,
	ESTSpawnerVolume_Sphere = 2,
	ESTSpawnerVolume_MAX = 3
};

// Object: Enum SpawnSystem.ESpawnSpotType
enum class ESpawnSpotType : uint8_t
{
	Ground = 0,
	Wall = 1,
	Air = 2,
	ESpawnSpotType_MAX = 3
};

// Object: Enum SpawnSystem.EReadSpeciesData
enum class EReadSpeciesData : uint8_t
{
	WeightedRandom = 0,
	Ordered = 1,
	ManuallyIndex = 2,
	EReadSpeciesData_MAX = 3
};

// Object: Enum SpawnSystem.EWaveState
enum class EWaveState : uint8_t
{
	None = 0,
	WaveSpawning = 1,
	WaveSpawned = 2,
	WaveCD = 3,
	WaveReadyForNext = 4,
	EWaveState_MAX = 5
};

// Object: ScriptStruct SpawnSystem.STSpawnParam
// Size: 0xD0 (Inherited: 0x0)
struct FSTSpawnParam
{
	struct FUnitConfig UnitConfig; // 0x0(0x78)
	uint8_t Pad_0x78[0x8]; // 0x78(0x8)
	struct FTransform Transform; // 0x80(0x30)
	int AttributeID; // 0xB0(0x4)
	uint32_t SpawnerID; // 0xB4(0x4)
	struct FString SpotID; // 0xB8(0x10)
	uint8_t Pad_0xC8[0x8]; // 0xC8(0x8)
};

// Object: ScriptStruct SpawnSystem.UnitConfig
// Size: 0x78 (Inherited: 0x0)
struct FUnitConfig
{
	struct FString Desc; // 0x0(0x10)
	int ConfigID; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct TArray<struct FUnitInitConfig> UnitInitConfig; // 0x18(0x10)
	int AttrID; // 0x28(0x4)
	int DropID; // 0x2C(0x4)
	struct FSoftClassPath BPPath; // 0x30(0x18)
	struct FString StrBPPath; // 0x48(0x10)
	bool bTraceGround; // 0x58(0x1)
	uint8_t Pad_0x59[0x7]; // 0x59(0x7)
	struct FString PreferSpotID; // 0x60(0x10)
	int UnitIndex; // 0x70(0x4)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
};

// Object: ScriptStruct SpawnSystem.UnitInitConfig
// Size: 0x18 (Inherited: 0x0)
struct FUnitInitConfig
{
	struct FName BlackboardKey; // 0x0(0x8)
	struct FString Value; // 0x8(0x10)
};

// Object: ScriptStruct SpawnSystem.SpawnSpotInfo
// Size: 0x60 (Inherited: 0x0)
struct FSpawnSpotInfo
{
	struct FTransform Transform; // 0x0(0x30)
	int SpecieSquadIndex; // 0x30(0x4)
	int SpecieUnitIndex; // 0x34(0x4)
	struct FString SpotID; // 0x38(0x10)
	struct TArray<struct FUnitInitConfig> SpotInitConfig; // 0x48(0x10)
	uint8_t Pad_0x58[0x8]; // 0x58(0x8)
};

// Object: ScriptStruct SpawnSystem.SpawnArea
// Size: 0x20 (Inherited: 0x0)
struct FSpawnArea
{
	struct FVector CenterLocation; // 0x0(0xC)
	uint8_t Shape; // 0xC(0x1)
	uint8_t Pad_0xD[0x3]; // 0xD(0x3)
	struct FVector ShapeSize; // 0x10(0xC)
	bool bInsideArea; // 0x1C(0x1)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
};

// Object: ScriptStruct SpawnSystem.SpeciesRatioStruct
// Size: 0x10 (Inherited: 0x0)
struct FSpeciesRatioStruct
{
	struct TArray<struct FUnitRatio> UnitRatios; // 0x0(0x10)
};

// Object: ScriptStruct SpawnSystem.UnitRatio
// Size: 0x80 (Inherited: 0x0)
struct FUnitRatio
{
	struct FUnitConfig Unit; // 0x0(0x78)
	float Ratio; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: ScriptStruct SpawnSystem.GroupConfig
// Size: 0x28 (Inherited: 0x0)
struct FGroupConfig
{
	struct FString Desc; // 0x0(0x10)
	struct TArray<struct FWeightedSquad> Squads; // 0x10(0x10)
	int Weight; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct SpawnSystem.WeightedSquad
// Size: 0x8 (Inherited: 0x0)
struct FWeightedSquad
{
	int Index; // 0x0(0x4)
	int Weight; // 0x4(0x4)
};

// Object: ScriptStruct SpawnSystem.SquadConfig
// Size: 0x40 (Inherited: 0x0)
struct FSquadConfig
{
	struct FString Desc; // 0x0(0x10)
	struct TArray<struct FWeightedUnit> Units; // 0x10(0x10)
	struct TArray<struct FUnitInitConfig> SquadInitConfig; // 0x20(0x10)
	struct FString SuggestNumber; // 0x30(0x10)
};

// Object: ScriptStruct SpawnSystem.WeightedUnit
// Size: 0x8 (Inherited: 0x0)
struct FWeightedUnit
{
	int Index; // 0x0(0x4)
	int Weight; // 0x4(0x4)
};

// Object: ScriptStruct SpawnSystem.STSpawnerDebugData
// Size: 0x1 (Inherited: 0x0)
struct FSTSpawnerDebugData
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: Class SpawnSystem.SpawnSystemSettings
// Size: 0x68 (Inherited: 0x38)
struct USpawnSystemSettings : UDeveloperSettings
{
	float TickFrequency; // 0x38(0x4)
	float SpawnUnitInterval; // 0x3C(0x4)
	int TickingSpawnerThreshold; // 0x40(0x4)
	bool bShouldSpawnSystemLogout; // 0x44(0x1)
	uint8_t Pad_0x45[0x3]; // 0x45(0x3)
	int MaxWaitSpawnQueSize; // 0x48(0x4)
	float VisualDebugRange; // 0x4C(0x4)
	struct FVector2D VisualDebugSpotCapsule; // 0x50(0x8)
	float SpotDrawThickness; // 0x58(0x4)
	float SpotDrawFlag; // 0x5C(0x4)
	int SpawnerVisualDebugLevel; // 0x60(0x4)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)


	// Object: Function SpawnSystem.SpawnSystemSettings.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b90970
	// Params: [ Num(1) Size(0x8) ]
	struct USpawnSystemSettings* Get();
	// [Call #1] RVA: 0x102B8A4E0
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102B907F8
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0
	// [Call #8] RVA: 0x102B907F8
	// [Call #9] RVA: 0x105185230
};

// Object: Class SpawnSystem.STSpawnerBase
// Size: 0x618 (Inherited: 0x4B0)
struct ASTSpawnerBase : AActor
{
	uint8_t Pad_0x4B0[0x60]; // 0x4B0(0x60)
	struct FString LuaFilePath; // 0x510(0x10)
	struct USTStrategyTiming* SpawnTiming; // 0x520(0x8)
	struct USTStrategyLocation* SpawnLocation; // 0x528(0x8)
	struct USTStrategySpecies* SpawnSpecies; // 0x530(0x8)
	struct TArray<struct USTStrategyCond*> SpawnConditions; // 0x538(0x10)
	uint8_t bUseRegion : 1; // 0x548(0x1), Mask(0x1)
	uint8_t bDebugDraw : 1; // 0x548(0x1), Mask(0x2)
	uint8_t bUsable : 1; // 0x548(0x1), Mask(0x4)
	uint8_t bIsMLAI : 1; // 0x548(0x1), Mask(0x8)
	uint8_t BitPad_0x548_4 : 4; // 0x548(0x1)
	uint8_t Pad_0x549[0x3]; // 0x549(0x3)
	int AILevel; // 0x54C(0x4)
	int SpawnerCampID; // 0x550(0x4)
	uint8_t VolumeType; // 0x554(0x1)
	uint8_t Pad_0x555[0x3]; // 0x555(0x3)
	float SphereRadius; // 0x558(0x4)
	struct FVector BoxHalfExtent; // 0x55C(0xC)
	struct ASTSpawnSpot* SpawnSpotClass; // 0x568(0x8)
	struct FScriptMulticastDelegate OnSpawnUnitSuccessDelegate; // 0x570(0x10)
	struct FScriptMulticastDelegate OnSpawnedUnitDeadDelegate; // 0x580(0x10)
	uint32_t SpawnerID; // 0x590(0x4)
	int MaxUnitsCount; // 0x594(0x4)
	int MaxAliveCount; // 0x598(0x4)
	uint8_t Pad_0x59C[0x4]; // 0x59C(0x4)
	struct FString SpawnerDescString; // 0x5A0(0x10)
	uint8_t bUseAsTrigger : 1; // 0x5B0(0x1), Mask(0x1)
	uint8_t bForceSpawn : 1; // 0x5B0(0x1), Mask(0x2)
	uint8_t BitPad_0x5B0_2 : 6; // 0x5B0(0x1)
	uint8_t bRecycle; // 0x5B1(0x1)
	uint8_t Pad_0x5B2[0x6]; // 0x5B2(0x6)
	struct FString SpawnerSnapshot; // 0x5B8(0x10)
	struct TArray<struct ASTSpawnSpot*> SpawnSpots; // 0x5C8(0x10)
	struct TArray<struct AActor*> AlivePawns; // 0x5D8(0x10)
	uint8_t bActive : 1; // 0x5E8(0x1), Mask(0x1)
	uint8_t bInitialized : 1; // 0x5E8(0x1), Mask(0x2)
	uint8_t bTimeIsRipe : 1; // 0x5E8(0x1), Mask(0x4)
	uint8_t BitPad_0x5E8_3 : 5; // 0x5E8(0x1)
	uint8_t Pad_0x5E9[0x3]; // 0x5E9(0x3)
	int TotalSpawnedUnits; // 0x5EC(0x4)
	struct USTSpawnSubsystem* SpawnSubsystem; // 0x5F0(0x8)
	uint8_t Pad_0x5F8[0x10]; // 0x5F8(0x10)
	int WaitSpawn; // 0x608(0x4)
	uint8_t bPlayerEnterRegion : 1; // 0x60C(0x1), Mask(0x1)
	uint8_t BitPad_0x60C_1 : 7; // 0x60C(0x1)
	uint8_t Pad_0x60D[0xB]; // 0x60D(0xB)


	// Object: Function SpawnSystem.STSpawnerBase.Thinking
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102b925a4
	// Params: [ Num(1) Size(0x4) ]
	void Thinking(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnerBase.Switch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b92520
	// Params: [ Num(1) Size(0x1) ]
	void Switch(bool IsSwitchOn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B7E494
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnerBase.StopSpawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b9250c
	// Params: [ Num(0) Size(0x0) ]
	void StopSpawn();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B7E494
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnerBase.SetSpawnerID
	// Flags: [Final|Native|Public]
	// Offset: 0x102b92494
	// Params: [ Num(1) Size(0x4) ]
	void SetSpawnerID(uint32_t ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B7E494
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnerBase.OnUnitSpawned
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x102b92310
	// Params: [ Num(3) Size(0xE8) ]
	void OnUnitSpawned(struct AActor* NewUnit, struct FSTSpawnParam& SpawnParam, struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.OnUnitDead
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b92258
	// Params: [ Num(2) Size(0x9) ]
	void OnUnitDead(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B7F3A0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B8C5A4
	// [Call #13] RVA: 0x102B8C5A4
	// [Call #14] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnerBase.OnSpawnTimingRipe
	// Flags: [Native|Protected]
	// Offset: 0x102b921cc
	// Params: [ Num(1) Size(0x1) ]
	void OnSpawnTimingRipe(bool IsRipe);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B7F3A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.OnSpawnerDeactivate
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnSpawnerDeactivate();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function SpawnSystem.STSpawnerBase.OnSpawnerActivate
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnSpawnerActivate();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function SpawnSystem.STSpawnerBase.OnRep_SpawnerID
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b921b8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SpawnerID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B7F3A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.Multicast_SpawnerSnapshot
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable]
	// Offset: 0x102b91f30
	// Params: [ Num(7) Size(0x52) ]
	void Multicast_SpawnerSnapshot(struct FString Timing, struct FString Species, struct FString Location, struct FString Conditions, struct FString Extra, bool IsActive, bool IsUsable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function SpawnSystem.STSpawnerBase.Multicast_AlivePawnsChange
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable]
	// Offset: 0x102b91e1c
	// Params: [ Num(3) Size(0xA) ]
	void Multicast_AlivePawnsChange(struct APawn* Unit, bool IsBorn, bool IsAllDead);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.ModifyMaxAlive
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b91da0
	// Params: [ Num(1) Size(0x4) ]
	void ModifyMaxAlive(int NewAlive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.IsUsable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91d80
	// Params: [ Num(1) Size(0x1) ]
	bool IsUsable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.IsPlayerEnterRegion
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91d50
	// Params: [ Num(1) Size(0x1) ]
	bool IsPlayerEnterRegion();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.IsInitialized
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91d30
	// Params: [ Num(1) Size(0x1) ]
	bool IsInitialized();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.IsActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91d10
	// Params: [ Num(1) Size(0x1) ]
	bool IsActive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.InitSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b91cf4
	// Params: [ Num(0) Size(0x0) ]
	void InitSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.GetTotalSpawnedNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91cd8
	// Params: [ Num(1) Size(0x4) ]
	int GetTotalSpawnedNum();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B81254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b91ca4
	// Params: [ Num(1) Size(0x8) ]
	struct USTSpawnSubsystem* GetSpawnSystem();
	// [Call #1] RVA: 0x102B7EAE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B81254
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnSpots
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b91c88
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct ASTSpawnSpot*> GetSpawnSpots();
	// [Call #1] RVA: 0x102B7EAE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B81254
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91c3c
	// Params: [ Num(1) Size(0x4) ]
	float GetSpawnRadius();
	// [Call #1] RVA: 0x102B7EAE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B81254
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102b91ba8
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetSpawnLocation();
	// [Call #1] RVA: 0x102B7EAE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91b80
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetSpawnExtent();
	// [Call #1] RVA: 0x102B7EAE0
	// [Call #2] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnerSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91af0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSpawnerSnapshot();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x102B7EAE0

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnerID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b91ad4
	// Params: [ Num(1) Size(0x4) ]
	uint32_t GetSpawnerID();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x102B7EAE0

	// Object: Function SpawnSystem.STSpawnerBase.GetSpawnerDesc
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91a44
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSpawnerDesc();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.GetReferencedCount
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102b91a08
	// Params: [ Num(1) Size(0x4) ]
	int GetReferencedCount();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.GetMaxUnits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b919ec
	// Params: [ Num(1) Size(0x4) ]
	int GetMaxUnits();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.GetMaxAlive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b919d0
	// Params: [ Num(1) Size(0x4) ]
	int GetMaxAlive();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.GetIsForceSpawn
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b919b0
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsForceSpawn();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.GetAliveUnits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b91920
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetAliveUnits();
	// [Call #1] RVA: 0x101FD9CA0
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504

	// Object: Function SpawnSystem.STSpawnerBase.FindSpot
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b9182c
	// Params: [ Num(2) Size(0x18) ]
	struct ASTSpawnSpot* FindSpot(struct FString SpotID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102B80690
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101FD9CA0
	// [Call #13] RVA: 0x10212ECFC
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8122C

	// Object: Function SpawnSystem.STSpawnerBase.DeactivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b91810
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102B80690
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101FD9CA0
	// [Call #13] RVA: 0x10212ECFC
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.CheckTriggerGuest
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102b91798
	// Params: [ Num(2) Size(0x9) ]
	bool CheckTriggerGuest(struct AActor* Guest);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102B80690
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x101FD9CA0
	// [Call #15] RVA: 0x10212ECFC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x101F811FC
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnerBase.CheckOwnedUnit
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b9170c
	// Params: [ Num(2) Size(0x9) ]
	bool CheckOwnedUnit(struct AActor* InUnit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B811A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102B80690
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x101FD9CA0

	// Object: Function SpawnSystem.STSpawnerBase.AnalyseConfigData
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b916f0
	// Params: [ Num(0) Size(0x0) ]
	void AnalyseConfigData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B811A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102B80690
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnerBase.ActivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b916d4
	// Params: [ Num(0) Size(0x0) ]
	void ActivateSpawner();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B811A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x102B80690
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
};

// Object: Class SpawnSystem.STSpawnSpot
// Size: 0x518 (Inherited: 0x4B0)
struct ASTSpawnSpot : AActor
{
	struct TArray<struct FUnitInitConfig> SpotInitConfig; // 0x4B0(0x10)
	int AliveThresholdCfg; // 0x4C0(0x4)
	int NumberThresholdCfg; // 0x4C4(0x4)
	struct FString SpotID; // 0x4C8(0x10)
	int SpotWeigh; // 0x4D8(0x4)
	uint8_t SpotType; // 0x4DC(0x1)
	uint8_t Pad_0x4DD[0x3]; // 0x4DD(0x3)
	int SquadIndex; // 0x4E0(0x4)
	int UnitIndex; // 0x4E4(0x4)
	struct FVector2D CapsuleSize; // 0x4E8(0x8)
	float MultiPosRangeMin; // 0x4F0(0x4)
	uint8_t Pad_0x4F4[0x4]; // 0x4F4(0x4)
	struct ASTSpawnerBase* OwnerSpawner; // 0x4F8(0x8)
	uint8_t Pad_0x500[0x18]; // 0x500(0x18)


	// Object: Function SpawnSystem.STSpawnSpot.OnUnitSpawnedSuc
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x102b93710
	// Params: [ Num(3) Size(0xE0) ]
	void OnUnitSpawnedSuc(uint32_t InSpawnerID, struct APawn* AIPawn, struct FSTSpawnParam& SpawnParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B815E4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSpot.OnUnitDead
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b93658
	// Params: [ Num(2) Size(0x10) ]
	void OnUnitDead(uint32_t InSpawnerID, struct APawn* AIPawn);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B815E4
	// [Call #13] RVA: 0x102B8C5A4
	// [Call #14] RVA: 0x102B8C5A4
	// [Call #15] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnSpot.IsSpotValid
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93604
	// Params: [ Num(1) Size(0x1) ]
	bool IsSpotValid();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B815E4
	// [Call #13] RVA: 0x102B8C5A4

	// Object: Function SpawnSystem.STSpawnSpot.HasModifySpecies
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b935d0
	// Params: [ Num(1) Size(0x1) ]
	bool HasModifySpecies();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSpot.GetSpotWeigh
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b935b4
	// Params: [ Num(1) Size(0x4) ]
	int GetSpotWeigh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnSpot.GetSpotUnitIndex
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93598
	// Params: [ Num(1) Size(0x4) ]
	int GetSpotUnitIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSpot.GetSpotType
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b9357c
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetSpotType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSpot.GetSpotSquadIndex
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93560
	// Params: [ Num(1) Size(0x4) ]
	int GetSpotSquadIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B81780
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSpot.GetSpotID
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b934d0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSpotID();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B81780

	// Object: Function SpawnSystem.STSpawnSpot.GetNumberThresholdCfg
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b934b4
	// Params: [ Num(1) Size(0x4) ]
	int GetNumberThresholdCfg();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B81780

	// Object: Function SpawnSystem.STSpawnSpot.GetMultiPositions
	// Flags: [Final|Native|Public]
	// Offset: 0x102b9338c
	// Params: [ Num(4) Size(0x20) ]
	struct TArray<struct FVector> GetMultiPositions(int ReqCount, int MaxCount, int TryTimes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B80774
	// [Call #8] RVA: 0x10246DCBC
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnSpot.GetCacheSpawnedCount
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93370
	// Params: [ Num(1) Size(0x4) ]
	int GetCacheSpawnedCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B80774
	// [Call #8] RVA: 0x10246DCBC
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnSpot.GetCacheAliveCount
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93354
	// Params: [ Num(1) Size(0x4) ]
	int GetCacheAliveCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B80774
	// [Call #8] RVA: 0x10246DCBC
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0

	// Object: Function SpawnSystem.STSpawnSpot.GetAliveThresholdCfg
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93338
	// Params: [ Num(1) Size(0x4) ]
	int GetAliveThresholdCfg();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B80774
	// [Call #8] RVA: 0x10246DCBC
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x100036FE0
};

// Object: Class SpawnSystem.STSpawnSubsystem
// Size: 0x1D0 (Inherited: 0x30)
struct USTSpawnSubsystem : UBattleSubsystem
{
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
	struct FScriptMulticastDelegate OnSpawnSysUnitSpawnedSuc; // 0x38(0x10)
	struct FScriptMulticastDelegate OnSpawnSysAfterUnitInit; // 0x48(0x10)
	struct TMap<uint32_t, struct ASTSpawnerBase*> SpawnersMap; // 0x58(0x50)
	uint8_t Pad_0xA8[0x88]; // 0xA8(0x88)
	float TickFrequency; // 0x130(0x4)
	int ThinkTimesPerFrame; // 0x134(0x4)
	float ReadySpawnFrequency; // 0x138(0x4)
	int MaxWaitSpawnQueSize; // 0x13C(0x4)
	bool bWaitSpawnInOrder; // 0x140(0x1)
	uint8_t Pad_0x141[0x57]; // 0x141(0x57)
	int RecAliveUnits; // 0x198(0x4)
	uint8_t Pad_0x19C[0x4]; // 0x19C(0x4)
	int WaitSpawnInOrderIndex; // 0x1A0(0x4)
	uint8_t Pad_0x1A4[0x2C]; // 0x1A4(0x2C)


	// Object: Function SpawnSystem.STSpawnSubsystem.UnregisterSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b946e0
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterSpawner(struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSubsystem.UnitFindSpawner
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b94654
	// Params: [ Num(2) Size(0x10) ]
	struct ASTSpawnerBase* UnitFindSpawner(int UnitUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B8B3B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSubsystem.StopSpawner
	// Flags: [Final|Native|Public]
	// Offset: 0x102b945d8
	// Params: [ Num(1) Size(0x4) ]
	void StopSpawner(uint32_t SpawnerID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B80EC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B8B3B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSubsystem.SpawnUnit
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b944b8
	// Params: [ Num(2) Size(0xD8) ]
	struct AActor* SpawnUnit(struct FSTSpawnParam SpawnParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B8CFE8
	// [Call #4] RVA: 0x102B8C5A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B80EC0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B8B3B0

	// Object: Function SpawnSystem.STSpawnSubsystem.RegisterSpawner
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b94434
	// Params: [ Num(1) Size(0x8) ]
	void RegisterSpawner(struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8CFE8
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B80EC0

	// Object: Function SpawnSystem.STSpawnSubsystem.RecordProgress
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x102b94420
	// Params: [ Num(0) Size(0x0) ]
	void RecordProgress();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8CFE8
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x102B8C5A4
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B80EC0

	// Object: Function SpawnSystem.STSpawnSubsystem.ReadySpawn
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b9439c
	// Params: [ Num(1) Size(0x4) ]
	void ReadySpawn(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8CFE8
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x102B8C5A4
	// [Call #11] RVA: 0x102B8C5A4
	// [Call #12] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnSubsystem.PreCheck
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b94360
	// Params: [ Num(1) Size(0x1) ]
	bool PreCheck();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8CFE8
	// [Call #8] RVA: 0x102B8C5A4
	// [Call #9] RVA: 0x102B8C5A4

	// Object: Function SpawnSystem.STSpawnSubsystem.OrderSpawnerThinking
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b942dc
	// Params: [ Num(1) Size(0x4) ]
	void OrderSpawnerThinking(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSubsystem.ModifyConfiguration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b94224
	// Params: [ Num(2) Size(0x8) ]
	void ModifyConfiguration(float TickFreq, int ThinkTimes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8B414
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnSubsystem.InitUnit
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b94138
	// Params: [ Num(2) Size(0x18) ]
	void InitUnit(struct APawn* AIPawn, struct TArray<struct FUnitInitConfig>& Configs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8D62C
	// [Call #6] RVA: 0x102B8D62C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B8B414
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STSpawnSubsystem.GetUnitConfigID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b940a4
	// Params: [ Num(2) Size(0xC) ]
	int GetUnitConfigID(struct AActor* Unit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8D62C
	// [Call #8] RVA: 0x102B8D62C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B8B414

	// Object: Function SpawnSystem.STSpawnSubsystem.GetAllUnits
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b94040
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetAllUnits();
	// [Call #1] RVA: 0x102B890DC
	// [Call #2] RVA: 0x10212ECFC
	// [Call #3] RVA: 0x101F811FC
	// [Call #4] RVA: 0x101F811FC
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B8D62C
	// [Call #13] RVA: 0x102B8D62C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnSubsystem.FindSpawner
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102b93fb4
	// Params: [ Num(2) Size(0x10) ]
	struct ASTSpawnerBase* FindSpawner(uint32_t SpawnerID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B8B258
	// [Call #4] RVA: 0x102B890DC
	// [Call #5] RVA: 0x10212ECFC
	// [Call #6] RVA: 0x101F811FC
	// [Call #7] RVA: 0x101F811FC
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B8D62C

	// Object: Function SpawnSystem.STSpawnSubsystem.EnQueue
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b93e6c
	// Params: [ Num(2) Size(0xD8) ]
	void EnQueue(struct FSTSpawnParam& SpawnParam, struct ASTSpawnerBase* Spawner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B8B258
	// [Call #11] RVA: 0x102B890DC
	// [Call #12] RVA: 0x10212ECFC
	// [Call #13] RVA: 0x101F811FC
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnSubsystem.CleanQueue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b93e50
	// Params: [ Num(0) Size(0x0) ]
	void CleanQueue();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8C5A4
	// [Call #6] RVA: 0x102B8C5A4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B8B258
	// [Call #11] RVA: 0x102B890DC
	// [Call #12] RVA: 0x10212ECFC
	// [Call #13] RVA: 0x101F811FC
	// [Call #14] RVA: 0x101F811FC
	// [Call #15] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STSpawnSubsystem.CheckCategoryLimit
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b93d70
	// Params: [ Num(3) Size(0xD) ]
	bool CheckCategoryLimit(struct ASTSpawnerBase* Spawner, int& AvailableBalance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B8C5A4
	// [Call #10] RVA: 0x102B8C5A4
	// [Call #11] RVA: 0x106C8459C
};

// Object: Class SpawnSystem.STSpawnSystemGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct USTSpawnSystemGameplayStatics : UGameplayStatics
{

	// Object: Function SpawnSystem.STSpawnSystemGameplayStatics.UnitFindSpawnerByUObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b9522c
	// Params: [ Num(2) Size(0x10) ]
	struct ASTSpawnerBase* UnitFindSpawnerByUObject(struct UObject* Object);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B8BFB4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSystemGameplayStatics.UnitFindSpawner
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b95174
	// Params: [ Num(3) Size(0x18) ]
	struct ASTSpawnerBase* UnitFindSpawner(struct UObject* WorldContextObject, int UnitUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B8BF3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B8BFB4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpawnSystem.STSpawnSystemGameplayStatics.ProjectPointToFloorWithComplexCollisionCheck
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102b94f68
	// Params: [ Num(7) Size(0xB0) ]
	struct FVector ProjectPointToFloorWithComplexCollisionCheck(struct UObject* WorldContextObject, struct FVector& Origin, bool& bOutHit, bool bCheckComplex, struct FHitResult& HitResult, float OffsetHeight);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C8CD38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B8BC78
	// [Call #15] RVA: 0x10516D168

	// Object: Function SpawnSystem.STSpawnSystemGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b94f34
	// Params: [ Num(1) Size(0x1) ]
	bool IsEditor();
	// [Call #1] RVA: 0x102B8BC70
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C8CD38
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B8BC78

	// Object: Function SpawnSystem.STSpawnSystemGameplayStatics.FindNearbyGroundLoc
	// Flags: [Final|Native|Static|Public|HasDefaults]
	// Offset: 0x102b94d2c
	// Params: [ Num(8) Size(0x38) ]
	struct TArray<struct FVector> FindNearbyGroundLoc(struct UObject* WorldContextObject, int OutCount, struct FVector InCenterLoc, float RangeMin, float RangeMax, float TraceHeight, int TryTimes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B817F8
	// [Call #16] RVA: 0x10246DCBC
	// [Call #17] RVA: 0x101F8C3A4
	// [Call #18] RVA: 0x101F8C3A4
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x102B8BC70
};

// Object: Class SpawnSystem.STSpawnVisualDebug
// Size: 0xE0 (Inherited: 0x28)
struct USTSpawnVisualDebug : UObject
{
	uint8_t Pad_0x28[0xB8]; // 0x28(0xB8)


	// Object: Function SpawnSystem.STSpawnVisualDebug.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102b95540
	// Params: [ Num(1) Size(0x8) ]
	struct USTSpawnVisualDebug* Get();
	// [Call #1] RVA: 0x102B98714
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class SpawnSystem.STSpeciesDataAsset
// Size: 0x70 (Inherited: 0x30)
struct USTSpeciesDataAsset : UDataAsset
{
	struct TArray<struct FUnitConfig> UnitConfig; // 0x30(0x10)
	struct TArray<struct FSquadConfig> SquadConfig; // 0x40(0x10)
	struct TArray<struct FGroupConfig> GroupConfig; // 0x50(0x10)
	struct TArray<struct FSpeciesRatioStruct> RatioConfig; // 0x60(0x10)
};

// Object: Class SpawnSystem.STStrategyBase
// Size: 0xE0 (Inherited: 0x28)
struct USTStrategyBase : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString LuaFilePath; // 0x80(0x10)
	uint8_t bShouldCD : 1; // 0x90(0x1), Mask(0x1)
	uint8_t BitPad_0x90_1 : 7; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float ConfigCDDuration; // 0x94(0x4)
	struct ASTSpawnerBase* OwnerSpawner; // 0x98(0x8)
	uint8_t bSTActive : 1; // 0xA0(0x1), Mask(0x1)
	uint8_t bTickEnable : 1; // 0xA0(0x1), Mask(0x2)
	uint8_t BitPad_0xA0_2 : 6; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x3]; // 0xA1(0x3)
	float CDCounter; // 0xA4(0x4)
	struct FString OwnerName; // 0xA8(0x10)
	struct FString StrategyName; // 0xB8(0x10)
	struct FString StrategySnapshot; // 0xC8(0x10)
	uint8_t Pad_0xD8[0x8]; // 0xD8(0x8)


	// Object: Function SpawnSystem.STStrategyBase.UpdateSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b95b58
	// Params: [ Num(1) Size(0x10) ]
	void UpdateSnapshot(struct FString New);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F82D88
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyBase.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b95ad4
	// Params: [ Num(1) Size(0x4) ]
	void TickStrategy(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F82D88
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyBase.ResetCD
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b95ab8
	// Params: [ Num(0) Size(0x0) ]
	void ResetCD();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F82D88
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyBase.OnStrategyDeactivate
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnStrategyDeactivate();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function SpawnSystem.STStrategyBase.OnStrategyActivate
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnStrategyActivate();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function SpawnSystem.STStrategyBase.IsSTActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b95a98
	// Params: [ Num(1) Size(0x1) ]
	bool IsSTActive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F82D88
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyBase.IsOnCD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b95a64
	// Params: [ Num(1) Size(0x1) ]
	bool IsOnCD();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F82D88
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyBase.GetTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b95a44
	// Params: [ Num(1) Size(0x1) ]
	bool GetTickEnable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F82D88
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function SpawnSystem.STStrategyBase.GetStrategyDesc
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b959b4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetStrategyDesc();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F82D88
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STStrategyBase.GetSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b95924
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSnapshot();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategyBase.GetOwnerSpawner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b95908
	// Params: [ Num(1) Size(0x8) ]
	struct ASTSpawnerBase* GetOwnerSpawner();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategyBase.DeactivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b958ec
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateStrategy();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategyBase.CDRemaining
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b958d0
	// Params: [ Num(1) Size(0x4) ]
	float CDRemaining();
	// [Call #1] RVA: 0x101F8122C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x104EEF504
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x100036FE0
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategyBase.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9584c
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x104EEF504
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x100036FE0
};

// Object: Class SpawnSystem.STStrategyCond
// Size: 0xE0 (Inherited: 0xE0)
struct USTStrategyCond : USTStrategyBase
{

	// Object: Function SpawnSystem.STStrategyCond.LuaCheckCondition
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x102b961a0
	// Params: [ Num(1) Size(0x1) ]
	bool LuaCheckCondition();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102B9648C

	// Object: Function SpawnSystem.STStrategyCond.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b96164
	// Params: [ Num(1) Size(0x1) ]
	bool CheckCondition();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102B9648C
};

// Object: Class SpawnSystem.STStrategyCond_Hide
// Size: 0x108 (Inherited: 0xE0)
struct USTStrategyCond_Hide : USTStrategyCond
{
	float Radius; // 0xDC(0x4)
	float Height; // 0xE0(0x4)
	struct FVector CharacterFOV; // 0xE4(0xC)
	uint8_t bUseLineTrace : 1; // 0xF0(0x1), Mask(0x1)
	uint8_t BitPad_0xF4_1 : 7; // 0xF4(0x1)
	uint8_t Pad_0xF5[0x3]; // 0xF5(0x3)
	struct ACharacter* ClassFilter; // 0xF8(0x8)
	uint8_t bUseSpawnerLoc : 1; // 0x100(0x1), Mask(0x1)
	uint8_t BitPad_0x100_1 : 7; // 0x100(0x1)
	uint8_t Pad_0x101[0x7]; // 0x101(0x7)


	// Object: Function SpawnSystem.STStrategyCond_Hide.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b9639c
	// Params: [ Num(1) Size(0x1) ]
	bool CheckCondition();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102B9671C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
};

// Object: Class SpawnSystem.STStrategyCond_Quantity
// Size: 0xE8 (Inherited: 0xE0)
struct USTStrategyCond_Quantity : USTStrategyCond
{
	uint8_t bLimitAlive : 1; // 0xDC(0x1), Mask(0x1)
	uint8_t bCustomQuantity : 1; // 0xDC(0x1), Mask(0x2)
	int ThresholdQuantity; // 0xE0(0x4)
	int AliveNumberLimit; // 0xE4(0x4)


	// Object: Function SpawnSystem.STStrategyCond_Quantity.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b965e8
	// Params: [ Num(1) Size(0x1) ]
	bool CheckCondition();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102B969C0
	// [Call #6] RVA: 0x10516D168

	// Object: Function SpawnSystem.STStrategyCond_Quantity.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b96564
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class SpawnSystem.STStrategyLocation
// Size: 0x100 (Inherited: 0xE0)
struct USTStrategyLocation : USTStrategyBase
{
	DelegateProperty OnGenerateSpawnLocationDelegate; // 0xE0(0x10)
	struct TArray<struct FSpawnSpotInfo> CacheSpotInfosArray; // 0xF0(0x10)


	// Object: Function SpawnSystem.STStrategyLocation.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b967f4
	// Params: [ Num(4) Size(0x21) ]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D5E0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class SpawnSystem.STStrategyLocation_Root
// Size: 0x100 (Inherited: 0x100)
struct USTStrategyLocation_Root : USTStrategyLocation
{

	// Object: Function SpawnSystem.STStrategyLocation_Root.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b996b0
	// Params: [ Num(4) Size(0x21) ]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D5E0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class SpawnSystem.STStrategyLocation_Spots
// Size: 0x100 (Inherited: 0x100)
struct USTStrategyLocation_Spots : USTStrategyLocation
{

	// Object: Function SpawnSystem.STStrategyLocation_Spots.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b99954
	// Params: [ Num(4) Size(0x21) ]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D5E0
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class SpawnSystem.STStrategySpecies
// Size: 0x108 (Inherited: 0xE0)
struct USTStrategySpecies : USTStrategyBase
{
	uint8_t bUseLuaConfigs : 1; // 0xDC(0x1), Mask(0x1)
	struct USTSpeciesDataAsset* SpeciesData; // 0xE0(0x8)
	DelegateProperty SupplySpawnSpeciesDelegate; // 0xE8(0x10)
	struct TArray<struct FUnitConfig> CacheSpeciesArray; // 0xF8(0x10)


	// Object: Function SpawnSystem.STStrategySpecies.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b99d24
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9C340
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategySpecies.GeAllCacheConfigIDs
	// Flags: [Final|Native|Public]
	// Offset: 0x102b99cc0
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<int> GeAllCacheConfigIDs();
	// [Call #1] RVA: 0x102B835F4
	// [Call #2] RVA: 0x101FA6168
	// [Call #3] RVA: 0x101F8BA44
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B9C340
	// [Call #11] RVA: 0x102B8D67C
	// [Call #12] RVA: 0x102B8D5E0
	// [Call #13] RVA: 0x102B8D67C
	// [Call #14] RVA: 0x102B8D5E0
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategySpecies.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b99c3c
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B835F4
	// [Call #4] RVA: 0x101FA6168
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B9C340
	// [Call #13] RVA: 0x102B8D67C
	// [Call #14] RVA: 0x102B8D5E0
	// [Call #15] RVA: 0x102B8D67C
	// [Call #16] RVA: 0x102B8D5E0
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
};

// Object: Class SpawnSystem.STStrategySpecies_SquadRatio
// Size: 0x160 (Inherited: 0x108)
struct USTStrategySpecies_SquadRatio : USTStrategySpecies
{
	int RatioIndex; // 0x108(0x4)
	uint8_t Pad_0x10C[0x54]; // 0x10C(0x54)


	// Object: Function SpawnSystem.STStrategySpecies_SquadRatio.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9a1b0
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9C340
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategySpecies_SquadRatio.ReadSquadRatios
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9a0cc
	// Params: [ Num(2) Size(0x18) ]
	void ReadSquadRatios(int ReferencedCount, struct TArray<struct FUnitRatio>& RatioConfig);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B83EFC
	// [Call #6] RVA: 0x102B97028
	// [Call #7] RVA: 0x102B97028
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B9C340
	// [Call #14] RVA: 0x102B8D67C
	// [Call #15] RVA: 0x102B8D5E0
	// [Call #16] RVA: 0x102B8D67C
	// [Call #17] RVA: 0x102B8D5E0
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategySpecies_SquadRatio.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9a048
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B83EFC
	// [Call #8] RVA: 0x102B97028
	// [Call #9] RVA: 0x102B97028
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B9C340
	// [Call #16] RVA: 0x102B8D67C
	// [Call #17] RVA: 0x102B8D5E0
};

// Object: Class SpawnSystem.STStrategySpecies_Static
// Size: 0x128 (Inherited: 0x108)
struct USTStrategySpecies_Static : USTStrategySpecies
{
	uint8_t HowDataRead; // 0x108(0x1)
	uint8_t Pad_0x109[0x3]; // 0x109(0x3)
	int GroupIndex; // 0x10C(0x4)
	int SquadIndex; // 0x110(0x4)
	int UnitIndex; // 0x114(0x4)
	uint8_t Pad_0x118[0x10]; // 0x118(0x10)


	// Object: Function SpawnSystem.STStrategySpecies_Static.WeightedReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9b114
	// Params: [ Num(2) Size(0x18) ]
	void WeightedReadUnit(int ReferencedCount, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B867B8
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D67C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategySpecies_Static.WeightedReadSquad
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9afb8
	// Params: [ Num(3) Size(0x58) ]
	void WeightedReadSquad(int ReferencedCount, struct FSquadConfig& SquadConfig, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B85854
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B97B7C
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B97B7C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B867B8
	// [Call #18] RVA: 0x102B8D67C
	// [Call #19] RVA: 0x102B8D67C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STStrategySpecies_Static.WeightedReadGroup
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9adf0
	// Params: [ Num(4) Size(0x50) ]
	void WeightedReadGroup(int ReferencedCount, struct FGroupConfig& GroupConfig, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B8537C
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B989E8
	// [Call #12] RVA: 0x102B97610
	// [Call #13] RVA: 0x102B8D67C
	// [Call #14] RVA: 0x102B989E8
	// [Call #15] RVA: 0x102B97610
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function SpawnSystem.STStrategySpecies_Static.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9accc
	// Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B9C340
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D5E0
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D5E0
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategySpecies_Static.ReadSpotSpecies
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9aaf4
	// Params: [ Num(4) Size(0x38) ]
	void ReadSpotSpecies(int& ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B85078
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B989E8
	// [Call #12] RVA: 0x102B8D5E0
	// [Call #13] RVA: 0x102B8D67C
	// [Call #14] RVA: 0x102B989E8
	// [Call #15] RVA: 0x102B8D5E0
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function SpawnSystem.STStrategySpecies_Static.OrderedReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9aa10
	// Params: [ Num(2) Size(0x18) ]
	void OrderedReadUnit(int ReferencedCount, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B878A0
	// [Call #6] RVA: 0x102B8D67C
	// [Call #7] RVA: 0x102B8D67C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B85078

	// Object: Function SpawnSystem.STStrategySpecies_Static.OrderedReadSquad
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9a8b4
	// Params: [ Num(3) Size(0x58) ]
	void OrderedReadSquad(int ReferencedCount, struct FSquadConfig& SquadConfig, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B87330
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B97B7C
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B97B7C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B878A0
	// [Call #18] RVA: 0x102B8D67C
	// [Call #19] RVA: 0x102B8D67C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function SpawnSystem.STStrategySpecies_Static.OrderedReadGroup
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9a6ec
	// Params: [ Num(4) Size(0x50) ]
	void OrderedReadGroup(int ReferencedCount, struct FGroupConfig& GroupConfig, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B86C68
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B989E8
	// [Call #12] RVA: 0x102B97610
	// [Call #13] RVA: 0x102B8D67C
	// [Call #14] RVA: 0x102B989E8
	// [Call #15] RVA: 0x102B97610
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function SpawnSystem.STStrategySpecies_Static.ManuallyReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x102b9a5cc
	// Params: [ Num(3) Size(0x18) ]
	void ManuallyReadUnit(int ReferencedCount, int Index, struct TArray<struct FUnitConfig>& Units);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B8641C
	// [Call #8] RVA: 0x102B8D67C
	// [Call #9] RVA: 0x102B8D67C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function SpawnSystem.STStrategySpecies_Static.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9a548
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B8641C
	// [Call #10] RVA: 0x102B8D67C
	// [Call #11] RVA: 0x102B8D67C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class SpawnSystem.STStrategyTiming
// Size: 0xF0 (Inherited: 0xE0)
struct USTStrategyTiming : USTStrategyBase
{
	struct FScriptMulticastDelegate OnSpawnTimingUp; // 0xE0(0x10)


	// Object: Function SpawnSystem.STStrategyTiming.TimeIsRipe
	// Flags: [Final|Native|Public]
	// Offset: 0x102b9b610
	// Params: [ Num(0) Size(0x0) ]
	void TimeIsRipe();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x102B9BA90
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
};

// Object: Class SpawnSystem.STStrategyTiming_Period
// Size: 0x110 (Inherited: 0xF0)
struct USTStrategyTiming_Period : USTStrategyTiming
{
	uint8_t bFirstDelay : 1; // 0xF0(0x1), Mask(0x1)
	uint8_t BitPad_0xF0_1 : 7; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	float FirstDelayDuration; // 0xF4(0x4)
	uint8_t bLoop : 1; // 0xF8(0x1), Mask(0x1)
	uint8_t BitPad_0xF8_1 : 7; // 0xF8(0x1)
	uint8_t Pad_0xF9[0x3]; // 0xF9(0x3)
	float PeriodDuration; // 0xFC(0x4)
	uint8_t Pad_0x100[0x10]; // 0x100(0x10)


	// Object: Function SpawnSystem.STStrategyTiming_Period.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9b854
	// Params: [ Num(1) Size(0x4) ]
	void TickStrategy(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Period.OnReachTimer
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b9b840
	// Params: [ Num(0) Size(0x0) ]
	void OnReachTimer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Period.OnFirstDelay
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b9b82c
	// Params: [ Num(0) Size(0x0) ]
	void OnFirstDelay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Period.DeactivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9b810
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateStrategy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Period.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9b78c
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

// Object: Class SpawnSystem.STStrategyTiming_Trigger
// Size: 0x110 (Inherited: 0xF0)
struct USTStrategyTiming_Trigger : USTStrategyTiming
{
	uint8_t VolumeType; // 0xF0(0x1)
	uint8_t Pad_0xF1[0x3]; // 0xF1(0x3)
	struct FVector CenterLocation; // 0xF4(0xC)
	float SphereRadius; // 0x100(0x4)
	struct FVector BoxExtent; // 0x104(0xC)


	// Object: Function SpawnSystem.STStrategyTiming_Trigger.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9bbec
	// Params: [ Num(1) Size(0x4) ]
	void TickStrategy(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B907F8
	// [Call #8] RVA: 0x105185230

	// Object: Function SpawnSystem.STStrategyTiming_Trigger.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9bb68
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
};

// Object: Class SpawnSystem.STStrategyTiming_Wave
// Size: 0x130 (Inherited: 0xF0)
struct USTStrategyTiming_Wave : USTStrategyTiming
{
	struct TArray<int> ConfigWaveAlive; // 0xF0(0x10)
	int WaveInterval; // 0x100(0x4)
	uint8_t bTriggerToStart : 1; // 0x104(0x1), Mask(0x1)
	uint8_t bDelayToStart : 1; // 0x104(0x1), Mask(0x2)
	uint8_t BitPad_0x104_2 : 6; // 0x104(0x1)
	uint8_t Pad_0x105[0x3]; // 0x105(0x3)
	int DelayDurationToStart; // 0x108(0x4)
	bool bRecycle; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	struct USTStrategyTiming_Trigger* TriggerHelper; // 0x110(0x8)
	int CurrentWave; // 0x118(0x4)
	uint8_t Pad_0x11C[0x14]; // 0x11C(0x14)


	// Object: Function SpawnSystem.STStrategyTiming_Wave.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9bff4
	// Params: [ Num(1) Size(0x4) ]
	void TickStrategy(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Wave.ResetCD
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x102b9bfd8
	// Params: [ Num(0) Size(0x0) ]
	void ResetCD();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Wave.OnTriggerToStartWave
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b9bf54
	// Params: [ Num(1) Size(0x1) ]
	void OnTriggerToStartWave(bool IsRipe);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B89C2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Wave.OnDelayToStartWave
	// Flags: [Final|Native|Protected]
	// Offset: 0x102b9bf40
	// Params: [ Num(0) Size(0x0) ]
	void OnDelayToStartWave();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B89C2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Wave.GetCurrentWave
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102b9bf24
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentWave();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B89C2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function SpawnSystem.STStrategyTiming_Wave.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102b9bea0
	// Params: [ Num(1) Size(0x8) ]
	void ActivateStrategy(struct ASTSpawnerBase* Owner);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B89C2C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
};

