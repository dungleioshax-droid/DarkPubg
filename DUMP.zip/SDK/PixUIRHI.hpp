#pragma once

#include <cstdint>

// Object: Class PixUIRHI.PxRHIImage
// Size: 0x28 (Inherited: 0x28)
struct UPxRHIImage : UObject
{

	// Object: Function PixUIRHI.PxRHIImage.GetHandleObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102968150
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetHandleObject();
	// [Call #1] RVA: 0x10295E1E0
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x102968670
	// [Call #6] RVA: 0x10295E220
	// [Call #7] RVA: 0x10295E228
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class PixUIRHI.PxRHIMgr
// Size: 0x28 (Inherited: 0x28)
struct UPxRHIMgr : UObject
{

	// Object: Function PixUIRHI.PxRHIMgr.RHIImageUpdate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102968440
	// Params: [ Num(2) Size(0x9) ]
	bool RHIImageUpdate(struct UPxRHIMgr* pPxRHIImage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10295E230
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PixUIRHI.PxRHIMgr.RHIImageFindByObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029683c4
	// Params: [ Num(2) Size(0x10) ]
	struct UPxRHIMgr* RHIImageFindByObject(struct UObject* pCoreObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10295E240
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10295E230
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function PixUIRHI.PxRHIMgr.RHIImageDestroy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102968348
	// Params: [ Num(2) Size(0x9) ]
	bool RHIImageDestroy(struct UPxRHIMgr* pPxRHIImage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10295E238
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10295E240
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10295E230
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function PixUIRHI.PxRHIMgr.RHIImageCreate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102968314
	// Params: [ Num(1) Size(0x8) ]
	struct UPxRHIImage* RHIImageCreate();
	// [Call #1] RVA: 0x10295E228
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10295E238
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10295E240
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10295E230
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function PixUIRHI.PxRHIMgr.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1029682e0
	// Params: [ Num(1) Size(0x8) ]
	struct UPxRHIMgr* Get();
	// [Call #1] RVA: 0x10295E220
	// [Call #2] RVA: 0x10295E228
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10295E238
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10295E240
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10295E230
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class PixUIRHI.PxRHIRender
// Size: 0xC0 (Inherited: 0x28)
struct UPxRHIRender : UObject
{
	uint8_t Pad_0x28[0x98]; // 0x28(0x98)
};

