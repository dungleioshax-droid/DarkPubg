#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_DecalBPTable_type.BP_STRUCT_DecalBPTable_type
// Size: 0x60 (Inherited: 0x0)
struct FBP_STRUCT_DecalBPTable_type
{
	int ID_0_0CAD9D8055C0CD6A25A0DCEE0A0553D4; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Path_1_0033FD807638E0C45A483151055262A8; // 0x8(0x10)
	struct FString CName_2_6D7E0B40638C94B731ACB8980538E865; // 0x18(0x10)
	struct FString DefaultTexturePath_3_3BA6EB00368C49AC4F31B2080CB16AE8; // 0x28(0x10)
	struct FString FlipBookTexturePath_4_75157F4004E82529477143F20510B968; // 0x38(0x10)
	int soundID_5_6F0D27C03EADFE7B44B5857B0ACC1DD4; // 0x48(0x4)
	uint8_t Pad_0x4C[0x4]; // 0x4C(0x4)
	struct FString soundPath_6_09E147C024FF3AFD468FAA630C1C6268; // 0x50(0x10)
};

