#pragma once

#include <cstdint>

// Object: ScriptStruct KantanChartsUMG.SeriesStyleManualMapping
// Size: 0x28 (Inherited: 0x0)
struct FSeriesStyleManualMapping
{
	struct FName SeriesId; // 0x0(0x8)
	struct FKantanSeriesStyle Style; // 0x8(0x20)
};

// Object: ScriptStruct KantanChartsUMG.CategoryStyleManualMapping
// Size: 0x20 (Inherited: 0x0)
struct FCategoryStyleManualMapping
{
	struct FName CategoryId; // 0x0(0x8)
	struct FKantanCategoryStyle Style; // 0x8(0x18)
};

// Object: Class KantanChartsUMG.KantanChart
// Size: 0x150 (Inherited: 0x100)
struct UKantanChart : UWidget
{
	struct FMargin Margins; // 0x100(0x10)
	struct FText ChartTitle; // 0x110(0x18)
	struct FMargin TitlePadding; // 0x128(0x10)
	float UpdateTickRate; // 0x138(0x4)
	uint8_t Pad_0x13C[0x14]; // 0x13C(0x14)


	// Object: Function KantanChartsUMG.KantanChart.SetUpdateTickRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207c700
	// Params: [ Num(1) Size(0x4) ]
	void SetUpdateTickRate(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102078664
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x10207CDBC

	// Object: Function KantanChartsUMG.KantanChart.SetMargins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207c674
	// Params: [ Num(1) Size(0x10) ]
	void SetMargins(struct FMargin& InMargins);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020785D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102078664
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChart.SetChartTitlePadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207c5e8
	// Params: [ Num(1) Size(0x10) ]
	void SetChartTitlePadding(struct FMargin& InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207863C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020785D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102078664
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChart.SetChartTitle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207c53c
	// Params: [ Num(1) Size(0x18) ]
	void SetChartTitle(struct FText& InTitle);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1020785F8
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10207863C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1020785D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102078664
};

// Object: Class KantanChartsUMG.KantanCategoryChart
// Size: 0x170 (Inherited: 0x150)
struct UKantanCategoryChart : UKantanChart
{
	bool bAutoPerCategoryStyles; // 0x150(0x1)
	uint8_t Pad_0x151[0x7]; // 0x151(0x7)
	struct UKantanCategoryStyleSet* CategoryStyleSet; // 0x158(0x8)
	struct TArray<struct FCategoryStyleManualMapping> ManualStyleMappings; // 0x160(0x10)


	// Object: Function KantanChartsUMG.KantanCategoryChart.AddCategoryStyleOverride
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10207c35c
	// Params: [ Num(2) Size(0x18) ]
	void AddCategoryStyleOverride(struct FName CategoryId, struct FLinearColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102078008
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10207C88C
	// [Call #9] RVA: 0x104F0F380
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
};

// Object: Class KantanChartsUMG.KantanBarChartBase
// Size: 0x328 (Inherited: 0x170)
struct UKantanBarChartBase : UKantanCategoryChart
{
	struct FKantanBarChartStyle WidgetStyle; // 0x170(0x158)
	uint8_t Orientation; // 0x2C8(0x1)
	uint8_t Pad_0x2C9[0x3]; // 0x2C9(0x3)
	float MaxBarValue; // 0x2CC(0x4)
	uint8_t LabelPosition; // 0x2D0(0x1)
	uint8_t Pad_0x2D1[0x3]; // 0x2D1(0x3)
	float BarToGapRatio; // 0x2D4(0x4)
	uint8_t ValueExtentsDisplay; // 0x2D8(0x1)
	uint8_t Pad_0x2D9[0x7]; // 0x2D9(0x7)
	struct FCartesianAxisConfig ValueAxisCfg; // 0x2E0(0x48)


	// Object: Function KantanChartsUMG.KantanBarChartBase.SetValueAxisConfig
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207b2c8
	// Params: [ Num(1) Size(0x48) ]
	void SetValueAxisConfig(struct FCartesianAxisConfig& InCfg);
	// [Call #1] RVA: 0x102071A7C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102076C88
	// [Call #5] RVA: 0x10206C258
	// [Call #6] RVA: 0x10206C258
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanBarChartBase.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b24c
	// Params: [ Num(1) Size(0x1) ]
	void SetOrientation(uint8_t InOrientation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076A08
	// [Call #4] RVA: 0x102071A7C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102076C88
	// [Call #8] RVA: 0x10206C258
	// [Call #9] RVA: 0x10206C258
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanBarChartBase.SetMaxBarValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b1d0
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxBarValue(float InMaxValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076A88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102076A08
	// [Call #7] RVA: 0x102071A7C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102076C88
	// [Call #11] RVA: 0x10206C258
	// [Call #12] RVA: 0x10206C258
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanBarChartBase.SetLabelPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b154
	// Params: [ Num(1) Size(0x1) ]
	void SetLabelPosition(uint8_t InPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076B08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102076A88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102076A08
	// [Call #10] RVA: 0x102071A7C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102076C88
	// [Call #14] RVA: 0x10206C258
	// [Call #15] RVA: 0x10206C258
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanBarChartBase.SetExtentsDisplay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b0d8
	// Params: [ Num(1) Size(0x1) ]
	void SetExtentsDisplay(uint8_t InExtents);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076C08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102076B08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102076A88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102076A08
	// [Call #13] RVA: 0x102071A7C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function KantanChartsUMG.KantanBarChartBase.SetBarToGapRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b05c
	// Params: [ Num(1) Size(0x4) ]
	void SetBarToGapRatio(float InRatio);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076B88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102076C08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102076B08
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102076A88
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class KantanChartsUMG.BarChart
// Size: 0x330 (Inherited: 0x328)
struct UBarChart : UKantanBarChartBase
{
	struct UObject* DataSource; // 0x328(0x8)


	// Object: Function KantanChartsUMG.BarChart.SetDatasource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207ab9c
	// Params: [ Num(2) Size(0x9) ]
	bool SetDatasource(struct UObject* InDatasource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207678C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519077C
	// [Call #8] RVA: 0x10508F76C
};

// Object: Class KantanChartsUMG.KantanCartesianChartBase
// Size: 0x390 (Inherited: 0x150)
struct UKantanCartesianChartBase : UKantanChart
{
	struct FKantanCartesianChartStyle WidgetStyle; // 0x150(0x158)
	struct FKantanCartesianPlotScale PlotScale; // 0x2A8(0x24)
	enum class EKantanDataPointSize DataPointSize; // 0x2CC(0x1)
	uint8_t Pad_0x2CD[0x3]; // 0x2CD(0x3)
	struct FCartesianAxisConfig XAxisCfg; // 0x2D0(0x48)
	struct FCartesianAxisConfig YAxisCfg; // 0x318(0x48)
	struct FMargin AxisTitlePadding; // 0x360(0x10)
	struct UKantanSeriesStyleSet* SeriesStyleSet; // 0x370(0x8)
	struct TArray<struct FSeriesStyleManualMapping> ManualStyleMappings; // 0x378(0x10)
	bool bAntiAlias; // 0x388(0x1)
	uint8_t Pad_0x389[0x7]; // 0x389(0x7)


	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetYAxisConfig
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207bd34
	// Params: [ Num(1) Size(0x48) ]
	void SetYAxisConfig(struct FCartesianAxisConfig& InCfg);
	// [Call #1] RVA: 0x102071A7C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102077510
	// [Call #5] RVA: 0x10206C258
	// [Call #6] RVA: 0x10206C258
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetXAxisConfig
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207bc88
	// Params: [ Num(1) Size(0x48) ]
	void SetXAxisConfig(struct FCartesianAxisConfig& InCfg);
	// [Call #1] RVA: 0x102071A7C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10207748C
	// [Call #5] RVA: 0x10206C258
	// [Call #6] RVA: 0x10206C258
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x102071A7C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102077510
	// [Call #12] RVA: 0x10206C258
	// [Call #13] RVA: 0x10206C258
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetPlotScaleByRange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207bb98
	// Params: [ Num(2) Size(0x10) ]
	void SetPlotScaleByRange(struct FCartesianAxisRange& InRangeX, struct FCartesianAxisRange& InRangeY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102077370
	// [Call #6] RVA: 0x102071A7C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10207748C
	// [Call #10] RVA: 0x10206C258
	// [Call #11] RVA: 0x10206C258
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102071A7C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102077510
	// [Call #17] RVA: 0x10206C258
	// [Call #18] RVA: 0x10206C258
	// [Call #19] RVA: 0x106C8459C

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetPlotScale
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10207bac0
	// Params: [ Num(2) Size(0x10) ]
	void SetPlotScale(struct FVector2D& InScale, struct FVector2D& InFocalCoords);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020772DC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102077370
	// [Call #11] RVA: 0x102071A7C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10207748C
	// [Call #15] RVA: 0x10206C258

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetDataPointSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207ba3c
	// Params: [ Num(1) Size(0x1) ]
	void SetDataPointSize(enum class EKantanDataPointSize InSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102077408
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1020772DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102077370

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.SetAxisTitlePadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207b9b0
	// Params: [ Num(1) Size(0x10) ]
	void SetAxisTitlePadding(struct FMargin& InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102077594
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102077408
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020772DC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.EnableSeries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b8f0
	// Params: [ Num(2) Size(0x9) ]
	void EnableSeries(struct FName ID, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102077B08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102077594
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102077408
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.ConfigureSeries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207b7e4
	// Params: [ Num(3) Size(0xA) ]
	void ConfigureSeries(struct FName ID, bool bDrawPoints, bool bDrawLines);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102077B80
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102077B08
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102077594

	// Object: Function KantanChartsUMG.KantanCartesianChartBase.AddSeriesStyleOverride
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10207b6f4
	// Params: [ Num(3) Size(0x20) ]
	void AddSeriesStyleOverride(struct FName SeriesId, struct UKantanPointStyle* PointStyle, struct FLinearColor Color);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102077618
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102077B80
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class KantanChartsUMG.KantanCartesianPlotBase
// Size: 0x390 (Inherited: 0x390)
struct UKantanCartesianPlotBase : UKantanCartesianChartBase
{
};

// Object: Class KantanChartsUMG.CartesianPlot
// Size: 0x398 (Inherited: 0x390)
struct UCartesianPlot : UKantanCartesianPlotBase
{
	struct UObject* DataSource; // 0x390(0x8)


	// Object: Function KantanChartsUMG.CartesianPlot.SetDatasource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207ae20
	// Params: [ Num(2) Size(0x9) ]
	bool SetDatasource(struct UObject* InDatasource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102076878
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10207B550
};

// Object: Class KantanChartsUMG.KantanChartLegend
// Size: 0x1F8 (Inherited: 0x100)
struct UKantanChartLegend : UWidget
{
	struct FMargin Margins; // 0x100(0x10)
	struct FMargin SeriesPadding; // 0x110(0x10)
	struct FSlateBrush Background; // 0x120(0xB8)
	int FontSize; // 0x1D8(0x4)
	struct TWeakObjectPtr<struct UKantanCartesianChartBase> Chart; // 0x1DC(0x8)
	uint8_t Pad_0x1E4[0x14]; // 0x1E4(0x14)


	// Object: Function KantanChartsUMG.KantanChartLegend.SetSeriesPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207cb98
	// Params: [ Num(1) Size(0x10) ]
	void SetSeriesPadding(struct FMargin& InPadding);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020787FC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChartLegend.SetMargins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207cb0c
	// Params: [ Num(1) Size(0x10) ]
	void SetMargins(struct FMargin& InMargins);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020787D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020787FC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChartLegend.SetFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207ca90
	// Params: [ Num(1) Size(0x4) ]
	void SetFontSize(int InFontSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102078868
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020787D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020787FC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChartLegend.SetChart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207ca14
	// Params: [ Num(1) Size(0x8) ]
	void SetChart(struct UKantanCartesianChartBase* InChart);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102078884
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102078868
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020787D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1020787FC
	// [Call #13] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.KantanChartLegend.SetBackground
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207c968
	// Params: [ Num(1) Size(0xB8) ]
	void SetBackground(struct FSlateBrush& InBrush);
	// [Call #1] RVA: 0x101FE9E54
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102078824
	// [Call #5] RVA: 0x101FEA144
	// [Call #6] RVA: 0x101FEA144
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102078884
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102078868
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020787D4
};

// Object: Class KantanChartsUMG.KantanTimeSeriesPlotBase
// Size: 0x3B0 (Inherited: 0x390)
struct UKantanTimeSeriesPlotBase : UKantanCartesianChartBase
{
	bool bUseFixedTimeRange; // 0x389(0x1)
	float DisplayTimeRange; // 0x38C(0x4)
	struct FCartesianRangeBound LowerTimeBound; // 0x390(0x8)
	struct FCartesianRangeBound UpperTimeBound; // 0x398(0x8)
	struct FCartesianRangeBound LowerValueBound; // 0x3A0(0x8)
	struct FCartesianRangeBound UpperValueBound; // 0x3A8(0x8)
};

// Object: Class KantanChartsUMG.SimpleBarChart
// Size: 0x340 (Inherited: 0x328)
struct USimpleBarChart : UKantanBarChartBase
{
	uint8_t Pad_0x328[0x18]; // 0x328(0x18)


	// Object: Function KantanChartsUMG.SimpleBarChart.BP_UpdateCategoryValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207d2f0
	// Params: [ Num(3) Size(0xD) ]
	void BP_UpdateCategoryValue(struct FName ID, float Value, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102079108
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.SimpleBarChart.BP_RemoveCategory
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207d228
	// Params: [ Num(2) Size(0x9) ]
	void BP_RemoveCategory(struct FName ID, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020790C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102079108
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function KantanChartsUMG.SimpleBarChart.BP_RemoveAllCategories
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207d214
	// Params: [ Num(0) Size(0x0) ]
	void BP_RemoveAllCategories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020790C8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102079108
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function KantanChartsUMG.SimpleBarChart.BP_AddCategoryWithId
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207d0bc
	// Params: [ Num(3) Size(0x21) ]
	void BP_AddCategoryWithId(struct FName ID, struct FText Name, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104F0F458
	// [Call #9] RVA: 0x102079068
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101FBDBE8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1020790C8

	// Object: Function KantanChartsUMG.SimpleBarChart.BP_AddCategory
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207cfa4
	// Params: [ Num(2) Size(0x20) ]
	void BP_AddCategory(struct FText Name, struct FName& CatId);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104F0F458
	// [Call #7] RVA: 0x1020790A0
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x101FBDBE8
	// [Call #11] RVA: 0x101FBDBE8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104F0F380
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104F0F458
	// [Call #21] RVA: 0x102079068
	// [Call #22] RVA: 0x101FBDBE8
	// [Call #23] RVA: 0x101FBDBE8
	// [Call #24] RVA: 0x101FBDBE8
};

// Object: Class KantanChartsUMG.SimpleCartesianPlot
// Size: 0x3A8 (Inherited: 0x390)
struct USimpleCartesianPlot : UKantanCartesianPlotBase
{
	uint8_t Pad_0x390[0x18]; // 0x390(0x18)


	// Object: Function KantanChartsUMG.SimpleCartesianPlot.BP_RemoveSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207dbe4
	// Params: [ Num(2) Size(0x9) ]
	void BP_RemoveSeries(struct FName ID, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020792E4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.SimpleCartesianPlot.BP_RemoveAllSeries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207dbd0
	// Params: [ Num(0) Size(0x0) ]
	void BP_RemoveAllSeries();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020792E4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.SimpleCartesianPlot.BP_AddSeriesWithId
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207d998
	// Params: [ Num(6) Size(0x2B) ]
	void BP_AddSeriesWithId(bool& bSuccess, struct FName ID, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104F0F380
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x1020791F4
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function KantanChartsUMG.SimpleCartesianPlot.BP_AddSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207d7a0
	// Params: [ Num(5) Size(0x23) ]
	void BP_AddSeries(struct FName& SeriesId, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104F0F458
	// [Call #13] RVA: 0x102079278
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function KantanChartsUMG.SimpleCartesianPlot.BP_AddDatapoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10207d688
	// Params: [ Num(3) Size(0x11) ]
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102079324
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
};

// Object: Class KantanChartsUMG.SimpleTimeSeriesPlot
// Size: 0x3C8 (Inherited: 0x3B0)
struct USimpleTimeSeriesPlot : UKantanTimeSeriesPlotBase
{
	uint8_t Pad_0x3B0[0x18]; // 0x3B0(0x18)


	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_RemoveSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207e5e8
	// Params: [ Num(2) Size(0x9) ]
	void BP_RemoveSeries(struct FName ID, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102079540
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_RemoveAllSeries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207e5d4
	// Params: [ Num(0) Size(0x0) ]
	void BP_RemoveAllSeries();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102079540
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddSeriesWithId
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207e39c
	// Params: [ Num(6) Size(0x2B) ]
	void BP_AddSeriesWithId(bool& bSuccess, struct FName ID, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104F0F380
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104F0F458
	// [Call #15] RVA: 0x102079450
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x101FBDBE8
	// [Call #20] RVA: 0x106C8459C

	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddSeries
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207e1a4
	// Params: [ Num(5) Size(0x23) ]
	void BP_AddSeries(struct FName& SeriesId, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104F0F380
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104F0F458
	// [Call #13] RVA: 0x1020794D4
	// [Call #14] RVA: 0x101FBDBE8
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101FBDBE8
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddDatapointNow
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10207e0a0
	// Params: [ Num(3) Size(0xD) ]
	void BP_AddDatapointNow(struct FName SeriesId, float Value, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1020795B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104F0F380
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddDatapoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10207df88
	// Params: [ Num(3) Size(0x11) ]
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102079580
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1020795B8
};

// Object: Class KantanChartsUMG.TimeSeriesPlot
// Size: 0x3B8 (Inherited: 0x3B0)
struct UTimeSeriesPlot : UKantanTimeSeriesPlotBase
{
	struct UObject* DataSource; // 0x3B0(0x8)


	// Object: Function KantanChartsUMG.TimeSeriesPlot.SetDatasource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10207e9dc
	// Params: [ Num(2) Size(0x9) ]
	bool SetDatasource(struct UObject* InDatasource);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207971C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x104FD0740
	// [Call #8] RVA: 0x1036A6C08
	// [Call #9] RVA: 0x105093FD0
};

