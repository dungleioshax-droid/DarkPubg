#pragma once

#include <cstdint>

// Object: Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	kUnfetched = 0,
	kFetchedSuccessfully = 1,
	kFetchedFailed = 2,
	EQFirebaseRemoteConfigStatus_MAX = 3
};

// Object: Class QDevKit.FilePicker
// Size: 0x38 (Inherited: 0x28)
struct UFilePicker : UObject
{
	struct FScriptMulticastDelegate OnFileSelectionComplete; // 0x28(0x10)


	// Object: Function QDevKit.FilePicker.UnInitialize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b161f4
	// Params: [ Num(0) Size(0x0) ]
	void UnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519077C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B169D4

	// Object: Function QDevKit.FilePicker.OpenFilePicker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b1614c
	// Params: [ Num(2) Size(0x11) ]
	bool OpenFilePicker(struct FString InParamJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1A70C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519077C

	// Object: Function QDevKit.FilePicker.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b16138
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1A70C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519077C

	// Object: Function QDevKit.FilePicker.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b16104
	// Params: [ Num(1) Size(0x8) ]
	struct UFilePicker* GetInstance();
	// [Call #1] RVA: 0x102B1285C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B1A70C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519077C

	// Object: DelegateFunction QDevKit.FilePicker.FileSelectionCompleteDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void FileSelectionCompleteDelegate__DelegateSignature(struct FString ResultJson);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class QDevKit.FirebaseHelper
// Size: 0x38 (Inherited: 0x28)
struct UFirebaseHelper : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)


	// Object: Function QDevKit.FirebaseHelper.SetConsent
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102b166b4
	// Params: [ Num(1) Size(0x50) ]
	void SetConsent(struct TMap<int, int>& InConsent);
	// [Call #1] RVA: 0x1020C77AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B1D8B0
	// [Call #5] RVA: 0x1020C7B88
	// [Call #6] RVA: 0x1020C7B88
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function QDevKit.FirebaseHelper.IsNotificationLaunchApp
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16680
	// Params: [ Num(1) Size(0x1) ]
	bool IsNotificationLaunchApp();
	// [Call #1] RVA: 0x102B1D7E4
	// [Call #2] RVA: 0x1020C77AC
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B1D8B0
	// [Call #6] RVA: 0x1020C7B88
	// [Call #7] RVA: 0x1020C7B88
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function QDevKit.FirebaseHelper.GetNotificationLaunchAppExtraData
	// Flags: [Final|Native|Public]
	// Offset: 0x102b165b0
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetNotificationLaunchAppExtraData(struct FString InKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1D82C
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x102B1D7E4
	// [Call #11] RVA: 0x1020C77AC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B1D8B0
	// [Call #15] RVA: 0x1020C7B88
	// [Call #16] RVA: 0x1020C7B88
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x105190870

	// Object: Function QDevKit.FirebaseHelper.GetInstance
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x102b1657c
	// Params: [ Num(1) Size(0x8) ]
	struct UFirebaseHelper* GetInstance();
	// [Call #1] RVA: 0x102B12B68
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B1D82C
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102B1D7E4
	// [Call #12] RVA: 0x1020C77AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102B1D8B0
	// [Call #16] RVA: 0x1020C7B88
	// [Call #17] RVA: 0x1020C7B88
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10519022C

	// Object: Function QDevKit.FirebaseHelper.GetFIRInstallId
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16518
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFIRInstallId();
	// [Call #1] RVA: 0x102B1D780
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B12B68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B1D82C
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102B1D7E4
	// [Call #17] RVA: 0x1020C77AC
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x102B1D8B0
	// [Call #21] RVA: 0x1020C7B88
	// [Call #22] RVA: 0x1020C7B88
	// [Call #23] RVA: 0x106C8459C

	// Object: Function QDevKit.FirebaseHelper.GetFIRAppInstanceId
	// Flags: [Final|Native|Public]
	// Offset: 0x102b164b4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFIRAppInstanceId();
	// [Call #1] RVA: 0x102B1D614
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B1D780
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102B12B68
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102B1D82C
	// [Call #15] RVA: 0x101F8156C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x102B1D7E4
	// [Call #22] RVA: 0x1020C77AC
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function QDevKit.FirebaseHelper.GetFCMToken
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16450
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFCMToken();
	// [Call #1] RVA: 0x102B1D4A4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B1D614
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102B1D780
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102B12B68
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B1D82C
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
	// [Call #26] RVA: 0x102B1D7E4

	// Object: Function QDevKit.FirebaseHelper.ConsumeNotificationLaunchApp
	// Flags: [Final|Native|Public]
	// Offset: 0x102b1643c
	// Params: [ Num(0) Size(0x0) ]
	void ConsumeNotificationLaunchApp();
	// [Call #1] RVA: 0x102B1D4A4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102B1D614
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x102B1D780
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102B12B68
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x102B1D82C
	// [Call #20] RVA: 0x101F8156C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C
};

// Object: Class QDevKit.FirebaseRemoteConfigImpl
// Size: 0xD0 (Inherited: 0x28)
struct UFirebaseRemoteConfigImpl : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct TArray<struct FString> QueryConfigNamesArray; // 0x30(0x10)
	uint8_t Pad_0x40[0x90]; // 0x40(0x90)


	// Object: Function QDevKit.FirebaseRemoteConfigImpl.GetStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b16c78
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetStatus();
	// [Call #1] RVA: 0x102B13288
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x102B17108

	// Object: Function QDevKit.FirebaseRemoteConfigImpl.GetRemoteConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b16b60
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetRemoteConfig(struct FString ConfigNameToQuery);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102B131EC
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x102B13288
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870
	// [Call #18] RVA: 0x10519022C
	// [Call #19] RVA: 0x10519022C

	// Object: Function QDevKit.FirebaseRemoteConfigImpl.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b16b2c
	// Params: [ Num(1) Size(0x8) ]
	struct UFirebaseRemoteConfigImpl* GetInstance();
	// [Call #1] RVA: 0x102B12D9C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x102B131EC
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x102B13288
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870
	// [Call #19] RVA: 0x10519022C
};

// Object: Class QDevKit.LocationHelper
// Size: 0x38 (Inherited: 0x28)
struct ULocationHelper : UObject
{
	struct FScriptMulticastDelegate LocationCompleteCallback; // 0x28(0x10)


	// Object: Function QDevKit.LocationHelper.QueryLocation
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16f34
	// Params: [ Num(1) Size(0x4) ]
	void QueryLocation(int InTimeout);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1F948
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function QDevKit.LocationHelper.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16f20
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1F948
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function QDevKit.LocationHelper.GetInstance
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x102b16eec
	// Params: [ Num(1) Size(0x8) ]
	struct ULocationHelper* GetInstance();
	// [Call #1] RVA: 0x102B136BC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B1F948
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function QDevKit.LocationHelper.Destroy
	// Flags: [Final|Native|Public]
	// Offset: 0x102b16ed8
	// Params: [ Num(0) Size(0x0) ]
	void Destroy();
	// [Call #1] RVA: 0x102B136BC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B1F948
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class QDevKit.PhotoAlbumHelper
// Size: 0x58 (Inherited: 0x28)
struct UPhotoAlbumHelper : UObject
{
	struct FScriptMulticastDelegate FetchAlbumImageInfoCompleteCallback; // 0x28(0x10)
	struct FScriptMulticastDelegate GenerateImageFromAlbumCompleteCallback; // 0x38(0x10)
	struct FScriptMulticastDelegate ScreenCapturedCompleteCallback; // 0x48(0x10)


	// Object: Function QDevKit.PhotoAlbumHelper.UnRegisterScreenCaptureListener
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17774
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterScreenCaptureListener();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function QDevKit.PhotoAlbumHelper.RegisterScreenCaptureListener
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17688
	// Params: [ Num(2) Size(0x20) ]
	void RegisterScreenCaptureListener(struct FString InScreenshotFolders, struct FString InScreenshotMimeTypes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B1FF0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function QDevKit.PhotoAlbumHelper.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17674
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B1FF0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function QDevKit.PhotoAlbumHelper.GetInstance
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x102b17640
	// Params: [ Num(1) Size(0x8) ]
	struct UPhotoAlbumHelper* GetInstance();
	// [Call #1] RVA: 0x102B137D4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B1FF0C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function QDevKit.PhotoAlbumHelper.GenerateImageFromAlbum
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17438
	// Params: [ Num(7) Size(0x30) ]
	int GenerateImageFromAlbum(struct FString InFilePath, struct FString InThumbFilePath, int InThumbnailWidth, int InThumbnailHeight, bool InForceJPG, bool InOverride);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B1FC98
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x102B137D4

	// Object: Function QDevKit.PhotoAlbumHelper.FetchAlbumImageInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17260
	// Params: [ Num(6) Size(0x30) ]
	void FetchAlbumImageInfo(int InStartIndex, int InLimitNum, int InThumbWidth, int InThumbHeight, struct FString InThumbPath, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B1FA14
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
};

// Object: Class QDevKit.StoreKit
// Size: 0x28 (Inherited: 0x28)
struct UStoreKit : UObject
{

	// Object: Function QDevKit.StoreKit.RequestReview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b17c48
	// Params: [ Num(1) Size(0x1) ]
	void RequestReview(bool bForceOpenStoreInTestEnv);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B1FFC4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x102B186A8

	// Object: Function QDevKit.StoreKit.OpenStorePage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b17bb8
	// Params: [ Num(1) Size(0x10) ]
	void OpenStorePage(struct FString storeParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B2010C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B1FFC4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function QDevKit.StoreKit.GetCountryCode
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102b17b1c
	// Params: [ Num(1) Size(0x10) ]
	void GetCountryCode(DelegateProperty& Callback);
	// [Call #1] RVA: 0x101FD9E48
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B206B4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B2010C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B1FFC4
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
};

// Object: Class QDevKit.SystemPermissionHelper
// Size: 0x38 (Inherited: 0x28)
struct USystemPermissionHelper : UObject
{
	struct FScriptMulticastDelegate RequestPermissionResultCallback; // 0x28(0x10)


	// Object: Function QDevKit.SystemPermissionHelper.RequestPermissions
	// Flags: [Final|Native|Public]
	// Offset: 0x102b182f0
	// Params: [ Num(3) Size(0x9) ]
	bool RequestPermissions(int InPermissionType, int InRequestCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B209CC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function QDevKit.SystemPermissionHelper.IsPermissionGranted
	// Flags: [Final|Native|Public]
	// Offset: 0x102b18264
	// Params: [ Num(2) Size(0x5) ]
	bool IsPermissionGranted(int InPermissionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B20958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B209CC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function QDevKit.SystemPermissionHelper.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x102b18250
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B20958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B209CC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function QDevKit.SystemPermissionHelper.GetPermissionStatus
	// Flags: [Final|Native|Public]
	// Offset: 0x102b181c4
	// Params: [ Num(2) Size(0x8) ]
	int GetPermissionStatus(int InPermissionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B20BA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102B20958
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B209CC
	// [Call #12] RVA: 0x10519022C

	// Object: Function QDevKit.SystemPermissionHelper.GetInstance
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x102b18190
	// Params: [ Num(1) Size(0x8) ]
	struct USystemPermissionHelper* GetInstance();
	// [Call #1] RVA: 0x102B14EC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102B20BA8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102B20958
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102B209CC
	// [Call #13] RVA: 0x10519022C

	// Object: Function QDevKit.SystemPermissionHelper.AndroidShouldShowRequestPermissionRationale
	// Flags: [Final|Native|Public]
	// Offset: 0x102b180e8
	// Params: [ Num(2) Size(0x11) ]
	bool AndroidShouldShowRequestPermissionRationale(struct FString InPermission);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B15110
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102B14EC8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102B20BA8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102B20958
	// [Call #14] RVA: 0x10516D168

	// Object: Function QDevKit.SystemPermissionHelper.AndroidRequestPermissions
	// Flags: [Final|Native|Public]
	// Offset: 0x102b18000
	// Params: [ Num(3) Size(0x15) ]
	bool AndroidRequestPermissions(struct FString InPermission, int InRequestCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102B15108
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B15110
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x102B14EC8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102B20BA8

	// Object: Function QDevKit.SystemPermissionHelper.AndroidIsPermissionGranted
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17f58
	// Params: [ Num(2) Size(0x11) ]
	bool AndroidIsPermissionGranted(struct FString InPermission);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B15100
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102B15108
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B15110
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function QDevKit.SystemPermissionHelper.AndroidHasDefinePermission
	// Flags: [Final|Native|Public]
	// Offset: 0x102b17eb0
	// Params: [ Num(2) Size(0x11) ]
	bool AndroidHasDefinePermission(struct FString InPermssionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B150F8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B15100
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102B15108
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
};

// Object: Class QDevKit.TouchTransmission
// Size: 0x38 (Inherited: 0x28)
struct UTouchTransmission : UObject
{
	struct FScriptMulticastDelegate OnTransmissionComplete; // 0x28(0x10)


	// Object: Function QDevKit.TouchTransmission.UnInitialize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b18910
	// Params: [ Num(0) Size(0x0) ]
	void UnInitialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B18F20
	// [Call #8] RVA: 0x102B18F50

	// Object: DelegateFunction QDevKit.TouchTransmission.TransmissionCompleteDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void TransmissionCompleteDelegate__DelegateSignature(struct FString ResultJson);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function QDevKit.TouchTransmission.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b188fc
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x102B18F20

	// Object: Function QDevKit.TouchTransmission.HandleReceivedPakFiles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b18854
	// Params: [ Num(2) Size(0x11) ]
	bool HandleReceivedPakFiles(struct FString InParamJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102B152C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function QDevKit.TouchTransmission.GetTransmissionRawJsonContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b187f0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetTransmissionRawJsonContent();
	// [Call #1] RVA: 0x102B15344
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102B152C4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function QDevKit.TouchTransmission.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102b187bc
	// Params: [ Num(1) Size(0x8) ]
	struct UTouchTransmission* GetInstance();
	// [Call #1] RVA: 0x102B15118
	// [Call #2] RVA: 0x102B15344
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102B152C4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
};

