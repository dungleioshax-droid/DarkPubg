#pragma once

#include <cstdint>

// Object: Enum IOSDeviceProfileSelector.ECompareType
enum class ECompareType : uint8_t
{
	CMP_Equal = 0,
	CMP_Less = 1,
	CMP_LessEqual = 2,
	CMP_Greater = 3,
	CMP_GreaterEqual = 4,
	CMP_NotEqual = 5,
	CMP_Regex = 6,
	CMP_MAX = 7
};

// Object: Enum IOSDeviceProfileSelector.ESourceType
enum class ESourceType : uint8_t
{
	SRC_PreviousRegexMatch = 0,
	SRC_DeviceModel = 1,
	SRC_iOSVersion = 2,
	SRC_MAX = 3
};

// Object: ScriptStruct IOSDeviceProfileSelector.ProfileMatch
// Size: 0x20 (Inherited: 0x0)
struct FProfileMatch
{
	struct FString Profile; // 0x0(0x10)
	struct TArray<struct FProfileMatchItem> Match; // 0x10(0x10)
};

// Object: ScriptStruct IOSDeviceProfileSelector.ProfileMatchItem
// Size: 0x18 (Inherited: 0x0)
struct FProfileMatchItem
{
	enum class ESourceType SourceType; // 0x0(0x1)
	enum class ECompareType CompareType; // 0x1(0x1)
	uint8_t Pad_0x2[0x6]; // 0x2(0x6)
	struct FString MatchString; // 0x8(0x10)
};

// Object: Class IOSDeviceProfileSelector.IOSDeviceProfileMatchingRules
// Size: 0x38 (Inherited: 0x28)
struct UIOSDeviceProfileMatchingRules : UObject
{
	struct TArray<struct FProfileMatch> IOSMatchProfile; // 0x28(0x10)
};

