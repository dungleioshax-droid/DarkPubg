#pragma once

#include <cstdint>

// Object: ScriptStruct ClientNet.IMSDKLoginResult
// Size: 0x40 (Inherited: 0x0)
struct FIMSDKLoginResult
{
	int imsdkRetCode; // 0x0(0x4)
	int thirdRetCode; // 0x4(0x4)
	struct FString OpenID; // 0x8(0x10)
	struct FString Token; // 0x18(0x10)
	int64_t tokenExpire; // 0x28(0x8)
	struct FString retExtraJson; // 0x30(0x10)
};

// Object: ScriptStruct ClientNet.IMSDKExtraInfo
// Size: 0x50 (Inherited: 0x0)
struct FIMSDKExtraInfo
{
	struct TMap<struct FString, struct FString> ExtraInfo; // 0x0(0x50)
};

// Object: Class ClientNet.HDmpveNet
// Size: 0x3B0 (Inherited: 0x28)
struct UHDmpveNet : UObject
{
	uint8_t Pad_0x28[0x230]; // 0x28(0x230)
	struct UHDmpveSDK* _ConnectorInst; // 0x258(0x8)
	struct FScriptMulticastDelegate StartTickNetPackageDelegate; // 0x260(0x10)
	uint8_t Pad_0x270[0x140]; // 0x270(0x140)


	// Object: Function ClientNet.HDmpveNet.SetTickNetMsgMaxTime
	// Flags: [Final|Native|Private]
	// Offset: 0x104543eac
	// Params: [ Num(1) Size(0x4) ]
	void SetTickNetMsgMaxTime(float MaxTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104512958
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function ClientNet.HDmpveNet.OnWebviewNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104543e00
	// Params: [ Num(1) Size(0x30) ]
	void OnWebviewNotify(struct FWebviewInfoWrapper& webviewinfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450CFF0
	// [Call #4] RVA: 0x10449356C
	// [Call #5] RVA: 0x10449356C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104512958
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function ClientNet.HDmpveNet.OnUAAssistantNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104543d50
	// Params: [ Num(1) Size(0x28) ]
	void OnUAAssistantNotify(struct FUAAssistantInfoWrapper& uaAssistantInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450B980
	// [Call #4] RVA: 0x104492A68
	// [Call #5] RVA: 0x104492A68
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10450CFF0
	// [Call #10] RVA: 0x10449356C
	// [Call #11] RVA: 0x10449356C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104512958
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function ClientNet.HDmpveNet.OnTraceCallBack
	// Flags: [Final|Native|Private]
	// Offset: 0x104543c2c
	// Params: [ Num(2) Size(0x18) ]
	void OnTraceCallBack(int code, struct FString dataJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x10450BD24
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10450B980
	// [Call #17] RVA: 0x104492A68
	// [Call #18] RVA: 0x104492A68
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10450CFF0

	// Object: Function ClientNet.HDmpveNet.OnTConndAuthFailDelegate
	// Flags: [Final|Native|Private]
	// Offset: 0x104543c18
	// Params: [ Num(0) Size(0x0) ]
	void OnTConndAuthFailDelegate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x10450BD24
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10450B980
	// [Call #17] RVA: 0x104492A68
	// [Call #18] RVA: 0x104492A68
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnShareNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104543b64
	// Params: [ Num(2) Size(0x8) ]
	void OnShareNotify(int Result, int Platform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10450AEE8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x10450BD24
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnRequestPermissionsResult
	// Flags: [Final|Native|Private]
	// Offset: 0x1045439a8
	// Params: [ Num(3) Size(0x28) ]
	void OnRequestPermissionsResult(int code, struct FString permission, struct FString grantResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x104510D58
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnReceiveDataNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104543884
	// Params: [ Num(2) Size(0x18) ]
	void OnReceiveDataNotify(int Result, struct TArray<uint8_t> Msg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FFC894
	// [Call #6] RVA: 0x10450C2BC
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F8122C
	// [Call #22] RVA: 0x104510D58
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function ClientNet.HDmpveNet.OnQuickLoginNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x1045437d8
	// Params: [ Num(1) Size(0x50) ]
	void OnQuickLoginNotify(struct FWakeupInfoWrapper& wakeupinfo);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10450C9F4
	// [Call #5] RVA: 0x101F87D64
	// [Call #6] RVA: 0x101F87D64
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FFC894
	// [Call #13] RVA: 0x10450C2BC
	// [Call #14] RVA: 0x101F8BA74
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnQRCodeGenQRImg
	// Flags: [Final|Native|Private]
	// Offset: 0x1045436c8
	// Params: [ Num(3) Size(0x18) ]
	void OnQRCodeGenQRImg(int Tag, int Ret, struct FString imgPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10450CC04
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x101F8676C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10450C9F4
	// [Call #15] RVA: 0x101F87D64
	// [Call #16] RVA: 0x101F87D64
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnMigrateNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x10454364c
	// Params: [ Num(1) Size(0x4) ]
	void OnMigrateNotify(int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450AD18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10450CC04
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x101F8676C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10450C9F4
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x101F87D64
	// [Call #20] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveNet.OnLaunchInfo
	// Flags: [Final|Native|Private]
	// Offset: 0x1045435b4
	// Params: [ Num(1) Size(0x10) ]
	void OnLaunchInfo(struct FString roominfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450CCEC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10450AD18
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10450CC04
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x101F8676C

	// Object: Function ClientNet.HDmpveNet.OnIGShareUploadFinished
	// Flags: [Final|Native|Private]
	// Offset: 0x1045434e0
	// Params: [ Num(2) Size(0x18) ]
	void OnIGShareUploadFinished(int Result, struct FString Platform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10450D370
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10450CCEC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10450AD18
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveNet.OnGroupNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104543430
	// Params: [ Num(1) Size(0x50) ]
	void OnGroupNotify(struct FGroupInfoWrapper& groupInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450C834
	// [Call #4] RVA: 0x104388CE4
	// [Call #5] RVA: 0x104388CE4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10450D370
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10450CCEC
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveNet.OnGetWebviewActionNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x10454334c
	// Params: [ Num(1) Size(0x10) ]
	void OnGetWebviewActionNotify(struct FString webviewinfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10450B320
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10450C834
	// [Call #15] RVA: 0x104388CE4
	// [Call #16] RVA: 0x104388CE4
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10450D370
	// [Call #23] RVA: 0x101F8130C

	// Object: Function ClientNet.HDmpveNet.OnGetTicketNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104543268
	// Params: [ Num(1) Size(0x10) ]
	void OnGetTicketNotify(struct FString TicketInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10450B798
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10450B320
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10450C834
	// [Call #26] RVA: 0x104388CE4

	// Object: Function ClientNet.HDmpveNet.OnGetShortUrlNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x1045431bc
	// Params: [ Num(1) Size(0x28) ]
	void OnGetShortUrlNotify(struct FShortURLInfoWrapper& shorturlinfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450B5F8
	// [Call #4] RVA: 0x10449330C
	// [Call #5] RVA: 0x10449330C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x10450B798
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x10450B320
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x104EEF504

	// Object: Function ClientNet.HDmpveNet.OnGetPlatformFriendsNotify
	// Flags: [Final|Native|Private|HasOutParms]
	// Offset: 0x104543104
	// Params: [ Num(1) Size(0x58) ]
	void OnGetPlatformFriendsNotify(struct FPlatformFriendInfoMap& platformFriends);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10450B114
	// [Call #5] RVA: 0x101F87D64
	// [Call #6] RVA: 0x101F87D64
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10450B5F8
	// [Call #11] RVA: 0x10449330C
	// [Call #12] RVA: 0x10449330C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x10450B798
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveNet.OnGetCountryNoByIMSDK
	// Flags: [Final|Native|Private]
	// Offset: 0x104543088
	// Params: [ Num(1) Size(0x4) ]
	void OnGetCountryNoByIMSDK(int Country);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450B498
	// [Call #4] RVA: 0x101F8676C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10450B114
	// [Call #8] RVA: 0x101F87D64
	// [Call #9] RVA: 0x101F87D64
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10450B5F8
	// [Call #14] RVA: 0x10449330C
	// [Call #15] RVA: 0x10449330C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveNet.OnGameMasterEvent
	// Flags: [Final|Native|Private]
	// Offset: 0x104542f64
	// Params: [ Num(2) Size(0x14) ]
	void OnGameMasterEvent(struct FString EvenName, int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x10450BB58
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10450B498
	// [Call #17] RVA: 0x101F8676C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10450B114
	// [Call #21] RVA: 0x101F87D64
	// [Call #22] RVA: 0x101F87D64
	// [Call #23] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveNet.OnConnectorStateChangeNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542e3c
	// Params: [ Num(4) Size(0x10) ]
	void OnConnectorStateChangeNotify(int State, int Param1, int Param2, int Param3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10450C0B8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x10450BB58
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveNet.OnConnectorDisconnectedNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542dc0
	// Params: [ Num(1) Size(0x4) ]
	void OnConnectorDisconnectedNotify(int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450C458
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10450C0B8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C

	// Object: Function ClientNet.HDmpveNet.OnConnectorConnectedNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542d0c
	// Params: [ Num(2) Size(0x8) ]
	void OnConnectorConnectedNotify(int IsConnected, int nResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10450BDF4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10450C458
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10450C0B8

	// Object: Function ClientNet.HDmpveNet.OnBindIntlNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542c90
	// Params: [ Num(1) Size(0x4) ]
	void OnBindIntlNotify(int bindEventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450ABB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10450BDF4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10450C458
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveNet.OnAccountLogoutNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542c14
	// Params: [ Num(1) Size(0x4) ]
	void OnAccountLogoutNotify(int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450A9E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10450ABB8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10450BDF4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10450C458

	// Object: Function ClientNet.HDmpveNet.OnAccountLoginNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x1045429cc
	// Params: [ Num(5) Size(0x34) ]
	void OnAccountLoginNotify(int Result, struct FString OpenID, int Channel, struct FString resultMsg, int thirdRetCode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x10450A234
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveNet.OnAccountInitializeNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x104542950
	// Params: [ Num(1) Size(0x4) ]
	void OnAccountInitializeNotify(int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450C60C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10450A234
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function ClientNet.HDmpveNet.OnAccessTokenRefreshedNotify
	// Flags: [Final|Native|Private]
	// Offset: 0x1045428d4
	// Params: [ Num(1) Size(0x4) ]
	void OnAccessTokenRefreshedNotify(int Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10450C6E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10450C60C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class ClientNet.HDmpveSDK
// Size: 0x138 (Inherited: 0x28)
struct UHDmpveSDK : UObject
{
	uint8_t Pad_0x28[0x100]; // 0x28(0x100)
	int MaxBufferSize; // 0x128(0x4)
	uint8_t Pad_0x12C[0xC]; // 0x12C(0xC)


	// Object: Function ClientNet.HDmpveSDK.UploadFile
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x10454599c
	// Params: [ Num(3) Size(0x28) ]
	void UploadFile(struct FString _imgPath, int shareFileType, struct FString InDestKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10451B020
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function ClientNet.HDmpveSDK.ShareWithUploadPhotoByChannel
	// Flags: [Final|Native|Public]
	// Offset: 0x10454581c
	// Params: [ Num(4) Size(0x38) ]
	void ShareWithUploadPhotoByChannel(struct FString _imgPath, int _channel, struct FString _url, struct FString _destKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10451B78C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveSDK.ShareWithPhotoByChannel_Simple
	// Flags: [Final|Native|Public]
	// Offset: 0x10454569c
	// Params: [ Num(4) Size(0x34) ]
	void ShareWithPhotoByChannel_Simple(struct FString _imgPath, struct FString _title, struct FString _content, int _channel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10451C450
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveSDK.ShareFacebookLink
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104545564
	// Params: [ Num(3) Size(0x30) ]
	void ShareFacebookLink(struct FString ftitle, struct FString fdesc, struct FString fsharelink);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10451A0A8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10451C450

	// Object: Function ClientNet.HDmpveSDK.SetTestLogin
	// Flags: [Final|Native|Public]
	// Offset: 0x10454548c
	// Params: [ Num(2) Size(0x14) ]
	void SetTestLogin(struct FString OpenID, int Channel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104516F20
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10451A0A8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveSDK.InviteSystemOfflineFriendsExt2
	// Flags: [Final|Native|Public]
	// Offset: 0x10454534c
	// Params: [ Num(3) Size(0x30) ]
	void InviteSystemOfflineFriendsExt2(struct FString _title, struct FString _content, struct FString _link);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045187E0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104516F20
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveSDK.InviteSystemOfflineFriendsExt
	// Flags: [Final|Native|Public]
	// Offset: 0x10454520c
	// Params: [ Num(3) Size(0x30) ]
	void InviteSystemOfflineFriendsExt(struct FString _title, struct FString _content, struct FString _link);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045185B0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1045187E0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function ClientNet.HDmpveSDK.InviteFBFriendsUnregistered_Link
	// Flags: [Final|Native|Public]
	// Offset: 0x104545078
	// Params: [ Num(4) Size(0x40) ]
	void InviteFBFriendsUnregistered_Link(struct FString _title, struct FString _content, struct FString _link, struct FString _extend);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104519184
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveSDK.HttpDnsSetOpenid
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544fe8
	// Params: [ Num(1) Size(0x10) ]
	void HttpDnsSetOpenid(struct FString InOpenid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10451CF10
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104519184
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveSDK.HttpDnsInit
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544ed0
	// Params: [ Num(3) Size(0x18) ]
	void HttpDnsInit(struct FString InAppId, bool InIsDebug, int InTimeout);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10451CE28
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10451CF10
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveSDK.HttpDnsDestroy
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544ebc
	// Params: [ Num(0) Size(0x0) ]
	void HttpDnsDestroy();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10451CE28
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10451CF10
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveSDK.GRomePingDuallink
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544e24
	// Params: [ Num(2) Size(0x14) ]
	int GRomePingDuallink(struct FString InHost);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104519E9C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10451CE28
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10451CF10
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveSDK.GRomeGetDuallinkStatus
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544df0
	// Params: [ Num(1) Size(0x4) ]
	int GRomeGetDuallinkStatus();
	// [Call #1] RVA: 0x104519FC8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104519E9C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10451CE28
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function ClientNet.HDmpveSDK.GetUploadUrlByFile
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544ce8
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetUploadUrlByFile(struct FString file);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10451B674
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104519FC8
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104519E9C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168

	// Object: Function ClientNet.HDmpveSDK.GetUploadUrl
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544c84
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetUploadUrl();
	// [Call #1] RVA: 0x10451B5AC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10451B674
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x104519FC8
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x104519E9C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveSDK.GetUploadStatusByFile
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544ba0
	// Params: [ Num(2) Size(0x14) ]
	int GetUploadStatusByFile(struct FString file);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10451B6FC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10451B5AC
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x10451B674
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x104EEF504
	// [Call #28] RVA: 0x100036FE0
	// [Call #29] RVA: 0x101F8130C
	// [Call #30] RVA: 0x106C8459C

	// Object: Function ClientNet.HDmpveSDK.GetUploadStatus
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544b6c
	// Params: [ Num(1) Size(0x4) ]
	int GetUploadStatus();
	// [Call #1] RVA: 0x10451B668
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x10451B6FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10451B5AC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x10451B674
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function ClientNet.HDmpveSDK.ClearFileUpload
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x104544a90
	// Params: [ Num(1) Size(0x10) ]
	void ClearFileUpload(struct FString file);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10451B744
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10451B668
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10451B6FC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10451B5AC
	// [Call #25] RVA: 0x101F8156C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x106C8459C
};

// Object: Class ClientNet.HDmpveSDKDelegates
// Size: 0x158 (Inherited: 0x28)
struct UHDmpveSDKDelegates : UObject
{
	struct FScriptMulticastDelegate ConnectNotifyDelegate; // 0x28(0x10)
	struct FScriptMulticastDelegate ConnectStateChangedNotifyDelegate; // 0x38(0x10)
	struct FScriptMulticastDelegate DisconnectNotifyDelegate; // 0x48(0x10)
	struct FScriptMulticastDelegate ReceiveDataNotifyDelegate; // 0x58(0x10)
	struct FScriptMulticastDelegate AccountInitializeNotifyDelegate; // 0x68(0x10)
	struct FScriptMulticastDelegate AccountLoginNotifyDelegate; // 0x78(0x10)
	struct FScriptMulticastDelegate AccessTokenRefreshedNotifyDelegate; // 0x88(0x10)
	struct FScriptMulticastDelegate AccountLogoutNotifyDelegate; // 0x98(0x10)
	struct FScriptMulticastDelegate ShareNotifyDelegate; // 0xA8(0x10)
	struct FScriptMulticastDelegate GroupNotifyDelegate; // 0xB8(0x10)
	struct FScriptMulticastDelegate QuickLoginNotifyDelegate; // 0xC8(0x10)
	struct FScriptMulticastDelegate QRCodeGenQRImgDelegate; // 0xD8(0x10)
	struct FScriptMulticastDelegate QRCodeLaunchDelegate; // 0xE8(0x10)
	struct FScriptMulticastDelegate WebviewNotifyDelegate; // 0xF8(0x10)
	struct FScriptMulticastDelegate ShortUrlNotifyDelegate; // 0x108(0x10)
	struct FScriptMulticastDelegate OnGetTicketNotifyDelegate; // 0x118(0x10)
	struct FScriptMulticastDelegate GameMasterEventDelegate; // 0x128(0x10)
	struct FScriptMulticastDelegate OnRequestPermissionResultDelegate; // 0x138(0x10)
	struct FScriptMulticastDelegate TConndAuthFailDelegate; // 0x148(0x10)
};

// Object: Class ClientNet.IMSDKConfig
// Size: 0x328 (Inherited: 0x28)
struct UIMSDKConfig : UObject
{
	struct FString IMSDK_GAME_ID; // 0x28(0x10)
	struct FString IMSDK_SERVER_SDKAPI_RELEASE; // 0x38(0x10)
	struct FString IMSDK_SERVER_SDKAPI_BACKUP_RELEASE; // 0x48(0x10)
	struct FString IMSDK_SERVER_NOTICE_RELEASE; // 0x58(0x10)
	struct FString IMSDK_SERVER_HELP_RELEASE; // 0x68(0x10)
	struct FString IMSDK_SERVER_HELP_SCHEME_RELEASE; // 0x78(0x10)
	struct FString IMSDK_SERVER_CONFIG_RELEASE; // 0x88(0x10)
	struct FString IMSDK_LOG_LEVEL_RELEASE; // 0x98(0x10)
	struct FString IMSDK_DEBUG_RELEASE; // 0xA8(0x10)
	struct FString IMSDK_INNER_VOLLEY_DEBUG_RELEASE; // 0xB8(0x10)
	struct FString IMSDK_SERVER_SDKAPI_TEST; // 0xC8(0x10)
	struct FString IMSDK_SERVER_SDKAPI_BACKUP_TEST; // 0xD8(0x10)
	struct FString IMSDK_SERVER_NOTICE_TEST; // 0xE8(0x10)
	struct FString IMSDK_SERVER_HELP_TEST; // 0xF8(0x10)
	struct FString IMSDK_SERVER_HELP_SCHEME_TEST; // 0x108(0x10)
	struct FString IMSDK_SERVER_CONFIG_TEST; // 0x118(0x10)
	struct FString IMSDK_LOG_LEVEL_TEST; // 0x128(0x10)
	struct FString IMSDK_DEBUG_TEST; // 0x138(0x10)
	struct FString IMSDK_INNER_VOLLEY_DEBUG_TEST; // 0x148(0x10)
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_RELEASE; // 0x158(0x10)
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_BACKUP_RELEASE; // 0x168(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_APP_ID_RELEASE; // 0x178(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_SDK_KEY_RELEASE; // 0x188(0x10)
	struct FString IMSDK_TWITTER_WEB_LOGIN_URL_RELEASE; // 0x198(0x10)
	struct FString MIGRATE_WEB_URL_RELEASE; // 0x1A8(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_CHECK_PASSWORD; // 0x1B8(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_PLATFORM_TYPE; // 0x1C8(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_CHANNEL_ID; // 0x1D8(0x10)
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_TEST; // 0x1E8(0x10)
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_BACKUP_TEST; // 0x1F8(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_APP_ID_TEST; // 0x208(0x10)
	struct FString IMSDK_UNIFIED_ACCOUNT_SDK_KEY_TEST; // 0x218(0x10)
	struct FString IMSDK_TWITTER_WEB_LOGIN_URL_TEST; // 0x228(0x10)
	struct FString MIGRATE_WEB_URL_TEST; // 0x238(0x10)
	struct FString MIGRATE_WEB_USER_AGENT_STRING; // 0x248(0x10)
	struct FString IMSDK_ACCOUNT_CHECK_POPUP_STATUS_ENABLE; // 0x258(0x10)
	struct FString IMSDK_ACCOUNT_VERIFY_OPT_SID_ENABLE; // 0x268(0x10)
	struct FString IMSDK_ACCOUNT_SEND_CODE_WEB_VERIFY; // 0x278(0x10)
	struct FString IMSDK_ADMOB_TEST_DEVICE; // 0x288(0x10)
	struct FString IMSDK_ACCOUNT_CAPTCHA_APP_ID_FOR_VERIFY_CODE; // 0x298(0x10)
	struct FString IMSDK_SERVER_QR_CODE_RELEASE; // 0x2A8(0x10)
	struct FString IMSDK_SERVER_QR_CODE_TEST; // 0x2B8(0x10)
	struct FString IMSDK_QR_CODE_SDK_KEY; // 0x2C8(0x10)
	struct FString IMSDK_NEW_API_ENABLE_LEVEL_RELEASE; // 0x2D8(0x10)
	struct FString IMSDK_NEW_API_ENABLE_LEVEL_TEST; // 0x2E8(0x10)
	struct FString IMSDK_LOCAL_LOG_ENABLE; // 0x2F8(0x10)
	struct FString IMSDK_WEB_LOGIN_BASE_URL_RELEASE; // 0x308(0x10)
	struct FString IMSDK_WEB_LOGIN_BASE_URL_TEST; // 0x318(0x10)


	// Object: Function ClientNet.IMSDKConfig.PatchMSDKConfigWithAreaConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x104546fac
	// Params: [ Num(0) Size(0x0) ]
	void PatchMSDKConfigWithAreaConfig();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x1045471E4
	// [Call #6] RVA: 0x10518559C
	// [Call #7] RVA: 0x10518D4FC
	// [Call #8] RVA: 0x106C8CD38

	// Object: Function ClientNet.IMSDKConfig.GetIMSDKLogLevel
	// Flags: [Final|Native|Public]
	// Offset: 0x104546ef8
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetIMSDKLogLevel(int InEnv);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10451FE68
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10508F76C
	// [Call #12] RVA: 0x1045471E4
};

// Object: Class ClientNet.IMSDKHelper
// Size: 0xB0 (Inherited: 0x28)
struct UIMSDKHelper : UObject
{
	struct FScriptMulticastDelegate WebviewVerifyCallbackDelegate; // 0x28(0x10)
	struct FScriptMulticastDelegate OnLoadAdvertiseResult; // 0x38(0x10)
	struct FScriptMulticastDelegate OnShowAdvertiseResult; // 0x48(0x10)
	struct FScriptMulticastDelegate OnGenerateQRCodeNotify; // 0x58(0x10)
	struct FScriptMulticastDelegate OnQRCodeStatusNotify; // 0x68(0x10)
	struct FScriptMulticastDelegate OnInvalidateQRCodeNotify; // 0x78(0x10)
	struct FScriptMulticastDelegate OnLoginCommandDelegate; // 0x88(0x10)
	struct FScriptMulticastDelegate OnOpenAppByUrlDelegate; // 0x98(0x10)
	uint8_t Pad_0xA8[0x8]; // 0xA8(0x8)


	// Object: Function ClientNet.IMSDKHelper.UpdateIMSDKBindResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b44c
	// Params: [ Num(1) Size(0x10) ]
	void UpdateIMSDKBindResult(struct FString InBindResult);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523EBC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function ClientNet.IMSDKHelper.SwitchQRCodeLoginResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b3a4
	// Params: [ Num(2) Size(0x11) ]
	bool SwitchQRCodeLoginResult(struct FString InOpenid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523CE4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104523EBC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function ClientNet.IMSDKHelper.StartWebVerify
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b264
	// Params: [ Num(3) Size(0x30) ]
	void StartWebVerify(struct FString InExtraInfo, struct FString InVerifyAppId, struct FString InAccount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523504
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104523CE4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x104523EBC

	// Object: Function ClientNet.IMSDKHelper.SetWindowEditorLoginTokenIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b1e8
	// Params: [ Num(1) Size(0x4) ]
	void SetWindowEditorLoginTokenIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522808
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104523504
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x104523CE4
	// [Call #21] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SetupLoginCacheInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b12c
	// Params: [ Num(2) Size(0x5) ]
	void SetupLoginCacheInfo(int InChannelId, bool InIsQuickLogin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104522058
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104522808
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104523504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SetupAdjustDMA
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454b03c
	// Params: [ Num(3) Size(0xC) ]
	void SetupAdjustDMA(int InEEA, int InAdPersonalization, int InAdUserData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045239B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104522058
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104522808

	// Object: Function ClientNet.IMSDKHelper.SetUgId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454afa4
	// Params: [ Num(1) Size(0x10) ]
	void SetUgId(struct FString InUgId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045226BC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1045239B8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104522058

	// Object: Function ClientNet.IMSDKHelper.SetNoAuthOpenid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454aec0
	// Params: [ Num(1) Size(0x10) ]
	void SetNoAuthOpenid(struct FString OpenID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x104522BE0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1045226BC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.SetMSDKConfig
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10454adc0
	// Params: [ Num(2) Size(0x51) ]
	void SetMSDKConfig(struct TMap<struct FString, struct FString>& InConfigMaps, bool InClearLoginData);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104522EA0
	// [Call #7] RVA: 0x101F87D64
	// [Call #8] RVA: 0x101F87D64
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x104522BE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x1045226BC
	// [Call #24] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SetLoginType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454ad28
	// Params: [ Num(1) Size(0x10) ]
	void SetLoginType(struct FString InIMSDKChannelName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522144
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F8676C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104522EA0
	// [Call #13] RVA: 0x101F87D64
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x104522BE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SetLoginResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454ac58
	// Params: [ Num(2) Size(0x20) ]
	struct FString SetLoginResult(struct FString InLoginRetJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523E10
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104522144
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101F8676C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x104522EA0
	// [Call #22] RVA: 0x101F87D64

	// Object: Function ClientNet.IMSDKHelper.SetIMSDKEnv
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454abdc
	// Params: [ Num(1) Size(0x4) ]
	void SetIMSDKEnv(int iEnv);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522B54
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104523E10
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104522144
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x101F8676C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.SetGameDeviceId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454ab34
	// Params: [ Num(2) Size(0x11) ]
	bool SetGameDeviceId(struct FString InGameDeviceId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104524074
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104522B54
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104523E10
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.SetChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454aa9c
	// Params: [ Num(1) Size(0x10) ]
	void SetChannel(struct FString InIMSDKChannelName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045220C8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104524074
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104522B54
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x104523E10
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SetAdvertiseUserID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454aa04
	// Params: [ Num(1) Size(0x10) ]
	void SetAdvertiseUserID(struct FString UserId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522A64
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1045220C8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104524074
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x104522B54

	// Object: Function ClientNet.IMSDKHelper.SetAdvertiseCustomData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a96c
	// Params: [ Num(1) Size(0x10) ]
	void SetAdvertiseCustomData(struct FString InCustomData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522ADC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104522A64
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045220C8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x104524074
	// [Call #22] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.SaveLastIMSDKChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a8f0
	// Params: [ Num(1) Size(0x4) ]
	void SaveLastIMSDKChannelID(int channelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522860
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104522ADC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104522A64
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1045220C8
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.RequestVerifyCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a6e0
	// Params: [ Num(6) Size(0x48) ]
	void RequestVerifyCode(struct FString InPhoneOrEmail, int InAccountType, int InUseForType, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104522FA8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.RefreshLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a6cc
	// Params: [ Num(0) Size(0x0) ]
	void RefreshLogin();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104522FA8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.RecoverGuest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a624
	// Params: [ Num(2) Size(0x11) ]
	bool RecoverGuest(struct FString channelUserId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523714
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104522FA8
	// [Call #20] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.QuickLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a610
	// Params: [ Num(0) Size(0x0) ]
	void QuickLogin();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523714
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.QueryQRCodeStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a4d0
	// Params: [ Num(3) Size(0x30) ]
	void QueryQRCodeStatus(struct FString InCodeId, struct FString InRandStr, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523858
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104523714
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.PlayAdvertise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a4bc
	// Params: [ Num(0) Size(0x0) ]
	void PlayAdvertise();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523858
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104523714
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.OriginalShare
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454a198
	// Params: [ Num(9) Size(0x88) ]
	void OriginalShare(int InShareType, struct FString InMSDKChannelName, struct FString InTitle, struct FString InContent, struct FString InLink, struct FString InThumbPath, struct FString InImagePath, struct FString InExtraJson, struct FString InUser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10452254C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.OriginalLogin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10454a048
	// Params: [ Num(3) Size(0x21) ]
	void OriginalLogin(struct FString InExtraJson, struct TArray<struct FString>& InPermissions, bool InNeedGuid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1045224DC
	// [Call #8] RVA: 0x101F8B9F8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.OriginalBind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549f08
	// Params: [ Num(3) Size(0x30) ]
	void OriginalBind(struct FString InChannel, struct FString InSubChannel, struct FString InExtra);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10452263C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1045224DC
	// [Call #22] RVA: 0x101F8B9F8
	// [Call #23] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.OnCommandLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549e1c
	// Params: [ Num(2) Size(0x20) ]
	void OnCommandLogin(struct FString InCmd, struct FString InExtra);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045239C8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10452263C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.ModifyAccountInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549a70
	// Params: [ Num(11) Size(0x90) ]
	void ModifyAccountInfo(struct FString InAccount, int InAccountType, int InVerifyType, struct FString InVerifyData, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InMondifyToAccount, int InModifyAccountType, struct FString InModifyVerifyCode, struct FString InModifyPhoneAreaCode, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.LogoutWith
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045499f4
	// Params: [ Num(1) Size(0x4) ]
	void LogoutWith(int InMSDKChannelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523748
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.LogoutQRCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454995c
	// Params: [ Num(1) Size(0x10) ]
	void LogoutQRCode(struct FString InOpenid);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104523D7C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104523748
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.LoadAdvertise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549870
	// Params: [ Num(2) Size(0x20) ]
	void LoadAdvertise(struct FString InAdvertiseUnitId, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104522950
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104523D7C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104523748
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.IsEqualCurLoginPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454977c
	// Params: [ Num(2) Size(0x11) ]
	bool IsEqualCurLoginPlatform(struct FString strChannel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x1045226CC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104522950
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x104523D7C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.IsChannelInstalled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045496d4
	// Params: [ Num(2) Size(0x11) ]
	bool IsChannelInstalled(struct FString InChannelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521888
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x1045226CC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x104522950
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.IsChannelBound
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549648
	// Params: [ Num(2) Size(0x5) ]
	bool IsChannelBound(int InMSDKChannelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521740
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104521888
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x1045226CC
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindWhatsApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549614
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindWhatsApp();
	// [Call #1] RVA: 0x104521878
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x104521740
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104521888
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x1045226CC
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindVK
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045495e0
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindVK();
	// [Call #1] RVA: 0x104521840
	// [Call #2] RVA: 0x104521878
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104521740
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104521888
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x1045226CC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindUnifiedAccount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045495ac
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindUnifiedAccount();
	// [Call #1] RVA: 0x104521860
	// [Call #2] RVA: 0x104521840
	// [Call #3] RVA: 0x104521878
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104521740
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521888
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindTwitter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549578
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindTwitter();
	// [Call #1] RVA: 0x104521830
	// [Call #2] RVA: 0x104521860
	// [Call #3] RVA: 0x104521840
	// [Call #4] RVA: 0x104521878
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104521740
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104521888
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindTikTok
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549544
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindTikTok();
	// [Call #1] RVA: 0x104521880
	// [Call #2] RVA: 0x104521830
	// [Call #3] RVA: 0x104521860
	// [Call #4] RVA: 0x104521840
	// [Call #5] RVA: 0x104521878
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104521740
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104521888
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindNosChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549510
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindNosChat();
	// [Call #1] RVA: 0x104521838
	// [Call #2] RVA: 0x104521880
	// [Call #3] RVA: 0x104521830
	// [Call #4] RVA: 0x104521860
	// [Call #5] RVA: 0x104521840
	// [Call #6] RVA: 0x104521878
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521740
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104521888
	// [Call #13] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045494dc
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindLine();
	// [Call #1] RVA: 0x104521848
	// [Call #2] RVA: 0x104521838
	// [Call #3] RVA: 0x104521880
	// [Call #4] RVA: 0x104521830
	// [Call #5] RVA: 0x104521860
	// [Call #6] RVA: 0x104521840
	// [Call #7] RVA: 0x104521878
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x104521740
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindHMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045494a8
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindHMS();
	// [Call #1] RVA: 0x104521868
	// [Call #2] RVA: 0x104521848
	// [Call #3] RVA: 0x104521838
	// [Call #4] RVA: 0x104521880
	// [Call #5] RVA: 0x104521830
	// [Call #6] RVA: 0x104521860
	// [Call #7] RVA: 0x104521840
	// [Call #8] RVA: 0x104521878
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104521740

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindGooglePlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549474
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindGooglePlay();
	// [Call #1] RVA: 0x104521820
	// [Call #2] RVA: 0x104521868
	// [Call #3] RVA: 0x104521848
	// [Call #4] RVA: 0x104521838
	// [Call #5] RVA: 0x104521880
	// [Call #6] RVA: 0x104521830
	// [Call #7] RVA: 0x104521860
	// [Call #8] RVA: 0x104521840
	// [Call #9] RVA: 0x104521878
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104521740

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindGameCenter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549440
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindGameCenter();
	// [Call #1] RVA: 0x104521828
	// [Call #2] RVA: 0x104521820
	// [Call #3] RVA: 0x104521868
	// [Call #4] RVA: 0x104521848
	// [Call #5] RVA: 0x104521838
	// [Call #6] RVA: 0x104521880
	// [Call #7] RVA: 0x104521830
	// [Call #8] RVA: 0x104521860
	// [Call #9] RVA: 0x104521840
	// [Call #10] RVA: 0x104521878
	// [Call #11] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindFB
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454940c
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindFB();
	// [Call #1] RVA: 0x104521738
	// [Call #2] RVA: 0x104521828
	// [Call #3] RVA: 0x104521820
	// [Call #4] RVA: 0x104521868
	// [Call #5] RVA: 0x104521848
	// [Call #6] RVA: 0x104521838
	// [Call #7] RVA: 0x104521880
	// [Call #8] RVA: 0x104521830
	// [Call #9] RVA: 0x104521860
	// [Call #10] RVA: 0x104521840
	// [Call #11] RVA: 0x104521878

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindDiscord
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045493d8
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindDiscord();
	// [Call #1] RVA: 0x104521870
	// [Call #2] RVA: 0x104521738
	// [Call #3] RVA: 0x104521828
	// [Call #4] RVA: 0x104521820
	// [Call #5] RVA: 0x104521868
	// [Call #6] RVA: 0x104521848
	// [Call #7] RVA: 0x104521838
	// [Call #8] RVA: 0x104521880
	// [Call #9] RVA: 0x104521830
	// [Call #10] RVA: 0x104521860
	// [Call #11] RVA: 0x104521840

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindBgBg
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045493a4
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindBgBg();
	// [Call #1] RVA: 0x104521850
	// [Call #2] RVA: 0x104521870
	// [Call #3] RVA: 0x104521738
	// [Call #4] RVA: 0x104521828
	// [Call #5] RVA: 0x104521820
	// [Call #6] RVA: 0x104521868
	// [Call #7] RVA: 0x104521848
	// [Call #8] RVA: 0x104521838
	// [Call #9] RVA: 0x104521880
	// [Call #10] RVA: 0x104521830
	// [Call #11] RVA: 0x104521860

	// Object: Function ClientNet.IMSDKHelper.IsAlreadyBindApple
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549370
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlreadyBindApple();
	// [Call #1] RVA: 0x104521858
	// [Call #2] RVA: 0x104521850
	// [Call #3] RVA: 0x104521870
	// [Call #4] RVA: 0x104521738
	// [Call #5] RVA: 0x104521828
	// [Call #6] RVA: 0x104521820
	// [Call #7] RVA: 0x104521868
	// [Call #8] RVA: 0x104521848
	// [Call #9] RVA: 0x104521838
	// [Call #10] RVA: 0x104521880
	// [Call #11] RVA: 0x104521830

	// Object: Function ClientNet.IMSDKHelper.InvalidateQRCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549230
	// Params: [ Num(3) Size(0x30) ]
	void InvalidateQRCode(struct FString InCodeId, struct FString InRandStr, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523908
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104521858
	// [Call #16] RVA: 0x104521850
	// [Call #17] RVA: 0x104521870
	// [Call #18] RVA: 0x104521738
	// [Call #19] RVA: 0x104521828

	// Object: Function ClientNet.IMSDKHelper.InitAdvertiseSDK_iOS
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454921c
	// Params: [ Num(0) Size(0x0) ]
	void InitAdvertiseSDK_iOS();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523908
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104521858
	// [Call #16] RVA: 0x104521850
	// [Call #17] RVA: 0x104521870
	// [Call #18] RVA: 0x104521738
	// [Call #19] RVA: 0x104521828

	// Object: Function ClientNet.IMSDKHelper.InitAdvertiseSDK
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104549208
	// Params: [ Num(0) Size(0x0) ]
	void InitAdvertiseSDK();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x104523908
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104521858
	// [Call #16] RVA: 0x104521850
	// [Call #17] RVA: 0x104521870
	// [Call #18] RVA: 0x104521738

	// Object: Function ClientNet.IMSDKHelper.GetVerifyAppId4SendCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045491a4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetVerifyAppId4SendCode();
	// [Call #1] RVA: 0x104523784
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x104523908
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x104521858
	// [Call #21] RVA: 0x104521850
	// [Call #22] RVA: 0x104521870

	// Object: Function ClientNet.IMSDKHelper.GetShortUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548f90
	// Params: [ Num(3) Size(0x30) ]
	void GetShortUrl(struct FString URL, struct FString Mask, struct FString Extra);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x104522CC4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x100036FE0
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x101F8130C
	// [Call #29] RVA: 0x106C8459C
	// [Call #30] RVA: 0x104523784
	// [Call #31] RVA: 0x101F8156C
	// [Call #32] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetSessionId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548f2c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetSessionId();
	// [Call #1] RVA: 0x104524288
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x104522CC4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x100036FE0
	// [Call #26] RVA: 0x104EEF504
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x100036FE0
	// [Call #29] RVA: 0x104EEF504
	// [Call #30] RVA: 0x100036FE0
	// [Call #31] RVA: 0x101F8130C
	// [Call #32] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetOpenId
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548ec8
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetOpenId();
	// [Call #1] RVA: 0x104521CE4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104524288
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x104522CC4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetLoginResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548e64
	// Params: [ Num(1) Size(0x40) ]
	struct FIMSDKLoginResult GetLoginResult();
	// [Call #1] RVA: 0x1045221C0
	// [Call #2] RVA: 0x1045222F4
	// [Call #3] RVA: 0x1045243B8
	// [Call #4] RVA: 0x1045243B8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104521CE4
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104524288
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x101F8122C
	// [Call #23] RVA: 0x101F8122C
	// [Call #24] RVA: 0x101F8122C

	// Object: Function ClientNet.IMSDKHelper.GetLastLoginResultJson
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548e00
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetLastLoginResultJson();
	// [Call #1] RVA: 0x104522344
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045221C0
	// [Call #7] RVA: 0x1045222F4
	// [Call #8] RVA: 0x1045243B8
	// [Call #9] RVA: 0x1045243B8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104521CE4
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104524288
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.GetLastIMSDKChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548dcc
	// Params: [ Num(1) Size(0x4) ]
	int GetLastIMSDKChannelID();
	// [Call #1] RVA: 0x1045226AC
	// [Call #2] RVA: 0x104522344
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045221C0
	// [Call #8] RVA: 0x1045222F4
	// [Call #9] RVA: 0x1045243B8
	// [Call #10] RVA: 0x1045243B8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104521CE4
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104524288
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104548d98
	// Params: [ Num(1) Size(0x8) ]
	struct UIMSDKHelper* GetInstance();
	// [Call #1] RVA: 0x104521678
	// [Call #2] RVA: 0x1045226AC
	// [Call #3] RVA: 0x104522344
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x1045221C0
	// [Call #9] RVA: 0x1045222F4
	// [Call #10] RVA: 0x1045243B8
	// [Call #11] RVA: 0x1045243B8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x104521CE4
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x104524288
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.GetIMSDKWebLoginParamsLaunchFromWeb
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548c74
	// Params: [ Num(3) Size(0x30) ]
	struct FString GetIMSDKWebLoginParamsLaunchFromWeb(struct FString InState, struct FString InChallenge);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045241D4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x104521678
	// [Call #15] RVA: 0x1045226AC
	// [Call #16] RVA: 0x104522344
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1045221C0
	// [Call #22] RVA: 0x1045222F4
	// [Call #23] RVA: 0x1045243B8
	// [Call #24] RVA: 0x1045243B8
	// [Call #25] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetIMSDKWebLoginParams
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548afc
	// Params: [ Num(4) Size(0x40) ]
	struct FString GetIMSDKWebLoginParams(struct FString InURL, struct FString InAppId, struct FString InVerifier);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10452410C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x1045241D4
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetIMSDKLoginTokenExpireTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548a98
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetIMSDKLoginTokenExpireTime();
	// [Call #1] RVA: 0x104521F8C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10452410C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.GetIMSDKLoginToken
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548a34
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetIMSDKLoginToken();
	// [Call #1] RVA: 0x104521E9C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104521F8C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10452410C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetIMSDKClientApiParams
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045489d0
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetIMSDKClientApiParams();
	// [Call #1] RVA: 0x104523F50
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104521E9C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104521F8C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10452410C
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetHDmpveChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454899c
	// Params: [ Num(1) Size(0x4) ]
	int GetHDmpveChannelID();
	// [Call #1] RVA: 0x1045235E8
	// [Call #2] RVA: 0x104523F50
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104521E9C
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104521F8C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10452410C

	// Object: Function ClientNet.IMSDKHelper.GetDisplayLoginErrorCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548938
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetDisplayLoginErrorCode();
	// [Call #1] RVA: 0x104524320
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045235E8
	// [Call #7] RVA: 0x104523F50
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104521E9C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104521F8C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.GetCurLoginPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045488d4
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCurLoginPlatform();
	// [Call #1] RVA: 0x10452284C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104524320
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1045235E8
	// [Call #12] RVA: 0x104523F50
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104521E9C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104521F8C
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetChannelNickname
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548870
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetChannelNickname();
	// [Call #1] RVA: 0x1045236B0
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10452284C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104524320
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x1045235E8
	// [Call #17] RVA: 0x104523F50
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104521E9C
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C
	// [Call #27] RVA: 0x104521F8C

	// Object: Function ClientNet.IMSDKHelper.GetBindRet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454880c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetBindRet();
	// [Call #1] RVA: 0x1045218FC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045236B0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10452284C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104524320
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1045235E8
	// [Call #22] RVA: 0x104523F50
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C
	// [Call #27] RVA: 0x104521E9C

	// Object: Function ClientNet.IMSDKHelper.GetBindInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045487f8
	// Params: [ Num(0) Size(0x0) ]
	void GetBindInfo();
	// [Call #1] RVA: 0x1045218FC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1045236B0
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10452284C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104524320
	// [Call #17] RVA: 0x101F8156C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x1045235E8
	// [Call #22] RVA: 0x104523F50
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetBindCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045487c4
	// Params: [ Num(1) Size(0x4) ]
	int GetBindCount();
	// [Call #1] RVA: 0x104522048
	// [Call #2] RVA: 0x1045218FC
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x1045236B0
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10452284C
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104524320
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x1045235E8
	// [Call #23] RVA: 0x104523F50
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.GetAllQRCodeLoginResults
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548760
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAllQRCodeLoginResults();
	// [Call #1] RVA: 0x104523C4C
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104522048
	// [Call #7] RVA: 0x1045218FC
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x1045236B0
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10452284C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104524320
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetAdjustID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045486fc
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAdjustID();
	// [Call #1] RVA: 0x104521E38
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104523C4C
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104522048
	// [Call #12] RVA: 0x1045218FC
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x1045236B0
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10452284C
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GetAdjustAttr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548698
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetAdjustAttr();
	// [Call #1] RVA: 0x104521DD4
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x104521E38
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x104523C4C
	// [Call #12] RVA: 0x101F8156C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x104522048
	// [Call #17] RVA: 0x1045218FC
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x1045236B0
	// [Call #23] RVA: 0x101F8156C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.GenerateQRCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548600
	// Params: [ Num(1) Size(0x10) ]
	void GenerateQRCode(struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1045237C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x104521DD4
	// [Call #8] RVA: 0x101F8156C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x104521E38
	// [Call #13] RVA: 0x101F8156C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x104523C4C
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104522048
	// [Call #23] RVA: 0x1045218FC
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.ConvertTConndChannel2IMSDKChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548574
	// Params: [ Num(2) Size(0x8) ]
	int ConvertTConndChannel2IMSDKChannel(int InTConndChannelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522830
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1045237C4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x104521DD4
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x104521E38
	// [Call #16] RVA: 0x101F8156C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x104523C4C
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.ConvertStrToIMSDKChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548480
	// Params: [ Num(2) Size(0x14) ]
	int ConvertStrToIMSDKChannel(struct FString strChannel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x10452275C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x104522830
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1045237C4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x104521DD4
	// [Call #22] RVA: 0x101F8156C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.ConvertIMSDKChannelToStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454838c
	// Params: [ Num(3) Size(0x18) ]
	struct FString ConvertIMSDKChannelToStr(int imsdkChannel, bool caseSensitive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045227F4
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x10452275C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.ConvertIMSDKChannel2TConndChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548300
	// Params: [ Num(2) Size(0x8) ]
	int ConvertIMSDKChannel2TConndChannel(int InIMSDKChannelId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522820
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045227F4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10452275C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504

	// Object: Function ClientNet.IMSDKHelper.ContinueLoginWithLocalResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045482ec
	// Params: [ Num(0) Size(0x0) ]
	void ContinueLoginWithLocalResult();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522820
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045227F4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10452275C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.ClearLoginResult
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045482d8
	// Params: [ Num(0) Size(0x0) ]
	void ClearLoginResult();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522820
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1045227F4
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x10452275C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.CheckVerifyCodeValid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104548070
	// Params: [ Num(7) Size(0x60) ]
	void CheckVerifyCodeValid(struct FString InAccount, int InAccountType, struct FString InPhoneAreaCode, struct FString InVerifyCode, int InCodeType, struct FString InLanuageCode, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045233F0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.CheckLocalForceLoginFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547fe4
	// Params: [ Num(2) Size(0x5) ]
	bool CheckLocalForceLoginFlag(int InChannel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104522870
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.CheckIsRegisted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547e10
	// Params: [ Num(5) Size(0x48) ]
	void CheckIsRegisted(struct FString InAccount, int InAccountType, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1045232F4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x104522870

	// Object: Function ClientNet.IMSDKHelper.ChangePassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547b94
	// Params: [ Num(7) Size(0x68) ]
	void ChangePassword(struct FString InAccount, int InAccountType, struct FString InVerifyCode, struct FString InNewPassword, struct FString InAreaCode, struct FString InLangType, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1045230B4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.BindWhatsApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547afc
	// Params: [ Num(1) Size(0x10) ]
	void BindWhatsApp(struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CCC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.BindVK
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547ae8
	// Params: [ Num(0) Size(0x0) ]
	void BindVK();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CCC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.BindUnifiedAccount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547a50
	// Params: [ Num(1) Size(0x10) ]
	void BindUnifiedAccount(struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521C28
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521CCC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.BindTwitter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547a3c
	// Params: [ Num(0) Size(0x0) ]
	void BindTwitter();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521C28
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521CCC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.BindTikTok
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1045479a4
	// Params: [ Num(1) Size(0x10) ]
	void BindTikTok(struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.BindNosChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547990
	// Params: [ Num(0) Size(0x0) ]
	void BindNosChat();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.IMSDKHelper.BindLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454797c
	// Params: [ Num(0) Size(0x0) ]
	void BindLine();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.BindHMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547968
	// Params: [ Num(0) Size(0x0) ]
	void BindHMS();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.BindGooglePlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547954
	// Params: [ Num(0) Size(0x0) ]
	void BindGooglePlay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.BindGameCenter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547940
	// Params: [ Num(0) Size(0x0) ]
	void BindGameCenter();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function ClientNet.IMSDKHelper.BindFB
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454792c
	// Params: [ Num(0) Size(0x0) ]
	void BindFB();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.BindDiscord
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547918
	// Params: [ Num(0) Size(0x0) ]
	void BindDiscord();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104521CD8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x104521C28
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x104521CCC
	// [Call #16] RVA: 0x101F8130C

	// Object: Function ClientNet.IMSDKHelper.BindChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547844
	// Params: [ Num(2) Size(0x18) ]
	void BindChannel(int InMSDKChannelId, struct FString InExtraJson);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045219AC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104521CD8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.BindBgBg
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104547830
	// Params: [ Num(0) Size(0x0) ]
	void BindBgBg();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045219AC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104521CD8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function ClientNet.IMSDKHelper.BindApple
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454781c
	// Params: [ Num(0) Size(0x0) ]
	void BindApple();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1045219AC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104521CD8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
};

// Object: Class ClientNet.MockGameSvrClientNet
// Size: 0x120 (Inherited: 0x28)
struct UMockGameSvrClientNet : UObject
{
	uint8_t Pad_0x28[0xE0]; // 0x28(0xE0)
	struct FString Host; // 0x108(0x10)
	int Port; // 0x118(0x4)
	uint8_t Pad_0x11C[0x4]; // 0x11C(0x4)


	// Object: Function ClientNet.MockGameSvrClientNet.LoginMockGameSvr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10454d9a4
	// Params: [ Num(3) Size(0x24) ]
	void LoginMockGameSvr(struct FString UID, struct FString PlayerName, int ModeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x10453D724
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
	// [Call #24] RVA: 0x105190870
};

// Object: Class ClientNet.StoreGameHelper
// Size: 0x38 (Inherited: 0x28)
struct UStoreGameHelper : UObject
{
	struct FScriptMulticastDelegate StoreGameCallback; // 0x28(0x10)


	// Object: Function ClientNet.StoreGameHelper.UnlockGPAchievement
	// Flags: [Final|Native|Public]
	// Offset: 0x10454f0c8
	// Params: [ Num(1) Size(0x10) ]
	void UnlockGPAchievement(struct FString InAchievement);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104541AB4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function ClientNet.StoreGameHelper.UnInitialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10454f0b4
	// Params: [ Num(0) Size(0x0) ]
	void UnInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x104541AB4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function ClientNet.StoreGameHelper.ShowLeaderboard
	// Flags: [Final|Native|Public]
	// Offset: 0x10454efdc
	// Params: [ Num(2) Size(0x14) ]
	void ShowLeaderboard(struct FString InIdentifier, int InTimeScope);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B5C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104541AB4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function ClientNet.StoreGameHelper.ShowAchievements
	// Flags: [Final|Native|Public]
	// Offset: 0x10454efc8
	// Params: [ Num(0) Size(0x0) ]
	void ShowAchievements();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B5C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104541AB4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function ClientNet.StoreGameHelper.RequestServerAuthCode
	// Flags: [Final|Native|Public]
	// Offset: 0x10454efb4
	// Params: [ Num(0) Size(0x0) ]
	void RequestServerAuthCode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B5C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104541AB4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function ClientNet.StoreGameHelper.ReportScore
	// Flags: [Final|Native|Public]
	// Offset: 0x10454eee0
	// Params: [ Num(2) Size(0x18) ]
	void ReportScore(int64_t InScore, struct FString InIdentifier);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B54
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104540B5C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x104541AB4

	// Object: Function ClientNet.StoreGameHelper.ReportAchievement1
	// Flags: [Final|Native|Public]
	// Offset: 0x10454ee08
	// Params: [ Num(2) Size(0x18) ]
	void ReportAchievement1(struct FString InIdentifier, double percent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B64
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104540B54
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function ClientNet.StoreGameHelper.ReportAchievement
	// Flags: [Final|Native|Public]
	// Offset: 0x10454ed30
	// Params: [ Num(2) Size(0x18) ]
	void ReportAchievement(struct FString InIdentifier, double percent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B60
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104540B64
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x104540B54

	// Object: Function ClientNet.StoreGameHelper.LoginGPManual
	// Flags: [Final|Native|Public]
	// Offset: 0x10454ed1c
	// Params: [ Num(0) Size(0x0) ]
	void LoginGPManual();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B60
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104540B64
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.LoadReceivedChallenges
	// Flags: [Final|Native|Public]
	// Offset: 0x10454ed08
	// Params: [ Num(0) Size(0x0) ]
	void LoadReceivedChallenges();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104540B60
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x104540B64
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function ClientNet.StoreGameHelper.LoadLeaderboardScores
	// Flags: [Final|Native|Public]
	// Offset: 0x10454eb78
	// Params: [ Num(5) Size(0x20) ]
	void LoadLeaderboardScores(struct FString InIdentifier, int InRangeLocation, int InRangeLength, int InPlayScope, int InTimeScope);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104540B58
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.LoadFriends
	// Flags: [Final|Native|Public]
	// Offset: 0x10454eb64
	// Params: [ Num(0) Size(0x0) ]
	void LoadFriends();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104540B58
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.LoadAchievements
	// Flags: [Final|Native|Public]
	// Offset: 0x10454eb50
	// Params: [ Num(0) Size(0x0) ]
	void LoadAchievements();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104540B58
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function ClientNet.StoreGameHelper.IssueChallengeWithScore
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10454e964
	// Params: [ Num(4) Size(0xC0) ]
	void IssueChallengeWithScore(struct TMap<struct FString, struct FString>& InScoreInfo, struct TMap<struct FString, struct FString>& InPlayerInfo, struct TArray<struct FString>& InPlayerIDs, struct FString InMessage);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8676C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x104541024
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x101F87D64
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F87D64
	// [Call #19] RVA: 0x101F87D64
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function ClientNet.StoreGameHelper.IssueChallengeWithArchivement
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10454e7f0
	// Params: [ Num(3) Size(0x70) ]
	void IssueChallengeWithArchivement(struct TMap<struct FString, struct FString>& InAchievementInfo, struct TArray<struct FString>& InPlayerIDs, struct FString InMessage);
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104540BE4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101F8676C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8676C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function ClientNet.StoreGameHelper.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x10454e7dc
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104540BE4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101F8676C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8676C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.InitGP
	// Flags: [Final|Native|Public]
	// Offset: 0x10454e7c8
	// Params: [ Num(0) Size(0x0) ]
	void InitGP();
	// [Call #1] RVA: 0x101F8676C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x104540BE4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F87D64
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x101F87D64
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101F8676C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8676C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.IncreaseGPAchievement
	// Flags: [Final|Native|Public]
	// Offset: 0x10454e6f0
	// Params: [ Num(2) Size(0x14) ]
	void IncreaseGPAchievement(struct FString InAchievement, int InStep);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x104541AB8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101F8676C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x104540BE4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x101F87D64

	// Object: Function ClientNet.StoreGameHelper.Get
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x10454e6bc
	// Params: [ Num(1) Size(0x8) ]
	struct UStoreGameHelper* Get();
	// [Call #1] RVA: 0x104540A5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104541AB8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x101F8676C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x104540BE4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8B9F8

	// Object: Function ClientNet.StoreGameHelper.Destroy
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x10454e6a8
	// Params: [ Num(0) Size(0x0) ]
	void Destroy();
	// [Call #1] RVA: 0x104540A5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104541AB8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x101F8676C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function ClientNet.StoreGameHelper.AuthenticateLocalPlayer
	// Flags: [Final|Native|Public]
	// Offset: 0x10454e694
	// Params: [ Num(0) Size(0x0) ]
	void AuthenticateLocalPlayer();
	// [Call #1] RVA: 0x104540A5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x104541AB8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x101F8676C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class ClientNet.iTOPPrefs
// Size: 0x100 (Inherited: 0x28)
struct UiTOPPrefs : USaveGame
{
	bool bForceLogin; // 0x28(0x1)
	bool bFirstLoginGuestAfterBindFB; // 0x29(0x1)
	uint8_t Pad_0x2A[0x2]; // 0x2A(0x2)
	int nHDmpveChannelID; // 0x2C(0x4)
	int nLastIMSDKChannelID; // 0x30(0x4)
	bool bNeedFBForceLoginForRelationChainError; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	int64_t lastTimeSetFBForceLoginForRelationChainError; // 0x38(0x8)
	bool bNeedWXForceLoginForRelationChainError; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
	int64_t lastTimeSetWXForceLoginForRelationChainError; // 0x48(0x8)
	bool bNeedVKForceLoginForRelationChainError; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	int64_t lastTimeSetVKForceLoginForRelationChainError; // 0x58(0x8)
	bool bNeedLineForceLoginForRelationChainError; // 0x60(0x1)
	uint8_t Pad_0x61[0x7]; // 0x61(0x7)
	int64_t lastTimeSetLineForceLoginForRelationChainError; // 0x68(0x8)
	bool bNeedBgBgForceLoginForRelationChainError; // 0x70(0x1)
	uint8_t Pad_0x71[0x7]; // 0x71(0x7)
	int64_t lastTimeSetBgBgForceLoginForRelationChainError; // 0x78(0x8)
	bool bNeedAppleForceLoginForRelationChainError; // 0x80(0x1)
	uint8_t Pad_0x81[0x7]; // 0x81(0x7)
	int64_t lastTimeSetAppleForceLoginForRelationChainError; // 0x88(0x8)
	bool bNeedUnifiedAccountForceLoginForRelationChainError; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	int64_t lastTimeSetUnifiedAccountForceLoginForRelationChainError; // 0x98(0x8)
	bool bNeedHMSForceLoginForRelationChainError; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x7]; // 0xA1(0x7)
	int64_t lastTimeSetHMSForceLoginForRelationChainError; // 0xA8(0x8)
	bool bNeedDiscordForceLoginForRelationChainError; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
	int64_t lastTimeSetDiscordForceLoginForRelationChainError; // 0xB8(0x8)
	bool bNeedWhatsAppForceLoginForRelationChainError; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x7]; // 0xC1(0x7)
	int64_t lastTimeSetWhatsappForceLoginForRelationChainError; // 0xC8(0x8)
	bool bNeedTikTokForceLoginForRelationChainError; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
	int64_t lastTimeSetTikTokForceLoginForRelationChainError; // 0xD8(0x8)
	bool bNeedForceLoginForRelationChainError; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
	int64_t lastTimeSetForceLoginForRelationChainError; // 0xE8(0x8)
	struct FString lastLoginArea; // 0xF0(0x10)
};

