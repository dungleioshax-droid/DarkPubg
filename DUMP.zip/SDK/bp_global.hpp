#pragma once

#include <cstdint>

// Object: ScriptBlueprintGeneratedClass bp_global.bp_global_C
// Size: 0x590 (Inherited: 0x518)
struct Abp_global_C : ALuaClassObj
{
	struct UScriptContextComponent* Generated_ScriptContext; // 0x518(0x8)
	int GLOBAL_USE_ITEM; // 0x520(0x4)
	struct FBP_STRUCT_NATION_SWITCH BP_STRUCT_NATION_SWITCH; // 0x524(0x4)
	int BP_StartUpType; // 0x528(0x4)
	int BP_Share_Platform; // 0x52C(0x4)
	bool BP_REVIEW_SVR_ENABLE_GM; // 0x530(0x1)
	uint8_t Pad_0x531[0x3]; // 0x531(0x3)
	int BP_Platform; // 0x534(0x4)
	bool BP_IsAppleAudit; // 0x538(0x1)
	bool BP_IS_EXTERNAL_CHANNEL; // 0x539(0x1)
	bool BP_IOS_CHECK; // 0x53A(0x1)
	uint8_t Pad_0x53B[0x1]; // 0x53B(0x1)
	int BP_GlobalSwitchCameraIndex; // 0x53C(0x4)
	int BP_Global_PreviewItemId; // 0x540(0x4)
	bool BP_Global_AndroidKey_IsValid; // 0x544(0x1)
	bool BP_Global_AdvertiseNeedShowtask; // 0x545(0x1)
	uint8_t Pad_0x546[0x2]; // 0x546(0x2)
	struct FString BP_GEM_REPORT_SUBEVENT; // 0x548(0x10)
	struct FString BP_GEM_REPORT_PARA2; // 0x558(0x10)
	struct FString BP_GEM_REPORT_PARA1; // 0x568(0x10)
	bool BP_CHECK_MENU_OPEN_RESULT; // 0x578(0x1)
	uint8_t Pad_0x579[0x3]; // 0x579(0x3)
	int BP_CHECK_MENU_OPEN_ID; // 0x57C(0x4)
	int BP_BA_REASON; // 0x580(0x4)
	int BP_BA_BUTTON_TYPE; // 0x584(0x4)
	struct USceneComponent* DefaultSceneRoot; // 0x588(0x8)


	// Object: Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatWXStartup_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventShowPlatWXStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatWXStartup();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatQQStartup_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventShowPlatQQStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatQQStartup();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatIconTips_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventShowPlatIconTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventShowPlatIconTips();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSetInfo_Push_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSetInfo_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSetInfo_Push();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSendClickGemReport_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSendClickGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSendClickGemReport();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSendBAReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSendBAReport_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventSendBAReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventSendBAReport();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventGlobalUseItem_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventGlobalUseItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventGlobalUseItem();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventGlobalCloseItemTips_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventGlobalCloseItemTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventGlobalCloseItemTips();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventFetchNationSwitch_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventFetchNationSwitch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventFetchNationSwitch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventFetchInfo_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventFetchInfo_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventFetchInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventFetchInfo();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventComMsgBoxSluaClickUrl_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventComMsgBoxSluaClickUrl();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventClickLobbyEventGemReport_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventClickLobbyEventGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventClickLobbyEventGemReport();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventCheckIfMenuOpen_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventCheckIfMenuOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventCheckIfMenuOpen();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventAndroidQuitGame_NoFetch();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.EventAndroidQuitGame
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void EventAndroidQuitGame();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function bp_global.bp_global_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void UserConstructionScript();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

