#pragma once

#include <cstdint>

// Object: Class YGamePipeline.YGamePipelineHelper
// Size: 0x50 (Inherited: 0x28)
struct UYGamePipelineHelper : UObject
{
	struct FScriptMulticastDelegate PipeDataRevMsg; // 0x28(0x10)
	struct FScriptMulticastDelegate PipeDataRevMsgT; // 0x38(0x10)
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)


	// Object: Function YGamePipeline.YGamePipelineHelper.SendDataWithKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bffc74
	// Params: [ Num(3) Size(0x21) ]
	bool SendDataWithKey(struct FString MsgKey, struct TArray<uint8_t> Data);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101FFC894
	// [Call #7] RVA: 0x102BFE930
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10519022C
	// [Call #22] RVA: 0x105190870
	// [Call #23] RVA: 0x10519022C

	// Object: Function YGamePipeline.YGamePipelineHelper.SendData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bffb80
	// Params: [ Num(2) Size(0x11) ]
	bool SendData(struct FString MsgInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BFE89C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101FFC894
	// [Call #18] RVA: 0x102BFE930
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8BA74
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x100036FE0
	// [Call #27] RVA: 0x104EEF504

	// Object: Function YGamePipeline.YGamePipelineHelper.Release
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bffb6c
	// Params: [ Num(0) Size(0x0) ]
	void Release();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BFE89C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101FFC894
	// [Call #18] RVA: 0x102BFE930
	// [Call #19] RVA: 0x101F8BA74
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8BA74
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8BA74
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x100036FE0

	// Object: Function YGamePipeline.YGamePipelineHelper.RecvdDataWithKeyTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bffa78
	// Params: [ Num(2) Size(0x11) ]
	bool RecvdDataWithKeyTest(struct FString MsgKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BFEC8C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BFE89C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function YGamePipeline.YGamePipelineHelper.RecvDataTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bff984
	// Params: [ Num(2) Size(0x11) ]
	bool RecvDataTest(struct FString MsgInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BFEA5C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BFEC8C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function YGamePipeline.YGamePipelineHelper.Log
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bff8a0
	// Params: [ Num(1) Size(0x10) ]
	void Log(struct FString LogInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x102BFE9CC
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x102BFEA5C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function YGamePipeline.YGamePipelineHelper.IsConnected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bff86c
	// Params: [ Num(1) Size(0x1) ]
	bool IsConnected();
	// [Call #1] RVA: 0x102BFE82C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F8122C
	// [Call #5] RVA: 0x102BFE9CC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x104EEF504
	// [Call #10] RVA: 0x100036FE0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x102BFEA5C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x10516D168

	// Object: Function YGamePipeline.YGamePipelineHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102bff838
	// Params: [ Num(1) Size(0x1) ]
	bool Init();
	// [Call #1] RVA: 0x102BFE764
	// [Call #2] RVA: 0x102BFE82C
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x102BFE9CC
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x102BFEA5C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function YGamePipeline.YGamePipelineHelper.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102bff804
	// Params: [ Num(1) Size(0x8) ]
	struct UYGamePipelineHelper* Get();
	// [Call #1] RVA: 0x102BFE5E4
	// [Call #2] RVA: 0x102BFE764
	// [Call #3] RVA: 0x102BFE82C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x102BFE9CC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x102BFEA5C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x104EEF504
};

