#pragma once

#include <cstdint>

// Object: Enum AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t
{
	Inner = 0,
	Outer = 1,
	ESphericalLimitType_MAX = 2
};

// Object: Enum AnimGraphRuntime.AnimPhysSimSpaceType
enum class EAnimPhysSimSpaceType : uint8_t
{
	Component = 0,
	Actor = 1,
	World = 2,
	RootRelative = 3,
	BoneRelative = 4,
	AnimPhysSimSpaceType_MAX = 5
};

// Object: Enum AnimGraphRuntime.AnimPhysLinearConstraintType
enum class EAnimPhysLinearConstraintType : uint8_t
{
	Free = 0,
	Limited = 1,
	AnimPhysLinearConstraintType_MAX = 2
};

// Object: Enum AnimGraphRuntime.AnimPhysAngularConstraintType
enum class EAnimPhysAngularConstraintType : uint8_t
{
	Angular = 0,
	Cone = 1,
	AnimPhysAngularConstraintType_MAX = 2
};

// Object: Enum AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t
{
	Bone = 0,
	MorphTarget = 1,
	MaterialParameter = 2,
	EDrivenDestinationMode_MAX = 3
};

// Object: Enum AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t
{
	AddToInput = 0,
	ReplaceComponent = 1,
	AddToRefPose = 2,
	EDrivenBoneModificationMode_MAX = 3
};

// Object: Enum AnimGraphRuntime.EComponentType
enum class EComponentType : uint8_t
{
	None = 0,
	TranslationX = 1,
	TranslationY = 2,
	TranslationZ = 3,
	RotationX = 4,
	RotationY = 5,
	RotationZ = 6,
	Scale = 7,
	ScaleX = 8,
	ScaleY = 9,
	ScaleZ = 10,
	EComponentType_MAX = 11
};

// Object: Enum AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t
{
	None = 0,
	Offset_RefPose = 1,
	EConstraintOffsetOption_MAX = 2
};

// Object: Enum AnimGraphRuntime.CopyBoneDeltaMode
enum class ECopyBoneDeltaMode : uint8_t
{
	Accumulate = 0,
	Copy = 1,
	CopyBoneDeltaMode_MAX = 2
};

// Object: Enum AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t
{
	Linear = 0,
	Cubic = 1,
	Sinusoidal = 2,
	EaseInOutExponent2 = 3,
	EaseInOutExponent3 = 4,
	EaseInOutExponent4 = 5,
	EaseInOutExponent5 = 6,
	MAX = 7
};

// Object: Enum AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t
{
	BMM_Ignore = 0,
	BMM_Replace = 1,
	BMM_Additive = 2,
	BMM_MAX = 3
};

// Object: Enum AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t
{
	Add = 0,
	Scale = 1,
	Blend = 2,
	EModifyCurveApplyMode_MAX = 3
};

// Object: Enum AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t
{
	DrivePoses = 0,
	DriveCurves = 1,
	EPoseDriverOutput_MAX = 2
};

// Object: Enum AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t
{
	Rotation = 0,
	Translation = 1,
	EPoseDriverSource_MAX = 2
};

// Object: Enum AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t
{
	SwingAndTwist = 0,
	SwingOnly = 1,
	Translation = 2,
	EPoseDriverType_MAX = 3
};

// Object: Enum AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t
{
	NamedSnapshot = 0,
	SnapshotPin = 1,
	ESnapshotSourceMode_MAX = 2
};

// Object: Enum AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t
{
	EIT_LocalSpace = 0,
	EIT_Additive = 1,
	EIT_MAX = 2
};

// Object: Enum AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t
{
	FixedDefaultLengthValue = 0,
	Distance = 1,
	ChainLength = 2,
	EScaleChainInitialLength_MAX = 3
};

// Object: Enum AnimGraphRuntime.ESequenceEvalTimeType
enum class ESequenceEvalTimeType : uint8_t
{
	ExplicitTime = 0,
	RelativeTime = 1,
	RemainderTime = 2,
	ESequenceEvalTimeType_MAX = 3
};

// Object: Enum AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t
{
	NoReset = 0,
	StartPosition = 1,
	ExplicitTime = 2,
	ESequenceEvalReinit_MAX = 3
};

// Object: Enum AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t
{
	X = 1,
	Y = 2,
	Z = 3,
	ESplineBoneAxis_MAX = 4
};

// Object: Enum AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t
{
	Euclidean = 0,
	Quaternion = 1,
	SwingAngle = 2,
	ERBFDistanceMethod_MAX = 3
};

// Object: Enum AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t
{
	Gaussian = 0,
	Exponential = 1,
	Linear = 2,
	Cubic = 3,
	Quintic = 4,
	ERBFFunctionType_MAX = 5
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Size: 0x78 (Inherited: 0x38)
struct FAnimNode_SkeletalControlBase : FAnimNode_Base
{
	struct FComponentSpacePoseLink ComponentPose; // 0x38(0x18)
	float Alpha; // 0x50(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0x54(0x8)
	int LODThreshold; // 0x5C(0x4)
	float ActualAlpha; // 0x60(0x4)
	uint8_t Pad_0x64[0x14]; // 0x64(0x14)
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Size: 0x30 (Inherited: 0x0)
struct FAnimPhysSphericalLimit
{
	struct FBoneReference DrivingBone; // 0x0(0x18)
	struct FVector SphereLocalOffset; // 0x18(0xC)
	float LimitRadius; // 0x24(0x4)
	uint8_t LimitType; // 0x28(0x1)
	bool IsEnabled; // 0x29(0x1)
	uint8_t Pad_0x2A[0x6]; // 0x2A(0x6)
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Size: 0x60 (Inherited: 0x0)
struct FAnimPhysPlanarLimit
{
	struct FBoneReference DrivingBone; // 0x0(0x18)
	uint8_t Pad_0x18[0x8]; // 0x18(0x8)
	struct FTransform PlaneTransform; // 0x20(0x30)
	bool IsEnabled; // 0x50(0x1)
	uint8_t Pad_0x51[0xF]; // 0x51(0xF)
};

// Object: ScriptStruct AnimGraphRuntime.BoneSocketTarget
// Size: 0x60 (Inherited: 0x0)
struct FBoneSocketTarget
{
	bool bUseSocket; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FBoneReference BoneReference; // 0x8(0x18)
	struct FSocketReference SocketReference; // 0x20(0x40)
};

// Object: ScriptStruct AnimGraphRuntime.SocketReference
// Size: 0x40 (Inherited: 0x0)
struct FSocketReference
{
	struct FName SocketName; // 0x0(0x8)
	uint8_t Pad_0x8[0x38]; // 0x8(0x38)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Size: 0x1C0 (Inherited: 0x78)
struct FAnimNode_TwoBoneIK : FAnimNode_SkeletalControlBase
{
	struct FBoneReference IKBone; // 0x78(0x18)
	uint8_t bAllowStretching : 1; // 0x90(0x1), Mask(0x1)
	uint8_t BitPad_0x90_1 : 7; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float StartStretchRatio; // 0x94(0x4)
	float MaxStretchScale; // 0x98(0x4)
	struct FVector2D StretchLimits; // 0x9C(0x8)
	uint8_t bTakeRotationFromEffectorSpace : 1; // 0xA4(0x1), Mask(0x1)
	uint8_t bMaintainEffectorRelRot : 1; // 0xA4(0x1), Mask(0x2)
	uint8_t BitPad_0xA4_2 : 6; // 0xA4(0x1)
	enum class EBoneControlSpace EffectorLocationSpace; // 0xA5(0x1)
	uint8_t Pad_0xA6[0x2]; // 0xA6(0x2)
	struct FName EffectorSpaceBoneName; // 0xA8(0x8)
	struct FVector EffectorLocation; // 0xB0(0xC)
	uint8_t Pad_0xBC[0x4]; // 0xBC(0x4)
	struct FBoneSocketTarget EffectorTarget; // 0xC0(0x60)
	enum class EBoneControlSpace JointTargetLocationSpace; // 0x120(0x1)
	uint8_t Pad_0x121[0x3]; // 0x121(0x3)
	struct FVector JointTargetLocation; // 0x124(0xC)
	struct FName JointTargetSpaceBoneName; // 0x130(0x8)
	uint8_t Pad_0x138[0x8]; // 0x138(0x8)
	struct FBoneSocketTarget JointTarget; // 0x140(0x60)
	bool bAllowTwist; // 0x1A0(0x1)
	uint8_t Pad_0x1A1[0x3]; // 0x1A1(0x3)
	struct FAxis TwistAxis; // 0x1A4(0x10)
	bool bNoTwist; // 0x1B4(0x1)
	uint8_t Pad_0x1B5[0xB]; // 0x1B5(0xB)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Size: 0xD0 (Inherited: 0x38)
struct FAnimNode_BlendListBase : FAnimNode_Base
{
	struct TArray<struct FPoseLink> BlendPose; // 0x38(0x10)
	struct TArray<float> BlendTime; // 0x48(0x10)
	uint8_t BlendType; // 0x58(0x1)
	uint8_t Pad_0x59[0x7]; // 0x59(0x7)
	struct UCurveFloat* CustomBlendCurve; // 0x60(0x8)
	struct UBlendProfile* BlendProfile; // 0x68(0x8)
	struct TArray<struct FAlphaBlend> Blends; // 0x70(0x10)
	struct TArray<float> BlendWeights; // 0x80(0x10)
	struct TArray<float> RemainingBlendTimes; // 0x90(0x10)
	int LastActiveChildIndex; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct TArray<struct FBlendSampleData> PerBoneSampleData; // 0xA8(0x10)
	uint8_t Pad_0xB8[0x10]; // 0xB8(0x10)
	bool bResetChildOnActivation; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x7]; // 0xC9(0x7)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Size: 0x1B0 (Inherited: 0x78)
struct FAnimNode_Fabrik : FAnimNode_SkeletalControlBase
{
	uint8_t Pad_0x78[0x8]; // 0x78(0x8)
	struct FTransform EffectorTransform; // 0x80(0x30)
	enum class EBoneControlSpace EffectorTransformSpace; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x7]; // 0xB1(0x7)
	struct FBoneReference EffectorTransformBone; // 0xB8(0x18)
	bool bUseIKFreeze; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x3]; // 0xD1(0x3)
	struct FVector PositionFreeze; // 0xD4(0xC)
	struct FVector RotationFreeze; // 0xE0(0xC)
	struct FVector ScaleFeeze; // 0xEC(0xC)
	uint8_t Pad_0xF8[0x8]; // 0xF8(0x8)
	struct FBoneSocketTarget EffectorTarget; // 0x100(0x60)
	enum class EBoneRotationSource EffectorRotationSource; // 0x160(0x1)
	uint8_t Pad_0x161[0x7]; // 0x161(0x7)
	struct FBoneReference TipBone; // 0x168(0x18)
	struct FBoneReference RootBone; // 0x180(0x18)
	float Precision; // 0x198(0x4)
	int MaxIterations; // 0x19C(0x4)
	bool bEnableDebugDraw; // 0x1A0(0x1)
	uint8_t Pad_0x1A1[0xF]; // 0x1A1(0xF)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Size: 0x128 (Inherited: 0x58)
struct FAnimNode_BlendSpacePlayer : FAnimNode_AssetPlayerBase
{
	float X; // 0x58(0x4)
	float Y; // 0x5C(0x4)
	float Z; // 0x60(0x4)
	float PlayRate; // 0x64(0x4)
	bool bLoop; // 0x68(0x1)
	uint8_t Pad_0x69[0x3]; // 0x69(0x3)
	float StartPosition; // 0x6C(0x4)
	struct UBlendSpaceBase* BlendSpace; // 0x70(0x8)
	bool bResetPlayTimeWhenBlendSpaceChanges; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
	struct FBlendFilter BlendFilter; // 0x80(0x90)
	struct TArray<struct FBlendSampleData> BlendSampleDataCache; // 0x110(0x10)
	struct UBlendSpaceBase* PreviousBlendSpace; // 0x120(0x8)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Size: 0x210 (Inherited: 0x128)
struct FAnimNode_AimOffsetLookAt : FAnimNode_BlendSpacePlayer
{
	struct FPoseLink BasePose; // 0x128(0x18)
	int LODThreshold; // 0x140(0x4)
	bool bIsLODEnabled; // 0x144(0x1)
	uint8_t Pad_0x145[0x3]; // 0x145(0x3)
	struct FVector LookAtLocation; // 0x148(0xC)
	uint8_t Pad_0x154[0x4]; // 0x154(0x4)
	struct FName SourceSocketName; // 0x158(0x8)
	struct FName PivotSocketName; // 0x160(0x8)
	struct FVector SocketAxis; // 0x168(0xC)
	float Alpha; // 0x174(0x4)
	struct FBoneReference SocketBoneReference; // 0x178(0x18)
	struct FTransform SocketLocalTransform; // 0x190(0x30)
	struct FBoneReference PivotSocketBoneReference; // 0x1C0(0x18)
	uint8_t Pad_0x1D8[0x8]; // 0x1D8(0x8)
	struct FTransform PivotSocketLocalTransform; // 0x1E0(0x30)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Size: 0x2C0 (Inherited: 0x78)
struct FAnimNode_AnimDynamics : FAnimNode_SkeletalControlBase
{
	uint8_t SimulationSpace; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
	struct FBoneReference RelativeSpaceBone; // 0x80(0x18)
	bool bChain; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
	struct FBoneReference BoundBone; // 0xA0(0x18)
	struct FBoneReference ChainEnd; // 0xB8(0x18)
	struct FVector BoxExtents; // 0xD0(0xC)
	struct FVector LocalJointOffset; // 0xDC(0xC)
	struct FVector OldLocalJointOffset; // 0xE8(0xC)
	float GravityScale; // 0xF4(0x4)
	bool bLinearSpring; // 0xF8(0x1)
	bool bAngularSpring; // 0xF9(0x1)
	uint8_t Pad_0xFA[0x2]; // 0xFA(0x2)
	float LinearSpringConstant; // 0xFC(0x4)
	float AngularSpringConstant; // 0x100(0x4)
	bool bEnableWind; // 0x104(0x1)
	bool bWindWasEnabled; // 0x105(0x1)
	uint8_t Pad_0x106[0x2]; // 0x106(0x2)
	float WindScale; // 0x108(0x4)
	bool bOverrideLinearDamping; // 0x10C(0x1)
	uint8_t Pad_0x10D[0x3]; // 0x10D(0x3)
	float LinearDampingOverride; // 0x110(0x4)
	bool bOverrideAngularDamping; // 0x114(0x1)
	uint8_t Pad_0x115[0x3]; // 0x115(0x3)
	float AngularDampingOverride; // 0x118(0x4)
	bool bOverrideAngularBias; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	float AngularBiasOverride; // 0x120(0x4)
	bool bDoUpdate; // 0x124(0x1)
	bool bDoEval; // 0x125(0x1)
	uint8_t Pad_0x126[0x2]; // 0x126(0x2)
	int NumSolverIterationsPreUpdate; // 0x128(0x4)
	int NumSolverIterationsPostUpdate; // 0x12C(0x4)
	struct FAnimPhysConstraintSetup ConstraintSetup; // 0x130(0x5C)
	bool bUseDynamicAngularLimits; // 0x18C(0x1)
	uint8_t Pad_0x18D[0x3]; // 0x18D(0x3)
	struct FVector Dynamic_AngularLimitsMin; // 0x190(0xC)
	struct FVector Dynamic_AngularLimitsMax; // 0x19C(0xC)
	bool bUsePlanarLimit; // 0x1A8(0x1)
	uint8_t Pad_0x1A9[0x7]; // 0x1A9(0x7)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // 0x1B0(0x10)
	bool bUseSphericalLimits; // 0x1C0(0x1)
	uint8_t Pad_0x1C1[0x7]; // 0x1C1(0x7)
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits; // 0x1C8(0x10)
	uint8_t CollisionType; // 0x1D8(0x1)
	uint8_t Pad_0x1D9[0x3]; // 0x1D9(0x3)
	float SphereCollisionRadius; // 0x1DC(0x4)
	int NonEvaluateFrameNum; // 0x1E0(0x4)
	uint8_t Pad_0x1E4[0x4]; // 0x1E4(0x4)
	struct FVector ExternalForce; // 0x1E8(0xC)
	uint8_t Pad_0x1F4[0xCC]; // 0x1F4(0xCC)
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Size: 0x5C (Inherited: 0x0)
struct FAnimPhysConstraintSetup
{
	uint8_t LinearXLimitType; // 0x0(0x1)
	uint8_t LinearYLimitType; // 0x1(0x1)
	uint8_t LinearZLimitType; // 0x2(0x1)
	uint8_t Pad_0x3[0x1]; // 0x3(0x1)
	struct FVector LinearAxesMin; // 0x4(0xC)
	struct FVector LinearAxesMax; // 0x10(0xC)
	uint8_t AngularConstraintType; // 0x1C(0x1)
	uint8_t TwistAxis; // 0x1D(0x1)
	uint8_t Pad_0x1E[0x2]; // 0x1E(0x2)
	float ConeAngle; // 0x20(0x4)
	float AngularXAngle; // 0x24(0x4)
	float AngularYAngle; // 0x28(0x4)
	float AngularZAngle; // 0x2C(0x4)
	struct FVector AngularLimitsMin; // 0x30(0xC)
	struct FVector AngularLimitsMax; // 0x3C(0xC)
	uint8_t AngularTargetAxis; // 0x48(0x1)
	uint8_t Pad_0x49[0x3]; // 0x49(0x3)
	struct FVector AngularTarget; // 0x4C(0xC)
	bool bLinearFullyLocked; // 0x58(0x1)
	uint8_t Pad_0x59[0x3]; // 0x59(0x3)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Size: 0x80 (Inherited: 0x38)
struct FAnimNode_ApplyAdditive : FAnimNode_Base
{
	struct FPoseLink Base; // 0x38(0x18)
	struct FPoseLink Additive; // 0x50(0x18)
	float Alpha; // 0x68(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0x6C(0x8)
	int LODThreshold; // 0x74(0x4)
	float ActualAlpha; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Size: 0xA8 (Inherited: 0x38)
struct FAnimNode_BlendBoneByChannel : FAnimNode_Base
{
	struct FPoseLink A; // 0x38(0x18)
	struct FPoseLink B; // 0x50(0x18)
	float Alpha; // 0x68(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0x6C(0x8)
	uint8_t Pad_0x74[0x4]; // 0x74(0x4)
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions; // 0x78(0x10)
	enum class EBoneControlSpace TransformsSpace; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	float InternalBlendAlpha; // 0x8C(0x4)
	bool bBIsRelevant; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct TArray<struct FBlendBoneByChannelEntry> ValidBoneEntries; // 0x98(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Size: 0x38 (Inherited: 0x0)
struct FBlendBoneByChannelEntry
{
	struct FBoneReference SourceBone; // 0x0(0x18)
	struct FBoneReference TargetBone; // 0x18(0x18)
	bool bBlendTranslation; // 0x30(0x1)
	bool bBlendRotation; // 0x31(0x1)
	bool bBlendScale; // 0x32(0x1)
	uint8_t Pad_0x33[0x5]; // 0x33(0x5)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Size: 0xD0 (Inherited: 0xD0)
struct FAnimNode_BlendListByBool : FAnimNode_BlendListBase
{
	bool bActiveValue; // 0xC9(0x1)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Size: 0xE8 (Inherited: 0xD0)
struct FAnimNode_BlendListByEnum : FAnimNode_BlendListBase
{
	struct TArray<int> EnumToPoseIndex; // 0xD0(0x10)
	uint8_t ActiveEnumValue; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnumAdvance
// Size: 0xF8 (Inherited: 0xD0)
struct FAnimNode_BlendListByEnumAdvance : FAnimNode_BlendListBase
{
	struct TArray<int> EnumToPoseIndex; // 0xD0(0x10)
	uint8_t ActiveEnumValue; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x7]; // 0xE1(0x7)
	struct TArray<struct FPoseBlendEnumData> PosesBlendTimeSetup; // 0xE8(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.PoseBlendEnumData
// Size: 0x20 (Inherited: 0x0)
struct FPoseBlendEnumData
{
	bool bUseOptionBlendTime; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct FName BlendPoseName; // 0x8(0x8)
	struct TArray<float> OtherPosesBlendTime; // 0x10(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Size: 0xD0 (Inherited: 0xD0)
struct FAnimNode_BlendListByInt : FAnimNode_BlendListBase
{
	int ActiveChildIndex; // 0xCC(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Size: 0x130 (Inherited: 0x128)
struct FAnimNode_BlendSpaceEvaluator : FAnimNode_BlendSpacePlayer
{
	float NormalizedTime; // 0x128(0x4)
	uint8_t Pad_0x12C[0x4]; // 0x12C(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Size: 0xE8 (Inherited: 0x78)
struct FAnimNode_BoneDrivenController : FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone; // 0x78(0x18)
	enum class EComponentType SourceComponent; // 0x90(0x1)
	uint8_t Pad_0x91[0x7]; // 0x91(0x7)
	struct UCurveFloat* DrivingCurve; // 0x98(0x8)
	float Multiplier; // 0xA0(0x4)
	bool bUseRange; // 0xA4(0x1)
	uint8_t Pad_0xA5[0x3]; // 0xA5(0x3)
	float RangeMin; // 0xA8(0x4)
	float RangeMax; // 0xAC(0x4)
	float RemappedMin; // 0xB0(0x4)
	float RemappedMax; // 0xB4(0x4)
	uint8_t DestinationMode; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x7]; // 0xB9(0x7)
	struct FName ParameterName; // 0xC0(0x8)
	struct FBoneReference TargetBone; // 0xC8(0x18)
	enum class EComponentType TargetComponent; // 0xE0(0x1)
	uint8_t bAffectTargetTranslationX : 1; // 0xE1(0x1), Mask(0x1)
	uint8_t bAffectTargetTranslationY : 1; // 0xE1(0x1), Mask(0x2)
	uint8_t bAffectTargetTranslationZ : 1; // 0xE1(0x1), Mask(0x4)
	uint8_t bAffectTargetRotationX : 1; // 0xE1(0x1), Mask(0x8)
	uint8_t bAffectTargetRotationY : 1; // 0xE1(0x1), Mask(0x10)
	uint8_t bAffectTargetRotationZ : 1; // 0xE1(0x1), Mask(0x20)
	uint8_t bAffectTargetScaleX : 1; // 0xE1(0x1), Mask(0x40)
	uint8_t bAffectTargetScaleY : 1; // 0xE1(0x1), Mask(0x80)
	uint8_t bAffectTargetScaleZ : 1; // 0xE2(0x1), Mask(0x1)
	uint8_t BitPad_0xE2_1 : 7; // 0xE2(0x1)
	uint8_t ModificationMode; // 0xE3(0x1)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BoneRetarget
// Size: 0xA8 (Inherited: 0x38)
struct FAnimNode_BoneRetarget : FAnimNode_Base
{
	struct FPoseLink BasePose; // 0x38(0x18)
	uint8_t Pad_0x50[0x50]; // 0x50(0x50)
	bool bUseAsMasterNode; // 0xA0(0x1)
	bool bUseRetargetFeature; // 0xA1(0x1)
	uint8_t Pad_0xA2[0x6]; // 0xA2(0x6)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Size: 0xC0 (Inherited: 0x78)
struct FAnimNode_Constraint : FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify; // 0x78(0x18)
	struct TArray<struct FConstraint> ConstraintSetup; // 0x90(0x10)
	struct TArray<float> ConstraintWeights; // 0xA0(0x10)
	uint8_t Pad_0xB0[0x10]; // 0xB0(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.Constraint
// Size: 0x20 (Inherited: 0x0)
struct FConstraint
{
	struct FBoneReference TargetBone; // 0x0(0x18)
	uint8_t OffsetOption; // 0x18(0x1)
	uint8_t TransformType; // 0x19(0x1)
	struct FFilterOptionPerAxis PerAxis; // 0x1A(0x3)
	uint8_t Pad_0x1D[0x3]; // 0x1D(0x3)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Size: 0xB0 (Inherited: 0x78)
struct FAnimNode_CopyBone : FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone; // 0x78(0x18)
	struct FBoneReference TargetBone; // 0x90(0x18)
	bool bCopyTranslation; // 0xA8(0x1)
	bool bCopyRotation; // 0xA9(0x1)
	bool bCopyScale; // 0xAA(0x1)
	enum class EBoneControlSpace ControlSpace; // 0xAB(0x1)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Size: 0xB8 (Inherited: 0x78)
struct FAnimNode_CopyBoneDelta : FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone; // 0x78(0x18)
	struct FBoneReference TargetBone; // 0x90(0x18)
	bool bCopyTranslation; // 0xA8(0x1)
	bool bCopyRotation; // 0xA9(0x1)
	bool bCopyScale; // 0xAA(0x1)
	uint8_t CopyMode; // 0xAB(0x1)
	float TranslationMultiplier; // 0xAC(0x4)
	float RotationMultiplier; // 0xB0(0x4)
	float ScaleMultiplier; // 0xB4(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Size: 0xC0 (Inherited: 0x38)
struct FAnimNode_CopyPoseFromMesh : FAnimNode_Base
{
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SourceMeshComponent; // 0x34(0x8)
	bool bUseAttachedParent; // 0x3C(0x1)
	uint8_t Pad_0x41[0x7F]; // 0x41(0x7F)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Size: 0x70 (Inherited: 0x38)
struct FAnimNode_CurveSource : FAnimNode_Base
{
	struct FPoseLink SourcePose; // 0x38(0x18)
	struct FName SourceBinding; // 0x50(0x8)
	float Alpha; // 0x58(0x4)
	uint8_t Pad_0x5C[0x4]; // 0x5C(0x4)
	struct TScriptInterface<Class> CurveSource; // 0x60(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Size: 0xF0 (Inherited: 0x78)
struct FAnimNode_HandIKRetargeting : FAnimNode_SkeletalControlBase
{
	struct FBoneReference RightHandFK; // 0x78(0x18)
	struct FBoneReference LeftHandFK; // 0x90(0x18)
	struct FBoneReference RightHandIK; // 0xA8(0x18)
	struct FBoneReference LeftHandIK; // 0xC0(0x18)
	struct TArray<struct FBoneReference> IKBonesToMove; // 0xD8(0x10)
	float HandFKWeight; // 0xE8(0x4)
	uint8_t Pad_0xEC[0x4]; // 0xEC(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Size: 0xE8 (Inherited: 0x38)
struct FAnimNode_LayeredBoneBlend : FAnimNode_Base
{
	struct FPoseLink BasePose; // 0x38(0x18)
	struct TArray<struct FPoseLink> BlendPoses; // 0x50(0x10)
	struct TArray<struct FInputBlendPose> LayerSetup; // 0x60(0x10)
	struct TArray<float> BlendWeights; // 0x70(0x10)
	bool bMeshSpaceRotationBlend; // 0x80(0x1)
	enum class ECurveBlendOption CurveBlendOption; // 0x81(0x1)
	bool bBlendRootMotionBasedOnRootBone; // 0x82(0x1)
	bool bHasRelevantPoses; // 0x83(0x1)
	uint8_t Pad_0x84[0x4]; // 0x84(0x4)
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // 0x88(0x10)
	struct FGuid SkeletonGuid; // 0x98(0x10)
	struct FGuid VirtualBoneGuid; // 0xA8(0x10)
	uint8_t Pad_0xB8[0x30]; // 0xB8(0x30)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Size: 0xA0 (Inherited: 0x78)
struct FAnimNode_LegIK : FAnimNode_SkeletalControlBase
{
	float ReachPrecision; // 0x78(0x4)
	int MaxIterations; // 0x7C(0x4)
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition; // 0x80(0x10)
	struct TArray<struct FAnimLegIKData> LegsData; // 0x90(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.AnimLegIKData
// Size: 0x70 (Inherited: 0x0)
struct FAnimLegIKData
{
	uint8_t Pad_0x0[0x70]; // 0x0(0x70)
};

// Object: ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Size: 0x40 (Inherited: 0x0)
struct FAnimLegIKDefinition
{
	struct FBoneReference IKFootBone; // 0x0(0x18)
	struct FBoneReference FKFootBone; // 0x18(0x18)
	int NumBonesInLimb; // 0x30(0x4)
	enum class EAxis FootBoneForwardAxis; // 0x34(0x1)
	bool bEnableRotationLimit; // 0x35(0x1)
	uint8_t Pad_0x36[0x2]; // 0x36(0x2)
	float MinRotationAngle; // 0x38(0x4)
	bool bEnableKneeTwistCorrection; // 0x3C(0x1)
	uint8_t Pad_0x3D[0x3]; // 0x3D(0x3)
};

// Object: ScriptStruct AnimGraphRuntime.IKChain
// Size: 0x30 (Inherited: 0x0)
struct FIKChain
{
	uint8_t Pad_0x0[0x30]; // 0x0(0x30)
};

// Object: ScriptStruct AnimGraphRuntime.IKChainLink
// Size: 0x1C (Inherited: 0x0)
struct FIKChainLink
{
	uint8_t Pad_0x0[0x1C]; // 0x0(0x1C)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Size: 0x1A0 (Inherited: 0x78)
struct FAnimNode_LookAt : FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify; // 0x78(0x18)
	struct FBoneReference LookAtBone; // 0x90(0x18)
	struct FName LookAtSocket; // 0xA8(0x8)
	struct FBoneSocketTarget LookAtTarget; // 0xB0(0x60)
	struct FVector LookAtLocation; // 0x110(0xC)
	enum class EAxisOption LookAtAxis; // 0x11C(0x1)
	uint8_t Pad_0x11D[0x3]; // 0x11D(0x3)
	struct FVector CustomLookAtAxis; // 0x120(0xC)
	struct FAxis LookAt_Axis; // 0x12C(0x10)
	bool bUseLookUpAxis; // 0x13C(0x1)
	enum class EAxisOption LookUpAxis; // 0x13D(0x1)
	uint8_t Pad_0x13E[0x2]; // 0x13E(0x2)
	struct FVector CustomLookUpAxis; // 0x140(0xC)
	struct FAxis LookUp_Axis; // 0x14C(0x10)
	float LookAtClamp; // 0x15C(0x4)
	enum class EInterpolationBlend InterpolationType; // 0x160(0x1)
	uint8_t Pad_0x161[0x3]; // 0x161(0x3)
	float InterpolationTime; // 0x164(0x4)
	float InterpolationTriggerThreashold; // 0x168(0x4)
	uint8_t Pad_0x16C[0x34]; // 0x16C(0x34)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Size: 0x70 (Inherited: 0x38)
struct FAnimNode_MakeDynamicAdditive : FAnimNode_Base
{
	struct FPoseLink Base; // 0x38(0x18)
	struct FPoseLink Additive; // 0x50(0x18)
	bool bMeshSpaceAdditive; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Size: 0xC0 (Inherited: 0x78)
struct FAnimNode_ModifyBone : FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify; // 0x78(0x18)
	struct FVector Translation; // 0x90(0xC)
	struct FRotator Rotation; // 0x9C(0xC)
	struct FVector Scale; // 0xA8(0xC)
	enum class EBoneModificationMode TranslationMode; // 0xB4(0x1)
	enum class EBoneModificationMode RotationMode; // 0xB5(0x1)
	enum class EBoneModificationMode ScaleMode; // 0xB6(0x1)
	enum class EBoneControlSpace TranslationSpace; // 0xB7(0x1)
	enum class EBoneControlSpace RotationSpace; // 0xB8(0x1)
	enum class EBoneControlSpace ScaleSpace; // 0xB9(0x1)
	uint8_t Pad_0xBA[0x6]; // 0xBA(0x6)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ModifyBoneTransforms
// Size: 0xA8 (Inherited: 0x78)
struct FAnimNode_ModifyBoneTransforms : FAnimNode_SkeletalControlBase
{
	struct FBonesTransfroms BoneTransforms; // 0x78(0x20)
	uint8_t Pad_0x98[0x10]; // 0x98(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.BonesTransfroms
// Size: 0x20 (Inherited: 0x0)
struct FBonesTransfroms
{
	struct TArray<struct FName> Names; // 0x0(0x10)
	struct TArray<struct FTransform> Transforms; // 0x10(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Size: 0x80 (Inherited: 0x38)
struct FAnimNode_ModifyCurve : FAnimNode_Base
{
	struct FPoseLink SourcePose; // 0x38(0x18)
	uint8_t ApplyMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	struct TArray<float> CurveValues; // 0x58(0x10)
	struct TArray<struct FName> CurveNames; // 0x68(0x10)
	float Alpha; // 0x78(0x4)
	uint8_t Pad_0x7C[0x4]; // 0x7C(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Size: 0x78 (Inherited: 0x38)
struct FAnimNode_MultiWayBlend : FAnimNode_Base
{
	struct TArray<struct FPoseLink> Poses; // 0x38(0x10)
	struct TArray<float> DesiredAlphas; // 0x48(0x10)
	bool bAdditiveNode; // 0x58(0x1)
	bool bNormalizeAlpha; // 0x59(0x1)
	uint8_t Pad_0x5A[0x2]; // 0x5A(0x2)
	struct FInputScaleBias AlphaScaleBias; // 0x5C(0x8)
	uint8_t Pad_0x64[0x14]; // 0x64(0x14)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Size: 0xB8 (Inherited: 0x78)
struct FAnimNode_ObserveBone : FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToObserve; // 0x78(0x18)
	enum class EBoneControlSpace DisplaySpace; // 0x90(0x1)
	bool bRelativeToRefPose; // 0x91(0x1)
	uint8_t Pad_0x92[0x2]; // 0x92(0x2)
	struct FVector Translation; // 0x94(0xC)
	struct FRotator Rotation; // 0xA0(0xC)
	struct FVector Scale; // 0xAC(0xC)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Size: 0xA0 (Inherited: 0x58)
struct FAnimNode_PoseHandler : FAnimNode_AssetPlayerBase
{
	struct UPoseAsset* PoseAsset; // 0x58(0x8)
	uint8_t Pad_0x60[0x40]; // 0x60(0x40)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Size: 0xC8 (Inherited: 0xA0)
struct FAnimNode_PoseBlendNode : FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose; // 0xA0(0x18)
	uint8_t BlendOption; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x7]; // 0xB9(0x7)
	struct UCurveFloat* CustomCurve; // 0xC0(0x8)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Size: 0xB0 (Inherited: 0xA0)
struct FAnimNode_PoseByName : FAnimNode_PoseHandler
{
	struct FName PoseName; // 0xA0(0x8)
	float PoseWeight; // 0xA8(0x4)
	uint8_t Pad_0xAC[0x4]; // 0xAC(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Size: 0x178 (Inherited: 0xA0)
struct FAnimNode_PoseDriver : FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose; // 0xA0(0x18)
	struct TArray<struct FBoneReference> SourceBones; // 0xB8(0x10)
	bool bOnlyDriveSelectedBones; // 0xC8(0x1)
	uint8_t Pad_0xC9[0x7]; // 0xC9(0x7)
	struct TArray<struct FBoneReference> OnlyDriveBones; // 0xD0(0x10)
	struct FBoneReference EvalSpaceBone; // 0xE0(0x18)
	struct FRBFParams RBFParams; // 0xF8(0x10)
	uint8_t DriveSource; // 0x108(0x1)
	uint8_t DriveOutput; // 0x109(0x1)
	uint8_t Pad_0x10A[0x6]; // 0x10A(0x6)
	struct TArray<struct FPoseDriverTarget> PoseTargets; // 0x110(0x10)
	struct FBoneReference SourceBone; // 0x120(0x18)
	enum class EBoneAxis TwistAxis; // 0x138(0x1)
	uint8_t Type; // 0x139(0x1)
	uint8_t Pad_0x13A[0x2]; // 0x13A(0x2)
	float RadialScaling; // 0x13C(0x4)
	uint8_t Pad_0x140[0x38]; // 0x140(0x38)
};

// Object: ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Size: 0xA8 (Inherited: 0x0)
struct FPoseDriverTarget
{
	struct TArray<struct FPoseDriverTransform> BoneTransforms; // 0x0(0x10)
	struct FRotator TargetRotation; // 0x10(0xC)
	float TargetScale; // 0x1C(0x4)
	bool bApplyCustomCurve; // 0x20(0x1)
	uint8_t Pad_0x21[0x7]; // 0x21(0x7)
	struct FRichCurve CustomCurve; // 0x28(0x70)
	struct FName DrivenName; // 0x98(0x8)
	uint8_t Pad_0xA0[0x8]; // 0xA0(0x8)
};

// Object: ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Size: 0x18 (Inherited: 0x0)
struct FPoseDriverTransform
{
	struct FVector TargetTranslation; // 0x0(0xC)
	struct FRotator TargetRotation; // 0xC(0xC)
};

// Object: ScriptStruct AnimGraphRuntime.RBFParams
// Size: 0x10 (Inherited: 0x0)
struct FRBFParams
{
	int TargetDimensions; // 0x0(0x4)
	float Radius; // 0x4(0x4)
	uint8_t Function; // 0x8(0x1)
	uint8_t DistanceMethod; // 0x9(0x1)
	enum class EBoneAxis TwistAxis; // 0xA(0x1)
	uint8_t Pad_0xB[0x1]; // 0xB(0x1)
	float WeightThreshold; // 0xC(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Size: 0xB0 (Inherited: 0x38)
struct FAnimNode_PoseSnapshot : FAnimNode_Base
{
	uint8_t Mode; // 0x32(0x1)
	struct FName SnapshotName; // 0x38(0x8)
	struct FPoseSnapshot Snapshot; // 0x40(0x38)
	uint8_t Pad_0x79[0x37]; // 0x79(0x37)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_QuadrupedTerrainAdapting
// Size: 0xBA0 (Inherited: 0x78)
struct FAnimNode_QuadrupedTerrainAdapting : FAnimNode_SkeletalControlBase
{
	bool bEnable; // 0x78(0x1)
	bool bDrawDebug; // 0x79(0x1)
	uint8_t Pad_0x7A[0x2]; // 0x7A(0x2)
	float RayTrace_SphereRadius; // 0x7C(0x4)
	struct FBoneSocketTarget RayTrace_LHandBottom; // 0x80(0x60)
	struct FBoneSocketTarget RayTrace_RHandBottom; // 0xE0(0x60)
	struct FBoneSocketTarget RayTrace_LFootBottom; // 0x140(0x60)
	struct FBoneSocketTarget RayTrace_RFootBottom; // 0x1A0(0x60)
	bool bEnableSlopeAdapting; // 0x200(0x1)
	bool bEnableLionDanceSlopeAdapting; // 0x201(0x1)
	uint8_t Pad_0x202[0x6]; // 0x202(0x6)
	struct FBoneReference SlopeAdapting_Pelvis; // 0x208(0x18)
	struct FBoneReference SlopeAdapting_Pelvis1; // 0x220(0x18)
	struct FBoneReference SlopeAdapting_Pelvis2; // 0x238(0x18)
	struct FBoneReference SlopeAdapting_LClavicle; // 0x250(0x18)
	struct FBoneReference SlopeAdapting_RClavicle; // 0x268(0x18)
	struct FBoneReference SlopeAdapting_LThigh; // 0x280(0x18)
	struct FBoneReference SlopeAdapting_RThigh; // 0x298(0x18)
	struct FBoneReference SlopeAdapting_Root; // 0x2B0(0x18)
	float SlopeAdapting_PelvisLimitHeight; // 0x2C8(0x4)
	float SlopeAdapting_LimitSlopeAngle; // 0x2CC(0x4)
	float SlopeAdapting_PositionLerpSpeed; // 0x2D0(0x4)
	float SlopeAdapting_RotationLerpSpeed; // 0x2D4(0x4)
	float SlopeAdapting_BehindLegModifyFactor; // 0x2D8(0x4)
	bool bEnableLegAdapting; // 0x2DC(0x1)
	uint8_t Pad_0x2DD[0x3]; // 0x2DD(0x3)
	float LegAdapting_IKLerpSpeed; // 0x2E0(0x4)
	float LegAdapting_IKMaxHeight; // 0x2E4(0x4)
	uint8_t Pad_0x2E8[0x8]; // 0x2E8(0x8)
	struct FAnimNode_TwoBoneIK LegAdapting_LHand; // 0x2F0(0x1C0)
	struct FAnimNode_TwoBoneIK LegAdapting_RHand; // 0x4B0(0x1C0)
	struct FAnimNode_TwoBoneIK LegAdapting_LFoot; // 0x670(0x1C0)
	struct FAnimNode_TwoBoneIK LegAdapting_RFoot; // 0x830(0x1C0)
	bool bEnableLionDanceLegAdapting; // 0x9F0(0x1)
	bool bEnableFootAdapting; // 0x9F1(0x1)
	uint8_t Pad_0x9F2[0x6]; // 0x9F2(0x6)
	struct FBoneReference FootAdapting_LHand; // 0x9F8(0x18)
	struct FBoneReference FootAdapting_RHand; // 0xA10(0x18)
	struct FBoneReference FootAdapting_LFoot; // 0xA28(0x18)
	struct FBoneReference FootAdapting_RFoot; // 0xA40(0x18)
	struct FRotator FootAdapting_LimitRotation; // 0xA58(0xC)
	float FootAdapting_RotationLerpSpeed; // 0xA64(0x4)
	uint8_t Pad_0xA68[0x138]; // 0xA68(0x138)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Size: 0x90 (Inherited: 0x38)
struct FAnimNode_RandomPlayer : FAnimNode_Base
{
	bool bShuffleMode; // 0x32(0x1)
	struct TArray<struct FRandomPlayerSequenceEntry> Entries; // 0x38(0x10)
	uint8_t Pad_0x49[0x47]; // 0x49(0x47)
};

// Object: ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Size: 0x58 (Inherited: 0x0)
struct FRandomPlayerSequenceEntry
{
	struct UAnimSequence* Sequence; // 0x0(0x8)
	float ChanceToPlay; // 0x8(0x4)
	int MinLoopCount; // 0xC(0x4)
	int MaxLoopCount; // 0x10(0x4)
	float MinPlayRate; // 0x14(0x4)
	float MaxPlayRate; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FAlphaBlend BlendIn; // 0x20(0x38)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Size: 0x38 (Inherited: 0x38)
struct FAnimNode_MeshSpaceRefPose : FAnimNode_Base
{
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Size: 0x38 (Inherited: 0x38)
struct FAnimNode_RefPose : FAnimNode_Base
{
	enum class ERefPoseType RefPoseType; // 0x32(0x1)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Root
// Size: 0x50 (Inherited: 0x38)
struct FAnimNode_Root : FAnimNode_Base
{
	struct FPoseLink Result; // 0x38(0x18)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Size: 0x68 (Inherited: 0x38)
struct FAnimNode_RotateRootBone : FAnimNode_Base
{
	struct FPoseLink BasePose; // 0x38(0x18)
	float Pitch; // 0x50(0x4)
	float Yaw; // 0x54(0x4)
	struct FRotator MeshToComponent; // 0x58(0xC)
	uint8_t Pad_0x64[0x4]; // 0x64(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotationLimit
// Size: 0xA8 (Inherited: 0x78)
struct FAnimNode_RotationLimit : FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify; // 0x78(0x18)
	struct FRotator RotationLimitMin; // 0x90(0xC)
	struct FRotator RotationLimitMax; // 0x9C(0xC)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Size: 0xB0 (Inherited: 0x78)
struct FAnimNode_RotationMultiplier : FAnimNode_SkeletalControlBase
{
	struct FBoneReference TargetBone; // 0x78(0x18)
	struct FBoneReference SourceBone; // 0x90(0x18)
	float Multiplier; // 0xA8(0x4)
	enum class EBoneAxis RotationAxisToRefer; // 0xAC(0x1)
	bool bIsAdditive; // 0xAD(0x1)
	uint8_t Pad_0xAE[0x2]; // 0xAE(0x2)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Size: 0x158 (Inherited: 0x128)
struct FAnimNode_RotationOffsetBlendSpace : FAnimNode_BlendSpacePlayer
{
	struct FPoseLink BasePose; // 0x128(0x18)
	int LODThreshold; // 0x140(0x4)
	bool bIsLODEnabled; // 0x144(0x1)
	uint8_t Pad_0x145[0x3]; // 0x145(0x3)
	float Alpha; // 0x148(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0x14C(0x8)
	float ActualAlpha; // 0x154(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Size: 0xC0 (Inherited: 0x38)
struct FAnimNode_ScaleChainLength : FAnimNode_Base
{
	struct FPoseLink InputPose; // 0x38(0x18)
	float DefaultChainLength; // 0x50(0x4)
	uint8_t Pad_0x54[0x4]; // 0x54(0x4)
	struct FBoneReference ChainStartBone; // 0x58(0x18)
	struct FBoneReference ChainEndBone; // 0x70(0x18)
	uint8_t ChainInitialLength; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	struct FVector TargetLocation; // 0x8C(0xC)
	float Alpha; // 0x98(0x4)
	float ActualAlpha; // 0x9C(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0xA0(0x8)
	bool bBoneIndicesCached; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x17]; // 0xA9(0x17)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Size: 0x70 (Inherited: 0x58)
struct FAnimNode_SequenceEvaluator : FAnimNode_AssetPlayerBase
{
	struct UAnimSequenceBase* Sequence; // 0x58(0x8)
	float ExplicitTime; // 0x60(0x4)
	enum class ESequenceEvalTimeType ExplicitTimeType; // 0x64(0x1)
	bool bShouldLoop; // 0x65(0x1)
	bool bTeleportToExplicitTime; // 0x66(0x1)
	uint8_t Pad_0x67[0x1]; // 0x67(0x1)
	float StartPosition; // 0x68(0x4)
	enum class ESequenceEvalReinit ReinitializationBehavior; // 0x6C(0x1)
	bool bReinitialized; // 0x6D(0x1)
	uint8_t Pad_0x6E[0x2]; // 0x6E(0x2)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Size: 0x70 (Inherited: 0x38)
struct FAnimNode_Slot : FAnimNode_Base
{
	struct FPoseLink Source; // 0x38(0x18)
	struct FName SlotName; // 0x50(0x8)
	bool bAlwaysUpdateSourcePose; // 0x58(0x1)
	uint8_t Pad_0x59[0x17]; // 0x59(0x17)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Size: 0x218 (Inherited: 0x78)
struct FAnimNode_SplineIK : FAnimNode_SkeletalControlBase
{
	struct FBoneReference StartBone; // 0x78(0x18)
	struct FBoneReference EndBone; // 0x90(0x18)
	uint8_t BoneAxis; // 0xA8(0x1)
	bool bAutoCalculateSpline; // 0xA9(0x1)
	uint8_t Pad_0xAA[0x2]; // 0xAA(0x2)
	int PointCount; // 0xAC(0x4)
	struct TArray<struct FTransform> ControlPoints; // 0xB0(0x10)
	float Roll; // 0xC0(0x4)
	float TwistStart; // 0xC4(0x4)
	float TwistEnd; // 0xC8(0x4)
	uint8_t Pad_0xCC[0x4]; // 0xCC(0x4)
	struct FAlphaBlend TwistBlend; // 0xD0(0x38)
	float Stretch; // 0x108(0x4)
	float Offset; // 0x10C(0x4)
	uint8_t Pad_0x110[0x70]; // 0x110(0x70)
	struct FSplineCurves BoneSpline; // 0x180(0x60)
	float OriginalSplineLength; // 0x1E0(0x4)
	uint8_t Pad_0x1E4[0x4]; // 0x1E4(0x4)
	struct TArray<struct FSplineIKCachedBoneData> CachedBoneReferences; // 0x1E8(0x10)
	struct TArray<float> CachedBoneLengths; // 0x1F8(0x10)
	struct TArray<struct FQuat> CachedOffsetRotations; // 0x208(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Size: 0x20 (Inherited: 0x0)
struct FSplineIKCachedBoneData
{
	struct FBoneReference Bone; // 0x0(0x18)
	int RefSkeletonIndex; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Size: 0xE0 (Inherited: 0x78)
struct FAnimNode_SpringBone : FAnimNode_SkeletalControlBase
{
	struct FBoneReference SpringBone; // 0x78(0x18)
	bool bLimitDisplacement; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float MaxDisplacement; // 0x94(0x4)
	float SpringStiffness; // 0x98(0x4)
	float SpringDamping; // 0x9C(0x4)
	float ErrorResetThresh; // 0xA0(0x4)
	bool bNoZSpring; // 0xA4(0x1)
	bool bTranslateX; // 0xA5(0x1)
	bool bTranslateY; // 0xA6(0x1)
	bool bTranslateZ; // 0xA7(0x1)
	bool bRotateX; // 0xA8(0x1)
	bool bRotateY; // 0xA9(0x1)
	bool bRotateZ; // 0xAA(0x1)
	uint8_t Pad_0xAB[0x35]; // 0xAB(0x35)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Size: 0x1B0 (Inherited: 0x78)
struct FAnimNode_Trail : FAnimNode_SkeletalControlBase
{
	struct FBoneReference TrailBone; // 0x78(0x18)
	int ChainLength; // 0x90(0x4)
	enum class EAxis ChainBoneAxis; // 0x94(0x1)
	bool bInvertChainBoneAxis; // 0x95(0x1)
	uint8_t Pad_0x96[0x2]; // 0x96(0x2)
	float TrailRelaxation; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
	struct FRuntimeFloatCurve TrailRelaxationSpeed; // 0xA0(0x78)
	bool bLimitStretch; // 0x118(0x1)
	uint8_t Pad_0x119[0x3]; // 0x119(0x3)
	float StretchLimit; // 0x11C(0x4)
	struct FVector FakeVelocity; // 0x120(0xC)
	bool bActorSpaceFakeVel; // 0x12C(0x1)
	uint8_t Pad_0x12D[0x3]; // 0x12D(0x3)
	struct FBoneReference BaseJoint; // 0x130(0x18)
	uint8_t Pad_0x148[0x68]; // 0x148(0x68)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Size: 0x100 (Inherited: 0x78)
struct FAnimNode_TwistCorrectiveNode : FAnimNode_SkeletalControlBase
{
	struct FReferenceBoneFrame BaseFrame; // 0x78(0x28)
	struct FReferenceBoneFrame TwistFrame; // 0xA0(0x28)
	struct FAxis TwistPlaneNormalAxis; // 0xC8(0x10)
	float RangeMax; // 0xD8(0x4)
	float RemappedMin; // 0xDC(0x4)
	float RemappedMax; // 0xE0(0x4)
	uint8_t Pad_0xE4[0x4]; // 0xE4(0x4)
	struct FAnimCurveParam Curve; // 0xE8(0x10)
	uint8_t Pad_0xF8[0x8]; // 0xF8(0x8)
};

// Object: ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Size: 0x28 (Inherited: 0x0)
struct FReferenceBoneFrame
{
	struct FBoneReference Bone; // 0x0(0x18)
	struct FAxis Axis; // 0x18(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Size: 0x80 (Inherited: 0x38)
struct FAnimNode_TwoWayBlend : FAnimNode_Base
{
	struct FPoseLink A; // 0x38(0x18)
	struct FPoseLink B; // 0x50(0x18)
	float Alpha; // 0x68(0x4)
	struct FInputScaleBias AlphaScaleBias; // 0x6C(0x8)
	float InternalBlendAlpha; // 0x74(0x4)
	bool bAIsRelevant; // 0x78(0x1)
	bool bBIsRelevant; // 0x79(0x1)
	bool bResetChildOnActivation; // 0x7A(0x1)
	uint8_t Pad_0x7B[0x5]; // 0x7B(0x5)
};

// Object: ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Size: 0x790 (Inherited: 0x5D0)
struct FAnimSequencerInstanceProxy : FAnimInstanceProxy
{
	uint8_t Pad_0x5D0[0x1C0]; // 0x5D0(0x1C0)
};

// Object: ScriptStruct AnimGraphRuntime.RBFEntry
// Size: 0x10 (Inherited: 0x0)
struct FRBFEntry
{
	struct TArray<float> Values; // 0x0(0x10)
};

// Object: ScriptStruct AnimGraphRuntime.RBFTarget
// Size: 0x88 (Inherited: 0x10)
struct FRBFTarget : FRBFEntry
{
	float ScaleFactor; // 0x10(0x4)
	bool bApplyCustomCurve; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
	struct FRichCurve CustomCurve; // 0x18(0x70)
};

// Object: Class AnimGraphRuntime.AnimCustomInstance
// Size: 0x3F0 (Inherited: 0x3F0)
struct UAnimCustomInstance : UAnimInstance
{
};

// Object: Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// Size: 0x40 (Inherited: 0x38)
struct UAnimNotify_PlayMontageNotify : UAnimNotify
{
	struct FName NotifyName; // 0x38(0x8)
};

// Object: Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// Size: 0x38 (Inherited: 0x30)
struct UAnimNotify_PlayMontageNotifyWindow : UAnimNotifyState
{
	struct FName NotifyName; // 0x30(0x8)
};

// Object: Class AnimGraphRuntime.AnimSequencerInstance
// Size: 0x3F0 (Inherited: 0x3F0)
struct UAnimSequencerInstance : UAnimCustomInstance
{
};

// Object: Class AnimGraphRuntime.KismetAnimationLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetAnimationLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105c96e70
	// Params: [ Num(10) Size(0x60) ]
	void K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105c96c6c
	// Params: [ Num(7) Size(0x90) ]
	struct FTransform K2_LookAt(struct FTransform& CurrentTransform, struct FVector& TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x105C82EAC
	// [Call #14] RVA: 0x10516D168
};

// Object: Class AnimGraphRuntime.PlayMontageCallbackProxy
// Size: 0xA8 (Inherited: 0x28)
struct UPlayMontageCallbackProxy : UObject
{
	struct FScriptMulticastDelegate OnCompleted; // 0x28(0x10)
	struct FScriptMulticastDelegate OnBlendOut; // 0x38(0x10)
	struct FScriptMulticastDelegate OnInterrupted; // 0x48(0x10)
	struct FScriptMulticastDelegate OnNotifyBegin; // 0x58(0x10)
	struct FScriptMulticastDelegate OnNotifyEnd; // 0x68(0x10)
	uint8_t Pad_0x78[0x30]; // 0x78(0x30)


	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x105c97730
	// Params: [ Num(2) Size(0x28) ]
	void OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C835E8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x105c9765c
	// Params: [ Num(2) Size(0x28) ]
	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C83558
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C835E8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
	// Flags: [Final|Native|Protected]
	// Offset: 0x105c9759c
	// Params: [ Num(2) Size(0x9) ]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C834A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C83558
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105C835E8

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
	// Flags: [Final|Native|Protected]
	// Offset: 0x105c974dc
	// Params: [ Num(2) Size(0x9) ]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x105C83458
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x105C834A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x105C83558

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105c97378
	// Params: [ Num(6) Size(0x28) ]
	struct UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105C831D8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105C83458
	// [Call #17] RVA: 0x10516D168
};

