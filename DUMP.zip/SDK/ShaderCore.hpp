#pragma once

#include <cstdint>

// Object: ScriptStruct ShaderCore.MapRenderConfig
// Size: 0x98 (Inherited: 0x0)
struct FMapRenderConfig
{
	struct FName ConfigName; // 0x0(0x8)
	struct FName MapName; // 0x8(0x8)
	struct TArray<struct FName> LevelNames; // 0x10(0x10)
	struct FOverrideRenderConfig OverrideRenderConfig; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct FRenderConfig RenderConfig; // 0x28(0x70)
};

// Object: ScriptStruct ShaderCore.RenderConfig
// Size: 0x70 (Inherited: 0x0)
struct FRenderConfig
{
	struct FName FormatName; // 0x0(0x8)
	struct FName FeatureLevel; // 0x8(0x8)
	int QualityType; // 0x10(0x4)
	int UserQualitySetting; // 0x14(0x4)
	struct FName MaterialQualityLevel; // 0x18(0x8)
	int PUBGLDR; // 0x20(0x4)
	int MobileHDR; // 0x24(0x4)
	int MobileSimplerShader; // 0x28(0x4)
	int ShadowQuality; // 0x2C(0x4)
	int MaxCSMShadowResolution; // 0x30(0x4)
	int MobileEnableHardwarePCF; // 0x34(0x4)
	int MobileEnableIBL; // 0x38(0x4)
	int MobileEarlyZPass; // 0x3C(0x4)
	int MobileEnableEarlyZDepthBias; // 0x40(0x4)
	int MobileUseAlphaToCoverage; // 0x44(0x4)
	int MobileBypassTranslucentMaterialPointLight; // 0x48(0x4)
	int MobileMSAA; // 0x4C(0x4)
	int AllowStaticLighting; // 0x50(0x4)
	int SupportAllShaderPermutations; // 0x54(0x4)
	int SupportLowQualityLightmaps; // 0x58(0x4)
	int MobileEnableVertexPointLight; // 0x5C(0x4)
	int MobileFallbackMSAAToFXAA; // 0x60(0x4)
	int IndirectLightingCache; // 0x64(0x4)
	int MobileNumDynamicPointLights; // 0x68(0x4)
	bool RHISupportsTexLod; // 0x6C(0x1)
	bool RHISupportsHardwarePCF; // 0x6D(0x1)
	uint8_t Pad_0x6E[0x2]; // 0x6E(0x2)
};

// Object: ScriptStruct ShaderCore.OverrideRenderConfig
// Size: 0x4 (Inherited: 0x0)
struct FOverrideRenderConfig
{
	uint8_t bFormatName : 1; // 0x0(0x1), Mask(0x1)
	uint8_t bFeatureLevel : 1; // 0x0(0x1), Mask(0x2)
	uint8_t bQualityType : 1; // 0x0(0x1), Mask(0x4)
	uint8_t bUserQualitySetting : 1; // 0x0(0x1), Mask(0x8)
	uint8_t bMaterialQualityLevel : 1; // 0x0(0x1), Mask(0x10)
	uint8_t bPUBGLDR : 1; // 0x0(0x1), Mask(0x20)
	uint8_t bMobileHDR : 1; // 0x0(0x1), Mask(0x40)
	uint8_t bMobileSimplerShader : 1; // 0x0(0x1), Mask(0x80)
	uint8_t bShadowQuality : 1; // 0x1(0x1), Mask(0x1)
	uint8_t bMaxCSMShadowResolution : 1; // 0x1(0x1), Mask(0x2)
	uint8_t bMobileEnableHardwarePCF : 1; // 0x1(0x1), Mask(0x4)
	uint8_t bMobileEnableIBL : 1; // 0x1(0x1), Mask(0x8)
	uint8_t bMobileEarlyZPass : 1; // 0x1(0x1), Mask(0x10)
	uint8_t bMobileEnableEarlyZDepthBias : 1; // 0x1(0x1), Mask(0x20)
	uint8_t bMobileUseAlphaToCoverage : 1; // 0x1(0x1), Mask(0x40)
	uint8_t bMobileBypassTranslucentMaterialPointLight : 1; // 0x1(0x1), Mask(0x80)
	uint8_t bMobileMSAA : 1; // 0x2(0x1), Mask(0x1)
	uint8_t bAllowStaticLighting : 1; // 0x2(0x1), Mask(0x2)
	uint8_t bSupportAllShaderPermutations : 1; // 0x2(0x1), Mask(0x4)
	uint8_t bSupportLowQualityLightmaps : 1; // 0x2(0x1), Mask(0x8)
	uint8_t bMobileEnableVertexPointLight : 1; // 0x2(0x1), Mask(0x10)
	uint8_t bMobileFallbackMSAAToFXAA : 1; // 0x2(0x1), Mask(0x20)
	uint8_t bIndirectLightingCache : 1; // 0x2(0x1), Mask(0x40)
	uint8_t bMobileNumDynamicPointLights : 1; // 0x2(0x1), Mask(0x80)
	uint8_t bRHISupportsTexLod : 1; // 0x3(0x1), Mask(0x1)
	uint8_t bRHISupportsHardwarePCF : 1; // 0x3(0x1), Mask(0x2)
	uint8_t BitPad_0x3_2 : 6; // 0x3(0x1)
};

// Object: ScriptStruct ShaderCore.DeviceRenderConfig
// Size: 0x78 (Inherited: 0x0)
struct FDeviceRenderConfig
{
	struct FName ConfigName; // 0x0(0x8)
	struct FRenderConfig RenderConfig; // 0x8(0x70)
};

// Object: ScriptStruct ShaderCore.CollectSwitchs
// Size: 0x18 (Inherited: 0x0)
struct FCollectSwitchs
{
	struct FName PlatformName; // 0x0(0x8)
	bool LevelStaticMeshMobile; // 0x8(0x1)
	bool LevelStaticMeshShadowDepth; // 0x9(0x1)
	bool LevelStaticMeshDepth; // 0xA(0x1)
	bool SkeletalMeshMobile; // 0xB(0x1)
	bool SkeletalMeshShadowDepth; // 0xC(0x1)
	bool SkeletalMeshDepth; // 0xD(0x1)
	bool ParticleSpriteMobile; // 0xE(0x1)
	bool MeshParticleMobile; // 0xF(0x1)
	bool LandscapeMobile; // 0x10(0x1)
	bool LandscapeShadowDepth; // 0x11(0x1)
	bool LandscapeDepth; // 0x12(0x1)
	bool SlateDefaultBase; // 0x13(0x1)
	bool SlateFontBase; // 0x14(0x1)
	uint8_t Pad_0x15[0x3]; // 0x15(0x3)
};

// Object: ScriptStruct ShaderCore.ShaderGroupDesc
// Size: 0x40 (Inherited: 0x0)
struct FShaderGroupDesc
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct FString Name; // 0x8(0x10)
	struct FString Parent; // 0x18(0x10)
	uint8_t Pad_0x28[0x18]; // 0x28(0x18)
};

// Object: ScriptStruct ShaderCore.ShaderPak
// Size: 0x60 (Inherited: 0x40)
struct FShaderPak : FShaderGroupDesc
{
	struct TArray<struct FString> Include; // 0x40(0x10)
	struct TArray<struct FString> Exclude; // 0x50(0x10)
};

// Object: ScriptStruct ShaderCore.ShaderLevel
// Size: 0x60 (Inherited: 0x40)
struct FShaderLevel : FShaderGroupDesc
{
	struct TArray<struct FString> Include; // 0x40(0x10)
	struct TArray<struct FString> Quality; // 0x50(0x10)
};

// Object: Class ShaderCore.PrecompileShaderGameConfig
// Size: 0x70 (Inherited: 0x28)
struct UPrecompileShaderGameConfig : UObject
{
	struct TArray<struct FCollectSwitchs> CollectSwitchs; // 0x28(0x10)
	struct TArray<struct FDeviceRenderConfig> DeviceRenderConfigs; // 0x38(0x10)
	struct TArray<struct FMapRenderConfig> MapRenderConfigs; // 0x48(0x10)
	uint8_t Pad_0x58[0x18]; // 0x58(0x18)
};

// Object: Class ShaderCore.ShaderGroupSettings
// Size: 0xA0 (Inherited: 0x28)
struct UShaderGroupSettings : UObject
{
	struct TArray<struct FShaderLevel> Levels_IOS; // 0x28(0x10)
	struct TArray<struct FShaderLevel> Levels_AOS; // 0x38(0x10)
	struct TArray<struct FShaderPak> Paks_IOS; // 0x48(0x10)
	struct TArray<struct FShaderPak> Paks_AOS; // 0x58(0x10)
	struct TArray<struct FShaderPak> Paks_PC; // 0x68(0x10)
	uint8_t Pad_0x78[0x28]; // 0x78(0x28)
};

