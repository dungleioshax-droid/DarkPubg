#pragma once

#include <cstdint>

// Object: Enum AkAudio.AkAcousticPortalState
enum class EAkAcousticPortalState : uint8_t
{
	Closed = 0,
	Open = 1,
	AkAcousticPortalState_MAX = 2
};

// Object: Enum AkAudio.ECustomAKAreaType
enum class ECustomAKAreaType : uint8_t
{
	EAT_NormalArea = 0,
	EAT_ApartArea = 1,
	EAT_ApartArea2 = 2,
	EAT_TransitionArea = 3,
	EAT_MAX = 4
};

// Object: Enum AkAudio.EReflectionFilterBits
enum class EReflectionFilterBits : uint8_t
{
	Wall = 0,
	Ceiling = 1,
	Floor = 2,
	EReflectionFilterBits_MAX = 3
};

// Object: Enum AkAudio.PanningRule
enum class EPanningRule : uint8_t
{
	PanningRule_Speakers = 0,
	PanningRule_Headphones = 1,
	PanningRule_MAX = 2
};

// Object: Enum AkAudio.AkChannelConfiguration
enum class EAkChannelConfiguration : uint8_t
{
	Ak_Parent = 0,
	Ak_1_0 = 1,
	Ak_2_0 = 2,
	Ak_3_0 = 3,
	Ak_4_0 = 4,
	Ak_5_1 = 5,
	Ak_7_1 = 6,
	Ak_5_1_2 = 7,
	Ak_7_1_2 = 8,
	Ak_7_1_4 = 9,
	Ak_Auro_9_1 = 10,
	Ak_Auro_10_1 = 11,
	Ak_Auro_11_1 = 12,
	Ak_Auro_13_1 = 13,
	Ak_Ambisonics_1st_order = 14,
	Ak_Ambisonics_2nd_order = 15,
	Ak_Ambisonics_3rd_order = 16,
	Ak_MAX = 17
};

// Object: Enum AkAudio.EFrequencyRange
enum class EFrequencyRange : uint8_t
{
	SubBass = 0,
	Bass = 1,
	LowMid = 2,
	Mid = 3,
	UpperMid = 4,
	High = 5,
	VeryHigh = 6,
	Decibal = 7,
	EFrequencyRange_MAX = 8
};

// Object: ScriptStruct AkAudio.AkAmbSoundCheckpointRecord
// Size: 0x1 (Inherited: 0x0)
struct FAkAmbSoundCheckpointRecord
{
	bool bCurrentlyPlaying; // 0x0(0x1)
};

// Object: ScriptStruct AkAudio.AKAreaVolumeArray
// Size: 0x10 (Inherited: 0x0)
struct FAKAreaVolumeArray
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct AkAudio.AkCombinedInfo
// Size: 0xC0 (Inherited: 0x0)
struct FAkCombinedInfo
{
	struct FVector Location; // 0x0(0xC)
	bool bActive; // 0xC(0x1)
	bool bIsUpdateEmmiterTransform; // 0xD(0x1)
	uint8_t Pad_0xE[0x2]; // 0xE(0x2)
	struct TArray<struct FString> EventList; // 0x10(0x10)
	struct TMap<struct FString, float> RTPCList; // 0x20(0x50)
	struct TMap<struct FString, struct FString> SwitchList; // 0x70(0x50)
};

// Object: ScriptStruct AkAudio.AKErrorInfo
// Size: 0x58 (Inherited: 0x0)
struct FAKErrorInfo
{
	uint8_t AKRESULT_ID; // 0x0(0x1)
	uint8_t Pad_0x1[0x7]; // 0x1(0x7)
	struct TSet<struct FAKFunctionInfo> DetailInfo; // 0x8(0x50)
};

// Object: ScriptStruct AkAudio.AKFunctionInfo
// Size: 0x28 (Inherited: 0x0)
struct FAKFunctionInfo
{
	struct FString FunctionName; // 0x0(0x10)
	struct FString StrParam; // 0x10(0x10)
	int NumParam; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
};

// Object: ScriptStruct AkAudio.AkRangedEmitterInfo
// Size: 0x18 (Inherited: 0x0)
struct FAkRangedEmitterInfo
{
	float RangeSquare; // 0x0(0x4)
	uint32_t PlayingID; // 0x4(0x4)
	struct FString EventName; // 0x8(0x10)
};

// Object: ScriptStruct AkAudio.AkPoly
// Size: 0x10 (Inherited: 0x0)
struct FAkPoly
{
	struct UAkAcousticTexture* Texture; // 0x0(0x8)
	bool EnableSurface; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct AkAudio.AudioOfflineVisualBeatData
// Size: 0x18 (Inherited: 0x0)
struct FAudioOfflineVisualBeatData
{
	float BeatTime; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct TArray<float> Intensity; // 0x8(0x10)
};

// Object: ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 (Inherited: 0x0)
struct FAkAudioEventTrackKey
{
	float Time; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct UAkAudioEvent* AkAudioEvent; // 0x8(0x8)
	struct FString EventName; // 0x10(0x10)
};

// Object: ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x20 (Inherited: 0x18)
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate
{
	struct UMovieSceneAkAudioEventSection* Section; // 0x18(0x8)
};

// Object: ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x20 (Inherited: 0x18)
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate
{
	struct UMovieSceneAkAudioRTPCSection* Section; // 0x18(0x8)
};

// Object: ScriptStruct AkAudio.MovieSceneAkAudioRTPCSectionData
// Size: 0x80 (Inherited: 0x0)
struct FMovieSceneAkAudioRTPCSectionData
{
	struct FString RTPCName; // 0x0(0x10)
	struct FRichCurve RTPCCurve; // 0x10(0x70)
};

// Object: Class AkAudio.AkAcousticPortal
// Size: 0x4F0 (Inherited: 0x4E0)
struct AAkAcousticPortal : AVolume
{
	float Gain; // 0x4E0(0x4)
	uint8_t InitialState; // 0x4E4(0x1)
	uint8_t Pad_0x4E5[0xB]; // 0x4E5(0xB)


	// Object: Function AkAudio.AkAcousticPortal.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f99fc4
	// Params: [ Num(0) Size(0x0) ]
	void OpenPortal();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function AkAudio.AkAcousticPortal.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101f99f90
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetCurrentState();
	// [Call #1] RVA: 0x101F60A78
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870

	// Object: Function AkAudio.AkAcousticPortal.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f99f7c
	// Params: [ Num(0) Size(0x0) ]
	void ClosePortal();
	// [Call #1] RVA: 0x101F60A78
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
};

// Object: Class AkAudio.AkAcousticTexture
// Size: 0x28 (Inherited: 0x28)
struct UAkAcousticTexture : UObject
{
};

// Object: Class AkAudio.AkAmbientSound
// Size: 0x508 (Inherited: 0x4B0)
struct AAkAmbientSound : AActor
{
	struct UAkAudioEvent* AkAudioEvent; // 0x4B0(0x8)
	struct UAkComponent* AkComponent; // 0x4B8(0x8)
	bool StopWhenOwnerIsDestroyed; // 0x4C0(0x1)
	bool AutoPost; // 0x4C1(0x1)
	uint8_t Pad_0x4C2[0x46]; // 0x4C2(0x46)


	// Object: Function AkAudio.AkAmbientSound.StopAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9a3a4
	// Params: [ Num(0) Size(0x0) ]
	void StopAmbientSound();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x101F99F14
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0

	// Object: Function AkAudio.AkAmbientSound.StartAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9a390
	// Params: [ Num(0) Size(0x0) ]
	void StartAmbientSound();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x101F99F14
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0
};

// Object: Class AkAudio.AkAreaCheckComponent
// Size: 0x1C8 (Inherited: 0x178)
struct UAkAreaCheckComponent : UActorComponent
{
	struct TMap<uint8_t, struct FAKAreaVolumeArray> RegistedAreaVolume; // 0x178(0x50)


	// Object: Function AkAudio.AkAreaCheckComponent.UnRegistAKAreaVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9a81c
	// Params: [ Num(2) Size(0x9) ]
	void UnRegistAKAreaVolume(struct AActor* AreaVolume, uint8_t AreaType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6154C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AkAreaCheckComponent.RegistAKAreaVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9a764
	// Params: [ Num(2) Size(0x9) ]
	void RegistAKAreaVolume(struct AActor* AreaVolume, uint8_t AreaType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F614C4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F6154C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function AkAudio.AkAreaCheckComponent.CheckVoiceAvailable
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x101f9a6cc
	// Params: [ Num(2) Size(0xD) ]
	bool CheckVoiceAvailable(struct FVector& VoicePostion);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F615DC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F614C4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F6154C
	// [Call #14] RVA: 0x10519022C
};

// Object: Class AkAudio.AkAreaCheckVolumeBase
// Size: 0x4B0 (Inherited: 0x4B0)
struct AAkAreaCheckVolumeBase : AActor
{
	uint8_t AKAreaType; // 0x4A9(0x1)


	// Object: Function AkAudio.AkAreaCheckVolumeBase.UnRegisterFromAreaCheck
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9ade0
	// Params: [ Num(0) Size(0x0) ]
	void UnRegisterFromAreaCheck();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10519022C

	// Object: Function AkAudio.AkAreaCheckVolumeBase.RegisterToAreaCheck
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9adcc
	// Params: [ Num(0) Size(0x0) ]
	void RegisterToAreaCheck();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10519022C

	// Object: Function AkAudio.AkAreaCheckVolumeBase.IsInsideVolume
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x101f9ad2c
	// Params: [ Num(2) Size(0xD) ]
	bool IsInsideVolume(struct FVector& OrignPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C

	// Object: Function AkAudio.AkAreaCheckVolumeBase.GetAKAreaType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101f9ad10
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetAKAreaType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
};

// Object: Class AkAudio.AkAreaCheckSphereVolume
// Size: 0x4B8 (Inherited: 0x4B0)
struct AAkAreaCheckSphereVolume : AAkAreaCheckVolumeBase
{
	struct USphereComponent* SphereComponent; // 0x4B0(0x8)
};

// Object: Class AkAudio.AkAreaCheckVolume
// Size: 0x4B8 (Inherited: 0x4B0)
struct AAkAreaCheckVolume : AAkAreaCheckVolumeBase
{
	struct UBoxComponent* CollisionComponent; // 0x4B0(0x8)
};

// Object: Class AkAudio.AkAudioBank
// Size: 0x40 (Inherited: 0x28)
struct UAkAudioBank : UObject
{
	bool AutoLoad; // 0x28(0x1)
	uint8_t Pad_0x29[0x17]; // 0x29(0x17)
};

// Object: Class AkAudio.AkAudioDeviceSettings
// Size: 0x58 (Inherited: 0x28)
struct UAkAudioDeviceSettings : UObject
{
	int SuperHighDefaultPoolSize; // 0x28(0x4)
	int SuperHighEngineDefaultPoolSize; // 0x2C(0x4)
	int HighDefaultPoolSize; // 0x30(0x4)
	int HighEngineDefaultPoolSize; // 0x34(0x4)
	int LowDefaultPoolSize; // 0x38(0x4)
	int LowEngineDefaultPoolSize; // 0x3C(0x4)
	int DefaultCommandQueueSize; // 0x40(0x4)
	int DefaultBluetoothDelay; // 0x44(0x4)
	float DefaultBluetoothErrThres; // 0x48(0x4)
	float DefaultBluetoothErrRatio; // 0x4C(0x4)
	float DefaultBluetoothMaxTime; // 0x50(0x4)
	bool bEnableSilence; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)


	// Object: Function AkAudio.AkAudioDeviceSettings.InitConfig
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9b17c
	// Params: [ Num(0) Size(0x0) ]
	void InitConfig();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class AkAudio.AkAudioEvent
// Size: 0x40 (Inherited: 0x28)
struct UAkAudioEvent : UObject
{
	struct UAkAudioBank* RequiredBank; // 0x28(0x8)
	float MaxAttenuationRadius; // 0x30(0x4)
	bool IsInfinite; // 0x34(0x1)
	uint8_t Pad_0x35[0x3]; // 0x35(0x3)
	float MinimumDuration; // 0x38(0x4)
	float MaximumDuration; // 0x3C(0x4)
};

// Object: Class AkAudio.AkAudioMonitor
// Size: 0x28 (Inherited: 0x28)
struct UAkAudioMonitor : UBlueprintFunctionLibrary
{

	// Object: Function AkAudio.AkAudioMonitor.UpdateAkComponentInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101f9cfd0
	// Params: [ Num(1) Size(0x50) ]
	void UpdateAkComponentInfo(struct TMap<struct FString, struct FAkCombinedInfo>& OutList);
	// [Call #1] RVA: 0x101FA63CC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F709F4
	// [Call #5] RVA: 0x101FA653C
	// [Call #6] RVA: 0x101FA653C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioMonitor.Update
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9cf5c
	// Params: [ Num(1) Size(0x4) ]
	void Update(float DeltaTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F63934
	// [Call #4] RVA: 0x101FA63CC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F709F4
	// [Call #8] RVA: 0x101FA653C
	// [Call #9] RVA: 0x101FA653C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioMonitor.SetUpdateInterval
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9cee8
	// Params: [ Num(1) Size(0x4) ]
	void SetUpdateInterval(float NewUpdateInterval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F709D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F63934
	// [Call #7] RVA: 0x101FA63CC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F709F4
	// [Call #11] RVA: 0x101FA653C
	// [Call #12] RVA: 0x101FA653C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioMonitor.SetMonitorFlag
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101f9cdc4
	// Params: [ Num(3) Size(0x12) ]
	void SetMonitorFlag(struct TArray<uint8_t>& InFlags, uint8_t TotalPlayCount, uint8_t ObjectPlayCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F70488
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F709D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F63934
	// [Call #17] RVA: 0x101FA63CC
	// [Call #18] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitor.OnReportError
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9cbc8
	// Params: [ Num(4) Size(0x30) ]
	void OnReportError(struct FString FunctionName, uint8_t ErrorAkCode, uint64_t NumericParam, struct FString StrParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F6DD14
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkAudioMonitor.OnAkAudioEventTrigger
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9caac
	// Params: [ Num(2) Size(0x14) ]
	void OnAkAudioEventTrigger(struct FString Name, int code);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F6D488
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x101F8122C

	// Object: Function AkAudio.AkAudioMonitor.OnAkAudioBankTrigger
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c94c
	// Params: [ Num(3) Size(0x19) ]
	void OnAkAudioBankTrigger(bool bUnload, struct FString BankName, uint8_t RefCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F6DAD8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F6D488
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitor.IsMonitorInit
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c918
	// Params: [ Num(1) Size(0x1) ]
	bool IsMonitorInit();
	// [Call #1] RVA: 0x101F63920
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F6DAD8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F8122C
	// [Call #22] RVA: 0x101F6D488
	// [Call #23] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitor.IsAkOutOfAttenuation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c860
	// Params: [ Num(3) Size(0xD) ]
	bool IsAkOutOfAttenuation(struct UAkComponent* AkComp, float Attenuation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6F2B4
	// [Call #6] RVA: 0x101F63920
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F6DAD8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.InitMonitorDataPtr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c84c
	// Params: [ Num(0) Size(0x0) ]
	void InitMonitorDataPtr();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6F2B4
	// [Call #6] RVA: 0x101F63920
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F6DAD8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitor.GetTotalPlayRecord
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c7e8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint16_t> GetTotalPlayRecord();
	// [Call #1] RVA: 0x101F70778
	// [Call #2] RVA: 0x101FA637C
	// [Call #3] RVA: 0x101FA6B28
	// [Call #4] RVA: 0x101FA6B28
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F6F2B4
	// [Call #11] RVA: 0x101F63920
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C

	// Object: Function AkAudio.AkAudioMonitor.GetSwitchValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c6a0
	// Params: [ Num(3) Size(0x28) ]
	struct FString GetSwitchValue(struct UAkComponent* Component, struct FString SwitchName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F6EC68
	// [Call #7] RVA: 0x101F8156C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x101F70778
	// [Call #18] RVA: 0x101FA637C
	// [Call #19] RVA: 0x101FA6B28
	// [Call #20] RVA: 0x101FA6B28
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168
	// [Call #25] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkAudioMonitor.GetSwitchNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c5fc
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FString> GetSwitchNames(struct UAkComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6E8EC
	// [Call #4] RVA: 0x101FA5F38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F6EC68
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C
	// [Call #24] RVA: 0x101F70778
	// [Call #25] RVA: 0x101FA637C
	// [Call #26] RVA: 0x101FA6B28
	// [Call #27] RVA: 0x101FA6B28
	// [Call #28] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetRTPCValueByID
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c544
	// Params: [ Num(3) Size(0x10) ]
	float GetRTPCValueByID(struct UAkComponent* Component, uint32_t RTPCID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6EB4C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F6E8EC
	// [Call #9] RVA: 0x101FA5F38
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x101F6EC68
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitor.GetRTPCValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c420
	// Params: [ Num(3) Size(0x1C) ]
	float GetRTPCValue(struct UAkComponent* Component, struct FString RTPCName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F6EAA4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F6EB4C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F6E8EC
	// [Call #22] RVA: 0x101FA5F38

	// Object: Function AkAudio.AkAudioMonitor.GetRTPCNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c37c
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FString> GetRTPCNames(struct UAkComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6E3AC
	// [Call #4] RVA: 0x101FA5F38
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F6EAA4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkAudioMonitor.GetRTPCIDs
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c2d8
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<uint32_t> GetRTPCIDs(struct UAkComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6E58C
	// [Call #4] RVA: 0x101FA632C
	// [Call #5] RVA: 0x101F8B9C8
	// [Call #6] RVA: 0x101F8B9C8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F6E3AC
	// [Call #11] RVA: 0x101FA5F38
	// [Call #12] RVA: 0x101F8B9F8
	// [Call #13] RVA: 0x101F8B9F8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x101F6EAA4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x104EEF504
	// [Call #25] RVA: 0x100036FE0

	// Object: Function AkAudio.AkAudioMonitor.GetReportErrorRecord
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c274
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<uint8_t, struct FAKErrorInfo> GetReportErrorRecord();
	// [Call #1] RVA: 0x101F707F8
	// [Call #2] RVA: 0x101FA61B8
	// [Call #3] RVA: 0x101FA683C
	// [Call #4] RVA: 0x101FA683C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F6E58C
	// [Call #9] RVA: 0x101FA632C
	// [Call #10] RVA: 0x101F8B9C8
	// [Call #11] RVA: 0x101F8B9C8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F6E3AC
	// [Call #16] RVA: 0x101FA5F38
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkAudioMonitor.GetPostion
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101f9c1f4
	// Params: [ Num(2) Size(0x14) ]
	struct FVector GetPostion(struct UAkComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6EE58
	// [Call #4] RVA: 0x101F707F8
	// [Call #5] RVA: 0x101FA61B8
	// [Call #6] RVA: 0x101FA683C
	// [Call #7] RVA: 0x101FA683C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F6E58C
	// [Call #12] RVA: 0x101FA632C
	// [Call #13] RVA: 0x101F8B9C8
	// [Call #14] RVA: 0x101F8B9C8
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F6E3AC
	// [Call #19] RVA: 0x101FA5F38
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x101F8B9F8
	// [Call #22] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetPlayingID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c150
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<int> GetPlayingID(struct UAkComponent* Component);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6E0B8
	// [Call #4] RVA: 0x101FA6168
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F6EE58
	// [Call #11] RVA: 0x101F707F8
	// [Call #12] RVA: 0x101FA61B8
	// [Call #13] RVA: 0x101FA683C
	// [Call #14] RVA: 0x101FA683C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F6E58C
	// [Call #19] RVA: 0x101FA632C
	// [Call #20] RVA: 0x101F8B9C8
	// [Call #21] RVA: 0x101F8B9C8
	// [Call #22] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetPlayEventName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9c070
	// Params: [ Num(3) Size(0x20) ]
	struct FString GetPlayEventName(struct UAkComponent* Component, int PlayID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6E280
	// [Call #6] RVA: 0x101F8156C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F6E0B8
	// [Call #13] RVA: 0x101FA6168
	// [Call #14] RVA: 0x101F8BA44
	// [Call #15] RVA: 0x101F8BA44
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F6EE58
	// [Call #20] RVA: 0x101F707F8
	// [Call #21] RVA: 0x101FA61B8
	// [Call #22] RVA: 0x101FA683C

	// Object: Function AkAudio.AkAudioMonitor.GetObjectPlayRecord
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9c00c
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FString, uint8_t> GetObjectPlayRecord();
	// [Call #1] RVA: 0x101F707D0
	// [Call #2] RVA: 0x101FA5FAC
	// [Call #3] RVA: 0x101FA6868
	// [Call #4] RVA: 0x101FA6868
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F6E280
	// [Call #11] RVA: 0x101F8156C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F6E0B8
	// [Call #18] RVA: 0x101FA6168
	// [Call #19] RVA: 0x101F8BA44
	// [Call #20] RVA: 0x101F8BA44
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x101F6EE58

	// Object: Function AkAudio.AkAudioMonitor.GetObjectNameByObjectID
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9bf68
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetObjectNameByObjectID(uint64_t ObjectID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F705F0
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101F707D0
	// [Call #9] RVA: 0x101FA5FAC
	// [Call #10] RVA: 0x101FA6868
	// [Call #11] RVA: 0x101FA6868
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F6E280
	// [Call #18] RVA: 0x101F8156C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x101F6E0B8

	// Object: Function AkAudio.AkAudioMonitor.GetMonitorDataPtr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9bf34
	// Params: [ Num(1) Size(0x8) ]
	struct UAkAudioMonitorData* GetMonitorDataPtr();
	// [Call #1] RVA: 0x101F6DF74
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F705F0
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x101F707D0
	// [Call #10] RVA: 0x101FA5FAC
	// [Call #11] RVA: 0x101FA6868
	// [Call #12] RVA: 0x101FA6868
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F6E280
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitor.GetGlobalSwitchValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9be2c
	// Params: [ Num(2) Size(0x20) ]
	struct FString GetGlobalSwitchValue(struct FString SwitchName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F6EDD4
	// [Call #5] RVA: 0x101F8156C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101F6DF74
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F705F0
	// [Call #19] RVA: 0x101F8156C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x101F707D0
	// [Call #24] RVA: 0x101FA5FAC
	// [Call #25] RVA: 0x101FA6868
	// [Call #26] RVA: 0x101FA6868
	// [Call #27] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetGlobalSwitchNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9bdc8
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetGlobalSwitchNames();
	// [Call #1] RVA: 0x101F6EA9C
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F6EDD4
	// [Call #10] RVA: 0x101F8156C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x101F6DF74
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F705F0
	// [Call #24] RVA: 0x101F8156C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetGlobalRTPCValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9bce4
	// Params: [ Num(2) Size(0x14) ]
	float GetGlobalRTPCValue(struct FString RTPCName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F6EBB0
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x101F6EA9C
	// [Call #13] RVA: 0x101FA5F38
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x101F6EDD4
	// [Call #21] RVA: 0x101F8156C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x104EEF504
	// [Call #28] RVA: 0x100036FE0
	// [Call #29] RVA: 0x101F8130C
	// [Call #30] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetGlobalRTPCNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9bc80
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetGlobalRTPCNames();
	// [Call #1] RVA: 0x101F6E72C
	// [Call #2] RVA: 0x101FA5F38
	// [Call #3] RVA: 0x101F8B9F8
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F6EBB0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x101F6EA9C
	// [Call #18] RVA: 0x101FA5F38
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x101F8122C
	// [Call #25] RVA: 0x101F6EDD4
	// [Call #26] RVA: 0x101F8156C
	// [Call #27] RVA: 0x101F8130C
	// [Call #28] RVA: 0x101F8130C
	// [Call #29] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitor.GetEventList
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101f9bbe0
	// Params: [ Num(1) Size(0x10) ]
	void GetEventList(struct TArray<struct FString>& OutRes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F70870
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F6E72C
	// [Call #8] RVA: 0x101FA5F38
	// [Call #9] RVA: 0x101F8B9F8
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F6EBB0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x101F6EA9C
	// [Call #24] RVA: 0x101FA5F38
	// [Call #25] RVA: 0x101F8B9F8
	// [Call #26] RVA: 0x101F8B9F8
	// [Call #27] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetEventInMemoryByName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9ba8c
	// Params: [ Num(3) Size(0x28) ]
	struct UAkAudioEvent* GetEventInMemoryByName(struct TArray<struct UAkAudioEvent*>& AllAk, struct FString AkName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F6F090
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8CA5C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8CA5C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F70870
	// [Call #19] RVA: 0x101F8B9F8
	// [Call #20] RVA: 0x101F8B9F8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x101F6E72C
	// [Call #23] RVA: 0x101FA5F38
	// [Call #24] RVA: 0x101F8B9F8
	// [Call #25] RVA: 0x101F8B9F8
	// [Call #26] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetDetailErrorCodeRecord
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9ba28
	// Params: [ Num(1) Size(0x50) ]
	struct TMap<uint32_t, struct FAKErrorInfo> GetDetailErrorCodeRecord();
	// [Call #1] RVA: 0x101F70820
	// [Call #2] RVA: 0x101FA5D74
	// [Call #3] RVA: 0x101FA6810
	// [Call #4] RVA: 0x101FA6810
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F6F090
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8CA5C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8CA5C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F70870
	// [Call #24] RVA: 0x101F8B9F8
	// [Call #25] RVA: 0x101F8B9F8
	// [Call #26] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetBankRefList
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x101f9b984
	// Params: [ Num(1) Size(0x50) ]
	void GetBankRefList(struct TMap<struct FString, uint8_t>& OutRes);
	// [Call #1] RVA: 0x101FA6748
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F70848
	// [Call #5] RVA: 0x101FA67E4
	// [Call #6] RVA: 0x101FA67E4
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101F70820
	// [Call #9] RVA: 0x101FA5D74
	// [Call #10] RVA: 0x101FA6810
	// [Call #11] RVA: 0x101FA6810
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8122C
	// [Call #18] RVA: 0x101F6F090
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8CA5C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8CA5C

	// Object: Function AkAudio.AkAudioMonitor.GetAllEventNameInMemory
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f9b8e0
	// Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FName> GetAllEventNameInMemory(struct UObject* WorldContent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6EF80
	// [Call #4] RVA: 0x101FA5D24
	// [Call #5] RVA: 0x101F8C344
	// [Call #6] RVA: 0x101F8C344
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x101FA6748
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F70848
	// [Call #12] RVA: 0x101FA67E4
	// [Call #13] RVA: 0x101FA67E4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101F70820
	// [Call #16] RVA: 0x101FA5D74
	// [Call #17] RVA: 0x101FA6810
	// [Call #18] RVA: 0x101FA6810
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkAudioMonitor.GetAllEventInMemory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9b804
	// Params: [ Num(2) Size(0x18) ]
	void GetAllEventInMemory(struct UObject* WorldContent, struct TArray<struct UAkAudioEvent*>& AllAk);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6EEB4
	// [Call #6] RVA: 0x101F8CA5C
	// [Call #7] RVA: 0x101F8CA5C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F6EF80
	// [Call #12] RVA: 0x101FA5D24
	// [Call #13] RVA: 0x101F8C344
	// [Call #14] RVA: 0x101F8C344
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101FA6748
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F70848
	// [Call #20] RVA: 0x101FA67E4
	// [Call #21] RVA: 0x101FA67E4
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x101F70820

	// Object: Function AkAudio.AkAudioMonitor.GetAllAkComponentFormDevice
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9b6fc
	// Params: [ Num(2) Size(0x20) ]
	void GetAllAkComponentFormDevice(struct TArray<struct UAkComponent*>& AkList, struct TArray<struct UAkComponent*>& recycledAkList);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F6F158
	// [Call #6] RVA: 0x101F8CA2C
	// [Call #7] RVA: 0x101F8CA2C
	// [Call #8] RVA: 0x101F8CA2C
	// [Call #9] RVA: 0x101F8CA2C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F6EEB4
	// [Call #16] RVA: 0x101F8CA5C
	// [Call #17] RVA: 0x101F8CA5C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F6EF80

	// Object: Function AkAudio.AkAudioMonitor.GetActiveObjCount
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9b6c8
	// Params: [ Num(1) Size(0x4) ]
	int GetActiveObjCount();
	// [Call #1] RVA: 0x101F70950
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F6F158
	// [Call #7] RVA: 0x101F8CA2C
	// [Call #8] RVA: 0x101F8CA2C
	// [Call #9] RVA: 0x101F8CA2C
	// [Call #10] RVA: 0x101F8CA2C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F6EEB4
	// [Call #17] RVA: 0x101F8CA5C
	// [Call #18] RVA: 0x101F8CA5C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitor.GetActiveEventCount
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9b694
	// Params: [ Num(1) Size(0x4) ]
	int GetActiveEventCount();
	// [Call #1] RVA: 0x101F70900
	// [Call #2] RVA: 0x101F70950
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F6F158
	// [Call #8] RVA: 0x101F8CA2C
	// [Call #9] RVA: 0x101F8CA2C
	// [Call #10] RVA: 0x101F8CA2C
	// [Call #11] RVA: 0x101F8CA2C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F6EEB4
	// [Call #18] RVA: 0x101F8CA5C
	// [Call #19] RVA: 0x101F8CA5C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function AkAudio.AkAudioMonitor.GetActiveBankCount
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101f9b660
	// Params: [ Num(1) Size(0x4) ]
	int GetActiveBankCount();
	// [Call #1] RVA: 0x101F70928
	// [Call #2] RVA: 0x101F70900
	// [Call #3] RVA: 0x101F70950
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F6F158
	// [Call #9] RVA: 0x101F8CA2C
	// [Call #10] RVA: 0x101F8CA2C
	// [Call #11] RVA: 0x101F8CA2C
	// [Call #12] RVA: 0x101F8CA2C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F6EEB4
};

// Object: Class AkAudio.AkAudioMonitorData
// Size: 0x378 (Inherited: 0x28)
struct UAkAudioMonitorData : UObject
{
	struct TSet<uint8_t> IgnoreErrorCode; // 0x28(0x50)
	struct TSet<uint32_t> IgnoreDetailErrorCode; // 0x78(0x50)
	struct TMap<uint32_t, struct FString> ErrorCodeMsgMap; // 0xC8(0x50)
	struct TMap<uint32_t, struct FString> NotifyCodeMsgMap; // 0x118(0x50)
	uint8_t Pad_0x168[0x80]; // 0x168(0x80)
	struct TArray<uint16_t> TotalPlayCountRecord; // 0x1E8(0x10)
	struct TMap<struct FString, uint8_t> ObjectPlayCountRecord; // 0x1F8(0x50)
	struct TMap<uint8_t, struct FAKErrorInfo> AkErrorRecord; // 0x248(0x50)
	struct TMap<uint32_t, struct FAKErrorInfo> AkDetailErrorCodeRecord; // 0x298(0x50)
	struct FScriptMulticastDelegate AkAudioDetailErrorCodeDelegate; // 0x2E8(0x10)
	struct FScriptMulticastDelegate AkAudioEventTrigger; // 0x2F8(0x10)
	float nPassedTime; // 0x308(0x4)
	float nUpdateInterval; // 0x30C(0x4)
	struct TMap<struct FString, uint8_t> BankRefList; // 0x310(0x50)
	struct TArray<struct FString> EventList; // 0x360(0x10)
	uint8_t Pad_0x370[0x8]; // 0x370(0x8)


	// Object: Function AkAudio.AkAudioMonitorData.UpdateEventList
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9e144
	// Params: [ Num(2) Size(0x18) ]
	void UpdateEventList(bool bStop, struct FString InEventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F70290
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioMonitorData.UpdateBankRefList
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9dfd4
	// Params: [ Num(3) Size(0x19) ]
	void UpdateBankRefList(bool bUnload, struct FString BankName, uint8_t RefCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F703E0
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F70290
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function AkAudio.AkAudioMonitorData.UpdateAkComponentInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x101f9df28
	// Params: [ Num(1) Size(0x50) ]
	void UpdateAkComponentInfo(struct TMap<struct FString, struct FAkCombinedInfo>& OutList);
	// [Call #1] RVA: 0x101FA63CC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F70A18
	// [Call #5] RVA: 0x101FA653C
	// [Call #6] RVA: 0x101FA653C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F703E0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitorData.SetMonitorFlagInternal
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x101f9ddf4
	// Params: [ Num(3) Size(0x12) ]
	void SetMonitorFlagInternal(struct TArray<uint8_t>& InFlags, uint8_t TotalPlayCount, uint8_t ObjectPlayCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F704C4
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x101F8BA74
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x101FA63CC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F70A18
	// [Call #15] RVA: 0x101FA653C
	// [Call #16] RVA: 0x101FA653C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitorData.OnReportErrorInternal
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9dbe8
	// Params: [ Num(4) Size(0x30) ]
	void OnReportErrorInternal(struct FString FunctionName, uint8_t ErrorAkCode, uint64_t NumericParam, struct FString StrParam);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F6F3B0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168

	// Object: Function AkAudio.AkAudioMonitorData.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9dbd4
	// Params: [ Num(0) Size(0x0) ]
	void Initialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F6F3B0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
};

// Object: Class AkAudio.AkAudioVisualComponent
// Size: 0x1420 (Inherited: 0x3A0)
struct UAkAudioVisualComponent : USceneComponent
{
	struct FString BankName; // 0x3A0(0x10)
	struct FString EventName; // 0x3B0(0x10)
	uint8_t RangeType; // 0x3C0(0x1)
	uint8_t Pad_0x3C1[0x3]; // 0x3C1(0x3)
	int BinNumber; // 0x3C4(0x4)
	uint8_t Pad_0x3C8[0x1010]; // 0x3C8(0x1010)
	bool UseOfflineData; // 0x13D8(0x1)
	uint8_t Pad_0x13D9[0x7]; // 0x13D9(0x7)
	struct TArray<struct FAudioOfflineVisualBeatData> OfflineData; // 0x13E0(0x10)
	uint8_t Pad_0x13F0[0x30]; // 0x13F0(0x30)


	// Object: Function AkAudio.AkAudioVisualComponent.StartOfflineTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9e84c
	// Params: [ Num(0) Size(0x0) ]
	void StartOfflineTime();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioVisualComponent.ResetOfflineTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9e838
	// Params: [ Num(0) Size(0x0) ]
	void ResetOfflineTime();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioVisualComponent.OnTickVisualInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x10) ]
	void OnTickVisualInfo(struct TArray<float>& VisualInfo);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AkAudio.AkAudioVisualComponent.OnTickOfflineVisualInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x18) ]
	void OnTickOfflineVisualInfo(struct FAudioOfflineVisualBeatData& VisualInfo);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function AkAudio.AkAudioVisualComponent.InitOfflineDataWithBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9e754
	// Params: [ Num(1) Size(0x10) ]
	void InitOfflineDataWithBeatTime(struct TArray<float> Datas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F898F8
	// [Call #4] RVA: 0x101F7D184
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioVisualComponent.InitOfflineData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9e670
	// Params: [ Num(1) Size(0x10) ]
	void InitOfflineData(struct TArray<struct FAudioOfflineVisualBeatData> Datas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F975F0
	// [Call #4] RVA: 0x101F7D10C
	// [Call #5] RVA: 0x101F8CA8C
	// [Call #6] RVA: 0x101F8CA8C
	// [Call #7] RVA: 0x101F8CA8C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8CA8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F898F8
	// [Call #15] RVA: 0x101F7D184
	// [Call #16] RVA: 0x101F8C2E4
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8C2E4
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C

	// Object: Function AkAudio.AkAudioVisualComponent.GetCurrentBeat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9e5b4
	// Params: [ Num(2) Size(0x19) ]
	bool GetCurrentBeat(struct FAudioOfflineVisualBeatData& Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D01C
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F975F0
	// [Call #10] RVA: 0x101F7D10C
	// [Call #11] RVA: 0x101F8CA8C
	// [Call #12] RVA: 0x101F8CA8C
	// [Call #13] RVA: 0x101F8CA8C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8CA8C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F898F8
	// [Call #21] RVA: 0x101F7D184
	// [Call #22] RVA: 0x101F8C2E4
	// [Call #23] RVA: 0x101F8C2E4
	// [Call #24] RVA: 0x101F8C2E4
};

// Object: Class AkAudio.AkAuxBus
// Size: 0x38 (Inherited: 0x28)
struct UAkAuxBus : UObject
{
	struct UAkAudioBank* RequiredBank; // 0x28(0x8)
	uint8_t Pad_0x30[0x8]; // 0x30(0x8)
};

// Object: Class AkAudio.AkComponent
// Size: 0x610 (Inherited: 0x3A0)
struct UAkComponent : USceneComponent
{
	struct UAkAuxBus* EarlyReflectionAuxBus; // 0x3A0(0x8)
	struct FString EarlyReflectionAuxBusName; // 0x3A8(0x10)
	int EarlyReflectionOrder; // 0x3B8(0x4)
	float EarlyReflectionBusSendGain; // 0x3BC(0x4)
	float EarlyReflectionMaxPathLength; // 0x3C0(0x4)
	uint8_t Pad_0x3C4[0x4]; // 0x3C4(0x4)
	uint8_t EnableSpotReflectors : 1; // 0x3C8(0x1), Mask(0x1)
	uint8_t DrawFirstOrderReflections : 1; // 0x3C8(0x1), Mask(0x2)
	uint8_t DrawSecondOrderReflections : 1; // 0x3C8(0x1), Mask(0x4)
	uint8_t DrawHigherOrderReflections : 1; // 0x3C8(0x1), Mask(0x8)
	uint8_t BitPad_0x3C8_4 : 4; // 0x3C8(0x1)
	bool StopWhenOwnerDestroyed; // 0x3C9(0x1)
	uint8_t bIsUpdateEmmiterTransform : 1; // 0x3CA(0x1), Mask(0x1)
	uint8_t bAllIsInstanceSound : 1; // 0x3CA(0x1), Mask(0x2)
	uint8_t BitPad_0x3CA_2 : 6; // 0x3CA(0x1)
	uint8_t Pad_0x3CB[0x1]; // 0x3CB(0x1)
	float AttenuationScalingFactor; // 0x3CC(0x4)
	float OcclusionRefreshInterval; // 0x3D0(0x4)
	uint8_t Pad_0x3D4[0x4]; // 0x3D4(0x4)
	struct UAkAudioEvent* AkAudioEvent; // 0x3D8(0x8)
	struct FString EventName; // 0x3E0(0x10)
	struct FAkRangedEmitterInfo RangedEmitterInfo; // 0x3F0(0x18)
	uint8_t Pad_0x408[0x208]; // 0x408(0x208)


	// Object: Function AkAudio.AkComponent.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9fe3c
	// Params: [ Num(1) Size(0x1) ]
	void UseReverbVolumes(bool inUseReverbVolumes);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7250C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AkAudio.AkComponent.UseEarlyReflections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9fb64
	// Params: [ Num(9) Size(0x20) ]
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, bool Left, bool Right, bool floor, bool Ceiling, bool Back, bool Front, bool SpotReflectors, struct FString AuxBusName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.UpdateGameObjectPosition
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9fb50
	// Params: [ Num(0) Size(0x0) ]
	void UpdateGameObjectPosition();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.TriggerEventWithRangedEmitter
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9facc
	// Params: [ Num(1) Size(0x1) ]
	void TriggerEventWithRangedEmitter(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F6A038
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.StopPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9fa50
	// Params: [ Num(1) Size(0x4) ]
	void StopPlayingID(int StopEventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F71DD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F6A038
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.StopEventInRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9fa3c
	// Params: [ Num(0) Size(0x0) ]
	void StopEventInRange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F71DD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F6A038
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.Stop
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9fa28
	// Params: [ Num(0) Size(0x0) ]
	void Stop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F71DD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F6A038
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f89c
	// Params: [ Num(3) Size(0x24) ]
	int SetSwitch(struct FString SwitchGroup, struct FString SwitchState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x101F720A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x101F71DD4

	// Object: Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f818
	// Params: [ Num(1) Size(0x1) ]
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F72188
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F720A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function AkAudio.AkComponent.SetRTPCValueGlobally
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f6f4
	// Params: [ Num(2) Size(0x14) ]
	void SetRTPCValueGlobally(struct FString RTPC, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F71E08
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F72188
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f590
	// Params: [ Num(3) Size(0x18) ]
	void SetRTPCValue(struct FString RTPC, float Value, int InterpolationTimeMs);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F71F10
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F71E08
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function AkAudio.AkComponent.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f514
	// Params: [ Num(1) Size(0x4) ]
	void SetOutputBusVolume(float BusVolume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F72534
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F71F10
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.SetListeners
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9f46c
	// Params: [ Num(1) Size(0x10) ]
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F72190
	// [Call #4] RVA: 0x101F8CA2C
	// [Call #5] RVA: 0x101F8CA2C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F72534
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F71F10
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function AkAudio.AkComponent.SetEarlyReflectionOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f3f0
	// Params: [ Num(1) Size(0x4) ]
	void SetEarlyReflectionOrder(int NewEarlyReflectionOrder);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F71820
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F72190
	// [Call #7] RVA: 0x101F8CA2C
	// [Call #8] RVA: 0x101F8CA2C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F72534
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.SetAutoDestroy
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f370
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoDestroy(bool in_AutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F71820
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F72190
	// [Call #9] RVA: 0x101F8CA2C
	// [Call #10] RVA: 0x101F8CA2C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F72534
	// [Call #15] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.SetAttenuationScalingFactor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f2f4
	// Params: [ Num(1) Size(0x4) ]
	void SetAttenuationScalingFactor(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F73494
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F71820
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F72190
	// [Call #12] RVA: 0x101F8CA2C
	// [Call #13] RVA: 0x101F8CA2C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.SeekOnEvent
	// Flags: [Final|Native|Public]
	// Offset: 0x101f9f20c
	// Params: [ Num(3) Size(0x18) ]
	int SeekOnEvent(struct FString in_EventName, int in_iPosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F750FC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F73494
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F71820

	// Object: Function AkAudio.AkComponent.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f128
	// Params: [ Num(1) Size(0x10) ]
	void PostTrigger(struct FString Trigger);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x101F72020
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F750FC
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x101F73494

	// Object: Function AkAudio.AkComponent.PostEventInRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f070
	// Params: [ Num(2) Size(0xC) ]
	void PostEventInRange(struct UAkAudioEvent* AkEvent, float RangeSquare);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F656AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F72020
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F750FC
	// [Call #22] RVA: 0x101F8130C

	// Object: Function AkAudio.AkComponent.PostAssociatedAkEventInRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f05c
	// Params: [ Num(0) Size(0x0) ]
	void PostAssociatedAkEventInRange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F656AC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F72020
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.PostAssociatedAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9f028
	// Params: [ Num(1) Size(0x4) ]
	int PostAssociatedAkEvent();
	// [Call #1] RVA: 0x101F68CE4
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F656AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F72020
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.PostAkEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9ef80
	// Params: [ Num(2) Size(0x14) ]
	int PostAkEventByName(struct FString in_EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F71940
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F68CE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F656AC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101F72020
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C

	// Object: Function AkAudio.AkComponent.PostAkEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101f9ee9c
	// Params: [ Num(3) Size(0x1C) ]
	int PostAkEvent(struct UAkAudioEvent* AkEvent, struct FString in_EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7189C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F71940
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x101F68CE4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AkAudio.AkComponent.GetAttenuationRadius
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101f9ee68
	// Params: [ Num(1) Size(0x4) ]
	float GetAttenuationRadius();
	// [Call #1] RVA: 0x101F72514
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F7189C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F71940
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x101F68CE4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkComponent.GetAkGameObjectName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x101f9edc0
	// Params: [ Num(1) Size(0x10) ]
	void GetAkGameObjectName(struct FString& Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F69448
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x101F72514
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F7189C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F71940
	// [Call #19] RVA: 0x101F8130C
};

// Object: Class AkAudio.AkGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UAkGameplayStatics : UBlueprintFunctionLibrary
{

	// Object: Function AkAudio.AkGameplayStatics.WakeupFromSuspend
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa3664
	// Params: [ Num(0) Size(0x0) ]
	void WakeupFromSuspend();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AkGameplayStatics.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa35ac
	// Params: [ Num(2) Size(0x10) ]
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F76F8C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function AkAudio.AkGameplayStatics.UseEarlyReflections
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa32ac
	// Params: [ Num(10) Size(0x28) ]
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, bool Left, bool Right, bool floor, bool Ceiling, bool Back, bool Front, bool SpotReflectors, struct FString AuxBusName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa321c
	// Params: [ Num(1) Size(0x10) ]
	void UnloadBankByName(struct FString BankName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F78144
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.UnloadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa3150
	// Params: [ Num(2) Size(0x18) ]
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F78134
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F78144
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.Suspend
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa313c
	// Params: [ Num(0) Size(0x0) ]
	void Suspend();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F78134
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F78144
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.StopProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa3128
	// Params: [ Num(0) Size(0x0) ]
	void StopProfilerCapture();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F78134
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F78144
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.StopPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa30b4
	// Params: [ Num(1) Size(0x4) ]
	void StopPlayingID(int PlayingID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F774C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F78134
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F78144
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.StopOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa30a0
	// Params: [ Num(0) Size(0x0) ]
	void StopOutputCapture();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F774C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F78134
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F78144
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa302c
	// Params: [ Num(1) Size(0x8) ]
	void StopAllAmbientSounds(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F77804
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F774C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F78134
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F78144

	// Object: Function AkAudio.AkGameplayStatics.StopAll
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa3018
	// Params: [ Num(0) Size(0x0) ]
	void StopAll();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F77804
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F774C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F78134
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.StopAkEventByID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2fa4
	// Params: [ Num(1) Size(0x4) ]
	void StopAkEventByID(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F773E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F77804
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F774C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F78134
	// [Call #15] RVA: 0x101F8130C

	// Object: Function AkAudio.AkGameplayStatics.StopActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2f30
	// Params: [ Num(1) Size(0x8) ]
	void StopActor(struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7741C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F773E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F77804
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F774C0
	// [Call #13] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.StartProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2ea0
	// Params: [ Num(1) Size(0x10) ]
	void StartProfilerCapture(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F784BC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F7741C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F773E8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F77804
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.StartOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2e10
	// Params: [ Num(1) Size(0x10) ]
	void StartOutputCapture(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F782A0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F784BC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F7741C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F773E8
	// [Call #19] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2d9c
	// Params: [ Num(1) Size(0x8) ]
	void StartAllAmbientSounds(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F77538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F782A0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F784BC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F7741C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa2af4
	// Params: [ Num(10) Size(0x68) ]
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct UAkAuxBus* EarlyReflectionsBus, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, struct FString EarlyReflectionsBusName, bool AutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F76348

	// Object: Function AkAudio.AkGameplayStatics.ShowAKComponentPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2a78
	// Params: [ Num(1) Size(0x1) ]
	void ShowAKComponentPosition(bool _IsShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F786A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.ShouldPostEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa29b4
	// Params: [ Num(3) Size(0x15) ]
	bool ShouldPostEvent(struct UObject* WorldContext, struct FVector& VoicePosition);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F75C6C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F786A8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchWithDummyActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2908
	// Params: [ Num(2) Size(0x10) ]
	void SetSwitchWithDummyActor(struct FName SwitchGroup, struct FName SwitchState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F76E88
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F75C6C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F786A8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2820
	// Params: [ Num(3) Size(0x18) ]
	void SetSwitch(struct FName SwitchGroup, struct FName SwitchState, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F76D28
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F76E88
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F75C6C

	// Object: Function AkAudio.AkGameplayStatics.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa276c
	// Params: [ Num(3) Size(0x14) ]
	int SetState(struct FName StateGroup, struct FName State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F76B08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F76D28
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F76E88

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2644
	// Params: [ Num(4) Size(0x18) ]
	void SetRTPCValue(struct FName RTPC, float Value, int InterpolationTimeMs, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F76A3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F76B08
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetRegionIpMute
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa25c8
	// Params: [ Num(1) Size(0x1) ]
	void SetRegionIpMute(bool bMuted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F771C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F76A3C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F76B08

	// Object: Function AkAudio.AkGameplayStatics.SetPanningRule
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2554
	// Params: [ Num(1) Size(0x1) ]
	void SetPanningRule(uint8_t PanRule);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F77308
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F771C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F76A3C
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa24a4
	// Params: [ Num(2) Size(0x10) ]
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7710C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F77308
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F771C4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2428
	// Params: [ Num(1) Size(0x4) ]
	void SetOcclusionScalingFactor(float ScalingFactor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F7710C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F77308
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F771C4
	// [Call #14] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa2378
	// Params: [ Num(2) Size(0x10) ]
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F77340
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F7710C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F77308

	// Object: Function AkAudio.AkGameplayStatics.SetMultiplePositions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa2294
	// Params: [ Num(2) Size(0x18) ]
	void SetMultiplePositions(struct TArray<struct FTransform>& InTransforms, struct UAkComponent* AkComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7894C
	// [Call #6] RVA: 0x101FA6AF8
	// [Call #7] RVA: 0x101FA6AF8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F77340
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.SetBusConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa21c4
	// Params: [ Num(2) Size(0x11) ]
	void SetBusConfig(struct FString BusName, uint8_t ChannelConfiguration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F771C8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F7894C
	// [Call #14] RVA: 0x101FA6AF8
	// [Call #15] RVA: 0x101FA6AF8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x101F77340

	// Object: Function AkAudio.AkGameplayStatics.SeekOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1fcc
	// Params: [ Num(6) Size(0x30) ]
	int SeekOnEvent(struct UAkAudioEvent* in_pAkEvent, struct AActor* in_pActor, int in_iPosition, struct FString EventName, bool in_bSeekToNearestMarker);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F786D0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.RefreshModDirectories
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1fb8
	// Params: [ Num(0) Size(0x0) ]
	void RefreshModDirectories();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F786D0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1f0c
	// Params: [ Num(2) Size(0x10) ]
	void PostTrigger(struct FName Trigger, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F76C20
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x101F786D0
	// [Call #18] RVA: 0x101F8130C

	// Object: Function AkAudio.AkGameplayStatics.PostEventWithVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1d1c
	// Params: [ Num(6) Size(0x30) ]
	int PostEventWithVolume(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct FString EventName, float Volume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F76418
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.PostEventWithDummyActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1bb8
	// Params: [ Num(4) Size(0x24) ]
	int PostEventWithDummyActor(struct UAkAudioEvent* AkEvent, struct FString EventName, struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F75F04
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.PostEventInRange
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1ac8
	// Params: [ Num(4) Size(0x20) ]
	struct UAkComponent* PostEventInRange(struct UAkAudioEvent* AkEvent, struct AActor* Actor, float RangeSquare);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F75D40
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F75F04
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function AkAudio.AkGameplayStatics.PostEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa19b0
	// Params: [ Num(3) Size(0x19) ]
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F7604C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F75D40
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.PostEventAttached
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa17bc
	// Params: [ Num(6) Size(0x34) ]
	int PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F75834
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.PostEventAtLocationWithVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa15f0
	// Params: [ Num(7) Size(0x40) ]
	int PostEventAtLocationWithVolume(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject, float Volume);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F76834
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa14a0
	// Params: [ Num(4) Size(0x30) ]
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F76338
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.PostEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa1314
	// Params: [ Num(6) Size(0x3C) ]
	int PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F7616C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.PostEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa1164
	// Params: [ Num(5) Size(0x2C) ]
	int PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct FString EventName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x101F75A0C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.MuteListener
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa10b4
	// Params: [ Num(2) Size(0xC) ]
	void MuteListener(struct APlayerController* Controller, int WindowID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F78948
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F75A0C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C

	// Object: Function AkAudio.AkGameplayStatics.LoadInitBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa10a0
	// Params: [ Num(0) Size(0x0) ]
	void LoadInitBank();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F78948
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F75A0C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504

	// Object: Function AkAudio.AkGameplayStatics.LoadBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa0fb4
	// Params: [ Num(2) Size(0x11) ]
	void LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F77C34
	// [Call #6] RVA: 0x101FA6AC8
	// [Call #7] RVA: 0x101FA6AC8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F78948
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0f24
	// Params: [ Num(1) Size(0x10) ]
	void LoadBankByName(struct FString BankName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F77944
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F77C34
	// [Call #12] RVA: 0x101FA6AC8
	// [Call #13] RVA: 0x101FA6AC8
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F78948

	// Object: Function AkAudio.AkGameplayStatics.LoadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0e58
	// Params: [ Num(2) Size(0x18) ]
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F77934
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F77944
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F77C34
	// [Call #20] RVA: 0x101FA6AC8
	// [Call #21] RVA: 0x101FA6AC8
	// [Call #22] RVA: 0x106C8459C

	// Object: Function AkAudio.AkGameplayStatics.IsGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0ddc
	// Params: [ Num(2) Size(0x9) ]
	bool IsGame(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F757E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F77934
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F77944
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0da8
	// Params: [ Num(1) Size(0x1) ]
	bool IsEditor();
	// [Call #1] RVA: 0x101F757D8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x101F757E0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F77934
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F77944
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.GetSourcePlayPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0d2c
	// Params: [ Num(2) Size(0x8) ]
	int GetSourcePlayPosition(int AkEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F78910
	// [Call #4] RVA: 0x101F757D8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F757E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F77934
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0d08
	// Params: [ Num(1) Size(0x4) ]
	float GetOcclusionScalingFactor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F78910
	// [Call #4] RVA: 0x101F757D8
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F757E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F77934
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.GetDefaultListenerLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa0c44
	// Params: [ Num(3) Size(0x15) ]
	bool GetDefaultListenerLocation(struct UObject* WorldContextObject, struct FVector& OutLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7567C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F78910
	// [Call #9] RVA: 0x101F757D8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F757E0
	// [Call #13] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.GetAkComponent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101fa0b18
	// Params: [ Num(5) Size(0x28) ]
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F755CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F7567C
	// [Call #15] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.ClearBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0b04
	// Params: [ Num(0) Size(0x0) ]
	void ClearBanks();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F755CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F7567C

	// Object: Function AkAudio.AkGameplayStatics.AKSetRTPCValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa09a0
	// Params: [ Num(3) Size(0x15) ]
	void AKSetRTPCValue(struct FString RTPC, float Value, bool in_bBypassInternalValueInterpolation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F760D8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0910
	// Params: [ Num(1) Size(0x10) ]
	void AddOutputCaptureMarker(struct FString MarkerText);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F78468
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F760D8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function AkAudio.AkGameplayStatics.AddModDirectory
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa0880
	// Params: [ Num(1) Size(0x10) ]
	void AddModDirectory(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F788DC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F78468
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x101F760D8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
};

// Object: Class AkAudio.AkLateReverbComponent
// Size: 0x3E0 (Inherited: 0x3A0)
struct UAkLateReverbComponent : USceneComponent
{
	uint8_t bEnable : 1; // 0x399(0x1), Mask(0x1)
	struct UAkAuxBus* AuxBus; // 0x3A0(0x8)
	struct FString AuxBusName; // 0x3A8(0x10)
	float SendLevel; // 0x3B8(0x4)
	float FadeRate; // 0x3BC(0x4)
	float Priority; // 0x3C0(0x4)
	uint8_t BitPad_0x3C4_1 : 7; // 0x3C4(0x1)
	uint8_t Pad_0x3C5[0x1B]; // 0x3C5(0x1B)
};

// Object: Class AkAudio.AkReverbVolume
// Size: 0x518 (Inherited: 0x4E0)
struct AAkReverbVolume : AVolume
{
	uint8_t bEnabled : 1; // 0x4E0(0x1), Mask(0x1)
	uint8_t BitPad_0x4E0_1 : 7; // 0x4E0(0x1)
	uint8_t Pad_0x4E1[0x7]; // 0x4E1(0x7)
	struct UAkAuxBus* AuxBus; // 0x4E8(0x8)
	struct FString AuxBusName; // 0x4F0(0x10)
	float SendLevel; // 0x500(0x4)
	float FadeRate; // 0x504(0x4)
	float Priority; // 0x508(0x4)
	uint8_t Pad_0x50C[0x4]; // 0x50C(0x4)
	struct UAkLateReverbComponent* LateReverbComponent; // 0x510(0x8)
};

// Object: Class AkAudio.AkRoomComponent
// Size: 0x3C0 (Inherited: 0x3A0)
struct UAkRoomComponent : USceneComponent
{
	uint8_t bEnable : 1; // 0x399(0x1), Mask(0x1)
	uint8_t BitPad_0x3A0_1 : 7; // 0x3A0(0x1)
	uint8_t Pad_0x3A1[0x7]; // 0x3A1(0x7)
	float Priority; // 0x3A8(0x4)
	uint8_t Pad_0x3AC[0x14]; // 0x3AC(0x14)


	// Object: Function AkAudio.AkRoomComponent.RemoveSpatialAudioRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8248
	// Params: [ Num(0) Size(0x0) ]
	void RemoveSpatialAudioRoom();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function AkAudio.AkRoomComponent.AddSpatialAudioRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8234
	// Params: [ Num(0) Size(0x0) ]
	void AddSpatialAudioRoom();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
};

// Object: Class AkAudio.AkSettings
// Size: 0xA0 (Inherited: 0x28)
struct UAkSettings : UObject
{
	uint8_t MaxSimultaneousReverbVolumes; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)
	struct FFilePath WwiseProjectPath; // 0x30(0x10)
	struct FDirectoryPath WwiseWindowsInstallationPath; // 0x40(0x10)
	struct FFilePath WwiseMacInstallationPath; // 0x50(0x10)
	bool SuppressWwiseProjectPathWarnings; // 0x60(0x1)
	bool UseAlternateObstructionOcclusionFeature; // 0x61(0x1)
	uint8_t Pad_0x62[0x3E]; // 0x62(0x3E)
};

// Object: Class AkAudio.AkSpatialAudioVolume
// Size: 0x4F8 (Inherited: 0x4E0)
struct AAkSpatialAudioVolume : AVolume
{
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // 0x4E0(0x8)
	struct UAkLateReverbComponent* LateReverb; // 0x4E8(0x8)
	struct UAkRoomComponent* Room; // 0x4F0(0x8)
};

// Object: Class AkAudio.AkSpotReflector
// Size: 0x4E0 (Inherited: 0x4B0)
struct AAkSpotReflector : AActor
{
	struct UAkAuxBus* AuxBus; // 0x4B0(0x8)
	struct FString AuxBusName; // 0x4B8(0x10)
	struct UAkAcousticTexture* AcousticTexture; // 0x4C8(0x8)
	float DistanceScalingFactor; // 0x4D0(0x4)
	float Level; // 0x4D4(0x4)
	uint8_t Pad_0x4D8[0x8]; // 0x4D8(0x8)
};

// Object: Class AkAudio.AkSurfaceReflectorSetComponent
// Size: 0x3C0 (Inherited: 0x3A0)
struct UAkSurfaceReflectorSetComponent : USceneComponent
{
	uint8_t bEnableSurfaceReflectors : 1; // 0x399(0x1), Mask(0x1)
	struct TArray<struct FAkPoly> AcousticPolys; // 0x3A0(0x10)
	uint8_t BitPad_0x3B0_1 : 7; // 0x3B0(0x1)
	uint8_t Pad_0x3B1[0xF]; // 0x3B1(0xF)


	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8824
	// Params: [ Num(0) Size(0x0) ]
	void UpdateSurfaceReflectorSet();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8810
	// Params: [ Num(0) Size(0x0) ]
	void SendSurfaceReflectorSet();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870

	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa87fc
	// Params: [ Num(0) Size(0x0) ]
	void RemoveSurfaceReflectorSet();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class AkAudio.AudioOfflineDataRecorder
// Size: 0x1410 (Inherited: 0x3A0)
struct UAudioOfflineDataRecorder : USceneComponent
{
	struct FString BankName; // 0x3A0(0x10)
	struct FString EventName; // 0x3B0(0x10)
	uint8_t RangeType; // 0x3C0(0x1)
	uint8_t Pad_0x3C1[0x3]; // 0x3C1(0x3)
	int BinNumber; // 0x3C4(0x4)
	struct TArray<float> BeatTimeArray; // 0x3C8(0x10)
	struct TArray<struct FAudioOfflineVisualBeatData> Result; // 0x3D8(0x10)
	uint8_t Pad_0x3E8[0x1028]; // 0x3E8(0x1028)
};

// Object: Class AkAudio.AudioOfflineVisual
// Size: 0x48 (Inherited: 0x28)
struct UAudioOfflineVisual : UObject
{
	struct TArray<struct FAudioOfflineVisualBeatData> OfflineData; // 0x28(0x10)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)


	// Object: Function AkAudio.AudioOfflineVisual.StartBeatOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8fdc
	// Params: [ Num(1) Size(0x4) ]
	void StartBeatOffset(float Offset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D31C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AudioOfflineVisual.StartBeat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8fc8
	// Params: [ Num(0) Size(0x0) ]
	void StartBeat();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D31C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AudioOfflineVisual.ResetBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8fb4
	// Params: [ Num(0) Size(0x0) ]
	void ResetBeatTime();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D31C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AudioOfflineVisual.InitWithBeatTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8ed0
	// Params: [ Num(1) Size(0x10) ]
	void InitWithBeatTime(struct TArray<float> Datas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F898F8
	// [Call #4] RVA: 0x101F7D48C
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F7D31C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function AkAudio.AudioOfflineVisual.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa8dec
	// Params: [ Num(1) Size(0x10) ]
	void Init(struct TArray<struct FAudioOfflineVisualBeatData> Datas);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F975F0
	// [Call #4] RVA: 0x101F7D484
	// [Call #5] RVA: 0x101F8CA8C
	// [Call #6] RVA: 0x101F8CA8C
	// [Call #7] RVA: 0x101F8CA8C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8CA8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F898F8
	// [Call #15] RVA: 0x101F7D48C
	// [Call #16] RVA: 0x101F8C2E4
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8C2E4
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function AkAudio.AudioOfflineVisual.GetCurrentBeatByCustomTime
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa8cf4
	// Params: [ Num(3) Size(0x21) ]
	bool GetCurrentBeatByCustomTime(float InBeatSecondTime, struct FAudioOfflineVisualBeatData& Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7D404
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F975F0
	// [Call #12] RVA: 0x101F7D484
	// [Call #13] RVA: 0x101F8CA8C
	// [Call #14] RVA: 0x101F8CA8C
	// [Call #15] RVA: 0x101F8CA8C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8CA8C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x101F898F8

	// Object: Function AkAudio.AudioOfflineVisual.GetCurrentBeat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa8c38
	// Params: [ Num(2) Size(0x19) ]
	bool GetCurrentBeat(struct FAudioOfflineVisualBeatData& Result);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D354
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F7D404
	// [Call #12] RVA: 0x101F8C2E4
	// [Call #13] RVA: 0x101F8C2E4
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F975F0
	// [Call #18] RVA: 0x101F7D484
	// [Call #19] RVA: 0x101F8CA8C
	// [Call #20] RVA: 0x101F8CA8C
};

// Object: Class AkAudio.AudioVisual
// Size: 0x1028 (Inherited: 0x28)
struct UAudioVisual : UObject
{
	uint8_t Pad_0x28[0x1000]; // 0x28(0x1000)


	// Object: Function AkAudio.AudioVisual.TryInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa9958
	// Params: [ Num(1) Size(0x1) ]
	bool TryInit();
	// [Call #1] RVA: 0x101F7D56C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa9944
	// Params: [ Num(0) Size(0x0) ]
	void Reset();
	// [Call #1] RVA: 0x101F7D56C
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.IsInited
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa9910
	// Params: [ Num(1) Size(0x1) ]
	bool IsInited();
	// [Call #1] RVA: 0x101F7D574
	// [Call #2] RVA: 0x101F7D56C
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.GetRMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa98dc
	// Params: [ Num(1) Size(0x4) ]
	float GetRMS();
	// [Call #1] RVA: 0x101F7D598
	// [Call #2] RVA: 0x101F7D574
	// [Call #3] RVA: 0x101F7D56C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.GetInstantEnergy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa98a8
	// Params: [ Num(1) Size(0x4) ]
	float GetInstantEnergy();
	// [Call #1] RVA: 0x101F7D590
	// [Call #2] RVA: 0x101F7D598
	// [Call #3] RVA: 0x101F7D574
	// [Call #4] RVA: 0x101F7D56C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.GetFrequencyVol
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101fa981c
	// Params: [ Num(2) Size(0x8) ]
	float GetFrequencyVol(uint8_t freqRange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D5A0
	// [Call #4] RVA: 0x101F7D590
	// [Call #5] RVA: 0x101F7D598
	// [Call #6] RVA: 0x101F7D574
	// [Call #7] RVA: 0x101F7D56C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function AkAudio.AudioVisual.GetFrequencyDataWithBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa969c
	// Params: [ Num(5) Size(0x20) ]
	int GetFrequencyDataWithBin(struct TArray<float>& pFreqData, uint8_t freqRange, int nBin, bool bAbsolute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F7D5B0
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8C2E4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F7D5A0
	// [Call #16] RVA: 0x101F7D590

	// Object: Function AkAudio.AudioVisual.GetFrequencyData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa95a0
	// Params: [ Num(3) Size(0x18) ]
	int GetFrequencyData(struct TArray<float>& pFreqData, uint8_t freqRange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F7D5A8
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F7D5B0
	// [Call #18] RVA: 0x101F8C2E4

	// Object: Function AkAudio.AudioVisual.GetAudioSamplesWithBin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa9460
	// Params: [ Num(4) Size(0x1C) ]
	int GetAudioSamplesWithBin(struct TArray<float>& pAudioData, int nBin, bool bAbsolute);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F7D588
	// [Call #8] RVA: 0x101F8C2E4
	// [Call #9] RVA: 0x101F8C2E4
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F7D5A8
	// [Call #16] RVA: 0x101F8C2E4
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x106C8459C

	// Object: Function AkAudio.AudioVisual.GetAudioSamples
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fa93a8
	// Params: [ Num(2) Size(0x14) ]
	int GetAudioSamples(struct TArray<float>& pAudioData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D580
	// [Call #4] RVA: 0x101F8C2E4
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F7D588
	// [Call #14] RVA: 0x101F8C2E4
	// [Call #15] RVA: 0x101F8C2E4
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
};

// Object: Class AkAudio.AudioVisualBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioVisualBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AkAudio.AudioVisualBlueprintLibrary.GetAudioVisual
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa9df8
	// Params: [ Num(2) Size(0x10) ]
	struct UAudioVisual* GetAudioVisual(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D5B8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x101F99F14
	// [Call #9] RVA: 0x105184F34

	// Object: Function AkAudio.AudioVisualBlueprintLibrary.GetAudioOfflineVisual
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101fa9d7c
	// Params: [ Num(2) Size(0x10) ]
	struct UAudioOfflineVisual* GetAudioOfflineVisual(struct UObject* Outer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F7D5C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F7D5B8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C
};

// Object: Class AkAudio.InterpTrackAkAudioEvent
// Size: 0xA8 (Inherited: 0x90)
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase
{
	struct TArray<struct FAkAudioEventTrackKey> Events; // 0x90(0x10)
	uint8_t bContinueEventOnMatineeEnd : 1; // 0xA0(0x1), Mask(0x1)
	uint8_t BitPad_0xA0_1 : 7; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x7]; // 0xA1(0x7)
};

// Object: Class AkAudio.InterpTrackAkAudioRTPC
// Size: 0xA8 (Inherited: 0x90)
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase
{
	struct FString Param; // 0x90(0x10)
	uint8_t bPlayOnReverse : 1; // 0xA0(0x1), Mask(0x1)
	uint8_t bContinueRTPCOnMatineeEnd : 1; // 0xA0(0x1), Mask(0x2)
	uint8_t BitPad_0xA0_2 : 6; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x7]; // 0xA1(0x7)
};

// Object: Class AkAudio.InterpTrackInstAkAudioEvent
// Size: 0x30 (Inherited: 0x28)
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst
{
	float LastUpdatePosition; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class AkAudio.InterpTrackInstAkAudioRTPC
// Size: 0x30 (Inherited: 0x28)
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst
{
	float LastUpdatePosition; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0xD0 (Inherited: 0xB0)
struct UMovieSceneAkAudioEventSection : UMovieSceneSection
{
	struct UAkAudioEvent* Event; // 0xB0(0x8)
	bool StopAtSectionEnd; // 0xB8(0x1)
	uint8_t Pad_0xB9[0x7]; // 0xB9(0x7)
	struct FString EventName; // 0xC0(0x10)
};

// Object: Class AkAudio.MovieSceneAkTrack
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneAkTrack : UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
	uint8_t bIsAMasterTrack : 1; // 0x68(0x1), Mask(0x1)
	uint8_t BitPad_0x68_1 : 7; // 0x68(0x1)
	uint8_t Pad_0x69[0x7]; // 0x69(0x7)
};

// Object: Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0x70 (Inherited: 0x70)
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack
{
};

// Object: Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x138 (Inherited: 0xB0)
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection
{
	uint8_t Pad_0xB0[0x8]; // 0xB0(0x8)
	struct FString Name; // 0xB8(0x10)
	struct FRichCurve FloatCurve; // 0xC8(0x70)
};

// Object: Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0x70 (Inherited: 0x70)
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack
{
};

