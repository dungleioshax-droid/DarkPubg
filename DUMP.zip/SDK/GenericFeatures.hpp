#pragma once

#include <cstdint>

// Object: Enum GenericFeatures.EHasAITagStateLogic
enum class EHasAITagStateLogic : uint8_t
{
	Any = 0,
	All = 1,
	None = 2,
	EHasAITagStateLogic_MAX = 3
};

// Object: Enum GenericFeatures.EGenericSearchEnemyRule
enum class EGenericSearchEnemyRule : uint16_t
{
	Nearest = 0,
	Farthest = 1,
	Random = 2,
	MostHP = 3,
	LeastHP = 4,
	LuaCustom = 5,
	ByBlackboardKey = 255,
	EGenericSearchEnemyRule_MAX = 256
};

// Object: ScriptStruct GenericFeatures.GenericSensingRuntimeState
// Size: 0xC (Inherited: 0x0)
struct FGenericSensingRuntimeState
{
	float CanNotSeeTargetElapsedTime; // 0x0(0x4)
	float LockTargetElapsedTime; // 0x4(0x4)
	float RememberEnemyElapsedTime; // 0x8(0x4)
};

// Object: ScriptStruct GenericFeatures.GenericMonsterSensingConfig
// Size: 0x48 (Inherited: 0x0)
struct FGenericMonsterSensingConfig
{
	float SensedRadius; // 0x0(0x4)
	float LoseSightRadius; // 0x4(0x4)
	float SensedAngle; // 0x8(0x4)
	float MaxRememberEnemyTime; // 0xC(0x4)
	float MinTimeLockTarget; // 0x10(0x4)
	float MinTimeWhenCannotSeeTarget; // 0x14(0x4)
	bool bIncludePlayer; // 0x18(0x1)
	bool bIncludeMonster; // 0x19(0x1)
	struct FGenericMonsterSensingFilterConfig PlayerFilter; // 0x1A(0xA)
	struct FGenericMonsterSensingFilterConfig MonsterFilter; // 0x24(0xA)
	enum class ECollisionChannel VisibilityTraceChannel; // 0x2E(0x1)
	uint8_t Pad_0x2F[0x1]; // 0x2F(0x1)
	float VisibilityTraceStartZ; // 0x30(0x4)
	float VisibilityTraceEndZ; // 0x34(0x4)
	uint8_t SearchRule; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FName IgnoreTargetIfHasTag; // 0x40(0x8)
};

// Object: ScriptStruct GenericFeatures.GenericMonsterSensingFilterConfig
// Size: 0xA (Inherited: 0x0)
struct FGenericMonsterSensingFilterConfig
{
	bool bEnableTargetAliveCheck; // 0x0(0x1)
	bool bEnableIgnoreTagCheck; // 0x1(0x1)
	bool bEnableFactionCheck; // 0x2(0x1)
	bool bEnableDistanceCheck; // 0x3(0x1)
	bool bEnableAngleCheck; // 0x4(0x1)
	bool bEnableNearDeathCheck; // 0x5(0x1)
	bool bDoNotAttackNearDeathEnemyFirst; // 0x6(0x1)
	bool bEnableWaterCheck; // 0x7(0x1)
	bool bEnableVisibilityCheck; // 0x8(0x1)
	bool bEnableLuaTargetOverride; // 0x9(0x1)
};

// Object: ScriptStruct GenericFeatures.HitBoxTagInfo
// Size: 0x18 (Inherited: 0x0)
struct FHitBoxTagInfo
{
	struct FBodyTypeDef BodyTypeDef; // 0x0(0x8)
	struct FString HitBoxTag; // 0x8(0x10)
};

// Object: ScriptStruct GenericFeatures.StateRelationEntry
// Size: 0x48 (Inherited: 0x0)
struct FStateRelationEntry
{
	struct FGameplayTag Tag; // 0x0(0x8)
	struct FGameplayTagContainer BlockedBy; // 0x8(0x20)
	struct FGameplayTagContainer Cancel; // 0x28(0x20)
};

// Object: Class GenericFeatures.BehaviorControlComponent
// Size: 0x1A8 (Inherited: 0x178)
struct UBehaviorControlComponent : UActorComponent
{
	struct TArray<struct UBehaviorTree*> BehaviorTreePath; // 0x178(0x10)
	struct APawn* OwnerPawn; // 0x188(0x8)
	struct AAIController* AIController; // 0x190(0x8)
	struct UBehaviorTreeComponent* BehaviorTreeComp; // 0x198(0x8)
	struct UBlackboardComponent* BlackboardComp; // 0x1A0(0x8)


	// Object: Function GenericFeatures.BehaviorControlComponent.UnPossessed
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224e1d4
	// Params: [ Num(0) Size(0x0) ]
	void UnPossessed();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GenericFeatures.BehaviorControlComponent.StopBehaviorTree
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224e1b8
	// Params: [ Num(0) Size(0x0) ]
	void StopBehaviorTree();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function GenericFeatures.BehaviorControlComponent.StopBehavior
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224e118
	// Params: [ Num(1) Size(0x10) ]
	void StopBehavior(struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericFeatures.BehaviorControlComponent.RunBehaviorTreeByIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224e084
	// Params: [ Num(2) Size(0x5) ]
	bool RunBehaviorTreeByIndex(int PathIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericFeatures.BehaviorControlComponent.ResumeBehavior
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224dfe4
	// Params: [ Num(1) Size(0x10) ]
	void ResumeBehavior(struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C

	// Object: Function GenericFeatures.BehaviorControlComponent.RestartBehavior
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224dfc8
	// Params: [ Num(0) Size(0x0) ]
	void RestartBehavior();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C

	// Object: Function GenericFeatures.BehaviorControlComponent.PossessedBy
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224df44
	// Params: [ Num(1) Size(0x8) ]
	void PossessedBy(struct AController* NewController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C

	// Object: Function GenericFeatures.BehaviorControlComponent.PauseBehavior
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224dea4
	// Params: [ Num(1) Size(0x10) ]
	void PauseBehavior(struct FString Reason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.BehaviorControlComponent.OnPlayerActiveRegionsChanged
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224de18
	// Params: [ Num(1) Size(0x1) ]
	void OnPlayerActiveRegionsChanged(bool bEnter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
};

// Object: Class GenericFeatures.BTDecorator_Generic_HasAIState
// Size: 0xA0 (Inherited: 0x60)
struct UBTDecorator_Generic_HasAIState : UBTDecorator
{
	struct TArray<struct FGameplayTag> States; // 0x60(0x10)
	uint8_t LogicOp; // 0x70(0x1)
	bool bExact; // 0x71(0x1)
	uint8_t Pad_0x72[0x6]; // 0x72(0x6)
	struct FBlackboardKeySelector BBKeyTarget; // 0x78(0x28)
};

// Object: Class GenericFeatures.BTService_Generic_ChooseEnemy
// Size: 0xE8 (Inherited: 0x68)
struct UBTService_Generic_ChooseEnemy : UBTService
{
	struct FBlackboardKeySelector BBKeyEnemy; // 0x68(0x28)
	struct FBlackboardKeySelector BBKeyCanNotSeeTarget; // 0x90(0x28)
	struct FBlackboardKeySelector BBKeyDynamicSearchRuleIndex; // 0xB8(0x28)
	bool bShowDebugInfo; // 0xE0(0x1)
	uint8_t Pad_0xE1[0x3]; // 0xE1(0x3)
	float DebugInfoLife; // 0xE4(0x4)
};

// Object: Class GenericFeatures.BTTask_Generic_ClearEnemy
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_Generic_ClearEnemy : UBTTaskNode
{
	struct FBlackboardKeySelector BBKeyEnemy; // 0x70(0x28)
};

// Object: Class GenericFeatures.GenericAIController
// Size: 0x620 (Inherited: 0x5B8)
struct AGenericAIController : AAIController
{
	uint8_t Pad_0x5B8[0x58]; // 0x5B8(0x58)
	struct FString LuaFilePath; // 0x610(0x10)
};

// Object: Class GenericFeatures.GenericCharacter
// Size: 0x9A0 (Inherited: 0x8F0)
struct AGenericCharacter : ACharacter
{
	uint8_t Pad_0x8F0[0x80]; // 0x8F0(0x80)
	uint32_t PlayerKey; // 0x970(0x4)
	uint8_t Pad_0x974[0x4]; // 0x974(0x4)
	struct UStateReflectComp* StateReflectComp; // 0x978(0x8)
	struct UAttrModifyComponent* AttrModifyComp; // 0x980(0x8)
	struct FString LuaFilePath; // 0x988(0x10)
	uint8_t Pad_0x998[0x8]; // 0x998(0x8)


	// Object: Function GenericFeatures.GenericCharacter.OnStateLeft
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10224ed44
	// Params: [ Num(1) Size(0x8) ]
	void OnStateLeft(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.OnStateEntered
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10224ecc0
	// Params: [ Num(1) Size(0x8) ]
	void OnStateEntered(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.OnRep_PlayerKey
	// Flags: [Native|Public]
	// Offset: 0x10224eca4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerKey();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.IsInObjectPool
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224ec68
	// Params: [ Num(1) Size(0x1) ]
	bool IsInObjectPool();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.IsAlive
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224ec2c
	// Params: [ Num(1) Size(0x1) ]
	bool IsAlive();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.HandleStateLeft
	// Flags: [Final|Native|Private]
	// Offset: 0x10224ebb0
	// Params: [ Num(1) Size(0x8) ]
	void HandleStateLeft(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022364E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericCharacter.HandleStateEntered
	// Flags: [Final|Native|Private]
	// Offset: 0x10224eb34
	// Params: [ Num(1) Size(0x8) ]
	void HandleStateEntered(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022363A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022364E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericCharacter.GetStateReflectComp
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224eb18
	// Params: [ Num(1) Size(0x8) ]
	struct UStateReflectComp* GetStateReflectComp();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022363A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022364E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.GenericChooseEnemyComponent
// Size: 0x1D0 (Inherited: 0x178)
struct UGenericChooseEnemyComponent : UActorComponent
{
	struct FGenericMonsterSensingConfig SensingConfig; // 0x178(0x48)
	struct FGenericSensingRuntimeState RuntimeState; // 0x1C0(0xC)
	uint8_t Pad_0x1CC[0x4]; // 0x1CC(0x4)


	// Object: Function GenericFeatures.GenericChooseEnemyComponent.SelectFromCandidates
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f5b8
	// Params: [ Num(3) Size(0x20) ]
	struct ACharacter* SelectFromCandidates(struct TArray<struct ACharacter*>& Filtered, uint8_t Rule);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10224A5C8
	// [Call #6] RVA: 0x10224A5C8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.IsValidEnemy
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f494
	// Params: [ Num(4) Size(0xB) ]
	bool IsValidEnemy(struct ACharacter* Target, bool& bOutIsNearDeath, bool bUseMonsterFilter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10224A5C8
	// [Call #12] RVA: 0x10224A5C8
	// [Call #13] RVA: 0x106C8459C

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.IsTargetAlive
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10224f418
	// Params: [ Num(2) Size(0x9) ]
	bool IsTargetAlive(struct ACharacter* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102238AAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.IsEnemyByActor
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10224f38c
	// Params: [ Num(2) Size(0x9) ]
	bool IsEnemyByActor(struct ACharacter* InTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022389F4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102238AAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.GetTargetHealth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10224f310
	// Params: [ Num(2) Size(0xC) ]
	float GetTargetHealth(struct ACharacter* Target);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102238B20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022389F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102238AAC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.GetSensingConfig
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f2b0
	// Params: [ Num(1) Size(0x48) ]
	struct FGenericMonsterSensingConfig GetSensingConfig();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102238B20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022389F4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102238AAC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.GetOwnerMonster
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f27c
	// Params: [ Num(1) Size(0x8) ]
	struct AGenericMonsterBase* GetOwnerMonster();
	// [Call #1] RVA: 0x1022389BC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102238B20
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022389F4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102238AAC
	// [Call #11] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.CollectPlayerCandidates
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f1cc
	// Params: [ Num(1) Size(0x10) ]
	void CollectPlayerCandidates(struct TArray<struct ACharacter*>& OutPlayers);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10224A5C8
	// [Call #4] RVA: 0x10224A5C8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x1022389BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102238B20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022389F4

	// Object: Function GenericFeatures.GenericChooseEnemyComponent.CollectMonsterCandidates
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224f11c
	// Params: [ Num(1) Size(0x10) ]
	void CollectMonsterCandidates(struct TArray<struct ACharacter*>& OutMonsters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10224A5C8
	// [Call #4] RVA: 0x10224A5C8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x10224A5C8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x1022389BC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.GenericMonsterBase
// Size: 0xB50 (Inherited: 0x9A0)
struct AGenericMonsterBase : AGenericCharacter
{
	uint8_t Pad_0x9A0[0x68]; // 0x9A0(0x68)
	struct FScriptMulticastDelegate OnMonsterSetPlayedIdleIndex; // 0xA08(0x10)
	struct FMonsterIdleIndex MonsterIdleIndex; // 0xA18(0x8)
	struct FScriptMulticastDelegate OnMonsterHurting; // 0xA20(0x10)
	struct FScriptMulticastDelegate OnEnemyChanged; // 0xA30(0x10)
	float WalkSpeed; // 0xA40(0x4)
	float RunSpeed; // 0xA44(0x4)
	float SpeedScale; // 0xA48(0x4)
	int TeamID; // 0xA4C(0x4)
	int Campid; // 0xA50(0x4)
	int MonsterLevel; // 0xA54(0x4)
	struct FString CharacterName; // 0xA58(0x10)
	struct UUTSkillManagerComponent* SkillManager; // 0xA68(0x8)
	struct USTBuffSystemComponent* BuffSystem; // 0xA70(0x8)
	struct USimulateSyncSmoothComponent* SimulateSyncSmooth; // 0xA78(0x8)
	struct UGenericChooseEnemyComponent* ChooseEnemyComponent; // 0xA80(0x8)
	struct UBehaviorControlComponent* BehaviorControlComp; // 0xA88(0x8)
	bool bEnableSimulateSyncSmooth; // 0xA90(0x1)
	uint8_t Pad_0xA91[0x3]; // 0xA91(0x3)
	float MovementTickInterval; // 0xA94(0x4)
	uint8_t RegionSize; // 0xA98(0x1)
	bool bRegionStatic; // 0xA99(0x1)
	uint8_t AutoDormancyType; // 0xA9A(0x1)
	uint8_t Pad_0xA9B[0x1]; // 0xA9B(0x1)
	float SpawnAnimTime; // 0xA9C(0x4)
	uint8_t Pad_0xAA0[0x18]; // 0xAA0(0x18)
	float LandDuration; // 0xAB8(0x4)
	float InAirVelocityThreshold; // 0xABC(0x4)
	float MoveSpeedTolerance; // 0xAC0(0x4)
	uint8_t Pad_0xAC4[0x4]; // 0xAC4(0x4)
	bool bAllowVehicleKnockback; // 0xAC8(0x1)
	uint8_t Pad_0xAC9[0x3]; // 0xAC9(0x3)
	float VehicleHitLaunchPitchDeg; // 0xACC(0x4)
	float VehicleHitRefMinImpulse; // 0xAD0(0x4)
	float VehicleHitRefMaxImpulse; // 0xAD4(0x4)
	float VehicleHitMinLaunchVelocity; // 0xAD8(0x4)
	float VehicleHitMaxLaunchVelocity; // 0xADC(0x4)
	bool bAllowLaunchAirState; // 0xAE0(0x1)
	uint8_t Pad_0xAE1[0x3]; // 0xAE1(0x3)
	float DelayCheckLaunchAirState; // 0xAE4(0x4)
	float MinLaunchAirGroundTime; // 0xAE8(0x4)
	float MaxLaunchAirGroundTime; // 0xAEC(0x4)
	float LaunchAirRiseUpDuration; // 0xAF0(0x4)
	uint8_t Pad_0xAF4[0x1C]; // 0xAF4(0x1C)
	float StunBeginAnimTime; // 0xB10(0x4)
	float StunAnimTime; // 0xB14(0x4)
	float StunRecoveryAnimTime; // 0xB18(0x4)
	uint8_t Pad_0xB1C[0x1C]; // 0xB1C(0x1C)
	bool CloseCollisionForMeshOnDS; // 0xB38(0x1)
	bool bForceAnimationUpdatedOnClient; // 0xB39(0x1)
	bool bHideMeshUntilAnimAssetsLoaded; // 0xB3A(0x1)
	uint8_t Pad_0xB3B[0x1]; // 0xB3B(0x1)
	float ShowMeshDelayAfterAnimAssetsLoaded; // 0xB3C(0x4)
	struct FScriptMulticastDelegate OnEditorKeyPressedDelegate; // 0xB40(0x10)


	// Object: Function GenericFeatures.GenericMonsterBase.SetTeamID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102252264
	// Params: [ Num(1) Size(0x4) ]
	void SetTeamID(int NewTeamId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterBase.SetSpeedScale
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022521e0
	// Params: [ Num(1) Size(0x4) ]
	void SetSpeedScale(float NewSpeedScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterBase.SetMonsterIdleIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10225215c
	// Params: [ Num(1) Size(0x4) ]
	void SetMonsterIdleIndex(int NewIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterBase.SetCharacterName
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022520bc
	// Params: [ Num(1) Size(0x10) ]
	void SetCharacterName(struct FString NewCharacterName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.SetCampID
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102252038
	// Params: [ Num(1) Size(0x4) ]
	void SetCampID(int NewCampID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.SelectEnemyByLua
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102251f78
	// Params: [ Num(2) Size(0x18) ]
	struct ACharacter* SelectEnemyByLua(struct TArray<struct ACharacter*>& Candidates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10224A5C8
	// [Call #4] RVA: 0x10224A5C8
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.ReviseSenseDistanceByActor
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102251ea8
	// Params: [ Num(3) Size(0x14) ]
	float ReviseSenseDistanceByActor(float InDistance, struct AActor* InTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonsterBase.ReceivedPlayerActiveRegionsChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void ReceivedPlayerActiveRegionsChanged(bool bEnter);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GenericFeatures.GenericMonsterBase.OnSmoothComponentSnapshotPreReplicate
	// Flags: [Final|Native|Public]
	// Offset: 0x102251e94
	// Params: [ Num(0) Size(0x0) ]
	void OnSmoothComponentSnapshotPreReplicate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.OnRep_MonsterIdleIndex
	// Flags: [Native|Protected]
	// Offset: 0x102251e78
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_MonsterIdleIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.OnRep_CampID
	// Flags: [Native|Public]
	// Offset: 0x102251e5c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CampID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.LeaveLaunchAirRiseUp
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251e40
	// Params: [ Num(0) Size(0x0) ]
	void LeaveLaunchAirRiseUp();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.LeaveLaunchAirGround
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251e24
	// Params: [ Num(0) Size(0x0) ]
	void LeaveLaunchAirGround();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10224A5C8
	// [Call #8] RVA: 0x10224A5C8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonsterBase.LaunchCharacterWithParam
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102251d5c
	// Params: [ Num(2) Size(0xD) ]
	void LaunchCharacterWithParam(struct FVector LaunchVelocity, bool bChangeState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.IsValidEnemyTarget
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102251cc8
	// Params: [ Num(2) Size(0x9) ]
	bool IsValidEnemyTarget(struct AActor* InTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonsterBase.IsEnemyByActor
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x102251c34
	// Params: [ Num(2) Size(0x9) ]
	bool IsEnemyByActor(struct ACharacter* InTarget);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetTeamID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251bf8
	// Params: [ Num(1) Size(0x4) ]
	int GetTeamID();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetSpeedScale
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251bbc
	// Params: [ Num(1) Size(0x4) ]
	float GetSpeedScale();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetSensingConfig
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251b5c
	// Params: [ Num(1) Size(0x48) ]
	struct FGenericMonsterSensingConfig GetSensingConfig();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetMonsterIdleIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251b20
	// Params: [ Num(1) Size(0x4) ]
	int GetMonsterIdleIndex();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetCurrentSpeed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251ae4
	// Params: [ Num(1) Size(0x4) ]
	float GetCurrentSpeed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetChooseEnemyComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251ab0
	// Params: [ Num(1) Size(0x8) ]
	struct UGenericChooseEnemyComponent* GetChooseEnemyComponent();
	// [Call #1] RVA: 0x102242E40
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonsterBase.GetCharacterName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251a44
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetCharacterName();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterBase.GetCampID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251a08
	// Params: [ Num(1) Size(0x4) ]
	int GetCampID();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.GetBuffComponent
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022519cc
	// Params: [ Num(1) Size(0x8) ]
	struct USTBuffSystemComponent* GetBuffComponent();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.FinishStunRecovery
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022519b0
	// Params: [ Num(0) Size(0x0) ]
	void FinishStunRecovery();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.ExitSpawnState
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251994
	// Params: [ Num(0) Size(0x0) ]
	void ExitSpawnState();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.EnterStunRecovery
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251978
	// Params: [ Num(0) Size(0x0) ]
	void EnterStunRecovery();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.EnterStun
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10225195c
	// Params: [ Num(0) Size(0x0) ]
	void EnterStun();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.DoHurting
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022518d8
	// Params: [ Num(1) Size(0xC) ]
	void DoHurting(struct FVector HurtDir);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.ClearStunState
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022518bc
	// Params: [ Num(0) Size(0x0) ]
	void ClearStunState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.ClearLaunchAirState
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022518a0
	// Params: [ Num(0) Size(0x0) ]
	void ClearLaunchAirState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.CheckLaunchAirState
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251884
	// Params: [ Num(0) Size(0x0) ]
	void CheckLaunchAirState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8156C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x102242E40

	// Object: Function GenericFeatures.GenericMonsterBase.ChangeWalkSpeed
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102251800
	// Params: [ Num(1) Size(0x1) ]
	void ChangeWalkSpeed(uint8_t InWalkType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.GenericMonster
// Size: 0xC80 (Inherited: 0xB50)
struct AGenericMonster : AGenericMonsterBase
{
	uint8_t Pad_0xB50[0xA0]; // 0xB50(0xA0)
	float HealthMax; // 0xBF0(0x4)
	float Health; // 0xBF4(0x4)
	struct TArray<uint8_t> DamageableGameObjectTypes; // 0xBF8(0x10)
	float TakeDamageScale; // 0xC08(0x4)
	float DamageScale; // 0xC0C(0x4)
	struct UCurveFloat* VehicleSpeedDamageCurve; // 0xC10(0x8)
	float VehicleHitDamageScale; // 0xC18(0x4)
	float VehicleHitMinDamageSpeedKmh; // 0xC1C(0x4)
	float VehicleHitRefDamageSpeedKmh; // 0xC20(0x4)
	float VehicleHitMinDamageImpulse; // 0xC24(0x4)
	float VehicleHitRefDamageImpulse; // 0xC28(0x4)
	float VehicleHitMinDamage; // 0xC2C(0x4)
	float VehicleHitMaxDamage; // 0xC30(0x4)
	float DeadAnimTime; // 0xC34(0x4)
	float HurtAnimTime; // 0xC38(0x4)
	uint8_t IsInvincible : 1; // 0xC3C(0x1), Mask(0x1)
	uint8_t BitPad_0xC3C_1 : 7; // 0xC3C(0x1)
	uint8_t Pad_0xC3D[0x1]; // 0xC3D(0x1)
	bool bForceOpenPawnCollision; // 0xC3E(0x1)
	bool bShowGenericHPBar; // 0xC3F(0x1)
	int GenericHPBarPlanID; // 0xC40(0x4)
	int CustomHPBarType; // 0xC44(0x4)
	int CustomHPBarScreenMarkID; // 0xC48(0x4)
	uint8_t Pad_0xC4C[0x4]; // 0xC4C(0x4)
	struct FString CustomHPBarUIConfig; // 0xC50(0x10)
	uint8_t Pad_0xC60[0x10]; // 0xC60(0x10)
	struct UPartHitComponentBase* PartHitComp; // 0xC70(0x8)
	uint8_t Pad_0xC78[0x8]; // 0xC78(0x8)


	// Object: Function GenericFeatures.GenericMonster.SetTakeDamageScale
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102250524
	// Params: [ Num(1) Size(0x4) ]
	void SetTakeDamageScale(float NewTakeDamageScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonster.SetIsInvincible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10225045c
	// Params: [ Num(2) Size(0x2) ]
	void SetIsInvincible(bool bInvincible, uint8_t InMaskBit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10223FCE4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonster.SetHealthMax
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022503d8
	// Params: [ Num(1) Size(0x4) ]
	void SetHealthMax(float NewHealthMax);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10223FCE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function GenericFeatures.GenericMonster.SetHealth
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102250354
	// Params: [ Num(1) Size(0x4) ]
	void SetHealth(float NewHealth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223FCE4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.SetDamageScale
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022502d0
	// Params: [ Num(1) Size(0x4) ]
	void SetDamageScale(float NewDamageScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10223FCE4

	// Object: Function GenericFeatures.GenericMonster.OnTargetTakeDamage
	// Flags: [Native|Public]
	// Offset: 0x1022501c4
	// Params: [ Num(4) Size(0x1C) ]
	float OnTargetTakeDamage(struct AActor* DamageTarget, float Damage, struct AController* EventInstigator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonster.OnDie
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102250148
	// Params: [ Num(1) Size(0x8) ]
	void OnDie(struct APawn* Causer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223F760
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonster.HandleTargetTakeDamage
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x10225003c
	// Params: [ Num(4) Size(0x1C) ]
	float HandleTargetTakeDamage(struct AActor* DamageTarget, float Damage, struct AController* EventInstigator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223F760
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.GetTakeDamageScale
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102250000
	// Params: [ Num(1) Size(0x4) ]
	float GetTakeDamageScale();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223F760
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.GetPartHitComponentBase
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10224ffc4
	// Params: [ Num(1) Size(0x8) ]
	struct UPartHitComponentBase* GetPartHitComponentBase();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223F760
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.GetIsInvincible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224ffa4
	// Params: [ Num(1) Size(0x1) ]
	bool GetIsInvincible();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223F760

	// Object: Function GenericFeatures.GenericMonster.GetHealthMax
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224ff68
	// Params: [ Num(1) Size(0x4) ]
	float GetHealthMax();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223F760

	// Object: Function GenericFeatures.GenericMonster.GetHealth
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224ff2c
	// Params: [ Num(1) Size(0x4) ]
	float GetHealth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168

	// Object: Function GenericFeatures.GenericMonster.GetDamageScale
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10224fef0
	// Params: [ Num(1) Size(0x4) ]
	float GetDamageScale();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.CalcVehicleHitDamage
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x10224fde4
	// Params: [ Num(4) Size(0x1C) ]
	float CalcVehicleHitDamage(struct ASTExtraVehicleBase* OtherVehicle, struct FVector HitImpulseDirection, float HitSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonster.BPReceiveDamage
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(5) Size(0x21) ]
	void BPReceiveDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser, enum class EDamageType DamageEventType);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function GenericFeatures.GenericMonster.BPPreTakeDamage
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10224fc84
	// Params: [ Num(5) Size(0x2C) ]
	float BPPreTakeDamage(float DamageAmount, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.GenericMonsterAnimInstance
// Size: 0x1850 (Inherited: 0x1780)
struct UGenericMonsterAnimInstance : UDataDriverAnimInstance
{
	struct FVector Velocity; // 0x177C(0xC)
	float Speed; // 0x1788(0x4)
	float RandomIdleIndex; // 0x178C(0x4)
	int RandomIdleIndexInt; // 0x1790(0x4)
	struct FGameplayTag RandomIdleBS1DTag; // 0x1798(0x8)
	struct FVector HurtDirection; // 0x17A0(0xC)
	float HurtingAccumulate; // 0x17AC(0x4)
	bool bIsHurting; // 0x17B0(0x1)
	uint8_t Pad_0x17B1[0x3]; // 0x17B1(0x3)
	float HurtingAnimPlayRate; // 0x17B4(0x4)
	struct FGameplayTag HurtBSTag; // 0x17B8(0x8)
	struct TMap<struct FGameplayTag, struct FGameplayTag> StateToMontageParamMap; // 0x17C0(0x50)
	bool bMonsterIdleIndexDelegateBound; // 0x1810(0x1)
	uint8_t Pad_0x1811[0x7]; // 0x1811(0x7)
	struct AGenericMonsterBase* CachedOwnerMonster; // 0x1818(0x8)
	bool bMonsterHurtingDelegateBound; // 0x1820(0x1)
	uint8_t Pad_0x1821[0x7]; // 0x1821(0x7)
	struct UStateReflectComp* CachedStateReflectComp; // 0x1828(0x8)
	struct TArray<struct FGameplayTag> PendingMontageTags; // 0x1830(0x10)
	bool bAnimAssetsLoadedDelegateBound; // 0x1840(0x1)
	uint8_t Pad_0x1841[0xF]; // 0x1841(0xF)


	// Object: Function GenericFeatures.GenericMonsterAnimInstance.PlayMontageWithAnimEventByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102250e60
	// Params: [ Num(2) Size(0xC) ]
	float PlayMontageWithAnimEventByName(struct FName& InTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223C5AC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterAnimInstance.PlayMontageWithAnimEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102250dc4
	// Params: [ Num(2) Size(0xC) ]
	float PlayMontageWithAnimEvent(struct FGameplayTag& EventTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223C1E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10223C5AC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterAnimInstance.OnMonsterRandomIdleIndexSet
	// Flags: [Native|Protected]
	// Offset: 0x102250d40
	// Params: [ Num(1) Size(0x4) ]
	void OnMonsterRandomIdleIndexSet(int NewIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10223C1E4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10223C5AC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function GenericFeatures.GenericMonsterAnimInstance.OnMonsterHurting
	// Flags: [Native|Protected|HasDefaults]
	// Offset: 0x102250c80
	// Params: [ Num(2) Size(0x14) ]
	void OnMonsterHurting(struct AGenericMonsterBase* Monster, struct FVector HurtDir);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223C1E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericMonsterAnimInstance.HandleStateEntered
	// Flags: [Final|Native|Protected]
	// Offset: 0x102250c04
	// Params: [ Num(1) Size(0x8) ]
	void HandleStateEntered(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223C0F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10223C1E4

	// Object: Function GenericFeatures.GenericMonsterAnimInstance.GetMonsterShareParams
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102250bd0
	// Params: [ Num(1) Size(0x8) ]
	struct UGenericMonsterAnimShareParamsComp* GetMonsterShareParams();
	// [Call #1] RVA: 0x10223AEE0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10223C0F0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.GenericMonsterAnimShareParamsComp
// Size: 0x550 (Inherited: 0x4B0)
struct UGenericMonsterAnimShareParamsComp : UDataDriverAnimShareParamsComp
{
	struct FSoftObjectPath AnimDataAsset; // 0x4B0(0x18)
	int64_t AnimAssetContextKey; // 0x4C8(0x8)
	struct TMap<struct FGameplayTag, struct FGameplayTag> StateToAnimParamMap; // 0x4D0(0x50)
	uint8_t Pad_0x520[0x18]; // 0x520(0x18)
	struct UStateReflectComp* CachedStateRef; // 0x538(0x8)
	struct FName AnimSourceKey; // 0x540(0x8)
	bool bAnimAssetsLoaded; // 0x548(0x1)
	uint8_t Pad_0x549[0x7]; // 0x549(0x7)


	// Object: Function GenericFeatures.GenericMonsterAnimShareParamsComp.IsAnimAssetsLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102251390
	// Params: [ Num(1) Size(0x1) ]
	bool IsAnimAssetsLoaded();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C

	// Object: Function GenericFeatures.GenericMonsterAnimShareParamsComp.HandleStateLeft
	// Flags: [Final|Native|Protected]
	// Offset: 0x102251314
	// Params: [ Num(1) Size(0x8) ]
	void HandleStateLeft(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223CED8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterAnimShareParamsComp.HandleStateEntered
	// Flags: [Final|Native|Protected]
	// Offset: 0x102251298
	// Params: [ Num(1) Size(0x8) ]
	void HandleStateEntered(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223CE08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10223CED8
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericMonsterAnimShareParamsComp.GetLoadedAnimAsset
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022511fc
	// Params: [ Num(2) Size(0x10) ]
	struct UAnimationAsset* GetLoadedAnimAsset(struct FGameplayTag& Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10223C528
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10223CE08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10223CED8
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
};

// Object: Class GenericFeatures.GenericMonsterEditor
// Size: 0xC80 (Inherited: 0xC80)
struct AGenericMonsterEditor : AGenericMonster
{
};

// Object: Class GenericFeatures.GenericNPC
// Size: 0xB50 (Inherited: 0xB50)
struct AGenericNPC : AGenericMonsterBase
{
};

// Object: Class GenericFeatures.GenericPartHitComponent
// Size: 0x2E0 (Inherited: 0x178)
struct UGenericPartHitComponent : UPartHitComponentBase
{
	struct ACharacter* OwnerCharacter; // 0x178(0x8)
	float UpdateHitBoxDeltaTime; // 0x180(0x4)
	bool bActivePartHit; // 0x184(0x1)
	uint8_t Pad_0x185[0x3]; // 0x185(0x3)
	uint64_t LastPartHitRefreshBoxCollisionFrameNum; // 0x188(0x8)
	struct TMap<struct FGameplayTag, enum class ESTEPoseState> TagToPoseMap; // 0x190(0x50)
	struct TMap<enum class ESTEPoseState, struct FHitBoxTagInfo> HitBoxTagMapData; // 0x1E0(0x50)
	struct FHitBoxTagInfo UselessHitBoxData; // 0x230(0x18)
	struct TArray<struct UPrimitiveComponent*> HitBoxList; // 0x248(0x10)
	uint8_t Pad_0x258[0x20]; // 0x258(0x20)
	struct TMap<struct FString, uint8_t> NewHitBodyPosMap; // 0x278(0x50)
	float PawnCollisionCountdown; // 0x2C8(0x4)
	bool bIsRefreshPawnCollision; // 0x2CC(0x1)
	uint8_t Pad_0x2CD[0x3]; // 0x2CD(0x3)
	float BoxCollisionCountdown; // 0x2D0(0x4)
	bool bIsRefreshBoxCollision; // 0x2D4(0x1)
	enum class EHitPartJugementType ClientHitPartJudgment; // 0x2D5(0x1)
	uint8_t Pad_0x2D6[0x1]; // 0x2D6(0x1)
	bool bDebugDrawHitPos; // 0x2D7(0x1)
	bool bCloseCharacterMeshCollision; // 0x2D8(0x1)
	uint8_t Pad_0x2D9[0x7]; // 0x2D9(0x7)


	// Object: Function GenericFeatures.GenericPartHitComponent.UpdatePoseCollisionShapes
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102255ba4
	// Params: [ Num(1) Size(0x1) ]
	void UpdatePoseCollisionShapes(enum class ESTEPoseState PoseState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericPartHitComponent.UpdateAllInstanceBodyTransform
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102255b20
	// Params: [ Num(1) Size(0x4) ]
	void UpdateAllInstanceBodyTransform(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericPartHitComponent.RefreshWorldBoxCollision
	// Flags: [Exec|Native|Public|BlueprintCallable]
	// Offset: 0x102255a9c
	// Params: [ Num(1) Size(0x4) ]
	void RefreshWorldBoxCollision(float countdown);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericPartHitComponent.RefreshByStateChange
	// Flags: [Final|Native|Public]
	// Offset: 0x102255a20
	// Params: [ Num(1) Size(0x8) ]
	void RefreshByStateChange(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102239B80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericPartHitComponent.InitBodyHitBox
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102255a04
	// Params: [ Num(0) Size(0x0) ]
	void InitBodyHitBox();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102239B80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericFeatures.GenericPartHitComponent.GetHitBoxByState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102255978
	// Params: [ Num(2) Size(0x10) ]
	struct UPrimitiveComponent* GetHitBoxByState(enum class ESTEPoseState InPoseState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102239F94
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102239B80
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericPartHitComponent.GetHitBodyTypeByHitPos
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022558d8
	// Params: [ Num(2) Size(0xD) ]
	uint8_t GetHitBodyTypeByHitPos(struct FVector& InHitPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102239F94
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102239B80
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericPartHitComponent.GetHitBodyTypeByBoneName
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102255828
	// Params: [ Num(2) Size(0x11) ]
	uint8_t GetHitBodyTypeByBoneName(struct FString InBoneName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102239F94
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericPartHitComponent.GetHitBodyType
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022556d8
	// Params: [ Num(4) Size(0x29) ]
	uint8_t GetHitBodyType(struct FVector& InHitPos, struct FVector& InImpactVec, struct FString InBoneName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GenericFeatures.GenericPartHitComponent.GetCurHitPartJudgementType
	// Flags: [Native|Public]
	// Offset: 0x10225569c
	// Params: [ Num(1) Size(0x1) ]
	enum class EHitPartJugementType GetCurHitPartJudgementType();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function GenericFeatures.GenericPartHitComponent.CloseBodyBulletCollision
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102255680
	// Params: [ Num(0) Size(0x0) ]
	void CloseBodyBulletCollision();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function GenericFeatures.GenericPartHitComponent.CalcHitBodyType
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022554fc
	// Params: [ Num(5) Size(0x2D) ]
	uint8_t CalcHitBodyType(struct FVector& InHitPos, struct FVector& InProjvec, struct FVector& InCenterPos, struct FBodyTypeDef& InBodyDef);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
};

// Object: Class GenericFeatures.StateReflectComp
// Size: 0x1C0 (Inherited: 0x178)
struct UStateReflectComp : UActorComponent
{
	struct UStateRelationDataAsset* RelationData; // 0x178(0x8)
	struct FScriptMulticastDelegate OnStateEntered; // 0x180(0x10)
	struct FScriptMulticastDelegate OnStateLeft; // 0x190(0x10)
	struct FGameplayTagContainer CurrentStates; // 0x1A0(0x20)


	// Object: Function GenericFeatures.StateReflectComp.OnRep_CurrentStates
	// Flags: [Final|Native|Protected]
	// Offset: 0x1022563cc
	// Params: [ Num(1) Size(0x20) ]
	void OnRep_CurrentStates(struct FGameplayTagContainer OldStates);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020C5138
	// [Call #4] RVA: 0x10223773C
	// [Call #5] RVA: 0x1020C4E8C
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x10519022C

	// Object: Function GenericFeatures.StateReflectComp.LeaveState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102256350
	// Params: [ Num(1) Size(0x8) ]
	void LeaveState(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022373F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1020C5138
	// [Call #7] RVA: 0x10223773C
	// [Call #8] RVA: 0x1020C4E8C
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x1020C4E8C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function GenericFeatures.StateReflectComp.HasState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102256280
	// Params: [ Num(3) Size(0xA) ]
	bool HasState(struct FGameplayTag State, bool bExact);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022376D4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022373F0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1020C5138
	// [Call #12] RVA: 0x10223773C
	// [Call #13] RVA: 0x1020C4E8C
	// [Call #14] RVA: 0x1020C4E8C
	// [Call #15] RVA: 0x1020C4E8C
	// [Call #16] RVA: 0x1020C4E8C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10519022C

	// Object: Function GenericFeatures.StateReflectComp.GetCurrentStates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102256214
	// Params: [ Num(1) Size(0x20) ]
	struct FGameplayTagContainer GetCurrentStates();
	// [Call #1] RVA: 0x1020C5138
	// [Call #2] RVA: 0x105E421EC
	// [Call #3] RVA: 0x1020C4E8C
	// [Call #4] RVA: 0x1020C4E8C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022376D4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022373F0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1020C5138
	// [Call #17] RVA: 0x10223773C
	// [Call #18] RVA: 0x1020C4E8C
	// [Call #19] RVA: 0x1020C4E8C

	// Object: Function GenericFeatures.StateReflectComp.EnterState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102256188
	// Params: [ Num(2) Size(0x9) ]
	bool EnterState(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102236A1C
	// [Call #4] RVA: 0x1020C5138
	// [Call #5] RVA: 0x105E421EC
	// [Call #6] RVA: 0x1020C4E8C
	// [Call #7] RVA: 0x1020C4E8C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022376D4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022373F0

	// Object: Function GenericFeatures.StateReflectComp.CanEnterState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022560fc
	// Params: [ Num(2) Size(0x9) ]
	bool CanEnterState(struct FGameplayTag State);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102236920
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x102236A1C
	// [Call #7] RVA: 0x1020C5138
	// [Call #8] RVA: 0x105E421EC
	// [Call #9] RVA: 0x1020C4E8C
	// [Call #10] RVA: 0x1020C4E8C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022376D4
};

// Object: Class GenericFeatures.StateRelationDataAsset
// Size: 0x90 (Inherited: 0x30)
struct UStateRelationDataAsset : UDataAsset
{
	struct TArray<struct FStateRelationEntry> Entries; // 0x30(0x10)
	uint8_t Pad_0x40[0x50]; // 0x40(0x50)
};

