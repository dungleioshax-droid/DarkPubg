#pragma once

#include <cstdint>

// Object: Enum PhotonDestructible.EFracturedMeshConnectionType
enum class EFracturedMeshConnectionType : uint8_t
{
	FracturedMeshConnType_None = 0,
	FracturedMeshConnType_Indestructible = 1,
	FracturedMeshConnType_Border = 2,
	FracturedMeshConnType_IndestructibleAndBorder = 3,
	FracturedMeshConnType_MAX = 4
};

// Object: Enum PhotonDestructible.EFracturedImpactEffType
enum class EFracturedImpactEffType : uint8_t
{
	FracturedImpactEffType_Normal = 0,
	FracturedImpactEffType_SpreadOut = 1,
	FracturedImpactEffType_MAX = 2
};

// Object: Enum PhotonDestructible.EFracturedMeshDestructibleAction
enum class EFracturedMeshDestructibleAction : uint8_t
{
	FracturedDAction_Hide = 0,
	FracturedDAction_Detach = 1,
	FracturedDAction_MAX = 2
};

// Object: Enum PhotonDestructible.EPhotonDestructibleSurfaceHitType
enum class EPhotonDestructibleSurfaceHitType : uint8_t
{
	PDSurfaceHit_Circle = 0,
	PDSurfaceHit_Texture = 1,
	PDSurfaceHit_MAX = 2
};

// Object: Enum PhotonDestructible.EFracturedAxis
enum class EFracturedAxis : uint8_t
{
	FracturedAxis_X = 0,
	FracturedAxis_Y = 1,
	FracturedAxis_Z = 2,
	FracturedAxis_NX = 3,
	FracturedAxis_NY = 4,
	FracturedAxis_NZ = 5,
	FracturedAxis_MAX = 6
};

// Object: ScriptStruct PhotonDestructible.PDSurfaceNetData
// Size: 0x18 (Inherited: 0x0)
struct FPDSurfaceNetData
{
	struct TArray<struct FPhotonDestructibleSurfaceHitData> SurfaceHitData; // 0x0(0x10)
	int HitDataCount; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct PhotonDestructible.PhotonDestructibleSurfaceHitData
// Size: 0x18 (Inherited: 0x0)
struct FPhotonDestructibleSurfaceHitData
{
	uint16_t InstanceIndex; // 0x0(0x2)
	enum class EPhotonDestructibleSurfaceHitType HitType; // 0x2(0x1)
	uint8_t Pad_0x3[0x1]; // 0x3(0x1)
	int HitParam; // 0x4(0x4)
	int HitParam2; // 0x8(0x4)
	struct FVector HitPoint; // 0xC(0xC)
};

// Object: Class PhotonDestructible.FEdgeData
// Size: 0x28 (Inherited: 0x28)
struct UFEdgeData : UObject
{
};

// Object: Class PhotonDestructible.FracturedFragmentInfo
// Size: 0x80 (Inherited: 0x28)
struct UFracturedFragmentInfo : UObject
{
	struct TArray<struct FKConvexElem> ConvexElemForCollision; // 0x28(0x10)
	struct FVector CenterPoint; // 0x38(0xC)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct TArray<int> neighbors; // 0x48(0x10)
	struct TArray<struct FPlane> FacePlaneData; // 0x58(0x10)
	struct TArray<struct FVector> PolygonVertex; // 0x68(0x10)
	uint8_t CanDestroy : 1; // 0x78(0x1), Mask(0x1)
	uint8_t HasTriangle : 1; // 0x78(0x1), Mask(0x2)
	uint8_t IsBorder : 1; // 0x78(0x1), Mask(0x4)
	uint8_t BitPad_0x78_3 : 5; // 0x78(0x1)
	uint8_t Pad_0x79[0x7]; // 0x79(0x7)
};

// Object: Class PhotonDestructible.MaterialExpressionObjectLocalPosition
// Size: 0x60 (Inherited: 0x60)
struct UMaterialExpressionObjectLocalPosition : UMaterialExpression
{
};

// Object: Class PhotonDestructible.MaterialExpressionGetPDInstancedSurfaceMask
// Size: 0x60 (Inherited: 0x60)
struct UMaterialExpressionGetPDInstancedSurfaceMask : UMaterialExpression
{
};

// Object: Class PhotonDestructible.PhotonDestructibleAtlasPool
// Size: 0x188 (Inherited: 0x178)
struct UPhotonDestructibleAtlasPool : UActorComponent
{
	uint8_t Pad_0x178[0x10]; // 0x178(0x10)
};

// Object: Class PhotonDestructible.PhotonDestructibleMgr
// Size: 0x4D8 (Inherited: 0x4B0)
struct APhotonDestructibleMgr : AActor
{
	struct UPhotonDestructibleTexturePool* TexturePool; // 0x4B0(0x8)
	struct UPhotonDestructibleAtlasPool* AtlasPool; // 0x4B8(0x8)
	struct UPhotonDestructibleTexture2DArrayManager* Texture2DArrayManager; // 0x4C0(0x8)
	struct UPhotonDestructibleSurfaceConfig* SurfaceConfig; // 0x4C8(0x8)
	struct UPhotonDestructiblePuppetMgr* PuppetMgr; // 0x4D0(0x8)
};

// Object: Class PhotonDestructible.PhotonDestructiblePuppet
// Size: 0x3B0 (Inherited: 0x3A0)
struct UPhotonDestructiblePuppet : USceneComponent
{
	struct FGuid TargetPuppetGUID; // 0x39C(0x10)


	// Object: Function PhotonDestructible.PhotonDestructiblePuppet.TriggerPuppetEvent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10208e600
	// Params: [ Num(1) Size(0x4) ]
	void TriggerPuppetEvent(int EventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10208E94C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
};

// Object: Class PhotonDestructible.PhotonDestructiblePuppetContainer
// Size: 0x3C0 (Inherited: 0x3A0)
struct UPhotonDestructiblePuppetContainer : USceneComponent
{
	struct TArray<struct FGuid> TargetsPuppetGUID; // 0x3A0(0x10)
	struct TArray<struct FString> TargetsName; // 0x3B0(0x10)


	// Object: Function PhotonDestructible.PhotonDestructiblePuppetContainer.TriggerPuppetEvent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10208e7e4
	// Params: [ Num(2) Size(0x14) ]
	void TriggerPuppetEvent(struct FString ObjectName, int EventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10508F76C
	// [Call #11] RVA: 0x10516EACC
};

// Object: Class PhotonDestructible.PhotonDestructiblePuppetMgr
// Size: 0x1C8 (Inherited: 0x178)
struct UPhotonDestructiblePuppetMgr : UActorComponent
{
	uint8_t Pad_0x178[0x50]; // 0x178(0x50)


	// Object: Function PhotonDestructible.PhotonDestructiblePuppetMgr.Client_TriggerPuppetEvent
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults]
	// Offset: 0x10208ea78
	// Params: [ Num(2) Size(0x14) ]
	void Client_TriggerPuppetEvent(struct FGuid PuppetGUID, int EventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x105190870
};

// Object: Class PhotonDestructible.PhotonDestructiblePuppetTarget
// Size: 0x28 (Inherited: 0x28)
struct IPhotonDestructiblePuppetTarget : IInterface
{
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceActor
// Size: 0x4C0 (Inherited: 0x4B0)
struct APhotonDestructibleSurfaceActor : AActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	struct UPhotonDestructibleSurfaceComponent* SurfaceComponent; // 0x4B8(0x8)
};

// Object: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceActor
// Size: 0x4C0 (Inherited: 0x4B0)
struct APhotonDestructibleInstancedSurfaceActor : AActor
{
	uint8_t Pad_0x4B0[0x8]; // 0x4B0(0x8)
	struct UPhotonDestructibleInstancedSurfaceComponent* InstancedSurfaceComponent; // 0x4B8(0x8)
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceActorBase
// Size: 0x28 (Inherited: 0x28)
struct IPhotonDestructibleSurfaceActorBase : IInterface
{
};

// Object: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceActorBase
// Size: 0x28 (Inherited: 0x28)
struct IPhotonDestructibleInstancedSurfaceActorBase : IInterface
{
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceComponent
// Size: 0xC40 (Inherited: 0xBD0)
struct UPhotonDestructibleSurfaceComponent : UStaticMeshComponent
{
	uint8_t Pad_0xBD0[0x10]; // 0xBD0(0x10)
	enum class EFracturedAxis MaskUAxis; // 0xBE0(0x1)
	enum class EFracturedAxis MaskVAxis; // 0xBE1(0x1)
	uint8_t Pad_0xBE2[0x6]; // 0xBE2(0x6)
	struct UTexture2D* MaskTexture2D; // 0xBE8(0x8)
	struct FPDSurfaceNetData SurfaceNetData; // 0xBF0(0x18)
	struct FGuid TargetPuppetGUID; // 0xC08(0x10)
	uint8_t Pad_0xC18[0x28]; // 0xC18(0x28)


	// Object: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.Server_ProcessHit
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10208f3d0
	// Params: [ Num(1) Size(0x18) ]
	void Server_ProcessHit(struct FPhotonDestructibleSurfaceHitData& HitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020827F8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x1051903D0

	// Object: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.OnRep_SurfaceNetData
	// Flags: [Final|Native|Public]
	// Offset: 0x10208f3bc
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SurfaceNetData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020827F8
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x1051903D0

	// Object: Function PhotonDestructible.PhotonDestructibleSurfaceComponent.Client_OnProcessHit
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x10208f328
	// Params: [ Num(1) Size(0x18) ]
	void Client_OnProcessHit(struct FPhotonDestructibleSurfaceHitData HitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1020827F8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent
// Size: 0xE80 (Inherited: 0xE10)
struct UPhotonDestructibleInstancedSurfaceComponent : UHierarchicalInstancedStaticMeshComponent
{
	uint8_t Pad_0xE10[0x10]; // 0xE10(0x10)
	enum class EFracturedAxis MaskUAxis; // 0xE20(0x1)
	enum class EFracturedAxis MaskVAxis; // 0xE21(0x1)
	uint8_t Pad_0xE22[0x6]; // 0xE22(0x6)
	struct UMaterialInterface* Texture2DArrayMaterial; // 0xE28(0x8)
	struct UMaterialInterface* AtlasMaterial; // 0xE30(0x8)
	struct FPDSurfaceNetData SurfaceNetData; // 0xE38(0x18)
	struct TArray<struct FGuid> TargetPuppetGUID; // 0xE50(0x10)
	uint8_t Pad_0xE60[0x20]; // 0xE60(0x20)


	// Object: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.Server_ProcessHit
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10208f7ac
	// Params: [ Num(1) Size(0x18) ]
	void Server_ProcessHit(struct FPhotonDestructibleSurfaceHitData& HitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102084D24
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.OnRep_SurfaceNetData
	// Flags: [Final|Native|Public]
	// Offset: 0x10208f798
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SurfaceNetData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102084D24
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10508F76C

	// Object: Function PhotonDestructible.PhotonDestructibleInstancedSurfaceComponent.Client_OnProcessHit
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	// Offset: 0x10208f704
	// Params: [ Num(1) Size(0x18) ]
	void Client_OnProcessHit(struct FPhotonDestructibleSurfaceHitData HitData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102084D24
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceBase
// Size: 0x28 (Inherited: 0x28)
struct IPhotonDestructibleSurfaceBase : IInterface
{
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceConfig
// Size: 0x188 (Inherited: 0x178)
struct UPhotonDestructibleSurfaceConfig : UActorComponent
{
	struct TArray<struct UPhotonDestructibleSurfaceMask*> TextureMaskData; // 0x178(0x10)
};

// Object: Class PhotonDestructible.PhotonDestructibleSurfaceMask
// Size: 0x48 (Inherited: 0x28)
struct UPhotonDestructibleSurfaceMask : UObject
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
	struct FIntPoint MaskSize; // 0x30(0x8)
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
};

// Object: Class PhotonDestructible.PhotonDestructibleTexture2DArrayManager
// Size: 0x1A0 (Inherited: 0x178)
struct UPhotonDestructibleTexture2DArrayManager : UActorComponent
{
	uint8_t Pad_0x178[0x28]; // 0x178(0x28)
};

// Object: Class PhotonDestructible.PhotonDestructibleTexturePool
// Size: 0x198 (Inherited: 0x178)
struct UPhotonDestructibleTexturePool : UActorComponent
{
	uint8_t Pad_0x178[0x20]; // 0x178(0x20)
};

