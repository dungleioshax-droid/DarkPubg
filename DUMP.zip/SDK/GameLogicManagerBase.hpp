#pragma once

#include <cstdint>

// Object: BlueprintGeneratedClass GameLogicManagerBase.GameLogicManagerBase_C
// Size: 0x180 (Inherited: 0x180)
struct UGameLogicManagerBase_C : UGameBusinessManager
{
};

