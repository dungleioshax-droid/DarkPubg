#pragma once

#include <cstdint>

// Object: Enum PhysXVehicles.EWheelSweepType
enum class EWheelSweepType : uint8_t
{
	SimpleAndComplex = 0,
	Simple = 1,
	Complex = 2,
	EWheelSweepType_MAX = 3
};

// Object: Enum PhysXVehicles.EVehicleDifferential4W
enum class EVehicleDifferential4W : uint8_t
{
	LimitedSlip_4W = 0,
	LimitedSlip_FrontDrive = 1,
	LimitedSlip_RearDrive = 2,
	Open_4W = 3,
	Open_FrontDrive = 4,
	Open_RearDrive = 5,
	EVehicleDifferential4W_MAX = 6
};

// Object: ScriptStruct PhysXVehicles.AnimNode_WheelHandler
// Size: 0x90 (Inherited: 0x78)
struct FAnimNode_WheelHandler : FAnimNode_SkeletalControlBase
{
	uint8_t Pad_0x78[0x18]; // 0x78(0x18)
};

// Object: ScriptStruct PhysXVehicles.TireConfigMaterialFriction
// Size: 0x10 (Inherited: 0x0)
struct FTireConfigMaterialFriction
{
	struct UPhysicalMaterial* PhysicalMaterial; // 0x0(0x8)
	float FrictionScale; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
};

// Object: ScriptStruct PhysXVehicles.VehicleAnimInstanceProxy
// Size: 0x5E0 (Inherited: 0x5D0)
struct FVehicleAnimInstanceProxy : FAnimInstanceProxy
{
	uint8_t Pad_0x5D0[0x10]; // 0x5D0(0x10)
};

// Object: ScriptStruct PhysXVehicles.VehicleInputRate
// Size: 0x8 (Inherited: 0x0)
struct FVehicleInputRate
{
	float RiseRate; // 0x0(0x4)
	float FallRate; // 0x4(0x4)
};

// Object: ScriptStruct PhysXVehicles.ReplicatedVehicleState
// Size: 0x14 (Inherited: 0x0)
struct FReplicatedVehicleState
{
	float SteeringInput; // 0x0(0x4)
	float ThrottleInput; // 0x4(0x4)
	float BrakeInput; // 0x8(0x4)
	float HandBrakeInput; // 0xC(0x4)
	int CurrentGear; // 0x10(0x4)
};

// Object: ScriptStruct PhysXVehicles.WheelSetup
// Size: 0x20 (Inherited: 0x0)
struct FWheelSetup
{
	struct UVehicleWheel* WheelClass; // 0x0(0x8)
	struct FName BoneName; // 0x8(0x8)
	struct FVector AdditionalOffset; // 0x10(0xC)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
};

// Object: ScriptStruct PhysXVehicles.VehicleTransmissionData
// Size: 0x30 (Inherited: 0x0)
struct FVehicleTransmissionData
{
	bool bUseGearAutoBox; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float GearSwitchTime; // 0x4(0x4)
	float GearAutoBoxLatency; // 0x8(0x4)
	float FinalRatio; // 0xC(0x4)
	struct TArray<struct FVehicleGearData> ForwardGears; // 0x10(0x10)
	float ReverseGearRatio; // 0x20(0x4)
	float NeutralGearUpRatio; // 0x24(0x4)
	float ClutchStrength; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: ScriptStruct PhysXVehicles.VehicleGearData
// Size: 0xC (Inherited: 0x0)
struct FVehicleGearData
{
	float Ratio; // 0x0(0x4)
	float DownRatio; // 0x4(0x4)
	float UpRatio; // 0x8(0x4)
};

// Object: ScriptStruct PhysXVehicles.VehicleEngineData
// Size: 0x90 (Inherited: 0x0)
struct FVehicleEngineData
{
	struct FRuntimeFloatCurve TorqueCurve; // 0x0(0x78)
	float MaxRPM; // 0x78(0x4)
	float MOI; // 0x7C(0x4)
	float DampingRateFullThrottle; // 0x80(0x4)
	float DampingRateZeroThrottleClutchEngaged; // 0x84(0x4)
	float DampingRateZeroThrottleClutchDisengaged; // 0x88(0x4)
	uint8_t Pad_0x8C[0x4]; // 0x8C(0x4)
};

// Object: ScriptStruct PhysXVehicles.VehicleDifferential4WData
// Size: 0x1C (Inherited: 0x0)
struct FVehicleDifferential4WData
{
	enum class EVehicleDifferential4W DifferentialType; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	float FrontRearSplit; // 0x4(0x4)
	float FrontLeftRightSplit; // 0x8(0x4)
	float RearLeftRightSplit; // 0xC(0x4)
	float CentreBias; // 0x10(0x4)
	float FrontBias; // 0x14(0x4)
	float RearBias; // 0x18(0x4)
};

// Object: Class PhysXVehicles.WheeledVehicleMovementComponent
// Size: 0x368 (Inherited: 0x1F8)
struct UWheeledVehicleMovementComponent : UPawnMovementComponent
{
	uint8_t Pad_0x1F8[0x8]; // 0x1F8(0x8)
	uint8_t bDeprecatedSpringOffsetMode : 1; // 0x200(0x1), Mask(0x1)
	uint8_t bRestorePhysicsState : 1; // 0x200(0x1), Mask(0x2)
	uint8_t BitPad_0x200_2 : 6; // 0x200(0x1)
	uint8_t Pad_0x201[0x7]; // 0x201(0x7)
	struct TArray<struct FWheelSetup> WheelSetups; // 0x208(0x10)
	float Mass; // 0x218(0x4)
	float DragCoefficient; // 0x21C(0x4)
	float ChassisWidth; // 0x220(0x4)
	float ChassisHeight; // 0x224(0x4)
	bool bReverseAsBrake; // 0x228(0x1)
	bool bClientSuspensionSweep; // 0x229(0x1)
	bool bServerSuspensionSweep; // 0x22A(0x1)
	uint8_t Pad_0x22B[0x1]; // 0x22B(0x1)
	float DragArea; // 0x22C(0x4)
	float EstimatedMaxEngineSpeed; // 0x230(0x4)
	float MaxEngineRPM; // 0x234(0x4)
	float DebugDragMagnitude; // 0x238(0x4)
	struct FVector InertiaTensorScale; // 0x23C(0xC)
	float MinNormalizedTireLoad; // 0x248(0x4)
	float MinNormalizedTireLoadFiltered; // 0x24C(0x4)
	float MaxNormalizedTireLoad; // 0x250(0x4)
	float MaxNormalizedTireLoadFiltered; // 0x254(0x4)
	float ThresholdLongitudinalSpeed; // 0x258(0x4)
	int LowForwardSpeedSubStepCount; // 0x25C(0x4)
	int HighForwardSpeedSubStepCount; // 0x260(0x4)
	uint8_t Pad_0x264[0x4]; // 0x264(0x4)
	struct TArray<struct UVehicleWheel*> Wheels; // 0x268(0x10)
	uint8_t Pad_0x278[0x18]; // 0x278(0x18)
	uint8_t bUseRVOAvoidance : 1; // 0x290(0x1), Mask(0x1)
	uint8_t BitPad_0x290_1 : 7; // 0x290(0x1)
	uint8_t Pad_0x291[0x3]; // 0x291(0x3)
	float RVOAvoidanceRadius; // 0x294(0x4)
	float RVOAvoidanceHeight; // 0x298(0x4)
	float AvoidanceConsiderationRadius; // 0x29C(0x4)
	float RVOSteeringStep; // 0x2A0(0x4)
	float RVOThrottleStep; // 0x2A4(0x4)
	int AvoidanceUID; // 0x2A8(0x4)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x2AC(0x4)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x2B0(0x4)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x2B4(0x4)
	float AvoidanceWeight; // 0x2B8(0x4)
	struct FVector PendingLaunchVelocity; // 0x2BC(0xC)
	uint8_t Pad_0x2C8[0x10]; // 0x2C8(0x10)
	struct FReplicatedVehicleState ReplicatedState; // 0x2D8(0x14)
	uint8_t Pad_0x2EC[0x4]; // 0x2EC(0x4)
	float RawSteeringInput; // 0x2F0(0x4)
	float RawThrottleInput; // 0x2F4(0x4)
	float RawBrakeInput; // 0x2F8(0x4)
	uint8_t bRawHandbrakeInput : 1; // 0x2FC(0x1), Mask(0x1)
	uint8_t bRawGearUpInput : 1; // 0x2FC(0x1), Mask(0x2)
	uint8_t bRawGearDownInput : 1; // 0x2FC(0x1), Mask(0x4)
	uint8_t BitPad_0x2FC_3 : 5; // 0x2FC(0x1)
	uint8_t Pad_0x2FD[0x3]; // 0x2FD(0x3)
	float SteeringInput; // 0x300(0x4)
	float ThrottleInput; // 0x304(0x4)
	float BrakeInput; // 0x308(0x4)
	float HandBrakeInput; // 0x30C(0x4)
	float IdleBrakeInput; // 0x310(0x4)
	float StopThreshold; // 0x314(0x4)
	float WrongDirectionThreshold; // 0x318(0x4)
	struct FVehicleInputRate ThrottleInputRate; // 0x31C(0x8)
	struct FVehicleInputRate BrakeInputRate; // 0x324(0x8)
	struct FVehicleInputRate HandbrakeInputRate; // 0x32C(0x8)
	struct FVehicleInputRate SteeringInputRate; // 0x334(0x8)
	uint8_t bWasAvoidanceUpdated : 1; // 0x33C(0x1), Mask(0x1)
	uint8_t BitPad_0x33C_1 : 7; // 0x33C(0x1)
	uint8_t Pad_0x33D[0x2B]; // 0x33D(0x2B)


	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetUseAutoGears
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4f14
	// Params: [ Num(1) Size(0x1) ]
	void SetUseAutoGears(bool bUseAuto);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetThrottleInput
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4e90
	// Params: [ Num(1) Size(0x4) ]
	void SetThrottleInput(float Throttle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetTargetGear
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4dcc
	// Params: [ Num(2) Size(0x5) ]
	void SetTargetGear(int GearNum, bool bImmediate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetSteeringInput
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4d48
	// Params: [ Num(1) Size(0x4) ]
	void SetSteeringInput(float Steering);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetPhysActive
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4cbc
	// Params: [ Num(1) Size(0x1) ]
	void SetPhysActive(bool bActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetHandbrakeInput
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4c30
	// Params: [ Num(1) Size(0x1) ]
	void SetHandbrakeInput(bool bNewHandbrake);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnoreMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025c4ba8
	// Params: [ Num(1) Size(0x4) ]
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask& GroupMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC6A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnore
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4b2c
	// Params: [ Num(1) Size(0x4) ]
	void SetGroupsToIgnore(int GroupFlags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC69C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC6A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoidMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025c4aa4
	// Params: [ Num(1) Size(0x4) ]
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask& GroupMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC690
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC69C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025BC6A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4a28
	// Params: [ Num(1) Size(0x4) ]
	void SetGroupsToAvoid(int GroupFlags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC688
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC690
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025BC69C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1025BC6A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c49a4
	// Params: [ Num(1) Size(0x1) ]
	void SetGearUp(bool bNewGearUp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BAEFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC688
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025BC690
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1025BC69C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4920
	// Params: [ Num(1) Size(0x1) ]
	void SetGearDown(bool bNewGearDown);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BAF1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BAEFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025BC688
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1025BC690
	// [Call #13] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetBrakeInput
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c489c
	// Params: [ Num(1) Size(0x4) ]
	void SetBrakeInput(float Brake);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025BAF1C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025BAEFC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025BC688
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroupMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025c4814
	// Params: [ Num(1) Size(0x4) ]
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask& GroupMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC67C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025BAF1C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025BAEFC
	// [Call #12] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4798
	// Params: [ Num(1) Size(0x4) ]
	void SetAvoidanceGroup(int GroupFlags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC674
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC67C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025BAF1C
	// [Call #12] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4714
	// Params: [ Num(1) Size(0x1) ]
	void SetAvoidanceEnabled(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC6B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025BC674
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025BC67C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.ServerUpdateState
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1025c45a4
	// Params: [ Num(5) Size(0x14) ]
	void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandBrakeInput, int CurrentGear);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025BC6B0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.IsSuspensionSweep
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1025c4568
	// Params: [ Num(1) Size(0x1) ]
	bool IsSuspensionSweep();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025BC6B0

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetWheelShapeIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c44c0
	// Params: [ Num(1) Size(0x10) ]
	void GetWheelShapeIndices(struct TArray<int>& OutWheelShapeIndices);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetUseAutoGears
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4484
	// Params: [ Num(1) Size(0x1) ]
	bool GetUseAutoGears();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetThrottleInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4468
	// Params: [ Num(1) Size(0x4) ]
	float GetThrottleInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetTargetGear
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c442c
	// Params: [ Num(1) Size(0x4) ]
	int GetTargetGear();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetSteeringInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4410
	// Params: [ Num(1) Size(0x4) ]
	float GetSteeringInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetHandbrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c43ec
	// Params: [ Num(1) Size(0x1) ]
	bool GetHandbrakeInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetForwardSpeed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c43b0
	// Params: [ Num(1) Size(0x4) ]
	float GetForwardSpeed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineRotationSpeed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4374
	// Params: [ Num(1) Size(0x4) ]
	float GetEngineRotationSpeed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10207FA04
	// [Call #4] RVA: 0x101F8BA44
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x106C8459C

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineMaxRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4340
	// Params: [ Num(1) Size(0x4) ]
	float GetEngineMaxRotationSpeed();
	// [Call #1] RVA: 0x1025BB100
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10207FA04
	// [Call #5] RVA: 0x101F8BA44
	// [Call #6] RVA: 0x101F8BA44
	// [Call #7] RVA: 0x106C8459C

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetCurrentGear
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c4304
	// Params: [ Num(1) Size(0x4) ]
	int GetCurrentGear();
	// [Call #1] RVA: 0x1025BB100
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10207FA04
	// [Call #5] RVA: 0x101F8BA44

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetBrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c42e8
	// Params: [ Num(1) Size(0x4) ]
	float GetBrakeInput();
	// [Call #1] RVA: 0x1025BB100
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10207FA04

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.EnableVehicleWheel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c422c
	// Params: [ Num(2) Size(0x5) ]
	void EnableVehicleWheel(int WheelIndex, bool InEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025BC884
	// [Call #6] RVA: 0x1025BB100

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.EnableVehicleSimulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c41a8
	// Params: [ Num(1) Size(0x1) ]
	void EnableVehicleSimulation(bool InEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC824
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025BC884
	// [Call #9] RVA: 0x1025BB100

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.ClearAllInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c4194
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllInput();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025BC824
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025BC884
	// [Call #9] RVA: 0x1025BB100
};

// Object: Class PhysXVehicles.SimpleWheeledVehicleMovementComponent
// Size: 0x368 (Inherited: 0x368)
struct USimpleWheeledVehicleMovementComponent : UWheeledVehicleMovementComponent
{

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c32b0
	// Params: [ Num(2) Size(0x8) ]
	void SetSteerAngle(float SteerAngle, int WheelIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025B6B0C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetDriveTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c31f8
	// Params: [ Num(2) Size(0x8) ]
	void SetDriveTorque(float DriveTorque, int WheelIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025B6A08
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025B6B0C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetBrakeTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c3140
	// Params: [ Num(2) Size(0x8) ]
	void SetBrakeTorque(float BrakeTorque, int WheelIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025B6904
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025B6A08
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1025B6B0C
};

// Object: Class PhysXVehicles.TireConfig
// Size: 0x50 (Inherited: 0x30)
struct UTireConfig : UDataAsset
{
	float FrictionScale; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // 0x38(0x10)
	uint8_t Pad_0x48[0x8]; // 0x48(0x8)
};

// Object: Class PhysXVehicles.VehicleAnimInstance
// Size: 0x9F0 (Inherited: 0x3F0)
struct UVehicleAnimInstance : UAnimInstance
{
	uint8_t Pad_0x3F0[0x8]; // 0x3F0(0x8)
	float fWheelRotationSpeedPitch; // 0x3F8(0x4)
	float fWheelRotationSpeedYaw; // 0x3FC(0x4)
	uint8_t Pad_0x400[0x5E0]; // 0x400(0x5E0)
	struct UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // 0x9E0(0x8)
	uint8_t Pad_0x9E8[0x8]; // 0x9E8(0x8)


	// Object: Function PhysXVehicles.VehicleAnimInstance.GetVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025c3828
	// Params: [ Num(1) Size(0x8) ]
	struct AWheeledVehicle* GetVehicle();
	// [Call #1] RVA: 0x1025B6FFC
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x1025C30A8
	// [Call #6] RVA: 0x105185230
	// [Call #7] RVA: 0x1051903D0
	// [Call #8] RVA: 0x1025C3D24
	// [Call #9] RVA: 0x1025B779C
};

// Object: Class PhysXVehicles.VehicleWheel
// Size: 0xF0 (Inherited: 0x28)
struct UVehicleWheel : UObject
{
	struct UStaticMesh* CollisionMesh; // 0x28(0x8)
	bool bDontCreateShape; // 0x30(0x1)
	bool bAutoAdjustCollisionSize; // 0x31(0x1)
	uint8_t Pad_0x32[0x2]; // 0x32(0x2)
	struct FVector Offset; // 0x34(0xC)
	float ShapeRadius; // 0x40(0x4)
	float ShapeWidth; // 0x44(0x4)
	float Mass; // 0x48(0x4)
	float DampingRate; // 0x4C(0x4)
	float SteerAngle; // 0x50(0x4)
	bool bAffectedByHandbrake; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
	struct UTireType* TireType; // 0x58(0x8)
	struct UTireConfig* TireConfig; // 0x60(0x8)
	float LatStiffMaxLoad; // 0x68(0x4)
	float LatStiffValue; // 0x6C(0x4)
	float LongStiffValue; // 0x70(0x4)
	float SuspensionForceOffset; // 0x74(0x4)
	float SuspensionMaxRaise; // 0x78(0x4)
	float SuspensionMaxDrop; // 0x7C(0x4)
	float SuspensionNaturalFrequency; // 0x80(0x4)
	float SuspensionDampingRatio; // 0x84(0x4)
	enum class EWheelSweepType SweepType; // 0x88(0x1)
	uint8_t Pad_0x89[0x3]; // 0x89(0x3)
	float MaxBrakeTorque; // 0x8C(0x4)
	float MaxHandBrakeTorque; // 0x90(0x4)
	uint8_t Pad_0x94[0x4]; // 0x94(0x4)
	struct UWheeledVehicleMovementComponent* VehicleSim; // 0x98(0x8)
	int WheelIndex; // 0xA0(0x4)
	float DebugLongSlip; // 0xA4(0x4)
	float DebugLatSlip; // 0xA8(0x4)
	float DebugNormalizedTireLoad; // 0xAC(0x4)
	uint8_t Pad_0xB0[0x4]; // 0xB0(0x4)
	float DebugWheelTorque; // 0xB4(0x4)
	float DebugLongForce; // 0xB8(0x4)
	float DebugLatForce; // 0xBC(0x4)
	struct FVector Location; // 0xC0(0xC)
	struct FVector OldLocation; // 0xCC(0xC)
	struct FVector Velocity; // 0xD8(0xC)
	uint8_t Pad_0xE4[0xC]; // 0xE4(0xC)


	// Object: Function PhysXVehicles.VehicleWheel.IsInAir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c3b24
	// Params: [ Num(1) Size(0x1) ]
	bool IsInAir();
	// [Call #1] RVA: 0x1025B76D0
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PhysXVehicles.VehicleWheel.GetSuspensionOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c3af0
	// Params: [ Num(1) Size(0x4) ]
	float GetSuspensionOffset();
	// [Call #1] RVA: 0x1025B74D4
	// [Call #2] RVA: 0x1025B76D0
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function PhysXVehicles.VehicleWheel.GetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c3abc
	// Params: [ Num(1) Size(0x4) ]
	float GetSteerAngle();
	// [Call #1] RVA: 0x1025B73F4
	// [Call #2] RVA: 0x1025B74D4
	// [Call #3] RVA: 0x1025B76D0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function PhysXVehicles.VehicleWheel.GetRotationAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c3a88
	// Params: [ Num(1) Size(0x4) ]
	float GetRotationAngle();
	// [Call #1] RVA: 0x1025B733C
	// [Call #2] RVA: 0x1025B73F4
	// [Call #3] RVA: 0x1025B74D4
	// [Call #4] RVA: 0x1025B76D0
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PhysXVehicles.VehicleWheel.GetContactNormal
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025c3a50
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetContactNormal();
	// [Call #1] RVA: 0x1025B779C
	// [Call #2] RVA: 0x1025B733C
	// [Call #3] RVA: 0x1025B73F4
	// [Call #4] RVA: 0x1025B74D4
	// [Call #5] RVA: 0x1025B76D0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

// Object: Class PhysXVehicles.WheeledVehicle
// Size: 0x520 (Inherited: 0x510)
struct AWheeledVehicle : APawn
{
	struct USkeletalMeshComponent* Mesh; // 0x510(0x8)
	struct UWheeledVehicleMovementComponent* VehicleMovement; // 0x518(0x8)
};

// Object: Class PhysXVehicles.WheeledVehicleMovementComponent4W
// Size: 0x4C8 (Inherited: 0x368)
struct UWheeledVehicleMovementComponent4W : UWheeledVehicleMovementComponent
{
	struct FVehicleEngineData EngineSetup; // 0x368(0x90)
	struct FVehicleDifferential4WData DifferentialSetup; // 0x3F8(0x1C)
	uint8_t Pad_0x414[0x4]; // 0x414(0x4)
	struct FVehicleTransmissionData TransmissionSetup; // 0x418(0x30)
	struct FRuntimeFloatCurve SteeringCurve; // 0x448(0x78)
	float AckermannAccuracy; // 0x4C0(0x4)
	uint8_t Pad_0x4C4[0x4]; // 0x4C4(0x4)
};

