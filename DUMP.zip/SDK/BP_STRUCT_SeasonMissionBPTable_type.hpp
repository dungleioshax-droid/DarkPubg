#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_SeasonMissionBPTable_type.BP_STRUCT_SeasonMissionBPTable_type
// Size: 0x38 (Inherited: 0x0)
struct FBP_STRUCT_SeasonMissionBPTable_type
{
	struct FString CName_0_3B02C7C021A8868F32F1BA220D295515; // 0x0(0x10)
	int ID_1_73B51A0066811C521281291A0132D224; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString Path_2_746EFA0071EA42DC1C74470F02D39998; // 0x18(0x10)
	struct FString Wrapper_3_324A4F00599DC022161C6E8C019B5BF2; // 0x28(0x10)
};

