#pragma once

#include <cstdint>

// Object: Enum OodleNetworkHandlerComponent.EOodleNetworkEnableMode
enum class EOodleNetworkEnableMode : uint8_t
{
	AlwaysEnabled = 0,
	WhenCompressedPacketReceived = 1,
	EOodleNetworkEnableMode_MAX = 2
};

// Object: Class OodleNetworkHandlerComponent.OodleNetworkTrainerCommandlet
// Size: 0x98 (Inherited: 0x80)
struct UOodleNetworkTrainerCommandlet : UCommandlet
{
	bool bCompressionTest; // 0x79(0x1)
	bool bWriteV5Dictionaries; // 0x7A(0x1)
	int HashTableSize; // 0x7C(0x4)
	int DictionarySize; // 0x80(0x4)
	int DictionaryTrials; // 0x84(0x4)
	int TrialRandomness; // 0x88(0x4)
	int TrialGenerations; // 0x8C(0x4)
	bool bNoTrials; // 0x90(0x1)
	uint8_t Pad_0x97[0x1]; // 0x97(0x1)
};

