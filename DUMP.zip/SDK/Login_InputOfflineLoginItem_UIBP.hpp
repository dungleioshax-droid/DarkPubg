#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Login_InputOfflineLoginItem_UIBP.Login_InputOfflineLoginItem_UIBP_C
// Size: 0x2E0 (Inherited: 0x2C8)
struct ULogin_InputOfflineLoginItem_UIBP_C : UCommonSearchBox
{
	struct UEditableTextBox* Input_Password; // 0x2C8(0x8)
	struct UEditableTextBox* Input_Username; // 0x2D0(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_Image; // 0x2D8(0x8)
};

