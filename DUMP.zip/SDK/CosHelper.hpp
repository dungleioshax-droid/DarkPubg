#pragma once

#include <cstdint>

// Object: Enum CosHelper.ECosHelperFileInfoType
enum class ECosHelperFileInfoType : uint8_t
{
	None = 0,
	ContentLength = 1,
	ETag = 2,
	LastModifiedUtcTimestamp = 4,
	ECosHelperFileInfoType_MAX = 5
};

// Object: ScriptStruct CosHelper.CosHelperInitializeInfo
// Size: 0x58 (Inherited: 0x0)
struct FCosHelperInitializeInfo
{
	bool bUseAuthorization; // 0x0(0x1)
	uint8_t Pad_0x1[0x3]; // 0x1(0x3)
	int SignExpirationTime; // 0x4(0x4)
	struct FString AppID; // 0x8(0x10)
	struct FString BucketName; // 0x18(0x10)
	struct FString Region; // 0x28(0x10)
	struct FString SecretId; // 0x38(0x10)
	struct FString SecretKey; // 0x48(0x10)
};

// Object: Class CosHelper.CosBase
// Size: 0x28 (Inherited: 0x28)
struct UCosBase : UObject
{

	// Object: Function CosHelper.CosBase.GetContent
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102768c94
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> GetContent();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519077C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870
};

// Object: Class CosHelper.CosHelper
// Size: 0x110 (Inherited: 0x28)
struct UCosHelper : UObject
{
	uint8_t Pad_0x28[0xE8]; // 0x28(0xE8)
};

// Object: Class CosHelper.CosHelperBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCosHelperBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function CosHelper.CosHelperBlueprintLibrary.UploadFileMemory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10276970c
	// Params: [ Num(6) Size(0x50) ]
	struct UCosRequest* UploadFileMemory(struct UCosHelper* CosHelper, struct TArray<uint8_t>& FileMemoryBuffer, struct FString URIPathName, struct FString URLParameters, DelegateProperty OnCosRequestCompleted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102764AC4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8BA74
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10519022C

	// Object: Function CosHelper.CosHelperBlueprintLibrary.UploadFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10276953c
	// Params: [ Num(6) Size(0x50) ]
	struct UCosRequest* UploadFile(struct UCosHelper* CosHelper, struct FString FilePathName, struct FString URIPathName, struct FString URLParameters, DelegateProperty OnCosRequestCompleted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1027649D8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function CosHelper.CosHelperBlueprintLibrary.InitCosInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10276947c
	// Params: [ Num(2) Size(0x68) ]
	struct FCosHelperInitializeInfo InitCosInfo(struct FString Section);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027644C8
	// [Call #4] RVA: 0x10276A5FC
	// [Call #5] RVA: 0x1027651A0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x1027651A0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x1027649D8
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function CosHelper.CosHelperBlueprintLibrary.GetFileInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027692c0
	// Params: [ Num(6) Size(0x48) ]
	struct UCosRequest* GetFileInfo(struct UCosHelper* CosHelper, struct FString URIPathName, struct FString URLParameters, int FileInfoType, DelegateProperty OnCosRequestCompleted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102764800
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1027644C8
	// [Call #21] RVA: 0x10276A5FC
	// [Call #22] RVA: 0x1027651A0
	// [Call #23] RVA: 0x101F8130C

	// Object: Function CosHelper.CosHelperBlueprintLibrary.DownloadFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1027690f0
	// Params: [ Num(6) Size(0x50) ]
	struct UCosRequest* DownloadFile(struct UCosHelper* CosHelper, struct FString URIPathName, struct FString URLParameters, struct FString SavedPathName, DelegateProperty OnCosRequestCompleted);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101FD9E48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1027648EC
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function CosHelper.CosHelperBlueprintLibrary.DestroyCosHelper
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10276907c
	// Params: [ Num(1) Size(0x8) ]
	void DestroyCosHelper(struct UCosHelper* CosHelper);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027647C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101FD9E48
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1027648EC
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function CosHelper.CosHelperBlueprintLibrary.ConstructCosHelper
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102768fb8
	// Params: [ Num(2) Size(0x60) ]
	struct UCosHelper* ConstructCosHelper(struct FCosHelperInitializeInfo& InitializeInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102764714
	// [Call #4] RVA: 0x1027651A0
	// [Call #5] RVA: 0x1027651A0
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027647C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48
	// [Call #19] RVA: 0x10516D168
};

// Object: Class CosHelper.CosRequest
// Size: 0x38 (Inherited: 0x28)
struct UCosRequest : UCosBase
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
};

// Object: Class CosHelper.CosResponse
// Size: 0x90 (Inherited: 0x28)
struct UCosResponse : UCosBase
{
	uint8_t Pad_0x28[0x68]; // 0x28(0x68)


	// Object: Function CosHelper.CosResponse.IsOK
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102769ffc
	// Params: [ Num(1) Size(0x1) ]
	bool IsOK();
	// [Call #1] RVA: 0x102764E04
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function CosHelper.CosResponse.GetResponseCode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102769fc8
	// Params: [ Num(1) Size(0x4) ]
	int GetResponseCode();
	// [Call #1] RVA: 0x102764E4C
	// [Call #2] RVA: 0x102764E04
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function CosHelper.CosResponse.GetRequestURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102769f64
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetRequestURL();
	// [Call #1] RVA: 0x102764FDC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x102764E4C
	// [Call #7] RVA: 0x102764E04
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function CosHelper.CosResponse.GetFileInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102769eb0
	// Params: [ Num(2) Size(0x18) ]
	struct FString GetFileInfo(uint8_t InFileInfoType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102764E68
	// [Call #4] RVA: 0x101F8156C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x102764FDC
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102764E4C
	// [Call #14] RVA: 0x102764E04
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function CosHelper.CosResponse.GetContentAsString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102769e4c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetContentAsString();
	// [Call #1] RVA: 0x102764DE8
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102764E68
	// [Call #9] RVA: 0x101F8156C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x102764FDC
	// [Call #14] RVA: 0x101F8156C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x102764E4C
	// [Call #19] RVA: 0x102764E04
	// [Call #20] RVA: 0x10519022C
};

