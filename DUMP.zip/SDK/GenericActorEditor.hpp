#pragma once

#include <cstdint>

// Object: ScriptStruct GenericActorEditor.ActorEditorCharacterMovementSyncData
// Size: 0x50 (Inherited: 0x0)
struct FActorEditorCharacterMovementSyncData
{
	float MaxAcceleration; // 0x0(0x4)
	float BrakingFriction; // 0x4(0x4)
	float MaxWalkSpeed; // 0x8(0x4)
	float MaxWalkSpeedCrouched; // 0xC(0x4)
	float MaxSwimSpeed; // 0x10(0x4)
	float MaxFlySpeed; // 0x14(0x4)
	float MaxCustomMovementSpeed; // 0x18(0x4)
	float JumpZVelocity; // 0x1C(0x4)
	float GravityScale; // 0x20(0x4)
	float AirControl; // 0x24(0x4)
	float FallingLateralFriction; // 0x28(0x4)
	float BrakingDecelerationWalking; // 0x2C(0x4)
	float BrakingDecelerationFalling; // 0x30(0x4)
	float BrakingDecelerationFlying; // 0x34(0x4)
	float BrakingDecelerationSwimming; // 0x38(0x4)
	float GroundFriction; // 0x3C(0x4)
	bool bOrientRotationToMovement; // 0x40(0x1)
	bool bUseControllerDesiredRotation; // 0x41(0x1)
	uint8_t Pad_0x42[0x2]; // 0x42(0x2)
	struct FRotator RotationRate; // 0x44(0xC)
};

// Object: Class GenericActorEditor.ActorEditorActorComponent
// Size: 0x230 (Inherited: 0x178)
struct UActorEditorActorComponent : UActorComponent
{
	uint8_t Pad_0x178[0x58]; // 0x178(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x1D0(0x50)
	struct FString LuaFilePath; // 0x220(0x10)
};

// Object: Class GenericActorEditor.ActorEditorAnimInstanceBase
// Size: 0x3F0 (Inherited: 0x3F0)
struct UActorEditorAnimInstanceBase : UAnimInstance
{

	// Object: Function GenericActorEditor.ActorEditorAnimInstanceBase.ClearAnimReferences
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022d121c
	// Params: [ Num(0) Size(0x0) ]
	void ClearAnimReferences();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class GenericActorEditor.ActorEditorBoxComponent
// Size: 0xAC0 (Inherited: 0x9F0)
struct UActorEditorBoxComponent : UBoxComponent
{
	uint8_t Pad_0x9F0[0x68]; // 0x9F0(0x68)
	struct FLuaNetSerialization LuaNetSerialization; // 0xA58(0x50)
	struct FString LuaFilePath; // 0xAA8(0x10)
	uint8_t Pad_0xAB8[0x8]; // 0xAB8(0x8)
};

// Object: Class GenericActorEditor.ActorEditorCameraComponent
// Size: 0xA60 (Inherited: 0x9A0)
struct UActorEditorCameraComponent : UCameraComponent
{
	uint8_t Pad_0x9A0[0x60]; // 0x9A0(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0xA00(0x50)
	struct FString LuaFilePath; // 0xA50(0x10)
};

// Object: Class GenericActorEditor.ActorEditorCapsuleComponent
// Size: 0xAD0 (Inherited: 0xA10)
struct UActorEditorCapsuleComponent : UCapsuleComponent
{
	uint8_t Pad_0xA10[0x60]; // 0xA10(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0xA70(0x50)
	struct FString LuaFilePath; // 0xAC0(0x10)
};

// Object: Class GenericActorEditor.ActorEditorCharacter
// Size: 0x9A0 (Inherited: 0x9A0)
struct AActorEditorCharacter : ALuaCharacter
{
};

// Object: Class GenericActorEditor.ActorEditorCharacterMovementComponent
// Size: 0x910 (Inherited: 0x810)
struct UActorEditorCharacterMovementComponent : UCharacterMovementComponent
{
	uint8_t Pad_0x810[0x50]; // 0x810(0x50)
	struct FLuaNetSerialization LuaNetSerialization; // 0x860(0x50)
	struct FActorEditorCharacterMovementSyncData CharacterMovementSyncData; // 0x8B0(0x50)
	struct FString LuaFilePath; // 0x900(0x10)


	// Object: Function GenericActorEditor.ActorEditorCharacterMovementComponent.OnRep_CharacterMovementSyncData
	// Flags: [Final|Native|Protected]
	// Offset: 0x1022d1888
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_CharacterMovementSyncData();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x1022D2C98
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CEFF4
};

// Object: Class GenericActorEditor.ActorEditorComponentBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UActorEditorComponentBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.UnregisterComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d2674
	// Params: [ Num(1) Size(0x8) ]
	void UnregisterComponent(struct UActorComponent* InComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEEFC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetWidgetOpacityFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d25c4
	// Params: [ Num(2) Size(0xC) ]
	void SetWidgetOpacityFromTexture(struct UWidgetComponent* InComp, float Opacity);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEF30
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022CEEFC
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetWidgetDrawAtDesiredSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d250c
	// Params: [ Num(2) Size(0x9) ]
	void SetWidgetDrawAtDesiredSize(struct UWidgetComponent* InComp, bool bDrawAtDesiredSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEF24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEF30
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022CEEFC
	// [Call #14] RVA: 0x10519022C

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetParticleSystemAutoDestroy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d2454
	// Params: [ Num(2) Size(0x9) ]
	void SetParticleSystemAutoDestroy(struct UParticleSystemComponent* InComp, bool bAutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEE78
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEF24
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEF30
	// [Call #16] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetMobility
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d23a4
	// Params: [ Num(2) Size(0x9) ]
	void SetMobility(struct USceneComponent* InSceneComp, enum class EComponentMobility NewMobility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEE54
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEE78
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEF24
	// [Call #16] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetComponentAutoActivate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d22ec
	// Params: [ Num(2) Size(0x9) ]
	void SetComponentAutoActivate(struct UActorComponent* InComponent, bool bAutoActivate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CF1B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEE54
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEE78
	// [Call #16] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.SetActorRootComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d2238
	// Params: [ Num(3) Size(0x11) ]
	bool SetActorRootComponent(struct AActor* InActor, struct USceneComponent* NewRootComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEFE8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CF1B8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEE54
	// [Call #16] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.ReregisterComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d21c4
	// Params: [ Num(1) Size(0x8) ]
	void ReregisterComponent(struct UActorComponent* InComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEF10
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022CEFE8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1022CF1B8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.RegisterComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d2150
	// Params: [ Num(1) Size(0x8) ]
	void RegisterComponent(struct UActorComponent* InComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEEE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022CEF10
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1022CEFE8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1022CF1B8

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.IsSimulatingPhysics
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d20d4
	// Params: [ Num(2) Size(0x9) ]
	bool IsSimulatingPhysics(struct UPrimitiveComponent* InComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEFC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022CEEE8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CEF10
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1022CEFE8
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.IsComponentRegistered
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d2058
	// Params: [ Num(2) Size(0x9) ]
	bool IsComponentRegistered(struct UActorComponent* InComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEED8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022CEFC4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CEEE8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022CEF10
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetParticleSystemAutoDestroy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d1fdc
	// Params: [ Num(2) Size(0x9) ]
	bool GetParticleSystemAutoDestroy(struct UParticleSystemComponent* InComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEE68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1022CEED8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CEFC4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022CEEE8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEF10

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetFloatParameter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d1f28
	// Params: [ Num(3) Size(0x14) ]
	float GetFloatParameter(struct UParticleSystemComponent* InComp, struct FName InName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEE9C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022CEE68
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1022CEED8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1022CEFC4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetComponentBounds
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022d1dd0
	// Params: [ Num(4) Size(0x24) ]
	void GetComponentBounds(struct USceneComponent* InSceneComp, struct FVector& Origin, struct FVector& BoxExtent, float& SphereRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CEE20
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1022CEE9C
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetCollisionTraceFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d1d54
	// Params: [ Num(2) Size(0x9) ]
	enum class ECollisionTraceFlag GetCollisionTraceFlag(struct UPrimitiveComponent* InComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEF8C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1022CEE20
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetBoneTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1022d1c28
	// Params: [ Num(4) Size(0x70) ]
	struct FTransform GetBoneTransform(struct USkinnedMeshComponent* InComp, int BoneIdx, struct FTransform& LocalToWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022CEF68
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEF8C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetBoneLocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022d1b34
	// Params: [ Num(4) Size(0x20) ]
	struct FVector GetBoneLocation(struct USkinnedMeshComponent* InComp, struct FName BoneName, enum class EBoneSpaces Space);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1022CEF3C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1022CEF68
	// [Call #15] RVA: 0x10516D168

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.GetActorRootComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1022d1ab8
	// Params: [ Num(2) Size(0x10) ]
	struct USceneComponent* GetActorRootComponent(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CEFDC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1022CEF3C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GenericActorEditor.ActorEditorComponentBlueprintLibrary.ChangeRootComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1022d1a04
	// Params: [ Num(3) Size(0x11) ]
	bool ChangeRootComponent(struct AActor* InActor, struct USceneComponent* NewRootComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1022CEFF4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1022CEFDC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1022CEF3C
	// [Call #16] RVA: 0x10516D168
};

// Object: Class GenericActorEditor.ActorEditorDecoratorActor
// Size: 0x660 (Inherited: 0x660)
struct AActorEditorDecoratorActor : ADecoratorActor
{
};

// Object: Class GenericActorEditor.ActorEditorDisableTransformReplicationInterface
// Size: 0x28 (Inherited: 0x28)
struct IActorEditorDisableTransformReplicationInterface : IInterface
{

	// Object: Function GenericActorEditor.ActorEditorDisableTransformReplicationInterface.SetDisableTransformReplication
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022d2e74
	// Params: [ Num(1) Size(0x1) ]
	void SetDisableTransformReplication(bool bInDisable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105190870
};

// Object: Class GenericActorEditor.ActorEditorMovementComponent
// Size: 0x270 (Inherited: 0x1B8)
struct UActorEditorMovementComponent : UMovementComponent
{
	uint8_t Pad_0x1B8[0x58]; // 0x1B8(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x210(0x50)
	struct FString LuaFilePath; // 0x260(0x10)
};

// Object: Class GenericActorEditor.ActorEditorParticleSystemComponent
// Size: 0xDD0 (Inherited: 0xD00)
struct UActorEditorParticleSystemComponent : UParticleSystemComponent
{
	uint8_t Pad_0xD00[0x68]; // 0xD00(0x68)
	struct FLuaNetSerialization LuaNetSerialization; // 0xD68(0x50)
	struct FString LuaFilePath; // 0xDB8(0x10)
	uint8_t Pad_0xDC8[0x8]; // 0xDC8(0x8)


	// Object: Function GenericActorEditor.ActorEditorParticleSystemComponent.GetEmitterInstanceNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022d3170
	// Params: [ Num(1) Size(0x4) ]
	int GetEmitterInstanceNum();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
};

// Object: Class GenericActorEditor.ActorEditorPawn
// Size: 0x5C8 (Inherited: 0x5C8)
struct AActorEditorPawn : ALuaPawn
{
};

// Object: Class GenericActorEditor.ActorEditorSceneComponent
// Size: 0x460 (Inherited: 0x3A0)
struct UActorEditorSceneComponent : USceneComponent
{
	uint8_t Pad_0x3A0[0x58]; // 0x3A0(0x58)
	struct FLuaNetSerialization LuaNetSerialization; // 0x3F8(0x50)
	struct FString LuaFilePath; // 0x448(0x10)
	uint8_t Pad_0x458[0x8]; // 0x458(0x8)
};

// Object: Class GenericActorEditor.ActorEditorSkeletalMeshComponent
// Size: 0x1410 (Inherited: 0x1350)
struct UActorEditorSkeletalMeshComponent : USkeletalMeshComponent
{
	uint8_t Pad_0x1350[0x60]; // 0x1350(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0x13B0(0x50)
	struct FString LuaFilePath; // 0x1400(0x10)


	// Object: Function GenericActorEditor.ActorEditorSkeletalMeshComponent.SetSkeletalModelPreset
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022d3590
	// Params: [ Num(1) Size(0x10) ]
	void SetSkeletalModelPreset(struct FString ModePresetIDStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C

	// Object: Function GenericActorEditor.ActorEditorSkeletalMeshComponent.PlaySkeletalAnimationPreset
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1022d34f0
	// Params: [ Num(1) Size(0x10) ]
	void PlaySkeletalAnimationPreset(struct FString AnimationPresetIDStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C
};

// Object: Class GenericActorEditor.ActorEditorSphereComponent
// Size: 0xAB0 (Inherited: 0x9F0)
struct UActorEditorSphereComponent : USphereComponent
{
	uint8_t Pad_0x9F0[0x60]; // 0x9F0(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0xA50(0x50)
	struct FString LuaFilePath; // 0xAA0(0x10)
};

// Object: Class GenericActorEditor.ActorEditorSplineComponent
// Size: 0xB80 (Inherited: 0xAB0)
struct UActorEditorSplineComponent : USplineComponent
{
	uint8_t Pad_0xAB0[0x68]; // 0xAB0(0x68)
	struct FLuaNetSerialization LuaNetSerialization; // 0xB18(0x50)
	struct FString LuaFilePath; // 0xB68(0x10)
	uint8_t Pad_0xB78[0x8]; // 0xB78(0x8)
};

// Object: Class GenericActorEditor.ActorEditorSpringArmComponent
// Size: 0x510 (Inherited: 0x450)
struct UActorEditorSpringArmComponent : USpringArmComponent
{
	uint8_t Pad_0x450[0x60]; // 0x450(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0x4B0(0x50)
	struct FString LuaFilePath; // 0x500(0x10)
};

// Object: Class GenericActorEditor.ActorEditorStaticMeshComponent
// Size: 0xCA0 (Inherited: 0xBD0)
struct UActorEditorStaticMeshComponent : UStaticMeshComponent
{
	uint8_t Pad_0xBD0[0x60]; // 0xBD0(0x60)
	struct FLuaNetSerialization LuaNetSerialization; // 0xC30(0x50)
	struct FString LuaFilePath; // 0xC80(0x10)
	struct FString StaticMeshPath; // 0xC90(0x10)


	// Object: Function GenericActorEditor.ActorEditorStaticMeshComponent.SetStaticMeshPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022d3b78
	// Params: [ Num(2) Size(0x11) ]
	bool SetStaticMeshPath(struct FString InMeshPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CDA78
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10508F76C

	// Object: Function GenericActorEditor.ActorEditorStaticMeshComponent.OnRep_StaticMeshPath
	// Flags: [Final|Native|Private]
	// Offset: 0x1022d3ae0
	// Params: [ Num(1) Size(0x10) ]
	void OnRep_StaticMeshPath(struct FString OldPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1022CDF40
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1022CDA78
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
};

// Object: Class GenericActorEditor.ActorEditorWidgetComponent
// Size: 0xC60 (Inherited: 0xB90)
struct UActorEditorWidgetComponent : UWidgetComponent
{
	uint8_t Pad_0xB90[0x68]; // 0xB90(0x68)
	struct FLuaNetSerialization LuaNetSerialization; // 0xBF8(0x50)
	bool bFaceCamera; // 0xC48(0x1)
	uint8_t Pad_0xC49[0x7]; // 0xC49(0x7)
	struct FString LuaFilePath; // 0xC50(0x10)
};

