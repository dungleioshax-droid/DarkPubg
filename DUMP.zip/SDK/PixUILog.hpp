#pragma once

#include <cstdint>

// Object: Enum PixUILog.EPxLogLevels
enum class EPxLogLevels : uint8_t
{
	Log = 0,
	Warning = 1,
	Error = 2,
	Debug = 3,
	Count = 4,
	EPxLogLevels_MAX = 5
};

// Object: Enum PixUILog.EPxLogGroups
enum class EPxLogGroups : uint8_t
{
	Core = 0,
	Plugin = 1,
	Script = 2,
	Profiler = 3,
	Count = 4,
	EPxLogGroups_MAX = 5
};

// Object: Class PixUILog.PxLogMgr
// Size: 0x38 (Inherited: 0x28)
struct UPxLogMgr : UObject
{
	struct FScriptMulticastDelegate LogDelegate; // 0x28(0x10)


	// Object: Function PixUILog.PxLogMgr.PxLogToggleSwitchLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fea4
	// Params: [ Num(2) Size(0x2) ]
	void PxLogToggleSwitchLevel(uint8_t eLogLevel, bool beOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10293EBDC
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PixUILog.PxLogMgr.PxLogToggleSwitchGroup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fdec
	// Params: [ Num(2) Size(0x2) ]
	void PxLogToggleSwitchGroup(uint8_t eLogGroup, bool beOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10293EBB0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10293EBDC
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function PixUILog.PxLogMgr.PxLogToggleForceLocalOutPut
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fd70
	// Params: [ Num(1) Size(0x1) ]
	void PxLogToggleForceLocalOutPut(bool beOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10293EC08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10293EBB0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10293EBDC
	// [Call #14] RVA: 0x10519022C

	// Object: Function PixUILog.PxLogMgr.PxLogEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fcf4
	// Params: [ Num(1) Size(0x1) ]
	void PxLogEnable(bool beEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10293E42C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10293EC08
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10293EBB0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10293EBDC

	// Object: Function PixUILog.PxLogMgr.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fcc0
	// Params: [ Num(1) Size(0x8) ]
	struct UPxLogMgr* Get();
	// [Call #1] RVA: 0x10293E848
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10293E42C
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10293EC08
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10293EBB0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function PixUILog.PxLogMgr.DispatchLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10293fbb8
	// Params: [ Num(3) Size(0x18) ]
	void DispatchLog(uint8_t eLogGroup, uint8_t eLogLevel, struct FString strLogContent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10293E618
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10293E848
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10293E42C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10293EC08
};

