#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_PetDressBlueprintTable_type.BP_STRUCT_PetDressBlueprintTable_type
// Size: 0x28 (Inherited: 0x0)
struct FBP_STRUCT_PetDressBlueprintTable_type
{
	int Slot_0_31125FC006688BBB2E6646B20FAFCD34; // 0x0(0x4)
	int ID_1_688F3A8033A7814C565560B30E5FAEF4; // 0x4(0x4)
	struct FString Path_2_51589A804E9002622E9485530FAF46F8; // 0x8(0x10)
	struct FString LobbyPath_3_7916988003DE45F8216AD7E90D649918; // 0x18(0x10)
};

