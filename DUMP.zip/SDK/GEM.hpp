#pragma once

#include <cstdint>

// Object: Class GEM.FpsReportActor
// Size: 0x4B0 (Inherited: 0x4B0)
struct AFpsReportActor : AActor
{
};

