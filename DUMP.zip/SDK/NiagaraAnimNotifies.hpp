#pragma once

#include <cstdint>

// Object: Class NiagaraAnimNotifies.AnimNotify_PlayNiagaraEffect
// Size: 0x90 (Inherited: 0x38)
struct UAnimNotify_PlayNiagaraEffect : UAnimNotify
{
	struct UNiagaraSystem* Template; // 0x38(0x8)
	struct FVector LocationOffset; // 0x40(0xC)
	struct FRotator RotationOffset; // 0x4C(0xC)
	struct FVector Scale; // 0x58(0xC)
	uint8_t Pad_0x64[0x1C]; // 0x64(0x1C)
	uint8_t Attached : 1; // 0x80(0x1), Mask(0x1)
	uint8_t BitPad_0x80_1 : 7; // 0x80(0x1)
	uint8_t Pad_0x81[0x7]; // 0x81(0x7)
	struct FName SocketName; // 0x88(0x8)
};

// Object: Class NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffect
// Size: 0x68 (Inherited: 0x30)
struct UAnimNotifyState_TimedNiagaraEffect : UAnimNotifyState
{
	struct UNiagaraSystem* Template; // 0x30(0x8)
	bool bAttachToCharacter; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FName SocketName; // 0x40(0x8)
	struct FVector LocationOffset; // 0x48(0xC)
	struct FRotator RotationOffset; // 0x54(0xC)
	bool bDestroyAtEnd; // 0x60(0x1)
	bool bNeedSetTranslucencySort; // 0x61(0x1)
	uint8_t Pad_0x62[0x2]; // 0x62(0x2)
	int TranslucencySortPriority; // 0x64(0x4)


	// Object: Function NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffect.GetParentCharacter
	// Flags: [Final|Native|Private|Const]
	// Offset: 0x1026f71c8
	// Params: [ Num(2) Size(0x10) ]
	struct ACharacter* GetParentCharacter(struct USkeletalMeshComponent* MeshComp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1026F655C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x10518559C
};

