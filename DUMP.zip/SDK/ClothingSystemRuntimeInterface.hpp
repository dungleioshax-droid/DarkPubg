#pragma once

#include <cstdint>

// Object: Enum ClothingSystemRuntimeInterface.EClothSkinningMode
enum class EClothSkinningMode : uint8_t
{
	Default = 0,
	Alternate = 1,
	EClothSkinningMode_MAX = 2
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionData
// Size: 0x30 (Inherited: 0x0)
struct FClothCollisionData
{
	struct TArray<struct FClothCollisionPrim_Sphere> Spheres; // 0x0(0x10)
	struct TArray<struct FClothCollisionPrim_SphereConnection> SphereConnections; // 0x10(0x10)
	struct TArray<struct FClothCollisionPrim_Convex> Convexes; // 0x20(0x10)
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Convex
// Size: 0x18 (Inherited: 0x0)
struct FClothCollisionPrim_Convex
{
	struct TArray<struct FPlane> Planes; // 0x0(0x10)
	int BoneIndex; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_SphereConnection
// Size: 0x8 (Inherited: 0x0)
struct FClothCollisionPrim_SphereConnection
{
	int SphereIndices[0x2]; // 0x0(0x8)
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Sphere
// Size: 0x14 (Inherited: 0x0)
struct FClothCollisionPrim_Sphere
{
	int BoneIndex; // 0x0(0x4)
	float Radius; // 0x4(0x4)
	struct FVector LocalPosition; // 0x8(0xC)
};

// Object: Class ClothingSystemRuntimeInterface.ClothingAssetBase
// Size: 0x48 (Inherited: 0x28)
struct UClothingAssetBase : UObject
{
	struct FString ImportedFilePath; // 0x28(0x10)
	struct FGuid AssetGuid; // 0x38(0x10)
};

// Object: Class ClothingSystemRuntimeInterface.ClothingSimulationFactory
// Size: 0x28 (Inherited: 0x28)
struct UClothingSimulationFactory : UObject
{
};

