#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_SkillPropsBPTable_type.BP_STRUCT_SkillPropsBPTable_type
// Size: 0x34 (Inherited: 0x0)
struct FBP_STRUCT_SkillPropsBPTable_type
{
	struct FString Path_0_7125AC0045061D844040043E0816E498; // 0x0(0x10)
	struct FString CName_1_638079C0129E37EF7ABD58DE018085B5; // 0x10(0x10)
	struct FString Wrapper_2_17D6010032F6D6462C8642BA064BF7A2; // 0x20(0x10)
	int ID_3_3E5DCC006BF812EC2517437F0C381754; // 0x30(0x4)
};

