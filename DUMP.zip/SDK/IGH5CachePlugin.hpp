#pragma once

#include <cstdint>

// Object: Class IGH5CachePlugin.IGH5CachePluginSettings
// Size: 0x38 (Inherited: 0x28)
struct UIGH5CachePluginSettings : UObject
{
	struct FString Html5Url; // 0x28(0x10)
};

