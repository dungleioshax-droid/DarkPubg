#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_DiySuitPatternConfig_type.BP_STRUCT_DiySuitPatternConfig_type
// Size: 0x48 (Inherited: 0x0)
struct FBP_STRUCT_DiySuitPatternConfig_type
{
	int ID_0_1986288022A4FBB87BF37984018D0894; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FString Icon_1_051847804144FD206B0A47070D08B9DE; // 0x8(0x10)
	int ItemID_2_0F4A4C4062CFB54B08ACFC37094B4CD4; // 0x18(0x4)
	uint8_t Pad_0x1C[0x4]; // 0x1C(0x4)
	struct FString BPUrl_3_25D5368039F7AA966A5B00C00083445C; // 0x20(0x10)
	int Cost_4_22EF0B80079BBB006A2E79840D08E724; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
	struct FString Name_5_5103258079CB0E186B3912250D0907B5; // 0x38(0x10)
};

