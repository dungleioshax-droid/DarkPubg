#pragma once

#include <cstdint>

// Object: Class GameplayTagEvent.UAEGameplayTagEventNodeBase
// Size: 0xE0 (Inherited: 0x28)
struct UUAEGameplayTagEventNodeBase : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FGameplayTagQuery Requirements; // 0x80(0x48)
	struct FString LuaFilePath; // 0xC8(0x10)
	bool bInitialAutoVerify; // 0xD8(0x1)
	uint8_t Pad_0xD9[0x7]; // 0xD9(0x7)


	// Object: Function GameplayTagEvent.UAEGameplayTagEventNodeBase.Validate
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102a354b8
	// Params: [ Num(2) Size(0x10) ]
	void Validate(struct AActor* NodeTarget, struct UObject* Observer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function GameplayTagEvent.UAEGameplayTagEventNodeBase.OnUnregistered
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102a353fc
	// Params: [ Num(2) Size(0x10) ]
	void OnUnregistered(struct AActor* NodeTarget, struct UObject* Observer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function GameplayTagEvent.UAEGameplayTagEventNodeBase.OnRegistered
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102a35340
	// Params: [ Num(2) Size(0x10) ]
	void OnRegistered(struct AActor* NodeTarget, struct UObject* Observer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function GameplayTagEvent.UAEGameplayTagEventNodeBase.Invalidate
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102a35284
	// Params: [ Num(2) Size(0x10) ]
	void Invalidate(struct AActor* NodeTarget, struct UObject* Observer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
};

// Object: Class GameplayTagEvent.UAEGameplayTagImposerSubsystem
// Size: 0x170 (Inherited: 0x30)
struct UUAEGameplayTagImposerSubsystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x140]; // 0x30(0x140)


	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.UntagActor
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a36804
	// Params: [ Num(2) Size(0x18) ]
	void UntagActor(struct AActor* Actor, struct TArray<struct FGameplayTag>& InTags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2EB78
	// [Call #6] RVA: 0x1020C4E3C
	// [Call #7] RVA: 0x1020C4E3C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.UnregisterActorTagQueryUpdatedEvent
	// Flags: [Final|RequiredAPI|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a36754
	// Params: [ Num(2) Size(0xC) ]
	void UnregisterActorTagQueryUpdatedEvent(struct AActor* Actor, int Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2F568
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102A2EB78
	// [Call #11] RVA: 0x1020C4E3C
	// [Call #12] RVA: 0x1020C4E3C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.UnregisterActorTagChangedEvent
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a36620
	// Params: [ Num(4) Size(0x21) ]
	bool UnregisterActorTagChangedEvent(struct AActor* Actor, struct FGameplayTag& InTag, DelegateProperty& InDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A2E1BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A2F568
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.TagActor
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a36544
	// Params: [ Num(2) Size(0x18) ]
	void TagActor(struct AActor* Actor, struct TArray<struct FGameplayTag>& InTags);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2E8FC
	// [Call #6] RVA: 0x1020C4E3C
	// [Call #7] RVA: 0x1020C4E3C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102A2E1BC
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.RemoveAllMatchingTags
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a36484
	// Params: [ Num(2) Size(0x10) ]
	void RemoveAllMatchingTags(struct AActor* Actor, struct FGameplayTag& Tag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2EC14
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102A2E8FC
	// [Call #11] RVA: 0x1020C4E3C
	// [Call #12] RVA: 0x1020C4E3C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101FD9E48
	// [Call #19] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.RemoveAllActorTagEventNode
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x102a36408
	// Params: [ Num(1) Size(0x8) ]
	void RemoveAllActorTagEventNode(struct AActor* TargetActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A2E750
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A2EC14
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A2E8FC
	// [Call #14] RVA: 0x1020C4E3C
	// [Call #15] RVA: 0x1020C4E3C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.RemoveActorTagEventNode
	// Flags: [Final|RequiredAPI|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a36358
	// Params: [ Num(2) Size(0xC) ]
	void RemoveActorTagEventNode(struct UObject* WorldContextObject, int Handle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2E5B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A2E750
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A2EC14
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.RegisterActorTagQueryUpdatedEvent
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a361f4
	// Params: [ Num(4) Size(0x64) ]
	int RegisterActorTagQueryUpdatedEvent(struct AActor* Actor, struct FGameplayTagQuery& Query, DelegateProperty& InDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x105E41A18
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101FD9E48
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A2F34C
	// [Call #10] RVA: 0x1020C4EB4
	// [Call #11] RVA: 0x1020C4EB4
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A2E5B8
	// [Call #18] RVA: 0x10516D168

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.RegisterActorTagChangedEvent
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a360c0
	// Params: [ Num(4) Size(0x21) ]
	bool RegisterActorTagChangedEvent(struct AActor* Actor, struct FGameplayTag& InTag, DelegateProperty& InDelegate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101FD9E48
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A2DF68
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x105E41A18
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101FD9E48
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A2F34C

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.OnActorEndPlay
	// Flags: [Final|Native|Protected]
	// Offset: 0x102a36008
	// Params: [ Num(2) Size(0x9) ]
	void OnActorEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2DB10
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101FD9E48
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102A2DF68
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x105E41A18

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.Get
	// Flags: [Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102a35f8c
	// Params: [ Num(2) Size(0x10) ]
	struct UUAEGameplayTagImposerSubsystem* Get(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102A2DBE8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102A2DB10
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101FD9E48
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102A2DF68

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.FindFirstActorWithTag
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a35e78
	// Params: [ Num(4) Size(0x20) ]
	struct AActor* FindFirstActorWithTag(struct UObject* WorldContextObject, struct FGameplayTag& SearchTag, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102A2F2E0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102A2DBE8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x102A2DB10

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.FindActorsWithTag
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a35cf0
	// Params: [ Num(5) Size(0x28) ]
	int FindActorsWithTag(struct UObject* WorldContextObject, struct FGameplayTag& SearchTag, struct TArray<struct AActor*>& OutActors, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102A2F108
	// [Call #10] RVA: 0x101F811FC
	// [Call #11] RVA: 0x101F811FC
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.ClearActorTags
	// Flags: [Final|RequiredAPI|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a35c38
	// Params: [ Num(2) Size(0x9) ]
	void ClearActorTags(struct AActor* Actor, bool bNotifyAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102A2DC78
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102A2F108
	// [Call #15] RVA: 0x101F811FC
	// [Call #16] RVA: 0x101F811FC
	// [Call #17] RVA: 0x106C8459C

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.ApplyActorTagEventNode
	// Flags: [Final|RequiredAPI|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a35b48
	// Params: [ Num(4) Size(0x1C) ]
	int ApplyActorTagEventNode(struct AActor* TargetActor, struct UObject* NodeOwner, struct UUAEGameplayTagEventNodeBase* NodeBase);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102A2E320
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102A2DC78
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.ActorHasMatchingTag
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a35a34
	// Params: [ Num(4) Size(0x12) ]
	bool ActorHasMatchingTag(struct AActor* Actor, struct FGameplayTag& TagToCheck, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102A2EE54
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x102A2E320
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.ActorHasAnyTags
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a358fc
	// Params: [ Num(4) Size(0x1A) ]
	bool ActorHasAnyTags(struct AActor* Actor, struct TArray<struct FGameplayTag>& InTags, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102A2F018
	// [Call #8] RVA: 0x1020C4E3C
	// [Call #9] RVA: 0x1020C4E3C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A2EE54

	// Object: Function GameplayTagEvent.UAEGameplayTagImposerSubsystem.ActorHasAllTags
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a357c4
	// Params: [ Num(4) Size(0x1A) ]
	bool ActorHasAllTags(struct AActor* Actor, struct TArray<struct FGameplayTag>& InTags, bool bExactMatch);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102A2EF28
	// [Call #8] RVA: 0x1020C4E3C
	// [Call #9] RVA: 0x1020C4E3C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102A2F018
	// [Call #18] RVA: 0x1020C4E3C
};

