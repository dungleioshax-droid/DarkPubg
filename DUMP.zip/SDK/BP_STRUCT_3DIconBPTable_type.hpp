#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_3DIconBPTable_type.BP_STRUCT_3DIconBPTable_type
// Size: 0x28 (Inherited: 0x0)
struct FBP_STRUCT_3DIconBPTable_type
{
	struct FString CName_0_197F95006C7D41D02E19833803105905; // 0x0(0x10)
	int ID_1_6249C74062AE6BD53F17F69101F33054; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FString Path_2_064E67406FC200F32023304A0331E958; // 0x18(0x10)
};

