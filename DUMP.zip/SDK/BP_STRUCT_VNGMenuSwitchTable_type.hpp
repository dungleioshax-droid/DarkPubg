#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VNGMenuSwitchTable_type.BP_STRUCT_VNGMenuSwitchTable_type
// Size: 0x8 (Inherited: 0x0)
struct FBP_STRUCT_VNGMenuSwitchTable_type
{
	int ID_0_7E289F40058F21997AC26B640BB07F84; // 0x0(0x4)
	int Open_1_0148C0806D55EA324F39ACAD00803D0E; // 0x4(0x4)
};

