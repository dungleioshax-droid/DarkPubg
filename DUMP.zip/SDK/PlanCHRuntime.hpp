#pragma once

#include <cstdint>

// Object: ScriptStruct PlanCHRuntime.PlanCH_CommonOccupy
// Size: 0x20 (Inherited: 0x0)
struct FPlanCH_CommonOccupy
{
	int LandId; // 0x0(0x4)
	bool bOccupied; // 0x4(0x1)
	uint8_t Pad_0x5[0x3]; // 0x5(0x3)
	int BeginTime; // 0x8(0x4)
	int EndTime; // 0xC(0x4)
	struct FString PlayerUID; // 0x10(0x10)
};

// Object: Class PlanCHRuntime.PlanCH_GameMode
// Size: 0x22B8 (Inherited: 0x22B0)
struct APlanCH_GameMode : ABattleRoyaleGameMode
{
	struct ADynamicSublevelGenerator* LevelGenerator; // 0x22B0(0x8)


	// Object: Function PlanCHRuntime.PlanCH_GameMode.HandleNavigationInfo
	// Flags: [Final|Native|Private]
	// Offset: 0x102806fe0
	// Params: [ Num(1) Size(0x8) ]
	void HandleNavigationInfo(struct AController* Controller);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102801BA4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519077C

	// Object: Function PlanCHRuntime.PlanCH_GameMode.GetPlayerStart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(3) Size(0x10) ]
	struct ASTExtraPlayerStart* GetPlayerStart(int LandId, int SkinID);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanCHRuntime.PlanCH_GameMode.DSPlayerKickOut
	// Flags: [Final|Native|Public]
	// Offset: 0x102806e78
	// Params: [ Num(3) Size(0x20) ]
	void DSPlayerKickOut(uint64_t UID, struct FName PlayerType, struct FString ExitReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x1028020BC
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x102801BA4
	// [Call #19] RVA: 0x10519022C
};

// Object: Class PlanCHRuntime.PlanCH_GameModeState_Active
// Size: 0xC8 (Inherited: 0xC8)
struct UPlanCH_GameModeState_Active : UGameModeStateActive
{
};

// Object: Class PlanCHRuntime.PlanCH_GameModeState_Fighting
// Size: 0xD8 (Inherited: 0xD8)
struct UPlanCH_GameModeState_Fighting : UGameModeStateFightingTeam
{
};

// Object: Class PlanCHRuntime.PlanCH_GameState
// Size: 0x16B0 (Inherited: 0x1620)
struct APlanCH_GameState : ASTExtraGameStateBase
{
	struct FScriptMulticastDelegate OnIslandPlayerChangeDelegate; // 0x1620(0x10)
	struct FPlanCH_CommonOccupy PartyDanceLeadInfo_1; // 0x1630(0x20)
	struct FPlanCH_CommonOccupy PartyDanceLeadInfo_2; // 0x1650(0x20)
	struct FPlanCH_CommonOccupy PartyDanceLeadInfo_3; // 0x1670(0x20)
	struct FPlanCH_CommonOccupy PartyDanceLeadInfo_4; // 0x1690(0x20)


	// Object: Function PlanCHRuntime.PlanCH_GameState.OnRep_PartyDanceLeadInfo_4
	// Flags: [Final|Native|Public]
	// Offset: 0x1028077d8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_4();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_GameState.OnRep_PartyDanceLeadInfo_3
	// Flags: [Final|Native|Public]
	// Offset: 0x1028077c4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_3();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_GameState.OnRep_PartyDanceLeadInfo_2
	// Flags: [Final|Native|Public]
	// Offset: 0x1028077b0
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_2();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_GameState.OnRep_PartyDanceLeadInfo_1
	// Flags: [Final|Native|Public]
	// Offset: 0x10280779c
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_PartyDanceLeadInfo_1();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_GameState.LuaOnRep_PartyDanceLeadInfo
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void LuaOnRep_PartyDanceLeadInfo(int LandId);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanCHRuntime.PlanCH_GameState.ChangePartyLeadInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1028075a8
	// Params: [ Num(5) Size(0x20) ]
	void ChangePartyLeadInfo(int LandId, bool bOccupied, int BeginTime, int EndTime, struct FString PlayerUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x1028024D4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
};

// Object: Class PlanCHRuntime.PlanCH_PlayerState
// Size: 0x1CE0 (Inherited: 0x1CD8)
struct APlanCH_PlayerState : ASTExtraPlayerState
{
	int LandId; // 0x1CD8(0x4)
	int SkinID; // 0x1CDC(0x4)


	// Object: Function PlanCHRuntime.PlanCH_PlayerState.RequestPaintDecal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102807bfc
	// Params: [ Num(2) Size(0x40) ]
	void RequestPaintDecal(int DecalId, struct FTransform& TargetTransform);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102802968
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_PlayerState.OnRep_SkinId
	// Flags: [Final|Native|Public]
	// Offset: 0x102807be8
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_SkinId();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102802968
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_PlayerState.OnRep_LandId
	// Flags: [Final|Native|Public]
	// Offset: 0x102807bd4
	// Params: [ Num(0) Size(0x0) ]
	void OnRep_LandId();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102802968
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCH_PlayerState.InitLandId
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void InitLandId();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanCHRuntime.PlanCH_PlayerState.CanPaintDecal
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x102807b40
	// Params: [ Num(2) Size(0x5) ]
	bool CanPaintDecal(int DecalId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102802968
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
};

// Object: Class PlanCHRuntime.PlanCHBinFileHelper
// Size: 0x28 (Inherited: 0x28)
struct UPlanCHBinFileHelper : UObject
{

	// Object: Function PlanCHRuntime.PlanCHBinFileHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102807f58
	// Params: [ Num(3) Size(0xC) ]
	int Init(int z4BufferSize, int zeroListSize);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10280331C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x102808618
	// [Call #10] RVA: 0x10516D168
};

// Object: Class PlanCHRuntime.PlanCHGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UPlanCHGameplayStatics : UBlueprintFunctionLibrary
{

	// Object: Function PlanCHRuntime.PlanCHGameplayStatics.SpinEvaluate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1028083f4
	// Params: [ Num(3) Size(0xC) ]
	float SpinEvaluate(float S, float T);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1028040A0
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function PlanCHRuntime.PlanCHGameplayStatics.SetPlayerMovementBlendTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1028082f0
	// Params: [ Num(4) Size(0x11) ]
	bool SetPlayerMovementBlendTime(struct ASTExtraPlayerCharacter* PlayerChar, int nType, float BlendTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102803F18
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1028040A0
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function PlanCHRuntime.PlanCHGameplayStatics.GetActorBound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10280822c
	// Params: [ Num(2) Size(0x14) ]
	void GetActorBound(struct AActor* Actor, struct FVector& Size);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102804110
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102803F18
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function PlanCHRuntime.PlanCHGameplayStatics.ChangeLightChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102808174
	// Params: [ Num(2) Size(0xC) ]
	void ChangeLightChannel(struct UPrimitiveComponent* InComponent, int InChannelBitMask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102803EFC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102804110
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class PlanCHRuntime.PlanCHMapData
// Size: 0xB8 (Inherited: 0x98)
struct UPlanCHMapData : UMapDataBase
{
	struct TArray<struct ASTExtraPlayerCharacter*> PlayerCharacterArrayC; // 0x98(0x10)
	struct TArray<struct FVector> OffsetLocations; // 0xA8(0x10)


	// Object: Function PlanCHRuntime.PlanCHMapData.RemovePlayerItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10280882c
	// Params: [ Num(2) Size(0x9) ]
	bool RemovePlayerItem(struct ASTExtraPlayerCharacter* PlayerCharacterItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10280321C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10516EACC

	// Object: Function PlanCHRuntime.PlanCHMapData.AddPlayerItem
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1028086f0
	// Params: [ Num(5) Size(0x25) ]
	bool AddPlayerItem(struct ASTExtraPlayerCharacter* PlayerCharacterItem, struct UWidget* PlayerInfoBPItem, struct UWidget* PlayerInfoRotWidgetItem, struct FVector OffsetLocation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102803158
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10280321C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
};

// Object: Class PlanCHRuntime.PlanCHSpectatorPawn
// Size: 0x5A8 (Inherited: 0x538)
struct APlanCHSpectatorPawn : ASpectatorPawn
{
	uint8_t Pad_0x538[0x58]; // 0x538(0x58)
	struct FString LuaFilePath; // 0x590(0x10)
	float PlaneMoveMaxSpeed; // 0x5A0(0x4)
	float VerticalMoveMaxSpeed; // 0x5A4(0x4)


	// Object: Function PlanCHRuntime.PlanCHSpectatorPawn.OnSpectatorRestart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void OnSpectatorRestart();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function PlanCHRuntime.PlanCHSpectatorPawn.MoveRight
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102808b38
	// Params: [ Num(1) Size(0x4) ]
	void MoveRight(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x10518366C

	// Object: Function PlanCHRuntime.PlanCHSpectatorPawn.MoveForward
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102808ab4
	// Params: [ Num(1) Size(0x4) ]
	void MoveForward(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
};

