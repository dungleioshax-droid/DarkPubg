#pragma once

#include <cstdint>

// Object: Enum MovieSceneCapture.EHDRCaptureGamut
enum class EHDRCaptureGamut : uint8_t
{
	HCGM_Rec709 = 0,
	HCGM_P3DCI = 1,
	HCGM_Rec2020 = 2,
	HCGM_ACES = 3,
	HCGM_ACEScg = 4,
	HCGM_MAX = 5
};

// Object: ScriptStruct MovieSceneCapture.CompositionGraphCapturePasses
// Size: 0x10 (Inherited: 0x0)
struct FCompositionGraphCapturePasses
{
	struct TArray<struct FString> Value; // 0x0(0x10)
};

// Object: ScriptStruct MovieSceneCapture.CaptureProtocolID
// Size: 0x8 (Inherited: 0x0)
struct FCaptureProtocolID
{
	struct FName Identifier; // 0x0(0x8)
};

// Object: ScriptStruct MovieSceneCapture.MovieSceneCaptureSettings
// Size: 0x50 (Inherited: 0x0)
struct FMovieSceneCaptureSettings
{
	struct FDirectoryPath OutputDirectory; // 0x0(0x10)
	struct AGameModeBase* GameModeOverride; // 0x10(0x8)
	struct FString OutputFormat; // 0x18(0x10)
	bool bOverwriteExisting; // 0x28(0x1)
	bool bUseRelativeFrameNumbers; // 0x29(0x1)
	uint8_t Pad_0x2A[0x2]; // 0x2A(0x2)
	int HandleFrames; // 0x2C(0x4)
	uint8_t ZeroPadFrameNumbers; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	int FrameRate; // 0x34(0x4)
	int BitRate; // 0x38(0x4)
	struct FCaptureResolution Resolution; // 0x3C(0x8)
	bool bEnableTextureStreaming; // 0x44(0x1)
	bool bCinematicEngineScalability; // 0x45(0x1)
	bool bCinematicMode; // 0x46(0x1)
	bool bAllowMovement; // 0x47(0x1)
	bool bAllowTurning; // 0x48(0x1)
	bool bShowPlayer; // 0x49(0x1)
	bool bShowHUD; // 0x4A(0x1)
	uint8_t Pad_0x4B[0x5]; // 0x4B(0x5)
};

// Object: ScriptStruct MovieSceneCapture.CaptureResolution
// Size: 0x8 (Inherited: 0x0)
struct FCaptureResolution
{
	uint32_t ResX; // 0x0(0x4)
	uint32_t ResY; // 0x4(0x4)
};

// Object: Class MovieSceneCapture.MovieSceneCapture
// Size: 0x1F0 (Inherited: 0x28)
struct UMovieSceneCapture : UObject
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
	struct FCaptureProtocolID CaptureType; // 0x38(0x8)
	struct UMovieSceneCaptureProtocolSettings* ProtocolSettings; // 0x40(0x8)
	struct FMovieSceneCaptureSettings Settings; // 0x48(0x50)
	uint8_t Pad_0x98[0x10]; // 0x98(0x10)
	bool bUseSeparateProcess; // 0xA8(0x1)
	bool bCloseEditorWhenCaptureStarts; // 0xA9(0x1)
	uint8_t Pad_0xAA[0x6]; // 0xAA(0x6)
	struct FString AdditionalCommandLineArguments; // 0xB0(0x10)
	struct FString InheritedCommandLineArguments; // 0xC0(0x10)
	uint8_t Pad_0xD0[0x120]; // 0xD0(0x120)
};

// Object: Class MovieSceneCapture.AutomatedLevelSequenceCapture
// Size: 0x1F0 (Inherited: 0x1F0)
struct UAutomatedLevelSequenceCapture : UMovieSceneCapture
{
};

// Object: Class MovieSceneCapture.MovieSceneCaptureProtocolSettings
// Size: 0x28 (Inherited: 0x28)
struct UMovieSceneCaptureProtocolSettings : UObject
{
};

// Object: Class MovieSceneCapture.FrameGrabberProtocolSettings
// Size: 0x30 (Inherited: 0x28)
struct UFrameGrabberProtocolSettings : UMovieSceneCaptureProtocolSettings
{
	uint8_t Pad_0x28[0x8]; // 0x28(0x8)
};

// Object: Class MovieSceneCapture.AVCaptureSettings
// Size: 0x30 (Inherited: 0x30)
struct UAVCaptureSettings : UFrameGrabberProtocolSettings
{
};

// Object: Class MovieSceneCapture.CompositionGraphCaptureSettings
// Size: 0x60 (Inherited: 0x28)
struct UCompositionGraphCaptureSettings : UMovieSceneCaptureProtocolSettings
{
	struct FCompositionGraphCapturePasses IncludeRenderPasses; // 0x28(0x10)
	bool bCaptureFramesInHDR; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	int HDRCompressionQuality; // 0x3C(0x4)
	enum class EHDRCaptureGamut CaptureGamut; // 0x40(0x1)
	uint8_t Pad_0x41[0x7]; // 0x41(0x7)
	struct FSoftObjectPath PostProcessingMaterial; // 0x48(0x18)
};

// Object: Class MovieSceneCapture.BmpImageCaptureSettings
// Size: 0x28 (Inherited: 0x28)
struct UBmpImageCaptureSettings : UMovieSceneCaptureProtocolSettings
{
};

// Object: Class MovieSceneCapture.ImageCaptureSettings
// Size: 0x38 (Inherited: 0x30)
struct UImageCaptureSettings : UFrameGrabberProtocolSettings
{
	int CompressionQuality; // 0x30(0x4)
	uint8_t Pad_0x34[0x4]; // 0x34(0x4)
};

// Object: Class MovieSceneCapture.MovieSceneCaptureInterface
// Size: 0x28 (Inherited: 0x28)
struct IMovieSceneCaptureInterface : IInterface
{
};

// Object: Class MovieSceneCapture.LevelCapture
// Size: 0x210 (Inherited: 0x1F0)
struct ULevelCapture : UMovieSceneCapture
{
	bool bAutoStartCapture; // 0x1F0(0x1)
	uint8_t Pad_0x1F1[0xB]; // 0x1F1(0xB)
	struct FGuid PrerequisiteActorId; // 0x1FC(0x10)
	uint8_t Pad_0x20C[0x4]; // 0x20C(0x4)
};

// Object: Class MovieSceneCapture.MovieSceneCaptureEnvironment
// Size: 0x28 (Inherited: 0x28)
struct UMovieSceneCaptureEnvironment : UObject
{

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureFrameNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105fbd5bc
	// Params: [ Num(1) Size(0x4) ]
	int GetCaptureFrameNumber();
	// [Call #1] RVA: 0x105FB7228
	// [Call #2] RVA: 0x10519022C
	// [Call #3] RVA: 0x105190870
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x105FBCA4C
	// [Call #7] RVA: 0x105184F34
	// [Call #8] RVA: 0x1036A6C08

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureElapsedTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105fbd588
	// Params: [ Num(1) Size(0x4) ]
	float GetCaptureElapsedTime();
	// [Call #1] RVA: 0x105FB7250
	// [Call #2] RVA: 0x105FB7228
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105FBCA4C
	// [Call #8] RVA: 0x105184F34
	// [Call #9] RVA: 0x1036A6C08
};

// Object: Class MovieSceneCapture.VideoCaptureSettings
// Size: 0x48 (Inherited: 0x30)
struct UVideoCaptureSettings : UFrameGrabberProtocolSettings
{
	bool bUseCompression; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	float CompressionQuality; // 0x34(0x4)
	struct FString VideoCodec; // 0x38(0x10)
};

