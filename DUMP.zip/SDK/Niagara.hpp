#pragma once

#include <cstdint>

// Object: Enum Niagara.ENiagaraCollisionMode
enum class ENiagaraCollisionMode : uint8_t
{
	None = 0,
	SceneGeometry = 1,
	DepthBuffer = 2,
	DistanceField = 3,
	ENiagaraCollisionMode_MAX = 4
};

// Object: Enum Niagara.ENiagaraScriptGroup
enum class ENiagaraScriptGroup : uint8_t
{
	Particle = 0,
	Emitter = 1,
	System = 2,
	Max = 3
};

// Object: Enum Niagara.ENiagaraScriptUsage
enum class ENiagaraScriptUsage : uint8_t
{
	Function = 0,
	Module = 1,
	DynamicInput = 2,
	ParticleSpawnScript = 3,
	ParticleSpawnScriptInterpolated = 4,
	ParticleUpdateScript = 5,
	ParticleEventScript = 6,
	ParticleGPUComputeScript = 7,
	EmitterSpawnScript = 8,
	EmitterUpdateScript = 9,
	SystemSpawnScript = 10,
	SystemUpdateScript = 11,
	ENiagaraScriptUsage_MAX = 12
};

// Object: Enum Niagara.ENiagaraScriptCompileStatus
enum class ENiagaraScriptCompileStatus : uint8_t
{
	NCS_Unknown = 0,
	NCS_Dirty = 1,
	NCS_Error = 2,
	NCS_UpToDate = 3,
	NCS_BeingCreated = 4,
	NCS_UpToDateWithWarnings = 5,
	NCS_ComputeUpToDateWithWarnings = 6,
	NCS_MAX = 7
};

// Object: Enum Niagara.ENiagaraInputNodeUsage
enum class ENiagaraInputNodeUsage : uint8_t
{
	Undefined = 0,
	Parameter = 1,
	Attribute = 2,
	SystemConstant = 3,
	TranslatorConstant = 4,
	RapidIterationParameter = 5,
	ENiagaraInputNodeUsage_MAX = 6
};

// Object: Enum Niagara.ENiagaraDataSetType
enum class ENiagaraDataSetType : uint8_t
{
	ParticleData = 0,
	Shared = 1,
	Event = 2,
	ENiagaraDataSetType_MAX = 3
};

// Object: Enum Niagara.ENiagaraAgeUpdateMode
enum class ENiagaraAgeUpdateMode : uint8_t
{
	TickDeltaTime = 0,
	DesiredAge = 1,
	ENiagaraAgeUpdateMode_MAX = 2
};

// Object: Enum Niagara.ENiagaraSimTarget
enum class ENiagaraSimTarget : uint8_t
{
	CPUSim = 0,
	GPUComputeSim = 1,
	ENiagaraSimTarget_MAX = 2
};

// Object: Enum Niagara.ENDISkeletalMesh_SkinningMode
enum class ENDISkeletalMesh_SkinningMode : uint8_t
{
	None = 0,
	SkinOnTheFly = 1,
	PreSkin = 2,
	ENDISkeletalMesh_MAX = 3
};

// Object: Enum Niagara.EScriptExecutionMode
enum class EScriptExecutionMode : uint8_t
{
	EveryParticle = 0,
	SpawnedParticles = 1,
	SingleParticle = 2,
	EScriptExecutionMode_MAX = 3
};

// Object: Enum Niagara.ENiagaraSortMode
enum class ENiagaraSortMode : uint8_t
{
	None = 0,
	ViewDepth = 1,
	ViewDistance = 2,
	CustomAscending = 3,
	CustomDecending = 4,
	ENiagaraSortMode_MAX = 5
};

// Object: Enum Niagara.ENiagaraMeshFacingMode
enum class ENiagaraMeshFacingMode : uint8_t
{
	Default = 0,
	Velocity = 1,
	CameraPosition = 2,
	CameraPlane = 3,
	ENiagaraMeshFacingMode_MAX = 4
};

// Object: Enum Niagara.ENiagaraPreviewGridResetMode
enum class ENiagaraPreviewGridResetMode : uint8_t
{
	Never = 0,
	Individual = 1,
	All = 2,
	ENiagaraPreviewGridResetMode_MAX = 3
};

// Object: Enum Niagara.ENiagaraRibbonTessellationMode
enum class ENiagaraRibbonTessellationMode : uint8_t
{
	Automatic = 0,
	Custom = 1,
	Disabled = 2,
	ENiagaraRibbonTessellationMode_MAX = 3
};

// Object: Enum Niagara.ENiagaraRibbonDrawDirection
enum class ENiagaraRibbonDrawDirection : uint8_t
{
	FrontToBack = 0,
	BackToFront = 1,
	ENiagaraRibbonDrawDirection_MAX = 2
};

// Object: Enum Niagara.ENiagaraRibbonAgeOffsetMode
enum class ENiagaraRibbonAgeOffsetMode : uint8_t
{
	Scale = 0,
	Clip = 1,
	ENiagaraRibbonAgeOffsetMode_MAX = 2
};

// Object: Enum Niagara.ENiagaraRibbonFacingMode
enum class ENiagaraRibbonFacingMode : uint8_t
{
	Screen = 0,
	Custom = 1,
	CustomSideVector = 2,
	ENiagaraRibbonFacingMode_MAX = 3
};

// Object: Enum Niagara.ENiagaraModuleDependencyScriptConstraint
enum class ENiagaraModuleDependencyScriptConstraint : uint8_t
{
	SameScript = 0,
	AllScripts = 1,
	ENiagaraModuleDependencyScriptConstraint_MAX = 2
};

// Object: Enum Niagara.ENiagaraModuleDependencyType
enum class ENiagaraModuleDependencyType : uint8_t
{
	PreDependency = 0,
	PostDependency = 1,
	ENiagaraModuleDependencyType_MAX = 2
};

// Object: Enum Niagara.EUnusedAttributeBehaviour
enum class EUnusedAttributeBehaviour : uint8_t
{
	Copy = 0,
	Zero = 1,
	None = 2,
	MarkInvalid = 3,
	PassThrough = 4,
	EUnusedAttributeBehaviour_MAX = 5
};

// Object: Enum Niagara.ENiagaraSpriteFacingMode
enum class ENiagaraSpriteFacingMode : uint8_t
{
	FaceCamera = 0,
	FaceCameraPlane = 1,
	CustomFacingVector = 2,
	FaceCameraPosition = 3,
	FaceCameraDistanceBlend = 4,
	ENiagaraSpriteFacingMode_MAX = 5
};

// Object: Enum Niagara.ENiagaraSpriteAlignment
enum class ENiagaraSpriteAlignment : uint8_t
{
	Unaligned = 0,
	VelocityAligned = 1,
	CustomAlignment = 2,
	ENiagaraSpriteAlignment_MAX = 3
};

// Object: Enum Niagara.ENiagaraExecutionState
enum class ENiagaraExecutionState : uint8_t
{
	Active = 0,
	Inactive = 1,
	InactiveClear = 2,
	Complete = 3,
	Disabled = 4,
	Num = 5,
	ENiagaraExecutionState_MAX = 6
};

// Object: Enum Niagara.ENiagaraExecutionStateSource
enum class ENiagaraExecutionStateSource : uint8_t
{
	Scalability = 0,
	Internal = 1,
	Owner = 2,
	InternalCompletion = 3,
	ENiagaraExecutionStateSource_MAX = 4
};

// Object: Enum Niagara.ENiagaraNumericOutputTypeSelectionMode
enum class ENiagaraNumericOutputTypeSelectionMode : uint8_t
{
	None = 0,
	Largest = 1,
	Smallest = 2,
	Scalar = 3,
	ENiagaraNumericOutputTypeSelectionMode_MAX = 4
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraParameterSectionTemplate
// Size: 0x48 (Inherited: 0x18)
struct FMovieSceneNiagaraParameterSectionTemplate : FMovieSceneEvalTemplate
{
	struct FNiagaraVariable Parameter; // 0x18(0x30)
};

// Object: ScriptStruct Niagara.NiagaraVariable
// Size: 0x30 (Inherited: 0x0)
struct FNiagaraVariable
{
	struct FName Name; // 0x0(0x8)
	struct FNiagaraTypeDefinition TypeDef; // 0x8(0x18)
	struct TArray<uint8_t> VarData; // 0x20(0x10)
};

// Object: ScriptStruct Niagara.NiagaraTypeDefinition
// Size: 0x18 (Inherited: 0x0)
struct FNiagaraTypeDefinition
{
	struct UStruct* Struct; // 0x0(0x8)
	struct UEnum* Enum; // 0x8(0x8)
	uint8_t Pad_0x10[0x8]; // 0x10(0x8)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraBoolParameterSectionTemplate
// Size: 0xB8 (Inherited: 0x48)
struct FMovieSceneNiagaraBoolParameterSectionTemplate : FMovieSceneNiagaraParameterSectionTemplate
{
	struct FIntegralCurve BoolCurve; // 0x48(0x70)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraColorParameterSectionTemplate
// Size: 0x208 (Inherited: 0x48)
struct FMovieSceneNiagaraColorParameterSectionTemplate : FMovieSceneNiagaraParameterSectionTemplate
{
	struct FRichCurve RedChannel; // 0x48(0x70)
	struct FRichCurve GreenChannel; // 0xB8(0x70)
	struct FRichCurve BlueChannel; // 0x128(0x70)
	struct FRichCurve AlphaChannel; // 0x198(0x70)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraFloatParameterSectionTemplate
// Size: 0xB8 (Inherited: 0x48)
struct FMovieSceneNiagaraFloatParameterSectionTemplate : FMovieSceneNiagaraParameterSectionTemplate
{
	struct FRichCurve FloatChannel; // 0x48(0x70)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraIntegerParameterSectionTemplate
// Size: 0xB8 (Inherited: 0x48)
struct FMovieSceneNiagaraIntegerParameterSectionTemplate : FMovieSceneNiagaraParameterSectionTemplate
{
	struct FIntegralCurve IntegerChannel; // 0x48(0x70)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraSystemTrackImplementation
// Size: 0x18 (Inherited: 0x10)
struct FMovieSceneNiagaraSystemTrackImplementation : FMovieSceneTrackImplementation
{
	float SpawnSectionStartFrame; // 0xC(0x4)
	float SpawnSectionEndFrame; // 0x10(0x4)
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraSystemTrackTemplate
// Size: 0x18 (Inherited: 0x18)
struct FMovieSceneNiagaraSystemTrackTemplate : FMovieSceneEvalTemplate
{
};

// Object: ScriptStruct Niagara.MovieSceneNiagaraVectorParameterSectionTemplate
// Size: 0x210 (Inherited: 0x48)
struct FMovieSceneNiagaraVectorParameterSectionTemplate : FMovieSceneNiagaraParameterSectionTemplate
{
	struct FRichCurve VectorChannels[0x4]; // 0x48(0x1C0)
	int ChannelsUsed; // 0x208(0x4)
	uint8_t Pad_0x20C[0x4]; // 0x20C(0x4)
};

// Object: ScriptStruct Niagara.NiagaraVariableDataInterfaceBinding
// Size: 0x30 (Inherited: 0x0)
struct FNiagaraVariableDataInterfaceBinding
{
	struct FNiagaraVariable BoundVariable; // 0x0(0x30)
};

// Object: ScriptStruct Niagara.NiagaraVariableAttributeBinding
// Size: 0x90 (Inherited: 0x0)
struct FNiagaraVariableAttributeBinding
{
	struct FNiagaraVariable BoundVariable; // 0x0(0x30)
	struct FNiagaraVariable DataSetVariable; // 0x30(0x30)
	struct FNiagaraVariable DefaultValueIfNonExistent; // 0x60(0x30)
};

// Object: ScriptStruct Niagara.NiagaraVariableInfo
// Size: 0x50 (Inherited: 0x0)
struct FNiagaraVariableInfo
{
	struct FNiagaraVariable Variable; // 0x0(0x30)
	struct FText Definition; // 0x30(0x18)
	struct UNiagaraDataInterface* DataInterface; // 0x48(0x8)
};

// Object: ScriptStruct Niagara.VMExternalFunctionBindingInfo
// Size: 0x78 (Inherited: 0x0)
struct FVMExternalFunctionBindingInfo
{
	struct FName Name; // 0x0(0x8)
	struct FName OwnerName; // 0x8(0x8)
	struct TArray<bool> InputParamLocations; // 0x10(0x10)
	int NumOutputs; // 0x20(0x4)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TMap<struct FName, struct FName> Specifiers; // 0x28(0x50)
};

// Object: ScriptStruct Niagara.NiagaraStatScope
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraStatScope
{
	struct FName FullName; // 0x0(0x8)
	struct FName FriendlyName; // 0x8(0x8)
};

// Object: ScriptStruct Niagara.NiagaraScriptDataInterfaceCompileInfo
// Size: 0x50 (Inherited: 0x0)
struct FNiagaraScriptDataInterfaceCompileInfo
{
	struct FName Name; // 0x0(0x8)
	int UserPtrIdx; // 0x8(0x4)
	uint8_t Pad_0xC[0x4]; // 0xC(0x4)
	struct FNiagaraTypeDefinition Type; // 0x10(0x18)
	struct TArray<struct FNiagaraFunctionSignature> RegisteredFunctions; // 0x28(0x10)
	struct FName RegisteredParameterMapRead; // 0x38(0x8)
	struct FName RegisteredParameterMapWrite; // 0x40(0x8)
	bool bIsPlaceholder; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: ScriptStruct Niagara.NiagaraFunctionSignature
// Size: 0x88 (Inherited: 0x0)
struct FNiagaraFunctionSignature
{
	struct FName Name; // 0x0(0x8)
	struct TArray<struct FNiagaraVariable> Inputs; // 0x8(0x10)
	struct TArray<struct FNiagaraVariable> Outputs; // 0x18(0x10)
	struct FName OwnerName; // 0x28(0x8)
	bool bRequiresContext; // 0x30(0x1)
	bool bMemberFunction; // 0x31(0x1)
	uint8_t Pad_0x32[0x6]; // 0x32(0x6)
	struct TMap<struct FName, struct FName> FunctionSpecifiers; // 0x38(0x50)
};

// Object: ScriptStruct Niagara.NiagaraScriptDataInterfaceInfo
// Size: 0x40 (Inherited: 0x0)
struct FNiagaraScriptDataInterfaceInfo
{
	struct UNiagaraDataInterface* DataInterface; // 0x0(0x8)
	struct FName Name; // 0x8(0x8)
	int UserPtrIdx; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FNiagaraTypeDefinition Type; // 0x18(0x18)
	struct FName RegisteredParameterMapRead; // 0x30(0x8)
	struct FName RegisteredParameterMapWrite; // 0x38(0x8)
};

// Object: ScriptStruct Niagara.NiagaraScriptDataUsageInfo
// Size: 0x1 (Inherited: 0x0)
struct FNiagaraScriptDataUsageInfo
{
	bool bReadsAttributeData; // 0x0(0x1)
};

// Object: ScriptStruct Niagara.NiagaraDataSetProperties
// Size: 0x20 (Inherited: 0x0)
struct FNiagaraDataSetProperties
{
	struct FNiagaraDataSetID ID; // 0x0(0x10)
	struct TArray<struct FNiagaraVariable> Variables; // 0x10(0x10)
};

// Object: ScriptStruct Niagara.NiagaraDataSetID
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraDataSetID
{
	struct FName Name; // 0x0(0x8)
	uint8_t Type; // 0x8(0x1)
	uint8_t Pad_0x9[0x7]; // 0x9(0x7)
};

// Object: ScriptStruct Niagara.MeshTriCoordinate
// Size: 0x10 (Inherited: 0x0)
struct FMeshTriCoordinate
{
	int Tri; // 0x0(0x4)
	struct FVector BaryCoord; // 0x4(0xC)
};

// Object: ScriptStruct Niagara.NDIStaticMeshSectionFilter
// Size: 0x10 (Inherited: 0x0)
struct FNDIStaticMeshSectionFilter
{
	struct TArray<int> AllowedMaterialSlots; // 0x0(0x10)
};

// Object: ScriptStruct Niagara.NiagaraEmitterScriptProperties
// Size: 0x28 (Inherited: 0x0)
struct FNiagaraEmitterScriptProperties
{
	struct UNiagaraScript* Script; // 0x0(0x8)
	struct TArray<struct FNiagaraEventReceiverProperties> EventReceivers; // 0x8(0x10)
	struct TArray<struct FNiagaraEventGeneratorProperties> EventGenerators; // 0x18(0x10)
};

// Object: ScriptStruct Niagara.NiagaraEventGeneratorProperties
// Size: 0x30 (Inherited: 0x0)
struct FNiagaraEventGeneratorProperties
{
	int MaxEventsPerFrame; // 0x0(0x4)
	uint8_t Pad_0x4[0x4]; // 0x4(0x4)
	struct FName ID; // 0x8(0x8)
	struct FNiagaraDataSetProperties SetProps; // 0x10(0x20)
};

// Object: ScriptStruct Niagara.NiagaraEventReceiverProperties
// Size: 0x18 (Inherited: 0x0)
struct FNiagaraEventReceiverProperties
{
	struct FName Name; // 0x0(0x8)
	struct FName SourceEventGenerator; // 0x8(0x8)
	struct FName SourceEmitter; // 0x10(0x8)
};

// Object: ScriptStruct Niagara.NiagaraEventScriptProperties
// Size: 0x58 (Inherited: 0x28)
struct FNiagaraEventScriptProperties : FNiagaraEmitterScriptProperties
{
	uint8_t ExecutionMode; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	uint32_t SpawnNumber; // 0x2C(0x4)
	uint32_t MaxEventsPerFrame; // 0x30(0x4)
	struct FGuid SourceEmitterID; // 0x34(0x10)
	uint8_t Pad_0x44[0x4]; // 0x44(0x4)
	struct FName SourceEventName; // 0x48(0x8)
	bool bRandomSpawnNumber; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	uint32_t MinSpawnNumber; // 0x54(0x4)
};

// Object: ScriptStruct Niagara.NiagaraEmitterHandle
// Size: 0x30 (Inherited: 0x0)
struct FNiagaraEmitterHandle
{
	struct FGuid ID; // 0x0(0x10)
	struct FName IdName; // 0x10(0x8)
	bool bIsEnabled; // 0x18(0x1)
	uint8_t Pad_0x19[0x7]; // 0x19(0x7)
	struct FName Name; // 0x20(0x8)
	struct UNiagaraEmitter* Instance; // 0x28(0x8)
};

// Object: ScriptStruct Niagara.NiagaraCollisionEventPayload
// Size: 0x2C (Inherited: 0x0)
struct FNiagaraCollisionEventPayload
{
	struct FVector CollisionPos; // 0x0(0xC)
	struct FVector CollisionNormal; // 0xC(0xC)
	struct FVector CollisionVelocity; // 0x18(0xC)
	int ParticleIndex; // 0x24(0x4)
	int PhysicalMaterialIndex; // 0x28(0x4)
};

// Object: ScriptStruct Niagara.NiagaraParameters
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraParameters
{
	struct TArray<struct FNiagaraVariable> Parameters; // 0x0(0x10)
};

// Object: ScriptStruct Niagara.NiagaraParameterStore
// Size: 0xE8 (Inherited: 0x0)
struct FNiagaraParameterStore
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct UObject* Owner; // 0x8(0x8)
	struct TMap<struct FNiagaraVariable, int> ParameterOffsets; // 0x10(0x50)
	struct TArray<uint8_t> ParameterData; // 0x60(0x10)
	struct TArray<struct UNiagaraDataInterface*> DataInterfaces; // 0x70(0x10)
	uint8_t Pad_0x80[0x68]; // 0x80(0x68)
};

// Object: ScriptStruct Niagara.NiagaraVMExecutableData
// Size: 0x108 (Inherited: 0x0)
struct FNiagaraVMExecutableData
{
	struct TArray<uint8_t> ByteCode; // 0x0(0x10)
	int NumUserPtrs; // 0x10(0x4)
	uint8_t Pad_0x14[0x4]; // 0x14(0x4)
	struct FNiagaraParameters Parameters; // 0x18(0x10)
	struct FNiagaraParameters InternalParameters; // 0x28(0x10)
	struct TMap<struct FName, struct FNiagaraParameters> DataSetToParameters; // 0x38(0x50)
	struct TArray<struct FNiagaraVariable> Attributes; // 0x88(0x10)
	struct FNiagaraScriptDataUsageInfo DataUsage; // 0x98(0x1)
	uint8_t Pad_0x99[0x7]; // 0x99(0x7)
	struct TArray<struct FNiagaraScriptDataInterfaceCompileInfo> DataInterfaceInfo; // 0xA0(0x10)
	struct TArray<struct FVMExternalFunctionBindingInfo> CalledVMExternalFunctions; // 0xB0(0x10)
	struct TArray<struct FNiagaraDataSetID> ReadDataSets; // 0xC0(0x10)
	struct TArray<struct FNiagaraDataSetProperties> WriteDataSets; // 0xD0(0x10)
	struct TArray<struct FNiagaraStatScope> StatScopes; // 0xE0(0x10)
	struct TArray<struct FNiagaraDataInterfaceGPUParamInfo> DIParamInfo; // 0xF0(0x10)
	uint8_t LastCompileStatus; // 0x100(0x1)
	uint8_t Pad_0x101[0x7]; // 0x101(0x7)
};

// Object: ScriptStruct Niagara.NiagaraVMExecutableDataId
// Size: 0x50 (Inherited: 0x0)
struct FNiagaraVMExecutableDataId
{
	struct FGuid CompilerVersionID; // 0x0(0x10)
	uint8_t ScriptUsageType; // 0x10(0x1)
	uint8_t Pad_0x11[0x3]; // 0x11(0x3)
	struct FGuid ScriptUsageTypeID; // 0x14(0x10)
	uint8_t Pad_0x24[0x4]; // 0x24(0x4)
	struct TArray<struct FString> AdditionalDefines; // 0x28(0x10)
	struct FGuid BaseScriptID; // 0x38(0x10)
	bool bIsScriptOptimized; // 0x48(0x1)
	uint8_t Pad_0x49[0x7]; // 0x49(0x7)
};

// Object: ScriptStruct Niagara.NiagaraModuleDependency
// Size: 0x28 (Inherited: 0x0)
struct FNiagaraModuleDependency
{
	struct FName ID; // 0x0(0x8)
	uint8_t Type; // 0x8(0x1)
	uint8_t ScriptConstraint; // 0x9(0x1)
	uint8_t Pad_0xA[0x6]; // 0xA(0x6)
	struct FText Description; // 0x10(0x18)
};

// Object: ScriptStruct Niagara.NiagaraScriptExecutionParameterStore
// Size: 0x108 (Inherited: 0xE8)
struct FNiagaraScriptExecutionParameterStore : FNiagaraParameterStore
{
	int ParameterSize; // 0xE8(0x4)
	uint32_t PaddedParameterSize; // 0xEC(0x4)
	struct TArray<struct FNiagaraScriptExecutionPaddingInfo> PaddingInfo; // 0xF0(0x10)
	uint8_t bInitialized : 1; // 0x100(0x1), Mask(0x1)
	uint8_t BitPad_0x100_1 : 7; // 0x100(0x1)
	uint8_t Pad_0x101[0x7]; // 0x101(0x7)
};

// Object: ScriptStruct Niagara.NiagaraScriptExecutionPaddingInfo
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraScriptExecutionPaddingInfo
{
	uint8_t Pad_0x0[0x10]; // 0x0(0x10)
};

// Object: ScriptStruct Niagara.NiagaraSystemCompileRequest
// Size: 0x78 (Inherited: 0x0)
struct FNiagaraSystemCompileRequest
{
	uint8_t Pad_0x0[0x8]; // 0x0(0x8)
	struct TArray<struct UObject*> RootObjects; // 0x8(0x10)
	uint8_t Pad_0x18[0x60]; // 0x18(0x60)
};

// Object: ScriptStruct Niagara.EmitterCompiledScriptPair
// Size: 0x80 (Inherited: 0x0)
struct FEmitterCompiledScriptPair
{
	uint8_t Pad_0x0[0x80]; // 0x0(0x80)
};

// Object: ScriptStruct Niagara.NiagaraEmitterSpawnAttributes
// Size: 0x10 (Inherited: 0x0)
struct FNiagaraEmitterSpawnAttributes
{
	struct TArray<struct FName> SpawnAttributes; // 0x0(0x10)
};

// Object: ScriptStruct Niagara.NiagaraVariableMetaData
// Size: 0xC8 (Inherited: 0x0)
struct FNiagaraVariableMetaData
{
	struct FText Description; // 0x0(0x18)
	struct FText CategoryName; // 0x18(0x18)
	bool bAdvancedDisplay; // 0x30(0x1)
	uint8_t Pad_0x31[0x3]; // 0x31(0x3)
	int EditorSortPriority; // 0x34(0x4)
	bool bInlineEditConditionToggle; // 0x38(0x1)
	uint8_t Pad_0x39[0x7]; // 0x39(0x7)
	struct FNiagaraInputConditionMetadata EditCondition; // 0x40(0x18)
	struct FNiagaraInputConditionMetadata VisibleCondition; // 0x58(0x18)
	struct TMap<struct FName, struct FString> PropertyMetaData; // 0x70(0x50)
	bool bIsStaticSwitch; // 0xC0(0x1)
	uint8_t Pad_0xC1[0x3]; // 0xC1(0x3)
	int StaticSwitchDefaultValue; // 0xC4(0x4)
};

// Object: ScriptStruct Niagara.NiagaraInputConditionMetadata
// Size: 0x18 (Inherited: 0x0)
struct FNiagaraInputConditionMetadata
{
	struct FName InputName; // 0x0(0x8)
	struct TArray<struct FString> TargetValues; // 0x8(0x10)
};

// Object: ScriptStruct Niagara.NiagaraID
// Size: 0x8 (Inherited: 0x0)
struct FNiagaraID
{
	int Index; // 0x0(0x4)
	int AcquireTag; // 0x4(0x4)
};

// Object: ScriptStruct Niagara.NiagaraSpawnInfo
// Size: 0x18 (Inherited: 0x0)
struct FNiagaraSpawnInfo
{
	int Count; // 0x0(0x4)
	float LOD1Scale; // 0x4(0x4)
	float LOD2Scale; // 0x8(0x4)
	float InterpStartDt; // 0xC(0x4)
	float IntervalDt; // 0x10(0x4)
	int SpawnGroup; // 0x14(0x4)
};

// Object: ScriptStruct Niagara.NiagaraMatrix
// Size: 0x40 (Inherited: 0x0)
struct FNiagaraMatrix
{
	struct FVector4 Row0; // 0x0(0x10)
	struct FVector4 Row1; // 0x10(0x10)
	struct FVector4 Row2; // 0x20(0x10)
	struct FVector4 Row3; // 0x30(0x10)
};

// Object: ScriptStruct Niagara.NiagaraTestStruct
// Size: 0x48 (Inherited: 0x0)
struct FNiagaraTestStruct
{
	struct FVector Vector1; // 0x0(0xC)
	struct FVector Vector2; // 0xC(0xC)
	struct FNiagaraTestStructInner InnerStruct1; // 0x18(0x18)
	struct FNiagaraTestStructInner InnerStruct2; // 0x30(0x18)
};

// Object: ScriptStruct Niagara.NiagaraTestStructInner
// Size: 0x18 (Inherited: 0x0)
struct FNiagaraTestStructInner
{
	struct FVector InnerVector1; // 0x0(0xC)
	struct FVector InnerVector2; // 0xC(0xC)
};

// Object: ScriptStruct Niagara.NiagaraParameterMap
// Size: 0x1 (Inherited: 0x0)
struct FNiagaraParameterMap
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Niagara.NiagaraNumeric
// Size: 0x1 (Inherited: 0x0)
struct FNiagaraNumeric
{
	uint8_t Pad_0x0[0x1]; // 0x0(0x1)
};

// Object: ScriptStruct Niagara.NiagaraBool
// Size: 0x4 (Inherited: 0x0)
struct FNiagaraBool
{
	int Value; // 0x0(0x4)
};

// Object: ScriptStruct Niagara.NiagaraInt32
// Size: 0x4 (Inherited: 0x0)
struct FNiagaraInt32
{
	int Value; // 0x0(0x4)
};

// Object: ScriptStruct Niagara.NiagaraFloat
// Size: 0x4 (Inherited: 0x0)
struct FNiagaraFloat
{
	float Value; // 0x0(0x4)
};

// Object: ScriptStruct Niagara.NiagaraUserRedirectionParameterStore
// Size: 0x138 (Inherited: 0xE8)
struct FNiagaraUserRedirectionParameterStore : FNiagaraParameterStore
{
	struct TMap<struct FNiagaraVariable, struct FNiagaraVariable> UserParameterRedirects; // 0xE8(0x50)
};

// Object: Class Niagara.NiagaraComponent
// Size: 0xB90 (Inherited: 0x9D0)
struct UNiagaraComponent : UFXSystemComponent
{
	struct UNiagaraSystem* Asset; // 0x9C8(0x8)
	struct FNiagaraUserRedirectionParameterStore OverrideParameters; // 0x9D0(0x138)
	uint8_t bForceSolo : 1; // 0xB08(0x1), Mask(0x1)
	uint8_t BitPad_0xB10_1 : 7; // 0xB10(0x1)
	uint8_t Pad_0xB11[0x1C]; // 0xB11(0x1C)
	uint8_t bAutoDestroy : 1; // 0xB2D(0x1), Mask(0x1)
	uint8_t bRenderingEnabled : 1; // 0xB2D(0x1), Mask(0x2)
	uint8_t bAutoManageAttachment : 1; // 0xB2D(0x1), Mask(0x4)
	uint8_t BitPad_0xB2D_3 : 5; // 0xB2D(0x1)
	uint8_t Pad_0xB2E[0x2]; // 0xB2E(0x2)
	struct FScriptMulticastDelegate OnSystemFinished; // 0xB30(0x10)
	struct TWeakObjectPtr<struct USceneComponent> AutoAttachParent; // 0xB40(0x8)
	struct FName AutoAttachSocketName; // 0xB48(0x8)
	uint8_t AutoAttachLocationRule; // 0xB50(0x1)
	uint8_t AutoAttachRotationRule; // 0xB51(0x1)
	uint8_t AutoAttachScaleRule; // 0xB52(0x1)
	uint8_t Pad_0xB53[0x1]; // 0xB53(0x1)
	int PreviewDetailLevel; // 0xB54(0x4)
	float PreviewLODDistance; // 0xB58(0x4)
	uint8_t bEnablePreviewDetailLevel : 1; // 0xB5C(0x1), Mask(0x1)
	uint8_t bEnablePreviewLODDistance : 1; // 0xB5C(0x1), Mask(0x2)
	uint8_t BitPad_0xB5C_2 : 6; // 0xB5C(0x1)
	uint8_t Pad_0xB5D[0x33]; // 0xB5D(0x33)


	// Object: Function Niagara.NiagaraComponent.SetSeekDelta
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb898
	// Params: [ Num(1) Size(0x4) ]
	void SetSeekDelta(float InSeekDelta);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13F0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Niagara.NiagaraComponent.SetRenderingEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb814
	// Params: [ Num(1) Size(0x1) ]
	void SetRenderingEnabled(bool bInRenderingEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025DF844
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E13F0
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Niagara.NiagaraComponent.SetPreviewLODDistance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb74c
	// Params: [ Num(2) Size(0x8) ]
	void SetPreviewLODDistance(bool bEnablePreviewLODDistance, float PreviewLODDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E1460
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025DF844
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025E13F0
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function Niagara.NiagaraComponent.SetPreviewDetailLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb684
	// Params: [ Num(2) Size(0x8) ]
	void SetPreviewDetailLevel(bool bEnablePreviewDetailLevel, int PreviewDetailLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E1408
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025E1460
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025DF844
	// [Call #14] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.SetPaused
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb600
	// Params: [ Num(1) Size(0x1) ]
	void SetPaused(bool bInPaused);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025DF8B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025E1408
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025E1460
	// [Call #14] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableVec4
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1026cb510
	// Params: [ Num(2) Size(0x20) ]
	void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0B24
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025DF8B0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025E1408

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableVec3
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026cb438
	// Params: [ Num(2) Size(0x1C) ]
	void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025DF214
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025E0B24
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x1025DF8B0

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableVec2
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026cb364
	// Params: [ Num(2) Size(0x18) ]
	void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0C3C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025DF214
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableQuat
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1026cb280
	// Params: [ Num(2) Size(0x20) ]
	void SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0A0C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025E0C3C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableLinearColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1026cb19c
	// Params: [ Num(2) Size(0x20) ]
	void SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025DF3B4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025E0A0C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableInt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cb0c4
	// Params: [ Num(2) Size(0x14) ]
	void SetNiagaraVariableInt(struct FString InVariableName, int InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0D60
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025DF3B4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableFloat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cafec
	// Params: [ Num(2) Size(0x14) ]
	void SetNiagaraVariableFloat(struct FString InVariableName, float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025DF078
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025E0D60
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableBool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026caf0c
	// Params: [ Num(2) Size(0x11) ]
	void SetNiagaraVariableBool(struct FString InVariableName, bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0E70
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1025DF078
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetNiagaraVariableActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cae48
	// Params: [ Num(2) Size(0x18) ]
	void SetNiagaraVariableActor(struct FString InVariableName, struct AActor* Actor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1025E0E70
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x1025DF078
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Niagara.NiagaraComponent.SetMaxSimTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cadcc
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxSimTime(float InMaxTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E1400
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1025E0E70
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.SetForceSolo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cad48
	// Params: [ Num(1) Size(0x1) ]
	void SetForceSolo(bool bInForceSolo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E1484
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E1400
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetDesiredAge
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026caccc
	// Params: [ Num(1) Size(0x4) ]
	void SetDesiredAge(float InDesiredAge);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E1484
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025E1400
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Niagara.NiagaraComponent.SetCanRenderWhileSeeking
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cac48
	// Params: [ Num(1) Size(0x1) ]
	void SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E13C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025E1484
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x1025E1400
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetAutoDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026cabc0
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoDestroy(bool bInAutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E13E0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025E13C4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025E1484
	// [Call #12] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.SetAutoAttachmentParameters
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026caa58
	// Params: [ Num(5) Size(0x13) ]
	void SetAutoAttachmentParameters(struct USceneComponent* Parent, struct FName SocketName, uint8_t LocationRule, uint8_t RotationRule, uint8_t ScaleRule);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025E14D8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca9dc
	// Params: [ Num(1) Size(0x8) ]
	void SetAsset(struct UNiagaraSystem* InAsset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025DF548
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1025E14D8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.SetAgeUpdateMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca960
	// Params: [ Num(1) Size(0x1) ]
	void SetAgeUpdateMode(uint8_t InAgeUpdateMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025DF548
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1025E14D8

	// Object: Function Niagara.NiagaraComponent.SeekToDesiredAge
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca8e4
	// Params: [ Num(1) Size(0x4) ]
	void SeekToDesiredAge(float InDesiredAge);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E13B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025DF548
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.ResetSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca8d0
	// Params: [ Num(0) Size(0x0) ]
	void ResetSystem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E13B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025DF548
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.ReinitializeSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca8bc
	// Params: [ Num(0) Size(0x0) ]
	void ReinitializeSystem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E13D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E13B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1025DF548
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraComponent.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca888
	// Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
	// [Call #1] RVA: 0x1025DF8C0
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1025E13D0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1025E13B4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025DF548
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.GetSeekDelta
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca854
	// Params: [ Num(1) Size(0x4) ]
	float GetSeekDelta();
	// [Call #1] RVA: 0x1025E13E8
	// [Call #2] RVA: 0x1025DF8C0
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E13D0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1025E13B4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025DF548
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.GetNiagaraParticleValueVec3_DebugOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca730
	// Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FVector> GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E104C
	// [Call #6] RVA: 0x10246DCBC
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x1025E13E8
	// [Call #15] RVA: 0x1025DF8C0
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1025E13D0

	// Object: Function Niagara.NiagaraComponent.GetNiagaraParticleValues_DebugOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca60c
	// Params: [ Num(3) Size(0x30) ]
	struct TArray<float> GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E11EC
	// [Call #6] RVA: 0x1026D01C0
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x1025E104C
	// [Call #19] RVA: 0x10246DCBC
	// [Call #20] RVA: 0x101F8C3A4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8C3A4
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x106C8459C

	// Object: Function Niagara.NiagaraComponent.GetNiagaraParticlePositions_DebugOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca53c
	// Params: [ Num(2) Size(0x20) ]
	struct TArray<struct FVector> GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1025E0F84
	// [Call #4] RVA: 0x10246DCBC
	// [Call #5] RVA: 0x101F8C3A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1025E11EC
	// [Call #15] RVA: 0x1026D01C0
	// [Call #16] RVA: 0x101F8C2E4
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8C2E4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.GetMaxSimTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca508
	// Params: [ Num(1) Size(0x4) ]
	float GetMaxSimTime();
	// [Call #1] RVA: 0x1025E13F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1025E0F84
	// [Call #5] RVA: 0x10246DCBC
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1025E11EC
	// [Call #16] RVA: 0x1026D01C0
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8C2E4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Niagara.NiagaraComponent.GetForceSolo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca4e8
	// Params: [ Num(1) Size(0x1) ]
	bool GetForceSolo();
	// [Call #1] RVA: 0x1025E13F8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1025E0F84
	// [Call #5] RVA: 0x10246DCBC
	// [Call #6] RVA: 0x101F8C3A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1025E11EC
	// [Call #16] RVA: 0x1026D01C0
	// [Call #17] RVA: 0x101F8C2E4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8C2E4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Niagara.NiagaraComponent.GetDesiredAge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca4b4
	// Params: [ Num(1) Size(0x4) ]
	float GetDesiredAge();
	// [Call #1] RVA: 0x1025E13BC
	// [Call #2] RVA: 0x1025E13F8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0F84
	// [Call #6] RVA: 0x10246DCBC
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025E11EC
	// [Call #17] RVA: 0x1026D01C0
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8C2E4

	// Object: Function Niagara.NiagaraComponent.GetAsset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca498
	// Params: [ Num(1) Size(0x8) ]
	struct UNiagaraSystem* GetAsset();
	// [Call #1] RVA: 0x1025E13BC
	// [Call #2] RVA: 0x1025E13F8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025E0F84
	// [Call #6] RVA: 0x10246DCBC
	// [Call #7] RVA: 0x101F8C3A4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8C3A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x1025E11EC
	// [Call #17] RVA: 0x1026D01C0
	// [Call #18] RVA: 0x101F8C2E4
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Niagara.NiagaraComponent.GetAgeUpdateMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1026ca464
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetAgeUpdateMode();
	// [Call #1] RVA: 0x1025E13AC
	// [Call #2] RVA: 0x1025E13BC
	// [Call #3] RVA: 0x1025E13F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E0F84
	// [Call #7] RVA: 0x10246DCBC
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.DeactivateImmediate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca448
	// Params: [ Num(0) Size(0x0) ]
	void DeactivateImmediate();
	// [Call #1] RVA: 0x1025E13AC
	// [Call #2] RVA: 0x1025E13BC
	// [Call #3] RVA: 0x1025E13F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1025E0F84
	// [Call #7] RVA: 0x10246DCBC
	// [Call #8] RVA: 0x101F8C3A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8C3A4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraComponent.AdvanceSimulationByTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca394
	// Params: [ Num(2) Size(0x8) ]
	void AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025DF884
	// [Call #6] RVA: 0x1025E13AC
	// [Call #7] RVA: 0x1025E13BC
	// [Call #8] RVA: 0x1025E13F8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x1025E0F84
	// [Call #12] RVA: 0x10246DCBC
	// [Call #13] RVA: 0x101F8C3A4
	// [Call #14] RVA: 0x101F8130C

	// Object: Function Niagara.NiagaraComponent.AdvanceSimulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026ca2dc
	// Params: [ Num(2) Size(0x8) ]
	void AdvanceSimulation(int TickCount, float TickDeltaSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1025DF864
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1025DF884
	// [Call #11] RVA: 0x1025E13AC
	// [Call #12] RVA: 0x1025E13BC
	// [Call #13] RVA: 0x1025E13F8
};

// Object: Class Niagara.MovieSceneNiagaraTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneNiagaraTrack : UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Object: Class Niagara.MovieSceneNiagaraParameterTrack
// Size: 0x98 (Inherited: 0x68)
struct UMovieSceneNiagaraParameterTrack : UMovieSceneNiagaraTrack
{
	struct FNiagaraVariable Parameter; // 0x68(0x30)
};

// Object: Class Niagara.MovieSceneNiagaraBoolParameterTrack
// Size: 0x98 (Inherited: 0x98)
struct UMovieSceneNiagaraBoolParameterTrack : UMovieSceneNiagaraParameterTrack
{
};

// Object: Class Niagara.MovieSceneNiagaraColorParameterTrack
// Size: 0x98 (Inherited: 0x98)
struct UMovieSceneNiagaraColorParameterTrack : UMovieSceneNiagaraParameterTrack
{
};

// Object: Class Niagara.MovieSceneNiagaraFloatParameterTrack
// Size: 0x98 (Inherited: 0x98)
struct UMovieSceneNiagaraFloatParameterTrack : UMovieSceneNiagaraParameterTrack
{
};

// Object: Class Niagara.MovieSceneNiagaraIntegerParameterTrack
// Size: 0x98 (Inherited: 0x98)
struct UMovieSceneNiagaraIntegerParameterTrack : UMovieSceneNiagaraParameterTrack
{
};

// Object: Class Niagara.MovieSceneNiagaraSystemSpawnSection
// Size: 0xB0 (Inherited: 0xB0)
struct UMovieSceneNiagaraSystemSpawnSection : UMovieSceneSection
{
};

// Object: Class Niagara.MovieSceneNiagaraSystemTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieSceneNiagaraSystemTrack : UMovieSceneNiagaraTrack
{
};

// Object: Class Niagara.MovieSceneNiagaraVectorParameterTrack
// Size: 0xA0 (Inherited: 0x98)
struct UMovieSceneNiagaraVectorParameterTrack : UMovieSceneNiagaraParameterTrack
{
	int ChannelsUsed; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
};

// Object: Class Niagara.NiagaraActor
// Size: 0x4B8 (Inherited: 0x4B0)
struct ANiagaraActor : AActor
{
	struct UNiagaraComponent* NiagaraComponent; // 0x4B0(0x8)
};

// Object: Class Niagara.NiagaraDataInterface
// Size: 0x38 (Inherited: 0x28)
struct UNiagaraDataInterface : UNiagaraDataInterfaceBase
{
	uint8_t Pad_0x28[0x10]; // 0x28(0x10)
};

// Object: Class Niagara.NiagaraDataInterfaceCurveBase
// Size: 0x58 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurveBase : UNiagaraDataInterface
{
	struct TArray<float> ShaderLUT; // 0x38(0x10)
	float LUTMinTime; // 0x48(0x4)
	float LUTMaxTime; // 0x4C(0x4)
	float LUTInvTimeRange; // 0x50(0x4)
	uint8_t bUseLUT : 1; // 0x54(0x1), Mask(0x1)
	uint8_t BitPad_0x54_1 : 7; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
};

// Object: Class Niagara.NiagaraDataInterfaceCollisionQuery
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceCollisionQuery : UNiagaraDataInterface
{
	uint8_t Pad_0x38[0x10]; // 0x38(0x10)
};

// Object: Class Niagara.NiagaraDataInterfaceColorCurve
// Size: 0x218 (Inherited: 0x58)
struct UNiagaraDataInterfaceColorCurve : UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve RedCurve; // 0x58(0x70)
	struct FRichCurve GreenCurve; // 0xC8(0x70)
	struct FRichCurve BlueCurve; // 0x138(0x70)
	struct FRichCurve AlphaCurve; // 0x1A8(0x70)
};

// Object: Class Niagara.NiagaraDataInterfaceCurlNoise
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceCurlNoise : UNiagaraDataInterface
{
	uint32_t Seed; // 0x38(0x4)
	uint8_t Pad_0x3C[0xC]; // 0x3C(0xC)
};

// Object: Class Niagara.NiagaraDataInterfaceCurve
// Size: 0xC8 (Inherited: 0x58)
struct UNiagaraDataInterfaceCurve : UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve Curve; // 0x58(0x70)
};

// Object: Class Niagara.NiagaraDataInterfaceParticleRead
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceParticleRead : UNiagaraDataInterface
{
	struct FString EmitterName; // 0x38(0x10)
};

// Object: Class Niagara.NiagaraDataInterfaceRWBase
// Size: 0xE0 (Inherited: 0x38)
struct UNiagaraDataInterfaceRWBase : UNiagaraDataInterface
{
	struct TSet<int> OutputShaderStages; // 0x38(0x50)
	struct TSet<int> IterationShaderStages; // 0x88(0x50)
	uint8_t Pad_0xD8[0x8]; // 0xD8(0x8)
};

// Object: Class Niagara.NiagaraDataInterfaceSimpleCounter
// Size: 0x38 (Inherited: 0x38)
struct UNiagaraDataInterfaceSimpleCounter : UNiagaraDataInterface
{
};

// Object: Class Niagara.NiagaraDataInterfaceSkeletalMesh
// Size: 0xB0 (Inherited: 0x38)
struct UNiagaraDataInterfaceSkeletalMesh : UNiagaraDataInterface
{
	struct USkeletalMesh* DefaultMesh; // 0x38(0x8)
	struct AActor* Source; // 0x40(0x8)
	struct USkeletalMeshComponent* SourceComponent; // 0x48(0x8)
	uint8_t SkinningMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	struct TArray<struct FName> SamplingRegions; // 0x58(0x10)
	int WholeMeshLOD; // 0x68(0x4)
	uint8_t Pad_0x6C[0x4]; // 0x6C(0x4)
	struct TArray<struct FName> SpecificBones; // 0x70(0x10)
	struct TArray<struct FName> SpecificSockets; // 0x80(0x10)
	bool bUseTriangleSampling; // 0x90(0x1)
	bool bUseVertexSampling; // 0x91(0x1)
	bool bUseSkeletonSampling; // 0x92(0x1)
	uint8_t Pad_0x93[0x5]; // 0x93(0x5)
	struct FString SourceComponentKeyWord; // 0x98(0x10)
	bool bForceUseDefaultMesh; // 0xA8(0x1)
	uint8_t Pad_0xA9[0x7]; // 0xA9(0x7)
};

// Object: Class Niagara.NiagaraDataInterfaceSpline
// Size: 0x50 (Inherited: 0x38)
struct UNiagaraDataInterfaceSpline : UNiagaraDataInterface
{
	struct AActor* Source; // 0x38(0x8)
	struct TArray<struct FVector> SplineKeyframePoints; // 0x40(0x10)
};

// Object: Class Niagara.NiagaraDataInterfaceStaticMesh
// Size: 0x68 (Inherited: 0x38)
struct UNiagaraDataInterfaceStaticMesh : UNiagaraDataInterface
{
	struct UStaticMesh* DefaultMesh; // 0x38(0x8)
	struct AActor* Source; // 0x40(0x8)
	struct UStaticMeshComponent* SourceComponent; // 0x48(0x8)
	struct FNDIStaticMeshSectionFilter SectionFilter; // 0x50(0x10)
	uint8_t Pad_0x60[0x8]; // 0x60(0x8)
};

// Object: Class Niagara.NiagaraDataInterfaceTexture
// Size: 0x40 (Inherited: 0x38)
struct UNiagaraDataInterfaceTexture : UNiagaraDataInterface
{
	struct UTexture* Texture; // 0x38(0x8)
};

// Object: Class Niagara.NiagaraDataInterfaceVector2DCurve
// Size: 0x138 (Inherited: 0x58)
struct UNiagaraDataInterfaceVector2DCurve : UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve; // 0x58(0x70)
	struct FRichCurve YCurve; // 0xC8(0x70)
};

// Object: Class Niagara.NiagaraDataInterfaceVector4Curve
// Size: 0x218 (Inherited: 0x58)
struct UNiagaraDataInterfaceVector4Curve : UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve; // 0x58(0x70)
	struct FRichCurve YCurve; // 0xC8(0x70)
	struct FRichCurve ZCurve; // 0x138(0x70)
	struct FRichCurve WCurve; // 0x1A8(0x70)
};

// Object: Class Niagara.NiagaraDataInterfaceVectorCurve
// Size: 0x1A8 (Inherited: 0x58)
struct UNiagaraDataInterfaceVectorCurve : UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve; // 0x58(0x70)
	struct FRichCurve YCurve; // 0xC8(0x70)
	struct FRichCurve ZCurve; // 0x138(0x70)
};

// Object: Class Niagara.NiagaraDataInterfaceVectorField
// Size: 0x48 (Inherited: 0x38)
struct UNiagaraDataInterfaceVectorField : UNiagaraDataInterface
{
	struct UVectorField* Field; // 0x38(0x8)
	bool bTileX; // 0x40(0x1)
	bool bTileY; // 0x41(0x1)
	bool bTileZ; // 0x42(0x1)
	uint8_t Pad_0x43[0x5]; // 0x43(0x5)
};

// Object: Class Niagara.NiagaraRendererProperties
// Size: 0x30 (Inherited: 0x28)
struct UNiagaraRendererProperties : UNiagaraMergeable
{
	int SortOrderHint; // 0x28(0x4)
	bool bIsEnabled; // 0x2C(0x1)
	uint8_t Pad_0x2D[0x3]; // 0x2D(0x3)
};

// Object: Class Niagara.NiagaraDecalRendererProperties
// Size: 0x3A0 (Inherited: 0x30)
struct UNiagaraDecalRendererProperties : UNiagaraRendererProperties
{
	struct UMaterialInterface* Material; // 0x30(0x8)
	float DecalScreenSizeFade; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x40(0x90)
	struct FNiagaraVariableAttributeBinding DecalOrientationBinding; // 0xD0(0x90)
	struct FNiagaraVariableAttributeBinding DecalSizeBinding; // 0x160(0x90)
	struct FNiagaraVariableAttributeBinding DecalFadeBinding; // 0x1F0(0x90)
	struct FNiagaraVariableAttributeBinding DecalSortOrderBinding; // 0x280(0x90)
	struct FNiagaraVariableAttributeBinding DecalVisibleBinding; // 0x310(0x90)
};

// Object: Class Niagara.NiagaraEditorDataBase
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraEditorDataBase : UObject
{
};

// Object: Class Niagara.NiagaraEmitter
// Size: 0x170 (Inherited: 0x28)
struct UNiagaraEmitter : UObject
{
	bool bLocalSpace; // 0x28(0x1)
	bool bBoneSpace; // 0x29(0x1)
	bool bDeterminism; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x1]; // 0x2B(0x1)
	int RandomSeed; // 0x2C(0x4)
	struct FNiagaraEmitterScriptProperties UpdateScriptProps; // 0x30(0x28)
	struct FNiagaraEmitterScriptProperties SpawnScriptProps; // 0x58(0x28)
	struct FNiagaraEmitterScriptProperties EmitterSpawnScriptProps; // 0x80(0x28)
	struct FNiagaraEmitterScriptProperties EmitterUpdateScriptProps; // 0xA8(0x28)
	uint8_t bHasPendingFallbackEmitterChange : 1; // 0xD0(0x1), Mask(0x1)
	uint8_t bIsFallbackEmitter : 1; // 0xD0(0x1), Mask(0x2)
	uint8_t BitPad_0xD0_2 : 6; // 0xD0(0x1)
	uint8_t Pad_0xD1[0x7]; // 0xD1(0x7)
	struct UNiagaraEmitter* CPUFallbackEmitter; // 0xD8(0x8)
	uint8_t SimTarget; // 0xE0(0x1)
	uint8_t bUseFallbackEmitter : 1; // 0xE1(0x1), Mask(0x1)
	uint8_t BitPad_0xE1_1 : 7; // 0xE1(0x1)
	uint8_t Pad_0xE2[0x2]; // 0xE2(0x2)
	struct FBox FixedBounds; // 0xE4(0x1C)
	int MinDetailLevel; // 0x100(0x4)
	int MaxDetailLevel; // 0x104(0x4)
	uint8_t bInterpolatedSpawning : 1; // 0x108(0x1), Mask(0x1)
	uint8_t bFixedBounds : 1; // 0x108(0x1), Mask(0x2)
	uint8_t bUseMinDetailLevel : 1; // 0x108(0x1), Mask(0x4)
	uint8_t bUseMaxDetailLevel : 1; // 0x108(0x1), Mask(0x8)
	uint8_t bRequiresPersistentIDs : 1; // 0x108(0x1), Mask(0x10)
	uint8_t BitPad_0x108_5 : 3; // 0x108(0x1)
	uint8_t Pad_0x109[0x3]; // 0x109(0x3)
	float MaxDeltaTimePerTick; // 0x10C(0x4)
	uint8_t bLimitDeltaTime : 1; // 0x110(0x1), Mask(0x1)
	uint8_t BitPad_0x110_1 : 7; // 0x110(0x1)
	uint8_t Pad_0x111[0x7]; // 0x111(0x7)
	struct FString UniqueEmitterName; // 0x118(0x10)
	struct TArray<struct UNiagaraRendererProperties*> RendererProperties; // 0x128(0x10)
	struct TArray<struct FNiagaraEventScriptProperties> EventHandlerScriptProps; // 0x138(0x10)
	struct UNiagaraScript* GPUComputeScript; // 0x148(0x8)
	struct TArray<struct FName> SharedEventGeneratorIds; // 0x150(0x10)
	struct UNiagaraEmitter* Parent; // 0x160(0x8)
	struct UNiagaraEmitter* ParentAtLastMerge; // 0x168(0x8)
};

// Object: Class Niagara.NiagaraEventReceiverEmitterAction
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraEventReceiverEmitterAction : UObject
{
};

// Object: Class Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles
// Size: 0x30 (Inherited: 0x28)
struct UNiagaraEventReceiverEmitterAction_SpawnParticles : UNiagaraEventReceiverEmitterAction
{
	uint32_t NumParticles; // 0x28(0x4)
	uint8_t Pad_0x2C[0x4]; // 0x2C(0x4)
};

// Object: Class Niagara.NiagaraFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraFunctionLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttached
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d3814
	// Params: [ Num(8) Size(0x40) ]
	struct UNiagaraComponent* SpawnSystemAttached(struct UNiagaraSystem* SystemTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bAutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269494C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d36a0
	// Params: [ Num(6) Size(0x38) ]
	struct UNiagaraComponent* SpawnSystemAtLocation(struct UObject* WorldContextObject, struct UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, bool bAutoDestroy);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102694818
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d3594
	// Params: [ Num(3) Size(0x20) ]
	void OverrideSystemUserVariableStaticMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMeshComponent* StaticMeshComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102694DF8
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMesh
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d3488
	// Params: [ Num(3) Size(0x20) ]
	void OverrideSystemUserVariableStaticMesh(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMesh* StaticMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1026951AC
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x102694DF8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableSkeletalMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d337c
	// Params: [ Num(3) Size(0x20) ]
	void OverrideSystemUserVariableSkeletalMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct USkeletalMeshComponent* SkeletalMeshComponent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x102695538
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x1026951AC
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraFunctionLibrary.IsAllowNiagaraGPUParticles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d3300
	// Params: [ Num(2) Size(0x9) ]
	bool IsAllowNiagaraGPUParticles(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x102694DC0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102695538
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.GetReadbackParticleCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d32cc
	// Params: [ Num(1) Size(0x4) ]
	int GetReadbackParticleCount();
	// [Call #1] RVA: 0x102695920
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x102694DC0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102695538
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.GetNiagaraParameterCollection
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d3218
	// Params: [ Num(3) Size(0x18) ]
	struct UNiagaraParameterCollectionInstance* GetNiagaraParameterCollection(struct UObject* WorldContextObject, struct UNiagaraParameterCollection* Collection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1026958C4
	// [Call #6] RVA: 0x102695920
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x102694DC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x102695538
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Niagara.NiagaraFunctionLibrary.GetGPUReadbackDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d31e4
	// Params: [ Num(1) Size(0x4) ]
	int GetGPUReadbackDelay();
	// [Call #1] RVA: 0x102695940
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x1026958C4
	// [Call #7] RVA: 0x102695920
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102694DC0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.GetGPUParticleCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d31b0
	// Params: [ Num(1) Size(0x4) ]
	int GetGPUParticleCount();
	// [Call #1] RVA: 0x102695950
	// [Call #2] RVA: 0x102695940
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1026958C4
	// [Call #8] RVA: 0x102695920
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x102694DC0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.GetDeadParticleCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d317c
	// Params: [ Num(1) Size(0x4) ]
	int GetDeadParticleCount();
	// [Call #1] RVA: 0x102695930
	// [Call #2] RVA: 0x102695950
	// [Call #3] RVA: 0x102695940
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1026958C4
	// [Call #9] RVA: 0x102695920
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102694DC0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraFunctionLibrary.GetCPUParticleCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1026d3148
	// Params: [ Num(1) Size(0x4) ]
	int GetCPUParticleCount();
	// [Call #1] RVA: 0x102695910
	// [Call #2] RVA: 0x102695930
	// [Call #3] RVA: 0x102695950
	// [Call #4] RVA: 0x102695940
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1026958C4
	// [Call #10] RVA: 0x102695920
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x102694DC0
};

// Object: Class Niagara.NiagaraLightRendererProperties
// Size: 0x3A0 (Inherited: 0x30)
struct UNiagaraLightRendererProperties : UNiagaraRendererProperties
{
	uint8_t bUseInverseSquaredFalloff : 1; // 0x2D(0x1), Mask(0x1)
	uint8_t bAffectsTranslucency : 1; // 0x2D(0x1), Mask(0x2)
	uint8_t bOverrideRenderingEnabled : 1; // 0x2D(0x1), Mask(0x4)
	float RadiusScale; // 0x30(0x4)
	struct FVector ColorAdd; // 0x34(0xC)
	struct FNiagaraVariableAttributeBinding LightRenderingEnabledBinding; // 0x40(0x90)
	struct FNiagaraVariableAttributeBinding LightExponentBinding; // 0xD0(0x90)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x160(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x1F0(0x90)
	struct FNiagaraVariableAttributeBinding RadiusBinding; // 0x280(0x90)
	struct FNiagaraVariableAttributeBinding VolumetricScatteringBinding; // 0x310(0x90)
};

// Object: Class Niagara.NiagaraMeshRendererProperties
// Size: 0x718 (Inherited: 0x30)
struct UNiagaraMeshRendererProperties : UNiagaraRendererProperties
{
	struct UStaticMesh* ParticleMesh; // 0x30(0x8)
	uint8_t SortMode; // 0x38(0x1)
	uint8_t bOverrideMaterials : 1; // 0x39(0x1), Mask(0x1)
	uint8_t bSortOnlyWhenTranslucent : 1; // 0x39(0x1), Mask(0x2)
	uint8_t BitPad_0x39_2 : 6; // 0x39(0x1)
	uint8_t Pad_0x3A[0x6]; // 0x3A(0x6)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x40(0x10)
	uint8_t FacingMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x7]; // 0x51(0x7)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x58(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0xE8(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x178(0x90)
	struct FNiagaraVariableAttributeBinding MeshOrientationBinding; // 0x208(0x90)
	struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x298(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x328(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x3B8(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x448(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x4D8(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x568(0x90)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x5F8(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x688(0x90)
};

// Object: Class Niagara.NiagaraParameterCollectionInstance
// Size: 0x128 (Inherited: 0x28)
struct UNiagaraParameterCollectionInstance : UObject
{
	struct UNiagaraParameterCollection* Collection; // 0x28(0x8)
	struct TArray<struct FNiagaraVariable> OverridenParameters; // 0x30(0x10)
	struct FNiagaraParameterStore ParameterStorage; // 0x40(0xE8)


	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetVectorParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4d90
	// Params: [ Num(2) Size(0x1C) ]
	void SetVectorParameter(struct FString InVariableName, struct FVector InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C3C8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x10519022C

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetVector4Parameter
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4ca0
	// Params: [ Num(2) Size(0x20) ]
	void SetVector4Parameter(struct FString InVariableName, struct FVector4& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C4D0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C3C8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetVector2DParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4bcc
	// Params: [ Num(2) Size(0x18) ]
	void SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C2D0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C4D0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetQuatParameter
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4ae8
	// Params: [ Num(2) Size(0x20) ]
	void SetQuatParameter(struct FString InVariableName, struct FQuat& InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C6D0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C2D0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetIntParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4a10
	// Params: [ Num(2) Size(0x14) ]
	void SetIntParameter(struct FString InVariableName, int InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C1E0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C6D0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetFloatParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4938
	// Params: [ Num(2) Size(0x14) ]
	void SetFloatParameter(struct FString InVariableName, float InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C0F0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C1E0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetColorParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4860
	// Params: [ Num(2) Size(0x20) ]
	void SetColorParameter(struct FString InVariableName, struct FLinearColor InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C5C4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C0F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10269C1E0

	// Object: Function Niagara.NiagaraParameterCollectionInstance.SetBoolParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4780
	// Params: [ Num(2) Size(0x11) ]
	void SetBoolParameter(struct FString InVariableName, bool InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10269C000
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10269C5C4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetVectorParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d46d0
	// Params: [ Num(2) Size(0x1C) ]
	struct FVector GetVectorParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BC00
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10269C000
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10269C5C4
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetVector4Parameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4620
	// Params: [ Num(2) Size(0x20) ]
	struct FVector4 GetVector4Parameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BD00
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BC00
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10269C000
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetVector2DParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d4574
	// Params: [ Num(2) Size(0x18) ]
	struct FVector2D GetVector2DParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BB10
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BD00
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269BC00
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetQuatParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d44c0
	// Params: [ Num(2) Size(0x20) ]
	struct FQuat GetQuatParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BE14
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BB10
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269BD00
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetIntParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4418
	// Params: [ Num(2) Size(0x14) ]
	int GetIntParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BA34
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BE14
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269BB10
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetFloatParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4370
	// Params: [ Num(2) Size(0x14) ]
	float GetFloatParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269B948
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BA34
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269BE14
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetColorParameter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1026d42c0
	// Params: [ Num(2) Size(0x20) ]
	struct FLinearColor GetColorParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269BEFC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269B948
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269BA34
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Niagara.NiagaraParameterCollectionInstance.GetBoolParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d4218
	// Params: [ Num(2) Size(0x11) ]
	bool GetBoolParameter(struct FString InVariableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269B7DC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10269BEFC
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10269B948
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
};

// Object: Class Niagara.NiagaraParameterCollection
// Size: 0x58 (Inherited: 0x28)
struct UNiagaraParameterCollection : UObject
{
	struct FName Namespace; // 0x28(0x8)
	struct TArray<struct FNiagaraVariable> Parameters; // 0x30(0x10)
	struct UNiagaraParameterCollectionInstance* DefaultInstance; // 0x40(0x8)
	struct FGuid CompileId; // 0x48(0x10)
};

// Object: Class Niagara.NiagaraPreviewBase
// Size: 0x4B0 (Inherited: 0x4B0)
struct ANiagaraPreviewBase : AActor
{

	// Object: Function Niagara.NiagaraPreviewBase.SetSystem
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x8) ]
	void SetSystem(struct UNiagaraSystem* InSystem);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Niagara.NiagaraPreviewBase.SetLabelText
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(2) Size(0x30) ]
	void SetLabelText(struct FText& InXAxisText, struct FText& InYAxisText);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

// Object: Class Niagara.NiagaraPreviewAxis
// Size: 0x28 (Inherited: 0x28)
struct UNiagaraPreviewAxis : UObject
{

	// Object: Function Niagara.NiagaraPreviewAxis.Num
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1026d5bb8
	// Params: [ Num(1) Size(0x4) ]
	int Num();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x105190870

	// Object: Function Niagara.NiagaraPreviewAxis.ApplyToPreview
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1026d5a44
	// Params: [ Num(4) Size(0x20) ]
	void ApplyToPreview(struct UNiagaraComponent* PreviewComponent, int PreviewIndex, bool bIsXAxis, struct FString& OutLabelText);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamBase
// Size: 0x40 (Inherited: 0x28)
struct UNiagaraPreviewAxis_InterpParamBase : UNiagaraPreviewAxis
{
	struct FString Param; // 0x28(0x10)
	int Count; // 0x38(0x4)
	uint8_t Pad_0x3C[0x4]; // 0x3C(0x4)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamInt32
// Size: 0x48 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamInt32 : UNiagaraPreviewAxis_InterpParamBase
{
	int Min; // 0x3C(0x4)
	int Max; // 0x40(0x4)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamFloat
// Size: 0x48 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamFloat : UNiagaraPreviewAxis_InterpParamBase
{
	float Min; // 0x3C(0x4)
	float Max; // 0x40(0x4)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamVector2D
// Size: 0x50 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector2D : UNiagaraPreviewAxis_InterpParamBase
{
	struct FVector2D Min; // 0x3C(0x8)
	struct FVector2D Max; // 0x44(0x8)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamVector
// Size: 0x58 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector : UNiagaraPreviewAxis_InterpParamBase
{
	struct FVector Min; // 0x3C(0xC)
	struct FVector Max; // 0x48(0xC)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamVector4
// Size: 0x60 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamVector4 : UNiagaraPreviewAxis_InterpParamBase
{
	struct FVector4 Min; // 0x40(0x10)
	struct FVector4 Max; // 0x50(0x10)
};

// Object: Class Niagara.NiagaraPreviewAxis_InterpParamLinearColor
// Size: 0x60 (Inherited: 0x40)
struct UNiagaraPreviewAxis_InterpParamLinearColor : UNiagaraPreviewAxis_InterpParamBase
{
	struct FLinearColor Min; // 0x3C(0x10)
	struct FLinearColor Max; // 0x4C(0x10)
};

// Object: Class Niagara.NiagaraPreviewGrid
// Size: 0x500 (Inherited: 0x4B0)
struct ANiagaraPreviewGrid : AActor
{
	struct UNiagaraSystem* System; // 0x4B0(0x8)
	uint8_t ResetMode; // 0x4B8(0x1)
	uint8_t Pad_0x4B9[0x7]; // 0x4B9(0x7)
	struct UNiagaraPreviewAxis* PreviewAxisX; // 0x4C0(0x8)
	struct UNiagaraPreviewAxis* PreviewAxisY; // 0x4C8(0x8)
	struct ANiagaraPreviewBase* PreviewClass; // 0x4D0(0x8)
	float SpacingX; // 0x4D8(0x4)
	float SpacingY; // 0x4DC(0x4)
	int NumX; // 0x4E0(0x4)
	int NumY; // 0x4E4(0x4)
	struct TArray<struct UChildActorComponent*> PreviewComponents; // 0x4E8(0x10)
	uint8_t Pad_0x4F8[0x8]; // 0x4F8(0x8)


	// Object: Function Niagara.NiagaraPreviewGrid.DeactivatePreviews
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d652c
	// Params: [ Num(0) Size(0x0) ]
	void DeactivatePreviews();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x10508F76C

	// Object: Function Niagara.NiagaraPreviewGrid.ActivatePreviews
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026d64a8
	// Params: [ Num(1) Size(0x1) ]
	void ActivatePreviews(bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10269DFD4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10508F76C
};

// Object: Class Niagara.NiagaraRibbonRendererProperties
// Size: 0x868 (Inherited: 0x30)
struct UNiagaraRibbonRendererProperties : UNiagaraRendererProperties
{
	struct UMaterialInterface* Material; // 0x30(0x8)
	uint8_t FacingMode; // 0x38(0x1)
	uint8_t Pad_0x39[0x3]; // 0x39(0x3)
	float UV0TilingDistance; // 0x3C(0x4)
	struct FVector2D UV0Scale; // 0x40(0x8)
	struct FVector2D UV0Offset; // 0x48(0x8)
	uint8_t UV0AgeOffsetMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	float UV1TilingDistance; // 0x54(0x4)
	struct FVector2D UV1Scale; // 0x58(0x8)
	struct FVector2D UV1Offset; // 0x60(0x8)
	uint8_t UV1AgeOffsetMode; // 0x68(0x1)
	uint8_t DrawDirection; // 0x69(0x1)
	uint8_t Pad_0x6A[0x2]; // 0x6A(0x2)
	float CurveTension; // 0x6C(0x4)
	uint8_t TessellationMode; // 0x70(0x1)
	uint8_t Pad_0x71[0x3]; // 0x71(0x3)
	int TessellationFactor; // 0x74(0x4)
	bool bUseConstantFactor; // 0x78(0x1)
	uint8_t Pad_0x79[0x3]; // 0x79(0x3)
	float TessellationAngle; // 0x7C(0x4)
	bool bScreenSpaceTessellation; // 0x80(0x1)
	uint8_t Pad_0x81[0x7]; // 0x81(0x7)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x88(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x118(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x1A8(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x238(0x90)
	struct FNiagaraVariableAttributeBinding RibbonTwistBinding; // 0x2C8(0x90)
	struct FNiagaraVariableAttributeBinding RibbonWidthBinding; // 0x358(0x90)
	struct FNiagaraVariableAttributeBinding RibbonFacingBinding; // 0x3E8(0x90)
	struct FNiagaraVariableAttributeBinding RibbonIdBinding; // 0x478(0x90)
	struct FNiagaraVariableAttributeBinding RibbonLinkOrderBinding; // 0x508(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x598(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x628(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x6B8(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x748(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x7D8(0x90)
};

// Object: Class Niagara.NiagaraScript
// Size: 0x680 (Inherited: 0x28)
struct UNiagaraScript : UObject
{
	uint8_t Usage; // 0x28(0x1)
	uint8_t Pad_0x29[0x3]; // 0x29(0x3)
	int UsageIndex; // 0x2C(0x4)
	struct FGuid UsageId; // 0x30(0x10)
	struct FNiagaraParameterStore RapidIterationParameters; // 0x40(0xE8)
	struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStoreCPU; // 0x128(0x108)
	struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStoreGPU; // 0x230(0x108)
	struct FNiagaraVMExecutableDataId CachedScriptVMId; // 0x338(0x50)
	struct FNiagaraVMExecutableDataId LastGeneratedVMId; // 0x388(0x50)
	uint8_t Pad_0x3D8[0x180]; // 0x3D8(0x180)
	struct FNiagaraVMExecutableData CachedScriptVM; // 0x558(0x108)
	struct TArray<struct UNiagaraParameterCollection*> CachedParameterCollectionReferences; // 0x660(0x10)
	struct TArray<struct FNiagaraScriptDataInterfaceInfo> CachedDefaultDataInterfaces; // 0x670(0x10)


	// Object: Function Niagara.NiagaraScript.OnCompilationComplete
	// Flags: [Final|Native|Public]
	// Offset: 0x1026d6ee4
	// Params: [ Num(0) Size(0x0) ]
	void OnCompilationComplete();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10518366C
	// [Call #5] RVA: 0x10518366C
	// [Call #6] RVA: 0x101F60CEC
	// [Call #7] RVA: 0x10518366C
	// [Call #8] RVA: 0x104FD0740
	// [Call #9] RVA: 0x1036A6C08
	// [Call #10] RVA: 0x105093FD0
};

// Object: Class Niagara.NiagaraScriptSourceBase
// Size: 0x48 (Inherited: 0x28)
struct UNiagaraScriptSourceBase : UObject
{
	uint8_t Pad_0x28[0x20]; // 0x28(0x20)
};

// Object: Class Niagara.NiagaraSettings
// Size: 0x68 (Inherited: 0x38)
struct UNiagaraSettings : UDeveloperSettings
{
	struct TArray<struct FSoftObjectPath> AdditionalParameterTypes; // 0x38(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalPayloadTypes; // 0x48(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalParameterEnums; // 0x58(0x10)
};

// Object: Class Niagara.NiagaraSpriteRendererProperties
// Size: 0xA08 (Inherited: 0x30)
struct UNiagaraSpriteRendererProperties : UNiagaraRendererProperties
{
	struct UMaterialInterface* Material; // 0x30(0x8)
	uint8_t Alignment; // 0x38(0x1)
	uint8_t FacingMode; // 0x39(0x1)
	uint8_t Pad_0x3A[0x2]; // 0x3A(0x2)
	struct FVector CustomFacingVectorMask; // 0x3C(0xC)
	struct FVector2D PivotInUVSpace; // 0x48(0x8)
	uint8_t SortMode; // 0x50(0x1)
	uint8_t Pad_0x51[0x3]; // 0x51(0x3)
	struct FVector2D SubImageSize; // 0x54(0x8)
	uint8_t bSubImageBlend : 1; // 0x5C(0x1), Mask(0x1)
	uint8_t bRemoveHMDRollInVR : 1; // 0x5C(0x1), Mask(0x2)
	uint8_t bSortOnlyWhenTranslucent : 1; // 0x5C(0x1), Mask(0x4)
	uint8_t BitPad_0x5C_3 : 5; // 0x5C(0x1)
	uint8_t Pad_0x5D[0x3]; // 0x5D(0x3)
	float MinFacingCameraBlendDistance; // 0x60(0x4)
	float MaxFacingCameraBlendDistance; // 0x64(0x4)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x68(0x90)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0xF8(0x90)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x188(0x90)
	struct FNiagaraVariableAttributeBinding SpriteRotationBinding; // 0x218(0x90)
	struct FNiagaraVariableAttributeBinding SpriteSizeBinding; // 0x2A8(0x90)
	struct FNiagaraVariableAttributeBinding SpriteFacingBinding; // 0x338(0x90)
	struct FNiagaraVariableAttributeBinding SpriteAlignmentBinding; // 0x3C8(0x90)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x458(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x4E8(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x578(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x608(0x90)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x698(0x90)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x728(0x90)
	struct FNiagaraVariableAttributeBinding UVScaleBinding; // 0x7B8(0x90)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x848(0x90)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x8D8(0x90)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x968(0x90)
	uint8_t Pad_0x9F8[0x10]; // 0x9F8(0x10)
};

// Object: Class Niagara.NiagaraSystem
// Size: 0x1E8 (Inherited: 0x28)
struct UNiagaraSystem : UFXSystemAsset
{
	bool bDumpDebugSystemInfo; // 0x28(0x1)
	bool bDumpDebugEmitterInfo; // 0x29(0x1)
	uint8_t bFixedBounds : 1; // 0x2A(0x1), Mask(0x1)
	uint8_t BitPad_0x2A_1 : 7; // 0x2A(0x1)
	uint8_t Pad_0x2B[0x5]; // 0x2B(0x5)
	struct TArray<struct FNiagaraEmitterHandle> EmitterHandles; // 0x30(0x10)
	struct TArray<struct UNiagaraParameterCollectionInstance*> ParameterCollectionOverrides; // 0x40(0x10)
	struct UNiagaraScript* SystemSpawnScript; // 0x50(0x8)
	struct UNiagaraScript* SystemUpdateScript; // 0x58(0x8)
	struct TArray<struct FNiagaraEmitterSpawnAttributes> EmitterSpawnAttributes; // 0x60(0x10)
	struct FNiagaraUserRedirectionParameterStore ExposedParameters; // 0x70(0x138)
	struct FBox FixedBounds; // 0x1A8(0x1C)
	bool bAutoDeactivate; // 0x1C4(0x1)
	uint8_t Pad_0x1C5[0x3]; // 0x1C5(0x3)
	float WarmupTime; // 0x1C8(0x4)
	int WarmupTickCount; // 0x1CC(0x4)
	float WarmupTickDelta; // 0x1D0(0x4)
	bool bHasSystemScriptDIsWithPerInstanceData; // 0x1D4(0x1)
	uint8_t Pad_0x1D5[0x3]; // 0x1D5(0x3)
	struct TArray<struct FName> UserDINamesReadInSystemScripts; // 0x1D8(0x10)
};

