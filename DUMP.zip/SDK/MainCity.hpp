#pragma once

#include <cstdint>

// Object: Enum MainCity.ECarryBackAnimState
enum class ECarryBackAnimState : uint8_t
{
	None = 0,
	CarryBack = 1,
	BeCarryBack = 2,
	ECarryBackAnimState_MAX = 3
};

// Object: Enum MainCity.EHoldingHandsIKMode
enum class EHoldingHandsIKMode : uint8_t
{
	HH_Default = 0,
	HH_SIMPLEIK = 1,
	HH_MAX = 2
};

// Object: Enum MainCity.ESeesawState
enum class ESeesawState : uint8_t
{
	Seesaw_None = 0,
	Seesaw_Idle = 1,
	Seesaw_InMatch = 2,
	Seesaw_EnterField = 3,
	Seesaw_InBattle = 4,
	Seesaw_InBattle_SpeedUp = 5,
	Seesaw_Settle = 6,
	Seesaw_Finished = 7,
	Seesaw_MAX = 8
};

// Object: Enum MainCity.ESeesawSeatState
enum class ESeesawSeatState : uint8_t
{
	Seat_Idle = 0,
	Seat_Waiting = 1,
	Seat_Entering = 2,
	Seat_Entered = 3,
	Seat_Exiting = 4,
	Seat_MAX = 5
};

// Object: Class MainCity.CarryBackMCAnimInstance
// Size: 0x1830 (Inherited: 0x17E0)
struct UCarryBackMCAnimInstance : UCharacterAnimStateBase
{
	struct UBlendSpace* BS_CarryBackMove; // 0x17E0(0x8)
	struct UBlendSpace* BS_beCarryBackMove; // 0x17E8(0x8)
	uint8_t CurrentCarryBackState; // 0x17F0(0x1)
	uint8_t Pad_0x17F1[0x7]; // 0x17F1(0x7)
	float CarryBackTimeAccumulator; // 0x17F8(0x4)
	bool bCarryBackState; // 0x17FC(0x1)
	bool bBeCarryBackState; // 0x17FD(0x1)
	uint8_t Pad_0x17FE[0x2]; // 0x17FE(0x2)
	int SubStateID; // 0x1800(0x4)
	uint8_t Pad_0x1804[0x4]; // 0x1804(0x4)
	struct ASTExtraBaseCharacter* AttachParentCharacter; // 0x1808(0x8)
	struct FVector AttachParentPawnMoveVelocity; // 0x1810(0xC)
	struct FVector PreAnimVelocity; // 0x181C(0xC)
	struct USTExtraAnimInstanceBase* MainInstance; // 0x1828(0x8)


	// Object: Function MainCity.CarryBackMCAnimInstance.HandlePlayerPoseChange
	// Flags: [Native|Public]
	// Offset: 0x1027ab650
	// Params: [ Num(2) Size(0x2) ]
	void HandlePlayerPoseChange(enum class ESTEPoseState LastPose, enum class ESTEPoseState NewPose);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10508F76C
	// [Call #8] RVA: 0x1027ABF58
};

// Object: Class MainCity.CharLocomotionMCAnimInstance
// Size: 0x1A40 (Inherited: 0x17E0)
struct UCharLocomotionMCAnimInstance : UCharacterAnimStateBase
{
	struct UBlendSpace* BS_MovementStand; // 0x17E0(0x8)
	struct UBlendSpace* BS_MovementCrouch; // 0x17E8(0x8)
	struct UBlendSpace* BS_MovementProne; // 0x17F0(0x8)
	struct UBlendSpace* BS_MovementStandDest; // 0x17F8(0x8)
	struct UBlendSpace* BS_MovementCrouchDest; // 0x1800(0x8)
	struct UBlendSpace* BS_MovementProneDest; // 0x1808(0x8)
	struct UAnimSequence* AS_StandScopeBlend; // 0x1810(0x8)
	struct UAnimSequence* AS_CrouchScopeBlend; // 0x1818(0x8)
	struct TMap<struct FName, float> MovementStand_SourceTransTime; // 0x1820(0x50)
	struct TMap<struct FName, float> MovementStand_DestTransTime; // 0x1870(0x50)
	struct TMap<enum class ECustomMovmentMode, float> CustomMovement_BlendTime; // 0x18C0(0x50)
	struct UAnimSequence* AS_SwitchPose_StandToCrouch; // 0x1910(0x8)
	struct UAnimSequence* AS_SwitchPose_StandToProne; // 0x1918(0x8)
	struct UAnimSequence* AS_SwitchPose_CrouchToStand; // 0x1920(0x8)
	struct UAnimSequence* AS_SwitchPose_CrouchToProne; // 0x1928(0x8)
	struct UAnimSequence* AS_SwitchPose_ProneToStand; // 0x1930(0x8)
	struct UAnimSequence* AS_SwitchPose_ProneToCrouch; // 0x1938(0x8)
	struct UAnimSequence* AS_SwitchPose_StandToCrouchDest; // 0x1940(0x8)
	struct UAnimSequence* AS_SwitchPose_StandToProneDest; // 0x1948(0x8)
	struct UAnimSequence* AS_SwitchPose_CrouchToStandDest; // 0x1950(0x8)
	struct UAnimSequence* AS_SwitchPose_CrouchToProneDest; // 0x1958(0x8)
	struct UAnimSequence* AS_SwitchPose_ProneToStandDest; // 0x1960(0x8)
	struct UAnimSequence* AS_SwitchPose_ProneToCrouchDest; // 0x1968(0x8)
	struct FVector moveVelocity; // 0x1970(0xC)
	enum class ECharacterPoseType PoseType; // 0x197C(0x1)
	enum class EWeaponType WeaponType; // 0x197D(0x1)
	enum class ECharacterPoseType InterruptCachePose; // 0x197E(0x1)
	enum class ECharacterPoseType RecoverCharPose; // 0x197F(0x1)
	uint8_t Pad_0x1980[0x8]; // 0x1980(0x8)
	bool bIsOnVehicle; // 0x1988(0x1)
	bool bScoping; // 0x1989(0x1)
	bool bIsMoving; // 0x198A(0x1)
	bool bMovementChanged; // 0x198B(0x1)
	uint8_t Pad_0x198C[0x1]; // 0x198C(0x1)
	bool bMovementChangedAndNotSwitchingPose; // 0x198D(0x1)
	uint8_t Pad_0x198E[0x1]; // 0x198E(0x1)
	bool bWithoutWeapon; // 0x198F(0x1)
	bool bIsSwitchingPose; // 0x1990(0x1)
	bool bUseInterruptPose; // 0x1991(0x1)
	bool bEmptyToCrouch; // 0x1992(0x1)
	bool bEmptyToProne; // 0x1993(0x1)
	bool bEmptyToStand; // 0x1994(0x1)
	bool bStandToProne; // 0x1995(0x1)
	bool bStandToCrouchNotMove; // 0x1996(0x1)
	bool bStandToCrouchMove; // 0x1997(0x1)
	bool bStandTo_StandToProne; // 0x1998(0x1)
	bool bStandTo_StandToCrouch; // 0x1999(0x1)
	bool bCrouchToProne; // 0x199A(0x1)
	bool bCrouchToStandNotMove; // 0x199B(0x1)
	bool bCrouchToStandMove; // 0x199C(0x1)
	bool bCrouchTo_CrouchToProne; // 0x199D(0x1)
	bool bCrouchTo_CrouchToStand; // 0x199E(0x1)
	bool bProneToStand; // 0x199F(0x1)
	bool bProneToCrouch; // 0x19A0(0x1)
	bool bProneTo_ProneToCrouch; // 0x19A1(0x1)
	bool bProneTo_ProneToStand; // 0x19A2(0x1)
	bool bProneToStand_ToStand; // 0x19A3(0x1)
	bool bStandToProne_ToProne; // 0x19A4(0x1)
	bool bCrouchToProne_ToProne; // 0x19A5(0x1)
	bool bProneToCrouch_ToCrouch; // 0x19A6(0x1)
	uint8_t Pad_0x19A7[0x1]; // 0x19A7(0x1)
	float StandSwitchToPronePoseAnimDuration; // 0x19A8(0x4)
	float StandSwitchFromPronePoseAnimDuration; // 0x19AC(0x4)
	float CrouchSwitchToPronePoseAnimDuration; // 0x19B0(0x4)
	float CrouchSwitchFromPronePoseAnimDuration; // 0x19B4(0x4)
	float StandSwitchToPronePoseAnimDelay; // 0x19B8(0x4)
	float StandSwitchFromPronePoseAnimDelay; // 0x19BC(0x4)
	float CrouchSwitchToPronePoseAnimDelay; // 0x19C0(0x4)
	float CrouchSwitchFromPronePoseAnimDelay; // 0x19C4(0x4)
	float MovementBlendTime; // 0x19C8(0x4)
	float SwitchPoseTransTime; // 0x19CC(0x4)
	float SwitchingPoseTimer; // 0x19D0(0x4)
	float SwitchingPoseTimerInternal; // 0x19D4(0x4)
	float InterruptPoseInternal; // 0x19D8(0x4)
	float SwitchPoseAnimStartPosition; // 0x19DC(0x4)
	float CustomMovementBlendTime; // 0x19E0(0x4)
	float ScopeVelocityInterpSpeed; // 0x19E4(0x4)
	float SprintToPronePlayRate; // 0x19E8(0x4)
	bool bCarryBackState; // 0x19EC(0x1)
	uint8_t Pad_0x19ED[0x7]; // 0x19ED(0x7)
	float CarryBackTimeAccumulator; // 0x19F4(0x4)
	struct TArray<struct FCharacterViewPointConfig> PoseStatusViewPointConfig; // 0x19F8(0x10)
	uint8_t Pad_0x1A08[0x10]; // 0x1A08(0x10)
	float LeaveStateTimerInternal; // 0x1A18(0x4)
	float GunSprintToProneDefaultPlayRate; // 0x1A1C(0x4)
	float CommonSprintToProneDefaultPlayRate; // 0x1A20(0x4)
	uint8_t Pad_0x1A24[0x4]; // 0x1A24(0x4)
	struct FName JumpProneBlendCurveName; // 0x1A28(0x8)
	struct USTExtraAnimInstanceBase* MainInstance; // 0x1A30(0x8)
	uint8_t Pad_0x1A38[0x8]; // 0x1A38(0x8)


	// Object: Function MainCity.CharLocomotionMCAnimInstance.SwitchingPoseFinishCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1027abb70
	// Params: [ Num(0) Size(0x0) ]
	void SwitchingPoseFinishCallback();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C

	// Object: Function MainCity.CharLocomotionMCAnimInstance.SetViewPointLimitByPoseStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027abab0
	// Params: [ Num(2) Size(0x2) ]
	void SetViewPointLimitByPoseStatus(uint8_t InPoseType, bool bEnter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027986E8
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function MainCity.CharLocomotionMCAnimInstance.SetInterruptPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027ab9e8
	// Params: [ Num(2) Size(0x2) ]
	void SetInterruptPose(bool bUseInterruptPose, enum class ECharacterPoseType InterruptPose);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102797754
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027986E8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function MainCity.CharLocomotionMCAnimInstance.LeaveStateCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ab9d4
	// Params: [ Num(0) Size(0x0) ]
	void LeaveStateCallback();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102797754
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027986E8
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870

	// Object: Function MainCity.CharLocomotionMCAnimInstance.HandleStateLeave
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ab958
	// Params: [ Num(1) Size(0x1) ]
	void HandleStateLeave(uint8_t LeaveState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027975B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x102797754
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1027986E8

	// Object: Function MainCity.CharLocomotionMCAnimInstance.HandlePlayerPoseChange
	// Flags: [Native|Public]
	// Offset: 0x1027ab898
	// Params: [ Num(2) Size(0x2) ]
	void HandlePlayerPoseChange(enum class ESTEPoseState LastPose, enum class ESTEPoseState NewPose);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x1027975B0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x102797754
	// [Call #13] RVA: 0x10516D168
};

// Object: Class MainCity.CharMainMCAnimInstance
// Size: 0x18D0 (Inherited: 0x17E0)
struct UCharMainMCAnimInstance : UCharacterAnimStateBase
{
	struct UAnimSequence* C_IdleAddtive; // 0x17E0(0x8)
	struct UAnimSequence* C_JumpStart; // 0x17E8(0x8)
	struct UAnimSequence* C_LandLight; // 0x17F0(0x8)
	struct UAnimSequence* C_LandHeavy; // 0x17F8(0x8)
	struct UBlendSpace1D* C_FallingBS; // 0x1800(0x8)
	bool bUseCustomBS; // 0x1808(0x1)
	uint8_t Pad_0x1809[0x7]; // 0x1809(0x7)
	struct UAnimSequence* C_JumpCustom; // 0x1810(0x8)
	struct UBlendSpace1D* C_FallingCustom; // 0x1818(0x8)
	bool C_Scoping; // 0x1820(0x1)
	uint8_t Pad_0x1821[0x3]; // 0x1821(0x3)
	float C_CharacterYawRotateRate; // 0x1824(0x4)
	float C_CharacterYawRotateRate_Reverse; // 0x1828(0x4)
	float ScopeVelocityInterpSpeed; // 0x182C(0x4)
	float b_WalkAdditiveAlpha; // 0x1830(0x4)
	bool b_UnarmedFallingToRifleFallLandingHard; // 0x1834(0x1)
	bool b_WalkToRifleJumpStationStart; // 0x1835(0x1)
	bool C_IdleAddtiveValid; // 0x1836(0x1)
	bool C_ShouldPauseAnim; // 0x1837(0x1)
	bool bWalkToJumpStart; // 0x1838(0x1)
	bool C_Move; // 0x1839(0x1)
	uint8_t Pad_0x183A[0x2]; // 0x183A(0x2)
	struct FVector C_MoveVelocity; // 0x183C(0xC)
	float f_C_MoveVelocityLengthSquard; // 0x1848(0x4)
	enum class EWeaponType C_WeaponType; // 0x184C(0x1)
	bool b_C_LastMovementMode_NEQ_Falling_OR_HoldGrenade; // 0x184D(0x1)
	bool b_WalkToUnarmedFalling; // 0x184E(0x1)
	bool b_UnarmedFallingToRifleCombatFallLanding; // 0x184F(0x1)
	float f_FallingVelocityZFactor; // 0x1850(0x4)
	float MaxFallingVelocityThreshold; // 0x1854(0x4)
	float f_C_MoveVelocity_X_FallingZFactor; // 0x1858(0x4)
	float C_MaxFallingSpeed; // 0x185C(0x4)
	bool MovingOnGround; // 0x1860(0x1)
	bool C_MovingOnGroundAndMovbale; // 0x1861(0x1)
	enum class ECharacterPoseType C_PoseType; // 0x1862(0x1)
	enum class EMovementMode C_LastMovementMode; // 0x1863(0x1)
	bool C_IsJumping; // 0x1864(0x1)
	bool bIsLandingHard; // 0x1865(0x1)
	bool bAlwaysLandLight; // 0x1866(0x1)
	uint8_t Pad_0x1867[0x1]; // 0x1867(0x1)
	struct FVector moveVelocity; // 0x1868(0xC)
	bool C_ClimbAnimSwitch; // 0x1874(0x1)
	uint8_t Pad_0x1875[0x3]; // 0x1875(0x3)
	float C_ClimbAnimTransTime; // 0x1878(0x4)
	float C_ClimbAnimTime_A; // 0x187C(0x4)
	float C_ClimbAnimTime_B; // 0x1880(0x4)
	uint8_t Pad_0x1884[0x4]; // 0x1884(0x4)
	struct UAnimSequence* C_Climb_FrameAnim_A; // 0x1888(0x8)
	struct UAnimSequence* C_Climb_FrameAnim_B; // 0x1890(0x8)
	bool C_PlayerUseSeesaw; // 0x1898(0x1)
	bool bIsLinkMotionLayer; // 0x1899(0x1)
	uint8_t Pad_0x189A[0x6]; // 0x189A(0x6)
	struct FName LinkMotionLayerTagName; // 0x18A0(0x8)
	bool bHasCarryBacK; // 0x18A8(0x1)
	enum class ECustomMovmentMode C_CustomMovementMode; // 0x18A9(0x1)
	uint8_t Pad_0x18AA[0x6]; // 0x18AA(0x6)
	struct USTExtraAnimInstanceBase* MainInstance; // 0x18B0(0x8)
	struct UAnimInstanceContainer* LocomotionAnimContainer; // 0x18B8(0x8)
	struct UAnimInstance* TargetLocomotionBP; // 0x18C0(0x8)
	uint8_t Pad_0x18C8[0x8]; // 0x18C8(0x8)


	// Object: Function MainCity.CharMainMCAnimInstance.SetClimbAnimation
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ac5dc
	// Params: [ Num(2) Size(0x9) ]
	void SetClimbAnimation(struct UAnimSequence* AnimSequence, bool bFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279A428
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayExtraDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ac3e0
	// Params: [ Num(7) Size(0x28) ]
	void HandlePlayerAnimMontagePlayExtraDelegate(struct UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, struct FName StartSection, float StartPos, bool bOnlyJumpToSectionWhilePlaying, struct FName IgnoreStopSection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10279A108
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ac25c
	// Params: [ Num(5) Size(0x1C) ]
	void HandlePlayerAnimMontagePlayDelegate(struct UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, struct FName StartSection, float StartPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MainCity.CharMainMCAnimInstance.HandleAnimPlaySlotAnimDelegate
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ac034
	// Params: [ Num(8) Size(0x2C) ]
	void HandleAnimPlaySlotAnimDelegate(struct UAnimSequenceBase* AnimSequence, bool bWantsPlay, struct FName SlotName, float PlayRate, float BlendTime, uint8_t InLoopCount, float InStartPos, float LoopStartPos);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10279A51C
};

// Object: Class MainCity.CharSeesawMCAnimInstance
// Size: 0xCB0 (Inherited: 0xC80)
struct UCharSeesawMCAnimInstance : USTExtraAnimInstanceBase
{
	uint8_t Pad_0xC80[0x8]; // 0xC80(0x8)
	struct UAssetPlayerSyncNode* AssetPlayerSyncNode; // 0xC88(0x8)
	bool C_IsActivate; // 0xC90(0x1)
	bool C_IsLooping; // 0xC91(0x1)
	uint8_t Pad_0xC92[0x2]; // 0xC92(0x2)
	int C_CurSeatState; // 0xC94(0x4)
	int C_OtherSeatState; // 0xC98(0x4)
	int C_SeesawState; // 0xC9C(0x4)
	bool C_SitAtA; // 0xCA0(0x1)
	bool C_SelfKnockUp; // 0xCA1(0x1)
	bool C_OtherKnockUp; // 0xCA2(0x1)
	bool C_SelfIdle; // 0xCA3(0x1)
	bool C_SelfWaiting; // 0xCA4(0x1)
	bool C_SelfEntering; // 0xCA5(0x1)
	bool C_SelfEntered; // 0xCA6(0x1)
	bool C_SelfExiting; // 0xCA7(0x1)
	bool C_OtherIdle; // 0xCA8(0x1)
	bool C_OtherWaiting; // 0xCA9(0x1)
	bool C_OtherEntering; // 0xCAA(0x1)
	bool C_OtherEntered; // 0xCAB(0x1)
	bool C_OtherExiting; // 0xCAC(0x1)
	bool C_IsEnterField; // 0xCAD(0x1)
	bool C_IsInGame; // 0xCAE(0x1)
	bool C_IsSpeedUp; // 0xCAF(0x1)
};

// Object: Class MainCity.FollowerSysDataAsset
// Size: 0xA0 (Inherited: 0x30)
struct UFollowerSysDataAsset : UDataAsset
{
	struct FName HandHoldingSocket; // 0x30(0x8)
	struct FVector HandHoldingSocketLocOffset; // 0x38(0xC)
	struct FRotator HandHoldingSocketRotOffset; // 0x44(0xC)
	float PullW; // 0x50(0x4)
	bool NormalizePull; // 0x54(0x1)
	uint8_t Pad_0x55[0x3]; // 0x55(0x3)
	struct FVector PositivePullFactor; // 0x58(0xC)
	struct FVector NegativePullFactor; // 0x64(0xC)
	bool RotateBone; // 0x70(0x1)
	bool RotateLimb; // 0x71(0x1)
	uint8_t Pad_0x72[0x2]; // 0x72(0x2)
	float DeltaSmoothSpeed; // 0x74(0x4)
	float AngularDeltaSmoothSpeed; // 0x78(0x4)
	float OffsetSoverParms1; // 0x7C(0x4)
	float TargetLocLerpSpeed; // 0x80(0x4)
	bool SmoothPositionOverTime; // 0x84(0x1)
	uint8_t Pad_0x85[0x3]; // 0x85(0x3)
	float MaxPositionSpeed; // 0x88(0x4)
	float MaxPositionDistance; // 0x8C(0x4)
	bool SmoothRotationOverTime; // 0x90(0x1)
	uint8_t Pad_0x91[0x3]; // 0x91(0x3)
	float MaxDegreesSpeed; // 0x94(0x4)
	float MaxDegreesDistance; // 0x98(0x4)
	uint8_t Pad_0x9C[0x4]; // 0x9C(0x4)
};

// Object: Class MainCity.HoldingHandsMCAnimInstance
// Size: 0x18D0 (Inherited: 0x17E0)
struct UHoldingHandsMCAnimInstance : UCharacterAnimStateBase
{
	struct UBlendSpace* BS_HoldingHoldsLeader; // 0x17E0(0x8)
	struct UBlendSpace* BS_HoldingHoldsFollower; // 0x17E8(0x8)
	struct FVector HoldingHandsTargetLoc; // 0x17F0(0xC)
	struct FRotator HoldingHandsTargetRot; // 0x17FC(0xC)
	struct FVector LeaderHoldingHandsTargetLoc; // 0x1808(0xC)
	struct FVector FollowerHoldingHandsTargetLoc; // 0x1814(0xC)
	bool bIsFollower; // 0x1820(0x1)
	uint8_t Pad_0x1821[0x3]; // 0x1821(0x3)
	struct FVector OffsetSover1; // 0x1824(0xC)
	float OffsetSoverParms1; // 0x1830(0x4)
	uint8_t Pad_0x1834[0x4]; // 0x1834(0x4)
	struct UFollowerSysDataAsset* FollowerDA; // 0x1838(0x8)
	struct UFollowerSysDataAsset* LeaderDA; // 0x1840(0x8)
	float PullW; // 0x1848(0x4)
	bool NormalizePull; // 0x184C(0x1)
	uint8_t Pad_0x184D[0x3]; // 0x184D(0x3)
	struct FVector PositivePullFactor; // 0x1850(0xC)
	struct FVector NegativePullFactor; // 0x185C(0xC)
	bool RotateBone; // 0x1868(0x1)
	bool RotateLimb; // 0x1869(0x1)
	uint8_t Pad_0x186A[0x2]; // 0x186A(0x2)
	float DeltaSmoothSpeed; // 0x186C(0x4)
	float AngularDeltaSmoothSpeed; // 0x1870(0x4)
	float F_PullW; // 0x1874(0x4)
	bool F_NormalizePull; // 0x1878(0x1)
	uint8_t Pad_0x1879[0x3]; // 0x1879(0x3)
	struct FVector F_PositivePullFactor; // 0x187C(0xC)
	struct FVector F_NegativePullFactor; // 0x1888(0xC)
	bool F_RotateBone; // 0x1894(0x1)
	bool F_RotateLimb; // 0x1895(0x1)
	uint8_t Pad_0x1896[0x2]; // 0x1896(0x2)
	float F_DeltaSmoothSpeed; // 0x1898(0x4)
	float F_AngularDeltaSmoothSpeed; // 0x189C(0x4)
	enum class ECharacterFollowType FollowType; // 0x18A0(0x1)
	enum class EHoldingHandsIKMode EHandIKMode; // 0x18A1(0x1)
	uint8_t Pad_0x18A2[0x2]; // 0x18A2(0x2)
	struct FVector followerVelocity; // 0x18A4(0xC)
	bool bUsePredictVelocity; // 0x18B0(0x1)
	uint8_t Pad_0x18B1[0x3]; // 0x18B1(0x3)
	float followerSpeed; // 0x18B4(0x4)
	uint8_t Pad_0x18B8[0x18]; // 0x18B8(0x18)
};

// Object: Class MainCity.MainCityGameMode
// Size: 0x2330 (Inherited: 0x22B0)
struct AMainCityGameMode : ABattleRoyaleGameMode
{
	uint8_t Pad_0x22B0[0x54]; // 0x22B0(0x54)
	uint32_t MaxAcceptOneFrame; // 0x2304(0x4)
	float MinAcceptTimeDelta; // 0x2308(0x4)
	float UpdateDistTimeDelta; // 0x230C(0x4)
	struct TArray<float> RelevantDistArray; // 0x2310(0x10)
	float TickTimeDelta; // 0x2320(0x4)
	float RelevantDataLifeTime; // 0x2324(0x4)
	float ForceRelevantTimeDelta; // 0x2328(0x4)
	uint8_t Pad_0x232C[0x4]; // 0x232C(0x4)


	// Object: Function MainCity.MainCityGameMode.ReplayRecoverGenerateDSCheckpoint
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ad3f0
	// Params: [ Num(1) Size(0x10) ]
	void ReplayRecoverGenerateDSCheckpoint(struct FString InReplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279C8DC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.MainCityGameMode.PreInitGameState
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ad3d4
	// Params: [ Num(0) Size(0x0) ]
	void PreInitGameState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279C8DC
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.MainCityGameMode.InternalNotifyPlayerExit
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ad350
	// Params: [ Num(1) Size(0x8) ]
	void InternalNotifyPlayerExit(struct ASTExtraPlayerController* PlayerController);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279C8DC
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.MainCityGameMode.InitConsoleVar
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ad2b8
	// Params: [ Num(1) Size(0x10) ]
	void InitConsoleVar(struct FString Command);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279CB18
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10279C8DC
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function MainCity.MainCityGameMode.GenReplayDone
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ad218
	// Params: [ Num(1) Size(0x10) ]
	void GenReplayDone(struct FString ErrorMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10279CB18
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10279C8DC
	// [Call #17] RVA: 0x101F8130C

	// Object: Function MainCity.MainCityGameMode.DSPlayerKickOut
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ad0b0
	// Params: [ Num(3) Size(0x20) ]
	void DSPlayerKickOut(uint64_t UID, struct FName PlayerType, struct FString ExitReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x10279CA80
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
};

// Object: Class MainCity.MainCityGameModeStateActive
// Size: 0xC8 (Inherited: 0xC8)
struct UMainCityGameModeStateActive : UGameModeStateActive
{
};

// Object: Class MainCity.MainCityGameModeStateFighting
// Size: 0xD0 (Inherited: 0xD0)
struct UMainCityGameModeStateFighting : UGameModeStateFighting
{
};

// Object: Class MainCity.MainCityGameModeStateFinished
// Size: 0xC0 (Inherited: 0xC0)
struct UMainCityGameModeStateFinished : UGameModeStateFinished
{
};

// Object: Class MainCity.MainCityGameModeStateReady
// Size: 0x118 (Inherited: 0x118)
struct UMainCityGameModeStateReady : UGameModeStateReady
{
};

// Object: Class MainCity.MainCityGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UMainCityGameplayStatics : UBlueprintFunctionLibrary
{

	// Object: Function MainCity.MainCityGameplayStatics.GetProjectSavedDir
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027adb4c
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectSavedDir();
	// [Call #1] RVA: 0x10279FCBC
	// [Call #2] RVA: 0x101F8156C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10508F76C
	// [Call #9] RVA: 0x105190870
};

// Object: Class MainCity.MainCityGameState
// Size: 0x1638 (Inherited: 0x1620)
struct AMainCityGameState : ASTExtraGameStateBase
{
	struct FScriptMulticastDelegate OnMainCityPlayerStateChangedDelegate; // 0x1620(0x10)
	bool bEnableTimeUpdate; // 0x1630(0x1)
	bool bEnableTimeOffset; // 0x1631(0x1)
	uint8_t Pad_0x1632[0x2]; // 0x1632(0x2)
	float ReplicatedWorldTimeSecondsOffset; // 0x1634(0x4)
};

// Object: Class MainCity.MainCityHelper
// Size: 0x28 (Inherited: 0x28)
struct UMainCityHelper : UObject
{

	// Object: Function MainCity.MainCityHelper.SetSwapRolesForReplay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027ade40
	// Params: [ Num(2) Size(0xC) ]
	int SetSwapRolesForReplay(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279FCC0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x1027AE164
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class MainCity.MainCityPlayerState
// Size: 0x1CD8 (Inherited: 0x1CD8)
struct AMainCityPlayerState : ASTExtraPlayerState
{

	// Object: Function MainCity.MainCityPlayerState.RefreshAliasInfo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1027ae024
	// Params: [ Num(1) Size(0x48) ]
	void RefreshAliasInfo(struct FGameModePlayerAliasInfo& PlayerAliasInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279D10C
	// [Call #4] RVA: 0x1023634D8
	// [Call #5] RVA: 0x1023634D8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x1027AB5E8
	// [Call #11] RVA: 0x105185230
};

// Object: Class MainCity.MainCitySeesawAnimInstance
// Size: 0x420 (Inherited: 0x3F0)
struct UMainCitySeesawAnimInstance : UAnimInstance
{
	struct UAssetPlayerSyncNode* AssetPlayerSyncNode; // 0x3F0(0x8)
	bool C_IsActivate; // 0x3F8(0x1)
	bool C_IsLooping; // 0x3F9(0x1)
	uint8_t Pad_0x3FA[0x2]; // 0x3FA(0x2)
	int C_SeatAState; // 0x3FC(0x4)
	int C_SeatBState; // 0x400(0x4)
	int C_SeesawState; // 0x404(0x4)
	bool C_AKnockUp; // 0x408(0x1)
	bool C_BKnockUp; // 0x409(0x1)
	bool C_A_Idle; // 0x40A(0x1)
	bool C_A_Waiting; // 0x40B(0x1)
	bool C_A_Entering; // 0x40C(0x1)
	bool C_A_Entered; // 0x40D(0x1)
	bool C_A_Exiting; // 0x40E(0x1)
	bool C_B_Idle; // 0x40F(0x1)
	bool C_B_Waiting; // 0x410(0x1)
	bool C_B_Entering; // 0x411(0x1)
	bool C_B_Entered; // 0x412(0x1)
	bool C_B_Exiting; // 0x413(0x1)
	bool C_IsEnterField; // 0x414(0x1)
	bool C_IsInGame; // 0x415(0x1)
	bool C_IsSpeedUp; // 0x416(0x1)
	uint8_t Pad_0x417[0x9]; // 0x417(0x9)


	// Object: Function MainCity.MainCitySeesawAnimInstance.SyncAttachedActorAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027ae34c
	// Params: [ Num(0) Size(0x0) ]
	void SyncAttachedActorAnimation();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x10516EACC
};

// Object: Class MainCity.MainCitySubsystem
// Size: 0xD8 (Inherited: 0x30)
struct UMainCitySubsystem : UWorldSubsystem
{
	uint8_t Pad_0x30[0x58]; // 0x30(0x58)
	struct FName FeatureDefaultPawnName; // 0x88(0x8)
	struct FString SkipLoadMapLevel; // 0x90(0x10)
	bool bShutdownUnrealNetwork; // 0xA0(0x1)
	uint8_t Pad_0xA1[0x2F]; // 0xA1(0x2F)
	struct ASTExtraBaseCharacter* InitialCharacter; // 0xD0(0x8)


	// Object: Function MainCity.MainCitySubsystem.SetHasInitLobbyAvatar
	// Flags: [Final|Native|Public]
	// Offset: 0x1027aeb48
	// Params: [ Num(2) Size(0x9) ]
	void SetHasInitLobbyAvatar(struct ASTExtraPlayerController* InController, bool bInValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279FB7C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.ResetMainCityGameState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1027aeacc
	// Params: [ Num(1) Size(0x8) ]
	void ResetMainCityGameState(struct ASTExtraGameStateBase* InGameState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279F958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10279FB7C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.PreShutdownUnrealNetwork
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027aeab0
	// Params: [ Num(0) Size(0x0) ]
	void PreShutdownUnrealNetwork();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279F958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10279FB7C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.PreEnterMainCityBattle
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027aea94
	// Params: [ Num(0) Size(0x0) ]
	void PreEnterMainCityBattle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279F958
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10279FB7C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.PreDestroyAutonomousChar
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027aea10
	// Params: [ Num(1) Size(0x8) ]
	void PreDestroyAutonomousChar(struct ASTExtraBaseCharacter* Character);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279FB7C
	// [Call #11] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.PostShutdownUnrealNetwork
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae9f4
	// Params: [ Num(0) Size(0x0) ]
	void PostShutdownUnrealNetwork();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279FB7C
	// [Call #11] RVA: 0x10519022C

	// Object: Function MainCity.MainCitySubsystem.PostPlayerActorChannelOpen
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae9d8
	// Params: [ Num(0) Size(0x0) ]
	void PostPlayerActorChannelOpen();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279FB7C

	// Object: Function MainCity.MainCitySubsystem.PostInitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae9bc
	// Params: [ Num(0) Size(0x0) ]
	void PostInitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279FB7C

	// Object: Function MainCity.MainCitySubsystem.PostEnterMainCityBattle
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae9a0
	// Params: [ Num(0) Size(0x0) ]
	void PostEnterMainCityBattle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279FB7C

	// Object: Function MainCity.MainCitySubsystem.PostDeinitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae984
	// Params: [ Num(0) Size(0x0) ]
	void PostDeinitialize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4

	// Object: Function MainCity.MainCitySubsystem.PostClearActors
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027ae968
	// Params: [ Num(0) Size(0x0) ]
	void PostClearActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10279F958
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168

	// Object: Function MainCity.MainCitySubsystem.KeepActor
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ae8ec
	// Params: [ Num(1) Size(0x8) ]
	void KeepActor(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10279F318
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10279F958

	// Object: Function MainCity.MainCitySubsystem.InitStandalonePawn
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1027ae7d0
	// Params: [ Num(4) Size(0x28) ]
	struct ASTExtraBaseCharacter* InitStandalonePawn(struct UObject* InClass, struct FVector& InLocation, struct FRotator& InRotation);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10279F144
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279F318

	// Object: Function MainCity.MainCitySubsystem.ClearActors
	// Flags: [Final|Native|Public]
	// Offset: 0x1027ae7bc
	// Params: [ Num(0) Size(0x0) ]
	void ClearActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10279F144
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10279F318
};

// Object: Class MainCity.MCAnimInstanceLocomotion
// Size: 0x1A80 (Inherited: 0x1A70)
struct UMCAnimInstanceLocomotion : UAnimInstanceLocomotion
{
	bool bUseCustomBS; // 0x1A65(0x1)
	struct UBlendSpace* BS_MovementStandCustom; // 0x1A68(0x8)
	struct UBlendSpace* BS_MovementCrouchCustom; // 0x1A70(0x8)
	struct UBlendSpace* BS_MovementProneCustom; // 0x1A78(0x8)
};

// Object: Class MainCity.ReplayRecoverSubsystem
// Size: 0x178 (Inherited: 0x30)
struct UReplayRecoverSubsystem : UGameInstanceSubsystem
{
	uint8_t Pad_0x30[0x60]; // 0x30(0x60)
	struct TArray<struct FString> IncludeWorldNames; // 0x90(0x10)
	int MoveStaticBuffer; // 0xA0(0x4)
	uint8_t Pad_0xA4[0x4]; // 0xA4(0x4)
	struct TArray<uint8_t> LuaInfo; // 0xA8(0x10)
	int64_t MaxTimeDelta; // 0xB8(0x8)
	int SkipRepNotifies; // 0xC0(0x4)
	uint8_t Pad_0xC4[0xB4]; // 0xC4(0xB4)


	// Object: Function MainCity.ReplayRecoverSubsystem.WriteLuaInfo
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1027afd1c
	// Params: [ Num(1) Size(0x10) ]
	void WriteLuaInfo(struct TArray<uint8_t>& InData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027A0A8C
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function MainCity.ReplayRecoverSubsystem.SetReplayName
	// Flags: [Final|Native|Public]
	// Offset: 0x1027afc84
	// Params: [ Num(1) Size(0x10) ]
	void SetReplayName(struct FString InReplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027A013C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1027A0A8C
	// [Call #10] RVA: 0x101F8BA74
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function MainCity.ReplayRecoverSubsystem.ReadLuaInfo
	// Flags: [Final|Native|Public]
	// Offset: 0x1027afc4c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<uint8_t> ReadLuaInfo();
	// [Call #1] RVA: 0x1027A0B10
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x1027A013C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027A0A8C
	// [Call #11] RVA: 0x101F8BA74
	// [Call #12] RVA: 0x101F8BA74
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x105190870
	// [Call #16] RVA: 0x10519022C

	// Object: Function MainCity.ReplayRecoverSubsystem.PreInitializeWithParams
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027afb90
	// Params: [ Num(2) Size(0x10) ]
	void PreInitializeWithParams(struct UWorld* InWorld, struct UNetDriver* InDriver);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027A0B10
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x1027A013C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1027A0A8C
	// [Call #15] RVA: 0x101F8BA74
	// [Call #16] RVA: 0x101F8BA74
	// [Call #17] RVA: 0x106C8459C

	// Object: Function MainCity.ReplayRecoverSubsystem.PreInitializeForWorld
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027afa74
	// Params: [ Num(3) Size(0x20) ]
	void PreInitializeForWorld(struct FString InURLStr, struct UWorld* InWorld, struct USTExtraGameInstance* InGameInstance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x1027A0B10
	// [Call #15] RVA: 0x10516D168

	// Object: Function MainCity.ReplayRecoverSubsystem.PreInitializeForGameMode
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af958
	// Params: [ Num(3) Size(0x20) ]
	void PreInitializeForGameMode(struct FString InURLStr, struct UWorld* InWorld, struct AGameStateBase* InGameState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function MainCity.ReplayRecoverSubsystem.PreDemoPlaybackEnded
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af8d4
	// Params: [ Num(1) Size(0x8) ]
	void PreDemoPlaybackEnded(struct UWorld* InWorld);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function MainCity.ReplayRecoverSubsystem.PostInitializeWithParams
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af818
	// Params: [ Num(2) Size(0x10) ]
	void PostInitializeWithParams(struct UWorld* InWorld, struct UNetDriver* InDriver);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C

	// Object: Function MainCity.ReplayRecoverSubsystem.PostInitializeForWorld
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af6fc
	// Params: [ Num(3) Size(0x20) ]
	void PostInitializeForWorld(struct FString InURLStr, struct UWorld* InWorld, struct USTExtraGameInstance* InGameInstance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function MainCity.ReplayRecoverSubsystem.PostInitializeForGameMode
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af5e0
	// Params: [ Num(3) Size(0x20) ]
	void PostInitializeForGameMode(struct FString InURLStr, struct UWorld* InWorld, struct AGameStateBase* InGameState);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function MainCity.ReplayRecoverSubsystem.LuaSaveLuaInfo
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af5a4
	// Params: [ Num(1) Size(0x1) ]
	bool LuaSaveLuaInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8130C

	// Object: Function MainCity.ReplayRecoverSubsystem.LoadReplayDone
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af504
	// Params: [ Num(1) Size(0x10) ]
	void LoadReplayDone(struct FString ErrorMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function MainCity.ReplayRecoverSubsystem.IsVersionValid
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af400
	// Params: [ Num(3) Size(0x21) ]
	bool IsVersionValid(struct FString RecordVersion, struct FString PlayerVersion);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function MainCity.ReplayRecoverSubsystem.IsTimeValid
	// Flags: [Final|Native|Public]
	// Offset: 0x1027af33c
	// Params: [ Num(3) Size(0x11) ]
	bool IsTimeValid(int64_t RecordTime, int64_t PlayTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x1027A0574
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x101F8130C

	// Object: Function MainCity.ReplayRecoverSubsystem.GenReplayDone
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1027af29c
	// Params: [ Num(1) Size(0x10) ]
	void GenReplayDone(struct FString ErrorMsg);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x1027A0574
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function MainCity.ReplayRecoverSubsystem.DeleteExpiredFiles
	// Flags: [Final|Native|Public]
	// Offset: 0x1027af220
	// Params: [ Num(1) Size(0x4) ]
	void DeleteExpiredFiles(float MaxKeepHours);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027A0B88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1027A0574
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function MainCity.ReplayRecoverSubsystem.ClearRecoverFile
	// Flags: [Final|Native|Public]
	// Offset: 0x1027af20c
	// Params: [ Num(0) Size(0x0) ]
	void ClearRecoverFile();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1027A0B88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x1027A0574
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
};

