#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Login_Video_UIBP.Login_Video_UIBP_C
// Size: 0x288 (Inherited: 0x260)
struct ULogin_Video_UIBP_C : UUserWidget
{
	struct UCanvasPanel* CanvasPanel_0; // 0x260(0x8)
	struct UImage* Image_Logo; // 0x268(0x8)
	struct UImage* Image_Mask; // 0x270(0x8)
	struct UImage* MediaContainer; // 0x278(0x8)
	struct UScaleBox* ScaleBox_0; // 0x280(0x8)
};

