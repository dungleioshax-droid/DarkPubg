#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_LobbyQueueControl_PostSwitchPopup_type.BP_STRUCT_LobbyQueueControl_PostSwitchPopup_type
// Size: 0x41 (Inherited: 0x0)
struct FBP_STRUCT_LobbyQueueControl_PostSwitchPopup_type
{
	struct FString EventID_0_4514838002A4BE4A0507256002721084; // 0x0(0x10)
	struct FString EventType_1_0B22E8C060F38C612ADDC4D30211F215; // 0x10(0x10)
	bool ExecuteOnce_2_4AC4B5C030B7A4AD7508230204FC1575; // 0x20(0x1)
	uint8_t Pad_0x21[0x3]; // 0x21(0x3)
	int ID_3_2853A3007A64CA2241F5132B0BA48534; // 0x24(0x4)
	int Order_5_74409EC04444D0CF56088D9E08683082; // 0x28(0x4)
	int ModuleID_6_1DBD9C8032679F5C7BF657310E20AF34; // 0x2C(0x4)
	struct FString CheckFunction_7_6E2B48C02B34A80B701D9D020D1B79DE; // 0x30(0x10)
	bool OnlyPostSwitch_8_604EAE405A32FA251FC46CFE0938FAE8; // 0x40(0x1)
};

