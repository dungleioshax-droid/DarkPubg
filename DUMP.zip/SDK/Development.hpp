#pragma once

#include <cstdint>

// Object: Enum Development.EImGuiWindowDisplayMode
enum class EImGuiWindowDisplayMode : uint8_t
{
	Embedded = 0,
	Standalone = 1,
	EImGuiWindowDisplayMode_MAX = 2
};

// Object: ScriptStruct Development.PropertyItemData
// Size: 0x28 (Inherited: 0x0)
struct FPropertyItemData
{
	struct FString PropertyName; // 0x0(0x10)
	struct UEditableTextBox* EditableTextBox; // 0x10(0x8)
	struct UWidget* ContainerWidget; // 0x18(0x8)
	struct UButton* NameButton; // 0x20(0x8)
};

// Object: Class Development.ActorClickPickerWidget
// Size: 0x430 (Inherited: 0x418)
struct UActorClickPickerWidget : UUAEUserWidget
{
	struct TWeakObjectPtr<struct UActorInspectorTab> OwnerTab; // 0x418(0x8)
	bool bPickerEnabled; // 0x420(0x1)
	uint8_t Pad_0x421[0x3]; // 0x421(0x3)
	float TraceDistance; // 0x424(0x4)
	bool bPrioritizePawns; // 0x428(0x1)
	uint8_t Pad_0x429[0x7]; // 0x429(0x7)


	// Object: Function Development.ActorClickPickerWidget.SetPickerEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c42404
	// Params: [ Num(1) Size(0x1) ]
	void SetPickerEnabled(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF5A60
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519077C

	// Object: Function Development.ActorClickPickerWidget.SetOwnerTab
	// Flags: [Final|Native|Public]
	// Offset: 0x106c42388
	// Params: [ Num(1) Size(0x8) ]
	void SetOwnerTab(struct UActorInspectorTab* InOwnerTab);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1051A2848
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BF5A60
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.ActorClickPickerWidget.IsPickerEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c4236c
	// Params: [ Num(1) Size(0x1) ]
	bool IsPickerEnabled();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1051A2848
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BF5A60
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
};

// Object: Class Development.ImGuiTabBase
// Size: 0xC0 (Inherited: 0x28)
struct UImGuiTabBase : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString TabName; // 0x80(0x10)
	struct FName TabID; // 0x90(0x8)
	bool bIsVisible; // 0x98(0x1)
	bool bIsEnabled; // 0x99(0x1)
	uint8_t Pad_0x9A[0x2]; // 0x9A(0x2)
	int TabPriority; // 0x9C(0x4)
	struct FString LuaFilePath; // 0xA0(0x10)
	bool bIsLuaInitialized; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x3]; // 0xB1(0x3)
	struct TWeakObjectPtr<struct AImGuiWindowBase> OwnerWindow; // 0xB4(0x8)
	bool bIsActive; // 0xBC(0x1)
	bool bIsInitialized; // 0xBD(0x1)
	uint8_t Pad_0xBE[0x2]; // 0xBE(0x2)
};

// Object: Class Development.ActorInspectorTab
// Size: 0x930 (Inherited: 0xC0)
struct UActorInspectorTab : UImGuiTabBase
{
	struct TWeakObjectPtr<struct UWorld> SelectedWorld; // 0xC0(0x8)
	uint8_t Pad_0xC8[0x13C]; // 0xC8(0x13C)
	struct TWeakObjectPtr<struct UObject> SelectedObject; // 0x204(0x8)
	struct TWeakObjectPtr<struct AActor> SelectedActor; // 0x20C(0x8)
	uint8_t Pad_0x214[0x18]; // 0x214(0x18)
	struct TWeakObjectPtr<struct UActorComponent> SelectedComponent; // 0x22C(0x8)
	uint8_t Pad_0x234[0x6DC]; // 0x234(0x6DC)
	bool bClickListenerEnabled; // 0x910(0x1)
	uint8_t Pad_0x911[0x1F]; // 0x911(0x1F)
};

// Object: Class Development.ActorPropertyMonitorWidget
// Size: 0x5A8 (Inherited: 0x418)
struct UActorPropertyMonitorWidget : UUAEUserWidget
{
	float PropertyFontSize; // 0x418(0x4)
	bool bUpdatePropertyValueEveryFrame; // 0x41C(0x1)
	uint8_t Pad_0x41D[0x3]; // 0x41D(0x3)
	struct UCanvasPanel* MainCanvasPanel; // 0x420(0x8)
	struct UScrollBox* PropertyScrollBox; // 0x428(0x8)
	struct UVerticalBox* PropertyContainer; // 0x430(0x8)
	struct USlider* OpacitySlider; // 0x438(0x8)
	struct USlider* ScaleSlider; // 0x440(0x8)
	struct UEditableTextBox* SearchTextBox; // 0x448(0x8)
	struct UButton* DragHandleButton; // 0x450(0x8)
	struct UComboBoxString* ComponentComboBox; // 0x458(0x8)
	struct UComboBoxString* AttachedActorComboBox; // 0x460(0x8)
	struct UButton* ClickListenerButton; // 0x468(0x8)
	struct UTextBlock* ClickListenerButtonText; // 0x470(0x8)
	struct UTextBlock* TargetActorName; // 0x478(0x8)
	struct UObject* TargetObject; // 0x480(0x8)
	struct AActor* TargetActor; // 0x488(0x8)
	struct TArray<struct FString> PropertyNamesToDisplay; // 0x490(0x10)
	struct TMap<struct FString, struct FPropertyItemData> PropertyItems; // 0x4A0(0x50)
	uint8_t Pad_0x4F0[0x40]; // 0x4F0(0x40)
	struct UObject* CachedPropertyNamesObject; // 0x530(0x8)
	uint8_t Pad_0x538[0x10]; // 0x538(0x10)
	struct UActorComponent* SelectedComponent; // 0x548(0x8)
	struct TMap<struct FString, struct AActor*> AttachedActorsMap; // 0x550(0x50)
	uint8_t Pad_0x5A0[0x8]; // 0x5A0(0x8)


	// Object: Function Development.ActorPropertyMonitorWidget.SetTargetObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c43160
	// Params: [ Num(1) Size(0x8) ]
	void SetTargetObject(struct UObject* InObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF7398
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.ActorPropertyMonitorWidget.SetTargetActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c430e4
	// Params: [ Num(1) Size(0x8) ]
	void SetTargetActor(struct AActor* InActor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF7318
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BF7398
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.ActorPropertyMonitorWidget.SetPropertyNames
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106c4303c
	// Params: [ Num(1) Size(0x10) ]
	void SetPropertyNames(struct TArray<struct FString>& PropertyNames);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF7E1C
	// [Call #4] RVA: 0x101F8B9F8
	// [Call #5] RVA: 0x101F8B9F8
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BF7318
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BF7398
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function Development.ActorPropertyMonitorWidget.SearchProperties
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c42fa4
	// Params: [ Num(1) Size(0x10) ]
	void SearchProperties(struct FString SearchKeyword);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF7EB4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BF7E1C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BF7318
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106BF7398

	// Object: Function Development.ActorPropertyMonitorWidget.RefreshPropertyValues
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c42f90
	// Params: [ Num(0) Size(0x0) ]
	void RefreshPropertyValues();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF7EB4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BF7E1C
	// [Call #10] RVA: 0x101F8B9F8
	// [Call #11] RVA: 0x101F8B9F8
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BF7318
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106BF7398

	// Object: Function Development.ActorPropertyMonitorWidget.OnSearchTextChanged
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106c42ee4
	// Params: [ Num(1) Size(0x18) ]
	void OnSearchTextChanged(struct FText& Text);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106BF6438
	// [Call #5] RVA: 0x101FBDBE8
	// [Call #6] RVA: 0x101FBDBE8
	// [Call #7] RVA: 0x106C8459C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BF7EB4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BF7E1C
	// [Call #17] RVA: 0x101F8B9F8
	// [Call #18] RVA: 0x101F8B9F8
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Development.ActorPropertyMonitorWidget.OnScaleChanged
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c42e68
	// Params: [ Num(1) Size(0x4) ]
	void OnScaleChanged(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF62C4
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BF6438
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x101FBDBE8
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BF7EB4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106BF7E1C
	// [Call #20] RVA: 0x101F8B9F8

	// Object: Function Development.ActorPropertyMonitorWidget.OnPropertyValueCommittedInternal
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106c42d70
	// Params: [ Num(2) Size(0x19) ]
	void OnPropertyValueCommittedInternal(struct FText& Text, enum class ETextCommit CommitMethod);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BF8C4C
	// [Call #7] RVA: 0x101FBDBE8
	// [Call #8] RVA: 0x101FBDBE8
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BF62C4
	// [Call #13] RVA: 0x104F0F380
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BF6438
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x101FBDBE8
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Development.ActorPropertyMonitorWidget.OnPropertyValueCommitted
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x106c42bd4
	// Params: [ Num(3) Size(0x30) ]
	void OnPropertyValueCommitted(struct FText& Text, enum class ETextCommit CommitMethod, struct FString PropertyName);
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106BF9280
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x104F0F380
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Development.ActorPropertyMonitorWidget.OnPropertyNameButtonClicked
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c42bc0
	// Params: [ Num(0) Size(0x0) ]
	void OnPropertyNameButtonClicked();
	// [Call #1] RVA: 0x104F0F380
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106BF9280
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101FBDBE8
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101FBDBE8
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x104F0F380
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Development.ActorPropertyMonitorWidget.OnOpacityChanged
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c42b44
	// Params: [ Num(1) Size(0x4) ]
	void OnOpacityChanged(float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF61B8
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106BF9280
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x104F0F380

	// Object: Function Development.ActorPropertyMonitorWidget.OnDragButtonReleased
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c42b30
	// Params: [ Num(0) Size(0x0) ]
	void OnDragButtonReleased();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF61B8
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106BF9280
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Development.ActorPropertyMonitorWidget.OnDragButtonPressed
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c42b1c
	// Params: [ Num(0) Size(0x0) ]
	void OnDragButtonPressed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BF61B8
	// [Call #4] RVA: 0x104F0F380
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106BF9280
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101FBDBE8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101FBDBE8
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Development.ActorPropertyMonitorWidget.OnComponentSelectionChanged
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c429f8
	// Params: [ Num(2) Size(0x11) ]
	void OnComponentSelectionChanged(struct FString SelectedItem, enum class ESelectInfo SelectionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106BF67D4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BF61B8
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.ActorPropertyMonitorWidget.OnClickListenerButtonClicked
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c429e4
	// Params: [ Num(0) Size(0x0) ]
	void OnClickListenerButtonClicked();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106BF67D4
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BF61B8
	// [Call #17] RVA: 0x104F0F380
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.ActorPropertyMonitorWidget.OnAttachedActorSelectionChanged
	// Flags: [Final|Native|Protected]
	// Offset: 0x106c428c0
	// Params: [ Num(2) Size(0x11) ]
	void OnAttachedActorSelectionChanged(struct FString SelectedItem, enum class ESelectInfo SelectionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106BF6AE0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C
	// [Call #19] RVA: 0x106BF67D4
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C
};

// Object: Class Development.BuffTableListPanel
// Size: 0x300 (Inherited: 0xC0)
struct UBuffTableListPanel : UImGuiTabBase
{
	uint8_t Pad_0xC0[0x240]; // 0xC0(0x240)
};

// Object: Class Development.ClientReportDataTab
// Size: 0x2C0 (Inherited: 0xC0)
struct UClientReportDataTab : UImGuiTabBase
{
	uint8_t Pad_0xC0[0x200]; // 0xC0(0x200)
};

// Object: Class Development.CloudGMHandle
// Size: 0x30 (Inherited: 0x28)
struct UCloudGMHandle : UObject
{
	bool bEnableCloudGM; // 0x28(0x1)
	uint8_t Pad_0x29[0x7]; // 0x29(0x7)


	// Object: Function Development.CloudGMHandle.InitCloudGM
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c4395c
	// Params: [ Num(0) Size(0x0) ]
	void InitCloudGM();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106C43C38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3D2FC

	// Object: Function Development.CloudGMHandle.DestroyCloudGM
	// Flags: [Final|Native|Public]
	// Offset: 0x106c43948
	// Params: [ Num(0) Size(0x0) ]
	void DestroyCloudGM();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10508F76C
	// [Call #5] RVA: 0x106C43C38
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3D2FC
};

// Object: Class Development.ImGuiFeatureWidget
// Size: 0xC0 (Inherited: 0x28)
struct UImGuiFeatureWidget : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
	struct FString FeatureName; // 0x80(0x10)
	struct FName FeatureID; // 0x90(0x8)
	bool bIsVisible; // 0x98(0x1)
	bool bIsEnabled; // 0x99(0x1)
	uint8_t Pad_0x9A[0x2]; // 0x9A(0x2)
	int FeaturePriority; // 0x9C(0x4)
	struct FString LuaFilePath; // 0xA0(0x10)
	bool bIsLuaInitialized; // 0xB0(0x1)
	uint8_t Pad_0xB1[0x3]; // 0xB1(0x3)
	struct TWeakObjectPtr<struct UObject> Owner; // 0xB4(0x8)
	bool bIsInitialized; // 0xBC(0x1)
	uint8_t Pad_0xBD[0x3]; // 0xBD(0x3)


	// Object: Function Development.ImGuiFeatureWidget.SetFeatureVisible
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106c66380
	// Params: [ Num(1) Size(0x1) ]
	void SetFeatureVisible(bool bVisible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.ImGuiFeatureWidget.SetFeatureEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x106c662f4
	// Params: [ Num(1) Size(0x1) ]
	void SetFeatureEnabled(bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.ImGuiFeatureWidget.IsFeatureVisible
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c662b8
	// Params: [ Num(1) Size(0x1) ]
	bool IsFeatureVisible();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.ImGuiFeatureWidget.IsFeatureEnabled
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c6627c
	// Params: [ Num(1) Size(0x1) ]
	bool IsFeatureEnabled();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x105190870
	// [Call #7] RVA: 0x10519022C

	// Object: Function Development.ImGuiFeatureWidget.GetOwnerWindow
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c66248
	// Params: [ Num(1) Size(0x8) ]
	struct AImGuiWindowBase* GetOwnerWindow();
	// [Call #1] RVA: 0x106C3B178
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870

	// Object: Function Development.ImGuiFeatureWidget.GetOwnerTab
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c66214
	// Params: [ Num(1) Size(0x8) ]
	struct UImGuiTabBase* GetOwnerTab();
	// [Call #1] RVA: 0x106C3B1C4
	// [Call #2] RVA: 0x106C3B178
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10519022C

	// Object: Function Development.ImGuiFeatureWidget.GetOwner
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c661e0
	// Params: [ Num(1) Size(0x8) ]
	struct UObject* GetOwner();
	// [Call #1] RVA: 0x106C3B13C
	// [Call #2] RVA: 0x106C3B1C4
	// [Call #3] RVA: 0x106C3B178
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiFeatureWidget.GetFeatureName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c66174
	// Params: [ Num(1) Size(0x10) ]
	struct FString GetFeatureName();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x106C3B13C
	// [Call #6] RVA: 0x106C3B1C4
	// [Call #7] RVA: 0x106C3B178
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168

	// Object: Function Development.ImGuiFeatureWidget.GetFeatureID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c66138
	// Params: [ Num(1) Size(0x8) ]
	struct FName GetFeatureID();
	// [Call #1] RVA: 0x101F8156C
	// [Call #2] RVA: 0x101F8130C
	// [Call #3] RVA: 0x101F8130C
	// [Call #4] RVA: 0x106C8459C
	// [Call #5] RVA: 0x106C3B13C
	// [Call #6] RVA: 0x106C3B1C4
	// [Call #7] RVA: 0x106C3B178
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
};

// Object: Class Development.DebugNameDisplayFeature
// Size: 0xD8 (Inherited: 0xC0)
struct UDebugNameDisplayFeature : UImGuiFeatureWidget
{
	bool bShowAllCharacterName; // 0xBD(0x1)
	bool bShowNearbyActorsName; // 0xBE(0x1)
	float NearbyActorDistance; // 0xC0(0x4)
	float ShowDebugNameDuration; // 0xC4(0x4)
	struct TArray<struct AActor*> ExcludedActorClasses; // 0xC8(0x10)


	// Object: Function Development.DebugNameDisplayFeature.AddExcludedActorClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c43b1c
	// Params: [ Num(1) Size(0x8) ]
	void AddExcludedActorClass(struct UObject* ActorClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3D2FC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x105190870
};

// Object: Class Development.DevConsole
// Size: 0x198 (Inherited: 0x130)
struct UDevConsole : UConsole
{
	uint8_t Pad_0x130[0x58]; // 0x130(0x58)
	struct TArray<struct FString> LuaCommandList; // 0x188(0x10)
};

// Object: Class Development.GMCheatSystem
// Size: 0x80 (Inherited: 0x28)
struct UGMCheatSystem : UObject
{
	uint8_t Pad_0x28[0x58]; // 0x28(0x58)
};

// Object: Class Development.GMCheatAI
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatAI : UGMCheatSystem
{

	// Object: Function Development.GMCheatAI.TeleportAIToLoc
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c445d8
	// Params: [ Num(3) Size(0xC) ]
	void TeleportAIToLoc(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BFBB88
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatAI.SpawnAITeam
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c444e8
	// Params: [ Num(3) Size(0x9) ]
	void SpawnAITeam(int Num, int AITeamID, uint8_t Difficulty);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BFB178
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFBB88
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Development.GMCheatAI.SpawnAIPosi
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c44380
	// Params: [ Num(5) Size(0x14) ]
	void SpawnAIPosi(int ID, int AITeamID, float PosiX, float PosiY, float PosiZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFB1D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106BFB178

	// Object: Function Development.GMCheatAI.SpawnAI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c442c4
	// Params: [ Num(2) Size(0x5) ]
	void SpawnAI(int Num, bool bSpawnAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFB124
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFB1D4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatAI.RecordReviveTowerInDSReplay
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c442b0
	// Params: [ Num(0) Size(0x0) ]
	void RecordReviveTowerInDSReplay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFB124
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFB1D4

	// Object: Function Development.GMCheatAI.MoveToAIWithClassName
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4415c
	// Params: [ Num(4) Size(0x1C) ]
	void MoveToAIWithClassName(struct FString AIClassName, float XOffset, float YOffset, float ZOffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFBB18
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106BFB124
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatAI.MoveToAIByDropItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c440e0
	// Params: [ Num(1) Size(0x4) ]
	void MoveToAIByDropItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFBDC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFBB18
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatAI.MoveToAI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c440cc
	// Params: [ Num(0) Size(0x0) ]
	void MoveToAI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFBDC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFBB18
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatAI.MobAIIgnorePlayers
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c440b8
	// Params: [ Num(0) Size(0x0) ]
	void MobAIIgnorePlayers();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFBDC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFBB18
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatAI.LogAIItemCount
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c44000
	// Params: [ Num(2) Size(0x8) ]
	void LogAIItemCount(int ItemId, float Distance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFB258
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFBDC4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatAI.FindAIDropItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c43f84
	// Params: [ Num(1) Size(0x4) ]
	void FindAIDropItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFC36C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFB258
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFBDC4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatAI.ChangeAIBehaviorTree
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c43f08
	// Params: [ Num(1) Size(0x4) ]
	void ChangeAIBehaviorTree(int TreeIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFB9EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFC36C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFB258
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFBDC4

	// Object: Function Development.GMCheatAI.AddAIItem
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c43e18
	// Params: [ Num(3) Size(0xC) ]
	void AddAIItem(int ID, int Count, float Distance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BFB5B8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFB9EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFC36C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
};

// Object: Class Development.GMCheatAnimation
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatAnimation : UGMCheatSystem
{

	// Object: Function Development.GMCheatAnimation.TestAnimation
	// Flags: [Final|Exec|Native|Private]
	// Offset: 0x106c44b7c
	// Params: [ Num(2) Size(0x5) ]
	void TestAnimation(int Param1, bool Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFC8F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
	// [Call #10] RVA: 0x106C46738

	// Object: Function Development.GMCheatAnimation.DumpCharacterAnimBPVars
	// Flags: [Final|Exec|Native|Private|BlueprintCallable]
	// Offset: 0x106c44b68
	// Params: [ Num(0) Size(0x0) ]
	void DumpCharacterAnimBPVars();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFC8F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10508F76C
};

// Object: Class Development.GMCheatAvatar
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatAvatar : UGMCheatSystem
{

	// Object: Function Development.GMCheatAvatar.UseLocalWeaponDIYData
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45dec
	// Params: [ Num(1) Size(0x1) ]
	void UseLocalWeaponDIYData(bool bFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFD810
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.GMCheatAvatar.UseLocalVehicleAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45dd8
	// Params: [ Num(0) Size(0x0) ]
	void UseLocalVehicleAvatar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFD810
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatAvatar.SetWeaponPendantShow
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45d54
	// Params: [ Num(1) Size(0x1) ]
	void SetWeaponPendantShow(bool bShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFCFA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFD810
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.GMCheatAvatar.SetVehicleAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45ca0
	// Params: [ Num(2) Size(0x8) ]
	void SetVehicleAvatar(int VehicleShapeType, int VehicleSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFDC0C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFCFA8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFD810
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870

	// Object: Function Development.GMCheatAvatar.SetPlayerTeamBodyInstMask
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45c24
	// Params: [ Num(1) Size(0x4) ]
	void SetPlayerTeamBodyInstMask(int Mask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFEF5C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFDC0C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFCFA8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFD810

	// Object: Function Development.GMCheatAvatar.SetPlayerBodyInstMask
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45ba8
	// Params: [ Num(1) Size(0x4) ]
	void SetPlayerBodyInstMask(int Mask);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFEEC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFEF5C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFDC0C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFCFA8

	// Object: Function Development.GMCheatAvatar.SetGrenadeAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45af4
	// Params: [ Num(2) Size(0x8) ]
	void SetGrenadeAvatar(int SubType, int EquipmentSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE680
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFEEC8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFEF5C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFDC0C

	// Object: Function Development.GMCheatAvatar.SetEquipmentAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45a40
	// Params: [ Num(2) Size(0x8) ]
	void SetEquipmentAvatar(int EquipmentAvatarType, int EquipmentSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE5B8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFE680
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFEEC8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFEF5C

	// Object: Function Development.GMCheatAvatar.SetEnableWingAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c459bc
	// Params: [ Num(1) Size(0x1) ]
	void SetEnableWingAvatar(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFF014
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFE5B8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE680
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFEEC8

	// Object: Function Development.GMCheatAvatar.SetDownloadInBattle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45938
	// Params: [ Num(1) Size(0x1) ]
	void SetDownloadInBattle(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE7A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFF014
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFE5B8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatAvatar.SetAvatarDownloadInBattle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c458b4
	// Params: [ Num(1) Size(0x1) ]
	void SetAvatarDownloadInBattle(bool bEnableDownload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE840
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFE7A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFF014
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFE5B8

	// Object: Function Development.GMCheatAvatar.PrintMainCharAllAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c458a0
	// Params: [ Num(0) Size(0x0) ]
	void PrintMainCharAllAvatar();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE840
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFE7A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFF014
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFE5B8

	// Object: Function Development.GMCheatAvatar.PrintAllStaticBufferSize
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4588c
	// Params: [ Num(0) Size(0x0) ]
	void PrintAllStaticBufferSize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE840
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFE7A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFF014
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFE5B8

	// Object: Function Development.GMCheatAvatar.DeleteVehicleAdvanceAvatar_Style
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c457d8
	// Params: [ Num(2) Size(0x8) ]
	void DeleteVehicleAdvanceAvatar_Style(int VehicleSkin, int VehicleStyle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE49C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFE840
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFE7A8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFF014

	// Object: Function Development.GMCheatAvatar.DeleteVehicleAdvanceAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45724
	// Params: [ Num(2) Size(0x8) ]
	void DeleteVehicleAdvanceAvatar(int VehicleSkin, int ModelID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE188
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFE49C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE840
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.DebugWorldPlayerAvatarInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45710
	// Params: [ Num(0) Size(0x0) ]
	void DebugWorldPlayerAvatarInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE188
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFE49C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE840

	// Object: Function Development.GMCheatAvatar.DebugChangeWearIndex
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45694
	// Params: [ Num(1) Size(0x4) ]
	void DebugChangeWearIndex(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE774
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFE188
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE49C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.ClearItemPathNotExistlist
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45680
	// Params: [ Num(0) Size(0x0) ]
	void ClearItemPathNotExistlist();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE774
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFE188
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE49C

	// Object: Function Development.GMCheatAvatar.ClearItemHandleNotExistlist
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4566c
	// Params: [ Num(0) Size(0x0) ]
	void ClearItemHandleNotExistlist();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE774
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFE188
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFE49C

	// Object: Function Development.GMCheatAvatar.ClearCharacterAvatarHandlePool
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c455e8
	// Params: [ Num(1) Size(0x1) ]
	void ClearCharacterAvatarHandlePool(bool bSelf);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFEB9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFE774
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFE188
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatAvatar.ChangeBattleAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c454c0
	// Params: [ Num(4) Size(0x10) ]
	void ChangeBattleAvatar(int HeadAvatarID, int HairAvatarID, int InGender, int PutOffAvatar);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFCDA4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFEB9C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106BFE774

	// Object: Function Development.GMCheatAvatar.AddWeaponPendantItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4540c
	// Params: [ Num(2) Size(0x8) ]
	void AddWeaponPendantItem(int WeaponId, int pendantID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFD894
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFCDA4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106BFEB9C

	// Object: Function Development.GMCheatAvatar.AddWeaponDIYPlan
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45358
	// Params: [ Num(2) Size(0x8) ]
	void AddWeaponDIYPlan(int AvatarID, int DIYPlanID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFD770
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFD894
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddWeaponAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c452dc
	// Params: [ Num(1) Size(0x4) ]
	void AddWeaponAvatar(int WeaponSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFD038
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFD770
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFD894
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddWeaponAttachmentAvatarSimple
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45228
	// Params: [ Num(2) Size(0x8) ]
	void AddWeaponAttachmentAvatarSimple(int WeaponId, int WeaponAttachmentSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFD5B0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFD038
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFD770
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddWeaponAttachmentAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45174
	// Params: [ Num(2) Size(0x8) ]
	void AddWeaponAttachmentAvatar(int WeaponId, int WeaponAttachmentSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFD218
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106BFD5B0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFD038
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddVehicleAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c450f8
	// Params: [ Num(1) Size(0x4) ]
	void AddVehicleAvatar(int VehicleSkin);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFDB1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFD218
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFD5B0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFD038

	// Object: Function Development.GMCheatAvatar.AddVehicleAdvanceAvatar_Style
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c45044
	// Params: [ Num(2) Size(0x8) ]
	void AddVehicleAdvanceAvatar_Style(int VehicleSkin, int VehicleStyle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106BFE324
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106BFDB1C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106BFD218
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddVehicleAdvanceAvatar
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c44ee0
	// Params: [ Num(5) Size(0x14) ]
	void AddVehicleAdvanceAvatar(int VehicleSkin, int ModelID, int ColorID, int PatternID, int ParticleID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFDFA0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFE324
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddItemPathNotExistlist
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c44e64
	// Params: [ Num(1) Size(0x4) ]
	void AddItemPathNotExistlist(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFE980
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFDFA0
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatAvatar.AddItemHandleNotExistlist
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c44de8
	// Params: [ Num(1) Size(0x4) ]
	void AddItemHandleNotExistlist(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFEA90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFE980
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106BFDFA0
};

// Object: Class Development.GMCheatBackpack
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatBackpack : UGMCheatSystem
{

	// Object: Function Development.GMCheatBackpack.UseItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46fac
	// Params: [ Num(1) Size(0x4) ]
	void UseItem(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFFE50
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.FlushItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46f30
	// Params: [ Num(1) Size(0x4) ]
	void FlushItem(int onlyStatic);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFFB88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFE50
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.DropItemsWithType
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46eb4
	// Params: [ Num(1) Size(0x4) ]
	void DropItemsWithType(int TypeItem);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFFAAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFB88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFE50
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.DropItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46e38
	// Params: [ Num(1) Size(0x4) ]
	void DropItem(int ID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFF8D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFAAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFB88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFFE50
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.DropAllItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46e24
	// Params: [ Num(0) Size(0x0) ]
	void DropAllItem();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFF8D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFAAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFB88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFFE50
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.DestroyPickUpActors
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46e10
	// Params: [ Num(0) Size(0x0) ]
	void DestroyPickUpActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFF8D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFAAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFB88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFFE50
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatBackpack.ClearBackpack
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46dfc
	// Params: [ Num(0) Size(0x0) ]
	void ClearBackpack();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106BFF8D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106BFFAAC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFB88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106BFFE50

	// Object: Function Development.GMCheatBackpack.BatchAddItemsString
	// Flags: [Final|Exec|Native|Public|HasOutParms]
	// Offset: 0x106c46d00
	// Params: [ Num(2) Size(0x11) ]
	void BatchAddItemsString(struct TArray<struct FString>& ItemDetailArray, bool bClearBackpack);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C00610
	// [Call #6] RVA: 0x101F8B9F8
	// [Call #7] RVA: 0x101F8B9F8
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106BFF8D0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106BFFAAC

	// Object: Function Development.GMCheatBackpack.BatchAddItemsFromFile
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46c20
	// Params: [ Num(2) Size(0x11) ]
	void BatchAddItemsFromFile(struct FString Filename, bool bClearBackpack);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C00744
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C00610
	// [Call #14] RVA: 0x101F8B9F8
	// [Call #15] RVA: 0x101F8B9F8
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatBackpack.AddItemString
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46b88
	// Params: [ Num(1) Size(0x10) ]
	void AddItemString(struct FString ItemDetail);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C000C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C00744
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C00610
	// [Call #20] RVA: 0x101F8B9F8

	// Object: Function Development.GMCheatBackpack.AddItemNew
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46a28
	// Params: [ Num(3) Size(0x18) ]
	void AddItemNew(struct FString ID, int Count, int PickupType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x106BFF7D4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x104EEF504
	// [Call #13] RVA: 0x100036FE0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C000C4
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatBackpack.AddItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46938
	// Params: [ Num(3) Size(0xC) ]
	void AddItem(int ID, int Count, int PickupType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106BFF6C8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106BFF7D4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Development.GMCheatBackpack.AddAvatarItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c46810
	// Params: [ Num(4) Size(0x10) ]
	void AddAvatarItem(int ID, int Color, int Pattern, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106BFFC48
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106BFF6C8
	// [Call #17] RVA: 0x10516D168
};

// Object: Class Development.GMCheatCharacter
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatCharacter : UGMCheatSystem
{

	// Object: Function Development.GMCheatCharacter.ToggleUserCmdDeltaSendAck
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c491b0
	// Params: [ Num(1) Size(0x1) ]
	void ToggleUserCmdDeltaSendAck(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C08
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.GMCheatCharacter.ToggleUserCmdDeltaFlag
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4912c
	// Params: [ Num(1) Size(0x1) ]
	void ToggleUserCmdDeltaFlag(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02BFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02C08
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatCharacter.ToggleUserCmdDeltaCheckSum
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c490a8
	// Params: [ Num(1) Size(0x1) ]
	void ToggleUserCmdDeltaCheckSum(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C00
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02BFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02C08
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatCharacter.ToggleUserCmdDelta
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c49024
	// Params: [ Num(1) Size(0x1) ]
	void ToggleUserCmdDelta(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C0C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02C00
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02BFC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02C08
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatCharacter.ToggleServerAcknowledgePossession
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48fa0
	// Params: [ Num(1) Size(0x1) ]
	void ToggleServerAcknowledgePossession(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02C0C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02C00
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02BFC
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.ToggleCheatLocation
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48f1c
	// Params: [ Num(1) Size(0x1) ]
	void ToggleCheatLocation(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C10
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02C04
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02C0C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02C00
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.TestLowProbCircle
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c48e54
	// Params: [ Num(2) Size(0x8) ]
	void TestLowProbCircle(bool UseLowProb, int LoopCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C026C4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C02C10
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C02C04
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C02C0C

	// Object: Function Development.GMCheatCharacter.TestLaunchFly
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48dd8
	// Params: [ Num(1) Size(0x4) ]
	void TestLaunchFly(float Speed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02DFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C026C4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C02C10
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C02C04

	// Object: Function Development.GMCheatCharacter.TestAutoMoveToShootingMachine
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48dc4
	// Params: [ Num(0) Size(0x0) ]
	void TestAutoMoveToShootingMachine();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02DFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C026C4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C02C10
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C02C04

	// Object: Function Development.GMCheatCharacter.TestAutoMoveToLocation
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48cd4
	// Params: [ Num(3) Size(0xC) ]
	void TestAutoMoveToLocation(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C02FEC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02DFC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C026C4

	// Object: Function Development.GMCheatCharacter.TestAutoMoveToCharacter
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48bf0
	// Params: [ Num(1) Size(0x10) ]
	void TestAutoMoveToCharacter(struct FString TargetPlayerUID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C02EC8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C02FEC
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106C02DFC

	// Object: Function Development.GMCheatCharacter.TeamNoAlwaysRelevant
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48bdc
	// Params: [ Num(0) Size(0x0) ]
	void TeamNoAlwaysRelevant();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C02EC8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C02FEC
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.SwitchViewTarget
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48bc8
	// Params: [ Num(0) Size(0x0) ]
	void SwitchViewTarget();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C02EC8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C02FEC
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.StartAirDropSpecified
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48b14
	// Params: [ Num(2) Size(0x8) ]
	void StartAirDropSpecified(float X, float Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C02858
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C02EC8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.StartAirDropBackupEnter
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48a24
	// Params: [ Num(3) Size(0xC) ]
	void StartAirDropBackupEnter(float X, float Y, int MaxPlaneNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C02928
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02858
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106C02EC8

	// Object: Function Development.GMCheatCharacter.StartAirDrop
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c489a8
	// Params: [ Num(1) Size(0x4) ]
	void StartAirDrop(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C027A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02928
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C02858

	// Object: Function Development.GMCheatCharacter.StartAirAttackSpecified
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c488b8
	// Params: [ Num(3) Size(0xC) ]
	void StartAirAttackSpecified(float X, float Y, float Radius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C02C70
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C027A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C02928

	// Object: Function Development.GMCheatCharacter.StartAirAttack
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4883c
	// Params: [ Num(1) Size(0x4) ]
	void StartAirAttack(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02C70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C027A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.ShowWeaponRecordInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48828
	// Params: [ Num(0) Size(0x0) ]
	void ShowWeaponRecordInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02C70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C027A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.ShowVaultEnable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48814
	// Params: [ Num(0) Size(0x0) ]
	void ShowVaultEnable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02C70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C027A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.ShowResultWeaponRecordInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48800
	// Params: [ Num(0) Size(0x0) ]
	void ShowResultWeaponRecordInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02C70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C027A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.ShowAllRoles
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c487ec
	// Params: [ Num(0) Size(0x0) ]
	void ShowAllRoles();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02C70
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C027A4

	// Object: Function Development.GMCheatCharacter.SetTimeSpeedFactor
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48770
	// Params: [ Num(1) Size(0x4) ]
	void SetTimeSpeedFactor(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02BF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02B30
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C02C70

	// Object: Function Development.GMCheatCharacter.SetTimeSpeedCheck
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c486ec
	// Params: [ Num(1) Size(0x1) ]
	void SetTimeSpeedCheck(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02BF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02BF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02B30
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.SetSpeed
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48670
	// Params: [ Num(1) Size(0x4) ]
	void SetSpeed(float Modifier);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C027A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C02BF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02BF8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02B30

	// Object: Function Development.GMCheatCharacter.SetMaxHealth
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c485f4
	// Params: [ Num(1) Size(0x4) ]
	void SetMaxHealth(float Hp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02D70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C027A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02BF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02BF8

	// Object: Function Development.GMCheatCharacter.SetLowProbCircle
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c484cc
	// Params: [ Num(4) Size(0x10) ]
	void SetLowProbCircle(float X, float Y, float R, float Prob);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C025B8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02D70
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C027A0
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.SetCustomJumpPoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c483dc
	// Params: [ Num(3) Size(0xC) ]
	void SetCustomJumpPoint(float JmpX, float JmpY, float JmpRadius);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C03C24
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C025B8
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.SetCircleCenter
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c48344
	// Params: [ Num(1) Size(0x10) ]
	void SetCircleCenter(struct FString PointString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02370
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C03C24
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.SetCirCenterFixed
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c48244
	// Params: [ Num(3) Size(0xC) ]
	void SetCirCenterFixed(bool Enable, float X, float Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C01D98
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C02370
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.SetAirDropEnable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c481c0
	// Params: [ Num(1) Size(0x1) ]
	void SetAirDropEnable(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C00D78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C01D98
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C02370
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.SetAirAttackEnable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4813c
	// Params: [ Num(1) Size(0x1) ]
	void SetAirAttackEnable(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C00E20
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C00D78
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C01D98
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.Set2x2ForceCircleLastR
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c480c0
	// Params: [ Num(1) Size(0x4) ]
	void Set2x2ForceCircleLastR(float R);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C01F88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C00E20
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C00D78
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.Set2x2ForceCircle
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c47fd0
	// Params: [ Num(3) Size(0xC) ]
	void Set2x2ForceCircle(float X, float Y, float R);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C01E88
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C01F88
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C00E20
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.Set2x2CircleCenter
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c47ee0
	// Params: [ Num(3) Size(0xC) ]
	void Set2x2CircleCenter(int Index, float X, float Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C0204C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C01E88
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C01F88

	// Object: Function Development.GMCheatCharacter.Set2x2Circle3Center
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c47d40
	// Params: [ Num(6) Size(0x18) ]
	void Set2x2Circle3Center(float X1, float Y1, float X2, float Y2, float x3, float y3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C02178
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.PrintMovementLog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47cc4
	// Params: [ Num(1) Size(0x4) ]
	void PrintMovementLog(int PrintLog);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03994
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C02178
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.PrintDownCollision
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47cb0
	// Params: [ Num(0) Size(0x0) ]
	void PrintDownCollision();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03994
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C02178

	// Object: Function Development.GMCheatCharacter.MoveToXY
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47bfc
	// Params: [ Num(2) Size(0x8) ]
	void MoveToXY(float X, float Y);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C0156C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C03994
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.MoveToVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47b80
	// Params: [ Num(1) Size(0x4) ]
	void MoveToVehicle(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03318
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C0156C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C03994
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.MoveToS
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c47ae8
	// Params: [ Num(1) Size(0x10) ]
	void MoveToS(struct FString VectorString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0142C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C03318
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0156C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C03994

	// Object: Function Development.GMCheatCharacter.MoveToNearestVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47a6c
	// Params: [ Num(1) Size(0x4) ]
	void MoveToNearestVehicle(float IgnoreDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03564
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C0142C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C03318
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C0156C

	// Object: Function Development.GMCheatCharacter.MoveToItem
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c479f0
	// Params: [ Num(1) Size(0x4) ]
	void MoveToItem(int ItemId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C030CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C03564
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C0142C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C03318
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.MoveTo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47900
	// Params: [ Num(3) Size(0xC) ]
	void MoveTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C0136C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C030CC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C03564
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C0142C

	// Object: Function Development.GMCheatCharacter.ModifyStreamingDistance
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c47884
	// Params: [ Num(1) Size(0x4) ]
	void ModifyStreamingDistance(int Distance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C02C1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C0136C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C030CC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C03564

	// Object: Function Development.GMCheatCharacter.KillSomeOne
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c477ec
	// Params: [ Num(1) Size(0x10) ]
	void KillSomeOne(struct FString InPlayerName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C00B34
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02C1C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C0136C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.KillAll
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c477d8
	// Params: [ Num(0) Size(0x0) ]
	void KillAll();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C00B34
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C02C1C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C0136C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.Kill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4775c
	// Params: [ Num(1) Size(0x4) ]
	void Kill(int GivenNumber);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0113C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C00B34
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C02C1C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.GMSetPlayerLocationInvalid
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4766c
	// Params: [ Num(3) Size(0xC) ]
	void GMSetPlayerLocationInvalid(uint32_t InPlayerKey, int errorType, int Side);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C01770
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C0113C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C00B34
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.GMSetCampId
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c475f0
	// Params: [ Num(1) Size(0x4) ]
	void GMSetCampId(int CamID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03A4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C01770
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C0113C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.GetGameScreenSize
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c475dc
	// Params: [ Num(0) Size(0x0) ]
	void GetGameScreenSize();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C03A4C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C01770
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C0113C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatCharacter.ExecFollowTeammate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c474f8
	// Params: [ Num(1) Size(0x10) ]
	void ExecFollowTeammate(struct FString Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C00A18
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C03A4C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106C01770

	// Object: Function Development.GMCheatCharacter.DebugSprint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c474e4
	// Params: [ Num(0) Size(0x0) ]
	void DebugSprint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C00A18
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C03A4C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatCharacter.DebugPhysicsAsset
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c474d0
	// Params: [ Num(0) Size(0x0) ]
	void DebugPhysicsAsset();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C00A18
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C03A4C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
};

// Object: Class Development.GMCheatDump
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatDump : UGMCheatSystem
{

	// Object: Function Development.GMCheatDump.DumpWeaponsToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b478
	// Params: [ Num(1) Size(0x10) ]
	void DumpWeaponsToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0B6A8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Development.GMCheatDump.DumpVehicleToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b394
	// Params: [ Num(1) Size(0x10) ]
	void DumpVehicleToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C097F8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0B6A8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
	// [Call #24] RVA: 0x105190870

	// Object: Function Development.GMCheatDump.DumpVehicleAnimInstanceToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b2b0
	// Params: [ Num(1) Size(0x10) ]
	void DumpVehicleAnimInstanceToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0B348
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C097F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C
	// [Call #26] RVA: 0x106C0B6A8
	// [Call #27] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpVehicleAnimInstance
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b29c
	// Params: [ Num(0) Size(0x0) ]
	void DumpVehicleAnimInstance();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0B348
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C097F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C

	// Object: Function Development.GMCheatDump.DumpVehicle
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b288
	// Params: [ Num(0) Size(0x0) ]
	void DumpVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0B348
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C097F8
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpSimulatedCharacterAnimInstanceToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b1a4
	// Params: [ Num(1) Size(0x10) ]
	void DumpSimulatedCharacterAnimInstanceToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0ADE4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0B348
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpSimulatedCharacterAnimInstance
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b190
	// Params: [ Num(0) Size(0x0) ]
	void DumpSimulatedCharacterAnimInstance();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0ADE4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0B348
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpReticleTargetActorToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4b05c
	// Params: [ Num(2) Size(0x11) ]
	void DumpReticleTargetActorToFile(struct FString Filename, bool bPrintFunc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C0C5F0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C0ADE4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function Development.GMCheatDump.DumpReticleTargetActor
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4afd8
	// Params: [ Num(1) Size(0x1) ]
	void DumpReticleTargetActor(bool bPrintFunc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0C3CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C0C5F0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0ADE4

	// Object: Function Development.GMCheatDump.DumpPlayerSkillInfo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4afc4
	// Params: [ Num(0) Size(0x0) ]
	void DumpPlayerSkillInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0C3CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C0C5F0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpPlayerInfoToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4aee0
	// Params: [ Num(1) Size(0x10) ]
	void DumpPlayerInfoToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0C018
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0C3CC
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0C5F0
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpPlayerControllerToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4adfc
	// Params: [ Num(1) Size(0x10) ]
	void DumpPlayerControllerToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C09D9C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0C018
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C0C3CC

	// Object: Function Development.GMCheatDump.DumpPlayerController
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4ade8
	// Params: [ Num(0) Size(0x0) ]
	void DumpPlayerController();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C09D9C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0C018
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpPlayerCameraManagerToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4ad04
	// Params: [ Num(1) Size(0x10) ]
	void DumpPlayerCameraManagerToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08614
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C09D9C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C

	// Object: Function Development.GMCheatDump.DumpObservingCharacterToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4ac20
	// Params: [ Num(1) Size(0x10) ]
	void DumpObservingCharacterToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C09444
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08614
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x101F8122C

	// Object: Function Development.GMCheatDump.DumpObservingCharacter
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4ac0c
	// Params: [ Num(0) Size(0x0) ]
	void DumpObservingCharacter();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C09444
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08614
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpObjectPropertiesRecursive
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4aaf0
	// Params: [ Num(3) Size(0x15) ]
	void DumpObjectPropertiesRecursive(struct FString ObjectName, int Depth, bool bPrintFunc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C0E708
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106C09444
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168

	// Object: Function Development.GMCheatDump.DumpObjectProperties
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4aa58
	// Params: [ Num(1) Size(0x10) ]
	void DumpObjectProperties(struct FString ObjectName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C04D44
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C0E708
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C09444
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpCharacterToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a974
	// Params: [ Num(1) Size(0x10) ]
	void DumpCharacterToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08288
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C04D44
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpCharacterAnimInstanceToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a890
	// Params: [ Num(1) Size(0x10) ]
	void DumpCharacterAnimInstanceToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A868
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08288
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C04D44
	// [Call #26] RVA: 0x101F8130C
	// [Call #27] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpCharacterAnimInstance
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a87c
	// Params: [ Num(0) Size(0x0) ]
	void DumpCharacterAnimInstance();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A868
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08288
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C04D44
	// [Call #26] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpCharacter
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a868
	// Params: [ Num(0) Size(0x0) ]
	void DumpCharacter();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A868
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08288
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpBatchManager
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4a854
	// Params: [ Num(0) Size(0x0) ]
	void DumpBatchManager();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A868
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C08288
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpAllVehiclesToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a770
	// Params: [ Num(1) Size(0x10) ]
	void DumpAllVehiclesToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08F34
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0A868
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatDump.DumpAllVehicles
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a75c
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllVehicles();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08F34
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C0A868
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168

	// Object: Function Development.GMCheatDump.DumpAllSkillActorsInfoToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a638
	// Params: [ Num(2) Size(0x14) ]
	void DumpAllSkillActorsInfoToFile(struct FString Filename, int Depth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C0DF14
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C08F34
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C

	// Object: Function Development.GMCheatDump.DumpAllSkillActorsInfo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a5bc
	// Params: [ Num(1) Size(0x4) ]
	void DumpAllSkillActorsInfo(int Depth);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0CB08
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C0DF14
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C08F34
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpAllPlayerControllerToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a4d8
	// Params: [ Num(1) Size(0x10) ]
	void DumpAllPlayerControllerToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A1F4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0CB08
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0DF14
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpAllPlayerController
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a4c4
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllPlayerController();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0A1F4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0CB08
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0DF14
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpAllCustomActorsInfoToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a3a0
	// Params: [ Num(2) Size(0x18) ]
	void DumpAllCustomActorsInfoToFile(struct AActor* DesiredClass, struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C0E38C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C0A1F4
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168

	// Object: Function Development.GMCheatDump.DumpAllCustomActorsInfo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a324
	// Params: [ Num(1) Size(0x8) ]
	void DumpAllCustomActorsInfo(struct AActor* DesiredClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0E210
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C0E38C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0A1F4
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpAllCharactersToFile
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a240
	// Params: [ Num(1) Size(0x10) ]
	void DumpAllCharactersToFile(struct FString Filename);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08960
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0E210
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0E38C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Development.GMCheatDump.DumpAllCharacters
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4a22c
	// Params: [ Num(0) Size(0x0) ]
	void DumpAllCharacters();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C08960
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0E210
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C0E38C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
};

// Object: Class Development.GMCheatGameFlow
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatGameFlow : UGMCheatSystem
{

	// Object: Function Development.GMCheatGameFlow.StartReadyCountDown
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4c194
	// Params: [ Num(0) Size(0x0) ]
	void StartReadyCountDown();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.GMCheatGameFlow.SetStateLeftTime
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4c118
	// Params: [ Num(1) Size(0x4) ]
	void SetStateLeftTime(int LeftTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0F920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatGameFlow.GotoFlying
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4c104
	// Params: [ Num(0) Size(0x0) ]
	void GotoFlying();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0F920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatGameFlow.GameModeGotoNextState
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4c0f0
	// Params: [ Num(0) Size(0x0) ]
	void GameModeGotoNextState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0F920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatGameFlow.GameModeGotoFightingState
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4c0dc
	// Params: [ Num(0) Size(0x0) ]
	void GameModeGotoFightingState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0F920
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatGameFlow.DsLuaGM
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4bff8
	// Params: [ Num(1) Size(0x10) ]
	void DsLuaGM(struct FString CmdString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C0F630
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C0F920
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Development.GMCheatGameFlow.DsLuaDoString
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4bf60
	// Params: [ Num(1) Size(0x10) ]
	void DsLuaDoString(struct FString LuaString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0F564
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C0F630
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106C0F920
};

// Object: Class Development.GMCheatHiggs
// Size: 0x158 (Inherited: 0x80)
struct UGMCheatHiggs : UGMCheatSystem
{
	uint8_t Pad_0x80[0xD8]; // 0x80(0xD8)


	// Object: Function Development.GMCheatHiggs.TriggerActorChannelErrorDelegate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4defc
	// Params: [ Num(0) Size(0x0) ]
	void TriggerActorChannelErrorDelegate();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.GMCheatHiggs.TestSpawnStaticmesh
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4de80
	// Params: [ Num(1) Size(0x4) ]
	void TestSpawnStaticmesh(int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C0FFD0
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatHiggs.TestGMCheatHiggs
	// Flags: [Final|Exec|Native|Private]
	// Offset: 0x106c4ddc4
	// Params: [ Num(2) Size(0x5) ]
	void TestGMCheatHiggs(int Param1, bool Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C0FD40
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C0FFD0
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x105190870
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatHiggs.TestGlueHia
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4dd10
	// Params: [ Num(2) Size(0x8) ]
	void TestGlueHia(int GlueType, int GlueValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C0FF24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C0FD40
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C0FFD0
	// [Call #14] RVA: 0x10519022C

	// Object: Function Development.GMCheatHiggs.StatCPU
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4dc94
	// Params: [ Num(1) Size(0x4) ]
	void StatCPU(int Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C100D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C0FF24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C0FD40
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C0FFD0

	// Object: Function Development.GMCheatHiggs.SetOpenSecurityAlert
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x1) ]
	void SetOpenSecurityAlert(bool bOpen);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Development.GMCheatHiggs.OnFinishAsyncLoadResource
	// Flags: [Final|Native|Private|HasDefaults]
	// Offset: 0x106c4dbc8
	// Params: [ Num(1) Size(0x18) ]
	void OnFinishAsyncLoadResource(struct FSoftObjectPath SoftObjectPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x1020FDC08
	// [Call #4] RVA: 0x106C1047C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C100D0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C0FF24
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatHiggs.HiggsTestSyncLoad
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4db30
	// Params: [ Num(1) Size(0x10) ]
	void HiggsTestSyncLoad(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C104E0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020FDC08
	// [Call #10] RVA: 0x106C1047C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C100D0
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168

	// Object: Function Development.GMCheatHiggs.HiggsTestForbitMove
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4db1c
	// Params: [ Num(0) Size(0x0) ]
	void HiggsTestForbitMove();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C104E0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x1020FDC08
	// [Call #10] RVA: 0x106C1047C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C100D0
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatHiggs.HiggsTestAsyncLoad
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4da84
	// Params: [ Num(1) Size(0x10) ]
	void HiggsTestAsyncLoad(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C10250
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C104E0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020FDC08
	// [Call #16] RVA: 0x106C1047C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168

	// Object: Function Development.GMCheatHiggs.DebugReplaySampleLocAndRot
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4da70
	// Params: [ Num(0) Size(0x0) ]
	void DebugReplaySampleLocAndRot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C10250
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C104E0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x1020FDC08
	// [Call #16] RVA: 0x106C1047C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
};

// Object: Class Development.GMCheatHUD
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatHUD : UGMCheatSystem
{

	// Object: Function Development.GMCheatHUD.ResetHUDDebugFunction
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e58c
	// Params: [ Num(0) Size(0x0) ]
	void ResetHUDDebugFunction();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10508F76C
	// [Call #7] RVA: 0x106C4F90C

	// Object: Function Development.GMCheatHUD.RemoveHUDDebugFunction
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e4f4
	// Params: [ Num(1) Size(0x10) ]
	void RemoveHUDDebugFunction(struct FString FuncName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C10850
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatHUD.EnableHUDDebug
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e410
	// Params: [ Num(2) Size(0x18) ]
	void EnableHUDDebug(bool bEnable, struct FString FuncName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C109F0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C10850
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870
	// [Call #17] RVA: 0x10519022C

	// Object: Function Development.GMCheatHUD.AddHUDDebugFunction
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e330
	// Params: [ Num(2) Size(0x11) ]
	void AddHUDDebugFunction(struct FString FuncName, bool bReset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1075C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C109F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C10850
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
};

// Object: Class Development.GMCheatLevel
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatLevel : UGMCheatSystem
{

	// Object: Function Development.GMCheatLevel.SpawnActorWithPath
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4f044
	// Params: [ Num(4) Size(0x1C) ]
	void SpawnActorWithPath(struct FString Path, float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C118E0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x10519022C

	// Object: Function Development.GMCheatLevel.ShutDownVehicleGenerate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4efc0
	// Params: [ Num(1) Size(0x1) ]
	void ShutDownVehicleGenerate(bool IsOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1269C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C118E0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10519022C
	// [Call #17] RVA: 0x105190870

	// Object: Function Development.GMCheatLevel.ShutDownPickUpGenerate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ef3c
	// Params: [ Num(1) Size(0x1) ]
	void ShutDownPickUpGenerate(bool IsOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C124E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1269C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C118E0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Development.GMCheatLevel.ShutDownItemGenerate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eeb8
	// Params: [ Num(1) Size(0x1) ]
	void ShutDownItemGenerate(bool IsOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C122E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C124E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1269C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.ShowNavOperator
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eea4
	// Params: [ Num(0) Size(0x0) ]
	void ShowNavOperator();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C122E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C124E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1269C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.SetServerLevelLoadingMode
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ee20
	// Params: [ Num(1) Size(0x1) ]
	void SetServerLevelLoadingMode(bool bNewLoadAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C128A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C122E4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C124E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1269C
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.SetPlaneEnabled
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ed9c
	// Params: [ Num(1) Size(0x1) ]
	void SetPlaneEnabled(bool InEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C12918
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C128A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C122E4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C124E0
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.SetCustomFlightRoute
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ec74
	// Params: [ Num(4) Size(0x10) ]
	void SetCustomFlightRoute(float StartX, float StartY, float EndX, float EndY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C128A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C12918
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C128A0

	// Object: Function Development.GMCheatLevel.RemoveAllDoors
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ec60
	// Params: [ Num(0) Size(0x0) ]
	void RemoveAllDoors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C128A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C12918
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C128A0

	// Object: Function Development.GMCheatLevel.PrintAllPickupWarpper
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ec4c
	// Params: [ Num(0) Size(0x0) ]
	void PrintAllPickupWarpper();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C128A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C12918
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C128A0

	// Object: Function Development.GMCheatLevel.LocalProfileFootprint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ec38
	// Params: [ Num(0) Size(0x0) ]
	void LocalProfileFootprint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C128A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C12918
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.LoadAllLand
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ebb4
	// Params: [ Num(1) Size(0x1) ]
	void LoadAllLand(bool bLoadAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C12840
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C128A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.GotoDoubleCircleEdge
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eb38
	// Params: [ Num(1) Size(0x4) ]
	void GotoDoubleCircleEdge(float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C128A4

	// Object: Function Development.GMCheatLevel.GMSetBoolPoisonCircle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eb24
	// Params: [ Num(0) Size(0x0) ]
	void GMSetBoolPoisonCircle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.GMSetBoolAirDrop
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eb10
	// Params: [ Num(0) Size(0x0) ]
	void GMSetBoolAirDrop();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GMSetBoolAirAttack
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eafc
	// Params: [ Num(0) Size(0x0) ]
	void GMSetBoolAirAttack();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GMSetBoolAI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eae8
	// Params: [ Num(0) Size(0x0) ]
	void GMSetBoolAI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.GMEnableRandom
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ead4
	// Params: [ Num(0) Size(0x0) ]
	void GMEnableRandom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GMEnableAllComponent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eac0
	// Params: [ Num(0) Size(0x0) ]
	void GMEnableAllComponent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GMDisableRandom
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4eaac
	// Params: [ Num(0) Size(0x0) ]
	void GMDisableRandom();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.GMDisableAllComponent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4ea98
	// Params: [ Num(0) Size(0x0) ]
	void GMDisableAllComponent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C11404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C12840
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GMBeginCircle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e9a8
	// Params: [ Num(3) Size(0xC) ]
	void GMBeginCircle(int CurIndex, float PosX, float PosY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C129DC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C11404
	// [Call #11] RVA: 0x10516D168

	// Object: Function Development.GMCheatLevel.GetCurrentLevelOffset
	// Flags: [Final|Exec|Native|Public|HasDefaults]
	// Offset: 0x106c4e970
	// Params: [ Num(1) Size(0xC) ]
	struct FVector GetCurrentLevelOffset();
	// [Call #1] RVA: 0x106C11628
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C129DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C11404

	// Object: Function Development.GMCheatLevel.EnableMyLandscapeDraw
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e95c
	// Params: [ Num(0) Size(0x0) ]
	void EnableMyLandscapeDraw();
	// [Call #1] RVA: 0x106C11628
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C129DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C11404

	// Object: Function Development.GMCheatLevel.DisableMyLandscapeDraw
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e948
	// Params: [ Num(0) Size(0x0) ]
	void DisableMyLandscapeDraw();
	// [Call #1] RVA: 0x106C11628
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C129DC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatLevel.DebugAirDropPickInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4e7e4
	// Params: [ Num(5) Size(0x14) ]
	void DebugAirDropPickInfo(float DrawTime, float BoxDrawSize, float BoxDrawLineLength, float ListWrapperDrawSize, float ListWrapperDrawLineLength);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C12914
	// [Call #12] RVA: 0x106C11628
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class Development.GMCheatManager
// Size: 0x128 (Inherited: 0x78)
struct UGMCheatManager : UCheatManager
{
	uint8_t Pad_0x78[0x58]; // 0x78(0x58)
	struct TArray<struct UGMCheatSystem*> GMCheatSystems; // 0xD0(0x10)
	struct AActor* PVETestMonster; // 0xE0(0x8)
	uint8_t Pad_0xE8[0x30]; // 0xE8(0x30)
	struct TArray<struct ASkeletalMeshActor*> SkeletalMeshActorPool; // 0x118(0x10)


	// Object: Function Development.GMCheatManager.WatchReport
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5a3b0
	// Params: [ Num(0) Size(0x0) ]
	void WatchReport();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.GMCheatManager.VehicleTowardTo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5a2c0
	// Params: [ Num(3) Size(0xC) ]
	void VehicleTowardTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C24D18
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatManager.VehicleSpotLog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5a2ac
	// Params: [ Num(0) Size(0x0) ]
	void VehicleSpotLog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C24D18
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x105190870
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatManager.VehicleMoveTo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5a1bc
	// Params: [ Num(3) Size(0xC) ]
	void VehicleMoveTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C24C14
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C24D18
	// [Call #15] RVA: 0x10519022C

	// Object: Function Development.GMCheatManager.VehicleMoveAndTowardTo
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5a01c
	// Params: [ Num(6) Size(0x18) ]
	void VehicleMoveAndTowardTo(float X, float Y, float Z, float X1, float Y1, float Z1);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C24E40
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.UpdateTrainingRank
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59ef4
	// Params: [ Num(4) Size(0x10) ]
	void UpdateTrainingRank(int TrainingType, int Level, int Top1wScore, int Score);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2759C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ToggleSpringMode
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59ee0
	// Params: [ Num(0) Size(0x0) ]
	void ToggleSpringMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2759C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ToggleSpringDebug
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59ecc
	// Params: [ Num(0) Size(0x0) ]
	void ToggleSpringDebug();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2759C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.TogglePawnInfo
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59eb8
	// Params: [ Num(0) Size(0x0) ]
	void TogglePawnInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2759C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TestStringSHA1
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59e20
	// Params: [ Num(1) Size(0x10) ]
	void TestStringSHA1(struct FString InStr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A47C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C2759C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.TestReplayStreamerLastError
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59e0c
	// Params: [ Num(0) Size(0x0) ]
	void TestReplayStreamerLastError();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A47C
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C2759C
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TestPlayerLostEvent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59d90
	// Params: [ Num(1) Size(0x4) ]
	void TestPlayerLostEvent(int LostEvent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A47C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TestPlayerBattleResult
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c59d7c
	// Params: [ Num(0) Size(0x0) ]
	void TestPlayerBattleResult();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A47C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TestNetworkLost
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59d68
	// Params: [ Num(0) Size(0x0) ]
	void TestNetworkLost();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A47C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.TestLineTrace
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59c78
	// Params: [ Num(3) Size(0xC) ]
	void TestLineTrace(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C18640
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C2A388
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2A47C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.TestKillInfoPanel
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c59b50
	// Params: [ Num(4) Size(0x10) ]
	void TestKillInfoPanel(int WeaponId, int Relationship, int WeaponAvatarID, int ClothID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C275A8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C18640

	// Object: Function Development.GMCheatManager.TestGameplayDataRecord
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59a9c
	// Params: [ Num(2) Size(0x8) ]
	void TestGameplayDataRecord(int UID, int RecordType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C147CC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C275A8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TestEnableRegionsLongDistanceSleep
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c59a18
	// Params: [ Num(1) Size(0x1) ]
	void TestEnableRegionsLongDistanceSleep(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A1B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C147CC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C275A8

	// Object: Function Development.GMCheatManager.TestDeactivate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59a04
	// Params: [ Num(0) Size(0x0) ]
	void TestDeactivate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A1B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C147CC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.TestCrash
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c599f0
	// Params: [ Num(0) Size(0x0) ]
	void TestCrash();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A1B8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C147CC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.TeleportToVehicleAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c59974
	// Params: [ Num(1) Size(0x4) ]
	void TeleportToVehicleAI(int InIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C290AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A1B8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C147CC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TeleportToPVEMonster
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59884
	// Params: [ Num(3) Size(0xC) ]
	void TeleportToPVEMonster(int ChapterID, int LevelID, int WaveID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1A570
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C290AC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2A1B8
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.TeleportTo
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59794
	// Params: [ Num(3) Size(0xC) ]
	void TeleportTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C14420
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1A570
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C290AC

	// Object: Function Development.GMCheatManager.TeleportNearestVehicleAIToPercentOfPath
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c59718
	// Params: [ Num(1) Size(0x4) ]
	void TeleportNearestVehicleAIToPercentOfPath(float InPercent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C29440
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C14420
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C1A570

	// Object: Function Development.GMCheatManager.SwitchSocialIsland
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59660
	// Params: [ Num(2) Size(0x8) ]
	void SwitchSocialIsland(int LandId, float Delay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C26100
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29440
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C14420
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SwitchShowUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5964c
	// Params: [ Num(0) Size(0x0) ]
	void SwitchShowUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C26100
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29440
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C14420

	// Object: Function Development.GMCheatManager.SuperGMKillDS
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c59638
	// Params: [ Num(0) Size(0x0) ]
	void SuperGMKillDS();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C26100
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29440
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C14420

	// Object: Function Development.GMCheatManager.StopAllMonsterDSAnim
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c595b4
	// Params: [ Num(1) Size(0x1) ]
	void StopAllMonsterDSAnim(bool bStop);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25F78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C26100
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C29440
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.StatVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c595a0
	// Params: [ Num(0) Size(0x0) ]
	void StatVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25F78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C26100
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C29440
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.StarTPerforPlatTag
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c594bc
	// Params: [ Num(1) Size(0x10) ]
	void StarTPerforPlatTag(struct FString TagName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C22C98
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C25F78
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C26100

	// Object: Function Development.GMCheatManager.SpawnVehicleWithPathAtPoint
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c592d8
	// Params: [ Num(6) Size(0x24) ]
	void SpawnVehicleWithPathAtPoint(struct FString Path, bool AroundMe, float X, float Y, float Z, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C23804
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SpawnTrainingAIAroundMe
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c59224
	// Params: [ Num(2) Size(0x8) ]
	void SpawnTrainingAIAroundMe(int Num, int Range);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C2712C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C23804

	// Object: Function Development.GMCheatManager.SpawnMonsterAround
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c590f0
	// Params: [ Num(4) Size(0xD) ]
	void SpawnMonsterAround(int MonsterID, float Radius, int Num, bool bStopAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C13D3C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C2712C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SpawnItemBySpotDefaultTag
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5900c
	// Params: [ Num(1) Size(0x10) ]
	void SpawnItemBySpotDefaultTag(struct FString DefaultTag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C260F8
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106C13D3C
	// [Call #21] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SpawnGameFeatureActor
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58f74
	// Params: [ Num(1) Size(0x10) ]
	void SpawnGameFeatureActor(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A370
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C260F8
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SpawnFakePlayer
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c58e68
	// Params: [ Num(3) Size(0x6) ]
	void SpawnFakePlayer(int Num, bool bWithPet, bool bStopAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C13784
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C2A370
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C260F8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.SpawnDecal
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58e54
	// Params: [ Num(0) Size(0x0) ]
	void SpawnDecal();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C13784
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C2A370
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C260F8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.SpawnBotForTest
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c58dd8
	// Params: [ Num(1) Size(0x4) ]
	void SpawnBotForTest(int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C13780
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C13784
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2A370
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.SpawnAIAroundMe
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c58c4c
	// Params: [ Num(5) Size(0xB) ]
	void SpawnAIAroundMe(int Num, float Range, bool HasWeapon, bool HasAvator, bool HasBackpack);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C26B04
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C13780
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ShowScrollMsg
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c58a90
	// Params: [ Num(3) Size(0x28) ]
	void ShowScrollMsg(uint32_t MsgID, struct FString Param1, struct FString Param2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C1FC10
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ShowPet
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c58a0c
	// Params: [ Num(1) Size(0x1) ]
	void ShowPet(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C182CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106C1FC10
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.ShowOBMultiKillTips
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5886c
	// Params: [ Num(4) Size(0x1C) ]
	void ShowOBMultiKillTips(struct FString PlayerName, int TeamID, int PlayerKillNum, int TeamKillNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C28E90
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x106C182CC
	// [Call #21] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ShowHideGuide
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c587b0
	// Params: [ Num(2) Size(0x5) ]
	void ShowHideGuide(int GuideID, bool bShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28658
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C28E90
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.ShowAllPlayersMarkIncludeAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c58734
	// Params: [ Num(1) Size(0x4) ]
	void ShowAllPlayersMarkIncludeAI(float VisDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C261D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C28658
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ShowAKComponentPosition
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c586b0
	// Params: [ Num(1) Size(0x1) ]
	void ShowAKComponentPosition(bool _IsShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1FCF0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C261D4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28658
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetWeatherPlaySpeed
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58634
	// Params: [ Num(1) Size(0x4) ]
	void SetWeatherPlaySpeed(float FSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF44
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1FCF0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C261D4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28658

	// Object: Function Development.GMCheatManager.SetViewFPP
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c585b0
	// Params: [ Num(1) Size(0x1) ]
	void SetViewFPP(bool IsFPP);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18780
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DF44
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1FCF0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C261D4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetTouchMoveLog
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c5852c
	// Params: [ Num(1) Size(0x1) ]
	void SetTouchMoveLog(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C182C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18780
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DF44
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1FCF0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetTouchMoveDelay
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c584b0
	// Params: [ Num(1) Size(0x4) ]
	void SetTouchMoveDelay(int DelayFrame);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C185CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C182C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18780
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DF44
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetSpringArm
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58434
	// Params: [ Num(1) Size(0x1) ]
	void SetSpringArm(uint8_t armFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C19E70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C185CC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C182C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C18780
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetSkillDup
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c583b8
	// Params: [ Num(1) Size(0x4) ]
	void SetSkillDup(int Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C19100
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C19E70
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C185CC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C182C8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetRateScore
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5833c
	// Params: [ Num(1) Size(0x4) ]
	void SetRateScore(float RankScore);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18498
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C19100
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C19E70
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C185CC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNetSpeed
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c582c0
	// Params: [ Num(1) Size(0x4) ]
	void SetNetSpeed(int NewSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C288C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18498
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C19100
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C19E70
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNeckUp
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58244
	// Params: [ Num(1) Size(0x4) ]
	void SetNeckUp(float UpAngle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18E78
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C288C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18498
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C19100
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNeckSpeed
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c581c8
	// Params: [ Num(1) Size(0x4) ]
	void SetNeckSpeed(float Speed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18F5C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18E78
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C288C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C18498
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNeckRight
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5814c
	// Params: [ Num(1) Size(0x4) ]
	void SetNeckRight(float RightAngle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18C68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18F5C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18E78
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C288C8
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNeckMax
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c580d0
	// Params: [ Num(1) Size(0x4) ]
	void SetNeckMax(float MaxAngle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18D70
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18C68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18F5C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C18E78
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetNeckLeft
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c58054
	// Params: [ Num(1) Size(0x4) ]
	void SetNeckLeft(float LeftAngle);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18B60
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18D70
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18C68
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C18F5C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetMonsterNumMultiple
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57f64
	// Params: [ Num(3) Size(0xC) ]
	void SetMonsterNumMultiple(int ChapterID, int LevelID, int DiffcultPerc);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1AB28
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C18B60
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C18D70
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C18C68

	// Object: Function Development.GMCheatManager.SetMonsterNB
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57ee0
	// Params: [ Num(1) Size(0x1) ]
	void SetMonsterNB(bool MonsterNB);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1D7FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1AB28
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C18B60
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetMonsterHatred
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57e64
	// Params: [ Num(1) Size(0x4) ]
	void SetMonsterHatred(float Hatred);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1E4F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1D7FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1AB28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetMaxFpsFromDevice
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57e50
	// Params: [ Num(0) Size(0x0) ]
	void SetMaxFpsFromDevice();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1E4F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1D7FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1AB28
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetIsRender
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57dcc
	// Params: [ Num(1) Size(0x1) ]
	void SetIsRender(bool IsRender);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1D7C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1E4F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D7FC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetInactiveClearEnable
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c57d48
	// Params: [ Num(1) Size(0x1) ]
	void SetInactiveClearEnable(bool bNewActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C266A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1D7C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1E4F0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1D7FC
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SetHignPerformance
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57cc4
	// Params: [ Num(1) Size(0x1) ]
	void SetHignPerformance(bool SetOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A250
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C266A8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D7C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E4F0
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SetGVMemberID
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57c48
	// Params: [ Num(1) Size(0x4) ]
	void SetGVMemberID(int memberID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C177A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A250
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C266A8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1D7C8
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SetFestivalAirDrop
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c57b18
	// Params: [ Num(2) Size(0x18) ]
	void SetFestivalAirDrop(bool bFestival, struct FString BoxMesh);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C1913C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C177A0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C2A250

	// Object: Function Development.GMCheatManager.SetFestivaGrenade
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57a94
	// Params: [ Num(1) Size(0x1) ]
	void SetFestivaGrenade(bool bFestival);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C19288
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C1913C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C177A0

	// Object: Function Development.GMCheatManager.SetDynamicWeather
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c579e0
	// Params: [ Num(2) Size(0x8) ]
	void SetDynamicWeather(int WeatherType, int EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C25C40
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C19288
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106C1913C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0

	// Object: Function Development.GMCheatManager.SetDsSwitch
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c578bc
	// Params: [ Num(2) Size(0x18) ]
	void SetDsSwitch(int InKey, struct FString InValue);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C27E0C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C25C40
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106C19288

	// Object: Function Development.GMCheatManager.SetDeliver
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c578a8
	// Params: [ Num(0) Size(0x0) ]
	void SetDeliver();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C27E0C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C25C40
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetDearDeathReduce
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c577f0
	// Params: [ Num(2) Size(0x8) ]
	void SetDearDeathReduce(int Index, float ReduceFactor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28E80
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C27E0C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetClearIslandEnable
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5776c
	// Params: [ Num(1) Size(0x1) ]
	void SetClearIslandEnable(bool bNewActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26704
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C28E80
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106C27E0C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504

	// Object: Function Development.GMCheatManager.SetCameraLagEnable
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c576e8
	// Params: [ Num(1) Size(0x1) ]
	void SetCameraLagEnable(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C178D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C26704
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28E80
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.SetCacheInputNum
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5766c
	// Params: [ Num(1) Size(0x4) ]
	void SetCacheInputNum(int CacheNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C185E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C178D0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C26704
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28E80

	// Object: Function Development.GMCheatManager.SetAnimEnable
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c575e8
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimEnable(bool Enable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17780
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C185E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C178D0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C26704
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetAnimDebugInfo
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57564
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimDebugInfo(bool debugAnimInfo);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DA28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17780
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C185E0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C178D0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetAnimDebugGroup
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c574e0
	// Params: [ Num(1) Size(0x1) ]
	void SetAnimDebugGroup(bool debugAnimGroup);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DBC4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DA28
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C17780
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C185E0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.SetAllMonsterHp
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c57464
	// Params: [ Num(1) Size(0x4) ]
	void SetAllMonsterHp(int Hp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1D7F8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DBC4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DA28
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C17780
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ServerCMD
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c573cc
	// Params: [ Num(1) Size(0x10) ]
	void ServerCMD(struct FString Cmd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C136D8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D7F8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DBC4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1DA28
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ResumeAllLevelSequenceActors
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c573b8
	// Params: [ Num(0) Size(0x0) ]
	void ResumeAllLevelSequenceActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C136D8
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D7F8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DBC4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1DA28

	// Object: Function Development.GMCheatManager.ReplayRecoverReconnect
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c572cc
	// Params: [ Num(2) Size(0x20) ]
	void ReplayRecoverReconnect(struct FString IP, struct FString Port);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C2CB7C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C136D8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C1D7F8
	// [Call #20] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ReplayRecoverGenerateDSCheckpoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57234
	// Params: [ Num(1) Size(0x10) ]
	void ReplayRecoverGenerateDSCheckpoint(struct FString InReplayName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2CA98
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C2CB7C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C136D8
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.RenderTargetCompressTest
	// Flags: [Final|Exec|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x106c5717c
	// Params: [ Num(2) Size(0x14) ]
	void RenderTargetCompressTest(struct UTexture* pTexture, struct FVector Posoffset);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C29D64
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C2CA98
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C2CB7C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.RemoveTimeSwitch
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c57100
	// Params: [ Num(1) Size(0x4) ]
	void RemoveTimeSwitch(int TimeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28080
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29D64
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C2CA98
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.RefreshReconnectUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c570ec
	// Params: [ Num(0) Size(0x0) ]
	void RefreshReconnectUI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28080
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29D64
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C2CA98
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVESpawnMonsterByPos
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56f4c
	// Params: [ Num(6) Size(0x18) ]
	void PVESpawnMonsterByPos(int MonsterID, int Num, float Radius, float PosX, float PosY, float PosZ);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1D3C0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C28080

	// Object: Function Development.GMCheatManager.PVESpawnMonsterByDistance
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c56e24
	// Params: [ Num(4) Size(0x10) ]
	void PVESpawnMonsterByDistance(int MonsterID, int Num, float Radius, float FrontDist);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D3C4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PVESpawnMonster
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56d68
	// Params: [ Num(2) Size(0x5) ]
	void PVESpawnMonster(int MonsterID, bool StopAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1AB7C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1D3C4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVESetTestMonster
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56cec
	// Params: [ Num(1) Size(0x8) ]
	void PVESetTestMonster(struct AActor* InMonster);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1AFC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1AB7C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C1D3C4

	// Object: Function Development.GMCheatManager.PVEResetMonsterTable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56cd8
	// Params: [ Num(0) Size(0x0) ]
	void PVEResetMonsterTable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1AFC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1AB7C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PVEPrintMonsterCount
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56cc4
	// Params: [ Num(0) Size(0x0) ]
	void PVEPrintMonsterCount();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1AFC8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1AB7C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PVEPrintAllAnim
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c56c40
	// Params: [ Num(1) Size(0x1) ]
	void PVEPrintAllAnim(bool bPrintAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1B654
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1AFC8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1AB7C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEPlayerTriggerSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56b8c
	// Params: [ Num(2) Size(0x8) ]
	void PVEPlayerTriggerSkill(int SkillID, int EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1B4EC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1B654
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1AFC8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEPlayerStopSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56ad8
	// Params: [ Num(2) Size(0x8) ]
	void PVEPlayerStopSkill(int SkillID, int StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1B5A0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1B4EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1B654
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEMonsterTriggerSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56a24
	// Params: [ Num(2) Size(0x8) ]
	void PVEMonsterTriggerSkill(int SkillID, int EventType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1B220
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1B5A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1B4EC
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEMonsterStopSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56970
	// Params: [ Num(2) Size(0x8) ]
	void PVEMonsterStopSkill(int SkillID, int StopReason);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1B364
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1B220
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1B5A0
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEMonsterRemoveBuffByID
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c56840
	// Params: [ Num(4) Size(0xD) ]
	void PVEMonsterRemoveBuffByID(int BuffID, int LayerCount, int CauserSkillID, bool CauseByPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D644
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1B364
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEMonsterAddBuffByID
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c56710
	// Params: [ Num(4) Size(0xD) ]
	void PVEMonsterAddBuffByID(int BuffID, int LayerCount, int CauserSkillID, bool CauseByPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1D4BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C1D644

	// Object: Function Development.GMCheatManager.PVECloseMonsterLimit
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5668c
	// Params: [ Num(1) Size(0x1) ]
	void PVECloseMonsterLimit(bool bCloseMonsterLimit);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DDD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1D4BC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PVEClearTestMonster
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56678
	// Params: [ Num(0) Size(0x0) ]
	void PVEClearTestMonster();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DDD0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1D4BC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PrintScreenDebug
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56568
	// Params: [ Num(3) Size(0x18) ]
	void PrintScreenDebug(int Key, float TimeToDisplay, struct FString DebugMessage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C185F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DDD0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PrintRegionObjectList
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c56554
	// Params: [ Num(0) Size(0x0) ]
	void PrintRegionObjectList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C185F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DDD0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PrintPool
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56540
	// Params: [ Num(0) Size(0x0) ]
	void PrintPool();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C185F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DDD0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PrintHP
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5652c
	// Params: [ Num(0) Size(0x0) ]
	void PrintHP();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C185F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DDD0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PrintAllAnim
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c56518
	// Params: [ Num(0) Size(0x0) ]
	void PrintAllAnim();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C185F0
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DDD0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PrintAllActorLocationByClassName
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c56480
	// Params: [ Num(1) Size(0x10) ]
	void PrintAllActorLocationByClassName(struct FString InClassName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C174A0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C185F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.PlayBornIslandSequence
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c563fc
	// Params: [ Num(1) Size(0x1) ]
	void PlayBornIslandSequence(bool bPlay);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A1A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C174A0
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C185F0
	// [Call #17] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.PauseAnim
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c56378
	// Params: [ Num(1) Size(0x1) ]
	void PauseAnim(bool bPause);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C187FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A1A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C174A0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PauseAllLevelSequenceActors
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56364
	// Params: [ Num(0) Size(0x0) ]
	void PauseAllLevelSequenceActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C187FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A1A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C174A0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.PacketSimulationLag
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c562e8
	// Params: [ Num(1) Size(0x4) ]
	void PacketSimulationLag(int InSimulationLag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C27C90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C187FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2A1A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C174A0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.OpenHitTest
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c562d4
	// Params: [ Num(0) Size(0x0) ]
	void OpenHitTest();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C27C90
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C187FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2A1A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C174A0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.OpenFixationFreeFallVelocity
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c561e4
	// Params: [ Num(3) Size(0xC) ]
	void OpenFixationFreeFallVelocity(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C28DBC
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C27C90
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C187FC
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.OpenAllCharacterHitBodyCollison
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c56168
	// Params: [ Num(1) Size(0x4) ]
	void OpenAllCharacterHitBodyCollison(float Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2DAFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C28DBC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C27C90
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.NotifyGameModeParamsChanged
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c560ec
	// Params: [ Num(1) Size(0x4) ]
	void NotifyGameModeParamsChanged(int NewDuration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26A9C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2DAFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C28DBC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.NativeSimulateAction
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c56070
	// Params: [ Num(1) Size(0x4) ]
	void NativeSimulateAction(int SimActionType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C24C10
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C26A9C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2DAFC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C28DBC

	// Object: Function Development.GMCheatManager.MoveSnake
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55f34
	// Params: [ Num(4) Size(0x10) ]
	void MoveSnake(bool bEnable, float moveInternal, float ForwardRate, float RightRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C28524
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C24C10
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C26A9C

	// Object: Function Development.GMCheatManager.ModifyVehicleSyncServerData
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55e80
	// Params: [ Num(2) Size(0x8) ]
	void ModifyVehicleSyncServerData(float MinCorrectionInterval, float AllowMaxDiatanceSqAtServer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C252A0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28524
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ModifyVehicleSyncClientData
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55e6c
	// Params: [ Num(0) Size(0x0) ]
	void ModifyVehicleSyncClientData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C252A0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28524
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ModifyVehicleBuoyancy
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55db4
	// Params: [ Num(2) Size(0x8) ]
	void ModifyVehicleBuoyancy(float MeshDensity, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C29C24
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C252A0
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.MaxSimulationIterations
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55d38
	// Params: [ Num(1) Size(0x4) ]
	void MaxSimulationIterations(int V);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2CFB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29C24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C252A0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.MarkAPMLevelFinish
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55d24
	// Params: [ Num(0) Size(0x0) ]
	void MarkAPMLevelFinish();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2CFB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C29C24
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C252A0
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.MainCityConnectToDS
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55c38
	// Params: [ Num(2) Size(0x20) ]
	void MainCityConnectToDS(struct FString IP, struct FString Port);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C2CCF8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2CFB8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C29C24

	// Object: Function Development.GMCheatManager.LogNetWorkParams
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55c24
	// Params: [ Num(0) Size(0x0) ]
	void LogNetWorkParams();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C2CCF8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2CFB8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C29C24

	// Object: Function Development.GMCheatManager.LogicAreaTest
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55b50
	// Params: [ Num(2) Size(0x18) ]
	void LogicAreaTest(int AreaType, struct FString str);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28520
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2CCF8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x106C2CFB8

	// Object: Function Development.GMCheatManager.LogAllBuffInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55b3c
	// Params: [ Num(0) Size(0x0) ]
	void LogAllBuffInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28520
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2CCF8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.LogAllActors
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55b28
	// Params: [ Num(0) Size(0x0) ]
	void LogAllActors();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28520
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2CCF8
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.LocalConnectToLobbySrv
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c55a44
	// Params: [ Num(1) Size(0x10) ]
	void LocalConnectToLobbySrv(struct FString URL);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C275A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C28520
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.KillAllPVEBot
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c55a30
	// Params: [ Num(0) Size(0x0) ]
	void KillAllPVEBot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C275A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C28520
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.KillAllPlayers
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55a1c
	// Params: [ Num(0) Size(0x0) ]
	void KillAllPlayers();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C275A4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C28520
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.JankOpt_Spawn20AIBlockVolume
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5592c
	// Params: [ Num(3) Size(0xC) ]
	void JankOpt_Spawn20AIBlockVolume(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C2C078
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C275A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ItemSpotLog
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55918
	// Params: [ Num(0) Size(0x0) ]
	void ItemSpotLog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C2C078
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C275A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.InGameAndroidBack
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c55904
	// Params: [ Num(0) Size(0x0) ]
	void InGameAndroidBack();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C2C078
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C275A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.GotoSpectatingDirectly
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c558f0
	// Params: [ Num(0) Size(0x0) ]
	void GotoSpectatingDirectly();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C2C078
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C275A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.GotoSpectating
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c558dc
	// Params: [ Num(0) Size(0x0) ]
	void GotoSpectating();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C2C078
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C275A4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.GotoSpecificWeather
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55860
	// Params: [ Num(1) Size(0x4) ]
	void GotoSpecificWeather(int WeatherIdx);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25CB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C2C078
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMWayPointEvent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c557e4
	// Params: [ Num(1) Size(0x4) ]
	void GMWayPointEvent(int EventID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28928
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C25CB4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2C078

	// Object: Function Development.GMCheatManager.GMUseGunCollision
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c55760
	// Params: [ Num(1) Size(0x1) ]
	void GMUseGunCollision(bool bIsUse);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EF80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C28928
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25CB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSuicideCurVehicle
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c5574c
	// Params: [ Num(0) Size(0x0) ]
	void GMSuicideCurVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EF80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C28928
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25CB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSuicide
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c55738
	// Params: [ Num(0) Size(0x0) ]
	void GMSuicide();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EF80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C28928
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25CB4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMStopAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c55670
	// Params: [ Num(2) Size(0x8) ]
	void GMStopAI(bool bStop, uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C20A68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1EF80
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28928
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnSociallandSubVehicle01
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5565c
	// Params: [ Num(0) Size(0x0) ]
	void GMSpawnSociallandSubVehicle01();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C20A68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1EF80
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28928
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnSocialLandPlayerAIAroundPointWithAvatarList
	// Flags: [Final|Exec|Native|Public|HasOutParms|Const]
	// Offset: 0x106c552e0
	// Params: [ Num(12) Size(0x31) ]
	void GMSpawnSocialLandPlayerAIAroundPointWithAvatarList(uint32_t DataOffset, uint32_t AINum, float X, float Y, float Z, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet, bool bWithEqui, struct FString& AvatarList, bool bWithWeapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSpawnSocialLandPlayerAIAroundPoint
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c54fe0
	// Params: [ Num(11) Size(0x1D) ]
	void GMSpawnSocialLandPlayerAIAroundPoint(uint32_t DataOffset, uint32_t AINum, float X, float Y, float Z, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet, bool bWithEqui, bool bWithWeapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSpawnSocialLandPlayerAIAroundMeWithAvatar
	// Flags: [Final|Exec|Native|Public|HasOutParms]
	// Offset: 0x106c54d4c
	// Params: [ Num(8) Size(0x21) ]
	void GMSpawnSocialLandPlayerAIAroundMeWithAvatar(uint32_t AINum, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet, bool bWithEqui, struct FString& AvatarList, bool bWithWeapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C20044

	// Object: Function Development.GMCheatManager.GMSpawnSocialLandPlayerAIAroundMe
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c54b30
	// Params: [ Num(7) Size(0xD) ]
	void GMSpawnSocialLandPlayerAIAroundMe(uint32_t AINum, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet, bool bWithEqui, bool bWithWeapon);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1FEBC

	// Object: Function Development.GMCheatManager.GMSpawnSmartBearerTestPlane
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c54b1c
	// Params: [ Num(0) Size(0x0) ]
	void GMSpawnSmartBearerTestPlane();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1FEBC

	// Object: Function Development.GMCheatManager.GMSpawnSingleSocialLandPlayerAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c548d0
	// Params: [ Num(8) Size(0x14) ]
	void GMSpawnSingleSocialLandPlayerAI(uint32_t DataOffset, float X, float Y, float Z, bool bActiveAI, bool IsAIInvincible, bool bWithPet, bool bWithEqui);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C22D20

	// Object: Function Development.GMCheatManager.GMSpawnPlayerAIAroundPointDownloadable
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c54698
	// Params: [ Num(8) Size(0x17) ]
	void GMSpawnPlayerAIAroundPointDownloadable(uint32_t iNum, float X, float Y, float Z, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C206E8

	// Object: Function Development.GMCheatManager.GMSpawnPlayerAIAroundPoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c54460
	// Params: [ Num(8) Size(0x17) ]
	void GMSpawnPlayerAIAroundPoint(uint32_t iNum, float X, float Y, float Z, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C1FE14

	// Object: Function Development.GMCheatManager.GMSpawnPlayerAIAroundMeDownloadable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c542d4
	// Params: [ Num(5) Size(0xB) ]
	void GMSpawnPlayerAIAroundMeDownloadable(uint32_t iNum, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C205CC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnPlayerAIAroundMe
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c54148
	// Params: [ Num(5) Size(0xB) ]
	void GMSpawnPlayerAIAroundMe(uint32_t iNum, float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1FCF8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnPickup
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5401c
	// Params: [ Num(4) Size(0x10) ]
	void GMSpawnPickup(int SpawnNum, int PickupTypes, int Direction, float SpawnDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2D158
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSpawnParticle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53e40
	// Params: [ Num(5) Size(0x20) ]
	void GMSpawnParticle(struct FString AssetPath, float X, float Y, float Z, float Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106C2D95C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSpawnAutoTestAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c53dc4
	// Params: [ Num(1) Size(0x4) ]
	void GMSpawnAutoTestAI(int NameExtraID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C23130
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x106C2D95C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.GMSpawnAIWithIDAndLoc
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53ab4
	// Params: [ Num(13) Size(0x38) ]
	struct AActor* GMSpawnAIWithIDAndLoc(int AIID, float SpawnLocX, float SpawnLocY, float SpawnLocZ, float Radius, int TeamID, int ItemID1, int ItemNum1, int ItemID2, int ItemNum2, int ItemID3, int ItemNum3);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnAIOnAIPoint3
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c53aa0
	// Params: [ Num(0) Size(0x0) ]
	void GMSpawnAIOnAIPoint3();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSpawnAIOnAIPoint2
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53a8c
	// Params: [ Num(0) Size(0x0) ]
	void GMSpawnAIOnAIPoint2();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSpawnAIOnAIPoint1
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53a78
	// Params: [ Num(0) Size(0x0) ]
	void GMSpawnAIOnAIPoint1();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSocialSetRotation
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c53988
	// Params: [ Num(3) Size(0xC) ]
	void GMSocialSetRotation(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C22A50
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMSociallandPlayerMoveToTestPoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53974
	// Params: [ Num(0) Size(0x0) ]
	void GMSociallandPlayerMoveToTestPoint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C22A50
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSociallandPlayerMoveToAISpawnPoint1
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53960
	// Params: [ Num(0) Size(0x0) ]
	void GMSociallandPlayerMoveToAISpawnPoint1();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C22A50
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSociallandChangeItemFromStr
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c537e4
	// Params: [ Num(2) Size(0x20) ]
	void GMSociallandChangeItemFromStr(struct FString ItemString, struct FString EquimentItemString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106C235E4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMShowHitFeedback
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c53760
	// Params: [ Num(1) Size(0x1) ]
	void GMShowHitFeedback(bool bCombatHitFeedbackEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C253A0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C235E4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x100036FE0
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.GMSetSpeed
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c536e4
	// Params: [ Num(1) Size(0x4) ]
	void GMSetSpeed(float WalkSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17F68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C253A0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106C235E4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x104EEF504
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x104EEF504
	// [Call #23] RVA: 0x100036FE0

	// Object: Function Development.GMCheatManager.GMSetServerLevelLoadingMode
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53660
	// Params: [ Num(1) Size(0x1) ]
	void GMSetServerLevelLoadingMode(bool bNewLoadAll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C181C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17F68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C253A0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8122C

	// Object: Function Development.GMCheatManager.GMSetPawnNull
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c535dc
	// Params: [ Num(1) Size(0x1) ]
	void GMSetPawnNull(bool bIsNull);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1ED58
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C181C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C17F68
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C253A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSetMLAIModifyDamage
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c53560
	// Params: [ Num(1) Size(0x4) ]
	void GMSetMLAIModifyDamage(int InIsModify);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A254
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1ED58
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C181C0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C17F68
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSetMaxAINum
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c534e4
	// Params: [ Num(1) Size(0x4) ]
	void GMSetMaxAINum(int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C208E8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A254
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1ED58
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C181C0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSetJoystickEightDirection
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53460
	// Params: [ Num(1) Size(0x1) ]
	void GMSetJoystickEightDirection(bool IsNeedEightDirection);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18090
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C208E8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C2A254
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1ED58
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMSetJoystickActivatedRange
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53398
	// Params: [ Num(2) Size(0x8) ]
	void GMSetJoystickActivatedRange(bool IsNeedActivatedRange, float ActivatedRange);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1811C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C18090
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C208E8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C2A254

	// Object: Function Development.GMCheatManager.GMSetHealth
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c5331c
	// Params: [ Num(1) Size(0x4) ]
	void GMSetHealth(float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17AF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1811C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C18090
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C208E8

	// Object: Function Development.GMCheatManager.GMSetDeliveryToMLAI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c532a0
	// Params: [ Num(1) Size(0x4) ]
	void GMSetDeliveryToMLAI(int InIsDeliveryToMLAI);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A2E0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17AF8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1811C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C18090

	// Object: Function Development.GMCheatManager.GMSetCullDistance
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5321c
	// Params: [ Num(1) Size(0x1) ]
	void GMSetCullDistance(bool bCullDistance);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EBF8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A2E0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C17AF8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1811C

	// Object: Function Development.GMCheatManager.GMSetCircleTime
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53168
	// Params: [ Num(2) Size(0x8) ]
	void GMSetCircleTime(float cdTime, float LastTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C17FB8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1EBF8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C2A2E0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C17AF8

	// Object: Function Development.GMCheatManager.GMSelectorWayPoint
	// Flags: [Final|Exec|Native|Public|HasOutParms]
	// Offset: 0x106c53098
	// Params: [ Num(2) Size(0xC) ]
	void GMSelectorWayPoint(struct FName& NameOfAIWayPointSelector, int GMPathIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C289BC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C17FB8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1EBF8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMRevivePlayer
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53084
	// Params: [ Num(0) Size(0x0) ]
	void GMRevivePlayer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C289BC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C17FB8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1EBF8
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMRainCount
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c53008
	// Params: [ Num(1) Size(0x4) ]
	void GMRainCount(float Count);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17B80
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C289BC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C17FB8
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMIOSFrameRateLock
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52f8c
	// Params: [ Num(1) Size(0x4) ]
	void GMIOSFrameRateLock(int FrameRateLock);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17EA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17B80
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C289BC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMInvincible
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52f08
	// Params: [ Num(1) Size(0x1) ]
	void GMInvincible(bool bInvincible);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17F0C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17EA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C17B80
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C289BC

	// Object: Function Development.GMCheatManager.GMIncreaseHealth
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52ef4
	// Params: [ Num(0) Size(0x0) ]
	void GMIncreaseHealth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17F0C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C17EA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C17B80
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMGatherAllPlayerAIAroundMe
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52da4
	// Params: [ Num(4) Size(0x7) ]
	void GMGatherAllPlayerAIAroundMe(float fRadius, bool bActiveAI, bool IsAIInvincible, bool bWithPet);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C24AC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C17F0C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C17EA8

	// Object: Function Development.GMCheatManager.GMForceSuicide
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52d90
	// Params: [ Num(0) Size(0x0) ]
	void GMForceSuicide();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C24AC0
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C17F0C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMForceNullNetwork
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c52d14
	// Params: [ Num(1) Size(0x4) ]
	void GMForceNullNetwork(int bForce);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C22C34
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C24AC0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMDrawLine
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52b3c
	// Params: [ Num(7) Size(0x1C) ]
	void GMDrawLine(float X1, float Y1, float Z1, float X2, float Y2, float Z2, float LifeTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1E328
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C22C34

	// Object: Function Development.GMCheatManager.GMDrawDirLine
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52928
	// Params: [ Num(8) Size(0x20) ]
	void GMDrawDirLine(float StartX, float StartY, float StartZ, float DirX, float DirY, float DirZ, float Length, float LifeTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C1E334
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMDrawDebugSphere2
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52784
	// Params: [ Num(6) Size(0x18) ]
	void GMDrawDebugSphere2(float X, float Y, float Z, float Radius, int Segments, float LifeTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1E31C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMDrawDebugSphere
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52690
	// Params: [ Num(3) Size(0xC) ]
	void GMDrawDebugSphere(float Radius, int Segments, float LifeTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1E274
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMDrawCone
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c525a0
	// Params: [ Num(3) Size(0xC) ]
	void GMDrawCone(float Degrees, float LifeTime, int LineNum);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1E340
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1E274
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GMDecreaseHealth
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c5258c
	// Params: [ Num(0) Size(0x0) ]
	void GMDecreaseHealth();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1E340
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1E274
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMChangeAIAype
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c524d8
	// Params: [ Num(2) Size(0x8) ]
	void GMChangeAIAype(int Type, uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C207E8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E340
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMAutoTestChangeItem
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5231c
	// Params: [ Num(3) Size(0x28) ]
	void GMAutoTestChangeItem(uint32_t PlayerKey, struct FString ItemString, struct FString EquimentItemString);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C23268
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMAIFire
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52308
	// Params: [ Num(0) Size(0x0) ]
	void GMAIFire();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C23268
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x10516D168
	// [Call #26] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMAddItemForAI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c52218
	// Params: [ Num(3) Size(0xC) ]
	void GMAddItemForAI(int ItemId, int Count, uint32_t InPlayerKey);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C209A0
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x101F8122C
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106C23268
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.GMActiveRenderDynamicStyle
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c52150
	// Params: [ Num(2) Size(0x8) ]
	void GMActiveRenderDynamicStyle(bool bSet, int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1FBA0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C209A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.GMActiveAI
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5213c
	// Params: [ Num(0) Size(0x0) ]
	void GMActiveAI();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1FBA0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C209A0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GetObjectRef
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c520c0
	// Params: [ Num(1) Size(0x8) ]
	void GetObjectRef(uint64_t ObjectAddr);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2D004
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1FBA0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C209A0

	// Object: Function Development.GMCheatManager.GetGVMemberID
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52044
	// Params: [ Num(1) Size(0x4) ]
	void GetGVMemberID(int memberID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17804
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2D004
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1FBA0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GetGold
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c52030
	// Params: [ Num(0) Size(0x0) ]
	void GetGold();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C17804
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2D004
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1FBA0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.GenerateMonsterWave
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51f40
	// Params: [ Num(3) Size(0xC) ]
	void GenerateMonsterWave(int ChapterID, int LevelID, int WaveID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1AAE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C17804
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2D004
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ForceStopDynamicWeatherChange
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51f2c
	// Params: [ Num(0) Size(0x0) ]
	void ForceStopDynamicWeatherChange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1AAE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C17804
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2D004

	// Object: Function Development.GMCheatManager.ForceStartNextDynamicWeatherChange
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51f18
	// Params: [ Num(0) Size(0x0) ]
	void ForceStartNextDynamicWeatherChange();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C1AAE4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C17804
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2D004

	// Object: Function Development.GMCheatManager.ForceKickoutAllPlayers
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51e9c
	// Params: [ Num(1) Size(0x4) ]
	void ForceKickoutAllPlayers(int LandId);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26760
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1AAE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C17804
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ForceGC
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51e88
	// Params: [ Num(0) Size(0x0) ]
	void ForceGC();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26760
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1AAE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C17804

	// Object: Function Development.GMCheatManager.ForceEndInputForAppWillDeactivate
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51e74
	// Params: [ Num(0) Size(0x0) ]
	void ForceEndInputForAppWillDeactivate();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26760
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1AAE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C17804

	// Object: Function Development.GMCheatManager.FireSpawnAirplane
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51e60
	// Params: [ Num(0) Size(0x0) ]
	void FireSpawnAirplane();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C26760
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1AAE4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C17804

	// Object: Function Development.GMCheatManager.FireReviveTeammate
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51da4
	// Params: [ Num(2) Size(0x5) ]
	void FireReviveTeammate(int RespawnStartID, bool bJump);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1FAF8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C26760
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.FallKill
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51d28
	// Params: [ Num(1) Size(0x4) ]
	void FallKill(int FallType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C181C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1FAF8
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C26760
	// [Call #12] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.EquipHelmetAndBodyArmor
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51cac
	// Params: [ Num(1) Size(0x4) ]
	void EquipHelmetAndBodyArmor(int Lev);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28834
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C181C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1FAF8
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.EnterPVELevel
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51bf8
	// Params: [ Num(2) Size(0x8) ]
	void EnterPVELevel(int ChapterID, int LevelID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1A4D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C28834
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C181C4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C1FAF8

	// Object: Function Development.GMCheatManager.EnterPawnState
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51b38
	// Params: [ Num(2) Size(0x2) ]
	void EnterPawnState(uint8_t InState, bool IsEnter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1A480
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1A4D8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C28834
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.EndAPMTag
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51b24
	// Params: [ Num(0) Size(0x0) ]
	void EndAPMTag();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1A480
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C1A4D8
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C28834
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.EnablePool
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51aa0
	// Params: [ Num(1) Size(0x1) ]
	void EnablePool(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F22C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1A480
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1A4D8
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.EnableHitBox
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51a1c
	// Params: [ Num(1) Size(0x1) ]
	void EnableHitBox(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28510
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1F22C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1A480
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.EnableFuzzyInformation
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51a08
	// Params: [ Num(0) Size(0x0) ]
	void EnableFuzzyInformation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C28510
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1F22C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1A480
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.EnableDSAnim
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51928
	// Params: [ Num(2) Size(0x11) ]
	void EnableDSAnim(struct FString MonsterName, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28B1C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28510
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1F22C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DumpSmartBearerManager
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51914
	// Params: [ Num(0) Size(0x0) ]
	void DumpSmartBearerManager();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28B1C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28510
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1F22C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DumpPlayerStart
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51900
	// Params: [ Num(0) Size(0x0) ]
	void DumpPlayerStart();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28B1C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28510
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1F22C

	// Object: Function Development.GMCheatManager.DumpObjectNetProperties
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51884
	// Params: [ Num(1) Size(0x8) ]
	void DumpObjectNetProperties(struct UObject* InObj);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C2A384
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C28B1C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28510
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DumpMoveLog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51800
	// Params: [ Num(1) Size(0x1) ]
	void DumpMoveLog(bool bDump);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DumpLevels
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c517ec
	// Params: [ Num(0) Size(0x0) ]
	void DumpLevels();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DumpLegacyObjectPoolInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c517d8
	// Params: [ Num(0) Size(0x0) ]
	void DumpLegacyObjectPoolInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DumpDSNetConsiderList
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c517c4
	// Params: [ Num(0) Size(0x0) ]
	void DumpDSNetConsiderList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DumpCharacterRelevant
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c517b0
	// Params: [ Num(0) Size(0x0) ]
	void DumpCharacterRelevant();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DumpAnimLayer
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5179c
	// Params: [ Num(0) Size(0x0) ]
	void DumpAnimLayer();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.DumpAIOcclusion
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51788
	// Params: [ Num(0) Size(0x0) ]
	void DumpAIOcclusion();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28B1C
	// [Call #12] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.DSReconnectEvent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51774
	// Params: [ Num(0) Size(0x0) ]
	void DSReconnectEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.DSConnectLostEvent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51760
	// Params: [ Num(0) Size(0x0) ]
	void DSConnectLostEvent();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.DismissIsland
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5174c
	// Params: [ Num(0) Size(0x0) ]
	void DismissIsland();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFEC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C2A384
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DetectUnderGround
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c515ac
	// Params: [ Num(6) Size(0x18) ]
	void DetectUnderGround(float X1, float Y1, float Z1, float X2, float Y2, float Z2);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C2DA14

	// Object: Function Development.GMCheatManager.DestroyVehicleWithPath
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51514
	// Params: [ Num(1) Size(0x10) ]
	void DestroyVehicleWithPath(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C23C00
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C2DA14

	// Object: Function Development.GMCheatManager.DebugUnderWaterEffect
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51500
	// Params: [ Num(0) Size(0x0) ]
	void DebugUnderWaterEffect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C23C00
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C2DA14

	// Object: Function Development.GMCheatManager.DebugStopEMote
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51484
	// Params: [ Num(1) Size(0x4) ]
	void DebugStopEMote(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C23C00
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.DebugStopCapture
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c51470
	// Params: [ Num(0) Size(0x0) ]
	void DebugStopCapture();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C23C00
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DebugStartEMote
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c513f4
	// Params: [ Num(1) Size(0x4) ]
	void DebugStartEMote(int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18884
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18900
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C23C00
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.DebugSpringArm
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51370
	// Params: [ Num(1) Size(0x1) ]
	void DebugSpringArm(bool bDebug);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C19EBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18884
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C23C00
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DebugSpeed
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5135c
	// Params: [ Num(0) Size(0x0) ]
	void DebugSpeed();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C19EBC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C18884
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18900
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C23C00
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.DebugSetChangeWearCoolDownTime
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c512e0
	// Params: [ Num(1) Size(0x4) ]
	void DebugSetChangeWearCoolDownTime(float Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1E684
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C19EBC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C18884
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C18900

	// Object: Function Development.GMCheatManager.DebugRoomCustomParams
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c511b8
	// Params: [ Num(4) Size(0x10) ]
	void DebugRoomCustomParams(int FirstCircleDelayTime, int FirstCircleAppearTime, int FirstWhiteCircleRadiusMultiplicator, int BlueCircleDamageMultiplicator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1E814
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E684
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C19EBC

	// Object: Function Development.GMCheatManager.DebugPoseState
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51134
	// Params: [ Num(1) Size(0x1) ]
	void DebugPoseState(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1E684

	// Object: Function Development.GMCheatManager.DebugMove
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c51120
	// Params: [ Num(0) Size(0x0) ]
	void DebugMove();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1E684

	// Object: Function Development.GMCheatManager.DebugLocation
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c5110c
	// Params: [ Num(0) Size(0x0) ]
	void DebugLocation();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1E684

	// Object: Function Development.GMCheatManager.DebugLevelsInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c510f8
	// Params: [ Num(0) Size(0x0) ]
	void DebugLevelsInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1E684

	// Object: Function Development.GMCheatManager.DebugFixedParams
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c510e4
	// Params: [ Num(0) Size(0x0) ]
	void DebugFixedParams();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.DebugFindFloorResult
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c510d0
	// Params: [ Num(0) Size(0x0) ]
	void DebugFindFloorResult();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DebugCamera
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c510bc
	// Params: [ Num(0) Size(0x0) ]
	void DebugCamera();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.DebugAttach
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c510a8
	// Params: [ Num(0) Size(0x0) ]
	void DebugAttach();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814

	// Object: Function Development.GMCheatManager.DebugAnimList
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c51094
	// Params: [ Num(0) Size(0x0) ]
	void DebugAnimList();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1F294
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1E814

	// Object: Function Development.GMCheatManager.ClientSetSpeed
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c50fd4
	// Params: [ Num(2) Size(0x5) ]
	void ClientSetSpeed(float Times, bool bGMSetSpeed);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C25C3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1F294
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ClearTestMesh
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50fc0
	// Params: [ Num(0) Size(0x0) ]
	void ClearTestMesh();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C25C3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1F294
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ClearScreenDebug
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50fac
	// Params: [ Num(0) Size(0x0) ]
	void ClearScreenDebug();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C25C3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1F294
	// [Call #9] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ClearNoDriverVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50f98
	// Params: [ Num(0) Size(0x0) ]
	void ClearNoDriverVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C25C3C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1F294
	// [Call #9] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ClearAnimLayer
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c50f1c
	// Params: [ Num(1) Size(0x4) ]
	void ClearAnimLayer(int AnimLayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C25C3C
	// [Call #9] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ClearAllTlog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50f08
	// Params: [ Num(0) Size(0x0) ]
	void ClearAllTlog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C25C3C

	// Object: Function Development.GMCheatManager.CheatBeginPlay
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x106c50eec
	// Params: [ Num(0) Size(0x0) ]
	void CheatBeginPlay();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25B30
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C25C3C

	// Object: Function Development.GMCheatManager.ChatTest
	// Flags: [Final|Exec|Native|Public|HasOutParms]
	// Offset: 0x106c50e44
	// Params: [ Num(1) Size(0x10) ]
	void ChatTest(struct FString& Content);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25F74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25B30
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C25C3C

	// Object: Function Development.GMCheatManager.ChangeViewTarget
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c50e30
	// Params: [ Num(0) Size(0x0) ]
	void ChangeViewTarget();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25F74
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25B30
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C25C3C

	// Object: Function Development.GMCheatManager.ChangeMonsterWalkMode
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50db4
	// Params: [ Num(1) Size(0x4) ]
	void ChangeMonsterWalkMode(int Mode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1E920
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C25F74
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C25B30
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.ChangeAllTimeDuration
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50c50
	// Params: [ Num(5) Size(0x14) ]
	void ChangeAllTimeDuration(int NewEndStateTime, int NewStartShowLifeTime, int NewMinimumAliveTime, int NewMinimumPlayerNum, int NewSpecialLifeTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C26864
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1E920
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ChangeAIDamageRate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50bd4
	// Params: [ Num(1) Size(0x4) ]
	void ChangeAIDamageRate(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C189F0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C26864
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C1E920

	// Object: Function Development.GMCheatManager.ChangeAIAttackPlayerDamageRate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50b58
	// Params: [ Num(1) Size(0x4) ]
	void ChangeAIAttackPlayerDamageRate(float InRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C18AA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C189F0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C26864

	// Object: Function Development.GMCheatManager.CastUIMsg
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50a6c
	// Params: [ Num(2) Size(0x20) ]
	void CastUIMsg(struct FString Msg, struct FString module);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1D7D4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C18AA8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C189F0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.CallOnReconnect
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c50a58
	// Params: [ Num(0) Size(0x0) ]
	void CallOnReconnect();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C1D7D4
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C18AA8
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C189F0
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.CallLuaTableFunction
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c5096c
	// Params: [ Num(2) Size(0x20) ]
	void CallLuaTableFunction(struct FString tableName, struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C18490
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C1D7D4
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4
	// [Call #23] RVA: 0x106C18AA8

	// Object: Function Development.GMCheatManager.CallGMLua
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50888
	// Params: [ Num(1) Size(0x10) ]
	void CallGMLua(struct FString FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C28350
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C18490
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x106C8459C
	// [Call #22] RVA: 0x10516D168
	// [Call #23] RVA: 0x10516D1A4
	// [Call #24] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.CallGameModeLuaOverrideFunction
	// Flags: [Final|Exec|Native|Public|HasOutParms|Const]
	// Offset: 0x106c507e0
	// Params: [ Num(1) Size(0x10) ]
	void CallGameModeLuaOverrideFunction(struct FString& FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25530
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C28350
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4
	// [Call #22] RVA: 0x106C18490
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.CallGameModeLuaFunction
	// Flags: [Final|Exec|Native|Public|HasOutParms|Const]
	// Offset: 0x106c50738
	// Params: [ Num(1) Size(0x10) ]
	void CallGameModeLuaFunction(struct FString& FunctionName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C25434
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C25530
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x106C28350
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x100036FE0
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.BuildingCollide
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c506b4
	// Params: [ Num(1) Size(0x1) ]
	void BuildingCollide(bool InCollide);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1A4D4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C25434
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C25530
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x106C8459C
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x101F8122C

	// Object: Function Development.GMCheatManager.AutoShoveling
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c505ec
	// Params: [ Num(2) Size(0x8) ]
	void AutoShoveling(bool bEnable, float AutoShvelingSeconds);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C28648
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C1A4D4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C25434
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AutoSetPlayerLocation
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50568
	// Params: [ Num(1) Size(0x1) ]
	void AutoSetPlayerLocation(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C150C4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C28648
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C1A4D4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C25434
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Development.GMCheatManager.AnimDebugUseSkipMapForDistanceFactor
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c504e4
	// Params: [ Num(1) Size(0x1) ]
	void AnimDebugUseSkipMapForDistanceFactor(bool bFlag);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C150C4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C28648
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1A4D4

	// Object: Function Development.GMCheatManager.AnimDebugUseLodMap
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50460
	// Params: [ Num(1) Size(0x1) ]
	void AnimDebugUseLodMap(bool bUseLodMap);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF28
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DF2C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C150C4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C28648

	// Object: Function Development.GMCheatManager.AnimDebugUpdateFlag
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c503e4
	// Params: [ Num(1) Size(0x4) ]
	void AnimDebugUpdateFlag(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DDD4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DF28
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DF2C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C150C4
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.AnimDebugNonRenderedRate
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50368
	// Params: [ Num(1) Size(0x4) ]
	void AnimDebugNonRenderedRate(int UpdateRate);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF38
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DDD4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DF28
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DF2C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AnimDebugNonRenderedMinDist
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c502ec
	// Params: [ Num(1) Size(0x4) ]
	void AnimDebugNonRenderedMinDist(float minDist);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF3C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DF38
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DDD4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DF28
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AnimDebugNonRenderedMaxDist
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50270
	// Params: [ Num(1) Size(0x4) ]
	void AnimDebugNonRenderedMaxDist(float MaxDist);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DF40
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C1DF3C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C1DF38
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C1DDD4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AnimDebugLodSkipMap
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c501b0
	// Params: [ Num(1) Size(0x50) ]
	void AnimDebugLodSkipMap(struct TMap<int, int> SkipMap);
	// [Call #1] RVA: 0x1020C77AC
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x10218A578
	// [Call #5] RVA: 0x106C1DF30
	// [Call #6] RVA: 0x1020C7B88
	// [Call #7] RVA: 0x1020C7B88
	// [Call #8] RVA: 0x1020C7B88
	// [Call #9] RVA: 0x1020C7B88
	// [Call #10] RVA: 0x106C8459C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C1DF40
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C1DF3C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C1DF38

	// Object: Function Development.GMCheatManager.AnimDebugEnable
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c5012c
	// Params: [ Num(1) Size(0x1) ]
	void AnimDebugEnable(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1DE64
	// [Call #4] RVA: 0x1020C77AC
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10218A578
	// [Call #8] RVA: 0x106C1DF30
	// [Call #9] RVA: 0x1020C7B88
	// [Call #10] RVA: 0x1020C7B88
	// [Call #11] RVA: 0x1020C7B88
	// [Call #12] RVA: 0x1020C7B88
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C1DF40
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C1DF3C

	// Object: Function Development.GMCheatManager.AnimDebugBaseDistFactor
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c50048
	// Params: [ Num(1) Size(0x10) ]
	void AnimDebugBaseDistFactor(struct TArray<float> BaseDistFactor);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F898F8
	// [Call #4] RVA: 0x106C1DF34
	// [Call #5] RVA: 0x101F8C2E4
	// [Call #6] RVA: 0x101F8C2E4
	// [Call #7] RVA: 0x101F8C2E4
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8C2E4
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C1DE64
	// [Call #15] RVA: 0x1020C77AC
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10218A578
	// [Call #19] RVA: 0x106C1DF30
	// [Call #20] RVA: 0x1020C7B88
	// [Call #21] RVA: 0x1020C7B88
	// [Call #22] RVA: 0x1020C7B88
	// [Call #23] RVA: 0x1020C7B88
	// [Call #24] RVA: 0x106C8459C

	// Object: Function Development.GMCheatManager.AirDropByClassPath
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4fe98
	// Params: [ Num(4) Size(0x20) ]
	void AirDropByClassPath(float X, float Y, float Z, struct FString ClassPath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C260FC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F898F8
	// [Call #21] RVA: 0x106C1DF34
	// [Call #22] RVA: 0x101F8C2E4
	// [Call #23] RVA: 0x101F8C2E4

	// Object: Function Development.GMCheatManager.AILog
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4fe84
	// Params: [ Num(0) Size(0x0) ]
	void AILog();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C260FC
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F898F8
	// [Call #21] RVA: 0x106C1DF34
	// [Call #22] RVA: 0x101F8C2E4

	// Object: Function Development.GMCheatManager.AddWonderfulPeriod
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4fd20
	// Params: [ Num(5) Size(0x14) ]
	void AddWonderfulPeriod(int Type, float StartTime, float EndTime, int AdditionalData, int Index);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C297F4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AddTimeSwitch
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4fca4
	// Params: [ Num(1) Size(0x4) ]
	void AddTimeSwitch(int TimeID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C27FA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C297F4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.AddTestTouchInput
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4fb34
	// Params: [ Num(5) Size(0x11) ]
	void AddTestTouchInput(int FingerIndex, float X, float Y, float Force, bool bIsStart);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C27C70
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C27FA8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatManager.AddScore
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c4fab8
	// Params: [ Num(1) Size(0x4) ]
	void AddScore(int Score);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C190FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C27C70
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C27FA8

	// Object: Function Development.GMCheatManager.AddAllTestRes
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4faa4
	// Params: [ Num(0) Size(0x0) ]
	void AddAllTestRes();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C190FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C27C70
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatManager.ActiveCurCamera
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c4fa20
	// Params: [ Num(1) Size(0x1) ]
	void ActiveCurCamera(bool bActive);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C1EFDC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C190FC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
};

// Object: Class Development.GMCheatMod
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatMod : UGMCheatSystem
{

	// Object: Function Development.GMCheatMod.TriggerHunterRevival
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c610e8
	// Params: [ Num(0) Size(0x0) ]
	void TriggerHunterRevival();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.GMCheatMod.SetUAETriggerEnable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61064
	// Params: [ Num(1) Size(0x1) ]
	void SetUAETriggerEnable(bool IsEnbale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36008
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatMod.SetInfectResetPlayerInterTime
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60fe8
	// Params: [ Num(1) Size(0x4) ]
	void SetInfectResetPlayerInterTime(float InterTime);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C360B4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36008
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatMod.OnBuyRevivalTeammate
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60f6c
	// Params: [ Num(1) Size(0x4) ]
	void OnBuyRevivalTeammate(int TeammateIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36138
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C360B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36008
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatMod.OnBuyRevivalSign
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60f58
	// Params: [ Num(0) Size(0x0) ]
	void OnBuyRevivalSign();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36138
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C360B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36008
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Development.GMCheatMod.InfectionEndRound
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60f44
	// Params: [ Num(0) Size(0x0) ]
	void InfectionEndRound();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36138
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C360B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36008
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Development.GMCheatMod.GetGameResult
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60f30
	// Params: [ Num(0) Size(0x0) ]
	void GetGameResult();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36138
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C360B4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36008
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870

	// Object: Function Development.GMCheatMod.DebugEnableFerrisWheelTick
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60eac
	// Params: [ Num(1) Size(0x1) ]
	void DebugEnableFerrisWheelTick(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C35EA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36138
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C360B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36008

	// Object: Function Development.GMCheatMod.ClearBossBornPoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60e98
	// Params: [ Num(0) Size(0x0) ]
	void ClearBossBornPoint();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C35EA8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36138
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C360B4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36008

	// Object: Function Development.GMCheatMod.ChangePVELevel
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60e1c
	// Params: [ Num(1) Size(0x4) ]
	void ChangePVELevel(int Lv);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C35E1C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C35EA8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36138
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C360B4

	// Object: Function Development.GMCheatMod.CallZombieFlowAirDrop
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60da0
	// Params: [ Num(1) Size(0x4) ]
	void CallZombieFlowAirDrop(int ZombieID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C35FFC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C35E1C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C35EA8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36138

	// Object: Function Development.GMCheatMod.CallZombieAirDrop
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60d24
	// Params: [ Num(1) Size(0x4) ]
	void CallZombieAirDrop(int ZombieID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C35EAC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C35FFC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C35E1C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C35EA8

	// Object: Function Development.GMCheatMod.AddBossBornPoint
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c60c70
	// Params: [ Num(2) Size(0x8) ]
	void AddBossBornPoint(float BornX, float BornY);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C36004
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C35EAC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C35FFC
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C35E1C
};

// Object: Class Development.GMCheatOther
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatOther : UGMCheatSystem
{

	// Object: Function Development.GMCheatOther.UnLoadAllCollision
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61e7c
	// Params: [ Num(1) Size(0x1) ]
	void UnLoadAllCollision(bool Unload);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C361FC
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatOther.ShutDownBroadcastFatalDamage
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61df8
	// Params: [ Num(1) Size(0x1) ]
	void ShutDownBroadcastFatalDamage(bool IsOpen);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C363C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C361FC
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatOther.ShowHideLandscapeComponent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61d74
	// Params: [ Num(1) Size(0x1) ]
	void ShowHideLandscapeComponent(bool bShow);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36414
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C363C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C361FC
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.GMCheatOther.SetSingleThreadUpdateAnim
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61cf0
	// Params: [ Num(1) Size(0x1) ]
	void SetSingleThreadUpdateAnim(bool InIsSingleThread);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3641C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36414
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C363C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C361FC
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatOther.SetIsShowBlood
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61c6c
	// Params: [ Num(1) Size(0x1) ]
	void SetIsShowBlood(bool InIsShowBlood);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3645C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3641C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36414
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C363C8
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatOther.RetrievePlayerBattleResultData
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61c58
	// Params: [ Num(0) Size(0x0) ]
	void RetrievePlayerBattleResultData();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3645C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3641C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36414
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C363C8
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatOther.RemoveDSOptimGrayPublishFlags
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61bdc
	// Params: [ Num(1) Size(0x4) ]
	void RemoveDSOptimGrayPublishFlags(int InFlagIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C369A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3645C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3641C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36414
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatOther.RecoverStatusAfterReconnecting
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61bc8
	// Params: [ Num(0) Size(0x0) ]
	void RecoverStatusAfterReconnecting();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C369A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3645C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3641C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36414

	// Object: Function Development.GMCheatOther.ObserveWhoKilledMe
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61bb4
	// Params: [ Num(0) Size(0x0) ]
	void ObserveWhoKilledMe();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C369A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3645C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3641C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36414

	// Object: Function Development.GMCheatOther.GMTestSpectateRPC
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61ba0
	// Params: [ Num(0) Size(0x0) ]
	void GMTestSpectateRPC();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C369A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3645C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3641C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36414

	// Object: Function Development.GMCheatOther.GMTestSpectateException
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61b24
	// Params: [ Num(1) Size(0x4) ]
	void GMTestSpectateException(int Type);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3666C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C369A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3645C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3641C

	// Object: Function Development.GMCheatOther.GMTestExternalData
	// Flags: [Final|Exec|Native|Public|HasOutParms]
	// Offset: 0x106c61a7c
	// Params: [ Num(1) Size(0x10) ]
	void GMTestExternalData(struct TArray<uint8_t>& InData);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36850
	// [Call #4] RVA: 0x101F8BA74
	// [Call #5] RVA: 0x101F8BA74
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3666C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C369A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatOther.GMTeleport
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61a00
	// Params: [ Num(1) Size(0x8) ]
	void GMTeleport(struct FName Teleporter);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36388
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36850
	// [Call #7] RVA: 0x101F8BA74
	// [Call #8] RVA: 0x101F8BA74
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3666C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C369A4

	// Object: Function Development.GMCheatOther.GMSetScalarParam
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61844
	// Params: [ Num(3) Size(0x24) ]
	void GMSetScalarParam(struct FString Name, struct FString ShaderName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3614C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C36388

	// Object: Function Development.GMCheatOther.GMSendDailyTaskReport
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61830
	// Params: [ Num(0) Size(0x0) ]
	void GMSendDailyTaskReport();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3614C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C36388

	// Object: Function Development.GMCheatOther.GMBroastSyncTaskInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6181c
	// Params: [ Num(0) Size(0x0) ]
	void GMBroastSyncTaskInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3614C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C36388

	// Object: Function Development.GMCheatOther.EmptyLandscapeActor
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61808
	// Params: [ Num(0) Size(0x0) ]
	void EmptyLandscapeActor();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3614C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatOther.DumpGUIDCache
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6178c
	// Params: [ Num(1) Size(0x4) ]
	void DumpGUIDCache(int DriverIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36408
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106C3614C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0

	// Object: Function Development.GMCheatOther.DumpActiveObject
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61778
	// Params: [ Num(0) Size(0x0) ]
	void DumpActiveObject();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36408
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106C3614C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x100036FE0
	// [Call #21] RVA: 0x104EEF504

	// Object: Function Development.GMCheatOther.DebugEnableDrawSearchLine
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c616fc
	// Params: [ Num(1) Size(0x4) ]
	void DebugEnableDrawSearchLine(int bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36418
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36408
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x101F8122C

	// Object: Function Development.GMCheatOther.CanSeeAllUI
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61678
	// Params: [ Num(1) Size(0x1) ]
	void CanSeeAllUI(bool bUIVisibility);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36298
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36418
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36408
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatOther.AutoSelectTeammateToView
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c61664
	// Params: [ Num(0) Size(0x0) ]
	void AutoSelectTeammateToView();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C36298
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36418
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36408
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168

	// Object: Function Development.GMCheatOther.AddDSOptimGrayPublishFlags
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c615e8
	// Params: [ Num(1) Size(0x4) ]
	void AddDSOptimGrayPublishFlags(int InFlagIndex);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C368CC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C36298
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C36418
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C36408
};

// Object: Class Development.GMCheatSkill
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatSkill : UGMCheatSystem
{

	// Object: Function Development.GMCheatSkill.TryDeleteOneSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6346c
	// Params: [ Num(2) Size(0x5) ]
	void TryDeleteOneSkill(int SkillID, bool bImmediately);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C378F4
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.GMCheatSkill.TryAddOneSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63368
	// Params: [ Num(3) Size(0xC) ]
	void TryAddOneSkill(int SkillID, bool bActive, int ButtonSlot);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C37744
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C378F4
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function Development.GMCheatSkill.TriggerSkillWithID
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c632ac
	// Params: [ Num(2) Size(0x5) ]
	void TriggerSkillWithID(int SkillID, bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C373D0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C37744
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.StartSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63230
	// Params: [ Num(1) Size(0x4) ]
	void StartSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37A74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C373D0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C37744

	// Object: Function Development.GMCheatSkill.StartMainSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6321c
	// Params: [ Num(0) Size(0x0) ]
	void StartMainSkill();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37A74
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C373D0
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C37744

	// Object: Function Development.GMCheatSkill.SetSkillSkinID
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63168
	// Params: [ Num(2) Size(0x8) ]
	void SetSkillSkinID(int SkillID, int SkillSkinID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C374EC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C37A74
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C373D0
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.SetSkillLevel
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c630b4
	// Params: [ Num(2) Size(0x8) ]
	void SetSkillLevel(int SkillID, int SkillLevel);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3741C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C374EC
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C37A74
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.SetSkillCDTimeScale
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62fc0
	// Params: [ Num(3) Size(0xC) ]
	void SetSkillCDTimeScale(int SkillID, float Scale, int ScaleType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C37AD4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3741C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C374EC

	// Object: Function Development.GMCheatSkill.SetSkillCDIndexTimeScale
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62e94
	// Params: [ Num(4) Size(0x10) ]
	void SetSkillCDIndexTimeScale(int SkillID, int SkillCDIndex, float Scale, int ScaleType);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C37BAC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C37AD4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.SetAllSkillCDTimeScale
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62e18
	// Params: [ Num(1) Size(0x4) ]
	void SetAllSkillCDTimeScale(float Scale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37C8C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C37BAC
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.RemoveVehicleBuffBySkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62d9c
	// Params: [ Num(1) Size(0x4) ]
	void RemoveVehicleBuffBySkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37320
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C37C8C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C37BAC
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.RemoveVehicleBuff
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62d20
	// Params: [ Num(1) Size(0x4) ]
	void RemoveVehicleBuff(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37260
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C37320
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C37C8C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.RemoveBuffBySkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62c30
	// Params: [ Num(3) Size(0xC) ]
	void RemoveBuffBySkill(int SkillID, int IsPlayer, int LayerCount);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C36CF8
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C37260
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C37320
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C37C8C

	// Object: Function Development.GMCheatSkill.RemoveBuff
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62b40
	// Params: [ Num(3) Size(0xC) ]
	void RemoveBuff(int BuffID, int IsPlayer, int BuffLayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C37068
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C36CF8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C37260

	// Object: Function Development.GMCheatSkill.ReloadPVETable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62b2c
	// Params: [ Num(0) Size(0x0) ]
	void ReloadPVETable();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C37068
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C36CF8
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.EnableSkillCD
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62aa8
	// Params: [ Num(1) Size(0x1) ]
	void EnableSkillCD(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C379C8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C37068
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.DynamicRemoveSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62a2c
	// Params: [ Num(1) Size(0x4) ]
	void DynamicRemoveSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37680
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C379C8
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C37068
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.DynamicAddSkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c629b0
	// Params: [ Num(1) Size(0x4) ]
	void DynamicAddSkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C375BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C37680
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C379C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.DumpSkills
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6299c
	// Params: [ Num(0) Size(0x0) ]
	void DumpSkills();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C375BC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C37680
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C379C8
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.AddVehicleBuffBySkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62920
	// Params: [ Num(1) Size(0x4) ]
	void AddVehicleBuffBySkill(int SkillID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C372C0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C375BC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C37680
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C379C8
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatSkill.AddVehicleBuff
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c628a4
	// Params: [ Num(1) Size(0x4) ]
	void AddVehicleBuff(int BuffID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C371FC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C372C0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C375BC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C37680
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatSkill.AddSkillToken
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c627e8
	// Params: [ Num(2) Size(0x5) ]
	void AddSkillToken(int SkillID, bool bAdd);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C37820
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C371FC
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C372C0
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C375BC

	// Object: Function Development.GMCheatSkill.AddBuffBySkill
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62734
	// Params: [ Num(2) Size(0x8) ]
	void AddBuffBySkill(int SkillID, int IsPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C36B68
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C37820
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C371FC
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C372C0

	// Object: Function Development.GMCheatSkill.AddBuff
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c62680
	// Params: [ Num(2) Size(0x8) ]
	void AddBuff(int BuffID, int IsPlayer);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C36ED0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C36B68
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C37820
	// [Call #16] RVA: 0x10516D168
};

// Object: Class Development.GMCheatVehicle
// Size: 0x80 (Inherited: 0x80)
struct UGMCheatVehicle : UGMCheatSystem
{

	// Object: Function Development.GMCheatVehicle.VW_Seat
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64804
	// Params: [ Num(1) Size(0x4) ]
	void VW_Seat(int change);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C38A34
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.GMCheatVehicle.VehicleResetTo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64714
	// Params: [ Num(3) Size(0xC) ]
	void VehicleResetTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C384D4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C38A34
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x105190870
	// [Call #13] RVA: 0x10519022C

	// Object: Function Development.GMCheatVehicle.VehicleMoveTo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64624
	// Params: [ Num(3) Size(0xC) ]
	void VehicleMoveTo(float X, float Y, float Z);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C38C10
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C384D4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C38A34

	// Object: Function Development.GMCheatVehicle.ToggleVehicleSync
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c645a0
	// Params: [ Num(1) Size(0x1) ]
	void ToggleVehicleSync(bool Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C37EB4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C38C10
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C384D4

	// Object: Function Development.GMCheatVehicle.TeleportAndEnterVehicleWithPath
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c644c8
	// Params: [ Num(2) Size(0x14) ]
	void TeleportAndEnterVehicleWithPath(struct FString Path, int SeatID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C38EF8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C37EB4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C38C10

	// Object: Function Development.GMCheatVehicle.SpawnVehicleWithPathAndLoc
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64334
	// Params: [ Num(5) Size(0x20) ]
	void SpawnVehicleWithPathAndLoc(struct FString Path, float X, float Y, float Z, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C380F4
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C38EF8
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Development.GMCheatVehicle.SpawnVehicleWithPath
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6425c
	// Params: [ Num(2) Size(0x14) ]
	void SpawnVehicleWithPath(struct FString Path, int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3802C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C380F4
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Development.GMCheatVehicle.SpawnVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64248
	// Params: [ Num(0) Size(0x0) ]
	void SpawnVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3802C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C380F4
	// [Call #20] RVA: 0x101F8130C

	// Object: Function Development.GMCheatVehicle.SpawnAllVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c641b0
	// Params: [ Num(1) Size(0x10) ]
	void SpawnAllVehicle(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C381F0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3802C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatVehicle.SetSnowBoradRotationInAir
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c640c0
	// Params: [ Num(3) Size(0xC) ]
	void SetSnowBoradRotationInAir(float Pitch, float Yaw, float Roll);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C3886C
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C381F0
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x106C3802C
	// [Call #19] RVA: 0x101F8130C

	// Object: Function Development.GMCheatVehicle.SetFuelByPercent
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64044
	// Params: [ Num(1) Size(0x4) ]
	void SetFuelByPercent(float percent);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3841C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C3886C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C381F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168

	// Object: Function Development.GMCheatVehicle.ResetVehicleEngine
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c64030
	// Params: [ Num(0) Size(0x0) ]
	void ResetVehicleEngine();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3841C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C3886C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C381F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Development.GMCheatVehicle.ReqLeaveVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6401c
	// Params: [ Num(0) Size(0x0) ]
	void ReqLeaveVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3841C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C3886C
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C381F0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C

	// Object: Function Development.GMCheatVehicle.ReqExchangeVehicleCharacter
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63fa0
	// Params: [ Num(1) Size(0x4) ]
	void ReqExchangeVehicleCharacter(int Param);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C385B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3841C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C3886C
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatVehicle.ReqEnterVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63f24
	// Params: [ Num(1) Size(0x4) ]
	void ReqEnterVehicle(float dis);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C38618
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C385B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3841C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatVehicle.ReqEnterSnowBoard
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63f10
	// Params: [ Num(0) Size(0x0) ]
	void ReqEnterSnowBoard();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C38618
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C385B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3841C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168

	// Object: Function Development.GMCheatVehicle.ReplaceVehicleWithPath
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63e78
	// Params: [ Num(1) Size(0x10) ]
	void ReplaceVehicleWithPath(struct FString Path);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C387C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C38618
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C385B0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C3841C

	// Object: Function Development.GMCheatVehicle.ReplaceVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63e64
	// Params: [ Num(0) Size(0x0) ]
	void ReplaceVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C387C4
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C38618
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C385B0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C3841C

	// Object: Function Development.GMCheatVehicle.MakeVehicleFly
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63da8
	// Params: [ Num(2) Size(0x5) ]
	void MakeVehicleFly(int IsFly, bool bIsUp);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C386D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C387C4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C38618
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.GMCheatVehicle.KillAllEnermyVehicle
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c63d94
	// Params: [ Num(0) Size(0x0) ]
	void KillAllEnermyVehicle();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C386D8
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C387C4
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C38618
	// [Call #15] RVA: 0x10516D168
};

// Object: Class Development.GMCheatWeapon
// Size: 0x90 (Inherited: 0x80)
struct UGMCheatWeapon : UGMCheatSystem
{
	uint8_t Pad_0x80[0x10]; // 0x80(0x10)


	// Object: Function Development.GMCheatWeapon.ToggleShootVertify
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c65988
	// Params: [ Num(0) Size(0x0) ]
	void ToggleShootVertify();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.GMCheatWeapon.ShowWeaponDirection
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6590c
	// Params: [ Num(1) Size(0x4) ]
	void ShowWeaponDirection(int Time);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C39A20
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatWeapon.ShowBulletInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c658f8
	// Params: [ Num(0) Size(0x0) ]
	void ShowBulletInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C39A20
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C

	// Object: Function Development.GMCheatWeapon.SetWeaponAttrValue
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c657d4
	// Params: [ Num(2) Size(0x14) ]
	void SetWeaponAttrValue(struct FString AttrName, float Val);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C3A5D8
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C39A20
	// [Call #17] RVA: 0x10519022C
	// [Call #18] RVA: 0x105190870

	// Object: Function Development.GMCheatWeapon.SetWeaponAttrReloadTable
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c656f0
	// Params: [ Num(1) Size(0x10) ]
	void SetWeaponAttrReloadTable(struct FString tableName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x101F8122C
	// [Call #4] RVA: 0x106C3A4E4
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x104EEF504
	// [Call #9] RVA: 0x100036FE0
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C3A5D8
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x104EEF504
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x106C8459C
	// [Call #25] RVA: 0x10516D168

	// Object: Function Development.GMCheatWeapon.SetShootPveVertify
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6566c
	// Params: [ Num(1) Size(0x1) ]
	void SetShootPveVertify(bool IsVertify);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A474
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x101F8122C
	// [Call #7] RVA: 0x106C3A4E4
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x104EEF504
	// [Call #12] RVA: 0x100036FE0
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x101F8122C
	// [Call #20] RVA: 0x106C3A5D8
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x101F8130C
	// [Call #23] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.SetShootPveDebug
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c655e8
	// Params: [ Num(1) Size(0x1) ]
	void SetShootPveDebug(bool DebugShootPve);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A404
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A474
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C3A4E4
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168

	// Object: Function Development.GMCheatWeapon.SetBaseImpactDamageEntity
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c6556c
	// Params: [ Num(1) Size(0x4) ]
	void SetBaseImpactDamageEntity(float Damage);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A344
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A404
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A474
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106C3A4E4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x104EEF504
	// [Call #18] RVA: 0x100036FE0

	// Object: Function Development.GMCheatWeapon.ScopeOut
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65558
	// Params: [ Num(0) Size(0x0) ]
	void ScopeOut();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A344
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A404
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A474
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106C3A4E4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.ScopeIn
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65544
	// Params: [ Num(0) Size(0x0) ]
	void ScopeIn();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A344
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A404
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A474
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106C3A4E4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.PrintWeaponAllState
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c65530
	// Params: [ Num(0) Size(0x0) ]
	void PrintWeaponAllState();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A344
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A404
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A474
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x106C3A4E4
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.GMSwitchWeaponSpeedScale
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c654b4
	// Params: [ Num(1) Size(0x4) ]
	void GMSwitchWeaponSpeedScale(float SwitchScale);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A1EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A344
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A404
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A474

	// Object: Function Development.GMCheatWeapon.GMSetReportWeaponNum
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65438
	// Params: [ Num(1) Size(0x4) ]
	void GMSetReportWeaponNum(int Num);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A284
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A1EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A344
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A404

	// Object: Function Development.GMCheatWeapon.EnableCurrentWeaponInfiniteBullets
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c653b4
	// Params: [ Num(1) Size(0x1) ]
	void EnableCurrentWeaponInfiniteBullets(bool bEnable);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C392EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A284
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A1EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A344

	// Object: Function Development.GMCheatWeapon.DrawDebugWeaponCrossHair
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c653a0
	// Params: [ Num(0) Size(0x0) ]
	void DrawDebugWeaponCrossHair();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C392EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A284
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A1EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A344

	// Object: Function Development.GMCheatWeapon.DestroyMyWeapons
	// Flags: [Final|Exec|Native|Public|Const]
	// Offset: 0x106c6538c
	// Params: [ Num(0) Size(0x0) ]
	void DestroyMyWeapons();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C392EC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A284
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A1EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A344

	// Object: Function Development.GMCheatWeapon.DebugEnableBulletImpact
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65310
	// Params: [ Num(1) Size(0x4) ]
	void DebugEnableBulletImpact(int bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C39190
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C392EC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3A284
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A1EC

	// Object: Function Development.GMCheatWeapon.CreateAutoShootTimer
	// Flags: [Final|Native|Public]
	// Offset: 0x106c65294
	// Params: [ Num(1) Size(0x4) ]
	void CreateAutoShootTimer(float Interval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A6AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C39190
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C392EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A284
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.GMCheatWeapon.CollectAllPlayerWeaponPosInfo
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65280
	// Params: [ Num(0) Size(0x0) ]
	void CollectAllPlayerWeaponPosInfo();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A6AC
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C39190
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C392EC
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3A284

	// Object: Function Development.GMCheatWeapon.ChangeWeaponFunction
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	// Offset: 0x106c65204
	// Params: [ Num(1) Size(0x4) ]
	void ChangeWeaponFunction(int NewWeaponFunction);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C398E4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3A6AC
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C39190
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C392EC

	// Object: Function Development.GMCheatWeapon.ChangeShootWeaponStrValue
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c65048
	// Params: [ Num(3) Size(0x24) ]
	void ChangeShootWeaponStrValue(struct FString StrName, struct FString KeyName, float Value);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C398E8
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10516D168
	// [Call #24] RVA: 0x10516D1A4
	// [Call #25] RVA: 0x106C398E4

	// Object: Function Development.GMCheatWeapon.AutoShootNearestEnemy
	// Flags: [Final|Exec|Native|Public]
	// Offset: 0x106c64f94
	// Params: [ Num(2) Size(0x8) ]
	void AutoShootNearestEnemy(float Interval, float Duration);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3A644
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x101F8122C
	// [Call #13] RVA: 0x101F8122C
	// [Call #14] RVA: 0x106C398E8
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x104EEF504
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x100036FE0
	// [Call #23] RVA: 0x104EEF504
	// [Call #24] RVA: 0x100036FE0
	// [Call #25] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.AutoShoot
	// Flags: [Final|Native|Public]
	// Offset: 0x106c64f18
	// Params: [ Num(1) Size(0x4) ]
	void AutoShoot(float Interval);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A81C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3A644
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101F8122C
	// [Call #17] RVA: 0x106C398E8
	// [Call #18] RVA: 0x101F8130C

	// Object: Function Development.GMCheatWeapon.AimForAutoShoot
	// Flags: [Final|Native|Public]
	// Offset: 0x106c64f04
	// Params: [ Num(0) Size(0x0) ]
	void AimForAutoShoot();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3A81C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3A644
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x101F8122C
	// [Call #16] RVA: 0x101F8122C
};

// Object: Class Development.ImGuiWindowBase
// Size: 0x5C8 (Inherited: 0x570)
struct AImGuiWindowBase : ALuaActor
{
	struct FString WindowTitle; // 0x570(0x10)
	struct FVector2D WindowSize; // 0x580(0x8)
	int WindowFlags; // 0x588(0x4)
	uint8_t DisplayMode; // 0x58C(0x1)
	bool bIsWindowVisible; // 0x58D(0x1)
	uint8_t Pad_0x58E[0x2]; // 0x58E(0x2)
	float WindowAlpha; // 0x590(0x4)
	int ImGuiWindowIndex; // 0x594(0x4)
	struct TArray<struct UImGuiTabBase*> Tabs; // 0x598(0x10)
	int ActiveTabIndex; // 0x5A8(0x4)
	uint8_t Pad_0x5AC[0x4]; // 0x5AC(0x4)
	struct TArray<struct UImGuiFeatureWidget*> Features; // 0x5B0(0x10)
	uint8_t Pad_0x5C0[0x8]; // 0x5C0(0x8)


	// Object: Function Development.ImGuiWindowBase.ToggleWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c674a8
	// Params: [ Num(0) Size(0x0) ]
	void ToggleWindow();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowBase.ToggleDisplayMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67494
	// Params: [ Num(0) Size(0x0) ]
	void ToggleDisplayMode();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x10519022C
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowBase.ShowWindowWithTabs
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106c673ec
	// Params: [ Num(1) Size(0x10) ]
	void ShowWindowWithTabs(struct TArray<struct UImGuiTabBase*>& TabClasses);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BAD4
	// [Call #4] RVA: 0x106C69160
	// [Call #5] RVA: 0x106C69160
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowBase.ShowWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c673d8
	// Params: [ Num(0) Size(0x0) ]
	void ShowWindow();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BAD4
	// [Call #4] RVA: 0x106C69160
	// [Call #5] RVA: 0x106C69160
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x105190870
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowBase.SetWindowAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c6735c
	// Params: [ Num(1) Size(0x4) ]
	void SetWindowAlpha(float Alpha);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BC68
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BAD4
	// [Call #7] RVA: 0x106C69160
	// [Call #8] RVA: 0x106C69160
	// [Call #9] RVA: 0x106C8459C
	// [Call #10] RVA: 0x10519022C
	// [Call #11] RVA: 0x105190870
	// [Call #12] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowBase.SetDisplayMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c672e0
	// Params: [ Num(1) Size(0x1) ]
	void SetDisplayMode(uint8_t NewMode);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BC84
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BC68
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BAD4
	// [Call #10] RVA: 0x106C69160
	// [Call #11] RVA: 0x106C69160
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10519022C
	// [Call #14] RVA: 0x105190870

	// Object: Function Development.ImGuiWindowBase.RemoveTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67264
	// Params: [ Num(1) Size(0x8) ]
	void RemoveTab(struct FName TabID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C068
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BC84
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BC68
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BAD4
	// [Call #13] RVA: 0x106C69160
	// [Call #14] RVA: 0x106C69160
	// [Call #15] RVA: 0x106C8459C

	// Object: Function Development.ImGuiWindowBase.RemoveFeature
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c671e8
	// Params: [ Num(1) Size(0x8) ]
	void RemoveFeature(struct FName FeatureID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C068
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BC84
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BC68
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiWindowBase.IsWindowVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c671cc
	// Params: [ Num(1) Size(0x1) ]
	bool IsWindowVisible();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C068
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BC84
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BC68
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowBase.HideWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c671b8
	// Params: [ Num(0) Size(0x0) ]
	void HideWindow();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C068
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BC84
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BC68

	// Object: Function Development.ImGuiWindowBase.GetWindowAlpha
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c6719c
	// Params: [ Num(1) Size(0x4) ]
	float GetWindowAlpha();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C538
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C068
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BC84
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BC68

	// Object: Function Development.ImGuiWindowBase.GetTabByID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67110
	// Params: [ Num(2) Size(0x10) ]
	struct UImGuiTabBase* GetTabByID(struct FName TabID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BF50
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C538
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3C068
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3BC84

	// Object: Function Development.ImGuiWindowBase.GetFeatureByID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67084
	// Params: [ Num(2) Size(0x10) ]
	struct UImGuiFeatureWidget* GetFeatureByID(struct FName FeatureID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C4D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BF50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3C538
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3C068

	// Object: Function Development.ImGuiWindowBase.GetDisplayMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67068
	// Params: [ Num(1) Size(0x1) ]
	uint8_t GetDisplayMode();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C4D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BF50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3C538
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiWindowBase.GetAllTabs
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c6704c
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UImGuiTabBase*> GetAllTabs();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C4D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BF50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3C538
	// [Call #10] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowBase.GetAllFeatures
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67030
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UImGuiFeatureWidget*> GetAllFeatures();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C4D0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3BF50
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3C538

	// Object: Function Development.ImGuiWindowBase.GetActiveTab
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c66ffc
	// Params: [ Num(1) Size(0x8) ]
	struct UImGuiTabBase* GetActiveTab();
	// [Call #1] RVA: 0x106C3C17C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106C3C4D0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x106C3BF50
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x106C3C538

	// Object: Function Development.ImGuiWindowBase.AddTabWithLuaPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66f18
	// Params: [ Num(3) Size(0x20) ]
	struct UImGuiTabBase* AddTabWithLuaPath(struct UImGuiTabBase* TabClass, struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3BEB0
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x106C3C17C
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3C4D0
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiWindowBase.AddTabInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66e44
	// Params: [ Num(2) Size(0x18) ]
	void AddTabInstance(struct UImGuiTabBase* Tab, struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3BD44
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C3BEB0
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x106C3C17C

	// Object: Function Development.ImGuiWindowBase.AddTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66db8
	// Params: [ Num(2) Size(0x10) ]
	struct UImGuiTabBase* AddTab(struct UImGuiTabBase* TabClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BB64
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3BD44
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C3BEB0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Development.ImGuiWindowBase.AddLuaTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66d10
	// Params: [ Num(2) Size(0x18) ]
	struct UImGuiTabBase* AddLuaTab(struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BE30
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BB64
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3BD44
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowBase.AddLuaFeature
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66c68
	// Params: [ Num(2) Size(0x18) ]
	struct UImGuiFeatureWidget* AddLuaFeature(struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C3B0
	// [Call #4] RVA: 0x101F8130C
	// [Call #5] RVA: 0x101F8130C
	// [Call #6] RVA: 0x106C8459C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3BE30
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x106C8459C
	// [Call #13] RVA: 0x10516D168
	// [Call #14] RVA: 0x10516D1A4
	// [Call #15] RVA: 0x106C3BB64
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowBase.AddFeatureWithLuaPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66b84
	// Params: [ Num(3) Size(0x20) ]
	struct UImGuiFeatureWidget* AddFeatureWithLuaPath(struct UImGuiFeatureWidget* FeatureClass, struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3C430
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3C3B0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C3BE30
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x101F8130C
	// [Call #20] RVA: 0x106C8459C

	// Object: Function Development.ImGuiWindowBase.AddFeatureInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66ab0
	// Params: [ Num(2) Size(0x18) ]
	void AddFeatureInstance(struct UImGuiFeatureWidget* Feature, struct FString InLuaFilePath);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3C2F8
	// [Call #6] RVA: 0x101F8130C
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x10516D168
	// [Call #12] RVA: 0x10516D1A4
	// [Call #13] RVA: 0x106C3C430
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x106C3C3B0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C

	// Object: Function Development.ImGuiWindowBase.AddFeature
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c66a24
	// Params: [ Num(2) Size(0x10) ]
	struct UImGuiFeatureWidget* AddFeature(struct UImGuiFeatureWidget* FeatureClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C1A4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3C2F8
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x106C3C430
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C

	// Object: Function Development.ImGuiWindowBase.ActivateTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c669a8
	// Params: [ Num(1) Size(0x8) ]
	void ActivateTab(struct FName TabID);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3BFB8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3C1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3C2F8
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x10516D168
};

// Object: Class Development.ImGuiWindowManager
// Size: 0x80 (Inherited: 0x30)
struct UImGuiWindowManager : UGameInstanceSubsystem
{
	struct TMap<struct AImGuiWindowBase*, struct AImGuiWindowBase*> WindowCache; // 0x30(0x50)


	// Object: Function Development.ImGuiWindowManager.ToggleWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c68160
	// Params: [ Num(1) Size(0x8) ]
	void ToggleWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CDE4
	// [Call #4] RVA: 0x10519022C
	// [Call #5] RVA: 0x105190870
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x10519022C
	// [Call #8] RVA: 0x10519022C
	// [Call #9] RVA: 0x10519022C
	// [Call #10] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowManager.ShowWindowWithTabs
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x106c6807c
	// Params: [ Num(2) Size(0x18) ]
	void ShowWindowWithTabs(struct AImGuiWindowBase* WindowClass, struct TArray<struct UImGuiTabBase*>& TabClasses);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3CCC0
	// [Call #6] RVA: 0x106C69160
	// [Call #7] RVA: 0x106C69160
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3CDE4
	// [Call #12] RVA: 0x10519022C
	// [Call #13] RVA: 0x105190870
	// [Call #14] RVA: 0x10519022C

	// Object: Function Development.ImGuiWindowManager.ShowWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c68000
	// Params: [ Num(1) Size(0x8) ]
	void ShowWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CC88
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3CCC0
	// [Call #9] RVA: 0x106C69160
	// [Call #10] RVA: 0x106C69160
	// [Call #11] RVA: 0x106C8459C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3CDE4
	// [Call #15] RVA: 0x10519022C
	// [Call #16] RVA: 0x105190870

	// Object: Function Development.ImGuiWindowManager.HideWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67f84
	// Params: [ Num(1) Size(0x8) ]
	void HideWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CCF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3CC88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3CCC0
	// [Call #12] RVA: 0x106C69160
	// [Call #13] RVA: 0x106C69160
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4
	// [Call #17] RVA: 0x106C3CDE4

	// Object: Function Development.ImGuiWindowManager.HideAllWindows
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67f70
	// Params: [ Num(0) Size(0x0) ]
	void HideAllWindows();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CCF4
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3CC88
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3CCC0
	// [Call #12] RVA: 0x106C69160
	// [Call #13] RVA: 0x106C69160
	// [Call #14] RVA: 0x106C8459C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiWindowManager.HasWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67ee4
	// Params: [ Num(2) Size(0x9) ]
	bool HasWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CE04
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3CCF4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3CC88
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3CCC0
	// [Call #15] RVA: 0x106C69160

	// Object: Function Development.ImGuiWindowManager.GetWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67e58
	// Params: [ Num(2) Size(0x10) ]
	struct AImGuiWindowBase* GetWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3CD2C
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3CE04
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3CCF4
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3CC88
	// [Call #13] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowManager.GetOrCreateWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67dcc
	// Params: [ Num(2) Size(0x10) ]
	struct AImGuiWindowBase* GetOrCreateWindow(struct AImGuiWindowBase* WindowClass);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C900
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3CD2C
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x106C3CE04
	// [Call #10] RVA: 0x10516D168
	// [Call #11] RVA: 0x10516D1A4
	// [Call #12] RVA: 0x106C3CCF4

	// Object: Function Development.ImGuiWindowManager.GetAllWindows
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x106c67d68
	// Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AImGuiWindowBase*> GetAllWindows();
	// [Call #1] RVA: 0x106C3D024
	// [Call #2] RVA: 0x106C69190
	// [Call #3] RVA: 0x106C3FC5C
	// [Call #4] RVA: 0x106C3FC5C
	// [Call #5] RVA: 0x106C8459C
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x106C3C900
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3CD2C
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3CE04
	// [Call #15] RVA: 0x10516D168

	// Object: Function Development.ImGuiWindowManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106c67cec
	// Params: [ Num(2) Size(0x10) ]
	struct UImGuiWindowManager* Get(struct UObject* WorldContextObject);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C8A0
	// [Call #4] RVA: 0x106C3D024
	// [Call #5] RVA: 0x106C69190
	// [Call #6] RVA: 0x106C3FC5C
	// [Call #7] RVA: 0x106C3FC5C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3C900
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3CD2C
	// [Call #15] RVA: 0x10516D168
	// [Call #16] RVA: 0x10516D1A4

	// Object: Function Development.ImGuiWindowManager.DestroyAllWindows
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x106c67cd8
	// Params: [ Num(0) Size(0x0) ]
	void DestroyAllWindows();
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3C8A0
	// [Call #4] RVA: 0x106C3D024
	// [Call #5] RVA: 0x106C69190
	// [Call #6] RVA: 0x106C3FC5C
	// [Call #7] RVA: 0x106C3FC5C
	// [Call #8] RVA: 0x106C8459C
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x106C3C900
	// [Call #12] RVA: 0x10516D168
	// [Call #13] RVA: 0x10516D1A4
	// [Call #14] RVA: 0x106C3CD2C
	// [Call #15] RVA: 0x10516D168
};

// Object: Class Development.MemLeakTestGameMode
// Size: 0x540 (Inherited: 0x540)
struct AMemLeakTestGameMode : AGameModeBase
{

	// Object: Function Development.MemLeakTestGameMode.ForceGC
	// Flags: [Final|Exec|Native|Private|BlueprintCallable]
	// Offset: 0x106c685f4
	// Params: [ Num(0) Size(0x0) ]
	void ForceGC();
	// [Call #1] RVA: 0x10519022C
	// [Call #2] RVA: 0x105190870
	// [Call #3] RVA: 0x10508F76C
	// [Call #4] RVA: 0x106C68D34
	// [Call #5] RVA: 0x106C3E2A0
	// [Call #6] RVA: 0x106C3E298
	// [Call #7] RVA: 0x106C3E2A8
	// [Call #8] RVA: 0x10516D168
};

// Object: Class Development.QPSBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UQPSBPLibrary : UBlueprintFunctionLibrary
{

	// Object: Function Development.QPSBPLibrary.SwitchUIWidgetShowFromUserWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106c68998
	// Params: [ Num(3) Size(0x28) ]
	void SwitchUIWidgetShowFromUserWidget(struct FName ContainName, struct FString UserWidgetName, struct FString WidgetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x101F8122C
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3E794
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x104EEF504
	// [Call #19] RVA: 0x100036FE0
	// [Call #20] RVA: 0x101F8130C
	// [Call #21] RVA: 0x101F8130C
	// [Call #22] RVA: 0x106C8459C
	// [Call #23] RVA: 0x10519022C
	// [Call #24] RVA: 0x105190870

	// Object: Function Development.QPSBPLibrary.SwitchUIWidgetShow
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106c6887c
	// Params: [ Num(2) Size(0x18) ]
	void SwitchUIWidgetShow(struct FName ContainName, struct FString WidgetName);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x101F8122C
	// [Call #6] RVA: 0x106C3E320
	// [Call #7] RVA: 0x101F8130C
	// [Call #8] RVA: 0x101F8130C
	// [Call #9] RVA: 0x101F8130C
	// [Call #10] RVA: 0x104EEF504
	// [Call #11] RVA: 0x100036FE0
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x106C8459C
	// [Call #14] RVA: 0x10516D168
	// [Call #15] RVA: 0x10516D1A4
	// [Call #16] RVA: 0x10516D168
	// [Call #17] RVA: 0x10516D1A4
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x101F8122C
	// [Call #21] RVA: 0x101F8122C
	// [Call #22] RVA: 0x106C3E794
	// [Call #23] RVA: 0x101F8130C
	// [Call #24] RVA: 0x101F8130C
	// [Call #25] RVA: 0x101F8130C
	// [Call #26] RVA: 0x101F8130C

	// Object: Function Development.QPSBPLibrary.SwitchUIContainsShow
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106c68808
	// Params: [ Num(1) Size(0x8) ]
	void SwitchUIContainsShow(struct FName Name);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x106C3E2B0
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x101F8122C
	// [Call #9] RVA: 0x106C3E320
	// [Call #10] RVA: 0x101F8130C
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x104EEF504
	// [Call #14] RVA: 0x100036FE0
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x106C8459C
	// [Call #17] RVA: 0x10516D168
	// [Call #18] RVA: 0x10516D1A4
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4
	// [Call #21] RVA: 0x10516D168
	// [Call #22] RVA: 0x10516D1A4

	// Object: Function Development.QPSBPLibrary.IsPublishVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106c687d4
	// Params: [ Num(1) Size(0x1) ]
	bool IsPublishVersion();
	// [Call #1] RVA: 0x106C3E2A8
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D1A4
	// [Call #4] RVA: 0x106C3E2B0
	// [Call #5] RVA: 0x10516D168
	// [Call #6] RVA: 0x10516D1A4
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x101F8122C
	// [Call #10] RVA: 0x106C3E320
	// [Call #11] RVA: 0x101F8130C
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x104EEF504
	// [Call #15] RVA: 0x100036FE0
	// [Call #16] RVA: 0x101F8130C
	// [Call #17] RVA: 0x106C8459C
	// [Call #18] RVA: 0x10516D168
	// [Call #19] RVA: 0x10516D1A4
	// [Call #20] RVA: 0x10516D168
	// [Call #21] RVA: 0x10516D1A4

	// Object: Function Development.QPSBPLibrary.GetHZBValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x106c687a0
	// Params: [ Num(1) Size(0x4) ]
	int GetHZBValue();
	// [Call #1] RVA: 0x106C3E298
	// [Call #2] RVA: 0x106C3E2A8
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x106C3E2B0
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x101F8122C
	// [Call #11] RVA: 0x106C3E320
	// [Call #12] RVA: 0x101F8130C
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x104EEF504
	// [Call #16] RVA: 0x100036FE0
	// [Call #17] RVA: 0x101F8130C
	// [Call #18] RVA: 0x106C8459C
	// [Call #19] RVA: 0x10516D168
	// [Call #20] RVA: 0x10516D1A4

	// Object: Function Development.QPSBPLibrary.GetDistanceCullingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x106c6876c
	// Params: [ Num(1) Size(0x4) ]
	float GetDistanceCullingFactor();
	// [Call #1] RVA: 0x106C3E2A0
	// [Call #2] RVA: 0x106C3E298
	// [Call #3] RVA: 0x106C3E2A8
	// [Call #4] RVA: 0x10516D168
	// [Call #5] RVA: 0x10516D1A4
	// [Call #6] RVA: 0x106C3E2B0
	// [Call #7] RVA: 0x10516D168
	// [Call #8] RVA: 0x10516D1A4
	// [Call #9] RVA: 0x10516D168
	// [Call #10] RVA: 0x10516D1A4
	// [Call #11] RVA: 0x101F8122C
	// [Call #12] RVA: 0x106C3E320
	// [Call #13] RVA: 0x101F8130C
	// [Call #14] RVA: 0x101F8130C
	// [Call #15] RVA: 0x101F8130C
	// [Call #16] RVA: 0x104EEF504
	// [Call #17] RVA: 0x100036FE0
	// [Call #18] RVA: 0x101F8130C
	// [Call #19] RVA: 0x106C8459C
};

// Object: Class Development.ReplayRecordersDataTab
// Size: 0x110 (Inherited: 0xC0)
struct UReplayRecordersDataTab : UImGuiTabBase
{
	uint8_t Pad_0xC0[0x50]; // 0xC0(0x50)
};

