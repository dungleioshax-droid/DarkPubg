#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Reconnect_BP.Reconnect_BP_C
// Size: 0x453 (Inherited: 0x418)
struct UReconnect_BP_C : UUAEUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x418(0x8)
	struct UReconnect_UIBP_C* Reconnect_UIBP; // 0x420(0x8)
	struct UTextBlock* TextNumber; // 0x428(0x8)
	struct UTextBlock* TextInfo; // 0x430(0x8)
	struct UHorizontalBox* BoxText; // 0x438(0x8)
	bool isShowText; // 0x440(0x1)
	uint8_t Pad_0x441[0x3]; // 0x441(0x3)
	int StartTime; // 0x444(0x4)
	float lastTickTime; // 0x448(0x4)
	float curTickTIme; // 0x44C(0x4)
	bool canCrtlFromLua; // 0x450(0x1)
	bool BIsShowAnim; // 0x451(0x1)
	bool bImmediatelyShow; // 0x452(0x1)


	// Object: Function Reconnect_BP.Reconnect_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Reconnect_BP(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

