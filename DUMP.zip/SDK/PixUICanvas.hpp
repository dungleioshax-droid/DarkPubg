#pragma once

#include <cstdint>

// Object: Class PixUICanvas.PixCanvasMgr
// Size: 0x28 (Inherited: 0x28)
struct UPixCanvasMgr : UObject
{
};

