#pragma once

#include <cstdint>

// Object: ScriptStruct AnimationBudgetAllocator.AnimationBudgetAllocatorParameters
// Size: 0x50 (Inherited: 0x0)
struct FAnimationBudgetAllocatorParameters
{
	float BudgetInMs; // 0x0(0x4)
	float MinQuality; // 0x4(0x4)
	int MaxTickRate; // 0x8(0x4)
	float WorkUnitSmoothingSpeed; // 0xC(0x4)
	float AlwaysTickFalloffAggression; // 0x10(0x4)
	float InterpolationFalloffAggression; // 0x14(0x4)
	int InterpolationMaxRate; // 0x18(0x4)
	int MaxInterpolatedComponents; // 0x1C(0x4)
	float InterpolationTickMultiplier; // 0x20(0x4)
	float InitialEstimatedWorkUnitTimeMs; // 0x24(0x4)
	int MaxTickedOffsreenComponents; // 0x28(0x4)
	int StateChangeThrottleInFrames; // 0x2C(0x4)
	float BudgetFactorBeforeReducedWork; // 0x30(0x4)
	float BudgetFactorBeforeReducedWorkEpsilon; // 0x34(0x4)
	float BudgetPressureSmoothingSpeed; // 0x38(0x4)
	int ReducedWorkThrottleMinInFrames; // 0x3C(0x4)
	int ReducedWorkThrottleMaxInFrames; // 0x40(0x4)
	float BudgetFactorBeforeAggressiveReducedWork; // 0x44(0x4)
	int ReducedWorkThrottleMaxPerFrame; // 0x48(0x4)
	float BudgetPressureBeforeEmergencyReducedWork; // 0x4C(0x4)
};

// Object: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary
{

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x102099820
	// Params: [ Num(2) Size(0x58) ]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102093D98
	// [Call #6] RVA: 0x10519022C
	// [Call #7] RVA: 0x105190870
	// [Call #8] RVA: 0x10519022C

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	// Offset: 0x102099768
	// Params: [ Num(2) Size(0x9) ]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x10516D1A4
	// [Call #5] RVA: 0x102093CEC
	// [Call #6] RVA: 0x10516D168
	// [Call #7] RVA: 0x10516D1A4
	// [Call #8] RVA: 0x10516D168
	// [Call #9] RVA: 0x10516D1A4
	// [Call #10] RVA: 0x102093D98
	// [Call #11] RVA: 0x10519022C
};

// Object: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0x1370 (Inherited: 0x1350)
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent
{
	uint8_t Pad_0x1350[0x18]; // 0x1350(0x18)
	uint8_t bAutoRegisterWithBudgetAllocator : 1; // 0x1368(0x1), Mask(0x1)
	uint8_t bAutoCalculateSignificance : 1; // 0x1368(0x1), Mask(0x2)
	uint8_t bShouldUseActorRenderedFlag : 1; // 0x1368(0x1), Mask(0x4)
	uint8_t bKeepUpdateRateOptimizationWhenBudgeted : 1; // 0x1368(0x1), Mask(0x8)
	uint8_t BitPad_0x1368_4 : 4; // 0x1368(0x1)
	uint8_t Pad_0x1369[0x7]; // 0x1369(0x7)


	// Object: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102099b08
	// Params: [ Num(1) Size(0x1) ]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator);
	// [Call #1] RVA: 0x10516D168
	// [Call #2] RVA: 0x10516D1A4
	// [Call #3] RVA: 0x10519022C
	// [Call #4] RVA: 0x105190870
	// [Call #5] RVA: 0x10508F76C
	// [Call #6] RVA: 0x10518366C
};

