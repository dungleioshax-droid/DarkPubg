#pragma once

#include <cstdint>

// Object: Class SurviveLoadingScreen.SurviveLoadingSettings
// Size: 0x58 (Inherited: 0x38)
struct USurviveLoadingSettings : UDeveloperSettings
{
	struct TArray<struct FSoftObjectPath> Images; // 0x38(0x10)
	struct TArray<struct FSoftObjectPath> Videos; // 0x48(0x10)
};

