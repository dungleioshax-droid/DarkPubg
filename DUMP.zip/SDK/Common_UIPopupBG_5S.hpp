#pragma once

#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Common_UIPopupBG_5S.Common_UIPopupBG_5S_C
// Size: 0x278 (Inherited: 0x260)
struct UCommon_UIPopupBG_5S_C : UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x8)
	struct UButton* Button_0; // 0x268(0x8)
	struct UImage* Image_Mask; // 0x270(0x8)


	// Object: Function Common_UIPopupBG_5S.Common_UIPopupBG_5S_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10516df8c
	// Params: [ Num(0) Size(0x0) ]
	void Construct();
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0

	// Object: Function Common_UIPopupBG_5S.Common_UIPopupBG_5S_C.ExecuteUbergraph_Common_UIPopupBG_5S
	// Flags: [None]
	// Offset: 0x10516df8c
	// Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Common_UIPopupBG_5S(int EntryPoint);
	// [Call #1] RVA: 0x105099E5C
	// [Call #2] RVA: 0x10516D168
	// [Call #3] RVA: 0x10516D168
	// [Call #4] RVA: 0x106C8CAC8
	// [Call #5] RVA: 0x106C8CD38
	// [Call #6] RVA: 0x104F910F0
};

