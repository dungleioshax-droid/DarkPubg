#pragma once

#include <cstdint>

// Object: UserDefinedStruct BP_STRUCT_VehicleRefitParticleTable_type.BP_STRUCT_VehicleRefitParticleTable_type
// Size: 0x18 (Inherited: 0x0)
struct FBP_STRUCT_VehicleRefitParticleTable_type
{
	struct FString PartileBPPath_0_5E40F7001EF760FC74A533720BB8A4F8; // 0x0(0x10)
	int ID_1_7D8FDE406414C5ED44FDA70204464694; // 0x10(0x4)
	int StyleID_2_4BC8E2804CB29D6C7BC616430EFC4DA4; // 0x14(0x4)
};

