#pragma once

#include <cstdint>


namespace UEOffsets
{

namespace Config
{
    constexpr bool isUsingCasePreservingName = false;
    constexpr bool IsUsingFNamePool = false;
    constexpr bool isUsingOutlineNumberName = false;
}

namespace FName
{
    constexpr uintptr_t ComparisonIndex = 0x0;
    constexpr uintptr_t Number = 0x4;
    constexpr uintptr_t DisplayIndex = 0x0;
    constexpr uintptr_t Size = 0x8;
}

namespace FNameEntry
{
    constexpr uintptr_t Index = 0x8;
    constexpr uintptr_t Name = 0xc;
}

namespace FNamePool
{
    constexpr int32_t Stride = 0;
    constexpr int32_t BlocksBit = 0;
    constexpr uintptr_t BlocksOff = 0x0;
}

namespace FNamePoolEntry
{
    constexpr uintptr_t Header = 0x0;
}

namespace FUObjectArray
{
    constexpr uintptr_t ObjObjects = 0x10;
}

namespace TUObjectArray
{
    constexpr uintptr_t Objects = 0x0;
    constexpr uintptr_t NumElements = 0xc;
    constexpr uintptr_t NumElementsPerChunk = 0x0;
}

namespace FUObjectItem
{
    constexpr uintptr_t Object = 0x0;
    constexpr uintptr_t Size = 0x18;
}

namespace UObject
{
    constexpr uintptr_t ObjectFlags = 0x8;
    constexpr uintptr_t InternalIndex = 0xc;
    constexpr uintptr_t ClassPrivate = 0x10;
    constexpr uintptr_t NamePrivate = 0x18;
    constexpr uintptr_t OuterPrivate = 0x20;
}

namespace UField
{
    constexpr uintptr_t Next = 0x28;
}

namespace UEnum
{
    constexpr uintptr_t Names = 0x40;
}

namespace UStruct
{
    constexpr uintptr_t SuperStruct = 0x30;
    constexpr uintptr_t Children = 0x38;
    constexpr uintptr_t ChildProperties = 0x0;
    constexpr uintptr_t PropertiesSize = 0x40;
}

namespace UFunction
{
    constexpr uintptr_t EFunctionFlags = 0x88;
    constexpr uintptr_t NumParams = 0x8c;
    constexpr uintptr_t ParamSize = 0x8e;
    constexpr uintptr_t Func = 0xb0;
}

namespace UProperty
{
    constexpr uintptr_t ArrayDim = 0x30;
    constexpr uintptr_t ElementSize = 0x34;
    constexpr uintptr_t PropertyFlags = 0x38;
    constexpr uintptr_t Offset_Internal = 0x44;
    constexpr uintptr_t Size = 0x70;
}

namespace FField
{
    constexpr uintptr_t ClassPrivate = 0x0;
    constexpr uintptr_t Next = 0x0;
    constexpr uintptr_t NamePrivate = 0x0;
    constexpr uintptr_t FlagsPrivate = 0x0;
}

namespace FProperty
{
    constexpr uintptr_t ArrayDim = 0x0;
    constexpr uintptr_t ElementSize = 0x0;
    constexpr uintptr_t PropertyFlags = 0x0;
    constexpr uintptr_t Offset_Internal = 0x0;
    constexpr uintptr_t Size = 0x0;
}


}

namespace UEPointers
{
    constexpr uintptr_t Names = 0x10d492ac0;
    constexpr uintptr_t UObjectArray = 0x10a692d18;
    constexpr uintptr_t ObjObjects = 0x10a692d28;
    constexpr uintptr_t Engine = 0x10a8aa8a0;
    constexpr uintptr_t World = 0x0;
    constexpr uintptr_t ProcessEvent = 0x10516ec34;
    constexpr int32_t ProcessEventIndex = 76;
}